//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension O6ProcessBomLineAttributes
 *
 */
 
#ifndef O6PROCESSBOMLINEATTRIBUTES_HXX
#define O6PROCESSBOMLINEATTRIBUTES_HXX
#include <tccore/method.h>
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern O6TANECUSTOMLIBRARY_API int O6ProcessBomLineAttributes(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
                
#endif  // O6PROCESSBOMLINEATTRIBUTES_HXX
