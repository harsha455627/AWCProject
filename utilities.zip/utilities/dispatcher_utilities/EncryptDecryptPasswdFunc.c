#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*---------------------------------------------------------------------------
 *
 * Usage : encrypt/decrypt key passwd
 *
 *  WHO                          WHEN            WHAT
 *  Jasvinder Singh		 5/12/2000       Original Code
 *
 *---------------------------------------------------------------------------*/

static char *map1 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
static char map2[100];
static char map3[100];

shuffle( char *key, char *passwd ) 
{

    int ii, indx, max=0;
    strcpy( map2, map3 );
    strcpy(map2,"                                                              ");

    for( ii=0; ii<strlen(key); ii++ )
    {
            max += key[ii];
    }

    max = max + strlen( passwd ) + strlen( key );
    srand(max);


    for( ii=0; ii<strlen(map2); ii++ ) {
        indx = rand()%strlen(map2);
        while( strchr( map2, map1[indx] ) ) {
            indx = rand()%strlen(map2);
        }
        map2[ii] = map1[indx];
    }

}


/** OLD SHUFFLE
shuffle( char *key, char *passwd )
{
    int ii=0, indx=0, max=0;

    fprintf(stdout, "shuffle:before strcpy\n");
    strcpy( map2, map3 );
    fprintf(stdout, "shuffle:after strcpy\n");

    for( ii=0; ii<strlen(key); ii++ )
    {
	max += key[ii];
    }

    max = max + strlen( passwd ) + strlen( key );

    srand(max);
    for( ii=0; ii<strlen(map2); ii++ )
    {
	indx = rand()%strlen(map2);
	while( strchr( map2, map1[indx] ) ) indx = rand()%strlen(map2);
	map2[ii] = map1[indx];
    }
} 
**/

EncryptPasswd( char *passwd, char *key, char **out_passwd )
{
    long ii=0,jj=0,kk=0;
    char *aa="", *temp="";

    temp = (char *)calloc(strlen(passwd)+1,1);

    shuffle( key, passwd );
    for( ii=0; ii<strlen(passwd); ii++ )
    {
	aa = strchr( map1, passwd[ii] );
	if( aa )
	{
	    jj = strlen(map1)-strlen(aa);
	    temp[ii] = map2[jj];
	}
	else
	{
	    temp[ii] = passwd[ii];
	}
    }

    *out_passwd = temp;
}

DecryptPasswd( char *passwd, char *key, char **out_passwd )
{
    int ii=0,jj=0,kk=0;
    char *aa="", *temp="";

    temp = (char *)calloc(strlen(passwd)+1,1);

    shuffle( key, passwd );
    for( ii=0; ii<strlen(passwd); ii++ )
    {
	aa = strchr( map2, passwd[ii] );
	if( aa )
	{
	    jj = strlen(map1)-strlen(aa);
	    temp[ii] = map1[jj];
	}
	else
	{
	    temp[ii] = passwd[ii];
	}
    }
    /*printf ( "\n Decrypted password = %s", temp );*/

    *out_passwd = temp;
}
