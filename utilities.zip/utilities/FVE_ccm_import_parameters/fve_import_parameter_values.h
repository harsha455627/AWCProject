/******************************************************************************
 * Filename        :   fve_import_parameter_values.h
 * Description     :   Defines the macro used in fve_import_parameter_values.c
 * Module          :   fve_import_parameter_values.exe
 * ENVIRONMENT     :   C,ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * 08-Aug-2012    Kalyan	      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_IMPORT_PARAMETER_VALUES_H
#define FVE_IMPORT_PARAMETER_VALUES_H

/*************************************************
* System Header Files
**************************************************/
#include <fve_includes.h>

#define PASSWORDKEY     "PASSWORDKEY"

//structure to store  information related to Parameter value object
struct FVEParmValInfostruct
{
	char*	parmName;
	char*	parmRevId;
	char*	parmValue;
	char*	parmValueName;
	char*	vExprName;
};

//structure to store  information related to Variant condition Object
struct FVEVariantInfostruct
{
	char *vCondExpr;
	char *vCondName;
};

//structure to store information for configuration file
struct FVEConfigFileInfostruct
{
	char	*constantName;
	char	*lofFileName;
	char	*logFilePath;
	char	*logFileExt;
	char	*csvFileDelim;
	char	*tolerance;
};

//display help
static void display_usage(void);

//validate file arguments
int FVE_validate_files(char *filename1, char *filename2);

//free memory for structure variables
void FVE_MemFreeStructVariant(struct FVEVariantInfostruct *variantStruct);
void FVE_initialize_VariantStructure(struct FVEVariantInfostruct * variantStruct);
void FVE_initialize_ParmValStructure(struct FVEParmValInfostruct * parmValReportStruct);
void FVE_MemFreeStructParameterVal(struct FVEParmValInfostruct * parmReportStruct);
void FVE_MemFreeStructConfigFile(struct FVEConfigFileInfostruct *configInfoStruct);
void FVE_initialize_ConfigFiletructure(struct FVEConfigFileInfostruct * configInfoStruct);

//parse file functions
int FVE_parse_parmValFile(FILE *flPtrProcess,char *delim,struct FVEParmValInfostruct *parmValueInfo);
int FVE_parse_variantFile(FILE *flPtrProcess,char *delim,struct FVEVariantInfostruct *variantInfo);
int fve_parse_configFile(FILE *configFlPtr,char *delim,struct FVEConfigFileInfostruct *configInfo);

//process parameter value object
int fve_process_parameterValueInfo(struct FVEParmValInfostruct *parmValInfoStr,int totalNoOfParameters);
//int FVE_traverse_paramUsageBomLine(struct FVEParmValInfostruct *valInfoStr,tag_t bomLineUsageTag,int counter,char *name, char *values,char *varExpName);
int FVE_traverse_paramUsageBomLine(struct FVEParmValInfostruct *valInfoStr,tag_t bomLineUsageTag,int counter);

/*Create parameter value Object */
int FVE_create_parmValObject(tag_t bomLine,char *name,char *values,tag_t *parmValItem,tag_t *parmValRevision);

/*Variant Condition*/
int FV_check_variantCondition_exist(struct FVEVariantInfostruct *strVarInfo,char *variantCondition,char **variantExpression);
int FVDT_delete_variant_condition(tag_t window , tag_t bomLine);
//int FV_create_clauseList_from_text(tag_t bomWin, tag_t clauseList, char * textStr);
//int FV_get_option_details_from_string(char * optInfoStr, char ** optNameStr, int* condStr, char ** optValueStr);

//common function
/*TODO create seperate c file for this*/
extern char* FV_trim_blanks(char* inputStr);
int FVE_find_rev(char* item_id,	char* rev_id, tag_t* rev);
int FV_object_is_typeof(tag_t obj_tag, char* typename, logical* answer);
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );
int FV_check_bomLineExist_inStruct(tag_t topBl,char *objName,tag_t *tagMatchingBl);
int FV_get_set_window_fromRev(tag_t revision, tag_t *windowTag,tag_t *bomLineTag);
int split_the_string(char *consolidated_str,char *delim, int * str_cnt, char *** splitted_strings);
extern char* FV_trim_invalidChars(char* inputStr);
void fve_get_value(char * init_value, char ** attr, logical * is_value_null);
int fv_strdup(const char* inputString, char** outputString);
int fve_get_val_line(char *delim,char *line_temp,char *locName,char **firstStr,char **secondStr);
int FVE_get_value_arrays(tag_t rev, char *attr,char *** value_array);
void FVE_truncate_double_values(double num, char ** truncated_vale);
extern int FV_delete_pom_objects(int pomObjCnt, tag_t* pomObjTags);
int FVE_reCreate_cells_multipleValues(tag_t parmDefRev,int newNumRows,int newNumCols,char *propName,char **values,char **domainElVal,char **domainElDescr);
int FVE_set_value(tag_t rev,char *attr,char *val);
int FVE_set_values(tag_t rev,char *propName,char **valArray,int valCnt);
int FVE_create_cells_MinMaxInit(tag_t parmDefRev,int newNumRows,int oldNumRows,int newNumCols,int oldNumCols,char *propName,char *value);
int FVE_set_rowColumns(tag_t parmDefRev,int Rows,int Columns,logical flagRowLabel,logical flagColLabel,char **rowlabelArr,char **colLabelArr);
int FV_create_cells_labels(tag_t revision,int new_Rcount,int old_Rcount , char *rowPropName ,char **rowPropValues,int new_Colcount,int old_Colcount , char *colPropName ,char **colPropValues);
int FVE_reCreate_cellsLabels(tag_t revision,int new_count,char *propName,char **propValues);
int FV_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag);
int FV_add_unique_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag);
int FV_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag);
int FV_handle_missing_arg_error(const char* functionName, char* argumentName);
int FV_strdup_plus(const char* inputString, int extraCnt, char** outputString);
int FV_strdup(const char* inputString, char** outputString);
char* FV_int_to_static_string(int intValue);
void get_time_stamp(char* format, char** timestamp);
int FVE_get_desc_array(tag_t rev, char *attr,char *cellsProp,char *** value_array,int * retCnt);
int FV_create_clauseList_from_text(tag_t bomWin, tag_t clauseList, char * textStr);
int FV_check_bomLine_has_matching_variantCondText(tag_t bomLineTag, char* str, logical* isMatching);
#endif

