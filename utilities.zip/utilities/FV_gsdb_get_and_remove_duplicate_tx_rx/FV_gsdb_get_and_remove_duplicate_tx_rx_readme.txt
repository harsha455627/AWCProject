1. Run the utiltiy in dry run mode using the below command and give the generated reports to tester or BA
	FV_gsdb_get_and_remove_duplicate_tx_rx -u=user_id -p=password -g=dba
2. Once the tester or BA reviews the report, he will ask you to run utiltiy without dry run mode. Use the below command to run the utility and share the reports to Tester or BA.
	FV_gsdb_get_and_remove_duplicate_tx_rx -u=user_id -p=password -g=dba -delete_duplicate=yes