//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6Stock_custom_process
 *
 */
#include <O6TaneCustomLibrary/O6Stock_custom_process.hxx>
#include <O6TaneCustomLibrary/method.hxx>
#include <epm/epm_task_template_itk.h>

int O6Stock_custom_process( METHOD_message_t * /*msg*/, va_list args )
{
	int			irc = ITK_ok/*,irc2 = ITK_ok,nb,i*//*,m=0*/,m1=0,customization_exit=ITK_serious_error;
	char		/**pt,*/prop_name[133],msg_name[133],action_opt[33];
	char	*objectformsg = (char*)NULL;
	tag_t saved_object;

	*prop_name = *msg_name = *action_opt = '\0';
	saved_object = NULL_TAG;

	/*nb = TC_number_of_arguments ( msg->user_args );

	for (i=0; i<nb; i++)
	{
		if (msg->user_args->arguments[i].type == POM_string)
		{
			switch (i) {case 0: {strcpy(action_opt, msg->user_args->arguments[i].val_union.str_value);break;}case 1: {strcpy(msg_name, msg->user_args->arguments[i].val_union.str_value);break;}default: {break;}}
		}
	}*/
	//if (strcmp(msg_name, TC_save_msg) == 0)
	{
		/*tag_t	dummy, *dummy_pt*/;
		char	*sAttrValue = (char*)NULL;
		saved_object = (tag_t)va_arg(args, tag_t);
		irc = ITK_CALL(AOM_ask_value_string(saved_object, CURR_OBJ_STR, &sAttrValue));
		MEM_free(sAttrValue);
	}
	if (saved_object != NULL_TAG)
	{
		irc = ITK_CALL(AOM_ask_value_string(saved_object, CURR_OBJ_STR, &objectformsg));
		//for (pt=&action_opt[0]; *pt != '\0'; pt++)
		{
			//if (*pt == '1')
			{
			}
			//if (*pt == '2')
			{
				int attach_types[1] = {EPM_target_attachment},objects_count=0;
				tag_t *objects_tags,process_template=NULLTAG,process=NULLTAG;
				irc = ITK_CALL(EPM_find_process_template("S1 - MaterialRequest", &process_template));
				if (process_template!=NULLTAG)
				{
					irc= ITK_CALL( AOM_ask_value_tags(saved_object, "process_stage_list", &objects_count, &objects_tags));
					if (objects_count > 0)
					{
						MEM_free (objects_tags);
					}
					else
					{
						irc = ITK_CALL(EPM_create_process("MaterialRequest", "", process_template,1, &saved_object, attach_types, &process));
					}
				}
			}
		}
	}
	if (m1 != 0)
	{
		irc = ITK_CALL(EMH_store_error_s1 ( EMH_severity_information, m1, objectformsg));
		MEM_free(objectformsg);
		return customization_exit;
	}
	else
	{
		MEM_free(objectformsg);
		return ITK_ok;
	}
}
