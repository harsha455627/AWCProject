//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================


#ifndef TEAMCENTER_HELLO_GDXREPORT_HXX
#define TEAMCENTER_HELLO_GDXREPORT_HXX


#ifdef __cplusplus
extern "C"{
#endif

#include <tc/tc.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tccore/aom.h>

#ifdef __cplusplus
}
#endif


#include <iostream>
#include <vector>

#define DIDQUERY		"__DIDActive..."
#define DTCQUERY		"__DTCActive..."
#define ECUQUERY		"__GMRDBNonDiscontinuedandNonObsoleteECUs..."
#define RTNQUERY		"__RoutineActive..."
#define FTBQUERY		"__FV9GMRFailureTypeByte"
#define	FVE_TC_TIER		2
#define FV_GMRDB_REPORT_DIR_PREF		"FV_GMRDB_REPORT_DIR"

namespace Teamcenter
{
    namespace Hello
    {
        class GDXReport;


class  GDXReport
{
public:

	/* This method generates excel GDX Report and pastes it to "Export" Folder in GMRDB Folder Structure.
	 * This implementation makes use of CPP SOA Service FileimportexportService to export objects to GMRDB Excel report template*/
	void GDXReport::generateReport(FILE *gdxLogFile ,std::string directory,std::vector<std::string> templateIds,std::vector<std::string> reportNames);

	const std::string currentDateTime();

};



}} //end namespace
#endif

