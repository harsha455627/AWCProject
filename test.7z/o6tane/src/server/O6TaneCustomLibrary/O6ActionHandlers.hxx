/*
 * @file
 *
 *   This file contains the all the custom action handler headers.
 *   Note: For custom rule handler, create a new source and a header file.
 *
 */
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/tc_arguments.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <tc/preferences.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tc/tc_util.h>
#include <sa/tcfile.h>
#include <epm/epm.h>
#include <string>

/**
 * Handler arguments
 */
#define INCLUDE_TYPE "include_type"
#define ATTACHMENT "attachment"
#define RELATION "relation"
#define DATASET_TYPE "dataset_type"
#define ACTION "action"

/**
 * SEEDS Preferences
 */
#define OUT_FILES_PATH "SEEDS_sharepoint_staging_dir"

/**
 * Share point object mapping xml file name.
 */
#define SP_OBJ_MAP_DATASET_NAME "O6SharepointObjMapping"

/**
 * Error codes
 */


/**
 * Attributes
 */
#define TARGET "target"
#define REFERENCE "reference"
#define OBJECT_TYPE "object_type"
#define ITEMID "item_id"
#define REVID "item_revision_id"
#define XML_DATASET_TYPE "MISC"
#define XML_NMD_REF_NAME "MISC_TEXT"

/*Constants*/
#define UNDERSCORE "_"
#define CSV_FILE_EXTENSION ".csv"
#define COPIED_INCI_HEADER "o6_seeds_919701"
#define INCI_BOM_REPORT_HEADER "o6_seeds_919702"
#define COMMA_SYMBOL ","
#define SKIPPED_INCI_HEADER "o6_seeds_919703"
#define IMPURE_INCI_HEADER "o6_seeds_919704"
#define TEXT_DATASET_TYPE "Text"
#define INITIAL_DATASET_REV "A"
#define NOTEPAD "Notepad"
#define TEXT_REFERENCE "TEXT_REF"
#define TC_ATTACHES "TC_Attaches"


/*BOMLine Attributes*/
static int item_revtag_attribute;
static int item_tag_attribute;
static int item_id_attribute;
static int item_rev_name_attribute;
static int bl_occ_attribute;
static int item_uom_attribute;
static int bl_occ_o6_percent_theoric_attribute;
static int bl_occ_o6_vol_percent_theoric_attribute;
static int bl_occ_o6_phase_attribute;
static int bl_occ_o6_impurete_attribute;

typedef struct relation_s
{
	char* rel_name;
	struct relation_s *next;

}rel_t;


typedef struct arguments_s
{
	//char* include_type;
	//char* attachment;
	char* action;
	rel_t* rellist;
}arguments_t;

struct SkippedINCIInfo
{
	char* pcINCIId               = NULL;
	char* pcINCName              = NULL;
	char* pcAllergenValue        = NULL;
	char* pcApplType             = NULL;
	char* pcImpurete             = NULL;

	double dTotalPercentage      = 0.0;

	struct SkippedINCIInfo *next = NULL;
};

int CreateBVandBVR ( tag_t , tag_t );
int O6_export_data(EPM_action_message_t msg);
int o6_quali_quanti_calc ( EPM_action_message_t msg );

/*Extra set of Handlers merged with BMIDE later*/
int O6Stock_manage_request ( EPM_action_message_t msg );
int O6Stock_manage_goods ( EPM_action_message_t msg );
int O6Stock_set_goods_request_as_approved ( EPM_action_message_t msg );
int O6Stock_set_goods_request_as_rejected ( EPM_action_message_t msg );
int O6Stock_set_goods_request_as_cancelled ( EPM_action_message_t msg );
