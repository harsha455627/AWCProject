#include "FVE_milestone_notification.h"
#include "textsrv/iman_textserver.h" //modified by harsha //added the header file

static void print_help(void)
{
   printf("\nUsage of FVE_milestone_notification utility\n");
   printf("\nFVE_milestone_notification -u=<uid> -p=<pwd> -g=<grp>\n\n");
   printf("   uid = user id to login to teamcenter to use this utility\n");
   printf("   pwd = password of user teamcenter user\n");
   printf("   grp = group of teamcenter user\n");
   printf("   -h  = print help of utility\n\n");
   printf("   example: FVE_milestone_notification -u=David -p=\"\" -g=dba\n");
   printf("            FVE_milestone_notification -u=infodba -p=infodba -g=dba\n");
}

void dump_itk_errors(int stat, const char* prog_name, int lineNumber, const char* fileName)
{
   int          n_ifails=0;
   const int   *severities=NULL;
   const int   *ifails=NULL;
   const char  **texts=NULL;
   char        *errstring=NULL;

   EMH_ask_errors(&n_ifails, &severities, &ifails, &texts);
   if(n_ifails && texts != NULL)
   {
      if(ifails[n_ifails-1] == stat)
      {
         TC_write_syslog("%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
      }
      else
      {
         EMH_ask_error_text(stat, &errstring);
         TC_write_syslog("%s: Error %d: %s\n", prog_name, stat, errstring);
      }
   }
   else
   {
      EMH_ask_error_text(stat, &errstring);
      TC_write_syslog("%s: Error %d: %s\n", prog_name, stat, errstring);
   }
   MEM_free(errstring);
   TC_write_syslog("%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName);
}

int FVE_send_mail(tag_t reminderTask, char* dueDate)
{
   int      ifail                                = ITK_ok;

   tag_t    responsible_party                    = NULLTAG;
   tag_t    envelope                             = NULLTAG;

   char*    process_id                           = NULL;
   char*    task_name                            = NULL;

   char     customSubject[1024]                  = {'\0'};
   char     customComment[1024]                  = {'\0'};

   ITK(EPM_ask_responsible_party(reminderTask, &responsible_party))
   ITK(AOM_ask_value_string(reminderTask, "job_name", &process_id))
   ITK(AOM_ask_value_string(reminderTask, "object_name", &task_name))

   sprintf(customSubject, "Reminder for Process ID - {%s} ", process_id);
   sprintf(customComment , "Workflow Task \"%s\" is due on \"%s\" ",task_name, dueDate);

   ITK(FV_Mail_Envelope_create(customSubject, customComment, &envelope))
   ITK(MAIL_add_envelope_receiver(envelope, responsible_party))
   ITK(MAIL_send_envelope(envelope))

   return ifail;
}

int FVE_process_started_task( )
{
   int         ifail                            = ITK_ok;
   int         i                                = 0;
   int         numWipProc                       = 0;
   int         iCntWipProc                      = 0;
   int         entry_count                      = 0;
   int         obj_count                        = 0;
   int         answer                           = 0;
   int         answer1                          = 0;
   int         answer2                          = 0;
   int         answer3                          = 0;
   int         answer4                          = 0;
   int         week_before_ms                   = 0;
   int         after_n_days                     = 0;
   int         subtask_count                    = 0;
   int         notif_flag                       = FALSE;
   logical     veh_notif_flag                   = TRUE;

   date_t      today_date                       = NULLDATE; 
   date_t      milestone_due_date               = NULLDATE; 
   date_t      WorkFlowTaskDueDate              = NULLDATE;
   date_t      NotifyDate1                      = NULLDATE;
   date_t      NotifyDate2                      = NULLDATE;
   date_t      NotifyDate3                      = NULLDATE;
   date_t      NotifyDateTemp                   = NULLDATE;
   date_t      AfterNDaysDate                   = NULLDATE;

   tag_t       qry_tag                          = NULLTAG;
   tag_t       epmtask                          = NULLTAG;
   tag_t       work_flow_task_assign_obj        = NULLTAG;
   tag_t       veh_ms_assign_obj                = NULLTAG;
   tag_t       veh_notif_obj                    = NULLTAG;
   tag_t       vehicle_notif_class_id           = NULLTAG;
   tag_t       work_flow_task_assign_class_id   = NULLTAG;
   tag_t       workflow_process_id_attr_id      = NULLTAG;
   tag_t       task_id_attr_id                  = NULLTAG;
   tag_t       vehicle_assign_class_id          = NULLTAG;
   tag_t       veh_prog_id_attr_id              = NULLTAG;
   tag_t       veh_prog_rev_attr_id             = NULLTAG;
   tag_t       veh_prg_id_attr_id1              = NULLTAG;
   tag_t       veh_prg_rev_attr_id1             = NULLTAG;
   tag_t       milestone_id_attr_id             = NULLTAG;
   tag_t       enqid                            = NULLTAG;
   tag_t       task_enqid                       = NULLTAG;
   tag_t       enq_id1                          = NULLTAG;
   tag_t       enq_id2                          = NULLTAG;
   tag_t       enq_id3                          = NULLTAG;
   tag_t       enq_id4                          = NULLTAG;
   tag_t       enq_id5                          = NULLTAG;
   tag_t       new_enq                          = NULLTAG;

   tag_t*      wip_proc                         = NULL;
   tag_t*      wf_task_assign_objs              = NULL;
   tag_t*      veh_assign_objs                  = NULL;
   tag_t*      veh_notif_objs                   = NULL;
   tag_t*      childtasks                       = NULL;

   char*       qry_name                         = NULL;
   char*       process_id                       = NULL;
   char*       milestone_id                     = NULL;
   char*       vehicle_prog_id                  = NULL;
   char*       vehicle_prog_rev                 = NULL;
   char*       before_two_months                = NULL;
   char*       before_one_month                 = NULL;
   char*       before_one_week                  = NULL;
   char*       formattedCurrDate                = NULL;
   char*       formattedTempDate                = NULL;
   char*       formattedTaskDueDate             = NULL;
   char*       formattedAfterNDaysDate          = NULL;
   char*       formattedWFTaskDuedate           = NULL;
   char*       formattedMSDuedate               = NULL;
   char*       formattedNotifyDate1             = NULL;
   char*       formattedNotifyDate2             = NULL;
   char*       formattedNotifyDate3             = NULL;
   char*       task_name                        = NULL;

   char**      entries                          = NULL;
   char**      values                           = NULL;

   EPM_state_t task_state                       = 0;

   GET_CURRENT_DATE_TIME(today_date)

   ITK(DATE_date_to_string(today_date, DATE_FORMAT, &formattedCurrDate))
   printf("\nToday's Date: %s\n",formattedCurrDate);

   // Entries of query "InParamvalueWorkflow_query" are 
   // state_value=4 and template_name="002_Parameter Value setup flow"
   qry_name = IMAN_text(FVE_STARTED_WORKFLOW_TASK_QRY);
   ITK(QRY_find(qry_name, &qry_tag))
   if(qry_tag == NULLTAG)
   {
      printf("\n\"InParamvalueWorkflow_query\" query is not available in tc server\n");
   }
   ITK(QRY_find_user_entries(qry_tag, &entry_count, &entries, &values))
   ITK(QRY_execute(qry_tag, entry_count, entries, values, &numWipProc, &wip_proc))

   // Loop for all the started task of workflow "002_Parameter Value setup flow" 
   for(iCntWipProc = 0; iCntWipProc < numWipProc; iCntWipProc++)
   {
      notif_flag = FALSE;
      veh_notif_flag = FALSE;
      answer  = 999;
      answer1 = 999;
      answer2 = 999;
      answer3 = 999;
      answer4 = 999;
      epmtask = wip_proc[iCntWipProc];
      ITK(AOM_ask_value_string(epmtask, FVE_JOB_NAME, &process_id))
      ITK(EPM_ask_sub_tasks(epmtask, &subtask_count, &childtasks))
      for(i=0; i<subtask_count; i++)
      {
         ITK(AOM_ask_value_string(childtasks[i], FVE_OBJECT_NAME, &task_name))
         ITK(EPM_ask_state(childtasks[i], &task_state))
         if(task_state == EPM_started)
         {
            break;
         }
      }

      printf("\n<%d> Process ID: %s\n", iCntWipProc+1, process_id);
      printf("\n    Task Name: %s\n", task_name);

      ITK(POM_class_id_of_class(FVE_WF_TASK_ASSIGNMENT_CLASS, &work_flow_task_assign_class_id))
      ITK(POM_attr_id_of_attr(FVE_WF_PROCESS_ID_ATTR, FVE_WF_TASK_ASSIGNMENT_CLASS, &workflow_process_id_attr_id))
      ITK(POM_attr_id_of_attr(FVE_WORKFLOW_TASK, FVE_WF_TASK_ASSIGNMENT_CLASS, &task_id_attr_id))
      ITK(POM_create_enquiry_on_string(work_flow_task_assign_class_id, workflow_process_id_attr_id, POM_is_equal_to, &process_id, &enqid))
      ITK(POM_create_enquiry_on_string(work_flow_task_assign_class_id, task_id_attr_id, POM_is_equal_to, &task_name, &task_enqid))
      ITK(POM_combine_enquiries(enqid, POM_and, task_enqid, &new_enq))

      // Get the FVE_WfTaskMSAssignmtStorage object for given FVE_WorkflowProcessID and FVE_WorkflowTask
      ITK(POM_execute_enquiry(new_enq, &obj_count, &wf_task_assign_objs))

      if(obj_count<1)
         continue;

      work_flow_task_assign_obj = wf_task_assign_objs[0];

      ITK(AOM_ask_value_string(work_flow_task_assign_obj, FVE_MILESTONE_ID_ATTR, &milestone_id))
      ITK(AOM_ask_value_string(work_flow_task_assign_obj, FVE_VEH_PRG_ID_ATTR, &vehicle_prog_id))
      ITK(AOM_ask_value_string(work_flow_task_assign_obj, FVE_VEH_PRG_REV_ATTR, &vehicle_prog_rev))
      ITK(AOM_ask_value_int(work_flow_task_assign_obj, FVE_WEEKS_BEFORE_MS_ATTR, &week_before_ms))

      // Check if Vehicle Notification is enabled or disabled
      ITK(POM_class_id_of_class(FVE_VEH_NOTIFICATION_CLASS, &vehicle_notif_class_id))
      ITK(POM_attr_id_of_attr(FVE_VEH_PRG_ID_ATTR, FVE_VEH_NOTIFICATION_CLASS, &veh_prg_id_attr_id1))
      ITK(POM_attr_id_of_attr(FVE_VEH_PRG_REV_ATTR, FVE_VEH_NOTIFICATION_CLASS, &veh_prg_rev_attr_id1))

      ITK(POM_create_enquiry_on_string(vehicle_notif_class_id, veh_prg_id_attr_id1, POM_is_equal_to, &vehicle_prog_id, &enq_id1))
      ITK(POM_create_enquiry_on_string(vehicle_notif_class_id, veh_prg_rev_attr_id1, POM_is_equal_to, &vehicle_prog_rev, &enq_id2))

      ITK(POM_combine_enquiries(enq_id1, POM_and, enq_id2, &enq_id4))

      obj_count = 0;

      // Get the FVE_VehNotificationStorage object for given FVE_VehPrgID and FVE_VehPrgRev
      ITK(POM_execute_enquiry(enq_id4, &obj_count, &veh_notif_objs))

      if(obj_count>0)
      {
         veh_notif_obj = veh_notif_objs[0];
         ITK(AOM_ask_value_logical(veh_notif_obj, FVE_NOTIF_STATUS_ATTR, &veh_notif_flag))
      }

      if(veh_notif_flag == false)
      {
         printf("       Notification is disabled for vehicle %s. This task is of vehicle %s.\n", vehicle_prog_id, vehicle_prog_id);
         continue;
      }

      ITK(POM_class_id_of_class(FVE_VEH_MS_ASSIGNMT_CLASS, &vehicle_assign_class_id))
      ITK(POM_attr_id_of_attr(FVE_VEH_PRG_ID_ATTR, FVE_VEH_MS_ASSIGNMT_CLASS, &veh_prog_id_attr_id))
      ITK(POM_attr_id_of_attr(FVE_VEH_PRG_REV_ATTR, FVE_VEH_MS_ASSIGNMT_CLASS, &veh_prog_rev_attr_id))
      ITK(POM_attr_id_of_attr(FVE_MILESTONE_ID_ATTR, FVE_VEH_MS_ASSIGNMT_CLASS, &milestone_id_attr_id))

      ITK(POM_create_enquiry_on_string(vehicle_assign_class_id, veh_prog_id_attr_id, POM_is_equal_to, &vehicle_prog_id, &enq_id1))
      ITK(POM_create_enquiry_on_string(vehicle_assign_class_id, veh_prog_rev_attr_id, POM_is_equal_to, &vehicle_prog_rev, &enq_id2))
      ITK(POM_create_enquiry_on_string(vehicle_assign_class_id, milestone_id_attr_id, POM_is_equal_to, &milestone_id, &enq_id3))

      ITK(POM_combine_enquiries(enq_id1, POM_and, enq_id2, &enq_id4))
      ITK(POM_combine_enquiries(enq_id4, POM_and, enq_id3, &enq_id5))

      obj_count = 0;

      // Get the FVE_VehMSAssignmentStorage object for given FVE_VehPrgID, FVE_VehPrgRev and FVE_MilestoneID
      ITK(POM_execute_enquiry(enq_id5, &obj_count, &veh_assign_objs))

      if(obj_count<1)
         continue;

      veh_ms_assign_obj = veh_assign_objs[0];

      ITK(AOM_ask_value_date(veh_ms_assign_obj, FVE_MS_DUE_DATE_ATTR, &milestone_due_date))
      ITK(AOM_ask_value_string(veh_ms_assign_obj, FVE_BEFORE_TWO_MONTH_ATTR, &before_two_months))
      ITK(AOM_ask_value_string(veh_ms_assign_obj, FVE_BEFORE_ONE_MONTH_ATTR, &before_one_month))
      ITK(AOM_ask_value_string(veh_ms_assign_obj, FVE_BEFORE_ONE_WEEK_ATTR, &before_one_week))
      ITK(AOM_ask_value_int(veh_ms_assign_obj, FVE_AFTER_N_DAYS_ATTR, &after_n_days))

      GET_NEXT_DATE(milestone_due_date, -(week_before_ms * 7), WorkFlowTaskDueDate )

      GET_NEXT_DATE(WorkFlowTaskDueDate, after_n_days, AfterNDaysDate)
      ITK(DATE_date_to_string(AfterNDaysDate, DATE_FORMAT, &formattedAfterNDaysDate))

      ITK(DATE_date_to_string(milestone_due_date, DATE_FORMAT, &formattedMSDuedate))
      printf("\n       Milestone %s Due Date: %s\n",milestone_id, formattedMSDuedate);

      ITK(DATE_date_to_string(WorkFlowTaskDueDate, DATE_FORMAT, &formattedWFTaskDuedate))
      printf("\n       Task Due Date is %d weeks before \"%s\" milestone due date: %s\n",week_before_ms, milestone_id, formattedWFTaskDuedate);

      // Get the date that is one week before workflow task due date
      GET_NEXT_DATE(WorkFlowTaskDueDate, -7, NotifyDate3)

      ITK(DATE_date_to_string(NotifyDate3, DATE_FORMAT, &formattedNotifyDate3))
      printf("\n       Date 1 week before Task Due Date: %s\n",formattedNotifyDate3);

      // Get the date that is one month before workflow task due date
      GET_NEXT_DATE(WorkFlowTaskDueDate, -30, NotifyDate2)

      ITK(DATE_date_to_string(NotifyDate2, DATE_FORMAT, &formattedNotifyDate2))
      printf("\n       Date 1 month before Task Due Date: %s\n",formattedNotifyDate2);

      // Get the date that is two month before workflow task due date
      GET_NEXT_DATE(WorkFlowTaskDueDate, -60, NotifyDate1)

      ITK(DATE_date_to_string(NotifyDate1, DATE_FORMAT, &formattedNotifyDate1))
      printf("\n       Date 2 months before Task Due Date: %s\n",formattedNotifyDate1);

      COMPARE_DATES(today_date, NotifyDate1, answer1)
      COMPARE_DATES(today_date, NotifyDate2, answer2)
      COMPARE_DATES(today_date, NotifyDate3, answer3)
      COMPARE_DATES(today_date, WorkFlowTaskDueDate, answer4)

      if(before_two_months!=NULL && answer2<=0 && answer1>=0)
      {
         if(strcmp(before_two_months, FVE_MONTHLY) == 0)
         {
            printf("\n       Date to send notification: %s\n",formattedNotifyDate1);
            printf("\n       Date to send notification: %s\n",formattedNotifyDate2);
            if((strcmp(formattedNotifyDate1, formattedCurrDate) == 0) || (strcmp(formattedNotifyDate2, formattedCurrDate) == 0))
            {
               notif_flag = TRUE;
            }
         }
         else if(strcmp(before_two_months, FVE_WEEKLY) == 0)
         {
            NotifyDateTemp = NotifyDate2;
            answer = 0;
            while(answer >= 0)
            {
               COMPARE_DATES(NotifyDateTemp, NotifyDate1, answer)

               ITK(DATE_date_to_string(NotifyDateTemp, DATE_FORMAT, &formattedTempDate))
               printf("\n       Date to send notification: %s\n",formattedTempDate);

               if(answer == 0 || answer == 1)
               {
                  if(strcmp(formattedTempDate, formattedCurrDate) == 0)
                  {
                     notif_flag = TRUE;
                     break;
                  }
                  else
                  {
                     GET_NEXT_DATE(NotifyDate2, -7, NotifyDateTemp)
                     NotifyDate2 = NotifyDateTemp;
                  }
               }
            }
         }
         else if(strcmp(before_two_months, FVE_DAILY) == 0)
         {
            NotifyDateTemp = NotifyDate2;
            answer = 0;
            while(answer >= 0)
            {
               COMPARE_DATES(NotifyDateTemp, NotifyDate1, answer)

               ITK(DATE_date_to_string(NotifyDateTemp, DATE_FORMAT, &formattedTempDate))
               printf("\n       Date to send notification: %s\n",formattedTempDate);

               if(answer == 0 || answer == 1)
               {
                  if(strcmp(formattedTempDate, formattedCurrDate) == 0)
                  {
                     notif_flag = TRUE;
                     break;
                  }
                  else
                  {
                     GET_NEXT_DATE(NotifyDate2, -1, NotifyDateTemp)
                     NotifyDate2 = NotifyDateTemp;
                  }
               }
            }
         }
      }

      if(before_two_months!=NULL && answer3<=0 && answer2>=0)
      {
         if(strcmp(before_one_month, FVE_WEEKLY) == 0)
         {
            NotifyDateTemp = NotifyDate3;
            answer = 0;
            while(answer >= 0)
            {
               COMPARE_DATES(NotifyDateTemp, NotifyDate2, answer)

               ITK(DATE_date_to_string(NotifyDateTemp, DATE_FORMAT, &formattedTempDate))
               printf("\n       Date to send notification: %s\n",formattedTempDate);

               if(answer == 0 || answer == 1)
               {
                  if(strcmp(formattedTempDate, formattedCurrDate) == 0)
                  {
                     notif_flag = TRUE;
                     break;
                  }
                  else
                  {
                     GET_NEXT_DATE(NotifyDate3, -7, NotifyDateTemp)
                     NotifyDate3 = NotifyDateTemp;
                  }
               }
            }
         }
         else if(strcmp(before_one_month, FVE_DAILY) == 0)
         {
            NotifyDateTemp = NotifyDate3;
            answer = 0;
            while(answer >= 0)
            {
               COMPARE_DATES(NotifyDateTemp, NotifyDate2, answer)

               ITK(DATE_date_to_string(NotifyDateTemp, DATE_FORMAT, &formattedTempDate))
               printf("\n       Date to send notification: %s\n",formattedTempDate);

               if(answer == 0 || answer == 1)
               {
                  if(strcmp(formattedTempDate, formattedCurrDate) == 0)
                  {
                     notif_flag = TRUE;
                     break;
                  }
                  else
                  {
                     GET_NEXT_DATE(NotifyDate3, -1, NotifyDateTemp)
                     NotifyDate3 = NotifyDateTemp;
                  }
               }
            }
         }
      }

      if(before_two_months!=NULL && answer4<=0 && answer3>=0)
      {
         if(strcmp(before_one_week, FVE_DAILY) == 0)
         {
            NotifyDateTemp = WorkFlowTaskDueDate;
            answer = 0;
            while(answer >= 0)
            {
               COMPARE_DATES(NotifyDateTemp, NotifyDate3, answer)

               ITK(DATE_date_to_string(NotifyDateTemp, DATE_FORMAT, &formattedTempDate))
               printf("\n       Date to send notification: %s\n",formattedTempDate);

               if(answer == 0 || answer == 1)
               {
                  if(strcmp(formattedTempDate, formattedCurrDate) == 0)
                  {
                     notif_flag = TRUE;
                     break;
                  }
                  else
                  {
                     GET_NEXT_DATE(WorkFlowTaskDueDate, -1, NotifyDateTemp)
                     WorkFlowTaskDueDate = NotifyDateTemp;
                  }
               }
            }
         }
      }

      if(strcmp(formattedAfterNDaysDate, formattedCurrDate) == 0)
      {
         notif_flag = TRUE;
      }

      if(notif_flag == TRUE)
      {
         ITK(DATE_date_to_string(WorkFlowTaskDueDate, DATE_FORMAT, &formattedTaskDueDate))
         //FVE_send_mail() will send email to the recipients of epmtask.
         FVE_send_mail (childtasks[i], formattedTaskDueDate); 
      }
   }

   FVE_FREE(wf_task_assign_objs)
   FVE_FREE(veh_assign_objs)
   FVE_FREE(veh_notif_objs)
   FVE_FREE(wip_proc)
   return ifail;
}

extern int ITK_user_main(int argc, char **argv)
{
   int         ifail                = ITK_ok;
   char        *uid                 = NULL;
   char        *pwd                 = NULL;
   char        *grp                 = NULL;
  
   // Uncomment to debug
   //getch();
   argv = NULL;

   if(argc < 4)
   {
      print_help();
      exit(0);
   }
   if (ITK_ask_cli_argument("-h"))
   {
      print_help();
      exit(0);
   }

   uid = ITK_ask_cli_argument("-u=");
   pwd = ITK_ask_cli_argument("-p=");
   grp = ITK_ask_cli_argument("-g=");

   ITK(ITK_initialize_text_services(ITK_BATCH_TEXT_MODE))
   ITK(ITK_init_module (uid, pwd, grp))
   ITK(FVE_process_started_task())

   return ifail;
}

