/*==================================================================================================

File description:

    Filename: fve_par_import_offline.c
    Module  : main

Utility to import PAR File in Offline Mode        

===============================================================================
Date               Name                    Description of Change
Mar '2013		Monika Arora               Initial version
===============================================================================*/

#include <sys/stat.h>
#include <errno.h>
#include <sys/types.h>

#include "fve_par_import_offline.h"


extern int DecryptPasswd(char *encrptedPasswd,
                         char *keyValue,
                         char **actualPasswd);

/*--------------------------Function Prototypes-------------------------------*/

int readAndDecryptPasswd( char *passwdFile, char **passwd );

/*-------------------------------End------------------------------------------*/

extern int ITK_user_main( int argc, char **  argv )
{
    
	char *login_user = NULL;
    char *login_password = NULL;
	char *login_group =  NULL;
	char *pw_file_location = NULL;
    char *owning_user = NULL;
    char *owning_group = NULL;
    char *ecct_project_item_id = NULL;
    char *ecct_project_rev_id = NULL;
    char *paramGrpsStr = NULL;
    char *configObjsStr = NULL;
    char *datasetUid = NULL;
	
    int   ifail = ITK_ok;
   
    char*	function_name	= "fve_par_import_offline";
	
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }
	
	printf("\n Input Arguments...");
		
	owning_user = ITK_ask_cli_argument("-u=");
	printf ("\n owning_user=%s", owning_user);
	owning_group = ITK_ask_cli_argument("-g=");
	printf ("\n owning_group=%s", owning_group);
	ecct_project_item_id = ITK_ask_cli_argument("-i=");
	printf ("\n ecct_project_item_id=%s", ecct_project_item_id);
	ecct_project_rev_id = ITK_ask_cli_argument("-r=");
	printf ("\n ecct_project_rev_id=%s", ecct_project_rev_id);
	paramGrpsStr = ITK_ask_cli_argument("-p=");
	printf ("\n paramGrpsStr=%s", paramGrpsStr);
	configObjsStr = ITK_ask_cli_argument("-c=");
	printf ("\n configObjsStr=%s", configObjsStr);
	datasetUid = ITK_ask_cli_argument("-d=");
	printf ("\n datasetUid=%s", datasetUid);
	
	
    ITK_initialize_text_services (0);

	/*------------------------------------------------------------------------------*/
    /* This utility is invoked via Dispatcher User. Need to know                    */
	/* this user-id                                                                 */
    /*------------------------------------------------------------------------------*/
	login_user = getenv("FV_TC_DISP_USERID");
   
	if(login_user == NULL || tc_strlen(login_user) == 0)
	{
		printf("\nERROR: Environment variable FV_TC_DISP_USERID is not set. Exiting...");
		exit(0);

	}
	
	/*------------------------------------------------------------------------------*/
    /* This utility is invoked via Dispatcher User. Need to know                    */
	/* this group                                                                 */
    /*------------------------------------------------------------------------------*/
	login_group = getenv("FV_TC_DISP_GROUP");
   
	if(login_group == NULL || tc_strlen(login_group) == 0)
	{
		printf("\nERROR: Environment variable FV_TC_DISP_GROUP is not set. Exiting...");
		exit(0);

	}

	/*------------------------------------------------------------------------------*/
    /* This utility is invoked via Dispatcher User. Need to know                    */
	/* this password. If Password is not provided check for cncrypted password file */
    /*------------------------------------------------------------------------------*/
	login_password = getenv("FV_TC_DISP_PASSWORD");
   
	if(login_password == NULL || tc_strlen(login_password) == 0)
	{
	
		/*------------------------------------------------------------------------------*/
		/* This utility is invoked via Dispatcher User. Need to know                    */
		/* the location of encrypted password file                                      */
		/*------------------------------------------------------------------------------*/
		pw_file_location = getenv("FV_TC_DISP_PASSWORD_FILE");
   
		if(pw_file_location == NULL || tc_strlen(pw_file_location) == 0)
		{
			printf("\nERROR: Environment variable FV_TC_DISP_PASSWORD_FILE is not set. Exiting...");
			exit(0);
    
		}
		
		/*-------------------------------------------*/	
		/*          Decrypt the password             */
		/*-------------------------------------------*/
		if( pw_file_location != 0 )
		{
			readAndDecryptPasswd( pw_file_location, &login_password) ;
		}

	}

	if ( owning_user != NULL && strlen(owning_user)!=0 &&  
	     owning_group != NULL && strlen(owning_group)!=0 &&  
		 ecct_project_item_id != NULL && strlen(ecct_project_item_id)!=0 &&
		 ecct_project_rev_id != NULL && strlen(ecct_project_rev_id)!=0 &&
	 	 paramGrpsStr != NULL && strlen(paramGrpsStr)!=0 &&
		 configObjsStr != NULL && strlen(configObjsStr)!=0 &&
	     datasetUid != NULL && strlen(datasetUid)!=0
		)
	{
   		ITK(ITK_init_module (login_user, login_password, login_group))
		if(ifail != ITK_ok)
		{
			printf("Login with user id: %s, group:%s is unsuccessful\n", login_user, login_group);
			exit(0);
		}

	}
	
	printf("\ninvoking PAR Import...");
	
	ifail = FV_import_PAR_offline ( ecct_project_item_id,
                                 	ecct_project_rev_id, 
									owning_user, 
									owning_group, 
									paramGrpsStr, 
									configObjsStr,
									datasetUid
									);
	

	if(ifail == ITK_ok)
	{
		FV_DEBUG_TXT(("\n End : Successfully completed par import"));
	}
	
	//CLEANUP:
    
	FV_DEBUG_TXT(("Exiting %s\n", function_name))
	return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


/*--------------------------------------------------------------------------*/

void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: fve_par_import_offline <args>\n\n");
        printf(" Where args include the following:\n\n");
		printf(" -u=<owning user id> \n");
		printf(" -g=<owning user group> \n");
        printf(" -i=<ECCT Project ID> \n");
		printf(" -r=<ECCT Project Revision ID> \n");
		printf(" -p=<Param groups strings>\n");
		printf(" -c=<Configuration groups strings>\n");
        printf(" -d=<UID of par dataset>\n");
        printf("\n");
        printf(" NOTE:- \n");
        printf("**********************************************************************************\n\n");
}


void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
			EMH_ask_error_text (stat, &errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], texts[n_ifails-1] );
			printf("%s: Error: %d Line %d in %s\n", prog_name, ifails[n_ifails-1], lineNumber, errstring );
			MEM_free( errstring );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], errstring );
			printf("%s: Error: %d Line %d in %s\n", prog_name, ifails[n_ifails-1], lineNumber, errstring );
			MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
		TC_write_syslog( "%s: Error: %d %s\n", prog_name, stat, errstring );
		printf("%s: Error: %d Line %d in %s\n", prog_name, stat, lineNumber, errstring );
		MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	/*printf(logfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );*/
}


/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                  */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;


    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );        
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        printf( "ERROR: Invalid format for password file '%s'\n", passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);

    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");        
        return !ITK_ok ;
    }

    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;

    return ifail;
}

