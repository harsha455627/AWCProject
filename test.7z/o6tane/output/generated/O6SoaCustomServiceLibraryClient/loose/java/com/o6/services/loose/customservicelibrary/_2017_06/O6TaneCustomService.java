/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/


package com.o6.services.loose.customservicelibrary._2017_06;

/**
 *
 */
 @SuppressWarnings("unchecked")
public interface O6TaneCustomService
{

    public class TargetObjecs
    {
        /**
         * contain list of strings of Target Objects
         */
        public String[] displaynames = new String[0];
        /**
         * real names
         */
        public String[] realnames = new String[0];
        /**
         * Naming Rule Pattern
         */
        public String[] nrPattern = new String[0];
    }



    

    /**
     * Calculate ingredient percentage in the BOM.
     *
     * @param obj
     *        Selected object
     *
     * @return
     *
     */
    public com.teamcenter.soa.client.model.ServiceData calculateINCIs ( com.teamcenter.soa.client.model.ModelObject obj );


    /**
     * .
     *
     * @param obj
     *        Teamcenter Worksspace object
     *
     * @param targetItemtype
     *        Target Item Type
     *
     * @return
     *
     */
    public com.teamcenter.soa.client.model.ServiceData copyObjectAndCreateRelation ( com.teamcenter.soa.client.model.ModelObject obj, String targetItemtype );


    /**
     * .
     *
     * @param obj
     *        Workspace Object
     *
     * @return
     *
     */
    public com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService.TargetObjecs getTargets ( com.teamcenter.soa.client.model.ModelObject obj );



}
