//==================================================
// 
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================


#include <string>
#ifdef _WIN32
#pragma warning(push)
#pragma warning(disable:4018) //signed/unsigned mismatch
#pragma warning(disable:4290) // exception spec ignored
#endif

#include <exception>
#include <list>
#include <algorithm>
#include <iostream>  //for dump()
#include <new>

#include <teamcenter/clientx/AppXMemoryAllocator.hxx>
#include <teamcenter/soa/common/MemoryAllocator.hxx>


using namespace std;
using namespace Teamcenter::Soa::Common;


Teamcenter::ClientX::AppXMemoryAllocator::AppXMemoryAllocator():
    MemoryAllocator()
{
}

Teamcenter::ClientX::AppXMemoryAllocator::~AppXMemoryAllocator()
{
}

void* Teamcenter::ClientX::AppXMemoryAllocator::allocate(size_t size)
{
    void* p = NULL;
    p = malloc(size);

    return p;
}

void Teamcenter::ClientX::AppXMemoryAllocator::deallocate(void *p)
{
    if( p )
        free(p);

}

void* Teamcenter::ClientX::AppXMemoryAllocator::placementallocate(size_t, void* _where)
{
    return _where;
}

void Teamcenter::ClientX::AppXMemoryAllocator::placementdeallocate(void*, void*)
{
}

std::string Teamcenter::ClientX::AppXMemoryAllocator::getAllocatorID()
{
    return "Teamcenter::Soa::Client::AppXMemoryAllocator";//Think about a better id.
}
