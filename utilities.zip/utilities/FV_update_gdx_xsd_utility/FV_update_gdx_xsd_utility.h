/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tcinit/tcinit.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tc/folder.h>

#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <res/res_itk.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>


/*************************************************
* System Header Files
**************************************************/
#include <stdlib.h>


/*************************************************
/* MACROS
**************************************************/
#define DATE_FORMAT_STR			"%m%d%Y_%H%M%S"
#define IP_PUBLIC				"Public"
#define DATASET_TYPE			"Text"
#define GDX_XSD_TEMPLATE_FOLDER	"GDX XSD Templates"


#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}	

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\


/*--------------------------Function Prototypes-------------------------------*/
static void print_usage(void);
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null);
//void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );//commented by harsha
int fve_create_dataset (char  *pchDatasetName,char  *pchDatasetDesc,char  *pchDatasetType,tag_t *tagDataSet);
int fve_import_file(char  *file,tag_t *file_tag);
int fve_attach_file (tag_t	dataset,tag_t	file_tag,char	*dst_type );
int fve_attach_template_to_folder (tag_t	dataset);
int fve_delete_template (tag_t	dataset);
int fve_update_xsd_definition(char * template_name,char * template_file,char * template_home);
int fve_create_xsd_template(char * template_name,char * template_file,char * template_home,char * template_folder_name);
