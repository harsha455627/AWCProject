/******************************************************************************
 * Filename         :   fve_import_parameters.c
 * Utility to import parameters from csv file.
 *
 * To maintain the log file related information like  log file name , path and extension ,some constant values
   Configuration file with name "FVE_ccm_config.txt" should exist where utility is executed.
   if this configuration file not exist ,
                                    1.log file will be created with executable name on time stamp basis where utility is executed.
									2.Deafult delimeter "||" will be considered for parsing csv files.Make sure csv file contains this parameter.
   if this configuration file exist ,it should specify log file related information ,delimeter used for csv file parsing & ..


 *
 *Utility Arguments
 *				-u=
                -p=
				-g=
				-dicId
				-revId
				-mode=parameter or -mode=process or -mode=all
				-parmdeffile=
				-processdeffile=

 * Folowing default values get used for Parameter Definitions.
 * unit = None ,if csv file didnt provide value for unit
          "Unitless" unit will be considered as "None"
 * Parameter type = Configuration , if csv file didnt provide value for parameter type.
 * denominator = 1
 * numerator= value of resolution
 * tolerance 1) If the tolerance is provided in the input file, use this value
			 2) If the tolerance is not provided in the input file and if it is provided in the configuration file use from the configuration file
             3) If the tolerance is not provided either in input file or configuration file hardcode the value in the program?
 *
 *Assumption :
 *CSV file should give values for following columns(Order is important as parsing function stores values as per this column sequence- Total 34)
 *NameOfData	DescriptionOfData	TypeOfData	CategoryOfData	StorageClass	InitialValue	StructureOfData	Units	Resolution	Tolerance	NumberOfRows	NumberOfColumns	RowLabels	ColumnLabels	Min	Max	Overwritable	Fault	Restricted	ImplementationDataType	Domain Element Name	Domain Element value	Domain Element Description	Source	Sink	Source & Sink	Local	ImplementedResolution	Offset	ConfigGrp	Inhale_Exhale	AsBuilt_VehOp	ModuleManf	FCSDCustPref ModelUnit Size

*Note BCM : For string type yet it is not finilized that which delimiter is used to specify for multile values .
			So currently it is assume that  string type  will contain only 1 row, 1 column and only 1 value for initial .
			Min/max values are not mandatory.If provided , entire string will be assume as single entry.
		    so currently any value specified for Initial/Min/max , it will not be parsed.
			Only validation should be made that value count=row*column
			 
			 e.g.Initial Value=SC +P1 -P3 00  or    
				 Initial Value=SC +P2 -P5 +P2 -P5 00
Note BCM :
		  For String Type : 
			if typeOfdata is character and structureOfdata is 1DArray , row=1 and column=1
			if Discrete and structureOfdata is  1DArray/2DArray/1DLookup/2DLookup , get row/column information from csv file

 * History
 *------------------------------------------------------------------------------
 * Date					Name				Description of Change
 * 3-Apr-2012			Swapnal Shewale         Created.
 * 8-Jun-2012           Swapnal Shewale      Modify parsing function to get Row/Column Labels ,Row/Column Count.
                                             Create/Update Parameter definitions(Int/Dbl) to set Min/Max/Initial/RowLabels/ColumnLabels.
											 Generate Failure Log File the includes only fail objects.
											 Remove userRole from configuration file.
 *21-Jun-2012           Swapnal Shewale      During update of parameter definition ,Delete existing cells for Min/max/Initial table ,Labels and reCreate again to set the updated values.

 *4-July-2012           Swapnal Shewale      Add validation for Structure Of data for Int/Dbl Type .No of rows and columns should exist based on structure of data.
 *25-July-2012			Swapnal Shewale		 Added 2 more columns in CSV  file i.e."Model Unit" and "Size"
                                             Include 2 more parameter definition types i.e. String and Hex.
 *22-August-2012        Swapnal Shewale      Map (TypeOfdata - Discrete  StructureOfdata-1DLookup/2DLookup/1DArray/2DArray ) with StringType insted of HexType 
 *05-sept-2012          Swapnal Shewale		 HEX type -->if any vale from "Initial Value Array" contains prefix "0x" , create HEX type.
                                             DROP 6 : Check will be made only for initial value.
 *05-sep-2012           Shalini Tawar        Changes to handle singles lines in csv with larger size    
 *07-sep-2012           Swapnal Shewale      Handled row/column label  create/update scenario irrespective of structure of data.
 *04-Oct-2012           Swapnal Shewale      If same set of process files is used for different dictionaries with different ECU , create
                                             relation FVE_Mod_Proc_Relation between new ECU and Existing process object.
 *26-Mar-2013           Shalini Tawar        Fix for hex type parameter creation on Solaris env.
 *
 *10-Apr-2013           Nikhil Patil         Fix - configuration file can be provided from input argument.
 *
 *16-Apr-2013           Nikhil Patil         If any of 3 table cells(min,max,intial) values starts with 0x,
 *                                           consider that parameter as type HEX.
 *                                           Also, set those value on table cells.
 *
 *18-Apr-2013           Nikhil Patil         Consider resolution value based on init, min,max values.
 *22-Apr-2013           Shalini Tawar        Fixed performance issues by removing unwandted refresh
 *                                           & check out APIs
 *25-Apr-2013           Shalini Tawar        Fixed change management issues.

 *26-Apr-2013           Nikhil Patil         Removed leading spaces from domain element name 
 *                                           and domain element value.
 *29-Apr-2013           Shalini Tawar        Fix change management issues when dictionary id is provided
 *29-Apr-2013           Nikhil Patil        Changes related to configuration file -
 *                                          If a config file is not available at the same location where the utility is executed or
 *                                          If the config file path (-configFile command line argument) is provided but
 *                                          the config file does not exist in that location - 
 *                                          throw an error saying 
 *                                          “+++ERROR: Config file is not provided. Please specify the location for the file FVE_ccm_config.txt” 
 *                                          and quit from there
 *30-Apr-2013          Shalini Tawar        Changes to remove old & create new parameter if on update parameter type is changed
 *08-May-2013          Shalini Tawar        Changes to solve access problems on reimport.
 *09-May-2013          Shalini Tawar        Changes to handle update of discrete data
 *10-May-2013          Shalini Tawar        Changes to handle update of parameters when group info is provided in CSV file.
 *Oct 2016           Karthik              VSEM4.0: Modified the code to replace deprecated API's.
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/

#include <sys/stat.h>
#include "fve_import_parameters.h"
#include "fve_macros.h"
#include "fve_constants.h"
#include "fve_includes.h"

FILE		*logfileptr				=	NULL;
FILE		*fileptr1				=	0;
FILE		*fileptr2				=	0;
FILE		*logFilePtrFailure			=	NULL;
int			totalNoOfParameters		=	0;
int			totalNoOfProcess		=	0;
int			successCntParameter		=	0;
int			failureCntParameter		=	0;
int			successCntProcesses		=	0;
int			failureCntProcesses		=	0;
char		* dicId					=	NULL;
char		* dicRevId				=	NULL;
char		*mode					=	NULL;
char		*ecuAcronym				=	NULL;
char		*csvConfigFileDelimeter		=	NULL;
char		*toleranceExistInConfigFile	=	NULL;
tag_t		dicRevTag				=	NULLTAG;
tag_t		dicItemTag				=	NULLTAG;
tag_t		topDicBomLine			=	NULLTAG;
tag_t		windowDic				=	NULLTAG;

//this is tag for groupBl
tag_t		orgBlTag				=	NULLTAG;
logical		isRevise				=	FALSE;
logical     ignoreProcessFile		=	FALSE;
char		*filename1				=	NULL;
char		*filename2				=	NULL;
struct      FVEParmDefInfostruct	*strParmInfo		= NULL;
struct		FVEProcessInfostruct	*strProcessInfo		=	NULL;
struct      stat file_stat;
struct      stat file_statProcessInfo;
struct      stat configFile_stat;

char		*file_pathFailure			=	NULL;
char 		*login_group				=	NULL;
char 		*login_user					=	NULL;
char        *upwf                       =   NULL;
char		currentRoleName[SA_name_size_c+1]	=	"";
char		*exeName					=	NULL;
logical     isDictionary				=	FALSE;
logical     isECCTProjectRev			=	FALSE;

//BCM
tag_t	ecctRevTag		=	NULLTAG;
tag_t	ecctItemTag		=	NULLTAG;
tag_t	primeDicItem	=	NULLTAG;
tag_t	primeDicRevision	=	NULLTAG;	
char	*ecctItemName	=	NULL;
tag_t	windowPrimeDic	=	NULLTAG;
tag_t	topBlPrimeDic	=	NULLTAG;
tag_t	topBlECCTPrj	=	NULLTAG;
tag_t	windowECCTPrj	=	NULLTAG;
char	itemIdForPrimeDic[ITEM_id_size_c+1] = {'\0'};
char    primeDicRevId[ITEM_id_size_c+1] = "";
char	*dicIdOnECCTRev		= NULL;

//Change Management variables
int		revisedObjsCnt		=	0;
tag_t	*revisedObjs		=	NULL;
logical	lgInContextMode		=	FALSE;

// Pointer to point configuration file path.
char*   configFileInput     =   NULL;

// File pointer to config file.
FILE    *configFilePtr      =   0;


extern int ITK_user_main( int argc, char **  argv)
{

    int  		ifail						=	ITK_ok;
	int			iCounter					=	0;
	int			totalNoOfConfigCons			=	0;
    char 		*login_password				=	NULL;
    char        logfilename[255 + 1]		=	"";
	char        logfilename_failure[255 + 1]		=	"";
	char		* time_stamp				=	NULL;
	char		* file_path					=	NULL;
	char		*lgFlName					=	NULL;
	char		*lgFlPath					=	NULL;
	char		*lgFlExt					=	NULL;
	char*       representsValue				=	NULL;
	char		object_type[WSO_name_size_c+1]	=	"";
	const char	*configFlName				=	NULL;
	tag_t		current_role_tag			=	NULLTAG;
	logical		isConfigFilePresent			=	FALSE;
	
    /* Nikhil Patil - Make this global variable. 

    FILE		*configFilePtr				=	0;

    */

	time_t      clock;
	int			numUsersSE					=	0;
	tag_t		*list_usersSE				=	NULL;
	int			numUsersMS					=	0;
	tag_t		*list_usersMS				=	NULL;
	int			numUsersDBA					=	0;
	tag_t		*list_usersDBA				=	NULL;
	int			numUsersCC					=	0;
	tag_t		*list_usersCC				=	NULL;
	char		*message					=	NULL;
	tag_t		group_tag					=	NULLTAG;
	tag_t		user_tag					=	NULLTAG;
	tag_t		se_role_tag					=	NULLTAG;
	tag_t		ms_role_tag					=	NULLTAG;
	tag_t		dba_role_tag				=	NULLTAG;
	tag_t		cc_role_tag			     	=	NULLTAG;
	//structure variables
	struct		FVEConfigFileInfostruct	*strConfigInfo	=	NULL;
	struct      stat configFile_stat;
	logical		sessionFlag					=	FALSE;
	struct		tm *time_struct;


    if( argc < 1)
    {
        print_usage();
        exit(0);
    }

    if (( ITK_ask_cli_argument( "-help" ) ) ||
		( ITK_ask_cli_argument( "-h" ) )    ||
		( ITK_ask_cli_argument( "-H" ) )
	   )
    {
        print_usage();
        exit(0);
    }

	login_user		=	ITK_ask_cli_argument("-u=");
	login_password	=	ITK_ask_cli_argument("-p=");
	upwf            =   ITK_ask_cli_argument("-pf=");/* gets the password file*/
	login_group		=	ITK_ask_cli_argument("-g=");
	dicId			=	ITK_ask_cli_argument("-itemid=");
	dicRevId		=	ITK_ask_cli_argument("-revid=");
	//-mode=<parameter or process or all>
	mode			=	ITK_ask_cli_argument("-mode=");
	filename1		=	ITK_ask_cli_argument("-parmdeffile=");
	filename2		=	ITK_ask_cli_argument("-processdeffile=");

    configFileInput =   ITK_ask_cli_argument("-configFile=");
	
	/*-------------------------------------------*/
    /*          Decrypt the password             */
    /*-------------------------------------------*/

    if( upwf != 0 )
    {
       readAndDecryptPasswd( upwf, &login_password) ;
    }


	if(login_user == NULL || tc_strlen(login_user) == 0)
	{
		fprintf(stderr,"\nERROR: -u=%s is Not provided.Please provide userid\n","user Id");
		print_usage();
        exit(0);

	}
	if(login_password == NULL || tc_strlen(login_password) ==0)
	{
		fprintf(stderr,"\nERROR: -p=%s is not provided.Please provide password\n","password");
		print_usage();
        exit(0);
	}
	if(login_group == NULL || tc_strlen(login_group) == 0)
	{
		fprintf(stderr,"\nERROR: -g=%s is not provided.Please provide group name\n","group Name");
		print_usage();
        exit(0);
	}
	if(dicId == NULL || tc_strlen(dicId) == 0)
	{
		fprintf(stderr,"\nERROR: -itemid=%s is not provided.\nPlease provide item Id.\n","item Id");
		print_usage();
        exit(0);
	}
	if(dicRevId == NULL || tc_strlen(dicRevId) == 0)
	{
		fprintf(stderr,"\nERROR: -revid=%s is not provided.\nPlease provide Revision Id.\n","revision Id");
		print_usage();
        exit(0);
	}
	if(mode == NULL || tc_strlen(mode) == 0)
	{
		fprintf(stderr,"\nERROR: -mode is not provided.\nPlease provide mode=parameter or mode=process or mode=all\n");
		print_usage();
        exit(0);
	}

	ifail=FVE_validate_arguments(mode);

	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	printf("Logging in...\n");
	if (( ifail = ITK_init_module(login_user,login_password,FV_trim_blanks(login_group))) != ITK_ok)
	{
		fprintf(stderr,"\nERROR: %d, Failed to login, See syslog file for details\n", ifail);
		printf("\nFailed to login.Either userId , Password or Group is wrong.\n");
		EMH_ask_error_text (ifail, &message);
		fprintf(stderr,"\nERROR: %s\n",message);
		exit(1);
	}


    
    // Nikhil Patil changes starts.
    if ( configFilePtr == 0)
    {
        //log file information
        /*Check if configuration file exist*/
        configFlName=FVE_CCM_CONFIG_FILE_NAME;
        configFilePtr=fopen(configFlName, "r");
    }
    // Nikhil Patil changes ends.
	if(configFilePtr == 0)
    {
        /*
            If a config file is not available at the same location where the utility is executed or
            If the config file path (-configFile command line argument) is provided but
            the config file does not exist in that location - 
            throw an error saying 
            “+++ERROR: Config file is not provided. Please specify the location for the file FVE_ccm_config.txt” 
            and quit from there
        */

            fprintf(stderr, "+++ERROR: Config file is not provided. Please specify the location for the file FVE_ccm_config.txt\n\n");
            exit(1);
    }else
	{
            // Nikhil Patil changes starts.
            if( configFlName == NULL || tc_strlen(configFlName) == 0 )
            {
                ITK(FV_strdup(configFileInput, &configFlName))
                //configFlName = ( (char*) MEM_alloc( sizeof(char) * tc_strlen(configFileInput) ) );
                //tc_strcpy(configFlName, configFileInput);
            }
            // Nikhil Patil changes ends.
			stat( configFlName, &configFile_stat);
			if( configFile_stat.st_size == 0 )
			{
				 printf("Warning: Config File [%s] is empty!!.\n", configFlName);
			}else
			{
				strConfigInfo=(struct FVEConfigFileInfostruct*)MEM_alloc((sizeof(struct FVEConfigFileInfostruct))*MAX_STRCT);
				FVE_initialize_ConfigFiletructure(strConfigInfo);
				//parse file to get the log file constants.
				totalNoOfConfigCons=fve_parse_configFile(configFilePtr,TXT_FILE_DELIM,strConfigInfo);
				if(totalNoOfConfigCons > 0)
				{
					//make sure log file name , path and extension exist
					for(iCounter=0;iCounter<totalNoOfConfigCons;iCounter++)
					{
						if(strConfigInfo[iCounter].constantName != NULL &&
							tc_strlen(strConfigInfo[iCounter].constantName) > 0 )
						{
							if(tc_strcmp(strConfigInfo[iCounter].constantName ,LOG_FILE_NAME) == 0)
							{
								if(strConfigInfo[iCounter].lofFileName != NULL && tc_strlen(strConfigInfo[iCounter].lofFileName)> 0)
								{
									lgFlName=(char*) MEM_alloc((int) (strlen(strConfigInfo[iCounter].lofFileName)+1)* sizeof(char));
									tc_strcpy(lgFlName,strConfigInfo[iCounter].lofFileName);
								}
							}else if(tc_strcmp(strConfigInfo[iCounter].constantName ,LOG_FILE_PATH) == 0)
							{
								if(strConfigInfo[iCounter].logFilePath != NULL && tc_strlen(strConfigInfo[iCounter].logFilePath)> 0)
								{
									lgFlPath=(char*) MEM_alloc((int) (strlen(strConfigInfo[iCounter].logFilePath)+1)* sizeof(char));
									tc_strcpy(lgFlPath,strConfigInfo[iCounter].logFilePath);
								}
							}else if(tc_strcmp(strConfigInfo[iCounter].constantName ,LOG_FILE_EXTENSION) == 0)
							{
								if(strConfigInfo[iCounter].logFileExt != NULL && tc_strlen(strConfigInfo[iCounter].logFileExt)> 0)
								{
									lgFlExt=(char*) MEM_alloc((int) (strlen(strConfigInfo[iCounter].logFileExt)+1)* sizeof(char));
									tc_strcpy(lgFlExt,strConfigInfo[iCounter].logFileExt);
								}
							}
						}//if
					}//for
					if(lgFlName && lgFlPath && lgFlExt )
						isConfigFilePresent = TRUE;

				}// totalNoOfConfigCons> 0
			}//configFile_stat.st_size == 0
	}//configFilePtr

	 /*Append the log file name with the date and time stamp along with Process ID */
	if(isConfigFilePresent == FALSE)
	{
		time( &clock );
		time_struct= localtime(&clock);
		#ifdef UNX
			sprintf(logfilename,"%s_%d_%02d_%02d_%d_%02d:%02d.log",argv[0],getpid(),
                 (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );

			sprintf(logfilename_failure,"%s_%s_%d_%02d_%02d_%d_%02d:%02d.log",argv[0],"failed_list",getpid(),
                 (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );

		#else
			sprintf(logfilename,"%s_%02d_%02d_%d_%02d_%02d.log",argv[0],
                    (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );

			sprintf(logfilename_failure,"%s_%s_%02d_%02d_%d_%02d_%02d.log",argv[0],"failed_list",
                    (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );
		#endif

		logfileptr = fopen( logfilename, "w+");
	}else
	{
		/*Append the log file name with the date and time stamp */
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		sprintf(logfilename,"%s",lgFlName);
		strcat(logfilename,"_");
		strcat(logfilename,time_stamp);

		file_path = (char*)MEM_alloc((int)(strlen(lgFlPath)+strlen(logfilename) +10) * sizeof(char));
		strcpy(file_path, lgFlPath);
		
        strcat(file_path, FILEPATH_DELIMITER);
		strcat(file_path, logfilename);
		strcat(file_path, ".");
		strcat(file_path, lgFlExt);
		logfileptr = fopen(file_path, "w+");

		//failure file name
		sprintf(logfilename_failure,"%s",lgFlName);
		strcat(logfilename_failure,"_");
		strcat(logfilename_failure,"failed_list");
		strcat(logfilename_failure,"_");
		strcat(logfilename_failure,time_stamp);

		file_pathFailure = (char*)MEM_alloc((int)(strlen(lgFlPath)+strlen(logfilename_failure) +10) * sizeof(char));
		strcpy(file_pathFailure, lgFlPath);
		strcat(file_pathFailure, FILEPATH_DELIMITER);
		strcat(file_pathFailure, logfilename_failure);
		strcat(file_pathFailure, ".");
		strcat(file_pathFailure, lgFlExt);

	}

	//verify if user is a member of a group and having a certain role
	if(login_group && tc_strlen(login_group)> 0 && login_user && tc_strlen(login_user)> 0)
	{
		ITK(SA_find_groupmember_by_rolename(FV_SW_ENGG_ROLE,login_group,login_user,&numUsersSE,&list_usersSE))
		ITK(SA_find_groupmember_by_rolename(FV_Module_SVR_ROLE,login_group,login_user,&numUsersMS,&list_usersMS))
		ITK(SA_find_groupmember_by_rolename(DBA_ROLE,login_group,login_user,&numUsersDBA,&list_usersDBA))
		ITK(SA_find_groupmember_by_rolename(CONF_COORD_ROLE,login_group,login_user,&numUsersCC,&list_usersCC))
		ITK(SA_find_group(login_group,&group_tag))
		ITK(SA_find_user(login_user,&user_tag))
	}

	//get the current login user role
	ITK(SA_ask_current_role(&current_role_tag))
	ITK(SA_ask_role_name(current_role_tag, currentRoleName))
	ITK(SA_find_role(FV_SW_ENGG_ROLE,&se_role_tag))
	ITK(SA_find_role(FV_Module_SVR_ROLE,&ms_role_tag))
	ITK(SA_find_role(DBA_ROLE,&dba_role_tag))
	ITK(SA_find_role(CONF_COORD_ROLE,&cc_role_tag))


	fprintf(logfileptr,"<Current Role name> %s.\n",currentRoleName);
	fprintf(logfileptr,"\n");
	if((currentRoleName) && (tc_strlen(currentRoleName)> 0))
	{
		/*check if the given role is a valid role in order to be able to run the script and
		 also check if the given user id is having the role specified in the config file*/
		if( (tc_strcasecmp(currentRoleName, FV_SW_ENGG_ROLE) == 0) || (tc_strcasecmp(currentRoleName, FV_Module_SVR_ROLE) == 0) || (tc_strcasecmp(currentRoleName, CONF_COORD_ROLE) == 0) || (tc_strcasecmp(currentRoleName,DBA_ROLE) == 0))
		{
			sessionFlag=TRUE;
		}else
		{
			/*
			if current user belongs to all 4 valid roles i.e. SE/MS/CC/DBA
				First Priority will be given for DBA , Then CC, SE and  last MS
				1.utility should get execute with DBA role.

			if current user belongs to any 3 roles valid roles i.e.
				1.SE/CC/MS or SE/DBA  ->utility should get execute with DBA
				2.CC/DBA -> utility should get execute with DBA
				3.MS/DBA -->Utility should get execute with DBA
			*/

			if(list_usersSE || numUsersSE > 0 || list_usersCC || numUsersCC > 0 || list_usersMS || list_usersDBA || numUsersMS > 0 || numUsersDBA > 0)
			{

				if(user_tag && group_tag && dba_role_tag)
				{
					if(list_usersDBA && numUsersDBA > 0)
					{
						fprintf(logfileptr,"Setting current user session with role %s\n",DBA_ROLE);
						fprintf(logfileptr,"\n");
						ITK(SA_set_default_role(user_tag,group_tag,dba_role_tag))
						if(ifail== ITK_ok)
						{
							sessionFlag=TRUE;
						}else
						{
							EMH_ask_error_text(ifail, &message);
							fprintf(stderr,"\nERROR: %s\n",message);
						}
					}
				}

				if(sessionFlag == FALSE)
				{
					//set session to se
					if(user_tag && group_tag && se_role_tag)
					{
						if(list_usersSE && numUsersSE > 0)
						{
							fprintf(logfileptr,"Setting current user session with role %s\n",FV_SW_ENGG_ROLE);
							fprintf(logfileptr,"\n");
							ITK(SA_set_default_role(user_tag,group_tag,se_role_tag))
							if(ifail== ITK_ok)
							{
								sessionFlag=TRUE;
							}else
							{
								EMH_ask_error_text(ifail, &message);
								fprintf(stderr,"\nERROR: %s\n",message);
							}
						}
					}
				}
				if(sessionFlag == FALSE)
				{
					//set session to cc
					if(user_tag && group_tag && cc_role_tag)
					{
						if(list_usersSE && numUsersCC > 0)
						{
							fprintf(logfileptr,"Setting current user session with role %s\n",CONF_COORD_ROLE);
							fprintf(logfileptr,"\n");
							ITK(SA_set_default_role(user_tag,group_tag,cc_role_tag))
							if(ifail== ITK_ok)
							{
								sessionFlag=TRUE;
							}else
							{
								EMH_ask_error_text(ifail, &message);
								fprintf(stderr,"\nERROR: %s\n",message);
							}
						}
					}
				}

				if(sessionFlag == FALSE)
				{
					//set session to ms
					if(user_tag && group_tag && ms_role_tag)
					{
						if(list_usersMS && numUsersMS > 0)
						{
							fprintf(logfileptr,"Setting current user session with role %s\n",FV_Module_SVR_ROLE);
							fprintf(logfileptr,"\n");
							ITK(SA_set_default_role(user_tag,group_tag,ms_role_tag))
							if(ifail== ITK_ok)
							{
								sessionFlag=TRUE;
							}else
							{
								EMH_ask_error_text(ifail, &message);
								fprintf(stderr,"\nERROR: %s\n",message);
							}
						}
					}
				}//sessionFlag == FALSE
			}// list_usersSE || numUsersSE > 0 || list_usersMS || list_usersDBA || numUsersMS > 0 || numUsersDBA > 0
		}//else
	}//currentRoleName

	if(sessionFlag == FALSE)
	{
		printf("\n Invalid user role \n");
		fprintf(stderr,"\nERROR: Current User Role is %s .\n",currentRoleName);
		fprintf(stderr,"\nERROR: Invalid Role , Only users having role Software Engineer or Config Coordinator or Module Supervisor or DBA can perform this action.\n");
		exit(1);

	}else
	{
		printf("\nValid user %s \n",login_user);
	}

	FVE_FREE(list_usersSE)
	numUsersSE=0;
	FVE_FREE(list_usersMS)
	numUsersMS=0;
	FVE_FREE(list_usersDBA)
	numUsersDBA=0;
	FVE_FREE(list_usersCC)
	numUsersCC=0;

	//ifail=ITEM_find_rev(dicId, dicRevId, &dicRevTag);
	ITK(FVE_find_rev(dicId, dicRevId, &dicRevTag))
	if(dicRevTag == NULLTAG)
	{
		fprintf(stderr,"\nERROR: Item with %s%s%s does not exist\n",dicId,"/",dicRevId);
	}else
	{
	    // Check the object type
		ITK(WSOM_ask_object_type(dicRevTag, object_type))
		
		if(strcmp(object_type, FVE_ParmGrpDefRevisionTYPE) == 0)
		{
			//check if its of type Dictionary
		    ITK(ITEM_ask_item_of_rev(dicRevTag, &dicItemTag))
            ITK(AOM_get_value_string(dicItemTag, representsPROP, &representsValue))
            if (representsValue && (tc_strcmp(Parameter_DictionaryVALUE, representsValue) == 0))
		    {
				isDictionary=TRUE;
				//get the ecu acronym from dictionary
				ITK(AOM_ask_value_string(dicItemTag,FVE_ECUAcronymPROP,&ecuAcronym))
			}
		}
		else if (strcmp(object_type, FVE_ECCTProjectRevisionTYPE) == 0)
		{
			isECCTProjectRev=TRUE;
			//get the ecu acronym from dictionary
			ITK(AOM_ask_value_string(dicRevTag,FVE_ECUAcronymPROP,&ecuAcronym))			
		}
		else
		{
		    fprintf(stderr,"\nERROR: Given item id %s%s%s does not represent a dictionary nor ECCT project.\n",dicId,"/",dicRevId);
		    exit(1);		  
		}		
	}

    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog details will be written into %s\n\n",file_path);
	if( logfileptr )
    {
        fprintf(logfileptr,"Utility name: %s\n\n",argv[0]);
		exeName= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(argv[0]))+1)* sizeof(char));
		strcpy(exeName,FV_trim_blanks(argv[0]));
		time( &clock );
        fprintf(logfileptr,"Start time: %s\n", ctime(&clock));
    }

	fprintf(logfileptr,"Logged in successfully.\n");

	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"ECU Name: %s\n", ecuAcronym);
	fprintf(logfileptr,"\n");
	if(isDictionary)
	{
		fprintf(logfileptr,"Dictionary Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
	}
	if(isECCTProjectRev)
	{
		fprintf(logfileptr,"ECCT Project Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
	}
	fprintf(logfileptr,"\n");

	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PARAMETER_MODE) == 0 || tc_strcmp(mode,ALL_MODE) == 0) )
	{
		
		strParmInfo=(struct FVEParmDefInfostruct*)MEM_alloc((sizeof(struct FVEParmDefInfostruct))*MAX_STRCT);
		FVE_initialize_ParmStructure(strParmInfo);
		//parse parameter definition file
		if(csvConfigFileDelimeter && tc_strlen(csvConfigFileDelimeter)> 0)
		{
			printf("\nDelimiter %s is specified in the configuration file.\n",csvConfigFileDelimeter);
			printf("\nStart Processing Parameter Definition File...\n");			
			
			//Time Statistics
			get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"Start Time To Parse CSV file for Parameter Definitions:%s\n",time_stamp);
			FVE_FREE(time_stamp)
			fprintf(logfileptr,"\n");

			totalNoOfParameters=FVE_parse_parmDefFile(fileptr1,csvConfigFileDelimeter);


			
			get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"End Time To Parse CSV file for Parameter Definitions :%s\n",time_stamp);
			FVE_FREE(time_stamp)

			fprintf(logfileptr,"\n");
			
		}else
		{
			printf("\nDelimiter is not specified in the configuration file\n");
			printf("\nDefault delimiter %s will be considered.Please make sure csv file contains this delimeter.\n",CSV_DEFAULT_FILE_DELIM);
			
			//Time Statistics
			get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"Start Time To Parse CSV file for Parameter Definitions :%s\n",time_stamp);
			FVE_FREE(time_stamp)
			fprintf(logfileptr,"\n");
			
			totalNoOfParameters=FVE_parse_parmDefFile(fileptr1,CSV_DEFAULT_FILE_DELIM);
			
			get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"End Time To Parse CSV file for Parameter Definitions :%s\n",time_stamp);
			FVE_FREE(time_stamp)

			fprintf(logfileptr,"\n");
		}
		printf("\nTotal Parameters=%d\n",totalNoOfParameters);
	}

	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PROCESS_MODE) == 0 || tc_strcmp(mode,ALL_MODE) == 0) )
	{
		strProcessInfo=(struct FVEProcessInfostruct*)MEM_alloc((sizeof(struct FVEProcessInfostruct))*MAX_STRCT);
		FVE_initialize_ProcessStructure(strProcessInfo);
		if(ignoreProcessFile == FALSE)
		{
			printf("\nStart Processing Process Definition File...\n");
			
			//Time Statistics
			get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"Start Time To Parse CSV file for Process Objects :%s\n",time_stamp);
			FVE_FREE(time_stamp)
			fprintf(logfileptr,"\n");
			
			if(csvConfigFileDelimeter && tc_strlen(csvConfigFileDelimeter)> 0)
			{
				totalNoOfProcess=FVE_parse_processFile(fileptr2,csvConfigFileDelimeter,strProcessInfo);
			}else
			{
				totalNoOfProcess=FVE_parse_processFile(fileptr2,CSV_DEFAULT_FILE_DELIM,strProcessInfo);
			}
			
			get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"End Time To Parse CSV file for Process Objects :%s\n",time_stamp);
			FVE_FREE(time_stamp)

			fprintf(logfileptr,"\n");
			printf("\nTotal No Of Processes=%d\n",totalNoOfProcess);
		}
	}

	//structure contains list of parameter definitions.Now create the parameter based on its type
	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PARAMETER_MODE) == 0 || tc_strcmp(mode,ALL_MODE) == 0) )
	{
        if(isDictionary)
		{
			//Time Statistics
			//get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			//fprintf(logfileptr,"Start Time to build the Prime Dictionary Structure:%s\n",time_stamp);
			//FVE_FREE(time_stamp)
			//fprintf(logfileptr,"\n");
			
			ifail=FVE_createParameterDefinitions(strParmInfo,totalNoOfParameters);
			
			//get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			//fprintf(logfileptr,"End Time to build the Prime Dictionary Structure for all %d parameters :%s\n",(totalNoOfParameters),time_stamp);
			//FVE_FREE(time_stamp)
			//fprintf(logfileptr,"\n");
		}
		if(isECCTProjectRev)
		{
		    //BCM : Create Repository Structure and Prime Dictionary Structure
			//get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			//fprintf(logfileptr,"Start Time to build the Repository Structure and Prime Dictionary Structure for all %d parameters :%s\n",(totalNoOfParameters),time_stamp);
			//FVE_FREE(time_stamp)
			//fprintf(logfileptr,"\n");
			

            ifail=FV_build_project_structure(dicRevTag,strParmInfo,totalNoOfParameters);
			
			//get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			//fprintf(logfileptr,"End Time :Total time taken (Start to End) to build Repository Structure and Prime Dictionary Structure for all %d parameters :%s\n",(totalNoOfParameters),time_stamp);
			//FVE_FREE(time_stamp)
			//fprintf(logfileptr,"\n");

		}
	}

	/*if mode=process then write a function that will just create/update process objects in the system*/
	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PROCESS_MODE) == 0))
	{
		if(isDictionary)
		{
		    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"Start Time to Create/Update %d Process Objects Only :%s\n",(totalNoOfProcess),time_stamp);
			FVE_FREE(time_stamp)
			fprintf(logfileptr,"\n");
			
			ifail=FVE_getProcessModeOnly(strProcessInfo,totalNoOfProcess);
			
			get_time_stamp(DATE_FORMAT_STR, &time_stamp);
			fprintf(logfileptr,"End Time :Total time taken (Start to End) to Create/Update %d Process Objects Only :%s\n",(totalNoOfProcess),time_stamp);
			FVE_FREE(time_stamp)
			fprintf(logfileptr,"\n");
			
		}
	}

    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    time( &clock );
    fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );

	if(logFilePtrFailure)
	{
		fprintf(logFilePtrFailure,"\nEnd time: %s", ctime( &clock ) );
	}

	if (logfileptr ) fclose( logfileptr);
	if(fileptr1) fclose(fileptr1);
	if(fileptr2) fclose(fileptr2);
	if(logFilePtrFailure) fclose(logFilePtrFailure);

    // Nikhil Patil - changes starts
    /*
    *  Close config file.
    */

    // Close config file.
    if( configFilePtr )
    {
        fclose(configFilePtr);
    }

    configFileInput =   NULL;


    // Nikhil Patil - changes ends

	if(isDictionary && windowDic)
		ITK(BOM_close_window(windowDic))
	
	if(isECCTProjectRev && windowPrimeDic)
		ITK(BOM_close_window(windowPrimeDic))

	if(user_tag && group_tag && current_role_tag)
		ITK(SA_set_default_role(user_tag,group_tag,current_role_tag))

	//free memory for structure variables
	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PARAMETER_MODE) == 0 || tc_strcmp(mode,ALL_MODE) == 0) )
	{
		FVE_MemFreeStructParameter(strParmInfo);
	}
	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PROCESS_MODE) == 0 || tc_strcmp(mode,ALL_MODE) == 0) )
	{
		FVE_MemFreeStructProcess(strProcessInfo);
	}

	FVE_MemFreeStructConfigFile(strConfigInfo);
	FVE_FREE(toleranceExistInConfigFile)
	FVE_FREE(exeName)
	FVE_FREE(revisedObjs)
	revisedObjsCnt=0;

	ITK_exit_module( true );

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


int power(int x, unsigned int y)
{
	if( y == 0)
		return 1;
	else if (y%2 == 0)
		return power(x, y/2)*power(x, y/2);
	else
		return x*power(x, y/2)*power(x, y/2);
}
/*
Function to parse the configuration file
*/
int fve_parse_configFile(FILE *configFlPtr,char *delim,struct FVEConfigFileInfostruct *configInfo)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_parse_configFile";
	int			totalCnt			=	0;
	char        *ptr				=	0;
	char*		line_temp			=	NULL;
	char		*copyStr			=	NULL;
	char        line_in[MAX_STRCT]	=	"";
	int			line_count			=	0;

	char *constName =NULL;
	char *constValue =NULL;


	TC_write_syslog("\n Enter function %s",function_name);
	if ( configFlPtr != 0)
	{

		line_count = 0;
		while (fgets(line_in, MAX_STRCT, configFlPtr) != 0)
		{

			int     len							=	0;
			logical lgIncrCount					=	FALSE;
			logical is_constName_null			=	FALSE;
			logical is_constValue_null			=	FALSE;

			if(line_in && tc_strlen(line_in)> 0)
			{
				copyStr=FV_trim_blanks(line_in);
				len = tc_strlen(copyStr);
				if(len > 0)
				{
					ITK(fv_strdup(copyStr, &line_temp))
				}
			}

			if ( len == 0 )
					continue;
			line_count++;

			if (len > 0 && copyStr[len-1] == '\n')
					copyStr[len-1] = '\0';


			if(delim != NULL && tc_strlen(delim)> 0)
			{
				//get constant name i.e. Log File Name
				ptr = tc_strtok(copyStr,delim);
				fve_get_value(ptr, &constName, &is_constName_null);
				if(is_constName_null == FALSE)
				{
					configInfo[totalCnt].constantName= (char*) MEM_alloc((int) (strlen(constName)+1)* sizeof(char));
					strcpy(configInfo[totalCnt].constantName,FV_trim_blanks(constName));
				}
				//get the constant value
				ptr = tc_strtok(NULL,delim);
				fve_get_value(ptr, &constValue, &is_constValue_null);
				if(is_constValue_null == FALSE)
				{
					if( (configInfo[totalCnt].constantName != NULL) && (tc_strlen(configInfo[totalCnt].constantName)> 0))
					{
						if( tc_strcmp(configInfo[totalCnt].constantName,LOG_FILE_NAME)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].lofFileName= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].lofFileName,FV_trim_blanks(constValue));
						}
						else if( tc_strcmp(configInfo[totalCnt].constantName,LOG_FILE_PATH)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].logFilePath= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].logFilePath,FV_trim_blanks(constValue));

						}else if( tc_strcmp(configInfo[totalCnt].constantName,LOG_FILE_EXTENSION)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].logFileExt= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].logFileExt,FV_trim_blanks(constValue));
						}else if( tc_strcmp(configInfo[totalCnt].constantName,CCM_CSV_FILE_DELIMITER)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].csvFileDelim= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							csvConfigFileDelimeter=(char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].csvFileDelim,FV_trim_blanks(constValue));
							strcpy(csvConfigFileDelimeter,FV_trim_blanks(constValue));
						}else if( tc_strcmp(configInfo[totalCnt].constantName,CCM_TOLERANCE_VALUE)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].tolerance= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							toleranceExistInConfigFile=(char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].tolerance,FV_trim_blanks(constValue));
							strcpy(toleranceExistInConfigFile,FV_trim_blanks(constValue));
						}
					}
				}
				FVE_FREE(line_temp)
				copyStr=NULL;
				if(lgIncrCount == TRUE)
						totalCnt++;
			}// delim != null
			//free memory
			FVE_FREE(constName)
			FVE_FREE(constValue)
		}//while
	}//if


	TC_write_syslog("\n Leave function %s",function_name);
	return totalCnt;
}
int FVE_parse_processFile(FILE *flPtrProcess,char *delim,struct FVEProcessInfostruct *processInfo)
{

		int         ifail					=	ITK_ok;
		char*       function_name			=	"FVE_parse_processFile";
		char*		line_temp				=	NULL;
		char        line_in[MAX_STRCT]			=	"";
		int			line_count				=	0;
		char		*copyStr				=	NULL;
		char		*prName					=	NULL;
		char		*prType					=	NULL;
		char		*featName				=	NULL;
		char		*taskRate				=	NULL;
		char		*prTypeLoc				=	NULL;
		char		*featNameLoc			=	NULL;
		char		*taskRateLoc			=	NULL;
		char		*remPartAfterPrName		=	NULL;
		char		*remPartAfterPrType		=	NULL;
		char		*remPartAfterFeatureName=	NULL;
		char		*remPartAfterTaskRate	=	NULL;

		int			totalCnt			=	0;

		TC_write_syslog("\n Enter function %s",function_name);

		if (flPtrProcess != 0)
		{
			fprintf(logfileptr,"Start Processing Parameter Process Definition File...\n");
			fprintf(logfileptr,"\n");
			line_count = 0;
			while (fgets(line_in, MAX_STRCT, flPtrProcess) != 0)
			{
				int     len						=	0;
				logical lgIncrCount				=	FALSE;

				if(line_in && tc_strlen(line_in) > 0)
				{
					copyStr=FV_trim_blanks(line_in);
					len = tc_strlen(copyStr);
					if(len > 0)
					{
						ITK(fv_strdup(copyStr, &line_temp))
					}
				}
				if (len == 0)
					continue;

				line_count++;

				if (len > 0 && line_temp[len-1] == '\n')
				{
					line_temp[len-1] = '\0';
				}


				if(delim != NULL && tc_strlen(delim)> 0)
				{
					char *prNameLoc =strstr(copyStr, delim);
					if(prNameLoc != NULL)
					{
						ifail=fve_get_val_line(delim,copyStr,prNameLoc,&prName,&remPartAfterPrName);
						if(prName && tc_strlen(prName) > 0)
						{
							lgIncrCount=TRUE;
							processInfo[totalCnt].processName= (char*) MEM_alloc((int) (strlen(prName)+1)* sizeof(char));
							strcpy(processInfo[totalCnt].processName,FV_trim_blanks(prName));
						}
					}
					//else
					//{
						//fprintf(logfileptr,"\n Could not find delimiter %s\n",delim);
					//}

					//process type
					if(remPartAfterPrName && tc_strlen(remPartAfterPrName)> 0)
					{
						prTypeLoc=strstr(FV_trim_blanks(remPartAfterPrName),delim);
						if(prTypeLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterPrName),FV_trim_blanks(prTypeLoc),&prType,&remPartAfterPrType);
							if(prType && tc_strlen(prType)> 0)
							{
								processInfo[totalCnt].processType= (char*) MEM_alloc((int) (strlen(prType)+1)* sizeof(char));
								strcpy(processInfo[totalCnt].processType,FV_trim_blanks(prType));
							}
						}
					}

					//feature name
					if(remPartAfterPrType && tc_strlen(remPartAfterPrType)> 0)
					{
						featNameLoc=strstr(FV_trim_blanks(remPartAfterPrType),delim);
						if(featNameLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterPrType),FV_trim_blanks(featNameLoc),&featName,&remPartAfterFeatureName);
							if(featName && tc_strlen(featName)> 0)
							{
								processInfo[totalCnt].featureName= (char*) MEM_alloc((int) (strlen(featName)+1)* sizeof(char));
								strcpy(processInfo[totalCnt].featureName,FV_trim_blanks(featName));
							}
						}
					}

					//task rate
					if(remPartAfterFeatureName && tc_strlen(remPartAfterFeatureName)> 0)
					{
						taskRateLoc=strstr(FV_trim_blanks(remPartAfterFeatureName),delim);
						if(taskRateLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterFeatureName),FV_trim_blanks(taskRateLoc),&taskRate,&remPartAfterTaskRate);
							if(taskRate && tc_strlen(taskRateLoc)> 0)
							{
								processInfo[totalCnt].taskRate= (char*) MEM_alloc((int) (strlen(taskRate)+1)* sizeof(char));
								strcpy(processInfo[totalCnt].taskRate,FV_trim_blanks(taskRate));
							}
						}else
						{
							processInfo[totalCnt].taskRate= (char*) MEM_alloc((int) (strlen(remPartAfterFeatureName)+1)* sizeof(char));
							strcpy(processInfo[totalCnt].taskRate,FV_trim_blanks(remPartAfterFeatureName));
						}
					}
					if(lgIncrCount == TRUE)
						totalCnt++;
					FVE_FREE(line_temp)
					copyStr=NULL;
				}//if delim != null
				//free memory
				FVE_FREE(prName)
				FVE_FREE(prType)
				FVE_FREE(featName)
				FVE_FREE(taskRate)

				FVE_FREE(remPartAfterPrName);
				FVE_FREE(remPartAfterPrType);
				FVE_FREE(remPartAfterFeatureName);
				FVE_FREE(remPartAfterTaskRate);
			}//while
		}//flPtrProcess != 0
		TC_write_syslog("\n Leave function %s",function_name);
	    return totalCnt;
}

/*
function to parse the line with given delimeper
I/p - delimeter
      line
	  locName = line pointer where the first occurance of delimeter exist.
	  e.g.
	  delimeter=||
	  line_temp=AirflowCalc||Calculated airflow output.Added Desc||Numeric||HW Output||
	  locName=||Calculated airflow output.Added Desc||Numeric||HW Output

0/p -Return first part before delimeter
     Return second Part after delimeter
*/
int fve_get_val_line(char *delim,char *line_temp,char *locName,char **firstStr,char **secondStr)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"fve_get_val_line";
	int			delimLength			=	0;
	int			reqLength1			=	0;
	int			reqLength2			=	0;
	char		*firstPart			=	NULL;
	char		*secondPart			=	NULL;
	int			lenStrPointer		=	0;

	TC_write_syslog("\n Enter function %s",function_name);

	if(locName != NULL)
	{
		delimLength = strlen(delim);
		reqLength1=(tc_strlen(line_temp))-(tc_strlen(locName));
		reqLength2=strlen(locName)+delimLength;

		//get the length for locName
		lenStrPointer=tc_strlen(locName);
		firstPart = (char*)MEM_alloc((int) (reqLength1+1)* sizeof(char));

		strncpy(firstPart, FV_trim_blanks(line_temp),reqLength1);
		firstPart[reqLength1]='\0';
		secondPart = (char*)MEM_alloc((int) (reqLength2+1)* sizeof(char));
		sprintf(secondPart,"%.*s",strlen(locName)-delimLength,&locName[delimLength]);

		if(firstPart && tc_strlen(firstPart)> 0)
		{
			*firstStr=firstPart;
			firstPart=NULL;
		}

		if(secondPart && tc_strlen(secondPart)> 0)
		{
			*secondStr=secondPart;
			secondPart=NULL;

		}
	}
	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}
//int FVE_parse_parmDefFile(FILE  *flPtrParmDef,char *delim,struct FVEParmDefInfostruct *parameterInfo)
int FVE_parse_parmDefFile(FILE  *flPtrParmDef,char *delim)
{
		int         ifail				=	ITK_ok;
		char*       function_name		=	"FVE_parse_parmDefFile";
		char*		line_temp			=	NULL;
		char        line_in[MAX_STRCT]	=	"";
		int			line_count			=	0;

		char        *parmName			=	NULL;		//Name of parameter
		char	    *parmDescr			=	NULL;		//description

		/*Numeric is Integer or Double Parameter. They are saying if the Resolution field has an integer value, we create integer parameter and
		if it has a value with decimals, then create double parameter.
		Secondly, if it says “discrete”, then we have to create an SED parameter.*/
		char		*parmType			=	NULL;

		char		*parmCategory		=	NULL;		//Parameter Type
		char		*parmStorageClass   =	NULL;		//Parameter Usage
		char        *parmInitValue		=	NULL;		//Initial Value
		char        *parmStruOfData		=	NULL;		//Scalar means 1 row and 1 column.
		char		*parmUnit			=	NULL;		//Engineering Unit
		char		*msaUnit			=	NULL;       //MSA Unit
		char		*parmSize			=	NULL;
		char		*groupInfo			=	NULL;
		
		/* -> Resolution has a logic. If the resolution is 0.0625, then in our case the resolution numerator will be 1 and denominator will be 16 (Essentially 1/16 = 0.0625).
		If the resolution is 1, then numerator and denominator is 1. This is just an example.*/
		char        *parmResolution		=	NULL;
		char		*parmTolerance		=	NULL;
		char		*parmRowCnt			=	NULL;
		char		*parmColCnt			=	NULL;
		char		*parmRowLabel		=	NULL;
		char		*parmColLabel		=	NULL;
		char		*parmMin			=	NULL;
		char		*parmMax			=	NULL;

		/*This is a new attribute resides on Model Specific Attributes form. (This can be ignored for parameter creation)*/
		char		*parmOverWritable	=	NULL;
		char		*implDataType		=	NULL;
		char		*implResolution		=	NULL;
		char		*offsetStr				=	NULL;

		/* New attribute added on all Parameter Revisions.*/
		char		*parmFault			=	NULL;

		/*New attribute added on all parameter revision objects.*/
		char		*parmRestricted		=	NULL;

		char		*domainElName		=	NULL;
		char		*domainElValue		=	NULL;
		char		*domainElDescr		=	NULL;
		char		*source				=	NULL;
		char		*snk				=	NULL;
		char		*srcSnk				=	NULL;
		char		*local				=	NULL;
		char		*configGrp			=	NULL;
		char		*inhale_Exhale		=	NULL;
		char		*asBuilt_VehOp		=	NULL;
		char		*moduleManf			=	NULL;
		char		*fcsdCustPref		=	NULL;
		int			totalCnt			=	0;

		char		*objectTypeTc		=	NULL;
		char		*numerator			=	NULL;
		char		*denominator		=	NULL;
		char		*precisionVal		=	NULL;

		//char       cntPrecision[FV_INTEGER_LEN+1] = {'\0'};
		char *copyStr	=	NULL;

		char	*descrLoc				=	NULL;
				char	*parmTypeLoc			=	NULL;
				char	*parmCategoryLoc		=	NULL;
				char	*parmStorageClLoc		=	NULL;
				char    *parmInitValueLoc		=	NULL;
				char    *parmStruOfDataLoc		=	NULL;
				char	*parmUnitLoc			=	NULL;
				char    *parmResolutionLoc		=	NULL;
				char    *parmToleranceLoc		=	NULL;
				char	*parmMinLoc				=	NULL;
				char	*parmMaxLoc				=	NULL;
				char	*parmOverWritableLoc	=	NULL;
				char	*implDataTypeLoc		=	NULL;
				char	*implResolutionLoc		=	NULL;
				char	*offsetLoc				=	NULL;
				char	*parmFaultLoc			=	NULL;
				char	*parmRestrictedLoc		=	NULL;
				char	*domainElValueLoc		=	NULL;
				char	*domainElNameLoc		=	NULL;
				char	*domainElDescrLoc		=	NULL;
				char	*sourceLoc				=	NULL;
				char	*snkLoc					=	NULL;
				char	*localLoc				=	NULL;
				char	*srcSnkLoc				=	NULL;
				char	*configGrpLoc			=	NULL;
				char	*inhale_ExhaleLoc		=	NULL;
				char	*asBuilt_VehOpLoc		=	NULL;
				char	*moduleManfLoc			=	NULL;
				char	*fcsdCustPrefLoc		=	NULL;
				char	*rowLabelLoc			=	NULL;
				char	*colLabelLoc			=	NULL;
				char	*rowCntLoc				=	NULL;
				char	*colCntLoc				=	NULL;
				char	*msaUnitLoc				=	NULL;
				char	*sizeLoc				=	NULL;

				char	*remPartAfterName			=	NULL;
				char	*remPartAfterParmType		=	NULL;
				char	*remPartAfterDescr			=	NULL;
				char	*remPartAfterParmCategory	=	NULL;
				char	*remPartAfterParmStorageCl	=	NULL;
				char	*remPartAfterParmInitValue	=	NULL;
				char	*remPartAfterparmStruOfData	=	NULL;
				char	*remPartAfterParmUnit		=	NULL;
				char	*remPartAfterMSAUnit		=	NULL;
				char	*remPartAfterSize			=	NULL;
				char	*remPartAfterParmResolution	=	NULL;
				char	*remPartAfterParmTolerance	=	NULL;
				char	*remPartAfterParmMin		=	NULL;
				char	*remPartAfterParmMax		=	NULL;
				char	*remParmOverWritable		=	NULL;
				char	*remPartAfterParmFault		=	NULL;
				char	*remPartAfterParmRestricted	=	NULL;
				char	*remPartAfterImplDataType	=	NULL;
				char	*remPartAfterdomainElName	=	NULL;
				char	*remPartAfterdomainElValue	=	NULL;
				char	*remPartAfterdomainElDescr	=	NULL;
				char	*remPartAfterSource			=	NULL;
				char	*remPartAfterSnk			=	NULL;
				char	*remPartAfterLocal			=	NULL;
				char	*remPartAfterSrcSnk			=	NULL;
				char	*remPartAfterImplResolution	=	NULL;
				char	*remPartAfterOffset			=	NULL;
				char	*remPartAfterconfigGrp		=	NULL;
				char	*remPartAfterInhale_Exhale	=	NULL;
				char	*remPartAfterAsBuilt_VehOp	=	NULL;
				char	*remPartAfterFcsdCustPref	=	NULL;
				char	*remPartAfterModuleManf		=	NULL;
				char	*remPartAfterRowCnt			=	NULL;
				char	*remPartAfterColCnt			=	NULL;
				char	*remPartAfterRowLabel		=	NULL;
				char	*remPartAfterColLabel		=	NULL;
				char	*remPartAfterGroup			=	NULL;
				char	*groupLoc					=	NULL;
				logical		hexFlag					=	FALSE;
                char	*tempStrLong                =   NULL;

                char    *findParmType                   =   NULL;

		TC_write_syslog("\n Enter function %s",function_name);
		if(flPtrParmDef != 0)
		{
			fprintf(logfileptr,"Start Processing Parameter Definition File...\n");
			fprintf(logfileptr,"\n");
			line_count = 0;

			while (fgets(line_in, MAX_STRCT, flPtrParmDef) != 0)
			{
				int		lengthAfterDot			=	0;
				int		lengthBeforeDot			=	0;
				int     len						=	0;
				logical lgIncrCount				=	FALSE;
						hexFlag					=	FALSE;

                if(line_in && tc_strlen(line_in) > 0)
                {
                    ITK(fv_strdup(line_in, &copyStr))
					len = (int)tc_strlen(copyStr);
                }
                
                if(copyStr != NULL && len > 0 && copyStr[len-1] != '\n' && !feof(flPtrParmDef))
                {
                    if(tempStrLong == NULL)
                        ITK(fv_strdup(copyStr, &tempStrLong))
                    continue;
                }
                if(tempStrLong != NULL && tc_strlen(tempStrLong) > 0)
                {
                    ITK(FV_strcat(&tempStrLong, copyStr))
                    copyStr=FV_trim_blanks(tempStrLong);
					len = (int)tc_strlen(copyStr);
					if(len > 0)
					{
						ITK(fv_strdup(copyStr, &line_temp))
					}
                }
				else if(len > 0)
				{
					ITK(fv_strdup(copyStr, &line_temp))
				}
				else if (len == 0)
					continue;

				line_count++;
				if (len > 0 && copyStr[len-1] == '\n')
				{
					copyStr[len-1] = '\0';
				}
				if(delim != NULL && tc_strlen(delim)> 0)
				{
					char *locName =strstr(copyStr, delim);
					//name
					if(locName != NULL)
					{
						ifail=fve_get_val_line(delim,FV_trim_blanks(copyStr),FV_trim_blanks(locName),&parmName,&remPartAfterName);
						if(parmName && tc_strlen(parmName) > 0)
						{
							//lgIncrCount=TRUE;
							strParmInfo[totalCnt].name= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmName))+1)* sizeof(char));
							strcpy(strParmInfo[totalCnt].name,FV_trim_invalidChars(FV_trim_blanks(parmName)));
						}
					}
					//else
					//{
						//fprintf(logfileptr,"\n Could not find delimiter %s\n",delim);
					//}

					//description
					if(remPartAfterName && tc_strlen(remPartAfterName)> 0)
					{
						descrLoc =strstr(FV_trim_blanks(remPartAfterName),delim);
						if(descrLoc != NULL)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterName),FV_trim_blanks(descrLoc),&parmDescr,&remPartAfterDescr);
							if(parmDescr && tc_strlen(parmDescr)> 0)
							{
								strParmInfo[totalCnt].descr= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmDescr))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].descr,FV_trim_blanks(parmDescr));
							}
						}
					}

					//Parameter Type
					if(remPartAfterDescr && tc_strlen(remPartAfterDescr)> 0)
					{
						parmTypeLoc =strstr(FV_trim_blanks(remPartAfterDescr),delim);
						if(parmTypeLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterDescr),FV_trim_blanks(parmTypeLoc),&parmType,&remPartAfterParmType);
							if(parmType != NULL && tc_strlen(parmType) > 0)
							{
								lgIncrCount=TRUE;
								strParmInfo[totalCnt].typeOfData= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmType))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].typeOfData,parmType);
								if( tc_strcmp(FV_trim_blanks(parmType),PARM_TYPE_CHARACTER)==0)
								{
									objectTypeTc = (char *) MEM_alloc((int)(strlen(FVE_ParmDefStrTYPE) + 1) * sizeof(char));
									tc_strcpy(objectTypeTc,FVE_ParmDefStrTYPE);
									
									if(objectTypeTc && tc_strlen(objectTypeTc) > 0)
									{
										strParmInfo[totalCnt].type= (char*) MEM_alloc((int) (strlen(objectTypeTc)+1)* sizeof(char));
										strcpy(strParmInfo[totalCnt].type,objectTypeTc);
									}
								}
							}
						}
					}

					//Parameter Category
					if(remPartAfterParmType && tc_strlen(remPartAfterParmType)> 0)
					{
						parmCategoryLoc=strstr(FV_trim_blanks(remPartAfterParmType),delim);
						if(parmCategoryLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmType),FV_trim_blanks(parmCategoryLoc),&parmCategory,&remPartAfterParmCategory);
							if(parmCategory && tc_strlen(parmCategory)> 0)
							{
								strParmInfo[totalCnt].paraType= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmCategory))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].paraType,FV_trim_blanks(parmCategory));
							}
						}
					}

					//Storage Class
					if(remPartAfterParmCategory && tc_strlen(remPartAfterParmCategory)> 0)
					{
						parmStorageClLoc=strstr(FV_trim_blanks(remPartAfterParmCategory),delim);
						if(parmStorageClLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmCategory),FV_trim_blanks(parmStorageClLoc),&parmStorageClass,&remPartAfterParmStorageCl);
							if(parmStorageClass != NULL && tc_strlen(FV_trim_blanks(parmStorageClass)) > 0)
							{
								strParmInfo[totalCnt].paraUsage= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmStorageClass))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].paraUsage,FV_trim_blanks(parmStorageClass));
							}
						}
					}

					//Initial Value
					if(remPartAfterParmStorageCl && tc_strlen(remPartAfterParmStorageCl)> 0)
					{
						parmInitValueLoc=strstr(FV_trim_blanks(remPartAfterParmStorageCl),delim);
						if(parmInitValueLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmStorageCl),FV_trim_blanks(parmInitValueLoc),&parmInitValue,&remPartAfterParmInitValue);
							if(parmInitValue != NULL && tc_strlen(parmInitValue) > 0)
							{
								strParmInfo[totalCnt].initVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmInitValue))+2)* sizeof(char));
								strcpy(strParmInfo[totalCnt].initVal,FV_trim_blanks(parmInitValue));
							}
						}
					}

					//Structure of Data
					if(remPartAfterParmInitValue && tc_strlen(remPartAfterParmInitValue) > 0)
					{
						parmStruOfDataLoc=strstr(FV_trim_blanks(remPartAfterParmInitValue),delim);
						if(parmStruOfDataLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmInitValue),FV_trim_blanks(parmStruOfDataLoc),&parmStruOfData,&remPartAfterparmStruOfData);
							if(parmStruOfData != NULL && tc_strlen(parmStruOfData) > 0 )
							{
								strParmInfo[totalCnt].structureOfData=(char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmStruOfData))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].structureOfData,FV_trim_blanks(parmStruOfData));
								if( tc_strcmp( FV_trim_blanks(parmStruOfData),ScalarInfo) == 0)
								{
									strParmInfo[totalCnt].rowCnt=1;
									strParmInfo[totalCnt].colCnt=1;
								}

								if(parmType && tc_strlen(parmType)> 0 && tc_strcmp(FV_trim_blanks(parmType),PARM_TYPE_DISCRETE) == 0)
								{
									if(parmStruOfData && tc_strlen(parmStruOfData)> 0 && ( tc_strcmp(FV_trim_blanks(parmStruOfData),ScalarInfo)==0))
									{
										objectTypeTc = (char *) MEM_alloc((int)(strlen(FVE_ParmDefSEDTYPE) + 1) * sizeof(char));
										tc_strcpy(objectTypeTc,FVE_ParmDefSEDTYPE);
									
										if(objectTypeTc && tc_strlen(objectTypeTc) > 0)
										{
											strParmInfo[totalCnt].type= (char*) MEM_alloc((int) (strlen(objectTypeTc)+1)* sizeof(char));
											strcpy(strParmInfo[totalCnt].type,objectTypeTc);
										}
									}//
									if(parmStruOfData && tc_strlen(parmStruOfData)> 0 && ( (tc_strcmp(FV_trim_blanks(parmStruOfData),Array1DInfo)==0) ||
										                                                     (tc_strcmp(FV_trim_blanks(parmStruOfData),Array2DInfo)==0)  ||
																							 (tc_strcmp(FV_trim_blanks(parmStruOfData),Lookup1DInfo)==0) ||
																							 (tc_strcmp(FV_trim_blanks(parmStruOfData),Lookup2DInfo)==0)))
									{
										objectTypeTc = (char *) MEM_alloc((int)(strlen(FVE_ParmDefStrTYPE) + 1) * sizeof(char));
										tc_strcpy(objectTypeTc,FVE_ParmDefStrTYPE);
									
										if(objectTypeTc && tc_strlen(objectTypeTc) > 0)
										{
											strParmInfo[totalCnt].type= (char*) MEM_alloc((int) (strlen(objectTypeTc)+1)* sizeof(char));
											strcpy(strParmInfo[totalCnt].type,objectTypeTc);
										}
									}//
								}//parmType

							}//parmStruOfData
						}//parmStruOfDataLoc
					}//remPartAfterParmInitValue

					//Engineering Unit
					if(remPartAfterparmStruOfData && tc_strlen(remPartAfterparmStruOfData) > 0)
					{
						parmUnitLoc=strstr(FV_trim_blanks(remPartAfterparmStruOfData),delim);
						if(parmUnitLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterparmStruOfData),FV_trim_blanks(parmUnitLoc),&parmUnit,&remPartAfterParmUnit);
							if(parmUnit != NULL && tc_strlen(parmUnit) > 0)
							{
								strParmInfo[totalCnt].engUnit= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmUnit))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].engUnit,FV_trim_blanks(parmUnit));
							}
						}
					}

					//Resolution
					if(remPartAfterParmUnit && tc_strlen(remPartAfterParmUnit) > 0)
					{
						parmResolutionLoc=strstr(FV_trim_blanks(remPartAfterParmUnit),delim);
						if(parmResolutionLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmUnit),FV_trim_blanks(parmResolutionLoc),&parmResolution,&remPartAfterParmResolution);
							if(parmResolution != NULL && tc_strlen(parmResolution) > 0)
							{
								if(parmType != NULL && tc_strcmp(FV_trim_blanks(parmType),PARM_TYPE_NUMERIC)== 0 )
								{
									ifail=FVE_get_precision(FV_trim_blanks(parmResolution),&lengthBeforeDot,&lengthAfterDot);
									if(lengthAfterDot == 0)
									{
										//Its integer type
										objectTypeTc = (char *) MEM_alloc((int)(strlen(FVE_ParmDefIntTYPE) + 1) * sizeof(char));
										tc_strcpy(objectTypeTc,FVE_ParmDefIntTYPE);
										strParmInfo[totalCnt].type= (char*) MEM_alloc((int) (strlen(objectTypeTc)+1)* sizeof(char));
										strcpy(strParmInfo[totalCnt].type,objectTypeTc);
									}else
									{
										//Its dbl type
										objectTypeTc = (char *) MEM_alloc((int)(strlen(FVE_ParmDefDblTYPE) + 1) * sizeof(char));
										tc_strcpy(objectTypeTc,FVE_ParmDefDblTYPE);
										strParmInfo[totalCnt].type= (char*) MEM_alloc((int) (strlen(objectTypeTc)+1)* sizeof(char));
										strcpy(strParmInfo[totalCnt].type,objectTypeTc);

										precisionVal = (char*)MEM_alloc((int)(lengthAfterDot + 1) * sizeof(char));
										sprintf(precisionVal, "%d",lengthAfterDot );
										strParmInfo[totalCnt].precision = (char *) MEM_alloc((int)(strlen(precisionVal) + 1) * sizeof(char));
										strcpy(strParmInfo[totalCnt].precision,precisionVal);
									}

									//numerator
									numerator =(char *) MEM_alloc((int)(strlen(FV_trim_blanks(parmResolution)) + 1) * sizeof(char));
									tc_strcpy(numerator,FV_trim_blanks(parmResolution));
									strParmInfo[totalCnt].numerator= (char*) MEM_alloc((int) (strlen(numerator)+1)* sizeof(char));
									strcpy(strParmInfo[totalCnt].numerator,numerator);

									//denominator
									denominator =(char *) MEM_alloc((int)(strlen(FVE_Int_Denominator_Value) + 1) * sizeof(char));
									tc_strcpy(denominator,FVE_Int_Denominator_Value);
									strParmInfo[totalCnt].denominator= (char*) MEM_alloc((int) (strlen(denominator)+1)* sizeof(char));
									strcpy(strParmInfo[totalCnt].denominator,denominator);
								}//parmType != NULL
							}//parmResolution != NULL
						}//parmResolutionLoc != NULL
					}//remPartAfterParmUnit

					//tolerance
					if(remPartAfterParmResolution && tc_strlen(remPartAfterParmResolution)> 0)
					{
						parmToleranceLoc=strstr(FV_trim_blanks(remPartAfterParmResolution),delim);
						if(parmToleranceLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmResolution),FV_trim_blanks(parmToleranceLoc),&parmTolerance,&remPartAfterParmTolerance);
							if(parmTolerance && tc_strlen(parmTolerance)> 0)
							{
								strParmInfo[totalCnt].tolerance= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmTolerance))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].tolerance,FV_trim_blanks(parmTolerance));
							}
						}
					}

					//number of Rows
					if(remPartAfterParmTolerance && tc_strlen(remPartAfterParmTolerance)> 0)
					{
						rowCntLoc=strstr(FV_trim_blanks(remPartAfterParmTolerance),delim);
						if(rowCntLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmTolerance),FV_trim_blanks(rowCntLoc),&parmRowCnt,&remPartAfterRowCnt);
							
							if(strParmInfo[totalCnt].type && tc_strlen(strParmInfo[totalCnt].type)> 0 && tc_strcmp(strParmInfo[totalCnt].type,FVE_ParmDefStrTYPE)==0)
							{
								//if typeOfdata is character and structureOfdata is 1DArray , row=1 and column=1
								if( tc_strcmp(FV_trim_blanks(parmType),PARM_TYPE_CHARACTER)==0)
								{
									if(strParmInfo[totalCnt].structureOfData && tc_strlen(strParmInfo[totalCnt].structureOfData)> 0 && tc_strcmp(strParmInfo[totalCnt].structureOfData,Array1DInfo)==0)
									{
										strParmInfo[totalCnt].rowCnt=1;
									}
								}//character
								//if Discrete and structureOfdata is  1DArray 2DArray 1DLookup 2DLookup , get row /column information from csv file
								if( tc_strcmp(FV_trim_blanks(parmType),PARM_TYPE_DISCRETE)==0)
								{
									if(strParmInfo[totalCnt].structureOfData && tc_strlen(strParmInfo[totalCnt].structureOfData)> 0 &&  ( tc_strcmp(strParmInfo[totalCnt].structureOfData,Array1DInfo)==0) ||
										                                                                                                (tc_strcmp(strParmInfo[totalCnt].structureOfData,Array2DInfo)==0) ||
																																		(tc_strcmp(strParmInfo[totalCnt].structureOfData,Lookup1DInfo)==0) ||
																																		(tc_strcmp(strParmInfo[totalCnt].structureOfData,Array2DInfo)==0))
									{
										if(parmRowCnt && tc_strlen(parmRowCnt) > 0)
										{
											strParmInfo[totalCnt].rowCnt=atoi(FV_trim_blanks(parmRowCnt));
										}
									}
								}//discrete
							}//strtype
							else
							{
								if(parmRowCnt && tc_strlen(parmRowCnt) > 0)
								{
									strParmInfo[totalCnt].rowCnt=atoi(FV_trim_blanks(parmRowCnt));
								}
							}
						}//rowCntLoc
					}//remPartAfterParmTolerance

					//number of columns
					if(remPartAfterRowCnt && tc_strlen(remPartAfterRowCnt) > 0)
					{
						colCntLoc=strstr(FV_trim_blanks(remPartAfterRowCnt),delim);
						if(colCntLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterRowCnt),FV_trim_blanks(colCntLoc),&parmColCnt,&remPartAfterColCnt);
							
							if(strParmInfo[totalCnt].type && tc_strlen(strParmInfo[totalCnt].type)> 0 && tc_strcmp(strParmInfo[totalCnt].type,FVE_ParmDefStrTYPE)==0)
							{
								//if typeOfdata is character and structureOfdata is 1DArray , row=1 and column=1
								if( tc_strcmp(FV_trim_blanks(parmType),PARM_TYPE_CHARACTER)==0)
								{
									if(strParmInfo[totalCnt].structureOfData && tc_strlen(strParmInfo[totalCnt].structureOfData)> 0 && tc_strcmp(strParmInfo[totalCnt].structureOfData,Array1DInfo)==0)
									{
										strParmInfo[totalCnt].colCnt=1;
									}
								}//character
								//if Discrete and structureOfdata is  1DArray 2DArray 1DLookup 2DLookup , get row /column information from csv file
								if( tc_strcmp(FV_trim_blanks(parmType),PARM_TYPE_DISCRETE)==0)
								{
									if(strParmInfo[totalCnt].structureOfData && tc_strlen(strParmInfo[totalCnt].structureOfData)> 0 &&  ( tc_strcmp(strParmInfo[totalCnt].structureOfData,Array1DInfo)==0) ||
										                                                                                                (tc_strcmp(strParmInfo[totalCnt].structureOfData,Array2DInfo)==0) ||
																																		(tc_strcmp(strParmInfo[totalCnt].structureOfData,Lookup1DInfo)==0) ||
																																		(tc_strcmp(strParmInfo[totalCnt].structureOfData,Array2DInfo)==0))
									{
										if(parmColCnt && tc_strlen(parmColCnt) > 0)
										{
											strParmInfo[totalCnt].colCnt=atoi(FV_trim_blanks(parmColCnt));
										}
									}
								}//discrete
							}//strType
							else
							{
								if(parmColCnt && tc_strlen(parmColCnt) > 0)
								{
									strParmInfo[totalCnt].colCnt=atoi(FV_trim_blanks(parmColCnt));
								}
							}
						}//colCntLoc
					}

					//rowLabels
					if(remPartAfterColCnt && tc_strlen(remPartAfterColCnt) > 0)
					{
						rowLabelLoc=strstr(FV_trim_blanks(remPartAfterColCnt),delim);
						if(rowLabelLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterColCnt),FV_trim_blanks(rowLabelLoc),&parmRowLabel,&remPartAfterRowLabel);
							if(parmRowLabel && tc_strlen(parmRowLabel) > 0)
							{
								strParmInfo[totalCnt].rowLabels= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmRowLabel))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].rowLabels,FV_trim_blanks(parmRowLabel));
							}
						}
					}

					//columnLabels
					if(remPartAfterRowLabel && tc_strlen(remPartAfterRowLabel)> 0)
					{
						colLabelLoc=strstr(FV_trim_blanks(remPartAfterRowLabel),delim);
						if(colLabelLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterRowLabel),FV_trim_blanks(colLabelLoc),&parmColLabel,&remPartAfterColLabel);
							if(parmColLabel && tc_strlen(parmColLabel)> 0)
							{
								strParmInfo[totalCnt].colLabels= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmColLabel))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].colLabels,FV_trim_blanks(parmColLabel));
							}
						}
					}


					//Minimum Value
					if(remPartAfterColLabel && tc_strlen(remPartAfterColLabel)> 0)
					{
						parmMinLoc=strstr(FV_trim_blanks(remPartAfterColLabel),delim);
						if(parmMinLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterColLabel),FV_trim_blanks(parmMinLoc),&parmMin,&remPartAfterParmMin);
							if(parmMin != NULL && tc_strlen(parmMin) > 0)
							{
								strParmInfo[totalCnt].minVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmMin))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].minVal,FV_trim_blanks(parmMin));
							}
						}
					}

					//Maximum Value
					if(remPartAfterParmMin && tc_strlen(remPartAfterParmMin) > 0)
					{
						parmMaxLoc=strstr(FV_trim_blanks(remPartAfterParmMin),delim);
						if(parmMaxLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmMin),FV_trim_blanks(parmMaxLoc),&parmMax,&remPartAfterParmMax);
							if(parmMax != NULL && tc_strlen(parmMax)> 0)
							{
								strParmInfo[totalCnt].maxVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmMax))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].maxVal,FV_trim_blanks(parmMax));
							}
						}
					}

                    // Nikhil Patil change starts.
                    /* If resolution value is double, make parameter type as double & dont traverse tables to decide type 
                     * & precision value. Get Precision from resolution
                     * If resolution value is integer then, check parameter type here.
                     * If any of 3 tables have values starting from 0x,
                     * consider that parameter as hex type.
                     * If any of 3 tables have values is double,
                     * consider that parameter as double type. Traverse all three tables to get maximum precision value.
                    */

                    if(strParmInfo[totalCnt].type == NULL || tc_strlen(strParmInfo[totalCnt].type) == 0 
                        || (strParmInfo[totalCnt].type != NULL && tc_strcmp(strParmInfo[totalCnt].type, FVE_ParmDefDblTYPE) != 0))
                    {
                        // Max precision value for init value.
                        int iPrecision_Init     =   0;

                        // Max precision value for min value.
                        int iPrecision_Min      =   0;

                        // Max precision value for max value.
                        int iPrecision_Max      =   0;

                        int iPrecision_Value    =   0;


                        ifail=fve_check_param_type(strParmInfo[totalCnt].initVal,strParmInfo[totalCnt].structureOfData,&findParmType);

                        /*
                            If parameter is double,
                            traverse all 3 tables, min,max and initial.
                            and find precision.

                            Ex .    min         = 1.23
                                    max         = 2.333
                                    initial =   2.1222
                                    Then precision is 4.
                        */
                        if ( tc_strcmp(findParmType, FVE_ParmDefDblTYPE) ==0 )
                        {

                            // Call custom function to get precision value.
                            ifail = fve_Get_Precision_Value(strParmInfo[totalCnt].initVal,
                                                            strParmInfo[totalCnt].structureOfData,
                                                            &iPrecision_Init);

                            // Call custom function to get precision value for max value.
                            ifail = fve_Get_Precision_Value(strParmInfo[totalCnt].maxVal,
                                                            strParmInfo[totalCnt].structureOfData,
                                                            &iPrecision_Max);

                            // Call custom function to get precision value for max value.
                            ifail = fve_Get_Precision_Value(strParmInfo[totalCnt].minVal,
                                                            strParmInfo[totalCnt].structureOfData,
                                                            &iPrecision_Min);

                            if ( iPrecision_Init >= iPrecision_Min)
                            {
                                iPrecision_Value = iPrecision_Init;
                            }
                            else
                            {
                                iPrecision_Value = iPrecision_Min;
                            }

                            if( iPrecision_Value <= iPrecision_Max)
                            {
                                iPrecision_Value = iPrecision_Max;
                            }

                            precisionVal = (char*)MEM_alloc((int)(iPrecision_Value + 1) * sizeof(char));
                            sprintf(precisionVal, "%d",iPrecision_Value );
                            strParmInfo[totalCnt].precision = (char *) MEM_alloc((int)(strlen(precisionVal) + 1) * sizeof(char));
                            strcpy(strParmInfo[totalCnt].precision,precisionVal);
                        }

                        if( (findParmType == NULL ) ||
                            ( findParmType != NULL &&
                              tc_strcmp(findParmType, FVE_ParmDefDblTYPE) != 0
                              && tc_strcmp(findParmType, FVE_ParmDefHexTYPE) != 0) )
                        {
                            // Check if min value starts from 0x.
                            ifail=fve_check_param_type(strParmInfo[totalCnt].minVal,strParmInfo[totalCnt].structureOfData,&findParmType);

                            // Check precision by traversing min and mx only.
                            if ( tc_strcmp(findParmType, FVE_ParmDefDblTYPE) ==0 )
                            {
                                // Call custom function to get precision value for max value.
                                ifail = fve_Get_Precision_Value(strParmInfo[totalCnt].maxVal,
                                                            strParmInfo[totalCnt].structureOfData,
                                                            &iPrecision_Max);

                                // Call custom function to get precision value for max value.
                                ifail = fve_Get_Precision_Value(strParmInfo[totalCnt].minVal,
                                                            strParmInfo[totalCnt].structureOfData,
                                                            &iPrecision_Min);

                                if( iPrecision_Max >= iPrecision_Min)
                                {
                                    iPrecision_Value    =   iPrecision_Max;
                                }
                                else
                                {
                                    iPrecision_Value    =   iPrecision_Min;
                                }

                                precisionVal = (char*)MEM_alloc((int)(iPrecision_Value + 1) * sizeof(char));
                                sprintf(precisionVal, "%d",iPrecision_Value );
                                strParmInfo[totalCnt].precision = (char *) MEM_alloc((int)(strlen(precisionVal) + 1) * sizeof(char));
                                strcpy(strParmInfo[totalCnt].precision,precisionVal);
                            }


                            if( (findParmType == NULL ) ||
                                ( findParmType != NULL &&
                                  tc_strcmp(findParmType, FVE_ParmDefDblTYPE) != 0 &&
                                  tc_strcmp(findParmType, FVE_ParmDefHexTYPE) != 0) )
                            {
                                ifail=fve_check_param_type(strParmInfo[totalCnt].maxVal,strParmInfo[totalCnt].structureOfData,&findParmType);

                                // Check precision by traversing mx only.
                                if ( tc_strcmp(findParmType, FVE_ParmDefDblTYPE) ==0 )
                                {
                                    // Call custom function to get precision value for max value.
                                    ifail = fve_Get_Precision_Value(strParmInfo[totalCnt].maxVal,
                                                            strParmInfo[totalCnt].structureOfData,
                                                            &iPrecision_Max);

                                    iPrecision_Value   =   iPrecision_Max;

                                    precisionVal = (char*)MEM_alloc((int)(iPrecision_Value + 1) * sizeof(char));
                                    sprintf(precisionVal, "%d",iPrecision_Value );
                                    strParmInfo[totalCnt].precision = (char *) MEM_alloc((int)(strlen(precisionVal) + 1) * sizeof(char));
                                    strcpy(strParmInfo[totalCnt].precision,precisionVal);
                                }
                            }
                         }
                         if(findParmType != NULL && (tc_strcmp(findParmType, FVE_ParmDefDblTYPE) == 0 || tc_strcmp(findParmType, FVE_ParmDefHexTYPE) == 0))
                         {
                            objectTypeTc = (char *) MEM_alloc((int)(strlen(findParmType) + 1) * sizeof(char));
                            tc_strcpy(objectTypeTc,findParmType);
                            if(objectTypeTc && tc_strlen(objectTypeTc) > 0)
                            {
                                strParmInfo[totalCnt].type= (char*) MEM_alloc((int) (strlen(objectTypeTc)+1)* sizeof(char));
                                tc_strcpy(strParmInfo[totalCnt].type,objectTypeTc);
                            }
                         }
                    }

                    // Nikhil Patil change ends.

					//overWritable
					if(remPartAfterParmMax && tc_strlen(remPartAfterParmMax)> 0)
					{
						parmOverWritableLoc=strstr(FV_trim_blanks(remPartAfterParmMax),delim);
						if(parmOverWritableLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmMax),FV_trim_blanks(parmOverWritableLoc),&parmOverWritable,&remParmOverWritable);
							if(parmOverWritable != NULL && tc_strlen(parmOverWritable)>0 && tc_strcmp("FALSE",FV_trim_blanks(parmOverWritable)) == 0)
								strParmInfo[totalCnt].overWritable=0;
							if(parmOverWritable != NULL && tc_strlen(parmOverWritable)>0 && tc_strcmp("TRUE",FV_trim_blanks(parmOverWritable)) == 0)
								strParmInfo[totalCnt].overWritable=1;
						}
					}

					//fault value
					if(remParmOverWritable && tc_strlen(remParmOverWritable)>0)
					{
						parmFaultLoc=strstr(FV_trim_blanks(remParmOverWritable),delim);
						if(parmFaultLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remParmOverWritable),FV_trim_blanks(parmFaultLoc),&parmFault,&remPartAfterParmFault);
							if(parmFault != NULL && tc_strlen(parmFault) > 0)
							{
								strParmInfo[totalCnt].faultVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmFault))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].faultVal,FV_trim_blanks(parmFault));
							}
						}
					}

					//Restricted
					if(remPartAfterParmFault && tc_strlen(remPartAfterParmFault)> 0)
					{
						parmRestrictedLoc=strstr(FV_trim_blanks(remPartAfterParmFault),delim);
						if(parmRestrictedLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmFault),FV_trim_blanks(parmRestrictedLoc),&parmRestricted,&remPartAfterParmRestricted);
							if(parmRestricted != NULL && tc_strlen(parmRestricted)> 0)
							{
								strParmInfo[totalCnt].restricted= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmRestricted))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].restricted,FV_trim_blanks(parmRestricted));
							}
						}
					}

					//Implementation Data Type
					if(remPartAfterParmRestricted && tc_strlen(remPartAfterParmRestricted)> 0)
					{
						implDataTypeLoc=strstr(FV_trim_blanks(remPartAfterParmRestricted),delim);
						if(implDataTypeLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParmRestricted),FV_trim_blanks(implDataTypeLoc),&implDataType,&remPartAfterImplDataType);
							if(implDataType != NULL && tc_strlen(implDataType)> 0)
							{
								strParmInfo[totalCnt].implDataType= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(implDataType))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].implDataType,FV_trim_blanks(implDataType));
							}
						}
					}

					//domain Element Name
					if(remPartAfterImplDataType && tc_strlen(remPartAfterImplDataType)> 0)
					{
						domainElNameLoc=strstr(FV_trim_blanks(remPartAfterImplDataType),delim);
						if(domainElNameLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterImplDataType),FV_trim_blanks(domainElNameLoc),&domainElName,&remPartAfterdomainElName);
							if(domainElName != NULL && tc_strlen(domainElName) > 0)
							{
								strParmInfo[totalCnt].domainElName= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(domainElName))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].domainElName,FV_trim_blanks(domainElName));
							}
						}
					}

					//domain Element Value
					if(remPartAfterdomainElName && tc_strlen(remPartAfterdomainElName)> 0)
					{
						domainElValueLoc=strstr(FV_trim_blanks(remPartAfterdomainElName),delim);
						if(domainElValueLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterdomainElName),FV_trim_blanks(domainElValueLoc),&domainElValue,&remPartAfterdomainElValue);
							if(domainElValue != NULL && tc_strlen(domainElValue)> 0)
							{
								strParmInfo[totalCnt].domainElVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(domainElValue))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].domainElVal,FV_trim_blanks(domainElValue));
							}
						}
					}

					//Domain Element Description
					if(remPartAfterdomainElValue && tc_strlen(remPartAfterdomainElValue)>0)
					{
						domainElDescrLoc=strstr(FV_trim_blanks(remPartAfterdomainElValue),delim);
						if(domainElDescrLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterdomainElValue),FV_trim_blanks(domainElDescrLoc),&domainElDescr,&remPartAfterdomainElDescr);
							if(domainElDescr != NULL && tc_strlen(domainElDescr)> 0)
							{
								strParmInfo[totalCnt].domainElDescr= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(domainElDescr))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].domainElDescr,FV_trim_blanks(domainElDescr));
							}
						}
					}

					//Source
					if(remPartAfterdomainElDescr && tc_strlen(remPartAfterdomainElDescr)> 0)
					{
						sourceLoc=strstr(FV_trim_blanks(remPartAfterdomainElDescr),delim);
						if(sourceLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterdomainElDescr),FV_trim_blanks(sourceLoc),&source,&remPartAfterSource);
							if(source != NULL && tc_strlen(source)> 0)
							{
								strParmInfo[totalCnt].src= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(source))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].src,FV_trim_blanks(source));
							}
						}
					}

					//sink
					if(remPartAfterSource && tc_strlen(remPartAfterSource)> 0)
					{
						snkLoc=strstr(FV_trim_blanks(remPartAfterSource),delim);
						if(snkLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterSource),FV_trim_blanks(snkLoc),&snk,&remPartAfterSnk);
							if(snk != NULL && tc_strlen(snk)> 0)
							{
								strParmInfo[totalCnt].snk= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(snk))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].snk,FV_trim_blanks(snk));
							}
						}
					}

					//source and sink
					if(remPartAfterSnk && tc_strlen(remPartAfterSnk)> 0)
					{
						srcSnkLoc=strstr(FV_trim_blanks(remPartAfterSnk),delim);
						if(srcSnkLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterSnk),FV_trim_blanks(srcSnkLoc),&srcSnk,&remPartAfterSrcSnk);
							if(srcSnk && tc_strlen(srcSnk) > 0)
							{
								strParmInfo[totalCnt].srcSnk= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(srcSnk))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].srcSnk,FV_trim_blanks(srcSnk));
							}
						}
					}

					//local
					if(remPartAfterSrcSnk && tc_strlen(remPartAfterSrcSnk)> 0)
					{
						localLoc=strstr(FV_trim_blanks(remPartAfterSrcSnk),delim);
						if(localLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterSrcSnk),FV_trim_blanks(localLoc),&local,&remPartAfterLocal);
							if(local && tc_strlen(local) > 0)
							{
								strParmInfo[totalCnt].local= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(local))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].local,FV_trim_blanks(local));
							}
						}
					}


					//Implementation Resolution
					if(remPartAfterLocal && tc_strlen(remPartAfterLocal)> 0)
					{
						implResolutionLoc=strstr(FV_trim_blanks(remPartAfterLocal),delim);
						if(implResolutionLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterLocal),FV_trim_blanks(implResolutionLoc),&implResolution,&remPartAfterImplResolution);
							if(implResolution != NULL && tc_strlen(implResolution) > 0)
							{
								strParmInfo[totalCnt].implResolution= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(implResolution))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].implResolution,FV_trim_blanks(implResolution));
							}
						}
					}

					//offset
					if(remPartAfterImplResolution && tc_strlen(remPartAfterImplResolution)> 0)
					{
						offsetLoc=strstr(FV_trim_blanks(remPartAfterImplResolution),delim);
						if(offsetLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterImplResolution),FV_trim_blanks(offsetLoc),&offsetStr,&remPartAfterOffset);
							if(offsetStr != NULL && tc_strlen(offsetStr) > 0)
							{
								strParmInfo[totalCnt].offset= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(offsetStr))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].offset,FV_trim_blanks(offsetStr));
							}
						}
					}


					//config group
					if(remPartAfterOffset && tc_strlen(remPartAfterOffset)> 0)
					{
						configGrpLoc=strstr(FV_trim_blanks(remPartAfterOffset),delim);
						if(configGrpLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterOffset),FV_trim_blanks(configGrpLoc),&configGrp,&remPartAfterconfigGrp);
							if(configGrp != NULL && tc_strlen(configGrp)> 0)
							{
								strParmInfo[totalCnt].configGrp= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(configGrp))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].configGrp,FV_trim_blanks(configGrp));
							}
						}
					}

					if(remPartAfterconfigGrp && tc_strlen(remPartAfterconfigGrp)> 0)
					{
						inhale_ExhaleLoc=strstr(FV_trim_blanks(remPartAfterconfigGrp),delim);
						if(inhale_ExhaleLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterconfigGrp),FV_trim_blanks(inhale_ExhaleLoc),&inhale_Exhale,&remPartAfterInhale_Exhale);
							if(inhale_Exhale != NULL && tc_strlen(inhale_Exhale) > 0)
							{
								strParmInfo[totalCnt].inhaleExhale= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(inhale_Exhale))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].inhaleExhale,FV_trim_blanks(inhale_Exhale));
							}
						}
					}

					if(remPartAfterInhale_Exhale && tc_strlen(remPartAfterInhale_Exhale)> 0)
					{
						asBuilt_VehOpLoc=strstr(FV_trim_blanks(remPartAfterInhale_Exhale),delim);
						if(asBuilt_VehOpLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterInhale_Exhale),FV_trim_blanks(asBuilt_VehOpLoc),&asBuilt_VehOp,&remPartAfterAsBuilt_VehOp);
							if(asBuilt_VehOp != NULL && tc_strlen(asBuilt_VehOp)> 0)
							{
								strParmInfo[totalCnt].asBuiltVehOp= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(asBuilt_VehOp))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].asBuiltVehOp,FV_trim_blanks(asBuilt_VehOp));
							}
						}
					}

					if(remPartAfterAsBuilt_VehOp && tc_strlen(remPartAfterAsBuilt_VehOp)> 0)
					{
						moduleManfLoc=strstr(FV_trim_blanks(remPartAfterAsBuilt_VehOp),delim);
						if(moduleManfLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterAsBuilt_VehOp),FV_trim_blanks(moduleManfLoc),&moduleManf,&remPartAfterModuleManf);
							if(moduleManf != NULL && tc_strlen(moduleManf)> 0)
							{
								strParmInfo[totalCnt].moduleManf= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(moduleManf))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].moduleManf,FV_trim_blanks(moduleManf));
							}
						}
					}

					if(remPartAfterModuleManf && tc_strlen(remPartAfterModuleManf)> 0)
					{
						fcsdCustPrefLoc=strstr(FV_trim_blanks(remPartAfterModuleManf),delim);
						if(fcsdCustPrefLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterModuleManf),FV_trim_blanks(fcsdCustPrefLoc),&fcsdCustPref,&remPartAfterFcsdCustPref);
							if(fcsdCustPref != NULL && tc_strlen(fcsdCustPref) > 0)
							{
								strParmInfo[totalCnt].fcsdCustPref= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(fcsdCustPref))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].fcsdCustPref,FV_trim_blanks(fcsdCustPref));
							}
						}else
						{
							strParmInfo[totalCnt].fcsdCustPref= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(remPartAfterModuleManf))+1)* sizeof(char));
							strcpy(strParmInfo[totalCnt].fcsdCustPref,FV_trim_blanks(remPartAfterModuleManf));
						}
					}
					//Model Unit
					if(remPartAfterFcsdCustPref && tc_strlen(remPartAfterFcsdCustPref)> 0)
					{
						msaUnitLoc=strstr(FV_trim_blanks(remPartAfterFcsdCustPref),delim);
						if(msaUnitLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterFcsdCustPref),FV_trim_blanks(msaUnitLoc),&msaUnit,&remPartAfterMSAUnit);
							if(msaUnit != NULL && tc_strlen(msaUnit) > 0)
							{
								strParmInfo[totalCnt].msaUnit= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(msaUnit))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].msaUnit,FV_trim_blanks(msaUnit));
							}
						}
					}
					//size
					if(remPartAfterMSAUnit && tc_strlen(remPartAfterMSAUnit)> 0)
					{
						sizeLoc=strstr(FV_trim_blanks(remPartAfterMSAUnit),delim);
						if(sizeLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterMSAUnit),FV_trim_blanks(sizeLoc),&parmSize,&remPartAfterSize);
							if(parmSize && tc_strlen(parmSize) > 0)
							{
								strParmInfo[totalCnt].size= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(parmSize))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].size,FV_trim_blanks(parmSize));
							}
						}
					}
					//group name
					if(remPartAfterSize && tc_strlen(remPartAfterSize)> 0)
					{
						groupLoc=strstr(FV_trim_blanks(remPartAfterSize),delim);
						if(groupLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterSize),FV_trim_blanks(groupLoc),&groupInfo,&remPartAfterGroup);
							if(groupInfo && tc_strlen(groupInfo) > 0)
							{
								strParmInfo[totalCnt].groupName= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(groupInfo))+1)* sizeof(char));
								strcpy(strParmInfo[totalCnt].groupName,FV_trim_blanks(groupInfo));
							}
						}else
						{
							strParmInfo[totalCnt].groupName= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(remPartAfterSize))+1)* sizeof(char));
							strcpy(strParmInfo[totalCnt].groupName,FV_trim_blanks(remPartAfterSize));
						}
					}
					if(lgIncrCount == TRUE)
						totalCnt++;
					FVE_FREE(line_temp)
					copyStr=NULL;
				}//if(delim != NULL && tc_strlen(delim)> 0)

                FVE_FREE(tempStrLong)

				FVE_FREE(parmName);
				FVE_FREE(parmDescr);
				FVE_FREE(parmType);

				FVE_FREE(parmCategory);
				FVE_FREE(parmStorageClass);
				FVE_FREE(parmInitValue);
				FVE_FREE(parmStruOfData);
				FVE_FREE(parmUnit);

				FVE_FREE(parmResolution);
				FVE_FREE(parmTolerance);
				FVE_FREE(parmRowLabel);
				FVE_FREE(parmColLabel);
				FVE_FREE(parmRowCnt);
				FVE_FREE(parmColCnt);
				FVE_FREE(parmMin);
				FVE_FREE(parmMax);
				FVE_FREE(parmOverWritable);
				FVE_FREE(implDataType);
				FVE_FREE(implResolution);
				FVE_FREE(offsetStr);
				FVE_FREE(parmFault);
				FVE_FREE(parmRestricted);

				FVE_FREE(domainElName);
				FVE_FREE(domainElValue);
				FVE_FREE(domainElDescr);
				FVE_FREE(source);
				FVE_FREE(snk);
				FVE_FREE(srcSnk);
				FVE_FREE(local);
				FVE_FREE(configGrp);
				FVE_FREE(inhale_Exhale);
				FVE_FREE(asBuilt_VehOp);
				FVE_FREE(moduleManf);
				FVE_FREE(fcsdCustPref);

				FVE_FREE(remPartAfterName);
				FVE_FREE(remPartAfterParmType);
				FVE_FREE(remPartAfterDescr);
				FVE_FREE(remPartAfterParmCategory);
				FVE_FREE(remPartAfterParmStorageCl);
				FVE_FREE(remPartAfterParmInitValue);
				FVE_FREE(remPartAfterparmStruOfData);
				FVE_FREE(remPartAfterParmUnit);
				FVE_FREE(remPartAfterParmResolution);
				FVE_FREE(remPartAfterRowCnt);
				FVE_FREE(remPartAfterColCnt);
				FVE_FREE(remPartAfterRowLabel);
				FVE_FREE(remPartAfterColLabel);
				FVE_FREE(remPartAfterParmTolerance);
				FVE_FREE(remPartAfterParmMin);
				FVE_FREE(remPartAfterParmMax);
				FVE_FREE(remParmOverWritable);
				FVE_FREE(remPartAfterParmFault);
				FVE_FREE(remPartAfterParmRestricted);
				FVE_FREE(remPartAfterImplDataType);
				FVE_FREE(remPartAfterdomainElName);
				FVE_FREE(remPartAfterdomainElValue);
				FVE_FREE(remPartAfterdomainElDescr);
				FVE_FREE(remPartAfterSource);
				FVE_FREE(remPartAfterSnk);
				FVE_FREE(remPartAfterLocal);
				FVE_FREE(remPartAfterSrcSnk);
				FVE_FREE(remPartAfterImplResolution);
				FVE_FREE(remPartAfterOffset);
				FVE_FREE(remPartAfterconfigGrp);
				FVE_FREE(remPartAfterInhale_Exhale);
				FVE_FREE(remPartAfterAsBuilt_VehOp);
				FVE_FREE(remPartAfterFcsdCustPref);
				FVE_FREE(remPartAfterModuleManf);
                FVE_FREE(findParmType)

			}//while
		}

		TC_write_syslog("\n Leave function %s",function_name);
	    return totalCnt;
}

/*
function to create the process object if it didnt exist
1.Attach the process object to parameter definition revision with given relation in context of dictionary.

2.get the alreday attached processes for parameter definition revision with relation in context of dictionary.
3.compare these process names with current processes based on relation name ,
  if old process name not exist , remove the relation between parameter rev and process object in context of dictionary.
  if new process name exist , add the relation between parameter rev and process object in context of dictionary.
*/
int FVE_get_ProcessObjectInfo(struct FVEParmDefInfostruct *parmInfoStr,int counter,tag_t parmDefBl,tag_t inContextRevision,tag_t window)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_get_ProcessObjectInfo";
	char*		srcName				=	NULL;
	char*		snkName				=	NULL;
	char*		localName			=	NULL;
	char*		srcSnkName			=	NULL;
	int			cntSrcObjects		=	0;
	char		**valSrcObjects		=	NULL;
	int			cntSnkObjects		=	0;
	char		**valSnkObjects	=	NULL;

	int			cntLocalObjects		=	0;
	char		**valLocalObjects	=	NULL;
	int			cntSrcSnkObjects		=	0;
	char		**valSrcSnkObjects	=	NULL;


	TC_write_syslog("\n Enter function %s",function_name);

	ifail=FVE_compare_process_basedRelation(parmInfoStr,counter,parmDefBl,FVE_SOURCE_RELATION);
	ifail=FVE_compare_process_basedRelation(parmInfoStr,counter,parmDefBl,FVE_SINK_RELATION);
	ifail=FVE_compare_process_basedRelation(parmInfoStr,counter,parmDefBl,FVE_LOCAL_RELATION);
	ifail=FVE_compare_process_basedRelation(parmInfoStr,counter,parmDefBl,FVE_SOURCE_SINK_RELATION);


	//get the process onject names from parmInfoStr for each relation
	//srcName=parmInfoStr[counter].src;
	if(parmInfoStr[counter].src && tc_strlen(parmInfoStr[counter].src) > 0)
	{
		srcName = (char *) MEM_alloc((int)(strlen(parmInfoStr[counter].src) + 1) * sizeof(char));
		tc_strcpy(srcName,parmInfoStr[counter].src);
	}

	//snkName=parmInfoStr[counter].snk;
	if(parmInfoStr[counter].snk && tc_strlen(parmInfoStr[counter].snk) > 0)
	{
		snkName=(char *) MEM_alloc((int)(strlen(parmInfoStr[counter].snk) + 1) * sizeof(char));
		tc_strcpy(snkName,parmInfoStr[counter].snk);
	}
	//localName=parmInfoStr[counter].local;
	if(parmInfoStr[counter].local && tc_strlen(parmInfoStr[counter].local) > 0)
	{
		localName=(char *) MEM_alloc((int)(strlen(parmInfoStr[counter].local) + 1) * sizeof(char));
		tc_strcpy(localName,parmInfoStr[counter].local);
	}
	//srcSnkName=parmInfoStr[counter].srcSnk;
	if(parmInfoStr[counter].srcSnk && tc_strlen(parmInfoStr[counter].srcSnk)> 0)
	{
		srcSnkName=(char *) MEM_alloc((int)(strlen(parmInfoStr[counter].srcSnk) + 1) * sizeof(char));
		tc_strcpy(srcSnkName,parmInfoStr[counter].srcSnk);
	}


	//get the process list seperated by comma for each realtion
	ifail=split_the_string(srcName,COMMA_DELIM,&cntSrcObjects,&valSrcObjects);
	ifail=split_the_string(snkName,COMMA_DELIM,&cntSnkObjects,&valSnkObjects);
	ifail=split_the_string(localName,COMMA_DELIM,&cntLocalObjects,&valLocalObjects);
	ifail=split_the_string(srcSnkName,COMMA_DELIM,&cntSrcSnkObjects,&valSrcSnkObjects);


	//source process objects
	if(valSrcObjects && cntSrcObjects > 0)
		ifail=FVE_process_object(parmDefBl,cntSrcObjects,valSrcObjects,FVE_SOURCE_RELATION,inContextRevision,window);

	//sink process objects
	if(valSnkObjects && cntSnkObjects > 0)
		ifail=FVE_process_object(parmDefBl,cntSnkObjects,valSnkObjects,FVE_SINK_RELATION,inContextRevision,window);

	//local process objects
	if(valLocalObjects && cntLocalObjects > 0)
		ifail=FVE_process_object(parmDefBl,cntLocalObjects,valLocalObjects,FVE_LOCAL_RELATION,inContextRevision,window);

	//source/sink process object
	if(valSrcSnkObjects && cntSrcSnkObjects > 0)
		ifail=FVE_process_object(parmDefBl,cntSrcSnkObjects,valSrcSnkObjects,FVE_SOURCE_SINK_RELATION,inContextRevision,window);


	FVE_FREE(srcName)
	FVE_FREE(snkName)
	FVE_FREE(localName)
	FVE_FREE(srcSnkName)

	cntSrcObjects=0;
	cntSnkObjects=0;
	cntLocalObjects=0;
	cntSrcSnkObjects=0;

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}

//create process object
int FVE_create_processObject(char *prName,char *prType,char *featureName,char *taskRate, tag_t *processObject)
{

	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_processObject";
	tag_t		revProcessObject	=	NULLTAG;
	char*		itemAttrNames[1]	=	{object_namePROP};
	char*		itemAttrValues[1]			=	{""};
	char*		revAttrNames[2]			=	{FVE_ECUAcronymPROP,FVE_ProcessTypePROP};
	char*		revAttrValues[2]			={"",""};
	char		*message			=	NULL;

	TC_write_syslog("\n Enter function %s",function_name);
	if(prName && prType && ecuAcronym && tc_strlen(prName)> 0 && tc_strlen(prType)> 0 && tc_strlen(ecuAcronym)> 0)
	{
		itemAttrValues[0]=prName;
		revAttrValues[0]=ecuAcronym;
		revAttrValues[1]=prType;
		//fprintf(logfileptr,"Comment: %s does not exist in the database, creating the new one\n",prName);

		ITK(FV_createObject("FVE_Process",1,itemAttrNames,itemAttrValues,2,revAttrNames,revAttrValues,&revProcessObject))
		if(revProcessObject)
		{
			*processObject=revProcessObject;
			fprintf(logfileptr,"Status: Created Successfully.\n");
			//set the taskRate on Process Object
			AM__set_application_bypass(TRUE);
			ITK(AOM_refresh(*processObject,TRUE))
			if(taskRate != NULL)
			{
				ITK(AOM_set_value_double(*processObject,FVE_TaskRatePROP,atof(taskRate)))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}

			ITK(AOM_save(*processObject))
			ITK(AOM_refresh(*processObject,FALSE))
			AM__set_application_bypass(FALSE);
		}
		else
		{
			*processObject=NULLTAG;
			fprintf(logfileptr,"Status: Failed.\n");
			EMH_ask_error_text (ifail, &message);
			fprintf(logfileptr,"ERROR: %s\n",message);
		}
	}

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}

/*
function to create/update process objects only.
*/
int FVE_getProcessModeOnly(struct FVEProcessInfostruct *processInfoStr,int totalNoOfProcess)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_getProcessModeOnly";
	int			iCounter			=	0;
	tag_t		*processObjTags		=	NULL;
	int			processObjCount		=	0;
	tag_t		processObjRevTag	=	NULLTAG;
	tag_t		processObject		=	NULLTAG;
	char		*message			=	NULL;

	TC_write_syslog("\n Enter function %s",function_name);

	fprintf(logfileptr,"Checking for the process objects...\n");
	fprintf(logfileptr,"\n");
	for(iCounter=0;iCounter<totalNoOfProcess;iCounter++)
	{
		if(processInfoStr[iCounter].processName && tc_strlen(processInfoStr[iCounter].processName)> 0)
		{
			fprintf(logfileptr,"Process Name:%s \n",processInfoStr[iCounter].processName);
			if(processInfoStr[iCounter].processType && tc_strlen(processInfoStr[iCounter].processType)> 0)
			{
				fprintf(logfileptr,"Process Type:%s \n",processInfoStr[iCounter].processType);
			}else
			{
				fprintf(logfileptr,"Process Type: \n");
			}
			if(processInfoStr[iCounter].featureName && tc_strlen(processInfoStr[iCounter].featureName) > 0)
			{
				fprintf(logfileptr,"Feature Name:%s \n",processInfoStr[iCounter].featureName);
			}else
			{
				fprintf(logfileptr,"Feature Name: \n");
			}

			if(processInfoStr[iCounter].taskRate && tc_strlen(processInfoStr[iCounter].taskRate)> 0)
			{
				fprintf(logfileptr,"Task Rate:%s \n",processInfoStr[iCounter].taskRate);
			}else
			{
				fprintf(logfileptr,"Task Rate: \n");
			}

			ifail=FVE_gsdb_find_wso_with_attr("FVE_process","object_name",FV_trim_blanks(processInfoStr[iCounter].processName),&processObjTags,&processObjCount);
			if(processObjCount == 0)
			{
				if(processInfoStr[iCounter].processName && processInfoStr[iCounter].processType)
				{
					ifail=FVE_create_processObject(FV_trim_blanks(processInfoStr[iCounter].processName),FV_trim_blanks(processInfoStr[iCounter].processType),FV_trim_blanks(processInfoStr[iCounter].featureName),FV_trim_blanks(processInfoStr[iCounter].taskRate),&processObject);
				}else
				{
					fprintf(logfileptr,"Process Type does not exist\n");
					fprintf(logfileptr,"Status: Failed\n");
					fprintf(logfileptr,"ERROR: Required attributes are missing\n");

				}

				if(processObject)
				{
					successCntProcesses++;
					TC_write_syslog("object %s created successfully \n",processInfoStr[iCounter].processName);
				}else
				{
					failureCntProcesses++;
					TC_write_syslog("object %s failed to create \n",processInfoStr[iCounter].processName);
				}
			}else
			{
				//get the latest revision for processObjTags[0]
				if(processObjTags[0])
				{
					successCntProcesses++;
					fprintf(logfileptr,"Status: Already exist in database.\n");
					processObjRevTag=NULLTAG;
					// Get the new item revision tag.
					ITK(ITEM_ask_latest_rev(processObjTags[0],&processObjRevTag))
					processObject=processObjRevTag;
					ifail=FVE_compare_process_object(processInfoStr,iCounter,processObject);
				}else
				{
					failureCntProcesses++;
					TC_write_syslog("Failed to get object %s from database.\n",processInfoStr[iCounter].processName);
					EMH_ask_error_text (ifail, &message);
					fprintf(logfileptr,"ERROR: %s\n",message);
				}
			}
			FVE_FREE(processObjTags)
			processObjCount=0;
			fprintf(logfileptr,"\n");
		}//processInfoStr[iCounter].processName
	}//for iCounter=0;

	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PROCESS_MODE) == 0))
	{
		fprintf(logfileptr,"\n");
		fprintf(logfileptr,"Total Count Of Processes: %d\n",totalNoOfProcess);

		fprintf(logfileptr,"Successfully Processed Processes: %d\n",successCntProcesses);
		fprintf(logfileptr,"Failure Count: %d\n",failureCntProcesses);
		fprintf(logfileptr,"\n");
	}
	fprintf(logfileptr,"Completed Processing Process Objects.\n");
	printf("\nCompleted Processing Process Objects.\n");
	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"\n");


	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}
int FVE_createParameterDefinitions(struct FVEParmDefInfostruct *parmInfoStr,int totalNoOfParameters)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_createParameterDefinitions";
	int			iParmCounter		=	0;
	
	//change management
	tag_t		newDicItemTag		=	NULLTAG;
	tag_t		dummyDicRevTag		=	NULLTAG;
	tag_t		new_DicRevTag		=	NULLTAG;
	tag_t		dictLockedStatusTag	=	NULLTAG;

	TC_write_syslog("\n Enter function %s",function_name);
	if(totalNoOfParameters > 0)
	{
		/* 
			Prime Dictionary should be set in "IN-CONTEXT" mode because "Process Object/s" get attach any time during lifecycle of dictionary.
			For ECCT project i.e. for repository structure no question of "process object/s" .so for this do not set top bomline in "IN-CONTEXT" mode.
					
		*/
		//get the precise Assembly structure for Dictionary .Get the BVR of dictionary rev
		if(dicItemTag != NULLTAG && dicRevTag != NULLTAG)
			ifail=FV_createPreciseStructure(dicItemTag,dicRevTag,&topDicBomLine,&windowDic,TRUE);
		if(topDicBomLine && windowDic)
		{
			/*The first thing we need to check before importing parameters,
			check if the dictionary has an org group, if not we create the org group, with the name “<dictionary name>–Org Group”.
			Then check if the Org group has any parameter group under it (this will be applicable, if the org group is available first of all).
			If not, we create the parameter group also with the name “<dictionary name>-Parameter Group”.
			Then, as and when we create parameters,attach it to the parameter group created before.*/

			ifail=FVE_get_organizationChild(topDicBomLine,&orgBlTag,&isRevise);
			
			//Change Management
			if(isRevise == TRUE)
			{
				fprintf(logfileptr,"Dictionary already contains the Organization and Parameter groups\n");
				fprintf(logfileptr,"\n");
			
				dummyDicRevTag=dicRevTag;
				AM__set_application_bypass(TRUE);
				ITK(AOM_refresh(dummyDicRevTag,TRUE))
				//revise dictionary revision
				ITK(ITEM_copy_rev(dummyDicRevTag,NULL,&new_DicRevTag))
				if(ifail== ITK_ok && new_DicRevTag)
				{
					ITK(ITEM_ask_item_of_rev(new_DicRevTag,&newDicItemTag))
					dicItemTag=newDicItemTag;
					TC_write_syslog("\n In %s: Revised Prime Dictionary",function_name);
					dicRevTag = new_DicRevTag;
				}
				ITK(AOM_refresh(dummyDicRevTag,FALSE))
				AM__set_application_bypass(FALSE);

				//set this newly revision in a structure
				if(dicItemTag && dicRevTag)
				{
					ifail=FV_createPreciseStructure(dicItemTag,dicRevTag,&topDicBomLine,&windowDic,TRUE);
				}

				orgBlTag=NULLTAG;
				isRevise=FALSE;
				ifail=FVE_get_organizationChild(topDicBomLine,&orgBlTag,&isRevise);

			}
		}

	}

	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,ALL_MODE) == 0))
	{
		ifail=FVE_getProcessModeOnly(strProcessInfo,totalNoOfProcess);
	}

	if(totalNoOfParameters > 0)
	{
		fprintf(logfileptr,"Start Processing Parameter Definitions \n");
		fprintf(logfileptr,"\n");
	}

    if(isRevise)
    {
        if( ( mode != NULL ) &&
        ( tc_strlen(mode) > 0 ) &&
        ( tc_strcmp(mode, PROCESS_MODE) != 0) )
        {
            /*  First, check if param present in current dictionary structure is
                present in csv(struct) file.
                If not present, remove it from dictionary structure.
            */

            ifail = FVE_DeleteLineFromBVRStructure(parmInfoStr, topDicBomLine, windowDic);

        }
    }


	for(iParmCounter=0;iParmCounter<totalNoOfParameters;iParmCounter++)
	{
		if(isRevise == FALSE)
		{
			ifail=FVE_create_operations(parmInfoStr,iParmCounter, TRUE, 0, NULL);
		}else
		{
			ifail=FVE_update_operations(parmInfoStr,iParmCounter, 0, NULL, 0, NULL);
		}
		fprintf(logfileptr,"\n");
	}//for loop
   
	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"Completed Processing Parameter Definitions \n");
	printf("\nCompleted Processing Parameter Definitions.\n");
	fprintf(logfileptr,"\n");
	if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,ALL_MODE) == 0))
	{
		fprintf(logfileptr,"\n");
		fprintf(logfileptr,"Total Count Of Processes: %d\n",totalNoOfProcess);

		fprintf(logfileptr,"Successfully Processed Processes: %d\n",successCntProcesses);
		fprintf(logfileptr,"Failure Count Processes: %d\n",failureCntProcesses);
		fprintf(logfileptr,"\n");
	}
	fprintf(logfileptr,"Total Count Of Parameters: %d\n",totalNoOfParameters);
	fprintf(logfileptr,"Successfully Processed Parameters: %d\n",successCntParameter);
	fprintf(logfileptr,"Failure Count Parameters: %d\n",failureCntParameter);
	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"\n");

	if(logFilePtrFailure)
	{
		fprintf(logFilePtrFailure,"\n");
		fprintf(logFilePtrFailure,"\n");
		fprintf(logFilePtrFailure,"Total Count Of Parameters: %d\n",totalNoOfParameters);
		fprintf(logFilePtrFailure,"Successfully Processed Parameters: %d\n",successCntParameter);
		fprintf(logFilePtrFailure,"Failure Count Parameters: %d\n",failureCntParameter);
		fprintf(logFilePtrFailure,"\n");
		fprintf(logFilePtrFailure,"\n");
	}
	
	//Change management
	if(ifail != ITK_ok)
	{
		ifail=ITK_ok;
	}
	ITK(FV_set_object_status(dicRevTag,DICTN_LOCK_STATUSTYPE,TRUE,&dictLockedStatusTag))

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}




/* This function checks the tokenised value is null or not */
void fve_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}

/*
int FV_create_folder(char *flName)
{
	int         ifail				=	ITK_ok;
    char*       function_name		=	"FV_create_folder";
	char *user_name_string=NULL;
	tag_t owning_user=NULLTAG;
	tag_t home_folder_tag=NULLTAG;
	tag_t newStuff_folder_tag=NULLTAG;
	tag_t *home_content_tags=NULL;
	int num_contents_home=0;
	int number_of_newStff_entries=0;
	logical verdict_HomeFl = false;
	logical verdict_newStuffFl = false;
	tag_t folder_tag=NULLTAG;

	TC_write_syslog("\n Enter function %s",function_name);
	ITK(POM_get_user(&user_name_string, &owning_user))
	FVE_FREE(user_name_string)
	ITK(FL_init_module())
	ITK(SA_ask_user_home_folder(owning_user, &home_folder_tag))
	ITK(SA_ask_user_newstuff_folder(owning_user,&newStuff_folder_tag))
	ITK(FL_ask_size(newStuff_folder_tag,&number_of_newStff_entries))
	ITK(POM_modifiable(home_folder_tag,&verdict_HomeFl))

	ITK(FL_create(flName, "folder_descr",&folder_tag))
	ITK(AOM_save(folder_tag))
	ITK(AOM_refresh(folder_tag,TRUE))

	ITK(AOM_ask_value_tags(home_folder_tag, CONTENTS_ATTR_NAME, &num_contents_home, &home_content_tags))
	//if home folder is loaded for modify
	if(verdict_HomeFl)
	{
		ITK(FL_insert(home_folder_tag,folder_tag, num_contents_home))
		ITK(AOM_save(home_folder_tag))
	}else
	{
			AM__set_application_bypass(TRUE);
			ITK(AOM_refresh(home_folder_tag,TRUE))
			if(ifail != ITK_ok)
			{
				ifail=ITK_ok;
				//get newStuff folder in users home directory.
				//directly copy newly folder in newstuff folder.

				//before insert check if newstuff folder loaded for modify
				ITK(POM_modifiable(newStuff_folder_tag,&verdict_newStuffFl))
				if(verdict_newStuffFl)
				{
					ITK(FL_insert(newStuff_folder_tag,folder_tag,number_of_newStff_entries))
					ITK(AOM_save(newStuff_folder_tag))
				}else
				{
					ITK(AOM_refresh(newStuff_folder_tag,TRUE))
					if(ifail != ITK_ok)
					{
						ifail=ITK_ok;
						TC_write_syslog("\n Newly Folder %s not get copied anywhere as Folders Home/Newstuff not loaded for modify.It exist in the databse. \n",flName);
						TC_write_syslog("\n Search on the newly folder  = %s for further modifications...\n",flName);
					}else
					{
						ITK(FL_insert(newStuff_folder_tag,folder_tag,number_of_newStff_entries))
						ITK(AOM_save(newStuff_folder_tag))
						ITK(AOM_refresh(newStuff_folder_tag,FALSE))
					}
				}
			}else
			{
				ITK(FL_insert(home_folder_tag,folder_tag, num_contents_home))
				ITK(AOM_save(home_folder_tag))
				ITK(AOM_refresh(home_folder_tag,FALSE))
			}
			AM__set_application_bypass(FALSE);
	}


	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}
*/

/******************************************************************************
 * Filename        :   fve_import_parameters.c
 * Description     :   Defines the help usage for this utility.
 * Module          :   fve_import_parameters.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name                Description of Change
 *                  Swapnal Shewale     Initial Code
 * 29-04-2013       Nikhil Patil        Added config file help usage.
 *                                      Corrected indentation for usage.
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
static void print_usage(void)
{
        printf("\n*******************************************************************************\n");
        printf("Usage: fve_import_parameters <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<User id with a Software Engr or Module Supervisor role>\n");
        printf(" {-p=password | -pf=passwordFile}\n");
		printf(" -g=<Teamcenter group for userid>\n");
		printf(" -itemid=<{Dictionary | Repository} item id>\n");
		printf(" -revid=<revision id>\n");
		printf(" -mode=parameter or process or all \n");
        printf(" -parmdeffile=<dir\\parmdeffile> \n");
        printf(" The parmdeffile name should contain parameter definition information seperated by || delimiter \n");
		printf(" -processdeffile=<dir\\processdeffile> \n");
        printf(" The processdeffile name should contain process information seperated by || delimiter \n");
        printf(" -configFile=<dir\\processdeffile> \n");
        printf(" This input is optional. The configuration file is used to process parameter definition files.  \n");
		printf("******************************************************************************\n\n");

}


void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
			EMH_ask_error_text (stat, &errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], texts[n_ifails-1] );
			fprintf(logfileptr, "%s: Error: %d at Line %d  -- %s\n", prog_name, ifails[n_ifails-1], lineNumber, texts[n_ifails-1] );
			fflush(logfileptr);

			MEM_free( errstring );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
			//TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], texts[n_ifails-1] );
			//fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, ifails[n_ifails-1], lineNumber, errstring );
			fprintf(logfileptr, "%s: Error: %d at Line %d -- %s\n", prog_name, ifails[n_ifails-1], lineNumber, texts[n_ifails-1] );
			fflush(logfileptr);
			

            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
		TC_write_syslog( "%s: Error: %d %s\n", prog_name, stat, errstring );
		fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, stat, lineNumber, errstring );
		fflush(logfileptr);
        MEM_free( errstring );
    }
    //TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	/*fprintf(logfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );*/
	//fflush(logfileptr);
}

// Given an object tag and a typename, if input object is
// is a type/subtype of the typename then return TRUE.
int FV_object_is_typeof(tag_t obj_tag, char* typename, logical* answer)
{
    int      ifail = ITK_ok;
    char*    function_name = "FV_object_is_typeof";
    tag_t    type_tag = NULLTAG;

    *answer = FALSE;

    if (typename == NULL)
       CLEANUP(FV_handle_missing_arg_error(function_name, "typename"))

    CLEANUP(TCTYPE_find_type(typename, NULL, &type_tag))

    CLEANUP(AOM_is_type_of(obj_tag, type_tag, answer))

CLEANUP:
    return ifail;
}

// Handle missing required argument value for custom functions. This throws an error!
int FV_handle_missing_arg_error(const char* functionName, char* argumentName)
{
	int ifail=-1;
	TC_write_syslog("ERROR: In %s, required argument %s is NULL\n", functionName, argumentName);
    return ifail;
}


int fv_strdup(const char* inputString, char** outputString)
{
   int   ifail = ITK_ok;
   char* function_name = "fv_strdup";
   char  intCharBuf[FV_INTEGER_LEN+1] = {'\0'};

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   *outputString = MEM_alloc((int)(sizeof(char)*(tc_strlen(inputString)+1)));

   if (*outputString != NULL)
   {
      tc_strcpy(*outputString, inputString);
   }
   else
   {
      sprintf(intCharBuf, "%d",  sizeof(char)*(tc_strlen(inputString)+1));
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, intCharBuf, function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}


/*
function to get the length before , after of dot in string
*/

int FVE_get_precision(char *str, int *lengthBeforeDot,int *lengthAfterDot)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_get_precision";

	int		len					=	0;
	int     lenAfterDot			=	0;
	int     lenBeforeDot		=	0;
	int		index				=	0;
	char    line[10000]			=	"";
	char    lineBeforeDot[10000]	=	"";
	char	*indexOfDot			=	NULL;


	TC_write_syslog("\n Enter %s\n", function_name);

	/* Get the index of first occurance of dot*/
	indexOfDot = strchr(str,'.');
	if(indexOfDot != NULL && tc_strlen(indexOfDot) > 0)
	{
		//get the length before dot
		index=(int)(indexOfDot - str);
		sprintf(lineBeforeDot,"%.*s",(index)-0,&str[0]);
		if(lineBeforeDot != NULL && strlen(lineBeforeDot) > 0)
		{
			lenBeforeDot= (int)tc_strlen(lineBeforeDot);
			*lengthBeforeDot=lenBeforeDot;
		}else
		{
			*lengthBeforeDot=lenBeforeDot;
		}

		//get the length after dot
		len=(int)tc_strlen(str);
		sprintf(line,"%.*s",len-(index+1),&str[index+1]);
		if(line != NULL && strlen(line) > 0)
		{
			lenAfterDot= (int)tc_strlen(line);
			*lengthAfterDot=lenAfterDot;
		}else
		{
			*lengthAfterDot=lenAfterDot;
		}
	}else
	{
		*lengthBeforeDot=lenBeforeDot;
		*lengthAfterDot=lenAfterDot;

	}
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;
}

void FVE_MemFreeStructConfigFile(struct FVEConfigFileInfostruct *configInfoStruct)
{

	TC_write_syslog("Start of FVE_MemFreeStructConfigFile \n");
	FVE_FREE(configInfoStruct->constantName);
	FVE_FREE(configInfoStruct->csvFileDelim);
	FVE_FREE(configInfoStruct->lofFileName);
	FVE_FREE(configInfoStruct->logFileExt);
	FVE_FREE(configInfoStruct->logFilePath);
	FVE_FREE(configInfoStruct->tolerance);
	FVE_FREE(configInfoStruct);

	TC_write_syslog("End of FVE_MemFreeStructConfigFile \n");
}

void FVE_initialize_ConfigFiletructure(struct FVEConfigFileInfostruct * configInfoStruct)
{
	TC_write_syslog("Start of FVE_initialize_ConfigFiletructure \n");
	configInfoStruct->constantName=NULL;
	configInfoStruct->csvFileDelim=NULL;
	configInfoStruct->lofFileName=NULL;
	configInfoStruct->logFileExt=NULL;
	configInfoStruct->logFilePath=NULL;
	configInfoStruct->tolerance=NULL;
	TC_write_syslog("End of FVE_initialize_ConfigFiletructure \n");
}

void FVE_MemFreeStructProcess(struct FVEProcessInfostruct *parmProcessStruct)
{
	TC_write_syslog("Start of FVE_MemFreeStructProcess \n");
	FVE_FREE(parmProcessStruct->processName);
	FVE_FREE(parmProcessStruct->processType);
	FVE_FREE(parmProcessStruct->featureName);
	FVE_FREE(parmProcessStruct->taskRate);
	FVE_FREE(parmProcessStruct);

	TC_write_syslog("End of FVE_MemFreeStructProcess \n");
}

void FVE_initialize_ProcessStructure(struct FVEProcessInfostruct * parmProcessStruct)
{
	TC_write_syslog("Start of FVE_initialize_ProcessStructure \n");
	parmProcessStruct->processName=NULL;
	parmProcessStruct->processType=NULL;
	parmProcessStruct->featureName=NULL;
	parmProcessStruct->taskRate=NULL;

	TC_write_syslog("End of FVE_initialize_ProcessStructure \n");
}


void FVE_initialize_ParmStructure(struct FVEParmDefInfostruct * parmReportStruct)
{
	TC_write_syslog("Start of FVE_initialize_ParmStructure \n");

	parmReportStruct->name=NULL;
	parmReportStruct->type=NULL;
	parmReportStruct->descr=NULL;
	parmReportStruct->paraUsage=NULL;
	parmReportStruct->paraType=NULL;
	parmReportStruct->engUnit=NULL;
	parmReportStruct->msaUnit=NULL;
    parmReportStruct->numerator=NULL;
	parmReportStruct->denominator=NULL;
	parmReportStruct->precision=NULL;
	parmReportStruct->tolerance=NULL;
	parmReportStruct->structureOfData=NULL;
	parmReportStruct->rowLabels=NULL;
	parmReportStruct->colLabels=NULL;
	parmReportStruct->minVal=NULL;
	parmReportStruct->initVal=NULL;
	parmReportStruct->maxVal=NULL;
	parmReportStruct->validValues=NULL;
	parmReportStruct->implDataType=NULL;
	parmReportStruct->implResolution=NULL;
	parmReportStruct->src=NULL;
	parmReportStruct->snk=NULL;
	parmReportStruct->local=NULL;
	parmReportStruct->srcSnk=NULL;
	parmReportStruct->faultVal=NULL;
	parmReportStruct->restricted=NULL;
	parmReportStruct->inhaleExhale=NULL;
	parmReportStruct->asBuiltVehOp=NULL;
	parmReportStruct->moduleManf=NULL;
	parmReportStruct->fcsdCustPref=NULL;
	parmReportStruct->configGrp=NULL;
    parmReportStruct->domainElName=NULL;
	parmReportStruct->domainElVal=NULL;
	parmReportStruct->domainElDescr=NULL;
	parmReportStruct->groupName=NULL;
	parmReportStruct->rowCnt=0;
	parmReportStruct->colCnt=0;
	parmReportStruct->size=NULL;
	parmReportStruct->overWritable=FALSE;
	parmReportStruct->typeOfData=NULL;
	parmReportStruct->offset=NULL;
	TC_write_syslog("End of FVE_initialize_ParmStructure \n");
}
void FVE_MemFreeStructParameter(struct FVEParmDefInfostruct * parmReportStruct)
{

	TC_write_syslog("Start of FVE_MemFreeStructParameter \n");
	FVE_FREE(parmReportStruct->name);
	FVE_FREE(parmReportStruct->type);
 	FVE_FREE(parmReportStruct->descr);
	FVE_FREE(parmReportStruct->paraUsage);
	FVE_FREE(parmReportStruct->paraType);
	FVE_FREE(parmReportStruct->engUnit);
	FVE_FREE(parmReportStruct->msaUnit);
    FVE_FREE(parmReportStruct->numerator);
	FVE_FREE(parmReportStruct->denominator);
	FVE_FREE(parmReportStruct->precision);
	FVE_FREE(parmReportStruct->tolerance);
	FVE_FREE(parmReportStruct->structureOfData);
	FVE_FREE(parmReportStruct->rowLabels);
	FVE_FREE(parmReportStruct->colLabels);
	FVE_FREE(parmReportStruct->minVal);
	FVE_FREE(parmReportStruct->initVal);
    FVE_FREE(parmReportStruct->maxVal);
	FVE_FREE(parmReportStruct->validValues);
	FVE_FREE(parmReportStruct->implDataType);
	FVE_FREE(parmReportStruct->implResolution);
	FVE_FREE(parmReportStruct->src);
	FVE_FREE(parmReportStruct->snk);
	FVE_FREE(parmReportStruct->local);
	FVE_FREE(parmReportStruct->srcSnk);
	FVE_FREE(parmReportStruct->faultVal);
    FVE_FREE(parmReportStruct->restricted);
	FVE_FREE(parmReportStruct->inhaleExhale);
	FVE_FREE(parmReportStruct->asBuiltVehOp);
	FVE_FREE(parmReportStruct->moduleManf);
	FVE_FREE(parmReportStruct->fcsdCustPref);
	FVE_FREE(parmReportStruct->configGrp);
    FVE_FREE(parmReportStruct->domainElName);
	FVE_FREE(parmReportStruct->domainElVal);
	FVE_FREE(parmReportStruct->domainElDescr);
	FVE_FREE(parmReportStruct->groupName);
	FVE_FREE(parmReportStruct->size);
	FVE_FREE(parmReportStruct->typeOfData);
	FVE_FREE(parmReportStruct->offset);
	FVE_FREE(parmReportStruct);
	TC_write_syslog("End of FVE_MemFreeStructParameter \n");

 }


/*
	Create Parameter Definitions of type Sed
	Default values
		ItemId
		RevId
		Name
		Ecu Acronym
		Parameter Usage
		Rows
		Valid Values
		Initial Value

	For SED columns will be fixed : 1
	Rows will be determined based on the values exist for domain element name.
	Parse the value for domain element name , get the number of rows.

	for valid values : domain element name and domain element values will be used
	for initial values : initial value provided in csv file will be used.
	if initial value exist , it should match with the domain element values
	if didnt match , throw error "initial value didnt match , object can not be created"

*/
int FVE_create_parmSed(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_parmSed";
	tag_t		sedTag				=	NULLTAG;
	tag_t		revisionTag			=	NULLTAG;
    tag_t		sedTypeTag			=	NULLTAG;
    tag_t		sedRevTypeTag		=	NULLTAG;
	tag_t		createInputTag		=	NULLTAG;
    tag_t		createRevInputTag	=	NULLTAG;

	tag_t		tableTypeTag		=	NULLTAG;
	tag_t		tableDefTypeTag		=	NULLTAG;
    tag_t		tableDefInputTag	=	NULLTAG;

	char		* rowCountTable		=	NULL;
	char		* colCountTable		=	NULL;
	char		* rowNumber         =   NULL;
	char		* colNumber         =   NULL;
	char		*revTypeName		=	NULL;

	int			rows				=	0;
	int			columns				=	0;
	int			iCounter			=	0;
	int			jCounter			=	0;

	tag_t	tableInputTagValidValue	=	NULLTAG;
	tag_t	tableCellTypeTag		=	NULLTAG;
	tag_t	tableCellInputTagValidValue	= NULLTAG;

	char       intRowBuf[FV_INTEGER_LEN+1] = {'\0'};
	char       intColBuf[FV_INTEGER_LEN+1] = {'\0'};

	tag_t*      cellInputTags		=	NULL;
	int         cellCnt				=	0;

	char		*objName[]			=	{""};
	char		*objDesc[]			=	{""};
    char		*usage[]			=	{""};
    char		*ecuacr[]			=	{""};
	char		*parType[]			=	{""};
	char		*initVal[]			=	{""};
	char		*domainElVal[]		=	{""};

	int			cntDomainElName		=	0;
	char		**valDomainElName	=	NULL;
	int			cntDomainElVal		=	0;
	char		**valDomainElVal	=	NULL;
	int			cntDomainElDescr	=	0;
	char		**valDomainElDescr	=	NULL;

    // Nikhil Patil change starts.

    // Length of domainElDescr string.
    int         valDomainElDescr_Length    =   0;

    // Nikhil Patil change ends.

	logical		lgDomainElName		=	false;
	logical		lgDomainElValue		=	false;
	logical		lgInitValMatchFound	=	false;
	logical		lgDomainElDescr		=	false;
	int			indexCounter		=	0;
	char		*trimDomainElName	=	NULL;
	char		*trimInitValue		=	NULL;
	char		*trimDomainElValue	=	NULL;

    int         iDomainElNameIndex =   0;

	TC_write_syslog("\n Enter function %s",function_name);

	*objName	=	parmInfoStruct[counter].name;
	*objDesc	=	parmInfoStruct[counter].descr;
	*usage		=	parmInfoStruct[counter].paraUsage;
	*ecuacr		=	ecuAcronym;
	if(parmInfoStruct[counter].paraType && tc_strlen(parmInfoStruct[counter].paraType)> 0)
	{
		*parType=parmInfoStruct[counter].paraType;
	}else
	{
		*parType=PARAMETER_TYPE_DEFAULT_VAL;
	}

	*initVal	=	 parmInfoStruct[counter].initVal;

	//default value
	columns=1;

	//check for domain element name
	if( (parmInfoStruct[counter].domainElName != NULL) && (tc_strlen(parmInfoStruct[counter].domainElName )> 0))
	{
		//get the rows
		split_the_string(parmInfoStruct[counter].domainElName,COMMA_DELIM,&cntDomainElName,&valDomainElName);
		if((cntDomainElName > 0) && (valDomainElName != NULL))
		{
			lgDomainElName=true;
			rows=cntDomainElName;
		}

        // Nikhil Patil changes starts
        /*
        Remove leading and trailing spaces from domain element name.
        */
        for( iDomainElNameIndex = 0; iDomainElNameIndex < cntDomainElName; iDomainElNameIndex++)
        {
            valDomainElName[iDomainElNameIndex] = 
                FV_trim_blanks(valDomainElName[iDomainElNameIndex]);
        }



        // Nikhil Patil changes ends.
	}

	//check for domain element values
	if( (parmInfoStruct[counter].domainElVal != NULL) && (tc_strlen(parmInfoStruct[counter].domainElVal )> 0))
	{
		//get the valid values
		split_the_string(parmInfoStruct[counter].domainElVal,COMMA_DELIM,&cntDomainElVal,&valDomainElVal);
		if((cntDomainElVal > 0) && (valDomainElVal != NULL))
		{
			lgDomainElValue=true;
		}


        // Nikhil Patil changes starts
        /*
        Remove leading and trailing spaces from domain element value.
        */
        for( iDomainElNameIndex = 0; iDomainElNameIndex < cntDomainElName; iDomainElNameIndex++)
        {
            valDomainElVal[iDomainElNameIndex] = 
                FV_trim_blanks(valDomainElVal[iDomainElNameIndex]);
        }



        // Nikhil Patil changes ends.
	}
	//check for domain element descr
	if( (parmInfoStruct[counter].domainElDescr) && (tc_strlen(parmInfoStruct[counter].domainElDescr )> 0))
	{
		//get the valid values
		/*split_the_string(parmInfoStruct[counter].domainElDescr,COMMA_DELIM,&cntDomainElDescr,&valDomainElDescr);*/
		// Use strstr-based function to parse value string with full delimiter string. 
        ifail=FV_parse_string_with_string(parmInfoStruct[counter].domainElDescr, CSV_DOMAINDESCR_DELIMITER, &cntDomainElDescr, &valDomainElDescr);
		if((cntDomainElDescr > 0) && (valDomainElDescr))
		{
			lgDomainElDescr=true;
		}	
	}

	//check for initial value
	if( (parmInfoStruct[counter].initVal != NULL) && (tc_strlen(parmInfoStruct[counter].initVal )> 0))
	{
		ifail=FVE_remove_invalidChars(parmInfoStruct[counter].initVal,&trimInitValue);
		//check if initial value exist in domain element values
		if((lgDomainElValue == true) && (cntDomainElVal > 0) && (valDomainElVal != NULL) )
		{
			if((lgDomainElName == true) && (cntDomainElName > 0) && (valDomainElName != NULL))
			{
				for(indexCounter =0; indexCounter<cntDomainElName ; indexCounter++)
				{
					ifail=FVE_remove_invalidChars(valDomainElName[indexCounter],&trimDomainElName);
					if(trimInitValue && trimDomainElName && tc_strlen(trimDomainElName)> 0 && tc_strlen(trimInitValue)> 0)
					{
						if( stricmp(trimInitValue,trimDomainElName) == 0)
						{
							lgInitValMatchFound=true;
							*domainElVal	=valDomainElVal[indexCounter];
							break;
						}
					}
					FVE_FREE(trimDomainElName)
				}//for
			}//lgDomainElName
		}//lgDomainElValue
		FVE_FREE(trimInitValue)
	}//initial value

	TC_write_syslog("Creating item input object %s\n",parmInfoStruct[counter].name);
	// create item
    ITK(TCTYPE_ask_type(parmInfoStruct[counter].type, &sedTypeTag))
    ITK(TCTYPE_construct_create_input(sedTypeTag, &createInputTag))

	// create item revision
	ITK(FV_strdup_plus(parmInfoStruct[counter].type, 9, &revTypeName))
    tc_strcat(revTypeName, "Revision");
    ITK(TCTYPE_ask_type(revTypeName, &sedRevTypeTag))
    ITK(TCTYPE_construct_create_input(sedRevTypeTag, &createRevInputTag))

    // set revision
    ITK(TCTYPE_set_compound_objects(createInputTag, "revision", 1, &createRevInputTag))

    //TC_write_syslog("Setting item attributes\n");
    // set item attribute
    ITK(TCTYPE_set_create_display_value(createInputTag, object_namePROP, 1, (const char**)objName))
	if(*objDesc && tc_strlen(*objDesc)> 0)
	{
		if(tc_strlen(*objDesc) <=240)
			ITK(TCTYPE_set_create_display_value(createInputTag, object_descPROP, 1, (const char**)objDesc))
	}
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ParameterUsagePROP, 1, (const char**)usage))
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ECUAcronymPROP, 1, (const char**)ecuacr))
	ITK(TCTYPE_set_create_display_value(createInputTag, parmTypePROP, 1, (const char**)parType))


	//set revision attributes
	ITK(TCTYPE_set_create_display_value(createRevInputTag, "initialValue", 1, (const char**)domainElVal))

	//TC_write_syslog("Creating table def\n");
    // create table definition
    ITK(TCTYPE_ask_type("TableDefinition", &tableDefTypeTag))
    ITK(TCTYPE_construct_create_input(tableDefTypeTag, &tableDefInputTag))
	rowCountTable = (char*)MEM_alloc((int)(rows + 1) * sizeof(char));
	colCountTable = (char*)MEM_alloc((int)(columns + 1) * sizeof(char));
	sprintf(rowCountTable, "%d", rows);
	sprintf(colCountTable, "%d", columns);
    ITK(TCTYPE_set_create_display_value(tableDefInputTag, "rows", 1, (const char**)&rowCountTable))
	ITK(TCTYPE_set_create_display_value(tableDefInputTag, "cols", 1, (const char**)&colCountTable))
	//free memory
	FVE_FREE(rowCountTable)
	FVE_FREE(colCountTable)


	ITK(TCTYPE_ask_type("Table", &tableTypeTag))

	//set the valid values for table
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagValidValue))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n",rowNumber);
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n",colNumber);
			// create table cell
			ITK(TCTYPE_ask_type(TableCellSEDCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagValidValue))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagValidValue, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagValidValue, "col", 1, (const char **)&colNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagValidValue, "desc",1,(const char **)&valDomainElName[iCounter]))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagValidValue, "value",1,(const char **)&valDomainElVal[iCounter]))
			if(cntDomainElDescr > 0 &&  valDomainElDescr && tc_strlen(*valDomainElDescr) > 0)
			{
				if(valDomainElDescr[iCounter] && tc_strlen(valDomainElDescr[iCounter])> 0)
                {
                    // Nikhil Patil changes starts

                    /*  If domainElDescr length is more than 400 char,
                        truncate it to only 400 char.

                    */

                    valDomainElDescr_Length = tc_strlen( valDomainElDescr[iCounter] );

                    if( valDomainElDescr_Length >= 400)
                    {
                        (valDomainElDescr[iCounter])[399] = '\0';

                    }

                    // Nikhil Patil changes ends

                    ITK(TCTYPE_set_create_display_value(tableCellInputTagValidValue,
                                                        "fnd0DomainElementDesc",
                                                        1,
                                                        (const char **)&valDomainElDescr[iCounter]))
                }


			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagValidValue))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagValidValue, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
    ITK(TCTYPE_set_compound_objects(tableInputTagValidValue, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	cellCnt=0;


	TC_write_syslog("Setting item revision compound objects\n");
    //set compound properties
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "validValues",1, &tableInputTagValidValue))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "tableDefinition", 1, &tableDefInputTag))

	 //TC_write_syslog("Creating object\n");
    // create the object
	if(lgInitValMatchFound)
	{
		 ITK(TCTYPE_create_object(createInputTag, &sedTag))
		if(sedTag != NULLTAG)
		{
			ITK(AOM_save(sedTag))
			ITK(AOM_refresh(sedTag, false) )
			*parmDefItem=sedTag;
			// Get the new item revision tag.
			ITK(ITEM_ask_latest_rev(sedTag, &revisionTag))
			if(revisionTag != NULLTAG)
			{
				*parmDefRevision=revisionTag;
			}
		}
	}

	//free memory
	FVE_FREE(valDomainElName)
	cntDomainElName	=	0;
	FVE_FREE(valDomainElVal)
	cntDomainElVal = 0;
	FVE_FREE(valDomainElDescr)
	cntDomainElDescr = 0;

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;
}

/*
	Create Parameter Definitions of type String

*/
int FVE_create_parmStr(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_parmStr";
	tag_t		strTag				=	NULLTAG;
	tag_t		revisionTag			=	NULLTAG;
    tag_t		strTypeTag			=	NULLTAG;
    tag_t		strRevTypeTag		=	NULLTAG;
	tag_t		createInputTag		=	NULLTAG;
    tag_t		createRevInputTag	=	NULLTAG;

	tag_t		tableTypeTag		=	NULLTAG;
	tag_t		tableDefTypeTag		=	NULLTAG;
    tag_t		tableDefInputTag	=	NULLTAG;
	tag_t		tableLabelTypeTag	=	NULLTAG;
	tag_t		tableRowLabelInputTag	=	NULLTAG;
	tag_t		tableColLabelInputTag	=	NULLTAG;

	char		* rowCountTable		=	NULL;
	char		* colCountTable		=	NULL;
	char		* rowNumber              =   NULL;
	char		* colNumber              =   NULL;

	char		*revTypeName		=	NULL;
	int		rows			=	0;
	int		columns			=	0;
	int		iCounter=0;
	int		jCounter	=	0;

	tag_t	tableInputTagMin	=	NULLTAG;
	tag_t	tableInputTagMax	=	NULLTAG;
	tag_t	tableInputTagInitial=	NULLTAG;

	tag_t	tableCellTypeTag	=	NULLTAG;
	tag_t	tableCellInputTagMin	=	NULLTAG;
	tag_t	tableCellInputTagMax	=	NULLTAG;
	tag_t	tableCellInputTagInitial=	NULLTAG;

	char       intRowBuf[FV_INTEGER_LEN+1] = {'\0'};
	char       intColBuf[FV_INTEGER_LEN+1] = {'\0'};

	tag_t*      cellInputTags = NULL;
	int         cellCnt = 0;

	char	*objName[]			=	{""};
	char	*objDesc[]			=	{""};
	char	*engUnit[]			=	{""};
    char	*usage[]			=	{""};
    char	*ecuacr[]			=	{""};
	char	*parType[]			=	{""};


	char	* initVal[]		=	{""};
	char	* maxVal[]		=	{""};
	char	* minVal[]		=	{""};

	int		rowLabelCnt		=	0;
	char	**rowLabelNames	=	NULL;
	int		colLabelCnt		=	0;
	char	**colLabelNames	=	NULL;
	int     initValArrayCnt	=	0;
	char	**initValArray	=	NULL;
	int		dummyInitValArrayCnt	=	0;
	char	**dummyInitValArray		=	NULL;
	int     minValArrayCnt	=	0;
	char	**minValArray	=	NULL;
	int     dummyMinValArrayCnt	=	0;
	char	**dummyMinValArray	=	NULL;
	int     maxValArrayCnt	=	0;
	char	**maxValArray	=	NULL;
	int     dummyMaxValArrayCnt	=	0;
	char	**dummyMaxValArray	=	NULL;
	char	*commaDelimExist	=	NULL;
	char	*semiColonDelimExist	=	NULL;
	int			incrCounter =0;

	TC_write_syslog("\n Enter function %s",function_name);
	if(parmInfoStruct[counter].rowCnt != 0)
		rows=parmInfoStruct[counter].rowCnt;


	if(parmInfoStruct[counter].colCnt != 0)
		columns=parmInfoStruct[counter].colCnt;

	*objName			=	parmInfoStruct[counter].name;
	*objDesc=parmInfoStruct[counter].descr;
	*usage=parmInfoStruct[counter].paraUsage;
	*ecuacr	=ecuAcronym;
	if(parmInfoStruct[counter].paraType && tc_strlen(parmInfoStruct[counter].paraType)> 0)
	{
		*parType=parmInfoStruct[counter].paraType;
	}else
	{
		*parType=PARAMETER_TYPE_DEFAULT_VAL;
	}
	if(parmInfoStruct[counter].engUnit != NULL && tc_strlen(parmInfoStruct[counter].engUnit) > 0)
	{
		if(tc_strcmp(parmInfoStruct[counter].engUnit,UNITLESS_UNIT) == 0)
		{
			*engUnit=NONE_UNIT;
		}else
		{
			*engUnit=parmInfoStruct[counter].engUnit;
		}
	}/*else
	{
		*engUnit=NONE_UNIT;
	}
	*/
	if(parmInfoStruct[counter].structureOfData && tc_strlen(parmInfoStruct[counter].structureOfData)> 0)
	{
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array1DInfo) == 0)
		{
			//get the rowlables and columnLabels
		
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			
			//get the initial Values
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			if(parmInfoStruct[counter].typeOfData && tc_strlen(parmInfoStruct[counter].typeOfData)> 0 && tc_strcmp(parmInfoStruct[counter].typeOfData,PARM_TYPE_CHARACTER) == 0)
			{
				*initVal	=	 parmInfoStruct[counter].initVal;
				*maxVal		=	 parmInfoStruct[counter].maxVal;
				*minVal		=	 parmInfoStruct[counter].minVal;
			}else
			{
				commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
				if(commaDelimExist != NULL)
				{

					split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
				}else
				{
					split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
				}

				//get the min values
				if(parmInfoStruct[counter].minVal && tc_strlen(parmInfoStruct[counter].minVal)>0)
				{
					commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
					if(commaDelimExist != NULL)
					{
						split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
						commaDelimExist=NULL;
					}else
					{
						split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
					}
				}

				//get the max values
				if(parmInfoStruct[counter].maxVal && tc_strlen(parmInfoStruct[counter].maxVal)>0)
				{
					commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
					if(commaDelimExist != NULL)
					{
						split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
						commaDelimExist=NULL;
					}else
					{
						split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
					}
				}
			}
		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArray && dummyInitValArrayCnt> 0)
				{
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
						}
					}
				}
			}else
			{
				//if didnt contains semicolon , its mean its single value
				*initVal	=	 parmInfoStruct[counter].initVal;
			}
			
			//check if semicolon exist in maximum value string
			if(parmInfoStruct[counter].maxVal && tc_strlen(parmInfoStruct[counter].maxVal)>0)
			{
				semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
				if(semiColonDelimExist)
				{
					split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
					semiColonDelimExist=NULL;
					if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
					{
						//store this info in maxValArrayCnt,maxValArray
						for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
								commaDelimExist=NULL;

							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
							}
						}
					}

				}else
				{
					*maxVal	=	parmInfoStruct[counter].maxVal;
				}
			}

			//check if semicolon exist in minimum value string
			if(parmInfoStruct[counter].minVal && tc_strlen(parmInfoStruct[counter].minVal)> 0)
			{
				semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
				if(semiColonDelimExist)
				{
					split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
					semiColonDelimExist=NULL;
					//store this info in minValArrayCnt,minValArray
					if(dummyMinValArrayCnt > 0 && dummyMinValArray)
					{
						for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
							}
						}
					}
				}else
				{
					*minVal	=	parmInfoStruct[counter].minVal;
				}
			}
		}//array2dinfo
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}
			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArray && dummyInitValArrayCnt> 0)
				{
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
						}
					}
				}
			}//semicolonexist

			//check if semicolon exist in maximum value string
			if(parmInfoStruct[counter].maxVal && tc_strlen(parmInfoStruct[counter].maxVal)> 0)
			{
				semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
				if(semiColonDelimExist)
				{
					split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
					semiColonDelimExist=NULL;
					if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
					{
						//store this info in maxValArrayCnt,maxValArray
						for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
							}
						}
					}
				}
			}

			//check if semicolon exist in minimum value string
			if(parmInfoStruct[counter].minVal && tc_strlen(parmInfoStruct[counter].minVal)> 0)
			{
				semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
				if(semiColonDelimExist)
				{
					split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
					semiColonDelimExist=NULL;
					//store this info in minValArrayCnt,minValArray
					if(dummyMinValArrayCnt > 0 && dummyMinValArray)
					{
						for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
							}
						}
					}
				}
			}
		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup1DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
			}

			//get the min values
			if(parmInfoStruct[counter].minVal && tc_strlen(parmInfoStruct[counter].minVal)> 0)
			{
				commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
				if(commaDelimExist != NULL)
				{
					split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
					commaDelimExist=NULL;
				}else
				{
					split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
				}
			}

			//get the max values
			if(parmInfoStruct[counter].maxVal && tc_strlen(parmInfoStruct[counter].maxVal)> 0)
			{
				commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
				if(commaDelimExist != NULL)
				{
					split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
					commaDelimExist=NULL;
				}else
				{
					split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
				}
			}
		}
	}
	TC_write_syslog("Creating item input object %s\n",parmInfoStruct[counter].name);
	// create item
    ITK(TCTYPE_ask_type(parmInfoStruct[counter].type, &strTypeTag))
    ITK(TCTYPE_construct_create_input(strTypeTag, &createInputTag))

	// create item revision
	ITK(FV_strdup_plus(parmInfoStruct[counter].type, 9, &revTypeName))
    tc_strcat(revTypeName, "Revision");
    ITK(TCTYPE_ask_type(revTypeName, &strRevTypeTag))
    ITK(TCTYPE_construct_create_input(strRevTypeTag, &createRevInputTag))

    // set revision
    ITK(TCTYPE_set_compound_objects(createInputTag, "revision", 1, &createRevInputTag))

    //TC_write_syslog("Setting item attributes\n");
    // set item attribute
    ITK(TCTYPE_set_create_display_value(createInputTag, object_namePROP, 1, (const char**)objName))
	if(*objDesc && tc_strlen(*objDesc)> 0)
	{
		if(tc_strlen(*objDesc) <=240)
			ITK(TCTYPE_set_create_display_value(createInputTag, object_descPROP, 1, (const char**)objDesc))
	}
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ParameterUsagePROP, 1, (const char**)usage))
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ECUAcronymPROP, 1, (const char**)ecuacr))
	ITK(TCTYPE_set_create_display_value(createInputTag, parmTypePROP, 1, (const char**)parType))

	//set Revision attributes
	if(*engUnit && tc_strlen(*engUnit)> 0)
	{
		ITK(TCTYPE_set_create_display_value(createRevInputTag, "FVE_EngUnit", 1, (const char**)engUnit ))
	}

	//TC_write_syslog("Creating table def\n");
    // create table definition
    ITK(TCTYPE_ask_type("TableDefinition", &tableDefTypeTag))
    ITK(TCTYPE_construct_create_input(tableDefTypeTag, &tableDefInputTag))
	rowCountTable = (char*)MEM_alloc((int)(rows + 1) * sizeof(char));
	colCountTable = (char*)MEM_alloc((int)(columns + 1) * sizeof(char));
	sprintf(rowCountTable, "%d", rows);
	sprintf(colCountTable, "%d", columns );
    ITK(TCTYPE_set_create_display_value(tableDefInputTag, "rows", 1, (const char**)&rowCountTable))
    ITK(TCTYPE_set_create_display_value(tableDefInputTag, "cols", 1, (const char**)&colCountTable))
	//free memory
	FVE_FREE(rowCountTable)
	FVE_FREE(colCountTable)

	/*set rowLabels and colLabels
		 create TableLabel definition */
		ITK(TCTYPE_ask_type("TableLabel", &tableLabelTypeTag))
		if(rowLabelNames && rowLabelCnt > 0 && rowLabelCnt==rows)
		{
			//set row labels
			for(iCounter=0;iCounter<rows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;
				//TC_write_syslog ("rowNumber = %s\n",rowNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableRowLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableRowLabelInputTag, "label", 1,(const char **)&rowLabelNames[iCounter]))
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableRowLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "rowLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		}

		 if(colLabelNames && colLabelCnt> 0 && colLabelCnt == columns)
		 {
			//set column labels
			for(iCounter=0;iCounter<columns;iCounter++)
			{
				sprintf(intColBuf, "%d",iCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n",colNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableColLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableColLabelInputTag, "label", 1,(const char **)&colLabelNames[iCounter]))
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableColLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "colLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		 }


	ITK(TCTYPE_ask_type("Table", &tableTypeTag))

	//set the maximum values for table
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMax))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n",rowNumber);
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n",colNumber);

			// create table cell
			ITK(TCTYPE_ask_type(TableCellStringCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMax))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "col", 1, (const char **)&colNumber))
			if(maxValArray && maxValArrayCnt == rows*columns)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[incrCounter]))
				incrCounter++;
			}else if(maxValArray && maxValArrayCnt == 1)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[0]))
			}else if(maxValArray == NULL)
			{
				if(*maxVal && tc_strlen(*maxVal)> 0)
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1, (const char**)maxVal))
			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMax))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagMax, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
	ITK(TCTYPE_set_compound_objects(tableInputTagMax, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	cellCnt=0;
	incrCounter=0;

	//Set the minimum values for a table
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMin))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n",rowNumber);
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n",colNumber);

			// create table cell
			ITK(TCTYPE_ask_type(TableCellStringCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMin))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "col", 1,(const char **)&colNumber))
			
			if(minValArray && minValArrayCnt == rows*columns)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[incrCounter]))
				incrCounter++;
			}else if(minValArray && minValArrayCnt ==1)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[0]))
			}else if(minValArray == NULL)
			{
				if(*minVal && tc_strlen(*minVal)> 0)
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1, (const char**)minVal))
			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMin))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagMin, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
	ITK(TCTYPE_set_compound_objects(tableInputTagMin, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	cellCnt=0;
	incrCounter=0;

	
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagInitial))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",  iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n", rowNumber );
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n", colNumber);
			// create table cell
			ITK(TCTYPE_ask_type(TableCellStringCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagInitial))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "col", 1,(const char **)&colNumber))
			if(initValArray && initValArrayCnt == rows*columns)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[incrCounter]))
				incrCounter++;
			}
			else if(initValArray && initValArrayCnt == 1)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[0]))
			}else if(initValArray == NULL)
			{
				if(*initVal && tc_strlen(*initVal)> 0)
					ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1, (const char**)initVal))
			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagInitial))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
	ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	

	TC_write_syslog("Setting item revision compound objects\n");
    //set revision attribute
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "initialValues", 1, &tableInputTagInitial))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "minValues",1, &tableInputTagMin))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "maxValues", 1, &tableInputTagMax))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "tableDefinition", 1, &tableDefInputTag))

	 //TC_write_syslog("Creating object\n");
    // create the object

    ITK(TCTYPE_create_object(createInputTag, &strTag))
	if(strTag)
	{
		ITK(AOM_save(strTag))
		ITK(AOM_refresh(strTag, false) )
		*parmDefItem=strTag;

		// Get the new item revision tag.
		ITK(ITEM_ask_latest_rev(strTag, &revisionTag))
		if(revisionTag != NULLTAG)
		{
			*parmDefRevision=revisionTag;
		}
	}

	//free memory
	FVE_FREE_ARRAY(rowLabelNames,rowLabelCnt);
	rowLabelCnt=0;
	FVE_FREE_ARRAY(colLabelNames,colLabelCnt);
	colLabelCnt=0;
	FVE_FREE_ARRAY(initValArray,initValArrayCnt)
	initValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyInitValArray,dummyInitValArrayCnt)
	dummyInitValArrayCnt=0;
	
	FVE_FREE_ARRAY(minValArray,minValArrayCnt)
	minValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyMinValArray,dummyMinValArrayCnt)
	dummyMinValArrayCnt	=	0;

	FVE_FREE_ARRAY(maxValArray,maxValArrayCnt);
	maxValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyMaxValArray,dummyMaxValArrayCnt)
	dummyMaxValArrayCnt	=	0;

	TC_write_syslog("\n Leaving function %s",function_name);
	return ifail;

}

/*
	Create Parameter Definitions of type Hex
	For this case, always set “N/A” as value for EngUnit attribute
	Currently for Hex type , 
	exception is irrespective of structure of data , row labels and column labels exist.
	if labels exist , Need to set in any case.
*/
int FVE_create_parmHex(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_parmHex";
	tag_t		hexTag				=	NULLTAG;
	tag_t		revisionTag			= NULLTAG;
    tag_t		hexTypeTag			=	NULLTAG;
    tag_t		hexRevTypeTag		=	NULLTAG;
	tag_t		createInputTag		=	NULLTAG;
    tag_t		createRevInputTag	=	NULLTAG;

	tag_t		tableTypeTag		=	NULLTAG;
	tag_t		tableDefTypeTag		=	NULLTAG;
    tag_t		tableDefInputTag	=	NULLTAG;
	tag_t		tableLabelTypeTag	=	NULLTAG;
	tag_t		tableRowLabelInputTag	=	NULLTAG;
	tag_t		tableColLabelInputTag	=	NULLTAG;


	char		* rowCountTable		=	NULL;
	char		* colCountTable		=	NULL;
	char		* rowNumber              =   NULL;
	char		* colNumber              =   NULL;

	char		*revTypeName		=	NULL;
	int			rows			=	0;
	int			columns			=	0;
	int			iCounter=0;
	int			jCounter	=	0;

	tag_t	tableInputTagMin	=	NULLTAG;
	tag_t	tableInputTagMax	=	NULLTAG;
	tag_t	tableInputTagInitial=	NULLTAG;

	tag_t	tableCellTypeTag	=	NULLTAG;
	tag_t	tableCellInputTagMin	=	NULLTAG;
	tag_t	tableCellInputTagMax	=	NULLTAG;
	tag_t	tableCellInputTagInitial=	NULLTAG;

	char       intRowBuf[FV_INTEGER_LEN+1] = {'\0'};
	char       intColBuf[FV_INTEGER_LEN+1] = {'\0'};

	tag_t*      cellInputTags = NULL;
	int         cellCnt = 0;

	//default values
	char	*objName[]			=	{""};
	char	*objDesc[]			=	{""};
	char	*engUnit[]			=	{""};
    char	*usage[]			=	{""};
    char	*ecuacr[]			=	{""};
	char	*parType[]			=	{""};

	char	* initVal[]		=	{""};
	char	* maxVal[]		=	{""};
	char	* minVal[]		=	{""};

    // Strint to hold max val if it has starts with 0x'
    char*   pcMaxVal_Hex    =   NULL;

    // Strint to hold max val if it has starts with 0x'
    char*   pcMinVal_Hex    =   NULL;


	int		minimumVal		=	0;
	int		maximumVal		=	0;
	int		initialVal		=	0;

	int		rowLabelCnt		=	0;
	char	**rowLabelNames	=	NULL;
	int		colLabelCnt		=	0;
	char	**colLabelNames	=	NULL;
	int     initValArrayCnt	=	0;
	char	**initValArray	=	NULL;
	int		dummyInitValArrayCnt	=	0;
	char	**dummyInitValArray		=	NULL;
	int     minValArrayCnt	=	0;
	char	**minValArray	=	NULL;
	int     dummyMinValArrayCnt	=	0;
	char	**dummyMinValArray	=	NULL;
	int     maxValArrayCnt	=	0;
	char	**maxValArray	=	NULL;
	int     dummyMaxValArrayCnt	=	0;
	char	**dummyMaxValArray	=	NULL;
	char	*commaDelimExist	=	NULL;
	char	*semiColonDelimExist	=	NULL;
	int		incrCounter =0;
	char	*valueSubstring			=	NULL;
	int		index					=0;
	 char*       indexOfX      = NULL;

	TC_write_syslog("\n Enter function %s",function_name);
	if(parmInfoStruct[counter].rowCnt != 0)
		rows=parmInfoStruct[counter].rowCnt;


	if(parmInfoStruct[counter].colCnt != 0)
		columns=parmInfoStruct[counter].colCnt;

	*objName			=	parmInfoStruct[counter].name;
	*objDesc=parmInfoStruct[counter].descr;
	*usage=parmInfoStruct[counter].paraUsage;
	*ecuacr	=ecuAcronym;
	if(parmInfoStruct[counter].paraType && tc_strlen(parmInfoStruct[counter].paraType)> 0)
	{
		*parType=parmInfoStruct[counter].paraType;
	}else
	{
		*parType=PARAMETER_TYPE_DEFAULT_VAL;
	}
	if(parmInfoStruct[counter].engUnit != NULL && tc_strlen(parmInfoStruct[counter].engUnit) > 0)
	{
		if(tc_strcmp(parmInfoStruct[counter].engUnit,UNITLESS_UNIT) == 0)
		{
			*engUnit=NONE_UNIT;
		}else
		{
			*engUnit=parmInfoStruct[counter].engUnit;
		}
	}else
	{
		*engUnit=NAUNIT;
	}

	if(parmInfoStruct[counter].structureOfData && tc_strlen(parmInfoStruct[counter].structureOfData)> 0)
	{
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,ScalarInfo) == 0)
		{
			*initVal	=	 parmInfoStruct[counter].initVal;
			*maxVal		=	 parmInfoStruct[counter].maxVal;
			*minVal		=	 parmInfoStruct[counter].minVal;

			minimumVal	=	atoi(parmInfoStruct[counter].minVal);
			maximumVal	=	atoi(parmInfoStruct[counter].maxVal);
			initialVal	=	atoi(parmInfoStruct[counter].initVal);
			TC_write_syslog ("initialVal = %d\n", initialVal);
			
		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArray && dummyInitValArrayCnt> 0)
				{
				    TC_write_syslog ("in 2DLookupInfo, dummyInitValArrayCnt = %d\n", dummyInitValArrayCnt );
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
						}
					}
				}
			}else
			{
				*initVal	=	 parmInfoStruct[counter].initVal;
			}

			//check if semicolon exist in maximum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
			if(semiColonDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
				semiColonDelimExist=NULL;
				if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
				{
					//store this info in maxValArrayCnt,maxValArray
					for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
							commaDelimExist=NULL;

						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
						}
					}
				}
			}else
			{
				*maxVal	=	 parmInfoStruct[counter].maxVal;
			}


			//check if semicolon exist in minimum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
			if(semiColonDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
				semiColonDelimExist=NULL;
				//store this info in minValArrayCnt,minValArray
				if(dummyMinValArrayCnt > 0 && dummyMinValArray)
				{
					for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
						}
					}
				}
			}else
			{
				*minVal	=	 parmInfoStruct[counter].minVal;
			}
		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}
			//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArray && dummyInitValArrayCnt> 0)
				{
				    TC_write_syslog ("In Array2DInfo, dummyInitValArray > 0\n" );
					TC_write_syslog ("dummyInitValArrayCnt = %d\n", dummyInitValArrayCnt );
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
						}
					}
				}
			}else
			{
				*initVal	=	 parmInfoStruct[counter].initVal;
			}

			//check if semicolon exist in maximum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
			if(semiColonDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
				semiColonDelimExist=NULL;
				if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
				{
					//store this info in maxValArrayCnt,maxValArray
					for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
							commaDelimExist=NULL;

						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
						}
					}
				}
			}else
			{
				*maxVal	=	 parmInfoStruct[counter].maxVal;
			}

			//check if semicolon exist in minimum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
			if(semiColonDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
				semiColonDelimExist=NULL;
				//store this info in minValArrayCnt,minValArray
				if(dummyMinValArrayCnt > 0 && dummyMinValArray)
				{
					for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
						}
					}
				}
			}else
			{
				*minVal	=	 parmInfoStruct[counter].minVal;
			}

		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup1DInfo) == 0)
		{
			//get the row lables
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//get the initial Values
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
			}
			
			TC_write_syslog ("In Lookup1DInfo, initValArray = %d\n", initValArray );

			//get the min values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
			}

			//get the max values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
			}

		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array1DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}
			//get the initial Values
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
			}

			TC_write_syslog ("In Array1DInfo, initValArrayCnt = %d\n", initValArrayCnt );
			//get the min values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
			}

			//get the max values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
			}
		}
	}
	
	//function to check if value is with prefix "0x" , remove it from the value and store it in array

	TC_write_syslog("Creating item input object %s\n",parmInfoStruct[counter].name);
	// create item
    ITK(TCTYPE_ask_type(parmInfoStruct[counter].type, &hexTypeTag))
    ITK(TCTYPE_construct_create_input(hexTypeTag, &createInputTag))

	// create item revision
	ITK(FV_strdup_plus(parmInfoStruct[counter].type, 9, &revTypeName))
    tc_strcat(revTypeName, "Revision");
	
	TC_write_syslog ("revTypeName = %s\n", revTypeName );
    ITK(TCTYPE_ask_type(revTypeName, &hexRevTypeTag))
    ITK(TCTYPE_construct_create_input(hexRevTypeTag, &createRevInputTag))

    // set revision
    ITK(TCTYPE_set_compound_objects(createInputTag, "revision", 1, &createRevInputTag))

    //TC_write_syslog("Setting item attributes\n");
    // set item attribute
    ITK(TCTYPE_set_create_display_value(createInputTag, object_namePROP, 1, (const char**)objName))
	if(*objDesc && tc_strlen(*objDesc)> 0)
	{
		if(tc_strlen(*objDesc) <=240)
			ITK(TCTYPE_set_create_display_value(createInputTag, object_descPROP, 1, (const char**)objDesc))
	}
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ParameterUsagePROP, 1, (const char**)usage))
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ECUAcronymPROP, 1, (const char**)ecuacr))
	ITK(TCTYPE_set_create_display_value(createInputTag, parmTypePROP, 1, (const char**)parType))

	//set Revision attributes
	ITK(TCTYPE_set_create_display_value(createRevInputTag, "FVE_EngUnit", 1, (const char**)engUnit ))

	//TC_write_syslog("Creating table def\n");
    // create table definition
    ITK(TCTYPE_ask_type("TableDefinition", &tableDefTypeTag))
    ITK(TCTYPE_construct_create_input(tableDefTypeTag, &tableDefInputTag))
	rowCountTable = (char*)MEM_alloc((int)(rows + 1) * sizeof(char));
	colCountTable = (char*)MEM_alloc((int)(columns + 1) * sizeof(char));
	sprintf(rowCountTable, "%d", rows);
	sprintf(colCountTable, "%d", columns );
    ITK(TCTYPE_set_create_display_value(tableDefInputTag, "rows", 1, (const char**)&rowCountTable))
    ITK(TCTYPE_set_create_display_value(tableDefInputTag, "cols", 1, (const char**)&colCountTable))
	//free memory
	FVE_FREE(rowCountTable)
	FVE_FREE(colCountTable)

	/*set rowLabels and colLabels
		 create TableLabel definition */
		ITK(TCTYPE_ask_type("TableLabel", &tableLabelTypeTag))
		if(rowLabelNames && rowLabelCnt > 0 && rowLabelCnt==rows)
		{
			//set row labels
			for(iCounter=0;iCounter<rows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;
				//TC_write_syslog ("rowNumber = %s\n",rowNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableRowLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableRowLabelInputTag, "label", 1,(const char **)&rowLabelNames[iCounter]))
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableRowLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "rowLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		}

		 if(colLabelNames && colLabelCnt> 0 && colLabelCnt == columns)
		 {
			//set column labels
			for(iCounter=0;iCounter<columns;iCounter++)
			{
				sprintf(intColBuf, "%d",iCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n",colNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableColLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableColLabelInputTag, "label", 1,(const char **)&colLabelNames[iCounter]))
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableColLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "colLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		 }


	ITK(TCTYPE_ask_type("Table", &tableTypeTag))

	//set the maximum values for table
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMax))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n",rowNumber);
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n",colNumber);

			// create table cell
			ITK(TCTYPE_ask_type(TableCellHexCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMax))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "col", 1, (const char **)&colNumber))
			if(maxValArray != NULL && maxValArrayCnt == rows*columns)
			{
                if(maxValArray[incrCounter]  && tc_strlen(maxValArray[incrCounter])> 0)
                {
                    indexOfX = NULL;
                    indexOfX = strchr(maxValArray[incrCounter],'x');
                    if(indexOfX != NULL)
                    {
                        index = (int)(indexOfX - maxValArray[incrCounter]);
                        valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(maxValArray[incrCounter])+1));
                        //sprintf(valueSubstring,"%d%s",strlen(initValArray[incrCounter])-(index+1),&(initValArray[incrCounter])[index+1]);
                        sprintf(valueSubstring,"%s",&(maxValArray[incrCounter])[index+1]);
                        if(valueSubstring != NULL)
                        {
                            TC_write_syslog ("+++++ valueSubstring = %s\n", valueSubstring );
                            
                            ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&valueSubstring))
                        }
                        FVE_FREE(valueSubstring)
                        index=0;
                        incrCounter++;
                    }
                    else
                    {
                        ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[incrCounter]))
                        incrCounter++;
                    }
                }
			}else if(maxValArray != NULL && maxValArrayCnt == 1)
			{
                indexOfX=NULL;
                indexOfX=strchr(maxValArray[0],'x');
                if(indexOfX != NULL)
                {
                    int     str_cnt = 0;
                    char**  splitted_strings = NULL;

                    TC_write_syslog("entered 0x\n");
                    /*
                    index = (int)(indexOfX - maxValArray[0]);
                    valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(maxValArray[0])+1));
                    sprintf(valueSubstring,"%d%s",strlen(maxValArray[0])-(index+1),&(maxValArray[0])[index+1]);
                    */
                    
                    ifail = split_the_string(maxValArray[0],
                                            "x",
                                            &str_cnt,
                                            &splitted_strings);

                    valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(splitted_strings[1])+1));
                    tc_strcpy(valueSubstring, splitted_strings[1]);

                    

                    //sprintf(valueSubstring,"%d%s",(maxValArray[0])[index+1]);
                    if(valueSubstring != NULL)
                    {
                        TC_write_syslog ("++++++== valueSubstring = %s\n", valueSubstring );
                        ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&valueSubstring))
                    }
                    FVE_FREE(valueSubstring)
                    index=0;
                }else
                {
                    ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[0]))
                }
			}else if(maxValArray == NULL)
			{
                // Nikhil Patil changes starts.
                /*  If max value starts with '0x',
                    truncate it and store remaining number on maxVal.
                */
                pcMaxVal_Hex = strchr(*maxVal, 'x');

                if( pcMaxVal_Hex != NULL )
                {
                    index = (int)(pcMaxVal_Hex - *maxVal);
                    valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen( *maxVal ) + 1));
                    sprintf(valueSubstring,"%s",&(*maxVal)[index+1]);
                    ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1, (const char**)&valueSubstring))
                }
                else
                {
                    ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1, (const char**)maxVal))
                }
                index = 0;
                FVE_FREE(valueSubstring);
                // Nikhil Patil changes ends.

			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMax))
		}
	}
    incrCounter = 0;
    index = 0;

	ITK(TCTYPE_set_compound_objects(tableInputTagMax, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
    ITK(TCTYPE_set_compound_objects(tableInputTagMax, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	cellCnt=0;
	incrCounter=0;

	//Set the minimum values for a table
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMin))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n",rowNumber);
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n",colNumber);

			// create table cell
			ITK(TCTYPE_ask_type(TableCellHexCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMin))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "col", 1,(const char **)&colNumber))
			if(minValArray != NULL && minValArrayCnt ==rows*columns)
			{
                if(minValArray[incrCounter]  && tc_strlen(minValArray[incrCounter])> 0)
				{				
					//check if value is with prefix "0x"
					indexOfX=NULL;
					indexOfX=strchr(minValArray[incrCounter],'x');
					if(indexOfX != NULL)
					{

						index = (int)(indexOfX - minValArray[incrCounter]);
						valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(minValArray[incrCounter])+1));
						//sprintf(valueSubstring,"%d%s",strlen(initValArray[incrCounter])-(index+1),&(initValArray[incrCounter])[index+1]);
						sprintf(valueSubstring,"%s",&(minValArray[incrCounter])[index+1]);
						if(valueSubstring != NULL)
						{
						    TC_write_syslog ("+++++ valueSubstring = %s\n", valueSubstring );
							
							ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&valueSubstring))
						}
						FVE_FREE(valueSubstring)
						index=0;
						incrCounter++;	
					}else
					{
						ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[incrCounter]))
						incrCounter++;	
					}
				}
			}else if(minValArray != NULL && minValArrayCnt ==1)
			{
                int     str_cnt = 0;
                char**  splitted_strings = NULL;

                indexOfX=NULL;
				indexOfX=strchr(minValArray[0],'x');
				if(indexOfX != NULL)
				{
				    TC_write_syslog("entered 0x\n");

                    /*
					index = (int)(indexOfX - minValArray[0]);
					valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(minValArray[0])+1));
					sprintf(valueSubstring,"%d%s",strlen(minValArray[0])-(index+1),&(minValArray[0])[index+1]);

                    */
                                        ifail = split_the_string(minValArray[0],
                                            "x",
                                            &str_cnt,
                                            &splitted_strings);

                    valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(splitted_strings[1])+1));
                    tc_strcpy(valueSubstring, splitted_strings[1]);

                    
					if(valueSubstring != NULL)
					{
						TC_write_syslog ("++++++== valueSubstring = %s\n", valueSubstring );
						ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&valueSubstring))
					}
					FVE_FREE(valueSubstring)
					index=0;
				}else
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[0]))
				}

			}else if(minValArray == NULL)
			{
                               // Nikhil Patil changes starts.
                /*  If max value starts with '0x',
                    truncate it and store remaining number on maxVal.
                */
                pcMinVal_Hex = strchr(*minVal, 'x');

                if( pcMinVal_Hex != NULL )
                {
                    index = (int)(pcMinVal_Hex - *minVal);
                    valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen( *minVal ) + 1));
                    sprintf(valueSubstring,"%s",&(*minVal)[index+1]);
                    ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1, (const char**)&valueSubstring))
                }
                else
                {
                    ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1, (const char**)minVal))
                }
                index = 0;
                FVE_FREE(valueSubstring);
                // Nikhil Patil changes ends.

			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMin))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagMin, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
    ITK(TCTYPE_set_compound_objects(tableInputTagMin, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	cellCnt=0;
	incrCounter=0;

	//initial Value
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagInitial))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",  iCounter);
   		rowNumber = intRowBuf;
		TC_write_syslog ("rowNumber = %s\n", rowNumber );
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			TC_write_syslog ("colNumber = %s\n", colNumber);
			 // create table cell
			ITK(TCTYPE_ask_type(TableCellHexCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagInitial))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "col", 1,(const char **)&colNumber))

			if(initValArray != NULL && initValArrayCnt == rows*columns)
			{
 				if(initValArray[incrCounter]  && tc_strlen(initValArray[incrCounter])> 0)
				{				
					//check if value is with prefix "0x"
					indexOfX=NULL;
					indexOfX=strchr(initValArray[incrCounter],'x');
					if(indexOfX != NULL)
					{
						index = (int)(indexOfX - initValArray[incrCounter]);
						valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(initValArray[incrCounter])+1));
						//sprintf(valueSubstring,"%d%s",strlen(initValArray[incrCounter])-(index+1),&(initValArray[incrCounter])[index+1]);
						sprintf(valueSubstring,"%s",&(initValArray[incrCounter])[index+1]);
						if(valueSubstring != NULL)
						{
						    TC_write_syslog ("+++++ valueSubstring = %s\n", valueSubstring );
							
							ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&valueSubstring))
						}
						FVE_FREE(valueSubstring)
						index=0;
						incrCounter++;	
					}else
					{
						ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[incrCounter]))
						incrCounter++;	
					}
				}
			}
			else if(initValArray != NULL && initValArrayCnt == 1)
			{
                 int     str_cnt = 0;
                 char**  splitted_strings = NULL;
				indexOfX=NULL;
				indexOfX=strchr(initValArray[0],'x');
				if(indexOfX != NULL)
				{
				    TC_write_syslog("entered 0x\n");

                    /*
					index = (int)(indexOfX - initValArray[0]);
					valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(initValArray[0])+1));
					sprintf(valueSubstring,"%d%s",strlen(initValArray[0])-(index+1),&(initValArray[0])[index+1]);

                    */
                     ifail = split_the_string(initValArray[0],
                                            "x",
                                            &str_cnt,
                                            &splitted_strings);

                    valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(splitted_strings[1])+1));
                    tc_strcpy(valueSubstring, splitted_strings[1]);

					if(valueSubstring != NULL)
					{
						TC_write_syslog ("++++++== valueSubstring = %s\n", valueSubstring );
						ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&valueSubstring))
					}
					FVE_FREE(valueSubstring)
					index=0;
				}else
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[0]))
				}
			}else if(initValArray == NULL)
			{
				indexOfX=NULL;
				indexOfX=strchr(*initVal,'x');
				if(indexOfX != NULL)
				{
					index = (int)(indexOfX - *initVal);
					valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(*initVal)+1));
					sprintf(valueSubstring,"%d%s",strlen(*initVal)-(index+1),&(*initVal)[index+1]);
					if(valueSubstring != NULL)
					{
					    TC_write_syslog ("====== valueSubstring = %s\n", valueSubstring );
						ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&valueSubstring))
					}
					FVE_FREE(valueSubstring)
					index=0;
				}else
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1, (const char**)initVal))
				}
				
			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagInitial))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
    ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)

	TC_write_syslog("Setting item revision compound objects\n");
    //set revision attribute
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "initialValues", 1, &tableInputTagInitial))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "minValues",1, &tableInputTagMin))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "maxValues", 1, &tableInputTagMax))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "tableDefinition", 1, &tableDefInputTag))

	 //TC_write_syslog("Creating object\n");
    // create the object

    ITK(TCTYPE_create_object(createInputTag, &hexTag))
	if(hexTag != NULLTAG)
	{
		ITK(AOM_save(hexTag))
		ITK(AOM_refresh(hexTag, false) )
		*parmDefItem=hexTag;

		// Get the new item revision tag.
		ITK(ITEM_ask_latest_rev(hexTag, &revisionTag))
		if(revisionTag != NULLTAG)
		{
			*parmDefRevision=revisionTag;
		}
	}

	//free memory
	FVE_FREE_ARRAY(rowLabelNames,rowLabelCnt);
	rowLabelCnt=0;
	FVE_FREE_ARRAY(colLabelNames,colLabelCnt);
	colLabelCnt=0;
	FVE_FREE_ARRAY(initValArray,initValArrayCnt)
	initValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyInitValArray,dummyInitValArrayCnt)
	dummyInitValArrayCnt=0;
	FVE_FREE_ARRAY(minValArray,minValArrayCnt)
	minValArrayCnt	=	0;

	FVE_FREE_ARRAY(dummyMinValArray,dummyMinValArrayCnt)
	dummyMinValArrayCnt	=	0;

	FVE_FREE_ARRAY(maxValArray,maxValArrayCnt);
	maxValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyMaxValArray,dummyMaxValArrayCnt)
	dummyMaxValArrayCnt	=	0;
	TC_write_syslog("\n Leaving function %s",function_name);
	return ifail;
}
/*
	Create Parameter Definitions of type Integer
	Default values
		if the Eng Unit is empty or "Unitless" we set it to "None"
		if rows , columns value is zero from csv file , rows=columns=1

*/
int FVE_create_parmInt(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision)
{

	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_parmInt";
	tag_t		intTag				=	NULLTAG;
	tag_t		revisionTag			= NULLTAG;
    tag_t		intTypeTag			=	NULLTAG;
    tag_t		intRevTypeTag		=	NULLTAG;
	tag_t		createInputTag		=	NULLTAG;
    tag_t		createRevInputTag	=	NULLTAG;

	tag_t		tableTypeTag		=	NULLTAG;
	tag_t		tableDefTypeTag		=	NULLTAG;
    tag_t		tableDefInputTag	=	NULLTAG;
	tag_t	tableLabelTypeTag	=	NULLTAG;
	tag_t	tableRowLabelInputTag	=	NULLTAG;
	tag_t	tableColLabelInputTag	=	NULLTAG;


	char		* rowCountTable		=	NULL;
	char		* colCountTable		=	NULL;
	char		* rowNumber              =   NULL;
	char		* colNumber              =   NULL;

	char		*revTypeName		=	NULL;
	int		rows			=	0;
	int		columns			=	0;
	int		iCounter=0;
	int		jCounter	=	0;

	tag_t	tableInputTagMin	=	NULLTAG;
	tag_t	tableInputTagMax	=	NULLTAG;
	tag_t	tableInputTagInitial=	NULLTAG;

	tag_t	tableCellTypeTag	=	NULLTAG;
	tag_t	tableCellInputTagMin	=	NULLTAG;
	tag_t	tableCellInputTagMax	=	NULLTAG;
	tag_t	tableCellInputTagInitial=	NULLTAG;

	char       intRowBuf[FV_INTEGER_LEN+1] = {'\0'};
	char       intColBuf[FV_INTEGER_LEN+1] = {'\0'};

	tag_t*      cellInputTags = NULL;
	int         cellCnt = 0;

	//default values
	//char	*issigned[]			=	{"False"};
	char	*issigned[]			=	{""};
	char	*objName[]			=	{""};
	char	*objDesc[]			=	{""};
	char	*engUnit[]			=	{""};
    char	*usage[]			=	{""};
    char	*ecuacr[]			=	{""};
	char	*parType[]			=	{""};

	char	*numarator[]		=	{""};
	char	*denominator[]		=	{""};

	char	* initVal[]		=	{""};
	char	* maxVal[]		=	{""};
	char	* minVal[]		=	{""};

	int		minimumVal		=	0;
	int		maximumVal		=	0;
	int		initialVal		=	0;

	int		rowLabelCnt		=	0;
	char	**rowLabelNames	=	NULL;
	int		colLabelCnt		=	0;
	char	**colLabelNames	=	NULL;
	int     initValArrayCnt	=	0;
	char	**initValArray	=	NULL;
	int		dummyInitValArrayCnt	=	0;
	char	**dummyInitValArray		=	NULL;
	int     minValArrayCnt	=	0;
	char	**minValArray	=	NULL;
	int     dummyMinValArrayCnt	=	0;
	char	**dummyMinValArray	=	NULL;
	int     maxValArrayCnt	=	0;
	char	**maxValArray	=	NULL;
	int     dummyMaxValArrayCnt	=	0;
	char	**dummyMaxValArray	=	NULL;
	char	*commaDelimExist	=	NULL;
	char	*semiColonDelimExist	=	NULL;
	int			incrCounter =0;
	logical		isMinNegative		=	false;
	logical		isMaxNegative		=	false;
	logical		isInitNegative		=	false;
	
	char *indexFirstMin				=NULL;
	char *indexFirstMax				=NULL;
	char *indexFirstInit			=NULL;
	char line_starts_withMin[128]	= "";
	char line_starts_withMax[128]	= "";
	char line_starts_withInit[128]	= "";
	int	index=0;

	TC_write_syslog("\n Enter function %s",function_name);

	if(parmInfoStruct[counter].rowCnt != 0)
		rows=parmInfoStruct[counter].rowCnt;


	if(parmInfoStruct[counter].colCnt != 0)
		columns=parmInfoStruct[counter].colCnt;

	*objName			=	parmInfoStruct[counter].name;
	*objDesc=parmInfoStruct[counter].descr;
	*usage=parmInfoStruct[counter].paraUsage;
	*ecuacr	=ecuAcronym;
	if(parmInfoStruct[counter].paraType && tc_strlen(parmInfoStruct[counter].paraType)> 0)
	{
		*parType=parmInfoStruct[counter].paraType;
	}else
	{
		*parType=PARAMETER_TYPE_DEFAULT_VAL;
	}
	if(parmInfoStruct[counter].engUnit != NULL && tc_strlen(parmInfoStruct[counter].engUnit) > 0)
	{
		if(tc_strcmp(parmInfoStruct[counter].engUnit,UNITLESS_UNIT) == 0)
		{
			*engUnit=NONE_UNIT;
		}else
		{
			*engUnit=parmInfoStruct[counter].engUnit;
		}
	}else
	{
		*engUnit=NONE_UNIT;
	}

	*numarator=parmInfoStruct[counter].numerator;
	*denominator=parmInfoStruct[counter].denominator;

	if(parmInfoStruct[counter].structureOfData && tc_strlen(parmInfoStruct[counter].structureOfData)> 0)
	{
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,ScalarInfo) == 0)
		{
			*initVal	=	 parmInfoStruct[counter].initVal;
			*maxVal		=	 parmInfoStruct[counter].maxVal;
			*minVal		=	 parmInfoStruct[counter].minVal;

			//minimumVal	=	atoi(parmInfoStruct[counter].minVal);
			indexFirstMin=strchr(parmInfoStruct[counter].minVal,'-');
			index = (int)(indexFirstMin - parmInfoStruct[counter].minVal);
			sprintf(line_starts_withMin,"%.*s",(index+1)-0,&parmInfoStruct[counter].minVal[0]);
			index=0;
			if(tc_strcmp(line_starts_withMin,"-") == 0)
			{
					minimumVal=-1;
			}

			//maximumVal	=	atoi(parmInfoStruct[counter].maxVal);
			indexFirstMax=strchr(parmInfoStruct[counter].maxVal,'-');
			index = (int)(indexFirstMax - parmInfoStruct[counter].maxVal);
			sprintf(line_starts_withMax,"%.*s",(index+1)-0,&parmInfoStruct[counter].maxVal[0]);
			index=0;
			if(tc_strcmp(line_starts_withMax,"-") == 0)
			{
					maximumVal=-1;
			}

			//initialVal	=	atoi(parmInfoStruct[counter].initVal);
			indexFirstInit=strchr(parmInfoStruct[counter].initVal,'-');
			index = (int)(indexFirstInit - parmInfoStruct[counter].initVal);
			sprintf(line_starts_withInit,"%.*s",(index+1)-0,&parmInfoStruct[counter].initVal[0]);
			index=0;
			if(tc_strcmp(line_starts_withInit,"-") == 0)
			{
					initialVal=-1;
			}

			if(minimumVal < 0 || maximumVal < 0 || initialVal < 0)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}
		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArray && dummyInitValArrayCnt> 0)
				{
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
						}
					}
				}
			}else
			{
				//Check : if 2d lookup and initial string didnt contains semicolon , its mean its single value or should I throw error
				*initVal	=	 parmInfoStruct[counter].initVal;
				//initialVal	=	atoi(parmInfoStruct[counter].initVal);
				indexFirstInit=strchr(parmInfoStruct[counter].initVal,'-');
				index = (int)(indexFirstInit - parmInfoStruct[counter].initVal);
				sprintf(line_starts_withInit,"%.*s",(index+1)-0,&parmInfoStruct[counter].initVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withInit,"-") == 0)
				{
					initialVal=-1;
				}
				if(initialVal < 0)
				{
					isInitNegative=true;
				}
			}

			//check if semicolon exist in maximum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
				semiColonDelimExist=NULL;
				if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
				{
					//store this info in maxValArrayCnt,maxValArray
					for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
							commaDelimExist=NULL;

						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
						}
					}
				}

			}else
			{
				*maxVal	=	parmInfoStruct[counter].maxVal;
				//maximumVal 	=	atoi(parmInfoStruct[counter].maxVal);
				indexFirstMax=strchr(parmInfoStruct[counter].maxVal,'-');
				index = (int)(indexFirstMax - parmInfoStruct[counter].maxVal);
				sprintf(line_starts_withMax,"%.*s",(index+1)-0,&parmInfoStruct[counter].maxVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMax,"-") == 0)
				{
					maximumVal=-1;
				}
				if(maximumVal < 0)
				{
					isMaxNegative=true;
				}
			}

			//check if semicolon exist in minimum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
				semiColonDelimExist=NULL;
				//store this info in minValArrayCnt,minValArray
				if(dummyMinValArrayCnt > 0 && dummyMinValArray)
				{
					for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
						}
					}
				}
			}else
			{
				*minVal	=	parmInfoStruct[counter].minVal;
				//minimumVal 	=	atoi(parmInfoStruct[counter].minVal);
				indexFirstMin=strchr(parmInfoStruct[counter].minVal,'-');
				index = (int)(indexFirstMin - parmInfoStruct[counter].minVal);
				sprintf(line_starts_withMin,"%.*s",(index+1)-0,&parmInfoStruct[counter].minVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMin,"-") == 0)
				{
					minimumVal=-1;
				}
				if(minimumVal < 0)
				{
					isMinNegative=true;
				}
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}
			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}
		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArray && dummyInitValArrayCnt> 0)
				{
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
						}
					}
				}
			}else
			{
				//Check : if 2d lookup and initial string didnt contains semicolon , its mean its single value or should I throw error
				*initVal	=	 parmInfoStruct[counter].initVal;
				//initialVal	=	atoi(parmInfoStruct[counter].initVal);
				indexFirstInit=strchr(parmInfoStruct[counter].initVal,'-');
				index = (int)(indexFirstInit - parmInfoStruct[counter].initVal);
				sprintf(line_starts_withInit,"%.*s",(index+1)-0,&parmInfoStruct[counter].initVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withInit,"-") == 0)
				{
					initialVal=-1;
				}
				if(initialVal < 0)
				{
					isInitNegative=true;
				}
			}

			//check if semicolon exist in maximum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
				semiColonDelimExist=NULL;
				if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
				{
					//store this info in maxValArrayCnt,maxValArray
					for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
							commaDelimExist=NULL;

						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
						}
					}
				}

			}else
			{
				*maxVal	=	parmInfoStruct[counter].maxVal;
				//maximumVal 	=	atoi(parmInfoStruct[counter].maxVal);
				indexFirstMax=strchr(parmInfoStruct[counter].maxVal,'-');
				index = (int)(indexFirstMax - parmInfoStruct[counter].maxVal);
				sprintf(line_starts_withMax,"%.*s",(index+1)-0,&parmInfoStruct[counter].maxVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMax,"-") == 0)
				{
					maximumVal=-1;
				}
				if(maximumVal < 0)
				{
					isMaxNegative=true;
				}
			}

			//check if semicolon exist in minimum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
				semiColonDelimExist=NULL;
				//store this info in minValArrayCnt,minValArray
				if(dummyMinValArrayCnt > 0 && dummyMinValArray)
				{
					for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
						}
					}
				}
			}else
			{
				*minVal	=	parmInfoStruct[counter].minVal;
				//minimumVal 	=	atoi(parmInfoStruct[counter].minVal);
				indexFirstMin=strchr(parmInfoStruct[counter].minVal,'-');
				index = (int)(indexFirstMin - parmInfoStruct[counter].minVal);
				sprintf(line_starts_withMin,"%.*s",(index+1)-0,&parmInfoStruct[counter].minVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMin,"-") == 0)
				{
					minimumVal=-1;
				}
				if(minimumVal < 0)
				{
					isMinNegative=true;
				}
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}


			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}

		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup1DInfo) == 0)
		{
			//get the row lables
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//get the initial Values
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
			}

			//get the min values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
			}

			//get the max values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}

			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}


		}
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array1DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}
			//get the initial Values
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{

				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
			}

			//get the min values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
			}

			//get the max values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}

			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}

		}
	}


	TC_write_syslog("Creating item input object %s\n",parmInfoStruct[counter].name);
	// create item
    ITK(TCTYPE_ask_type(parmInfoStruct[counter].type, &intTypeTag))
    ITK(TCTYPE_construct_create_input(intTypeTag, &createInputTag))

	// create item revision
	ITK(FV_strdup_plus(parmInfoStruct[counter].type, 9, &revTypeName))
    tc_strcat(revTypeName, "Revision");
    ITK(TCTYPE_ask_type(revTypeName, &intRevTypeTag))
    ITK(TCTYPE_construct_create_input(intRevTypeTag, &createRevInputTag))

    // set revision
    ITK(TCTYPE_set_compound_objects(createInputTag, "revision", 1, &createRevInputTag))

    //TC_write_syslog("Setting item attributes\n");
    // set item attribute
    ITK(TCTYPE_set_create_display_value(createInputTag, object_namePROP, 1, (const char**)objName))
	if(*objDesc && tc_strlen(*objDesc)> 0)
	{
		if(tc_strlen(*objDesc) <=240)
		{
			ITK(TCTYPE_set_create_display_value(createInputTag, object_descPROP, 1, (const char**)objDesc))
		}
		
	}
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ParameterUsagePROP, 1, (const char**)usage))
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ECUAcronymPROP, 1, (const char**)ecuacr))
	ITK(TCTYPE_set_create_display_value(createInputTag, parmTypePROP, 1, (const char**)parType))

	//set Revision attributes
	ITK(TCTYPE_set_create_display_value(createRevInputTag, "FVE_EngUnit", 1, (const char**)engUnit ))
	ITK(TCTYPE_set_create_display_value(createRevInputTag, "isSigned", 1,  (const char**)issigned))
	ITK(TCTYPE_set_create_display_value(createRevInputTag, "resolution_denominator", 1, (const char**)denominator))
	ITK(TCTYPE_set_create_display_value(createRevInputTag, "resolution_numerator", 1,  (const char**)numarator))

	//TC_write_syslog("Creating table def\n");
    // create table definition
    ITK(TCTYPE_ask_type("TableDefinition", &tableDefTypeTag))
    ITK(TCTYPE_construct_create_input(tableDefTypeTag, &tableDefInputTag))
	rowCountTable = (char*)MEM_alloc((int)(rows + 1) * sizeof(char));
	colCountTable = (char*)MEM_alloc((int)(columns + 1) * sizeof(char));
	sprintf(rowCountTable, "%d", rows);
	sprintf(colCountTable, "%d", columns );
    ITK(TCTYPE_set_create_display_value(tableDefInputTag, "rows", 1, (const char**)&rowCountTable))
    ITK(TCTYPE_set_create_display_value(tableDefInputTag, "cols", 1, (const char**)&colCountTable))
	//free memory
	FVE_FREE(rowCountTable)
	FVE_FREE(colCountTable)

	/*set rowLabels and colLabels
		 create TableLabel definition */
		ITK(TCTYPE_ask_type("TableLabel", &tableLabelTypeTag))
		if(rowLabelNames && rowLabelCnt > 0 && rowLabelCnt==rows)
		{
			//set row labels
			for(iCounter=0;iCounter<rows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;
				//TC_write_syslog ("rowNumber = %s\n",rowNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableRowLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableRowLabelInputTag, "label", 1,(const char **)&rowLabelNames[iCounter]))
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableRowLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "rowLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		}

		 if(colLabelNames && colLabelCnt> 0 && colLabelCnt == columns)
		 {
			//set column labels
			for(iCounter=0;iCounter<columns;iCounter++)
			{
				sprintf(intColBuf, "%d",iCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n",colNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableColLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableColLabelInputTag, "label", 1,(const char **)&colLabelNames[iCounter]))
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableColLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "colLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		 }


	ITK(TCTYPE_ask_type("Table", &tableTypeTag))

	//set the maximum values for table
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMax))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n",rowNumber);
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n",colNumber);

			// create table cell
			ITK(TCTYPE_ask_type(TableCellIntCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMax))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "col", 1, (const char **)&colNumber))
			if(maxValArray != NULL && maxValArrayCnt == rows*columns)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[incrCounter]))
				incrCounter++;
			}else if(maxValArray != NULL && maxValArrayCnt == 1)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[0]))
			}else if(maxValArray == NULL)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1, (const char**)maxVal))
			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMax))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagMax, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
    ITK(TCTYPE_set_compound_objects(tableInputTagMax, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	cellCnt=0;
	incrCounter=0;

	//Set the minimum values for a table
	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMin))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n",rowNumber);
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n",colNumber);

			// create table cell
			ITK(TCTYPE_ask_type(TableCellIntCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMin))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "col", 1,(const char **)&colNumber))
			if(minValArray != NULL && minValArrayCnt ==rows*columns)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[incrCounter]))
				incrCounter++;
			}else if(minValArray != NULL && minValArrayCnt ==1)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[0]))
			}else if(minValArray == NULL)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1, (const char**)minVal))
			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMin))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagMin, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
    ITK(TCTYPE_set_compound_objects(tableInputTagMin, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)
	cellCnt=0;
	incrCounter=0;

	ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagInitial))
	for(iCounter=0;iCounter<rows;iCounter++)
	{
		sprintf(intRowBuf, "%d",  iCounter);
   		rowNumber = intRowBuf;
		//TC_write_syslog ("rowNumber = %s\n", rowNumber );
		for(jCounter=0;jCounter<columns;jCounter++)
		{
			sprintf(intColBuf, "%d",jCounter);
   			colNumber = intColBuf;
			//TC_write_syslog ("colNumber = %s\n", colNumber);
			 // create table cell
			ITK(TCTYPE_ask_type(TableCellIntCLASS, &tableCellTypeTag))
			ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagInitial))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "row", 1,(const char **)&rowNumber))
			ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "col", 1,(const char **)&colNumber))

			if(initValArray != NULL && initValArrayCnt == rows*columns)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[incrCounter]))
				incrCounter++;
			}
			else if(initValArray != NULL && initValArrayCnt == 1)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[0]))
			}else if(initValArray == NULL)
			{
				ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1, (const char**)initVal))
			}
			// Add array cell input tag to array of tags.
			ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagInitial))
		}
	}
	ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "definition", 1, &tableDefInputTag))
	// Set array of Table Cell input tags on Table object.
    ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "cells", cellCnt, cellInputTags))
	FVE_FREE(cellInputTags)

	TC_write_syslog("Setting item revision compound objects\n");
    //set revision attribute
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "initialValues", 1, &tableInputTagInitial))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "minValues",1, &tableInputTagMin))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "maxValues", 1, &tableInputTagMax))
	ITK(TCTYPE_set_compound_objects(createRevInputTag, "tableDefinition", 1, &tableDefInputTag))

	 //TC_write_syslog("Creating object\n");
    // create the object

    ITK(TCTYPE_create_object(createInputTag, &intTag))
	if(intTag != NULLTAG)
	{
		ITK(AOM_save(intTag))
		ITK(AOM_refresh(intTag, false) )
		*parmDefItem=intTag;

		// Get the new item revision tag.
		ITK(ITEM_ask_latest_rev(intTag, &revisionTag))
		if(revisionTag != NULLTAG)
		{
			*parmDefRevision=revisionTag;
		}
	}

	//free memory
	FVE_FREE_ARRAY(rowLabelNames,rowLabelCnt);
	rowLabelCnt=0;
	FVE_FREE_ARRAY(colLabelNames,colLabelCnt);
	colLabelCnt=0;
	FVE_FREE_ARRAY(initValArray,initValArrayCnt)
	initValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyInitValArray,dummyInitValArrayCnt)
	dummyInitValArrayCnt=0;
	FVE_FREE_ARRAY(minValArray,minValArrayCnt)
	minValArrayCnt	=	0;

	FVE_FREE_ARRAY(dummyMinValArray,dummyMinValArrayCnt)
	dummyMinValArrayCnt	=	0;

	FVE_FREE_ARRAY(maxValArray,maxValArrayCnt);
	maxValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyMaxValArray,dummyMaxValArrayCnt)
	dummyMaxValArrayCnt	=	0;

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}

/*
Function Name :	FVE_validate_required_attributes
Validate the required attributes for creation of "Int/Dbl/Sed".

return : true/false
*/
int FVE_validate_required_attributes(FILE *filePtr,struct FVEParmDefInfostruct *parmInfoStruct,int counter, logical *reqAttrPresent)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_validate_required_attributes";
	logical		lgName				=	false;
	logical		lgType				=	false;
	logical		lgParaUsage			=	false;
	logical		lgParaType			=	false;
	logical		lgNumerator			=	false;
	logical		lgDenominator		=	false;
	logical		lgPrecision			=	false;
	logical		lgMin				=	false;
	logical		lgMax				=	false;
	logical		lgInitial			=	false;
	logical		lgDomainElName		=	false;
	logical		lgDomainElValue		=	false;
	logical		lgInitValMatchFound	=	false;
	logical     lgMismatchCount		=	false;
	logical		lgRowLabelMisMatchFound	=	false;
	logical		lgColumnLabelMisMatchFound	=	false;
	logical		lgInitialValMisMatchFound	=	false;
	logical		lgMinValMisMatchFound	=	false;
	logical		lgMaxValMisMatchFound	=	false;
	logical     lgStructureOfData		=	false;
	int			cntDomainEl			=	0;
	char		**valDomainEl		=	NULL;
	int			cntDomainElVal		=	0;
	char		**valDomainElVal	=	NULL;
	int			indexCounter		=	0;
	char		*trimInitValue		=	NULL;
	char		*trimDomainElVal	=	NULL;
	int			rowCount			=	0;
	int			columnCount			=	0;
	int		rowLabelCnt		=	0;
	char	**rowLabelNames	=	NULL;
	int		colLabelCnt		=	0;
	char	**colLabelNames	=	NULL;
	int     initValArrayCnt	=	0;
	char	**initValArray	=	NULL;
	int		dummyInitValArrayCnt	=	0;
	char	**dummyInitValArray		=	NULL;
	int     minValArrayCnt	=	0;
	char	**minValArray	=	NULL;
	int     dummyMinValArrayCnt	=	0;
	char	**dummyMinValArray	=	NULL;
	int     maxValArrayCnt	=	0;
	char	**maxValArray	=	NULL;
	int     dummyMaxValArrayCnt	=	0;
	char	**dummyMaxValArray	=	NULL;
	char	*commaDelimExist	=	NULL;
	char	*semiColonDelimExist	=	NULL;
	int		iCounter			=	0;
	logical	validRowCol_basedStrOfdata	=	true;


	TC_write_syslog("\n Enter function %s",function_name);
	rowCount	=	parmInfoStruct[counter].rowCnt;
	columnCount	=	parmInfoStruct[counter].colCnt;

	if(parmInfoStruct[counter].name != NULL && tc_strlen(parmInfoStruct[counter].name)> 0)
	{
		lgName =true;
	}
	if(parmInfoStruct[counter].type != NULL && tc_strlen(parmInfoStruct[counter].type)> 0)
	{
		lgType=true;
	}
	if(parmInfoStruct[counter].structureOfData != NULL && tc_strlen(parmInfoStruct[counter].structureOfData)> 0)
	{
		lgStructureOfData=true;
	}
	if(parmInfoStruct[counter].paraUsage != NULL && tc_strlen(parmInfoStruct[counter].paraUsage)> 0)
	{
		lgParaUsage=true;
	}
	if(parmInfoStruct[counter].paraType != NULL && tc_strlen(parmInfoStruct[counter].paraType)> 0)
	{
		lgParaType=true;
	}
	if(parmInfoStruct[counter].numerator != NULL && tc_strlen(parmInfoStruct[counter].numerator)> 0)
	{
		lgNumerator=true;
	}
	if(parmInfoStruct[counter].denominator != NULL && tc_strlen(parmInfoStruct[counter].denominator)> 0)
	{
		lgDenominator=true;
	}
	if(parmInfoStruct[counter].precision != NULL && tc_strlen(parmInfoStruct[counter].precision)> 0)
	{
		lgPrecision=true;
	}
	if(parmInfoStruct[counter].minVal != NULL && tc_strlen(parmInfoStruct[counter].minVal)> 0)
	{
		lgMin=true;
	}
	if(parmInfoStruct[counter].maxVal != NULL && tc_strlen(parmInfoStruct[counter].maxVal)> 0)
	{
		lgMax=true;
	}
	if(parmInfoStruct[counter].initVal != NULL && tc_strlen(parmInfoStruct[counter].initVal)> 0)
	{
		lgInitial=true;
	}

	if( (tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefIntTYPE) == 0) )
	{
		if(lgStructureOfData)
		{
			if( tc_strcmp(parmInfoStruct[counter].structureOfData,ScalarInfo) == 0)
			{

			}
			else if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup2DInfo) == 0)
			{
				if(rowCount >1 && columnCount >=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}

				if(validRowCol_basedStrOfdata)
				{
					//get the rowlables and columnLabels
					if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels) > 0)
					{
						split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
					}

					if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels) > 0)
					{
						split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
					}

					if(rowLabelCnt == rowCount)
					{
					}else
					{
						lgRowLabelMisMatchFound=true;
					}

					if(colLabelCnt == columnCount)
					{
					}else
					{
						lgColumnLabelMisMatchFound=true;
					}
					//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
					//check if semicolon exist in initial value string
					if(lgInitial)
					{
						semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
						if(semiColonDelimExist)
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
							semiColonDelimExist=NULL;
							if(dummyInitValArrayCnt == rowCount)
							{
								if(dummyInitValArray && dummyInitValArrayCnt> 0)
								{
									//store this info in initValArrayCnt,&initValArray
									for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
									{
										commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
										if(commaDelimExist)
										{
											split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
											commaDelimExist=NULL;
										}else
										{
											split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
										}
									}
									//check if initialValue array = rows*columns
									if(initValArrayCnt == rowCount *columnCount)
									{
									}else
									{
										lgInitialValMisMatchFound=true;
									}
								}
							}//cnt match with rows
							else
							{
								lgInitialValMisMatchFound=true;
							}
						}//semiColonDelimExist
						else
						{
							/*If 2d Lookup didnt contains semicolon , it means single row
							e.g string = 1,0 ,2  or
							string=1 0 2
							string =1
							*/
							commaDelimExist=strstr(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
							}
							if( (initValArrayCnt == rowCount *columnCount) || (initValArrayCnt == 1) )
							{
							}else
							{
								lgInitialValMisMatchFound=true;
							}
						}
					}//lginitial

					//check if semicolon exist in maximum value string
					if(lgMax)
					{
						semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
						if(semiColonDelimExist)
						{
							split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
							semiColonDelimExist=NULL;
							if(dummyMaxValArrayCnt == rowCount)
							{
								if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
								{
									//store this info in maxValArrayCnt,maxValArray
									for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
									{
										commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
										if(commaDelimExist)
										{
											split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
											commaDelimExist=NULL;
										}else
										{
											split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
										}
									}
									if(maxValArrayCnt == rowCount*columnCount)
									{
									}else
									{
										lgMaxValMisMatchFound=true;
									}
								}
							}//cnt match with rows
							else
							{
								lgMaxValMisMatchFound=true;
							}
						}//semiColonDelimExist
						else
						{
							/*If 2d Lookup didnt contains semicolon , it means single row
							 e.g string = 1,0 ,2  or
							string=1 0 2
							string =1
							*/
							commaDelimExist=strstr(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),"' '",&maxValArrayCnt,&maxValArray);
							}
							if( (maxValArrayCnt == rowCount*columnCount) || (maxValArrayCnt == 1))
							{
							}else
							{
								lgMaxValMisMatchFound=true;
							}

						}
					}//lgMax

					//check if semicolon exist in minimum value string
					if(lgMin)
					{
						semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
						if(semiColonDelimExist)
						{
							split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
							semiColonDelimExist=NULL;
							if(dummyMinValArrayCnt == rowCount)
							{
								if(dummyMinValArrayCnt > 0 && dummyMinValArray)
								{
									//store this info in minValArrayCnt,minValArray
									for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
									{
										commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
										if(commaDelimExist)
										{
											split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
											commaDelimExist=NULL;
										}else
										{
											split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
										}
									}
									if(minValArrayCnt == rowCount*columnCount)
									{
									}else
									{
										lgMinValMisMatchFound=true;
									}
								}
							}else
							{
								lgMinValMisMatchFound=true;
							}
						}//semiColonDelimExist
						else
						{
							/*If 2d Lookup didnt contains semicolon , it means single row
							 e.g string = 1,0 ,2
								 or string=1 0 2
								 or string =1
							*/
							commaDelimExist=strstr(FV_trim_invalidChars(parmInfoStruct[counter].minVal),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),COMMA_DELIM,&minValArrayCnt,&minValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),"' '",&minValArrayCnt,&minValArray);
							}
							if( (minValArrayCnt == rowCount*columnCount) || (minValArrayCnt == 1) )
							{
							}else
							{
								lgMinValMisMatchFound=true;
							}
						}
					}//lgMin
				}//validStructureData
			}
			else if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array2DInfo) == 0)
			{
					if(rowCount >1 && columnCount>=1)
					{
						validRowCol_basedStrOfdata=true;
					}else
					{
						validRowCol_basedStrOfdata=false;
					}

					if(validRowCol_basedStrOfdata)
					{
						//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
						//check if semicolon exist in initial value string
						if(lgInitial)
						{
							semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
							if(semiColonDelimExist)
							{
								split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
								semiColonDelimExist=NULL;
								if(dummyInitValArrayCnt == rowCount)
								{
									if(dummyInitValArray && dummyInitValArrayCnt> 0)
									{
										//store this info in initValArrayCnt,&initValArray
										for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
										{
											commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
											if(commaDelimExist)
											{
												split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
												commaDelimExist=NULL;
											}else
											{
												split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
											}
										}
										if(initValArrayCnt == rowCount*columnCount)
										{
										}else
										{
											lgInitialValMisMatchFound=true;
										}
									}
								}else
								{
									lgInitialValMisMatchFound=true;
								}
							}//semiColonDelimExist
							else
							{
								/*If 2d Array didnt contains semicolon , it means single row
								e.g string = 1,0 ,2  or
							        string=1 0 2
									 string =1
								*/
								commaDelimExist=strstr(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM);
								if(commaDelimExist)
								{
									split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
									commaDelimExist=NULL;
								}else
								{
									split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
								}
								if( (initValArrayCnt == rowCount*columnCount) || (initValArrayCnt == 1) )
								{
								}else
								{
									lgInitialValMisMatchFound=true;
								}

							}
						}//lgInitial

						if(lgMax)
						{
							//check if semicolon exist in maximum value string
							semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
							if(semiColonDelimExist)
							{
								split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
								semiColonDelimExist=NULL;
								if(dummyMaxValArrayCnt == rowCount)
								{
									if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
									{
										//store this info in maxValArrayCnt,maxValArray
										for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
										{
											commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
											if(commaDelimExist)
											{
												split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
												commaDelimExist=NULL;
											}else
											{
												split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
											}
										}
										if(maxValArrayCnt == rowCount*columnCount)
										{
										}else
										{
											lgMaxValMisMatchFound=true;
										}
									}
								}else
								{
									lgMaxValMisMatchFound=true;
								}
							}//semiColonDelimExist
							else
							{
								/*If 2d Lookup didnt contains semicolon , it means single row
								 e.g string = 1,0 ,2  or
								string=1 0 2
								string =1
								*/
								commaDelimExist=strstr(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),COMMA_DELIM);
								if(commaDelimExist)
								{
									split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
									commaDelimExist=NULL;
								}else
								{
									split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),"' '",&maxValArrayCnt,&maxValArray);
								}
								if( (maxValArrayCnt == rowCount*columnCount) || (maxValArrayCnt == 1))
								{
								}else
								{
									lgMaxValMisMatchFound=true;
								}
							}
						}//lgMax

						if(lgMin)
						{
							//check if semicolon exist in minimum value string
							semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
							if(semiColonDelimExist)
							{
								split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
								semiColonDelimExist=NULL;
								if(dummyMinValArrayCnt == rowCount)
								{
									//store this info in minValArrayCnt,minValArray
									if(dummyMinValArrayCnt > 0 && dummyMinValArray)
									{
										for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
										{
											commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
											if(commaDelimExist)
											{
												split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
												commaDelimExist=NULL;
											}else
											{
												split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
											}
										}
										if(minValArrayCnt == rowCount*columnCount)
										{
										}else
										{
											lgMinValMisMatchFound=true;
										}
									}
								}else
								{
									lgMinValMisMatchFound=true;
								}
							}//semiColonDelimExist
							else
							{
								/*If 2d Lookup didnt contains semicolon , it means single row
									 e.g string = 1,0 ,2
										or string=1 0 2
										or string =1
								*/
								commaDelimExist=strstr(FV_trim_invalidChars(parmInfoStruct[counter].minVal),COMMA_DELIM);
								if(commaDelimExist)
								{
									split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),COMMA_DELIM,&minValArrayCnt,&minValArray);
									commaDelimExist=NULL;
								}else
								{
									split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),"' '",&minValArrayCnt,&minValArray);
								}
								if( (minValArrayCnt == rowCount*columnCount) || (minValArrayCnt == 1) )
								{
								}else
								{
									lgMinValMisMatchFound=true;
								}
							}
						}//lgMin
					}//validRowCol_basedStrOfdata
			}else if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup1DInfo) == 0)
			{
				if(rowCount ==1 && columnCount>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}

				if(validRowCol_basedStrOfdata)
				{
					//1D LOOKUP only contains column labels , it didnt contains rowlabel names
					//get the column lables
					if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels) > 0)
					{
						split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
						if(colLabelCnt == columnCount)
						{
						}else
						{
							lgColumnLabelMisMatchFound=true;
						}
					}

					if(lgInitial)
					{
						//get the initial Values
						//check which delimiter exist in CSV file for  initial values.either space or comma.
						commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
						}

						if( (initValArrayCnt == columnCount) || ((initValArrayCnt == 1)))
						{
						}else
						{
							lgInitialValMisMatchFound=true;
						}
					}

					if(lgMin)
					{
						//get the min values
						commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),COMMA_DELIM,&minValArrayCnt,&minValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),"' '",&minValArrayCnt,&minValArray);
						}

						if((minValArrayCnt == columnCount) || (minValArrayCnt == 1))
						{
						}else
						{
							lgMinValMisMatchFound=true;
						}
					}

					if(lgMax)
					{
						//get the max values
						commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),"' '",&maxValArrayCnt,&maxValArray);
						}

						if((maxValArrayCnt == columnCount) || (maxValArrayCnt == 1))
						{
						}else
						{
							lgMaxValMisMatchFound=true;
						}
					}
				}//validRowCol_basedStrOfdata
			}else if(tc_strcmp(parmInfoStruct[counter].structureOfData,Array1DInfo) == 0)
			{
				if(rowCount ==1 && columnCount>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}

				if(validRowCol_basedStrOfdata)
				{
					//1D array dint contain rowLabel/Column Label .rowCount =1
					if(lgInitial)
					{
						//get the initial Values
						//check which delimiter exist in CSV file for  initial values.either space or comma.
						commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
						}else
						{
							split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
						}

						if((initValArrayCnt == columnCount) || (initValArrayCnt == 1))
						{
						}else
						{
							lgInitialValMisMatchFound=true;
						}
					}

					if(lgMin)
					{
						//get the min values
						commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
						}
						if((minValArrayCnt == columnCount) || (minValArrayCnt == 1))
						{
						}else
						{
							lgMinValMisMatchFound=true;
						}
					}


					if(lgMax)
					{
						//get the max values
						commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
						}
						if((maxValArrayCnt == columnCount) || (maxValArrayCnt ==1))
						{
						}else
						{
							lgMaxValMisMatchFound=true;
						}
					}
				}//validRowCol_basedStrOfdata
			}
		}//structureOfData
	}//Int or Dbl Type

	if(lgType && filePtr)
	{
		if(tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefDblTYPE)== 0)
		{
			if(lgStructureOfData && lgNumerator && lgDenominator && lgPrecision && lgMin && lgMax && lgInitial)
			{
				/* if structure of data is 2D LookUp or 2D Array then only check if rowSize is matching with the number of semicolons
				   for 1D array or 1D Lookup or Scalar row always 1
				*/
				if( (tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup2DInfo) == 0) )
				{
					if(validRowCol_basedStrOfdata == false || lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound || lgRowLabelMisMatchFound || lgColumnLabelMisMatchFound)
					{
						*reqAttrPresent=false;
					}else
					{
						*reqAttrPresent=true;
					}
				}else if( (tc_strcmp(parmInfoStruct[counter].structureOfData,Array2DInfo) == 0) ||
						  (tc_strcmp(parmInfoStruct[counter].structureOfData,Array1DInfo) == 0) ||
						  (tc_strcmp(parmInfoStruct[counter].structureOfData,ScalarInfo) == 0))
				{
					if(validRowCol_basedStrOfdata == false || lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound)
					{
						*reqAttrPresent=false;
					}else
					{
						*reqAttrPresent=true;
					}
				}else if((tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup1DInfo) == 0))
				{
					if(validRowCol_basedStrOfdata == false || lgColumnLabelMisMatchFound || lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound )
					{
						*reqAttrPresent=false;
					}else
					{
						*reqAttrPresent=true;
					}

				}

				if(*reqAttrPresent==false)
				{
					fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
					fprintf(filePtr,"Row count=%d \n",rowCount);
					fprintf(filePtr,"Column count=%d \n",columnCount);
					fprintf(filePtr,"Structure Of Data:%s \n",parmInfoStruct[counter].structureOfData);

					if(validRowCol_basedStrOfdata == false)
					{
						fprintf(filePtr,"Row X Column size is not provided correctly based on the structure of data.\n");
					}

					if(lgInitialValMisMatchFound)
					{
						fprintf(filePtr,"Initial Value array size do not match with the row and column sizes.\n");
					}
					if(lgMinValMisMatchFound)
					{
						fprintf(filePtr,"Minimum Value array size do not match with the row and column sizes.\n");
					}
					if(lgMaxValMisMatchFound)
					{
						fprintf(filePtr,"Maximum Value array size do not match with the row and column sizes.\n");
					}
					if(lgRowLabelMisMatchFound)
					{
						fprintf(filePtr,"Row Labels size do not match with the row count.\n");
					}
					if(lgColumnLabelMisMatchFound)
					{
						fprintf(filePtr,"Column Labels size do not match with the column count.\n");
					}

					fprintf(filePtr,"Status: Failed\n");
					fprintf(filePtr,"ERROR: Required attributes are missing for %s\n", parmInfoStruct[counter].name);
				}
			}else
			{
				*reqAttrPresent=false;
				fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
				fprintf(filePtr,"Row count=%d \n",rowCount);
				fprintf(filePtr,"Column count=%d \n",columnCount);
				fprintf(filePtr,"Structure Of Data:%s \n",parmInfoStruct[counter].structureOfData);
				if(lgStructureOfData == false)
				{
					fprintf(filePtr,"Value for Structure Of Data does not exist \n");
				}
				if(validRowCol_basedStrOfdata == false)
				{
					fprintf(filePtr,"Row X Column size is not provided correctly based on the structure of data.\n");
				}
				if(lgNumerator == false)
				{
					fprintf(filePtr,"Value for Numerator does not exist \n");
				}
				if(lgDenominator == false)
				{
					fprintf(filePtr,"Value for Denominator does not exist \n");
				}
				if(lgPrecision == false)
				{
					fprintf(filePtr,"Value for Precision does not exist \n");
				}
				if(lgMin == false)
				{
					fprintf(filePtr,"Minimum Value does not exist \n");
				}
				if(lgMax == false)
				{
					fprintf(filePtr,"Maximum Value does not exist \n");
				}
				if(lgInitial == false)
				{
					fprintf(filePtr,"Initial Value does not exist \n");
				}
				if(lgInitialValMisMatchFound)
				{
					fprintf(filePtr,"Initial Value array size do not match with the row and column sizes.\n");
				}
				if(lgMinValMisMatchFound)
				{
					fprintf(filePtr,"Minimum Value array size do not match with the row and column sizes.\n");
				}
				if(lgMaxValMisMatchFound)
				{
					fprintf(filePtr,"Maximum Value array size do not match with the row and column sizes.\n");
				}
				if(lgRowLabelMisMatchFound)
				{
					fprintf(filePtr,"Row Labels size do not match with the row count.\n");
				}
				if(lgColumnLabelMisMatchFound)
				{
					fprintf(filePtr,"Column Labels size do not match with the column count.\n");
				}

				fprintf(filePtr,"Status: Failed\n");
				fprintf(filePtr,"ERROR: Required attributes are missing for %s\n", parmInfoStruct[counter].name);
			}

		}
		if(tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefStrTYPE)== 0)
		{
			if(lgStructureOfData && lgInitial)
			{
				*reqAttrPresent=true;
			}else
			{
				*reqAttrPresent=false;
			}
			if(*reqAttrPresent==false)
			{
					fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
					fprintf(filePtr,"Row count=%d \n",rowCount);
					fprintf(filePtr,"Column count=%d \n",columnCount);
					fprintf(filePtr,"Structure Of Data:%s \n",parmInfoStruct[counter].structureOfData);
					if(lgInitial == false)
					{
						fprintf(filePtr,"Initial Values not provided.\n");
					}
					if(lgStructureOfData == false)
					{
						fprintf(filePtr,"Structure Of data not provided.\n");
					}
					fprintf(filePtr,"Status: Failed\n");
					fprintf(filePtr,"ERROR: Required attributes are missing for %s\n", parmInfoStruct[counter].name);
			}
		}
		if(tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefHexTYPE)== 0)
		{
			if(lgStructureOfData && lgMin && lgMax && lgInitial)
			{
				*reqAttrPresent=true;
			}else
			{
				*reqAttrPresent=false;
			}
			
			if(*reqAttrPresent==false)
			{
					fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
					fprintf(filePtr,"Row count=%d \n",rowCount);
					fprintf(filePtr,"Column count=%d \n",columnCount);
					fprintf(filePtr,"Structure Of Data:%s \n",parmInfoStruct[counter].structureOfData);
					if(lgInitial == false)
					{
						fprintf(filePtr,"Initial Values not provided.\n");
					}
					if(lgMin == false)
					{
						fprintf(filePtr,"Minimum Values not provided.\n");
					}
					if(lgMax == false)
					{
						fprintf(filePtr,"Maximum Values not provided.\n");
					}
					if(lgStructureOfData == false)
					{
						fprintf(filePtr,"Structure Of data not provided.\n");
					}
					
					fprintf(filePtr,"Status: Failed\n");
					fprintf(filePtr,"ERROR: Required attributes are missing for %s\n", parmInfoStruct[counter].name);
			}
		}
		if(tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefIntTYPE)== 0)
		{
			if(lgStructureOfData && lgNumerator && lgDenominator && lgMin && lgMax && lgInitial)
			{
				if( (tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup2DInfo) == 0) )
				{
					if(validRowCol_basedStrOfdata == false || lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound || lgRowLabelMisMatchFound || lgColumnLabelMisMatchFound)
					{
						*reqAttrPresent=false;
					}else
					{
						*reqAttrPresent=true;
					}
				}else if( (tc_strcmp(parmInfoStruct[counter].structureOfData,Array2DInfo) == 0) ||
					      (tc_strcmp(parmInfoStruct[counter].structureOfData,Array1DInfo) == 0) ||
						  (tc_strcmp(parmInfoStruct[counter].structureOfData,ScalarInfo) == 0))
				{
					if(validRowCol_basedStrOfdata == false || lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound)
					{
						*reqAttrPresent=false;
					}else
					{
						*reqAttrPresent=true;
					}
				}else if((tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup1DInfo) == 0))
				{
					if(validRowCol_basedStrOfdata == false || lgColumnLabelMisMatchFound || lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound)
					{
						*reqAttrPresent=false;
					}else
					{
						*reqAttrPresent=true;
					}

				}

				if(*reqAttrPresent==false)
				{
					fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
					fprintf(filePtr,"Row count=%d \n",rowCount);
					fprintf(filePtr,"Column count=%d \n",columnCount);
					fprintf(filePtr,"Structure Of Data:%s \n",parmInfoStruct[counter].structureOfData);
					if(validRowCol_basedStrOfdata == false)
					{
						fprintf(filePtr,"Row X Column size is not provided correctly based on the structure of data.\n");
					}
					if(lgInitialValMisMatchFound)
					{
						fprintf(filePtr,"Initial Value array size do not match with the row and column sizes.\n");
					}
					if(lgMinValMisMatchFound)
					{
						fprintf(filePtr,"Minimum Value array size do not match with the row and column sizes.\n");
					}
					if(lgMaxValMisMatchFound)
					{
						fprintf(filePtr,"Maximum Value array size do not match with the row and column sizes.\n");
					}
					if(lgRowLabelMisMatchFound)
					{
						fprintf(filePtr,"Row Labels size do not match with the row count.\n");
					}
					if(lgColumnLabelMisMatchFound)
					{
						fprintf(filePtr,"Column Labels size do not match with the column count.\n");
					}

					fprintf(filePtr,"Status: Failed\n");
					fprintf(filePtr,"ERROR: Required attributes are missing for %s\n", parmInfoStruct[counter].name);
				}
			}else
			{
				*reqAttrPresent=false;
				fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
				fprintf(filePtr,"Row count=%d \n",rowCount);
				fprintf(filePtr,"Column count=%d \n",columnCount);
				fprintf(filePtr,"Structure Of Data:%s \n",parmInfoStruct[counter].structureOfData);
				fprintf(filePtr,"Status: Failed\n");
				fprintf(filePtr,"ERROR: Required attributes are missing for %s\n", parmInfoStruct[counter].name);
				if(lgStructureOfData == false)
				{
					fprintf(filePtr,"Value for Structure Of Data does not exist \n");
				}
				if(validRowCol_basedStrOfdata == false)
				{
					fprintf(filePtr,"Row X Column size is not provided correctly based on the structure of data.\n");
				}
				if(lgNumerator == false)
				{
					fprintf(filePtr,"Value for Numerator does not exist \n");
				}
				if(lgDenominator == false)
				{
					fprintf(filePtr,"Value for Denominator does not exist \n");
				}
					if(lgMin == false)
				{
					fprintf(filePtr,"Minimum Value does not exist \n");
				}
				if(lgMax == false)
				{
					fprintf(filePtr,"Maximum Value does not exist \n");
				}
				if(lgInitial == false)
				{
					fprintf(filePtr,"Initial Value does not exist \n");
				}
				if(lgInitialValMisMatchFound)
				{
					fprintf(filePtr,"Initial Value array size do not match with the row and column sizes.\n");
				}
				if(lgMinValMisMatchFound)
				{
					fprintf(filePtr,"Minimum Value array size do not match with the row and column sizes.\n");
				}
				if(lgMaxValMisMatchFound)
				{
					fprintf(filePtr,"Maximum Value array size do not match with the row and column sizes.\n");
				}
				if(lgRowLabelMisMatchFound)
				{
					fprintf(filePtr,"Row Labels size do not match with the row count.\n");
				}
				if(lgColumnLabelMisMatchFound)
				{
					fprintf(filePtr,"Column Labels size do not match with the column count.\n");
				}
			}

		}
		if(tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefSEDTYPE)== 0)
		{
			//for valid values : domain element name and domain element values will be used
			//for initial values : initial value provided in csv file will be used.
			//if initial value exist , it should match with the domain element values
			//if didnt match , throw error "initial value didnt match , object can not be created"
			//check for domain element name
			if( (parmInfoStruct[counter].domainElName != NULL) && (tc_strlen(parmInfoStruct[counter].domainElName )> 0))
			{
				//get the rows
				split_the_string(parmInfoStruct[counter].domainElName,COMMA_DELIM,&cntDomainEl,&valDomainEl);
				if((cntDomainEl > 0) && (valDomainEl != NULL))
				{
					lgDomainElName=true;
				}
			}
			//check for domain element values
			if( (parmInfoStruct[counter].domainElVal != NULL) && (tc_strlen(parmInfoStruct[counter].domainElVal )> 0))
			{
				//get the valid values
				split_the_string(parmInfoStruct[counter].domainElVal,COMMA_DELIM,&cntDomainElVal,&valDomainElVal);
				if((cntDomainElVal > 0) && (valDomainElVal != NULL))
				{
					lgDomainElValue=true;
				}
			}
			//check for initial value
			if( (parmInfoStruct[counter].initVal != NULL) && (tc_strlen(parmInfoStruct[counter].initVal )> 0))
			{
				lgInitial=true;
				if(cntDomainEl == cntDomainElVal)
				{
					//check if initial value exist in domain element values
					if((lgDomainElValue == true) && (cntDomainElVal > 0) && (valDomainElVal != NULL) )
					{
						if((lgDomainElName == true) && (cntDomainEl > 0) && (valDomainEl != NULL))
						{
							ifail=FVE_remove_invalidChars(parmInfoStruct[counter].initVal,&trimInitValue);
							for(indexCounter =0; indexCounter<cntDomainEl ; indexCounter++)
							{
								ifail=FVE_remove_invalidChars(valDomainEl[indexCounter],&trimDomainElVal);
								if( stricmp(trimInitValue,trimDomainElVal) == 0)
								{
									lgInitValMatchFound=true;
									break;
								}
								FVE_FREE(trimDomainElVal)
							}
							FVE_FREE(trimInitValue);
						}
					}//
				}//cntDomainEl == cntDomainElVal
				else
				{
					lgMismatchCount=true;
				}
			}//initial value


			if(lgParaUsage && lgDomainElName && lgDomainElValue && lgInitial)
			{
				*reqAttrPresent=true;
				if(lgInitValMatchFound == false)
				{
					*reqAttrPresent=false;
					fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
					fprintf(filePtr,"Status: Failed\n");
					fprintf(filePtr,"ERROR: Initial value does not match with the set of domain elements values\n");
					if(lgMismatchCount == true)
					{
						fprintf(filePtr,"Different count for domain element name and values exist\n");
					}
				}

			}else
			{
				*reqAttrPresent=false;
				fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
				fprintf(filePtr,"Status: Failed\n");
				fprintf(filePtr,"ERROR: Required attributes are missing for %s\n", parmInfoStruct[counter].name);
				if(lgParaUsage == false)
				{
					fprintf(filePtr,"Parameter Usage does not exist \n");
				}
				if(lgDomainElName == false)
				{
					fprintf(filePtr,"Domain Element does not exist \n");
				}
				if(lgDomainElValue == false)
				{
					fprintf(filePtr,"Domain Element does not exist \n");
				}
				if(lgInitial == false)
				{
					fprintf(filePtr,"Initial Value does not exist \n");
				}
			}
			//free memory
			FVE_FREE(valDomainEl)
			cntDomainEl=0;
			FVE_FREE(valDomainElVal);
			cntDomainElVal=0;
		}//SED type
	}else
	{
		fprintf(filePtr,"Parameter Name:%s \n",parmInfoStruct[counter].name);
		fprintf(filePtr,"Status: Failed\n");
		fprintf(filePtr,"ERROR: Parameter Type does not exist for %s\n", parmInfoStruct[counter].name);
		fprintf(filePtr,"\n");

	}

	FVE_FREE_ARRAY(rowLabelNames,rowLabelCnt);
	rowLabelCnt=0;
	FVE_FREE_ARRAY(colLabelNames,colLabelCnt);
	colLabelCnt=0;

	FVE_FREE_ARRAY(initValArray,initValArrayCnt)
	initValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyInitValArray,dummyInitValArrayCnt)
	dummyInitValArrayCnt=0;

	FVE_FREE_ARRAY(minValArray,minValArrayCnt)
	minValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyMinValArray,dummyMinValArrayCnt)
	dummyMinValArrayCnt	=	0;

	FVE_FREE_ARRAY(maxValArray,maxValArrayCnt);
	maxValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyMaxValArray,dummyMaxValArrayCnt)
	dummyMaxValArrayCnt	=	0;

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;
}

/*
Update operations to the parameter definitions
*/
int FVE_update_operations(struct FVEParmDefInfostruct *parmInfoStruct,int counter, int dicChildlineCnt, tag_t* dicChildlineTags, int* revisePendingCnt, tag_t **revisePendingObjects)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_update_operations";
	char*       name				=	NULL;
    char*       paramGrpId    =   NULL;
	tag_t		tagOldParmRevBl		=	NULLTAG;
	tag_t		itemRevTag			=	NULLTAG;
	tag_t		msaFormTag			=	NULLTAG;
	
	tag_t		tagNewParmRevBl		=	NULLTAG;

    // Attach definition approved status to newly created param def rev.
    tag_t       defAppStatusTag     =   NULLTAG;
    tag_t       newAddedOrgGrpLine = NULLTAG;
    tag_t       paramDefRevLineFound = NULLTAG;
    tag_t       orgBlRevTag = NULLTAG;
    int         foundIndx = -1;
    logical     isParmTypeSame = TRUE;


	TC_write_syslog("\n Enter function %s",function_name);

	name = parmInfoStruct[counter].name;
	if( (name != NULL) && (tc_strlen(name)> 0 ))
	{
        if(isDictionary)
		{
			//ifail=FVE_check_objName_existIn_Structure(orgBlTag,parmInfoStruct[counter].name,&tagOldParmRevBl);
			  ifail=FV_check_bomLineExist_inStruct(topDicBomLine,parmInfoStruct[counter].name,&tagOldParmRevBl);
		}
		if(isECCTProjectRev)
		{
			foundIndx = FV_find_tag_in_array_by_string_attr_value(dicChildlineCnt, dicChildlineTags,
                                bl_item_object_namePROP, 1, &name);
            if(foundIndx >= 0)
            {
                tagOldParmRevBl = dicChildlineTags[foundIndx];
                dicChildlineTags[foundIndx] = NULLTAG;
            }
            //ifail=FVE_check_objName_existIn_Structure(topBlPrimeDic,parmInfoStruct[counter].name,&tagOldParmRevBl);
			/*Recursive function to get the matching bomline for repository structure */
			//ifail=FV_check_bomLineExist_inStruct(topBlECCTPrj,parmInfoStruct[counter].name,&tagOldParmUsageBl);
		}
	}
	if(tagOldParmRevBl)
	{
		itemRevTag=NULLTAG;
		msaFormTag=NULLTAG;

        /*
         * Use case handled -
         * In Second run,
         * if the Resolution or Initial or Min or Max values are modified and
         * that triggers a different type to be created but with the same parameter name
         * (created in the previous run).
         * 
         * Algorithm followed -
         * 
         * 1) Get the incoming values for these 4 attributes 
         * 2) Based on the values, we get to know what type of parameter to be created. 
         * 3) Check if a parameter with that name already exists in the dictionary. 
         * 4) Check for the object type of the parameter that is found. 
         * 5) If there is no difference in the type, go ahead and update it. 
         * 6) If there is a difference in the type,
         *    then cut the existing bomline and 
         *    create a new parameter of type based on the attribute values and 
         *    replace this as a bomline in the dictionary and project structures. 
        */

        //Check parameter type of tagOldParmRevBl.
        ITK(FV_bomline_is_typeof(tagOldParmRevBl, parmInfoStruct[counter].type, &isParmTypeSame))

        // If parameter type is changed
        if( !isParmTypeSame)
        {
            // If dictionary item id is provided to uploader,
            // then revise stucture up the hierarchy before removing & adding
            // new parameter
            if(isDictionary && topDicBomLine && orgBlTag)
            {
                ITK(AOM_ask_value_string(orgBlTag,bl_item_item_idPROP, &paramGrpId))
                foundIndx = -1;
                ITK(AOM_ask_value_tag(orgBlTag,bomAttr_lineItemRevTag,&orgBlRevTag))
                foundIndx = FV_find_tag_in_array(revisedObjsCnt, revisedObjs, orgBlRevTag);
                if(foundIndx < 0)
                {
                    ifail = FV_revise_bomline_and_limited_parents_BT(orgBlTag,
                                                    topDicBomLine,
                                                    windowDic,
                                                    &revisedObjsCnt,
                                                    &revisedObjs,
                                                    &newAddedOrgGrpLine,
                                                    TRUE,
                                                    paramGrpId);
                    if(newAddedOrgGrpLine != NULLTAG)
                    {
                        ifail = FV_check_bomLineExist_inStruct(newAddedOrgGrpLine, name, &paramDefRevLineFound);
                        tagOldParmRevBl = paramDefRevLineFound;
                        orgBlTag = newAddedOrgGrpLine;
                    }
                }
                // Remove old parameter
                ITK( BOM_line_cut(tagOldParmRevBl))
                ITK( BOM_save_window(windowDic))
            }
            // For ecct project mode, only remove parameter def from dictionary.
            // No revising up the hierarchy required, as dict has flat structure.
            else
            {
                ITK( BOM_line_cut(tagOldParmRevBl) )
                ITK( BOM_save_window(windowPrimeDic) )
            }
            ifail=FVE_create_operations(parmInfoStruct,counter, isParmTypeSame, revisePendingCnt, revisePendingObjects);
        }
        else
        {
             //update log file
            ifail=FVE_update_log_file(logfileptr,parmInfoStruct,counter);

            //compare properties with currentObject and Old object
            ifail=FVE_compare_properties(parmInfoStruct,counter,tagOldParmRevBl,&tagNewParmRevBl);

            if(isDictionary)
            {
                ITK(BOM_save_window(windowDic))
                //Performance
                //ITK(BOM_refresh_window(windowDic))
            }

            if(ifail != ITK_ok)
            {
                ifail=ITK_ok;
            }

            if(tagNewParmRevBl)
            {
                    tagOldParmRevBl=tagNewParmRevBl;
                    //get the itemRevision from bomLine
                    ITK(AOM_ask_value_tag(tagOldParmRevBl,bomAttr_lineItemRevTag,&itemRevTag))
            }else
            {
                if(tagOldParmRevBl)
                    ITK(AOM_ask_value_tag(tagOldParmRevBl,bomAttr_lineItemRevTag,&itemRevTag))

            }

            if(itemRevTag)
            {
                AM__set_application_bypass(TRUE);
                ifail=FVE_create_MSAForm(parmInfoStruct,counter,itemRevTag,&msaFormTag);
                ITK(FV_set_object_status(itemRevTag,"Definition Approved",TRUE,&defAppStatusTag))
                AM__set_application_bypass(FALSE);
            }
            if(ignoreProcessFile == FALSE)
            {
                fprintf(logfileptr,"Checking for the process objects...\n");
                //create/update Process Relations
                if(isDictionary)
                {
                    ifail=FVE_get_ProcessObjectInfo(parmInfoStruct,counter,tagOldParmRevBl,dicRevTag,windowDic);
                }
                if(isECCTProjectRev)
                {
                    //add process object incontext of Prime Dictionary for parameter definitions
                    ifail=FVE_get_ProcessObjectInfo(parmInfoStruct,counter,tagOldParmRevBl,primeDicRevision,windowPrimeDic);
                }
            }

        }

		
	}else
	{
         if(orgBlTag == NULLTAG)
        {
            orgBlTag = topBlPrimeDic;
        }
        ITK(AOM_ask_value_string(orgBlTag,"bl_item_item_id", &paramGrpId))

        ifail = FV_revise_bomline_and_limited_parents_BT(orgBlTag, topDicBomLine, windowDic, &revisedObjsCnt, &revisedObjs, &newAddedOrgGrpLine, TRUE, paramGrpId);

        if(newAddedOrgGrpLine)
        {
            orgBlTag    = newAddedOrgGrpLine;
        }
		ifail=FVE_create_operations(parmInfoStruct,counter, TRUE, revisePendingCnt, revisePendingObjects);

        FVE_FREE(paramGrpId);
	}

    FVE_FREE(paramGrpId);

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}


/*
create function based on the object type
*/

int FVE_create_operations(struct FVEParmDefInfostruct *parmInfoStruct,int counter, logical isParmTypeSame, int* revisePendingCnt, tag_t** revisePendingObjects)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_operations";
	char		*type				=	NULL;
	char		*name				=	NULL;
	tag_t		parmDefRev			=	NULLTAG;
	tag_t		parmDefItem			=	NULLTAG;
	tag_t		msaFormTag			=	NULLTAG;
	char		*message			=	NULL;
	tag_t		parmDefBl			=	NULLTAG;
	tag_t		parmUsageBl			=	NULLTAG;
	tag_t		tagGroupBl			=	NULLTAG;
	tag_t		itemRevGrpTag		=	NULLTAG;
	logical		isReqAttrPresent	=	false;
	char		*finalStrDD			=	NULL;
	int			index				=	0;
	tag_t		parmDefUsgItemRev	=	NULLTAG;

	int			cntDomainElDescr	=	0;
	char		**valDomainElDescr	=	NULL;
	char		**valDomainElName	=	NULL;
	int			cntDomainElName		=	0;
	char		**valDomainElVal	=	NULL;
	int			cntDomainElVal		=	0;

    char*       paramGrpId = NULL;

    logical     isPartTypeValValid  = FALSE;
    tag_t       partTypeLovTag      = NULLTAG;
	
	tag_t		defAppStatusTag		=	NULLTAG;

    tag_t       newAddedGrpLine = NULLTAG;


	TC_write_syslog("\n Enter function %s",function_name);

	//type=parmInfoStruct[counter].type;
	if(parmInfoStruct[counter].type && tc_strlen(parmInfoStruct[counter].type)> 0)
	{
		type= (char*) MEM_alloc((int)(strlen(parmInfoStruct[counter].type)+1)* sizeof(char));
		strcpy(type,parmInfoStruct[counter].type);
	}
	//name=parmInfoStruct[counter].name;
	if(parmInfoStruct[counter].name && tc_strlen(parmInfoStruct[counter].name)> 0)
	{
		name= (char*) MEM_alloc((int)(strlen(parmInfoStruct[counter].name)+1)* sizeof(char));
		strcpy(name,parmInfoStruct[counter].name);
	}
	ifail=FVE_validate_required_attributes(logfileptr,parmInfoStruct,counter,&isReqAttrPresent);

	if( (name != NULL) && (tc_strlen(name)> 0 ))
	{
		if(isReqAttrPresent == TRUE)
		{
			if( (type != NULL) && (tc_strlen(type) > 0))
			{
				//update log file
				ifail=FVE_update_log_file(logfileptr,parmInfoStruct,counter);
				if( tc_strcmp(type ,FVE_ParmDefDblTYPE)==0)
				{
					ifail=FVE_create_parmDbl(parmInfoStruct,counter,&parmDefItem,&parmDefRev);
				}

				if( tc_strcmp(type ,FVE_ParmDefIntTYPE)==0 )
				{
					ifail=FVE_create_parmInt(parmInfoStruct,counter,&parmDefItem,&parmDefRev);
				}

				if( tc_strcmp(type ,FVE_ParmDefSEDTYPE)==0 )
				{
					ifail=FVE_create_parmSed(parmInfoStruct,counter,&parmDefItem,&parmDefRev);
				}
				if( tc_strcmp(type ,FVE_ParmDefStrTYPE)==0 )
				{
					ifail=FVE_create_parmStr(parmInfoStruct,counter,&parmDefItem,&parmDefRev);
				}
				if( tc_strcmp(type ,FVE_ParmDefHexTYPE)==0 )
				{
					ifail=FVE_create_parmHex(parmInfoStruct,counter,&parmDefItem,&parmDefRev);
				}

			}
			if(parmDefItem != NULLTAG && parmDefRev != NULLTAG)
			{
				successCntParameter++;
				TC_write_syslog("object %s created successfully \n",parmInfoStruct[counter].name);
				fprintf(logfileptr,"Status: Successful.\n");
				if(parmInfoStruct[counter].descr && tc_strlen(parmInfoStruct[counter].descr)>0)
				{
					if(tc_strlen(parmInfoStruct[counter].descr)>240)
					{
						//Description is more than the specified length. Refer to the comment filed for full description
						if(tc_strlen(parmInfoStruct[counter].descr)<=2000)
						{
							fprintf(logfileptr,"WARNING: Description is more than the specified length. Refer to the extended description field for full description.\n");
							ifail=FV_set_stringValue_object(parmDefRev,object_descPROP,"Description is more than the specified length. Refer to the extended description field for full description");
							if(ifail != ITK_ok)
								ifail=ITK_ok;
							
							ifail=FV_set_stringValue_object(parmDefItem,FVE_CommentPROP,parmInfoStruct[counter].descr);
							if(ifail != ITK_ok)
								ifail=ITK_ok;
						}else
						{
							fprintf(logfileptr,"WARNING: Could not set the Description as the length is more than 2000 characters.\n");
						}
					}
				}

				//set the properties on object
				if(parmInfoStruct[counter].faultVal && tc_strlen(parmInfoStruct[counter].faultVal) > 0)
				{
					if(tc_strlen(parmInfoStruct[counter].faultVal)>500)
					{
						fprintf(logfileptr,"WARNING: Could not set the Fault Value as the length is more than 500 characters.\n");
					}else
					{
						ifail=FV_set_stringValue_object(parmDefRev,FVE_FaultValuePROP,parmInfoStruct[counter].faultVal);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
				}

				if(parmInfoStruct[counter].moduleManf && tc_strlen(parmInfoStruct[counter].moduleManf)> 0)
				{
					if(tc_strlen(parmInfoStruct[counter].moduleManf)> 10)
					{
						fprintf(logfileptr,"WARNING: Could not set the Module Manufacturer Indicator Value as the length is more than 10 characters.\n");
					}else
					{
						ifail=FV_set_stringValue_object(parmDefRev,FVE_ModulemanfIndPROP,parmInfoStruct[counter].moduleManf);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
				}


				if(parmInfoStruct[counter].inhaleExhale && tc_strlen(parmInfoStruct[counter].inhaleExhale)> 0)
				{
					if(tc_strlen(parmInfoStruct[counter].inhaleExhale)> 10)
					{
						fprintf(logfileptr,"WARNING: Could not set the Inhale/Exhale Indicator Value as the length is more than 10 characters.\n");
					}else
					{
						ifail=FV_set_stringValue_object(parmDefRev,FVE_InhaleExhaleIndPROP,parmInfoStruct[counter].inhaleExhale);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
				}

				if(parmInfoStruct[counter].asBuiltVehOp && tc_strlen(parmInfoStruct[counter].asBuiltVehOp)> 0)
				{
					if(tc_strlen(parmInfoStruct[counter].asBuiltVehOp)> 10)
					{
						fprintf(logfileptr,"WARNING: Could not set the As-built/Vehicle Operations Value as the length is more than 10 characters.\n");
					}else
					{
						ifail=FV_set_stringValue_object(parmDefRev,FVE_AsBuiltVehOpsPROP,parmInfoStruct[counter].asBuiltVehOp);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
				}

				//FCSD Customer Preference
				if(parmInfoStruct[counter].fcsdCustPref && tc_strlen(parmInfoStruct[counter].fcsdCustPref) > 0)
				{
					if(tc_strlen(parmInfoStruct[counter].fcsdCustPref)>10)
					{
						fprintf(logfileptr,"WARNING: Could not set the FCSD Customer Preference Value as the length is more than 10 characters.\n");
					}else
					{
						ifail=FV_set_stringValue_object(parmDefRev,FVE_FCSDCustPrefPROP,parmInfoStruct[counter].fcsdCustPref);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
				}

				if(parmInfoStruct[counter].restricted && tc_strlen(parmInfoStruct[counter].restricted)> 0)
				{
					if(tc_strlen(parmInfoStruct[counter].restricted) > 20)
					{
						fprintf(logfileptr,"WARNING: Could not set the Restricted Value as the length is more than 20 characters.\n");
					}else
					{
						ifail=FV_set_stringValue_object(parmDefRev,FVE_RestrictedPROP,parmInfoStruct[counter].restricted);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
				}

				//Domain data has to be displayed in “User Comments” field only for discrete arrays (mapped to string type). 
				if( (tc_strcmp(type ,FVE_ParmDefStrTYPE)==0 ) && ( (parmInfoStruct[counter].structureOfData && tc_strlen(parmInfoStruct[counter].structureOfData )> 0 && ( (tc_strcmp(FV_trim_blanks(parmInfoStruct[counter].structureOfData ),Array1DInfo)==0) ||
										                                                     (tc_strcmp(FV_trim_blanks(parmInfoStruct[counter].structureOfData ),Array2DInfo)==0)  ||
																							 (tc_strcmp(FV_trim_blanks(parmInfoStruct[counter].structureOfData ),Lookup1DInfo)==0) ||
																							 (tc_strcmp(FV_trim_blanks(parmInfoStruct[counter].structureOfData ),Lookup2DInfo)==0)))) )
				{
					if(parmInfoStruct[counter].domainElDescr && tc_strlen(parmInfoStruct[counter].domainElDescr) <= 2000)
					{
						//get the domain element name , value and description
						if( (parmInfoStruct[counter].domainElName != NULL) && (tc_strlen(parmInfoStruct[counter].domainElName )> 0))
						{
							split_the_string(parmInfoStruct[counter].domainElName,COMMA_DELIM,&cntDomainElName,&valDomainElName);
						}

						//check for domain element values
						if( (parmInfoStruct[counter].domainElVal != NULL) && (tc_strlen(parmInfoStruct[counter].domainElVal )> 0))
						{
							//get the valid values
							split_the_string(parmInfoStruct[counter].domainElVal,COMMA_DELIM,&cntDomainElVal,&valDomainElVal);
						}

						if( (parmInfoStruct[counter].domainElDescr) && (tc_strlen(parmInfoStruct[counter].domainElDescr )> 0))
						{
							// Use strstr-based function to parse value string with full delimiter string. 
							ifail=FV_parse_string_with_string(parmInfoStruct[counter].domainElDescr, CSV_DOMAINDESCR_DELIMITER, &cntDomainElDescr, &valDomainElDescr);
						}
						if(cntDomainElName == cntDomainElVal && cntDomainElVal==cntDomainElDescr)
						{
							if( (valDomainElName[0]) && (tc_strlen(valDomainElName[0])> 0) && 
								(valDomainElVal[0]) && (tc_strlen(valDomainElVal[0])> 0) &&
								(valDomainElDescr[0]) && (tc_strlen(valDomainElDescr[0])> 0))
							{
								finalStrDD= (char*) MEM_alloc((int)(strlen(valDomainElName[0])+ strlen(CSV_DOMAINDESCR_DELIMITER)+strlen(valDomainElVal[0])+ strlen(CSV_DOMAINDESCR_DELIMITER)+strlen(valDomainElDescr[0]) +1)* sizeof(char));
								tc_strcpy(finalStrDD,FV_trim_blanks(valDomainElName[0]));
								tc_strcat(finalStrDD,":");
								tc_strcat(finalStrDD,FV_trim_blanks(valDomainElVal[0]));
								tc_strcat(finalStrDD,":");
								tc_strcat(finalStrDD,FV_trim_blanks(valDomainElDescr[0]));
								for(index=1;index<cntDomainElName;index++)
								{
									if( (valDomainElName[index]) && (tc_strlen(valDomainElName[index])> 0) && 
									(valDomainElVal[index]) && (tc_strlen(valDomainElVal[index])> 0) &&
									(valDomainElDescr[index]) && (tc_strlen(valDomainElDescr[index])> 0))
									{
										finalStrDD= (char*) MEM_realloc(finalStrDD,(int)(strlen(finalStrDD)+tc_strlen(FV_trim_blanks(valDomainElName[index]))+tc_strlen(CSV_DOMAINDESCR_DELIMITER)
										                                                               +tc_strlen(FV_trim_blanks(valDomainElVal[index]))+tc_strlen(CSV_DOMAINDESCR_DELIMITER)
																									   +tc_strlen(FV_trim_blanks(valDomainElDescr[index]))+tc_strlen("\n")+1)* sizeof(char));
										tc_strcat(finalStrDD,"\n");
										tc_strcat(finalStrDD,FV_trim_blanks(valDomainElName[index]));
										tc_strcat(finalStrDD,":");
										tc_strcat(finalStrDD,FV_trim_blanks(valDomainElVal[index]));
										tc_strcat(finalStrDD,":");
										tc_strcat(finalStrDD,FV_trim_blanks(valDomainElDescr[index]));
									}
									tc_strcat(finalStrDD ,'\0');
									AM__set_application_bypass(TRUE);
									ITK(AOM_refresh(parmDefRev,TRUE))
									ifail=AOM_set_value_string(parmDefRev,FVE_CommentsPROP,finalStrDD);
									if(ifail != ITK_ok)
										ifail=ITK_ok;
									ITK(AOM_save(parmDefRev))
									ITK(AOM_refresh(parmDefRev,FALSE))
									AM__set_application_bypass(FALSE);
								}//for
							}//if
							FVE_FREE_ARRAY(valDomainElName,cntDomainElName)
							cntDomainElName=0;
							FVE_FREE_ARRAY(valDomainElVal,cntDomainElVal)
							cntDomainElVal=0;
							FVE_FREE_ARRAY(valDomainElDescr,cntDomainElDescr)
							cntDomainElDescr=0;
							FVE_FREE(finalStrDD)
						}
					}//else
					else if(parmInfoStruct[counter].domainElDescr && tc_strlen(parmInfoStruct[counter].domainElDescr) > 2000)
					{
						fprintf(logfileptr,"WARNING: Could not set the Domain Description as the length is more than 2000 characters.\n");
					}
				}
				
				/*From TC9  : sed also contains entry for domain description along with  domain name and domain value.So no need
				  to store domain description entry on  FVE_comments attribute*/
				/*
				if(parmInfoStruct[counter].domainElDescr && tc_strlen(parmInfoStruct[counter].domainElDescr) <= 1024)
				{
					ifail=split_the_string(parmInfoStruct[counter].domainElDescr,COMMA_DELIM,&newCntDD,&newDDNames);

					if(newDDNames && tc_strlen(*newDDNames)> 0)
					{
						finalStrDD= (char*) MEM_alloc((int)(strlen(newDDNames[0])+1)* sizeof(char));
						tc_strcpy(finalStrDD,FV_trim_blanks(newDDNames[0]));
						for(index=1;index<newCntDD;index++)
						{
							finalStrDD= (char*) MEM_realloc(finalStrDD,(int)(strlen(finalStrDD)+tc_strlen(FV_trim_blanks(newDDNames[index]))+tc_strlen("\n")+1)* sizeof(char));
							tc_strcat(finalStrDD,"\n");
							tc_strcat(finalStrDD,FV_trim_blanks(newDDNames[index]));
						}
						tc_strcat(finalStrDD ,'\0');
						AM__set_application_bypass(TRUE);
						ITK(AOM_refresh(parmDefRev,TRUE))
						ifail=AOM_set_value_string(parmDefRev,FVE_CommentsPROP,finalStrDD);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
						ITK(AOM_save(parmDefRev))
						ITK(AOM_refresh(parmDefRev,FALSE))
						AM__set_application_bypass(FALSE);
					}

					FVE_FREE_ARRAY(newDDNames,newCntDD)
					newCntDD=0;
					FVE_FREE(finalStrDD)
				}else if(parmInfoStruct[counter].domainElDescr && tc_strlen(parmInfoStruct[counter].domainElDescr) > 1024)
				{
					fprintf(logfileptr,"WARNING: Could not set the Domain Description as the length is more than 1024 characters.\n");
				}
				*/

				//set size
				FV_set_uifValue_object(parmDefRev,sizePROP,parmInfoStruct[counter].size);
				if(ifail != ITK_ok)
					ifail=ITK_ok;

				//set section number
				if(parmInfoStruct[counter].configGrp && tc_strlen(parmInfoStruct[counter].configGrp)> 0)
				{
					if(tc_strlen(parmInfoStruct[counter].configGrp) > 128)
					{
						fprintf(logfileptr,"WARNING: Could not set Configuration Group as the length is more than 128 characters.\n");
					}else
					{
						
                        // Check if given Part Type is valid lov value
                        ITK(LOV_find_attached_prop(ParmDefRevisionTYPE, fv9PartTypePROP, &partTypeLovTag))
                        if(partTypeLovTag != NULLTAG)
                            ITK(LOV_is_value_valid_string(partTypeLovTag, parmInfoStruct[counter].configGrp, &isPartTypeValValid))
                        if(isPartTypeValValid)
                        {
                            ITK(FV_set_stringValue_object(parmDefRev,fv9PartTypePROP,parmInfoStruct[counter].configGrp))
                            // On creation of new Parameter Defintion, its configuration group value should be set on ECCT Project
                            // & Parameter Dictionary.
                            if(primeDicRevision != NULLTAG)
                                ITK(FV_check_set_value_string_at(primeDicRevision, fv9PartTypeListPROP,  parmInfoStruct[counter].configGrp))
                            else
                                ITK(FV_check_set_value_string_at(dicRevTag, fv9PartTypeListPROP,  parmInfoStruct[counter].configGrp))
                        }
                        else
                        {
                           fprintf(logfileptr,"WARNING: Could not set Configuration Group as \"%s\" is not a valid value. \n", parmInfoStruct[counter].configGrp);
                        }
					}
				}

				if(isDictionary)
				{
					if(topDicBomLine && orgBlTag)
					{
						//Change Management : release this revision with definition approved status.
						ITK(FV_set_object_status(parmDefRev,"Definition Approved",TRUE,&defAppStatusTag))
						ITK(BOM_line_add(orgBlTag, NULLTAG, parmDefRev, NULLTAG, &parmDefBl))
						ITK(BOM_save_window(windowDic))
						TC_write_syslog("\n In %s: Added ParmDefBomLine in the Structure ", function_name);
					}
				}
				if(isECCTProjectRev)
				{
					//prime Dictionary Structure
					if(topBlPrimeDic)
					{
					    //Change Management : release this  revision with definition approved status.
						ITK(FV_set_object_status(parmDefRev,"Definition Approved",TRUE,&defAppStatusTag))
						ITK(BOM_line_add(topBlPrimeDic, NULLTAG, parmDefRev, NULLTAG, &parmDefBl))
						if(windowPrimeDic)
							ITK(BOM_save_window(windowPrimeDic))
						TC_write_syslog("\n In %s: Added ParmDefBomLine in the Structure ", function_name);
					}
					//repository structure
                    // isParmTypeSame = true,   indicates this function is not called due to parameter type change on update.
                    // Parameter type change on update is handled in sync function.
                    // If group info is provided in csv file then, handle addition of new parameter usage
                    // else it is handled in sync function.
					if(isParmTypeSame && topBlECCTPrj && parmInfoStruct[counter].groupName && tc_strlen(parmInfoStruct[counter].groupName) > 0)
					{
						//check if parmInfoStruct[counter].groupName i.e. groupName exist below repository structure .
				        //If it exists , add usage object below grou else creation & addition is handled in sync function.
                        ifail=FV_get_bomLine_withName(topBlECCTPrj,parmInfoStruct[counter].groupName,&tagGroupBl);
                        if(tagGroupBl)
						{
                            //create parameter usage object for the parmDefRev
						    if( tc_strcmp(type ,FVE_ParmDefDblTYPE)==0)
						    {
							    ifail=FV_create_parameter_usage_instance(FV9ParmDfDblUsgTYPE,parmDefItem,fv9RefParmDefPROP, parmDefRev, 
                                fv9RefParmDefRevPROP,&parmDefUsgItemRev);
						    }
						    if( tc_strcmp(type ,FVE_ParmDefIntTYPE)==0 )
						    {
							    ifail=FV_create_parameter_usage_instance(FV9ParmDfIntUsgTYPE, parmDefItem, fv9RefParmDefPROP, parmDefRev, 
                                fv9RefParmDefRevPROP,&parmDefUsgItemRev);
						    }
						    if( tc_strcmp(type ,FVE_ParmDefSEDTYPE)==0 )
						    {
							    ifail=FV_create_parameter_usage_instance(FV9ParmDfSEDUsgTYPE,parmDefItem,fv9RefParmDefPROP, parmDefRev, 
                                fv9RefParmDefRevPROP,&parmDefUsgItemRev);
						    }
						    if( tc_strcmp(type ,FVE_ParmDefStrTYPE)==0 )
						    {
							    ifail=FV_create_parameter_usage_instance(FV9ParmDfStrUsgTYPE,parmDefItem,fv9RefParmDefPROP, parmDefRev, 
                                fv9RefParmDefRevPROP,&parmDefUsgItemRev);
						    }
						    if( tc_strcmp(type ,FVE_ParmDefHexTYPE)==0 )
						    {
							    ifail=FV_create_parameter_usage_instance(FV9ParmDfHexUsgTYPE,parmDefItem,fv9RefParmDefPROP, parmDefRev, 
                                fv9RefParmDefRevPROP,&parmDefUsgItemRev);
						    }
						    if(parmDefUsgItemRev)
						    {
						        //Change Management : release this  revision with definition approved status.
							    ITK(FV_set_object_status(parmDefUsgItemRev,"Definition Approved",TRUE,&defAppStatusTag))
							    AM__set_application_bypass(TRUE);
    							
							    // If update & parent is released, revise struture up the hierarchy before adding new parameter usage.
                                if(isRevise)
                                {
                                    tag_t  parentRevTag = NULLTAG;
                                    char** parentStatus = NULL;

                                    ITK(AOM_ask_value_tag(tagGroupBl,bl_revisionPROP, &parentRevTag))
                                    ITK(FV_ask_release_status(parentRevTag,&parentStatus))
                                    if(parentStatus != NULL)
                                    {
                                        ifail = FV_revise_bomline_and_limited_parents(tagGroupBl,
                                                                        topBlECCTPrj,
                                                                        windowECCTPrj,
                                                                        &revisedObjsCnt,
                                                                        &revisedObjs,
                                                                        &newAddedGrpLine,
                                                                        TRUE);
                                        if(newAddedGrpLine != NULLTAG)
                                        {
                                            tagGroupBl = newAddedGrpLine;
                                            ITK(AOM_ask_value_tag(tagGroupBl,bl_revisionPROP, &parentRevTag))

                                            // After revising, status is removed from parent.
                                            // This is done to handle cases where parameter usages are updated & added under same parent
                                            // e.g. 1. If one new parameter P1 added under Parent1 & P2 updated under Parent1.
                                            // So if we released Parent1 after revising P1 & Parent1, then in sync function Parent1
                                            // will be again revised while updating P2. So here we keep Parent in WIP status &
                                            // once sync is done we release all parameters in one go.
                                            ITK(FV_clear_object_status(parentRevTag, DICTN_LOCK_STATUSTYPE))
                                            ITK(FV_add_unique_tag_to_array(revisePendingCnt, revisePendingObjects, parentRevTag))
                                        }
                                    }
                                }
                                ITK(AOM_ask_value_tag(tagGroupBl,bomAttr_lineItemRevTag,&itemRevGrpTag))
							    ifail=FV_check_bom_views_exist(itemRevGrpTag);

							    ITK(BOM_line_add(tagGroupBl, NULLTAG, parmDefUsgItemRev, NULLTAG, &parmUsageBl))
                                if(windowECCTPrj)
							        ITK(BOM_save_window(windowECCTPrj))
						        TC_write_syslog("\n In %s: Added Parmeter usage object Structure ", function_name);
							    AM__set_application_bypass(FALSE);
                            }
						}
					}
				}
				//Create MSA Form and attach it to Parameter Def Revision.
                AM__set_application_bypass(TRUE);
				ifail=FVE_create_MSAForm(parmInfoStruct,counter,parmDefRev,&msaFormTag);
                AM__set_application_bypass(FALSE);
				//get the process object Name from structure parmInfoStr. Check for sink and source
				//Search these process object information in another structure
				if(ignoreProcessFile == FALSE)
				{
					fprintf(logfileptr,"Checking for the process objects...\n");
					if(isDictionary)
					{
						ifail=FVE_get_ProcessObjectInfo(parmInfoStruct,counter,parmDefBl,dicRevTag,windowDic);
					}
					if(isECCTProjectRev)
					{
						//add process object incontext of Prime Dictionary for parameter definitions
						ifail=FVE_get_ProcessObjectInfo(parmInfoStruct,counter,parmDefBl,primeDicRevision,windowPrimeDic);
					}

				}
			}else
			{
				failureCntParameter++;
				TC_write_syslog("object %s failed to create \n",parmInfoStruct[counter].name);
				fprintf(logfileptr,"Status: Failed.\n");
				EMH_ask_error_text (ifail, &message);
				//fprintf(logfileptr,"ERROR: %s\n",message);

				//Create seperate log file for failure objects.
				//update log file
				if(logFilePtrFailure == NULL)
				{
					logFilePtrFailure = fopen(file_pathFailure, "w+");
					fprintf(logFilePtrFailure,"Failed parameter List\n");
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"\n");

					if(logfileptr)
					{
						fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
						//time( &clock );
						//fprintf(logFilePtrFailure,"Start time: %s\n", ctime(&clock));
					}
					fprintf(logFilePtrFailure,"Logged in successfully.\n");
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"Dictionary Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
					fprintf(logFilePtrFailure,"\n");
				}
				ifail=FVE_update_log_file(logFilePtrFailure,parmInfoStruct,counter);
				fprintf(logFilePtrFailure,"Status: Failed.\n");
				//fprintf(logFilePtrFailure,"ERROR: %s\n",message);
				fprintf(logFilePtrFailure,"\n");

			}
		}else
		{
			//required attributes are missing
			if(logFilePtrFailure == NULL)
			{
					logFilePtrFailure = fopen(file_pathFailure, "w+");
					fprintf(logFilePtrFailure,"Failed parameter List\n");
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"\n");

					if(logfileptr)
					{
						fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
						//time( &clock );
						//fprintf(logFilePtrFailure,"Start time: %s\n", ctime(&clock));
					}
					fprintf(logFilePtrFailure,"Logged in successfully.\n");
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
					fprintf(logFilePtrFailure,"\n");
					fprintf(logFilePtrFailure,"Dictionary Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
					fprintf(logFilePtrFailure,"\n");
			}
			ifail=FVE_validate_required_attributes(logFilePtrFailure,parmInfoStruct,counter,&isReqAttrPresent);
			fprintf(logFilePtrFailure,"\n");
			failureCntParameter++;
		}
	}//name != NULL

	FVE_FREE(type)
	FVE_FREE(name)
    FVE_FREE(paramGrpId)
	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}

/*
function to update log file contents
If all required attributes are present , generate the log file with  required attributes.
*/
int FVE_update_log_file(FILE *filePtr,struct FVEParmDefInfostruct *parmInfoStruct,int counter)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_update_log_file";
	char*       type				=	NULL;
	int			cntDomainEl			=	0;
	char		**valDomainEl		=	NULL;
	int			cntDomainElVal		=	0;
	char		**valDomainElVal	=	NULL;
	logical		lgDomainElName		=	false;
	logical		lgDomainElValue		=	false;

	TC_write_syslog("\n Enter function %s",function_name);
	if(filePtr)
	{

		type=parmInfoStruct[counter].type;

		fprintf(filePtr,"Parameter Name: %s\n",parmInfoStruct[counter].name);
		if(parmInfoStruct[counter].descr && tc_strlen(parmInfoStruct[counter].descr)>0)
		{
			fprintf(filePtr,"Description: %s\n",parmInfoStruct[counter].descr);
		}else
		{
			fprintf(filePtr,"Description: \n");
		}


		if(type && tc_strlen(type) > 0 )
		{
			fprintf(filePtr,"Type: %s\n",type);
			if( (tc_strcmp(type,FVE_ParmDefDblTYPE)== 0) ||
			(tc_strcmp(type,FVE_ParmDefIntTYPE)== 0))
			{
				if(parmInfoStruct[counter].engUnit != NULL && tc_strlen(parmInfoStruct[counter].engUnit) > 0)
				{
					if(tc_strcmp(parmInfoStruct[counter].engUnit,UNITLESS_UNIT) == 0)
					{
						fprintf(filePtr,"Unit: %s\n",NONE_UNIT);
					}else
					{
						fprintf(filePtr,"Unit: %s\n",parmInfoStruct[counter].engUnit);
					}
				}else
				{
					fprintf(filePtr,"Unit: %s\n",NONE_UNIT);
				}
			}
		}else
		{
			fprintf(filePtr,"Type: \n");
		}

		if(tc_strcmp(parmInfoStruct[counter].type,FVE_ParmDefSEDTYPE)== 0)
		{
			//check for domain element name
			if( (parmInfoStruct[counter].domainElName != NULL) && (tc_strlen(parmInfoStruct[counter].domainElName )> 0))
			{
				//get the rows
				split_the_string(parmInfoStruct[counter].domainElName,COMMA_DELIM,&cntDomainEl,&valDomainEl);
				if((cntDomainEl > 0) && (valDomainEl != NULL))
				{
					lgDomainElName=true;
				}
			}
			//check for domain element values
			if( (parmInfoStruct[counter].domainElVal != NULL) && (tc_strlen(parmInfoStruct[counter].domainElVal )> 0))
			{
				//get the valid values
				split_the_string(parmInfoStruct[counter].domainElVal,COMMA_DELIM,&cntDomainElVal,&valDomainElVal);
				if((cntDomainElVal > 0) && (valDomainElVal != NULL))
				{
					lgDomainElValue=true;
				}
			}
			if(lgDomainElName && lgDomainElValue && cntDomainEl == cntDomainElVal)
			{
				fprintf(filePtr,"No Of Rows/Columns: %d%s%d\n",cntDomainEl,"X",parmInfoStruct[counter].colCnt);
			}

		}else
		{
			fprintf(filePtr,"No Of Rows/Columns: %d%s%d\n",parmInfoStruct[counter].rowCnt,"X",parmInfoStruct[counter].colCnt);
		}

		if(type && tc_strlen(type)> 0 && tc_strcmp(type,FVE_ParmDefDblTYPE)== 0)
		{
			fprintf(filePtr,"Numerator: %s\n",parmInfoStruct[counter].numerator);
			fprintf(filePtr,"Denominator: %s\n",parmInfoStruct[counter].denominator);
			fprintf(filePtr,"Precision: %s\n",parmInfoStruct[counter].precision);
		}

		if(type && tc_strlen(type) > 0 )
		{
			if( (tc_strcmp(type,FVE_ParmDefDblTYPE)== 0) ||
				(tc_strcmp(type,FVE_ParmDefIntTYPE)== 0))
			{
				fprintf(filePtr,"Min Value: %s\n",	FV_trim_invalidChars(parmInfoStruct[counter].minVal));
				fprintf(filePtr,"Max Value: %s\n",	FV_trim_invalidChars(parmInfoStruct[counter].maxVal));
				fprintf(filePtr,"Initial Value: %s\n",FV_trim_invalidChars(parmInfoStruct[counter].initVal));
				//fprintf(filePtr,"Initial Value: %s\n", strParmInfo[counter].initVal);
			}
		}

		if( type && tc_strlen(type)> 0 && tc_strcmp(type,FVE_ParmDefSEDTYPE)==0)
		{
			if(parmInfoStruct[counter].implDataType != NULL && tc_strlen(parmInfoStruct[counter].implDataType)>0)
			{
				fprintf(filePtr,"Implementation Data Type: %s\n",parmInfoStruct[counter].implDataType);
			}
			else
			{
				fprintf(filePtr,"Implementation Data Type: \n");
			}

			fprintf(filePtr,"Valid Value: %s\n",	 parmInfoStruct[counter].domainElVal);
			fprintf(filePtr,"Initial Value: %s\n",parmInfoStruct[counter].initVal);

		}
	}

	FVE_FREE(valDomainEl)
	cntDomainEl=0;
	FVE_FREE(valDomainElVal);
	cntDomainElVal=0;

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}


/*
	Create Parameter Definitions of type Doublle
	Default values
		if the Eng Unit is empty, we set it to “None”
		if rows , columns value is zero from csv file , rows=columns=1;
*/

int FVE_create_parmDbl(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_parmDbl";

    tag_t	dbTag				=	NULLTAG;
	tag_t   revisionTag			=	NULLTAG;
    tag_t	dbTypeTag			=	NULLTAG;
    tag_t	dbRevTypeTag		=	NULLTAG;
	tag_t	createInputTag		=	NULLTAG;
    tag_t	createRevInputTag	=	NULLTAG;

	tag_t	tableTypeTag		=	NULLTAG;
	tag_t	tableDefTypeTag		=	NULLTAG;
    tag_t	tableDefInputTag	=	NULLTAG;
	tag_t	tableLabelTypeTag	=	NULLTAG;
	tag_t	tableRowLabelInputTag	=	NULLTAG;
	tag_t	tableColLabelInputTag	=	NULLTAG;

	char	* rowCountTable		=	NULL;
	char	* colCountTable		=	NULL;
	char       *rowNumber       =   NULL;
	char       *colNumber       =   NULL;

	char	*revTypeName		=	NULL;

	int		rows			=	0;
	int		columns			=	0;
	int		iCounter=0;
	int		jCounter	=	0;

	tag_t	tableInputTagMin	=	NULLTAG;
	tag_t	tableInputTagMax	=	NULLTAG;
	tag_t	tableInputTagInitial=	NULLTAG;

	tag_t	tableCellTypeTag	=	NULLTAG;
	tag_t	tableCellInputTagMin	=	NULLTAG;
	tag_t	tableCellInputTagMax	=	NULLTAG;
	tag_t	tableCellInputTagInitial=	NULLTAG;

	char       intRowBuf[FV_INTEGER_LEN+1] = {'\0'};
	char       intColBuf[FV_INTEGER_LEN+1] = {'\0'};

	tag_t*      cellInputTags = NULL;
	int         cellCnt = 0;

	//default values
	//char	*issigned[]			=	{"True"};
	//char	*tolerance[]		=	{"1"};
	char	*issigned[]			=	{""};
	char	*tolerance[]		=	{""};
	char	*objName[]			=	{""};
	char	*objDesc[]			=	{""};
	char	*engUnit[]			=	{""};
    char	*usage[]			=	{""};
    char	*ecuacr[]			=	{""};
	char	*parType[]			=	{""};

	char	*numarator[]		=	{""};
	char	*denominator[]		=	{""};
	char	*precision[]		=	{""};

	char	* initVal[]		=	{""};
	char	* maxVal[]		=	{""};
	char	* minVal[]		=	{""};
	int		minimumVal		=	0;
	int		maximumVal		=	0;
	int		initialVal		=	0;

	int		rowLabelCnt		=	0;
	char	**rowLabelNames	=	NULL;
	int		colLabelCnt		=	0;
	char	**colLabelNames	=	NULL;
	int     initValArrayCnt	=	0;
	char	**initValArray	=	NULL;
	int		dummyInitValArrayCnt	=	0;
	char	**dummyInitValArray		=	NULL;
	int     minValArrayCnt	=	0;
	char	**minValArray	=	NULL;
	int     dummyMinValArrayCnt	=	0;
	char	**dummyMinValArray	=	NULL;
	int     maxValArrayCnt	=	0;
	char	**maxValArray	=	NULL;
	int     dummyMaxValArrayCnt	=	0;
	char	**dummyMaxValArray	=	NULL;
	char	*commaDelimExist	=	NULL;
	char	*semiColonDelimExist	=	NULL;
	int			incrCounter =0;
	logical		isMinNegative		=	false;
	logical		isMaxNegative		=	false;
	logical		isInitNegative		=	false;

	char *indexFirstMin				=NULL;
	char *indexFirstMax				=NULL;
	char *indexFirstInit			=NULL;
	char line_starts_withMin[128]	= "";
	char line_starts_withMax[128]	= "";
	char line_starts_withInit[128]	= "";
	int	index=0;

	TC_write_syslog("\n Enter function %s",function_name);

	if(parmInfoStruct[counter].rowCnt != 0)
		rows=parmInfoStruct[counter].rowCnt;

	if(parmInfoStruct[counter].colCnt != 0)
		columns=parmInfoStruct[counter].colCnt;


	*objName			=	parmInfoStruct[counter].name;
	*objDesc=parmInfoStruct[counter].descr;
	*usage=parmInfoStruct[counter].paraUsage;
	*ecuacr	=ecuAcronym;

	if(parmInfoStruct[counter].paraType && tc_strlen(parmInfoStruct[counter].paraType)> 0)
	{
		*parType=parmInfoStruct[counter].paraType;
	}else
	{
		*parType=PARAMETER_TYPE_DEFAULT_VAL;
	}
	if(parmInfoStruct[counter].engUnit != NULL && tc_strlen(parmInfoStruct[counter].engUnit) > 0)
	{
		if(tc_strcmp(parmInfoStruct[counter].engUnit,UNITLESS_UNIT) == 0)
		{
			*engUnit=NONE_UNIT;
		}else
		{
			*engUnit=parmInfoStruct[counter].engUnit;
		}
	}else
	{
		*engUnit=NONE_UNIT;
	}
	*numarator=parmInfoStruct[counter].numerator;
	*denominator=parmInfoStruct[counter].denominator;
	*precision=parmInfoStruct[counter].precision;

	if(parmInfoStruct[counter].tolerance && tc_strlen(parmInfoStruct[counter].tolerance)> 0)
	{
		*tolerance=parmInfoStruct[counter].tolerance;
		//printf("\n tolerance value from csv file \n");
	}else if(toleranceExistInConfigFile && tc_strlen(toleranceExistInConfigFile)> 0)
	{
		*tolerance=toleranceExistInConfigFile;
		//printf("\n tolerance value from configuration file \n");
	}else
	{
		*tolerance="1";
		//printf("\n defaulting tolerance to 1\n");
	}

	/*	Get the Row Labels , Column Lables and Min/Max/Initial Values based on structure of data
		if structure of data is ,
		scalar    - matrix is 1X1 (sample file didnt provide value for rows/columns , rowLabels/columnLabels in such case)
		2D Lookup - get both row lables and column Labels
		1D Lookup - get only column labels
	*/
	if(parmInfoStruct[counter].structureOfData && tc_strlen(parmInfoStruct[counter].structureOfData)> 0)
	{
		if( tc_strcmp(parmInfoStruct[counter].structureOfData,ScalarInfo) == 0)
		{
			*initVal	=	 parmInfoStruct[counter].initVal;
			*maxVal		=	 parmInfoStruct[counter].maxVal;
			*minVal		=	 parmInfoStruct[counter].minVal;

			//get the first character for each value , if it starts with minus sign , isSigned=TRUE.
			//minimumVal	=	atoi(parmInfoStruct[counter].minVal);
			indexFirstMin=strchr(parmInfoStruct[counter].minVal,'-');
			index = (int)(indexFirstMin - parmInfoStruct[counter].minVal);
			sprintf(line_starts_withMin,"%.*s",(index+1)-0,&parmInfoStruct[counter].minVal[0]);
			index=0;
			if(tc_strcmp(line_starts_withMin,"-") == 0)
			{
					minimumVal=-1;
			}

			//maximumVal	=	atoi(parmInfoStruct[counter].maxVal);
			indexFirstMax=strchr(parmInfoStruct[counter].maxVal,'-');
			index = (int)(indexFirstMax - parmInfoStruct[counter].maxVal);
			sprintf(line_starts_withMax,"%.*s",(index+1)-0,&parmInfoStruct[counter].maxVal[0]);
			index=0;
			if(tc_strcmp(line_starts_withMax,"-") == 0)
			{
					maximumVal=-1;
			}

			//initialVal	=	atoi(parmInfoStruct[counter].initVal);
			indexFirstInit=strchr(parmInfoStruct[counter].initVal,'-');
			index = (int)(indexFirstInit - parmInfoStruct[counter].initVal);
			sprintf(line_starts_withInit,"%.*s",(index+1)-0,&parmInfoStruct[counter].initVal[0]);
			index=0;
			if(tc_strcmp(line_starts_withInit,"-") == 0)
			{
					initialVal=-1;
			}
			if(minimumVal < 0 || maximumVal < 0 || initialVal < 0)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}
		}
		else if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArrayCnt == rows)
				{
					if(dummyInitValArray && dummyInitValArrayCnt> 0)
					{
						//store this info in initValArrayCnt,&initValArray
						for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
							}
						}
					}
				}//cnt match with rows
				else
				{
					//throw error
				}
			}else
			{
				//Check : if 2d lookup and initial string didnt contains semicolon , its mean its single value or should I throw error
				*initVal	=	 parmInfoStruct[counter].initVal;
				//initialVal	=	atoi(parmInfoStruct[counter].initVal);
				indexFirstInit=strchr(parmInfoStruct[counter].initVal,'-');
				index = (int)(indexFirstInit - parmInfoStruct[counter].initVal);
				sprintf(line_starts_withInit,"%.*s",(index+1)-0,&parmInfoStruct[counter].initVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withInit,"-") == 0)
				{
						initialVal=-1;
				}
				if(initialVal < 0)
				{
					isInitNegative=true;
				}
			}

			//check if semicolon exist in maximum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
				semiColonDelimExist=NULL;
				if(dummyMaxValArrayCnt == rows)
				{
					if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
					{
						//store this info in maxValArrayCnt,maxValArray
						for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
								commaDelimExist=NULL;

							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
							}
						}
					}
				}

			}else
			{
				*maxVal	=	parmInfoStruct[counter].maxVal;
				//maximumVal 	=	atoi(parmInfoStruct[counter].maxVal);
				indexFirstMax=strchr(parmInfoStruct[counter].maxVal,'-');
				index = (int)(indexFirstMax - parmInfoStruct[counter].maxVal);
				sprintf(line_starts_withMax,"%.*s",(index+1)-0,&parmInfoStruct[counter].maxVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMax,"-") == 0)
				{
					maximumVal=-1;
				}
				if(maximumVal < 0)
				{
					isMaxNegative=true;
				}
			}

			//check if semicolon exist in minimum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
				semiColonDelimExist=NULL;
				//store this info in minValArrayCnt,minValArray
				if(dummyMinValArrayCnt == rows)
				{
					if(dummyMinValArrayCnt > 0 && dummyMinValArray)
					{
						for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
							}
						}
					}
				}
			}else
			{
				*minVal	=	parmInfoStruct[counter].minVal;
				//minimumVal 	=	atoi(parmInfoStruct[counter].minVal);
				indexFirstMin=strchr(parmInfoStruct[counter].minVal,'-');
				index = (int)(indexFirstMin - parmInfoStruct[counter].minVal);
				sprintf(line_starts_withMin,"%.*s",(index+1)-0,&parmInfoStruct[counter].minVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMin,"-") == 0)
				{
					minimumVal=-1;
				}
				if(minimumVal < 0)
				{
					isMinNegative=true;
				}
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}

			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}


		}
		else if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array2DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
			//check if semicolon exist in initial value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
				semiColonDelimExist=NULL;
				if(dummyInitValArrayCnt == rows)
				{
					if(dummyInitValArray && dummyInitValArrayCnt> 0)
					{
						//store this info in initValArrayCnt,&initValArray
						for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&initValArrayCnt,&initValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&initValArrayCnt,&initValArray);
							}
						}
					}
				}
			}else
			{
				//Check : if 2d lookup and initial string didnt contains semicolon , its mean its single value or should I throw error
				*initVal	=	 parmInfoStruct[counter].initVal;
				//initialVal	=	atoi(parmInfoStruct[counter].initVal);
				indexFirstInit=strchr(parmInfoStruct[counter].initVal,'-');
				index = (int)(indexFirstInit - parmInfoStruct[counter].initVal);
				sprintf(line_starts_withInit,"%.*s",(index+1)-0,&parmInfoStruct[counter].initVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withInit,"-") == 0)
				{
					initialVal=-1;
				}
				if(initialVal < 0)
				{
					isInitNegative=true;
				}
			}

			//check if semicolon exist in maximum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
				semiColonDelimExist=NULL;
				if(dummyMaxValArrayCnt == rows)
				{
					if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
					{
						//store this info in maxValArrayCnt,maxValArray
						for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&maxValArrayCnt,&maxValArray);
							}
						}
					}
				}
			}else
			{
				*maxVal	=	parmInfoStruct[counter].maxVal;
				//maximumVal 	=	atoi(parmInfoStruct[counter].maxVal);
				indexFirstMax=strchr(parmInfoStruct[counter].maxVal,'-');
				index = (int)(indexFirstMax - parmInfoStruct[counter].maxVal);
				sprintf(line_starts_withMax,"%.*s",(index+1)-0,&parmInfoStruct[counter].maxVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMax,"-") == 0)
				{
					maximumVal=-1;
				}
				if(maximumVal < 0)
				{
					isMaxNegative=true;
				}
			}

			//check if semicolon exist in minimum value string
			semiColonDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(parmInfoStruct[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
				semiColonDelimExist=NULL;
				if(dummyMinValArrayCnt == rows)
				{
					//store this info in minValArrayCnt,minValArray
					if(dummyMinValArrayCnt > 0 && dummyMinValArray)
					{
						for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
						{
							commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
							if(commaDelimExist)
							{
								split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&minValArrayCnt,&minValArray);
								commaDelimExist=NULL;
							}else
							{
								split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&minValArrayCnt,&minValArray);
							}
						}
					}
				}
			}else
			{
				*minVal	=	parmInfoStruct[counter].minVal;
				//minimumVal 	=	atoi(parmInfoStruct[counter].minVal);
				indexFirstMin=strchr(parmInfoStruct[counter].minVal,'-');
				index = (int)(indexFirstMin - parmInfoStruct[counter].minVal);
				sprintf(line_starts_withMin,"%.*s",(index+1)-0,&parmInfoStruct[counter].minVal[0]);
				index=0;
				if(tc_strcmp(line_starts_withMin,"-") == 0)
				{
					minimumVal=-1;
				}
				if(minimumVal < 0)
				{
					isMinNegative=true;
				}
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}

			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}

		}
		else if( tc_strcmp(parmInfoStruct[counter].structureOfData,Lookup1DInfo) == 0)
		{
			//get the row lables
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels) > 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//get the initial Values
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
			}

			//get the min values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),COMMA_DELIM,&minValArrayCnt,&minValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].minVal),"' '",&minValArrayCnt,&minValArray);
			}

			//get the max values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),COMMA_DELIM,&maxValArrayCnt,&maxValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].maxVal),"' '",&maxValArrayCnt,&maxValArray);
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}

			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}


		}
		else if( tc_strcmp(parmInfoStruct[counter].structureOfData,Array1DInfo) == 0)
		{
			//get the rowlables and columnLabels
			if(parmInfoStruct[counter].rowLabels && tc_strlen(parmInfoStruct[counter].rowLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].rowLabels,COMMA_DELIM,&rowLabelCnt,&rowLabelNames);
			}
			if(parmInfoStruct[counter].colLabels && tc_strlen(parmInfoStruct[counter].colLabels)> 0)
			{
				split_the_string(parmInfoStruct[counter].colLabels,COMMA_DELIM,&colLabelCnt,&colLabelNames);
			}

			//get the initial Values
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].initVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),COMMA_DELIM,&initValArrayCnt,&initValArray);
			}else
			{
				split_the_string(FV_trim_invalidChars(parmInfoStruct[counter].initVal),"' '",&initValArrayCnt,&initValArray);
			}

			//get the min values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].minVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].minVal,COMMA_DELIM,&minValArrayCnt,&minValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].minVal,"' '",&minValArrayCnt,&minValArray);
			}

			//get the max values
			commaDelimExist=strstr(FV_trim_blanks(parmInfoStruct[counter].maxVal),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(parmInfoStruct[counter].maxVal,COMMA_DELIM,&maxValArrayCnt,&maxValArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(parmInfoStruct[counter].maxVal,"' '",&maxValArrayCnt,&maxValArray);
			}

			//get the isSigned value based on Min,max and Initial Value
			if(initValArrayCnt > 0 && initValArray)
			{
				for(iCounter=0;iCounter<initValArrayCnt;iCounter++)
				{
					//initialVal	=	atoi(initValArray[iCounter]);
					indexFirstInit=strchr(initValArray[iCounter],'-');
					index = (int)(indexFirstInit - initValArray[iCounter]);
					sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(initValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withInit,"-") == 0)
					{
						initialVal=-1;
					}
					if(initialVal < 0)
					{
						isInitNegative=true;
						break;
					}
				}
			}

			if(maxValArrayCnt > 0 && maxValArray)
			{
				for(iCounter=0;iCounter<maxValArrayCnt;iCounter++)
				{
					//maximumVal	=	atoi(maxValArray[iCounter]);
					indexFirstMax=strchr(maxValArray[iCounter],'-');
					index = (int)(indexFirstMax - maxValArray[iCounter]);
					sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(maxValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMax,"-") == 0)
					{
						maximumVal=-1;
					}
					if(maximumVal < 0)
					{
						isMaxNegative=true;
						break;
					}
				}
			}

			if(minValArrayCnt > 0 && minValArray)
			{
				for(iCounter=0;iCounter<minValArrayCnt;iCounter++)
				{
					//minimumVal	=	atoi(minValArray[iCounter]);
					indexFirstMin=strchr(minValArray[iCounter],'-');
					index = (int)(indexFirstMin - minValArray[iCounter]);
					sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(minValArray[iCounter])[0]);
					index=0;
					if(tc_strcmp(line_starts_withMin,"-") == 0)
					{
						minimumVal=-1;
					}
					if(minimumVal < 0)
					{
						isMinNegative=true;
						break;
					}
				}
			}

			if(isMinNegative || isMaxNegative || isInitNegative)
			{
				*issigned="TRUE";
			}else
			{
				*issigned="FALSE";
			}
		}
	}


	//if(isReqAttrPresent == true)
	//{
		TC_write_syslog("Creating item input object %s\n",parmInfoStruct[counter].name);
		// create item
		ITK(TCTYPE_ask_type(parmInfoStruct[counter].type, &dbTypeTag))
		ITK(TCTYPE_construct_create_input(dbTypeTag, &createInputTag))

		// create item revision
		ITK(FV_strdup_plus(parmInfoStruct[counter].type, 9, &revTypeName))
		tc_strcat(revTypeName, "Revision");
		ITK(TCTYPE_ask_type(revTypeName, &dbRevTypeTag))
		ITK(TCTYPE_construct_create_input(dbRevTypeTag, &createRevInputTag))

		// set revision
		ITK(TCTYPE_set_compound_objects(createInputTag, "revision", 1, &createRevInputTag))

		//TC_write_syslog("Setting item attributes\n");
		// set item attribute
		ITK(TCTYPE_set_create_display_value(createInputTag, object_namePROP, 1, (const char**)objName))
		if(*objDesc && tc_strlen(*objDesc)> 0)
		{
			if(tc_strlen(*objDesc) <=240)
				ITK(TCTYPE_set_create_display_value(createInputTag, object_descPROP, 1, (const char**)objDesc))
		}
		ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ParameterUsagePROP, 1, (const char**)usage))
		ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ECUAcronymPROP, 1, (const char**)ecuacr))
		ITK(TCTYPE_set_create_display_value(createInputTag, parmTypePROP, 1, (const char**)parType))

		//set Revision attributes
		ITK(TCTYPE_set_create_display_value(createRevInputTag, FVE_EngUnitPROP, 1, (const char**)engUnit ))
		ITK(TCTYPE_set_create_display_value(createRevInputTag, "isSigned", 1,  (const char**)issigned))
		ITK(TCTYPE_set_create_display_value(createRevInputTag, resolution_denominatorPROP, 1, (const char**)denominator))
		ITK(TCTYPE_set_create_display_value(createRevInputTag, resolution_numeratorPROP, 1,  (const char**)numarator))
		ITK(TCTYPE_set_create_display_value(createRevInputTag, precisionPROP, 1,  (const char**)precision ))
		ITK(TCTYPE_set_create_display_value(createRevInputTag, tolerancePROP, 1, (const char**)tolerance))

		//TC_write_syslog("Creating table def\n");
		// create table definition
		ITK(TCTYPE_ask_type("TableDefinition", &tableDefTypeTag))
		ITK(TCTYPE_construct_create_input(tableDefTypeTag, &tableDefInputTag))
		rowCountTable = (char*)MEM_alloc((int)(rows + 1) * sizeof(char));
		colCountTable = (char*)MEM_alloc((int)(columns + 1) * sizeof(char));
		sprintf(rowCountTable, "%d", rows);
		sprintf(colCountTable, "%d", columns );
		ITK(TCTYPE_set_create_display_value(tableDefInputTag, "rows", 1, (const char**)&rowCountTable))
		ITK(TCTYPE_set_create_display_value(tableDefInputTag, "cols", 1, (const char**)&colCountTable))
		//free memory
		FVE_FREE(rowCountTable)
		FVE_FREE(colCountTable)

		/*set rowLabels and colLabels
		 create TableLabel definition */
		ITK(TCTYPE_ask_type("TableLabel", &tableLabelTypeTag))
		if(rowLabelNames && rowLabelCnt > 0 && rowLabelCnt==rows)
		{
			//set row labels
			for(iCounter=0;iCounter<rows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;
				//TC_write_syslog ("rowNumber = %s\n",rowNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableRowLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableRowLabelInputTag, "label", 1,(const char **)&rowLabelNames[iCounter]))
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableRowLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "rowLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		}

		 if(colLabelNames && colLabelCnt> 0 && colLabelCnt == columns)
		 {
			//set column labels
			for(iCounter=0;iCounter<columns;iCounter++)
			{
				sprintf(intColBuf, "%d",iCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n",colNumber);
				ITK(TCTYPE_construct_create_input(tableLabelTypeTag, &tableColLabelInputTag))
				ITK(TCTYPE_set_create_display_value(tableColLabelInputTag, "label", 1,(const char **)&colLabelNames[iCounter]))
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableColLabelInputTag))
			}
			ITK(TCTYPE_set_compound_objects(tableDefInputTag, "colLabels", cellCnt, cellInputTags))
			//free memory
			FVE_FREE(cellInputTags)
			cellCnt=0;
		 }

		ITK(TCTYPE_ask_type("Table", &tableTypeTag))

		//set the maximum values for table
		ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMax))
		for(iCounter=0;iCounter<rows;iCounter++)
		{
			sprintf(intRowBuf, "%d",iCounter);
   			rowNumber = intRowBuf;
			//TC_write_syslog ("rowNumber = %s\n",rowNumber);
			for(jCounter=0;jCounter<columns;jCounter++)
			{
				sprintf(intColBuf, "%d",jCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n",colNumber);

				// create table cell
				ITK(TCTYPE_ask_type(TableCellDoubleCLASS, &tableCellTypeTag))
				ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMax))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "row", 1,(const char **)&rowNumber))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "col", 1, (const char **)&colNumber))
				if(maxValArray != NULL && maxValArrayCnt == rows*columns)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[incrCounter]))
					incrCounter++;
				}else if(maxValArray != NULL && maxValArrayCnt == 1)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1,(const char **)&maxValArray[0]))
				}else if(maxValArray == NULL)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMax, "value",1, (const char**)maxVal))
				}
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMax))
			}
		}

		ITK(TCTYPE_set_compound_objects(tableInputTagMax, "definition", 1, &tableDefInputTag))
		// Set array of Table Cell input tags on Table object.
		ITK(TCTYPE_set_compound_objects(tableInputTagMax, "cells", cellCnt, cellInputTags))
		FVE_FREE(cellInputTags)
		cellCnt=0;
		incrCounter=0;

		//Set the minimum values for a table
		ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagMin))
		for(iCounter=0;iCounter<rows;iCounter++)
		{
			sprintf(intRowBuf, "%d",iCounter);
   			rowNumber = intRowBuf;
			//TC_write_syslog ("rowNumber = %s\n",rowNumber);
			for(jCounter=0;jCounter<columns;jCounter++)
			{
				sprintf(intColBuf, "%d",jCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n",colNumber);

				// create table cell
				ITK(TCTYPE_ask_type(TableCellDoubleCLASS, &tableCellTypeTag))
				ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagMin))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "row", 1,(const char **)&rowNumber))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "col", 1,(const char **)&colNumber))
				if(minValArray != NULL && minValArrayCnt == rows*columns)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[incrCounter]))
					incrCounter++;
				}else if(minValArray != NULL && minValArrayCnt ==1)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1,(const char **)&minValArray[0]))
				}else if(minValArray == NULL)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagMin, "value",1, (const char**)minVal))
				}
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagMin))
			}
		}
		ITK(TCTYPE_set_compound_objects(tableInputTagMin, "definition", 1, &tableDefInputTag))
		// Set array of Table Cell input tags on Table object.
		ITK(TCTYPE_set_compound_objects(tableInputTagMin, "cells", cellCnt, cellInputTags))
		FVE_FREE(cellInputTags)
		cellCnt=0;
		incrCounter=0;

		ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagInitial))
		for(iCounter=0;iCounter<rows;iCounter++)
		{
			sprintf(intRowBuf, "%d",  iCounter);
   			rowNumber = intRowBuf;
			//TC_write_syslog ("rowNumber = %s\n", rowNumber );
			for(jCounter=0;jCounter<columns;jCounter++)
			{
				sprintf(intColBuf, "%d",jCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n", colNumber);
				// create table cell
				ITK(TCTYPE_ask_type(TableCellDoubleCLASS, &tableCellTypeTag))
				ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagInitial))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "row", 1,(const char **)&rowNumber))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "col", 1,(const char **)&colNumber))
				if(initValArray != NULL && initValArrayCnt == rows*columns)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[incrCounter]))
					incrCounter++;
				}
				else if(initValArray != NULL && initValArrayCnt == 1)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1,(const char **)&initValArray[0]))
				}else if(initValArray == NULL)
				{
					ITK(TCTYPE_set_create_display_value(tableCellInputTagInitial, "value",1, (const char**)initVal))
				}
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagInitial))
			}
		}
		ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "definition", 1, &tableDefInputTag))
		// Set array of Table Cell input tags on Table object.
		ITK(TCTYPE_set_compound_objects(tableInputTagInitial, "cells", cellCnt, cellInputTags))
		FVE_FREE(cellInputTags)
		incrCounter=0;


		TC_write_syslog("Setting item revision compound objects\n");
		//set revision attribute
		ITK(TCTYPE_set_compound_objects(createRevInputTag, "initialValues", 1, &tableInputTagInitial))
		ITK(TCTYPE_set_compound_objects(createRevInputTag, "minValues",1, &tableInputTagMin))
		ITK(TCTYPE_set_compound_objects(createRevInputTag, "maxValues", 1, &tableInputTagMax))
		ITK(TCTYPE_set_compound_objects(createRevInputTag, "tableDefinition", 1, &tableDefInputTag))

		//TC_write_syslog("Creating object\n");
		// create the object

		ITK(TCTYPE_create_object(createInputTag, &dbTag))
		if(dbTag != NULLTAG)
		{
			ITK(AOM_save(dbTag))
			ITK(AOM_refresh(dbTag, false) )
			*parmDefItem=dbTag;

			// Get the new item revision tag.
			ITK(ITEM_ask_latest_rev(dbTag, &revisionTag))
			if(revisionTag != NULLTAG)
			{
				*parmDefRevision=revisionTag;
			}
		}
	//}

	//free memory
	FVE_FREE_ARRAY(rowLabelNames,rowLabelCnt);
	rowLabelCnt=0;
	FVE_FREE_ARRAY(colLabelNames,colLabelCnt);
	colLabelCnt=0;
	FVE_FREE_ARRAY(initValArray,initValArrayCnt)
	initValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyInitValArray,dummyInitValArrayCnt)
	dummyInitValArrayCnt=0;
	FVE_FREE_ARRAY(minValArray,minValArrayCnt)
	minValArrayCnt	=	0;

	FVE_FREE_ARRAY(dummyMinValArray,dummyMinValArrayCnt)
	dummyMinValArrayCnt	=	0;

	FVE_FREE_ARRAY(maxValArray,maxValArrayCnt);
	maxValArrayCnt	=	0;

	FVE_FREE_ARRAY(dummyMaxValArray,dummyMaxValArrayCnt)
	dummyMaxValArrayCnt	=	0;

	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}




// This allocates/reallocates the array and adds the tag to the end of the array.
// I/O argument tagCnt is incremented on exit.
// Handles out-of-memory error.
extern int FV_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_add_tag_to_array";

   *tagArray = MEM_realloc(*tagArray, sizeof(tag_t) * (*tagCnt+1));

   if (*tagArray != NULL)
   {
      (*tagArray)[*tagCnt] = addTag;
      (*tagCnt)++;
   }
   else
   {
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, "1", function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
      goto CLEANUP;
   }

CLEANUP:
   return (ifail);
}

extern int FV_strdup_plus(const char* inputString, int extraCnt, char** outputString)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_strdup_plus";
   char  intCharBuf[FV_INTEGER_LEN+1] = {'\0'};

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   *outputString = MEM_alloc(sizeof(char)*(tc_strlen(inputString)+1+extraCnt));

   if (*outputString != NULL)
   {
      tc_strcpy(*outputString, inputString);
   }
   else
   {
      sprintf(intCharBuf, "%d",  sizeof(char)*(tc_strlen(inputString)+1));
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, intCharBuf, function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}


void FVE_truncate_double_values(double num, char ** truncated_vale)
{
	char temp_num[32] = "";
	char temp_str[2] = "";
	char * ptr = NULL;
	int len = 0;
	int i = 0;
	int unwanted_zero_cnt = 0;

	sprintf(temp_num, "%f", num);
	ptr = strtok(temp_num, ".");
	if(ptr != NULL)
	{
		(*truncated_vale) = (char *) MEM_alloc((int) (strlen(ptr) + 1) * sizeof(char));
		strcpy((*truncated_vale), ptr);
	}
	ptr = strtok(NULL, ".");
	if(ptr != NULL)
	{
		len = (int) strlen(ptr);
		for(i = len-1; i >= 0; i--)
		{
			if(ptr[i] != '0')
				break;
			else
				unwanted_zero_cnt++;
		}
		if(unwanted_zero_cnt < len)
		{
			(*truncated_vale) = (char *) MEM_realloc((*truncated_vale), (int) (strlen(*truncated_vale) + (len - unwanted_zero_cnt) + 2) * sizeof(char));
			strcat((*truncated_vale), ".");
			for(i = 0; i < (len - unwanted_zero_cnt); i++)
			{
				sprintf(temp_str, "%c", ptr[i]);
				strcat((*truncated_vale), temp_str);
			}
		}
	}
}


/*
  Set window for revision.
  I/P : revision tag
  o/p : window
		topBomLine
*/
int FV_get_set_window_fromRev(tag_t revision, tag_t *windowTag,tag_t *bomLineTag)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FV_get_set_window_fromRev";
	tag_t	newWindow			=	NULLTAG;
	tag_t	topbomLine		=	NULLTAG;
	tag_t	absocc_edit_mode_attr	=		NULLTAG;
    tag_t	absocc_ctxt_line_attr	=		NULLTAG;
	
	TC_write_syslog("\n Entering %s\n", function_name);
	if(revision != NULLTAG)
	{
		ITK(BOM_create_window(&newWindow))
		ITK(BOM_set_window_top_line(newWindow, NULLTAG, revision, NULLTAG, &topbomLine))
	   //ITK(PROP_ask_property_by_name(newWindow,(char *)"absocc_specific_edit_mode",&absocc_edit_mode_attr))//Deprecated
	  //ITK(PROP_ask_property_by_name(newWindow,(char *)"absocc_ctxtline",&absocc_ctxt_line_attr))//Deprecated
	  //ITK(PROP_set_value_logical(absocc_edit_mode_attr,TRUE))//Deprecated
	  //ITK(PROP_set_value_tag(absocc_ctxt_line_attr,topbomLine))//Deprecated
	   ITK(AOM_set_value_logical(newWindow,(char *)"absocc_specific_edit_mode",TRUE))
	   ITK(AOM_set_value_tag(newWindow,(char *)"absocc_ctxtline",topbomLine))
   
		ITK(BOM_save_window(newWindow))
		ITK(BOM_refresh_window(newWindow))
		ITK(BOM_line_set_precise(topbomLine, TRUE))
		ITK(BOM_save_window(newWindow))

		ITK(BOM_set_window_pack_all(newWindow,FALSE))
		ITK(BOM_window_show_substitutes(newWindow))
		ITK(BOM_window_show_unconfigured(newWindow))
		ITK(BOM_window_show_variants(newWindow))

		if(topbomLine)
		{
			*windowTag=newWindow;
			*bomLineTag=topbomLine;
		}
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

int FV_createPreciseStructure(tag_t itemTag,tag_t revisionTag,tag_t *topDicBl,tag_t *topWindow,logical inContextMode)
{

	int		ifail					=		ITK_ok;
	char	*function_name			=		"FV_createPreciseStructure";
	tag_t	newWindow				=		NULLTAG;
	tag_t	topbomLine				=		NULLTAG;
	tag_t	absocc_edit_mode_attr	=		NULLTAG;
    tag_t	absocc_ctxt_line_attr	=		NULLTAG;
	tag_t	viewType				=		NULLTAG;
	tag_t	bom_viewDic				=		NULLTAG;
	tag_t	bvrDic					=		NULLTAG;
	int		countBVDic				=		0;
    tag_t	*bvDicList				=		NULL;

	TC_write_syslog("\n Entering %s\n", function_name);


   ITK(PS_ask_default_view_type(&viewType))
   if((ifail != ITK_ok) || (viewType == NULLTAG))
   {
      TC_write_syslog(" In %s: BOM View type - view not found ", function_name);
      return ifail;
   }
   //check bomview exist for dictionary or not
   ITK(ITEM_list_bom_views(itemTag,&countBVDic,&bvDicList))
   if(ifail==ITK_ok && countBVDic ==0)
   {
	   AM__set_application_bypass(TRUE);

      ITK(PS_create_bom_view(viewType,NULL,NULL,itemTag,&bom_viewDic))
      if(bom_viewDic != NULLTAG)
      {
         ITK(AOM_lock(bom_viewDic))
         ITK(AOM_save(bom_viewDic))
         ITK(AOM_unlock(bom_viewDic))

		 ITK(AOM_save(itemTag))
         ITK(PS_create_bvr(bom_viewDic,NULL,NULL,TRUE,revisionTag,&bvrDic))

         ITK(AOM_lock(bvrDic))
         ITK(AOM_save(bvrDic))
         ITK(AOM_unlock(bvrDic))

         ITK(AOM_save(revisionTag))
      }
      AM__set_application_bypass(FALSE);

   }
    /* Set the BOM window to make an attachment with IN-CONTEXT mode
   Asks an object for its property with the specified name. */
   ITK(BOM_create_window(&newWindow))
   ITK(BOM_set_window_top_line(newWindow,NULLTAG,revisionTag,NULLTAG,&topbomLine))
   
   /*
		set the "IN-CONTEXT" mode if required.
   */
   if(inContextMode == TRUE)
   {
	   //ITK(PROP_ask_property_by_name(newWindow,(char *)"absocc_specific_edit_mode",&absocc_edit_mode_attr))//Deprecated
	  //ITK(PROP_ask_property_by_name(newWindow,(char *)"absocc_ctxtline",&absocc_ctxt_line_attr))//Deprecated
	  //ITK(PROP_set_value_logical(absocc_edit_mode_attr,TRUE))//Deprecated
	  //ITK(PROP_set_value_tag(absocc_ctxt_line_attr,topbomLine))//Deprecated
	   ITK(AOM_set_value_logical(newWindow,(char *)"absocc_specific_edit_mode",TRUE))
	   ITK(AOM_set_value_tag(newWindow,(char *)"absocc_ctxtline",topbomLine))
   
   }
   
   ITK(BOM_save_window(newWindow))
   //Performance
   //ITK(BOM_refresh_window(newWindow))
   ITK(BOM_line_set_precise(topbomLine, TRUE))
   ITK(BOM_save_window(newWindow))

   ITK(BOM_set_window_pack_all(newWindow,FALSE))
   ITK(BOM_window_show_substitutes(newWindow))
   ITK(BOM_window_show_unconfigured(newWindow))
   ITK(BOM_window_show_variants(newWindow))

   *topDicBl=topbomLine;
   *topWindow=newWindow;
	TC_write_syslog("\n Entering %s\n", function_name);
	return ifail;

}

int FVE_get_parmGrpBomLine(tag_t dictBl, tag_t *parmGrpBlTag)
{

	int		ifail							=	ITK_ok;
	char	*function_name					=	"FVE_get_parmGrpBomLine";
	tag_t		orgItem						=	NULLTAG;
	tag_t		orgRevision					=	NULLTAG;
	tag_t		grpItem						=	NULLTAG;
	tag_t		grpRevision					=	NULLTAG;
	char*		itemName					=	NULL;
	char*		orgName						=	NULL;
	char*		grpName						=	NULL;
	tag_t		orgBlTag					=	NULLTAG;
	tag_t		grpBlTag					=	NULLTAG;
	tag_t		defAppStatusTag				=	NULLTAG;


	TC_write_syslog("\n Enter %s",function_name);
	if(dictBl != NULLTAG)
	{
		ITK(AOM_ask_value_string(dictBl,bomAttr_itemName,&itemName))
		orgName= (char*) MEM_alloc((int)(strlen(itemName)+strlen("Org Group")+2)* sizeof(char));
	    strcpy(orgName,itemName);
	    strcat(orgName,"-");
		strcat(orgName,"Org Group");

		grpName= (char*) MEM_alloc((int)(strlen(itemName)+strlen("Parameter Group")+2)* sizeof(char));
		strcpy(grpName,itemName);
		strcat(grpName,"-");
		strcat(grpName,"Parameter Group");

		fprintf(logfileptr,"Creating the org group with name %s under the dictionary node\n",orgName);
		//Create Organization with name “<dictionary name>-Org Group"
		ifail=FV_create_parmDefGroups(PARM_GRPS,orgName,ecuAcronym,Organizational_GroupVALUE,&orgItem,&orgRevision);
		if(orgItem && orgRevision)
		{
			//Change management
			ITK(FV_set_object_status(orgRevision,DICTN_LOCK_STATUSTYPE,TRUE,&defAppStatusTag))
			
			fprintf(logfileptr,"Creating the parameter group with name %s under the Organization Group\n",grpName);
			fprintf(logfileptr,"\n");
			//create Parameter Group with name "<dictionary name>-Parameter Group"
			ifail=FV_create_parmDefGroups(PARM_GRPS,grpName,ecuAcronym,PARM_GRP,&grpItem,&grpRevision);
			//Change management
			ITK(FV_set_object_status(grpRevision,DICTN_LOCK_STATUSTYPE,TRUE,&defAppStatusTag))
		}
		if(grpItem && grpRevision)
		{
			//add organization below dictionary
			ifail=FV_check_bom_views_exist(dicRevTag);
			ITK(BOM_line_add(dictBl, NULLTAG, orgRevision, NULLTAG, &orgBlTag))
			ITK(BOM_save_window(windowDic))

			//add parameter group below organization
			if(orgBlTag)
			{
				ifail=FV_check_bom_views_exist(orgRevision);
				ITK(BOM_line_add(orgBlTag, NULLTAG, grpRevision, NULLTAG, &grpBlTag))
				ITK(BOM_save_window(windowDic))
				if(grpBlTag)
				{
					ifail=FV_check_bom_views_exist(grpRevision);
					*parmGrpBlTag=grpBlTag;
				}
			}//orgBlTag
		}
	}//dictBl != nulltag

	TC_write_syslog("\n Leave %s",function_name);
	return ifail;

}
int FVE_get_organizationChild(tag_t dictBl,tag_t *retunObj,logical *isRevise)
{
	int		ifail							=	ITK_ok;
	char	*function_name					=	"FVE_get_organizationChild";
	tag_t	*childlines						=	NULL;
	int		iCount_children					=	0;

	tag_t    childItemRevTag = NULLTAG;
	tag_t	childItemTag	=	NULLTAG;
	logical     isParmGrpDef				=	FALSE;
	char*       representsValue				=	NULL;
	tag_t		grpItem						=	NULLTAG;
	tag_t		grpRevision					=	NULLTAG;
	char*		itemName					=	NULL;
	char*		orgName						=	NULL;
	char*		grpName						=	NULL;
	tag_t		grpBlTag					=	NULLTAG;

	tag_t		parmGrpBlTag				=	NULLTAG;
	int			countGrpObject				=	0;
	int			countParmDefObject			=	0;
	tag_t		tagGrpBL					=	NULLTAG;
	tag_t		dictLockedStatusTag			=	NULLTAG;


	TC_write_syslog("\n Enter %s",function_name);

	if(dictBl != NULLTAG)
	{
		ITK(AOM_ask_value_string(dictBl,bomAttr_itemName,&itemName))
		grpName= (char*) MEM_alloc((int)(strlen(itemName)+strlen("Parameter Group")+2)* sizeof(char));
		strcpy(grpName,itemName);
		strcat(grpName,"-");
		strcat(grpName,"Parameter Group");
	}

   /* Get the immediate children of the selected assembly */
   ITK(BOM_line_ask_child_lines(dictBl,&iCount_children,&childlines))

  //123
	if(iCount_children == 0)
	{
	   ifail=FVE_get_parmGrpBomLine(dictBl,&parmGrpBlTag);
	   *retunObj=parmGrpBlTag;
	}
	if(iCount_children == 1)
	{
		ITK(AOM_ask_value_tag(childlines[0],bomAttr_lineItemRevTag,&childItemRevTag))
		if(childItemRevTag != NULLTAG)
		{
			//check if its of type Organization
			ITK(FV_object_is_typeof(childItemRevTag, FVE_ParmGrpsRevisionTYPE, &isParmGrpDef))
			if(isParmGrpDef)
			{
				ITK(ITEM_ask_item_of_rev(childItemRevTag, &childItemTag))
				ITK(AOM_get_value_string(childItemTag, representsPROP, &representsValue))
				if (representsValue && (tc_strcmp(Organizational_GroupVALUE, representsValue) == 0))
				{
					ifail=FV_check_bom_views_exist(childItemRevTag);

					//recursive function to get the child line that represents "Parameter Group"
					ifail=FVE_recur_getChildParmGrpBl(childlines[0],&countGrpObject,&countParmDefObject,&tagGrpBL);
					if(tagGrpBL == NULLTAG && countGrpObject == 0)
					{
						//create Parameter Group with name "<dictionary name>-Parameter Group"
						fprintf(logfileptr,"Creating the parameter group with name %s under the Organization Group\n",grpName);
						fprintf(logfileptr,"\n");
						ifail=FV_create_parmDefGroups(PARM_GRPS,grpName,ecuAcronym,PARM_GRP,&grpItem,&grpRevision);
						if(grpItem && grpRevision)
						{
							//Change management
							ITK(FV_set_object_status(grpRevision,DICTN_LOCK_STATUSTYPE,TRUE,&dictLockedStatusTag))
							ITK(BOM_line_add(childlines[0], NULLTAG, grpRevision, NULLTAG, &grpBlTag))
							ITK(BOM_save_window(windowDic))
							ifail=FV_check_bom_views_exist(grpRevision);
							*retunObj=grpBlTag;
						}
					}else if(tagGrpBL != NULLTAG && countGrpObject >=1)
					{
						//fprintf(logfileptr,"Dictionary already contains the Organization and Parameter groups\n");
						//fprintf(logfileptr,"\n");
						*retunObj=tagGrpBL;
						if(countParmDefObject >=1)
							*isRevise = TRUE;

					}
				}//organization
			}//isParmGrpDef
			else
			{
				//Create Organization below dictionary .Parameter Group below organization.
				 ifail=FVE_get_parmGrpBomLine(dictBl,&parmGrpBlTag);
				*retunObj=parmGrpBlTag;
			}
		}//childItemRevTag != NULLTAG
   }//iCount_children == 1


   FVE_FREE(orgName)
   FVE_FREE(grpName)
   FVE_FREE(childlines)


	TC_write_syslog("\n Leave %s",function_name);
	return ifail;
}

/*
check Bom View & BVR exist for given revision.If not exist create it.
*/
int FV_check_bom_views_exist(tag_t revision)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FV_check_bom_views_exist";
	tag_t	viewTypeTag		=	NULLTAG;
	int		countBV			=	0;
	tag_t	*bvList			=	NULL;
	tag_t	bvTag			=	NULLTAG;
	tag_t	bvrTag			=	NULLTAG;
	tag_t	itemTag			=	NULLTAG;
	tag_t*  attached_bvrs   =	 NULL;
	int     bvr_count       =	0;
	char	*objName		=	NULL;
	char	item_id[ITEM_id_size_c + 1] = "";

	TC_write_syslog("\n Entering %s\n", function_name);

	//get the item for vehicle program document
	if(revision != NULLTAG)
	{
		ITK(ITEM_ask_item_of_rev(revision,&itemTag))
		ITK(ITEM_ask_id(itemTag, item_id))
		ITK(PS_find_view_type(viewVIEW, &viewTypeTag))
		if((ifail != ITK_ok) || (viewTypeTag == NULLTAG))
		{
			TC_write_syslog(" In %s: BOM View type - view not found ", function_name);
			return ifail;
		}
		ITK(ITEM_list_bom_views(itemTag,&countBV,&bvList))
		if(ifail==ITK_ok && countBV ==	0)
		{
				AM__set_application_bypass(TRUE);
				ITK(PS_create_bom_view(viewTypeTag,NULL,NULL,itemTag,&bvTag))
				if(bvTag != NULLTAG)
				{
					 ITK(AOM_lock(bvTag))
					 ITK(AOM_save_with_extensions(bvTag))
					 ITK(AOM_unlock(bvTag))
					 ITK(AOM_save_with_extensions(itemTag))
					 ITK(PS_create_bvr(bvTag,NULL,NULL,TRUE,revision,&bvrTag))
					 ITK(AOM_lock(bvrTag))
					 ITK(AOM_save_with_extensions(bvrTag))
					 ITK(AOM_unlock(bvrTag))
					 ITK(AOM_save_with_extensions(revision))
				}
				AM__set_application_bypass(FALSE);
		}
		else if(ifail==ITK_ok && countBV >	0)
		{
			AM__set_application_bypass(TRUE);
			ITK(ITEM_rev_list_all_bom_view_revs (revision,&bvr_count,&attached_bvrs))
			if(bvr_count == 0)
			{
				ITK(AOM_ask_value_string(revision,object_stringPROP,&objName))
				TC_write_syslog("\n Item Revision %s  with ID %s contains BV but dont have BVR \n",objName,item_id);
				TC_write_syslog("\n Error : Vehicle Program Structure not created now..... \n");
				ITK(EMH_store_error_s2(EMH_severity_error, FV_ITEMREV_WITHOUT_BVR,objName,item_id))
				return FV_ITEMREV_WITHOUT_BVR;
			}
			AM__set_application_bypass(FALSE);

		}

		FVE_FREE(bvList);
		FVE_FREE(attached_bvrs);
		FVE_FREE(objName);
	}
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}


/*
Attach this form object with parmdef revision with relation  FVE_Model_spec_attrs_Rel

Overwritable   -->FVE_Overwritable --boolean
Units  -->FVE_MSAUnit -string
Offset -->FVE_MSAOffset - integer
ImplementedResolution -->FVE_MSAResolution  -str
ImplementationDataType -->FVE_MSAImplDataType -str

*/

int FVE_create_MSAForm(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t parmDefItemRev,tag_t *msaFormTag)
{

	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_MSAForm";
	char		*form_name			=	NULL;
	char		*form_descr			=	NULL;
	tag_t		msa_form_tag		=	NULLTAG;
	tag_t		relationTypeTag		=	NULLTAG;
	tag_t		relationTag			=	NULLTAG;
	tag_t		itemTag				=	NULLTAG;
	int			model_form_cnt		=	0;
	tag_t		*model_forms		=	NULL;
	char		itemId[ITEM_id_size_c+1] = {'\0'};
	char		rev_id[ITEM_id_size_c + 1] = "";

	TC_write_syslog("\n Enter %s\n", function_name);
	ITK(GRM_find_relation_type(FVE_Model_spec_attrs_Rel_RELATION, &relationTypeTag))
	if (relationTypeTag == NULLTAG)
	{
			TC_write_syslog("In %s, relation type %s not found\n", function_name, FVE_Model_spec_attrs_Rel_RELATION);
			EMH_store_initial_error_s1(EMH_severity_error, FV_INVALID_RELATION_TYPE, FVE_Model_spec_attrs_Rel_RELATION);
			ifail = FV_INVALID_RELATION_TYPE;
			goto CLEANUP;
	}

	//get the item Id and revision Id from parameter definition.
	if(parmDefItemRev)
	{
		ITK(ITEM_ask_item_of_rev(parmDefItemRev,&itemTag))
		ITK(ITEM_ask_id(itemTag,itemId))
		ITK(ITEM_ask_rev_id(parmDefItemRev,rev_id))
		form_name = (char*) MEM_alloc( (int)(strlen (itemId)+strlen("/")+strlen(rev_id) +1) * sizeof(char));
		strcpy(form_name, itemId);
		strcat(form_name,"/");
		strcat(form_name,rev_id);

		form_descr=parmInfoStruct[counter].descr;
		if(form_descr && tc_strlen(form_descr) > 240)
		{
			form_descr="";
		}

		if(relationTypeTag != NULLTAG)
			ITK(GRM_list_secondary_objects_only(parmDefItemRev, relationTypeTag, &model_form_cnt, &model_forms))

		if(model_form_cnt == 0 && model_forms == NULL)
		{
			ITK(FORM_create(form_name,form_descr, FVE_ModelSpAttrFormTYPE,&msa_form_tag))
			if(msa_form_tag != NULLTAG)
			{
				*msaFormTag=msa_form_tag;
				TC_write_syslog("\n MSA Form Created By Name %s \n",parmInfoStruct[counter].name);
				ITK(AOM_save(msa_form_tag))
				//attach this form to rev with relation  FVE_Model_spec_attrs_Rel
				ITK(GRM_create_relation(parmDefItemRev, msa_form_tag, relationTypeTag, NULLTAG, &relationTag))
				ITK(GRM_save_relation(relationTag))

				ITK(AOM_refresh(msa_form_tag,TRUE))

				//set the properties on MSA form
				if( (parmInfoStruct[counter].implResolution != NULL) && (tc_strlen(parmInfoStruct[counter].implResolution) > 0))
				{
					ITK(AOM_set_value_string(msa_form_tag,FVE_MSAResolutionPROP,parmInfoStruct[counter].implResolution))
					if(ifail != ITK_ok)
						ifail=ITK_ok;
				}
				if( (parmInfoStruct[counter].msaUnit) && (tc_strlen(parmInfoStruct[counter].msaUnit)> 0))
				{
					if(tc_strcmp(parmInfoStruct[counter].msaUnit,UNITLESS_UNIT) == 0)
					{
						ITK(AOM_set_value_string(msa_form_tag,FVE_MSAUnitPROP,NONE_UNIT))
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}else
					{
						ITK(AOM_set_value_string(msa_form_tag,FVE_MSAUnitPROP,parmInfoStruct[counter].msaUnit))
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
				}
				
				//ITK(AOM_set_value_int(msa_form_tag,FVE_MSAOffsetPROP,parmInfoStruct[counter].offset))
				ITK(AOM_UIF_set_value(msa_form_tag, FVE_MSAOffsetPROP,parmInfoStruct[counter].offset))
				if(ifail != ITK_ok)
						ifail=ITK_ok;
				ITK(AOM_set_value_logical(msa_form_tag,FVE_OverwritablePROP,parmInfoStruct[counter].overWritable))
				if(ifail != ITK_ok)
						ifail=ITK_ok;

				if( (parmInfoStruct[counter].implDataType != NULL) && ( tc_strlen(parmInfoStruct[counter].implDataType)> 0))
				{
					ITK(AOM_set_value_string(msa_form_tag,FVE_MSAImplDataTypePROP,parmInfoStruct[counter].implDataType))
					if(ifail != ITK_ok)
						ifail=ITK_ok;
				}

				ITK(AOM_save(msa_form_tag))
				ITK(AOM_refresh(msa_form_tag,FALSE))

			}else
			{
				*msaFormTag= NULLTAG;
			}
			FVE_FREE(form_name)
		}else if(model_forms && model_form_cnt> 0)
		{
			*msaFormTag=model_forms[0];

			/*if(model_forms[0])
			{
				ITK(AOM_ask_if_modifiable (model_forms[0], &modifiable));
				if(modifiable == true)
				{
					ITK(RES_is_checked_out(model_forms[0], &checked_out));
					if(checked_out == false)
					{
						ITK(RES_checkout(model_forms[0],"","","",2))
						//ITK(AOM_refresh(model_forms[0] ,FALSE))
					}
				}
			}*/

			ITK(AOM_refresh(model_forms[0],TRUE))
			//update the properties on existing form.
			if(parmInfoStruct[counter].implResolution != NULL && tc_strlen(parmInfoStruct[counter].implResolution)> 0)
			{
				ITK(AOM_set_value_string(model_forms[0],FVE_MSAResolutionPROP,parmInfoStruct[counter].implResolution))
				if(ifail != ITK_ok)
						ifail=ITK_ok;
			}

			if( (parmInfoStruct[counter].msaUnit) && (tc_strlen(parmInfoStruct[counter].msaUnit)> 0))
			{
				if(tc_strcmp(parmInfoStruct[counter].msaUnit,UNITLESS_UNIT) == 0)
				{
					ITK(AOM_set_value_string(model_forms[0],FVE_MSAUnitPROP,NONE_UNIT))
					if(ifail != ITK_ok)
						ifail=ITK_ok;
				}else
				{
					ITK(AOM_set_value_string(model_forms[0],FVE_MSAUnitPROP,parmInfoStruct[counter].msaUnit))
					if(ifail != ITK_ok)
						ifail=ITK_ok;
				}
			}
			//ITK(AOM_set_value_int(model_forms[0],FVE_MSAOffsetPROP,parmInfoStruct[counter].offset))
			ITK(AOM_UIF_set_value(model_forms[0], FVE_MSAOffsetPROP,parmInfoStruct[counter].offset))
			if(ifail != ITK_ok)
				ifail=ITK_ok;

			ITK(AOM_set_value_logical(model_forms[0],FVE_OverwritablePROP,parmInfoStruct[counter].overWritable))
			if(ifail != ITK_ok)
				ifail=ITK_ok;

			if(parmInfoStruct[counter].implDataType != NULL && tc_strlen(parmInfoStruct[counter].implDataType)> 0)
			{
				ITK(AOM_set_value_string(model_forms[0],FVE_MSAImplDataTypePROP,parmInfoStruct[counter].implDataType))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}

			ITK(AOM_save(model_forms[0]))
			ITK(AOM_refresh(model_forms[0],FALSE))

			/*if(model_forms[0])
			{
				ITK(RES_checkin(model_forms[0]));
				ITK(AOM_refresh(model_forms[0] , FALSE));
			} */

		}//model_forms != null

	}//parmDefItemRev

	TC_write_syslog("\n Exiting %s\n", function_name);
	CLEANUP:
    return ifail;
}


/*
function to create object
*/
int FV_createObject(char *itemTypeName,int itemAttrCnt,char **itemAttrNames,char **itemAttrValues,int revAttrCnt,char **revAttrNames,char** revAttrValues,tag_t *revTag)
{
	int			ifail			=	ITK_ok;
	char*       function_name = "FV_createObject";
    tag_t       itemTypeTag		= NULLTAG;
    tag_t		revTypeTag = NULLTAG;
    tag_t       itemTag = NULLTAG;
    tag_t       revisionTag = NULLTAG;
    tag_t       createItemInputTag = NULLTAG;
    tag_t       createRevInputTag = NULLTAG;
	int			attrIdx	=	0;
	char*       attrValue = NULL;
	char*       revTypeName = NULL;
	TC_write_syslog("\n Entering %s\n", function_name);

	// Construct item input object
    CLEANUP(TCTYPE_ask_type(itemTypeName, &itemTypeTag))
    CLEANUP(TCTYPE_construct_create_input(itemTypeTag, &createItemInputTag))

	//Set item attribute values.
    for (attrIdx=0; attrIdx<itemAttrCnt; attrIdx++)
    {
        attrValue = itemAttrValues[attrIdx];
		if ((attrValue != NULL) && (tc_strlen(attrValue) > 0))
		{
			FV_trim_blanks(attrValue);
           CLEANUP(TCTYPE_set_create_display_value(createItemInputTag, itemAttrNames[attrIdx], 1,  (const char**)&attrValue))
		}
    }

	// Get typename of revision object for this item.
    // Can't find an API to do this, so concatenate "Revision" to item typename.
    CLEANUP(FV_strdup_plus(itemTypeName, 9, &revTypeName))
    tc_strcat(revTypeName, "Revision");

    // Construct item revision input object
    CLEANUP(TCTYPE_ask_type(revTypeName, &revTypeTag))
    CLEANUP(TCTYPE_construct_create_input(revTypeTag, &createRevInputTag))

	 // Set revision attribute values (optional).
    for (attrIdx=0; attrIdx<revAttrCnt; attrIdx++)
    {
        attrValue = revAttrValues[attrIdx];
		if ((attrValue != NULL) && (tc_strlen(attrValue) > 0))
		{
			FV_trim_blanks(attrValue);
           CLEANUP(TCTYPE_set_create_display_value(createRevInputTag, revAttrNames[attrIdx], 1,  (const char**)&attrValue))
		}
    }

	// Create and relate the objects.
    CLEANUP(TCTYPE_set_compound_objects(createItemInputTag, revisionPROP, 1, &createRevInputTag))
    CLEANUP(TCTYPE_create_object(createItemInputTag, &itemTag))
    CLEANUP( AOM_save_with_extensions(itemTag) )
    CLEANUP( AOM_refresh(itemTag, false) )

    // Get the new item revision tag.
    CLEANUP(ITEM_ask_latest_rev(itemTag, &revisionTag))
	if(revisionTag != NULLTAG)
		*revTag=revisionTag;


	TC_write_syslog("\n Exiting %s\n", function_name);

CLEANUP:
	 FVE_FREE(revTypeName)

	return ifail;

}

int FVE_add_process_with_relation(tag_t parentDictRev,tag_t selectedParamDefLine,tag_t fveprocess,char *relation,tag_t bomWindow)
{
	int ifail = ITK_ok;
	tag_t window = NULLTAG;
	tag_t revRule = NULLTAG;
	tag_t attWinTag = NULLTAG;
	tag_t attachRootLine = NULLTAG;
	tag_t newChild_obj = NULLTAG;


	int status_count=0;
	int sCounter=0;
	tag_t *status_list=NULL;
	char *status_name=NULL;
	char *object_id=NULL;

	logical isDictLocked=FALSE;

	TC_write_syslog("Enter In function FVE_add_process_with_relation... \n");
	if(parentDictRev && selectedParamDefLine && fveprocess && relation && tc_strlen(relation)> 0)
	{
		AM__set_application_bypass(TRUE);
		ITK(BOM_line_ask_window(selectedParamDefLine, &window))
		//ITK(BOM_ask_window_config_rule(windowDic, &revRule))
		ITK(BOM_ask_window_config_rule(bomWindow, &revRule))
		ITK(ME_create_attachment_window(revRule, bomWindow, &attWinTag))
		ITK(ME_window_create_root_line(attWinTag,selectedParamDefLine,&attachRootLine))

		//get the status for ParentDictionaryRev
		ITK(WSOM_ask_object_id_string(parentDictRev,&object_id))
		ITK(AOM_ask_value_tags(parentDictRev,"release_status_list",&status_count,&status_list))
		/* if dictionary not released with any status */
		if(status_count ==0 && isDictLocked==FALSE)
		{
			ITK(ME_line_add(attachRootLine,fveprocess,relation,&newChild_obj))
			ITK(BOM_save_window(bomWindow))
		}
		for(sCounter=0;sCounter<status_count;sCounter++)
		{
			ITK(AOM_ask_name(status_list[sCounter],&status_name))
			if((strcmp(status_name,DICTN_LOCK_STATUSTYPE) != 0 ) &&
			    (strcmp(status_name,FREEZE_STATUSTYPE) !=0 ))
			{
				isDictLocked=FALSE;
			}
			else
			{
				isDictLocked=TRUE;
			}

			/* release mem for status list */
			FVE_FREE(status_name);
		}
		/* release mem for status list */
		FVE_FREE(status_list);
		if(status_count >=1 && isDictLocked==FALSE)
		{
			ITK(ME_line_add(attachRootLine,fveprocess,relation,&newChild_obj))
			ITK(BOM_save_window(bomWindow))
		}
		if(isDictLocked==TRUE)
		{
			TC_write_syslog("\n Dictionary %s is locked .Not allowed to add ProcessRevisions \n",object_id);
			ITK(EMH_store_error_s1(EMH_severity_error,DICT_LOCK_CANT_ADD_FVEPROCESSREV,object_id))
			return DICT_LOCK_CANT_ADD_FVEPROCESSREV;
		}
		ITK (ME_window_close(attWinTag))
		AM__set_application_bypass(FALSE);
	}
	TC_write_syslog("Leave function FVE_add_process_with_relation... \n");
	return ifail;
}



/* Function to query for WSO using attribute value filter */
int FVE_gsdb_find_wso_with_attr( char *class_name, char *attr_name, char *attr_value,
								    tag_t **obj_tags, int *num_values )
{
	int      ifail           = ITK_ok;
	char*    function_name   = "FVE_gsdb_find_wso_with_attr";
	int      wso_count       = 0;
	tag_t    class_id        = NULLTAG;
    tag_t    attr_id         = NULLTAG;
    tag_t    enq_id          = NULLTAG;
	tag_t    *wso_objects    = NULL;

	TC_write_syslog(" Entering %s, class_name: %s, attr_name: %s, attr_value: %s\n",
		      function_name, (class_name?class_name:FV_NULL_VALUE),
		      (attr_name?attr_name:FV_NULL_VALUE), (attr_value?attr_value:FV_NULL_VALUE));

    ITK(POM_class_id_of_class(class_name, &class_id));
	ITK(POM_attr_id_of_attr(attr_name, class_name, &attr_id));
	ITK(POM_create_enquiry_on_string(class_id, attr_id, POM_is_equal_to , &attr_value, &enq_id));

	if ( enq_id != NULLTAG )
	{
		ITK(POM_execute_enquiry(enq_id, &wso_count, &wso_objects));
		ITK(POM_delete_enquiries(1 ,&enq_id));
		if(wso_count > 0)
		{
			*num_values = wso_count;
			*obj_tags = wso_objects;
		}
	}
   TC_write_syslog("\n Exit FVE_gsdb_find_wso_with_attr\n");
   return ifail;
}


int split_the_string(char *consolidated_str,char *delim, int * str_cnt, char *** splitted_strings)
{
	char	*temp_str	=	NULL;
	char	* ptr			=	NULL;
	int		ifail			=	ITK_ok;
	char	*function_name	=	"split_the_string";

	TC_write_syslog("\n Entering %s\n", function_name);
	if(consolidated_str != NULL)
	{
		ITK(FV_strdup(consolidated_str, &temp_str))
		ptr = strtok(temp_str,delim);
		while(ptr != NULL)
		{
			(*splitted_strings) = (char **) MEM_realloc((*splitted_strings), (*str_cnt + 1) * sizeof(char *));
			(*splitted_strings)[*str_cnt] = (char *) MEM_alloc ((int)((strlen(ptr) + 1)) * sizeof(char));
			strcpy((*splitted_strings)[*str_cnt], ptr);
			(*str_cnt)++;
			ptr = strtok(NULL,delim);
		}
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
    FVE_FREE(temp_str)
	return ifail;
}

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}


int FVE_validate_arguments(char *modeName)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FVE_validate_arguments";

	TC_write_syslog("\n Entering %s\n", function_name);
	if(modeName != NULL && tc_strlen(modeName) > 0)
	{
		if(tc_strcmp(modeName,"all") == 0)
		{

		}else if(tc_strcmp(modeName,"parameter")==0)
		{
			ignoreProcessFile = TRUE;
		}else if(tc_strcmp(modeName,"process")==0)
		{
		}else
		{
			fprintf(stderr,"\nERROR.Value for mode should be parameter or process or all only\n");
			exit(1);
		}
		ifail=FVE_validate_file(modeName);
	}
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

int FVE_validate_file(char *modeName)
{

	int		ifail			=	ITK_ok;
	char	*function_name	=	"FVE_validate_file";
	int		iCounter		=	0;
	int		validCounterExt	=	0;
	int		cntExt			=	0;
	char	**extension		=	NULL;
	TC_write_syslog("\n Entering %s\n", function_name);


    // Nikhil Patil changes starts.
    /*
    *  Take input for configuration file.
    */
        if (configFileInput != 0)
        {
            configFilePtr = fopen(configFileInput, "r");
            if (configFilePtr == 0)
            {
                fprintf(stderr, "\nERROR: file %s does not exist.\n", filename1);
                exit(1);
            }
        }

    // Nikhil Patil changes ends.

	if(tc_strcmp(modeName,ALL_MODE) == 0)
	{
		//all mode , both file names i.e. parmdeffile and processdeffile should be entered
		if(filename1 == NULL || tc_strlen(filename1) == 0)
		{
			fprintf(stderr,"\nERROR: -parmdeffile is not provided. \nPlease provide a file name with .csv extension, containing the Parameter Definition Information.\n");
			print_usage();
			exit(0);
		}else
		{
			//check if file extension is csv
			split_the_string(filename1,".",&cntExt,&extension);
			for(iCounter = 0;iCounter< cntExt; iCounter++)
			{
				if( (tc_strcmp(extension[iCounter] ,"csv") == 0) ||
				(tc_strcmp(extension[iCounter] ,"CSV") == 0))
				{
					validCounterExt++;
				}
			}
			if(validCounterExt == 0)
			{
				fprintf(stderr,"\nERROR: -parmdeffile is provided with wrong extension.\nPlease provide the file name with extension csv.\n");
				exit(1);
			}else
			{
				validCounterExt=0;
			}
			FVE_FREE_ARRAY(extension,cntExt)
			cntExt=0;
		}//filename1

		//Make sure if file : Parameter Definition exist
		if (filename1 != 0)
		{
			fileptr1 = fopen(filename1, "r");
			if (fileptr1 == 0)
			{
				fprintf(stderr, "\nERROR: file %s does not exist.\n", filename1);
				exit(1);
			}
			//If file size is Zero, Exit
			stat( filename1, &file_stat);
			if( file_stat.st_size == 0 )
			{
				printf("\nERROR: Input File [%s] is empty!!.\n", filename1);
				exit(1);
			}
		}


		if(filename2 == NULL || tc_strlen(filename2) == 0)
		{
			fprintf(stderr,"\nERROR: -processdeffile is not provided.\n Please provide a file name with .csv extension, containing the Process Definition Information.\n");
			print_usage();
			exit(0);
		}else
		{
			//check if file extension is csv
			//check if file extension is csv
			split_the_string(filename2,".",&cntExt,&extension);
			for(iCounter = 0;iCounter< cntExt; iCounter++)
			{
				if( (tc_strcmp(extension[iCounter] ,"csv") == 0) ||
				(tc_strcmp(extension[iCounter] ,"CSV") == 0))
				{
					validCounterExt++;
				}
			}
			if(validCounterExt == 0)
			{
				fprintf(stderr,"\nERROR: -processdeffile is provided with wrong extension.\nPlease provide the file name with extension csv.\n");
				exit(1);
			}else
			{
				validCounterExt=0;
			}
			FVE_FREE_ARRAY(extension,cntExt)
			cntExt=0;
		}//filename2

		//Make sure if file : Process Definition exist
		if ( filename2 != 0 )
		{
			fileptr2 = fopen(filename2, "r");
			if (fileptr2 == 0)
			{
				fprintf(stderr, "\nERROR: file %s does not exist.\n", filename2);
				exit(1);
			}
			//If Process input file size is Zero, Exit
			stat( filename2, &file_statProcessInfo);
			if( file_statProcessInfo.st_size == 0 )
			{
				printf("\nERROR: Input File [%s] is empty!!.\n", filename2);
				exit(1);
			}
		}

	}else if(tc_strcmp(modeName,PARAMETER_MODE) == 0)
	{
		//parameter mode , should entered only parmdeffile name
		if(filename1 == NULL || tc_strlen(filename1) == 0)
		{
			fprintf(stderr,"\nERROR: -parmdeffile is not provided. \nPlease provide a file name with .csv extension, containing the Parameter Definition Information.\n");
			print_usage();
			exit(0);
		}else
		{
			//check if file extension is csv
			split_the_string(filename1,".",&cntExt,&extension);
			for(iCounter = 0;iCounter< cntExt; iCounter++)
			{
				if( (tc_strcmp(extension[iCounter] ,"csv") == 0) ||
				(tc_strcmp(extension[iCounter] ,"CSV") == 0))
				{
					validCounterExt++;
				}
			}
			if(validCounterExt == 0)
			{
				fprintf(stderr,"\nERROR: -parmdeffile is provided with wrong extension.\nPlease provide the file name with extension csv.\n");
				exit(1);
			}else
			{
				validCounterExt=0;
			}
			FVE_FREE_ARRAY(extension,cntExt)
			cntExt=0;
		}//filename1
		//Make sure if file : Parameter Definition exist
		if (filename1 != 0)
		{
			fileptr1 = fopen(filename1, "r");
			if (fileptr1 == 0)
			{
				fprintf(stderr, "\nERROR: file %s does not exist.\n", filename1);
				exit(1);
			}
			//If file size is Zero, Exit
			stat( filename1, &file_stat);
			if( file_stat.st_size == 0 )
			{
					printf("\nERROR: Input File [%s] is empty!!.\n", filename1);
					exit(1);
			}
		}

	}else if(tc_strcmp(modeName,PROCESS_MODE) == 0)
	{
		//process mode , should entered only processdeffile name
		if(filename2 == NULL || tc_strlen(filename2) == 0)
		{
			fprintf(stderr,"\nERROR: -processdeffile is not provided.\n Please provide a file name with .csv extension, containing the Process Definition Information.\n");
			print_usage();
			exit(0);
		}else
		{
			//check if file extension is csv
			//check if file extension is csv
			split_the_string(filename2,".",&cntExt,&extension);
			for(iCounter = 0;iCounter< cntExt; iCounter++)
			{
				if( (tc_strcmp(extension[iCounter] ,"csv") == 0) ||
				(tc_strcmp(extension[iCounter] ,"CSV") == 0))
				{
					validCounterExt++;
				}
			}
			if(validCounterExt == 0)
			{
				fprintf(stderr,"\nERROR: -processdeffile is provided with wrong extension.\nPlease provide the file name with extension csv.\n");
				exit(1);
			}else
			{
				validCounterExt=0;
			}
			FVE_FREE_ARRAY(extension,cntExt)
			cntExt=0;
		}

		//Make sure if file : Process Definition exist
		if ( filename2 != 0 )
		{
			fileptr2 = fopen(filename2, "r");
			if (fileptr2 == 0)
			{
				fprintf(stderr, "\nERROR: file %s does not exist.\n", filename2);
				exit(1);
			}
			//If Process input file size is Zero, Exit
			stat( filename2, &file_statProcessInfo);
			if( file_statProcessInfo.st_size == 0 )
			{
				printf("\nERROR: Input File [%s] is empty!!.\n", filename2);
				exit(1);
			}
		}
	}//process mode

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}

/*
   Create object  "FVE_ParmGrpDef"
   Set Of Required Attributes
		1.Dictionary Id
		2.RevId
		3.Name
		4.ECU  Acronym
		5.Represents= Parameter Dictionary
					Packeted Parameter
					Parameter Group
					Parameter Dictionary
					Parameter Breakdown
					Organizational Group

*/

int FV_create_parmDefGroups(char *objType,char *objectName,char *ecuAcr,char *representsVal,tag_t *itemTag,tag_t *revTag)
{

	int		ifail				=	ITK_ok;
	char	*function_name		=	"FV_create_paramGroups";
	char	*objName[]			=	{objectName};
    char	*ecuacr[]			=	{ecuAcr};
	char	*repreAttr[]		=	{representsVal};
	char	*revTypeName		=	NULL;
	tag_t	grTag				=	NULLTAG;
    tag_t	grTypeTag			=	NULLTAG;
    tag_t	grRevTypeTag		=	NULLTAG;
    tag_t	createInputTag		=	NULLTAG;
    tag_t	createRevInputTag	=	NULLTAG;
	tag_t   revisionTag			=	NULLTAG;

	TC_write_syslog("\n Entering %s\n", function_name);
    TC_write_syslog("Creating object %s\n",objectName);

	// create item
	ITK(TCTYPE_ask_type(objType, &grTypeTag))
    ITK(TCTYPE_construct_create_input(grTypeTag, &createInputTag))

    // create item revision
	ITK(FV_strdup_plus(objType, 9, &revTypeName))
    tc_strcat(revTypeName, "Revision");
	ITK(TCTYPE_ask_type(revTypeName,&grRevTypeTag))
    ITK(TCTYPE_construct_create_input(grRevTypeTag, &createRevInputTag))

    // set revision
    ITK(TCTYPE_set_compound_objects(createInputTag, "revision", 1, &createRevInputTag))

    TC_write_syslog("Setting item attributes\n");
    // set item attribute
    ITK(TCTYPE_set_create_display_value(createInputTag, "object_name", 1,  (const char**)objName))
    ITK(TCTYPE_set_create_display_value(createInputTag, FVE_ECUAcronymPROP, 1,  (const char**)ecuacr))
	ITK(TCTYPE_set_create_display_value(createInputTag, "represents", 1, (const char**)repreAttr))

	// create the object
    ITK(TCTYPE_create_object(createInputTag, &grTag))
	if(grTag != NULLTAG)
	{
		ITK(AOM_save_with_extensions(grTag))
		//ITK(AOM_save(grTag))
		ITK(AOM_refresh(grTag, false))
		*itemTag=grTag;

		 // Get the new item revision tag.
		ITK(ITEM_ask_latest_rev(grTag, &revisionTag))
		if(revisionTag != NULLTAG)
			*revTag=revisionTag;
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

/*
Recursive function to get the child line tag that represents "parameter group".
If exist return its bomLineTag
*/
int FVE_recur_getChildParmGrpBl(tag_t bomLine,int *countGrpObject,int *countParmDefObject,tag_t *tagGrpBL)
{
	int			ifail				=		ITK_ok;
	char		*function_name		=		"FVE_recur_getChildParmGrpBl";
	int			cntChildLine		=		0;
	tag_t		*tagsChildLines		=		NULL;
	int			iCnt				=		0;
	tag_t		childItemRevTag		=		NULLTAG;
	logical		isParmGrpDef		=		FALSE;
	logical		isParameter			=		FALSE;
	tag_t		childItemTag		=		NULLTAG;
	char*       representsValue		=		NULL;
	int			counterGrpObject	=		0;
	int			counterParmDefObject	=		0;
	char        itemId[ITEM_id_size_c+1] = {'\0'};
	char        revId[ITEM_id_size_c+1] = {'\0'};
	tag_t		itemTag=NULLTAG;


	TC_write_syslog("\n Entering %s\n", function_name);

	ITK(AOM_ask_value_tag(bomLine,bomAttr_lineItemRevTag,&childItemRevTag))
	if(childItemRevTag)
	{
		//check if its of type Parameter Group
		ITK(FV_object_is_typeof(childItemRevTag, FVE_ParmGrpsRevisionTYPE, &isParmGrpDef))
		if(isParmGrpDef)
		{
			ITK(ITEM_ask_item_of_rev(childItemRevTag, &childItemTag))
			ITK(AOM_get_value_string(childItemTag, representsPROP, &representsValue))
			if (representsValue && (tc_strcmp(PARM_GRP, representsValue) == 0))
			{
				counterGrpObject++;
				ifail=FV_check_bom_views_exist(childItemRevTag);
				*tagGrpBL=bomLine;
				*countGrpObject=counterGrpObject;
				
				//print the item id and revision id for this
				//get Item tag
				ifail=ITEM_ask_item_of_rev(childItemRevTag, &itemTag );

				//get item id
				ifail=ITEM_ask_id(itemTag,itemId);

				//get rev id
				ifail=ITEM_ask_rev_id(childItemRevTag,revId);

				//printf("\n Item Id=%s  Rev Id=%s \n",itemId,revId);
				//printf("\n bomline tag is %d \n",bomLine);

			}
		}
		ITK(FV_object_is_typeof(childItemRevTag, ParmDefRevisionTYPE, &isParameter))
		if(isParameter)
		{
			counterParmDefObject++;
			*countParmDefObject=counterParmDefObject;
			return ifail;
		}
	}

	ITK(BOM_line_ask_child_lines(bomLine, &cntChildLine, &tagsChildLines))
	for(iCnt = 0; iCnt < cntChildLine; iCnt++)
	{
		ITK(FVE_recur_getChildParmGrpBl(tagsChildLines[iCnt],countGrpObject,countParmDefObject,tagGrpBL))
		if(ifail == ITK_ok)
		{
			return ifail;
		}
	}

	FVE_FREE(tagsChildLines)
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}

// Remove leading and trailing blank characters from input string.
// WARNING! This modifies and returns the input string so make sure it is not static!!
extern char* FV_trim_blanks(char* inputStr)
{
  char* end = NULL;

  if (inputStr == NULL)
     return inputStr;

  end=strrchr(inputStr, '\0'); // Find null terminator

  while (inputStr<end && isspace(*inputStr)) // Scan forward
    ++inputStr;

  while (end>inputStr && isspace(*(end-1))) // scan back from end
    --end;

  *end='\0'; // terminate modified string

  return inputStr;
}

/*
  This function will trim only first and last invalid character from string.
  Only exception is with - minus sign , if string starts with it.
  If string starts with - sign , it will not be removed.
  If string ends with any invalid character , it will be removed.

 e.g  Matrix 4X2
  String = -40 15 25 40 20 30 40 50-
  string[0] = -40 15  ->Here - sign will not be removed.
  string[1]=   40 50-  ->Here  - sign will be removed.


*/
extern char* FV_trim_invalidChars(char* inputStr)
{
  char		*end			=	NULL;
  int		asciiValueStart		=	0;
  int		asciiValueEnd		=	0;
  logical	flagStart		=	FALSE;
  logical	flagEnd			=	FALSE;

  if (inputStr == NULL)
     return inputStr;

  asciiValueStart = *inputStr;
  end=strrchr(inputStr, '\0'); // Find null terminator
  asciiValueEnd= *(end-1);

  if( (asciiValueStart >= 32 && asciiValueStart <= 44) || (asciiValueStart >= 46 && asciiValueStart <= 47) || (asciiValueStart >= 58 && asciiValueStart <= 64) || (asciiValueStart >= 91 && asciiValueStart <= 96) || (asciiValueStart >= 123 && asciiValueStart <= 127))
	   flagStart = TRUE;

  if( (asciiValueEnd >= 32 && asciiValueEnd <= 47) || (asciiValueEnd >= 58 && asciiValueEnd <= 64) || (asciiValueEnd >= 91 && asciiValueEnd <= 96) || (asciiValueEnd >= 123 && asciiValueEnd <= 127))
	   flagEnd = TRUE;

  if(inputStr<end && flagStart) // Scan forward
    ++inputStr;

  if(end>inputStr && flagEnd) // scan back from end
    --end;

  *end='\0'; // terminate modified string

  return inputStr;
}

/*
This function removes invalid characters like  from complete string
need to write function that only removes leading/trailing invalid characters from complete string
*/
int FVE_remove_invalidChars(char *str,char **result)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_remove_invalidChars";
	char		*src							=	NULL;
	int			asciiValue						=	0;
	int			validCount						=	0;
	char		*outputStr						= NULL;

	TC_write_syslog("\n Entering %s\n", function_name);
    TC_write_syslog("\n Input string to be scanned for invalid chars - %s\n", str);
	for(src = str; *src != '\0'; src++)
	{
        TC_write_syslog("\n Entering for loop \n");
		asciiValue = *src;
		if( (asciiValue >= 48 && asciiValue <= 57) || (asciiValue >= 65 && asciiValue <= 90) || (asciiValue >= 97 && asciiValue <= 122))
		{
			TC_write_syslog("\n valid char found \n");
			outputStr = (char *) MEM_realloc(outputStr, (int)(tc_strlen(outputStr) + 2) *sizeof(char));
			outputStr[validCount] = *src;
			validCount++;
            TC_write_syslog("\n validCount - %d \n", validCount);
		}
	}
	outputStr[validCount] = '\0';
    TC_write_syslog("\n Backslash zero copied\n");
    if( outputStr != NULL && tc_strlen(outputStr) >0 )
    {
        TC_write_syslog("Valid String formed is  - %s\n", outputStr);
    }
//	str=outputStr;
    TC_write_syslog("\n b4 final string copy \n");
	*result= MEM_alloc(sizeof(char)* ((int)tc_strlen(outputStr)+1));
	tc_strcpy(*result,outputStr);
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

/*
 * Funtion to trim Return Carraige Character
 * & trailing whitespaces for each line if string is multiple lines
 */
//below not working
void FVE_trim_trailing_invalidChars(char *str, char **result)
{
   char *src       = NULL;
   char *dst       = NULL;
   int			asciiValue						=	0;

   TC_write_syslog("\n Enter FVE_trim_trailing_invalidChars");

   if(str != NULL && tc_strlen(str) > 0)
   {
      for(src = dst = str; *src != '\0'; src++)
      {
         *dst = *src;
		 asciiValue = *dst;
         /*
          * Trims trailing whitespaces for each line if
          * string is multiple line
          */
        if( (asciiValue >= 32 && asciiValue <= 47) || (asciiValue >= 58 && asciiValue <= 64) || (asciiValue >= 91 && asciiValue <= 96) || (asciiValue >= 123 && asciiValue <= 127))
         {
            dst--;
            while(*dst == ' ' || *dst == '\t')
            {
               dst--;
            }
            dst++;
            *dst = *src;
            dst++;
         }
          /*
          * Trims Return Carraige Character
          */
         else if (*dst != '\r')
            dst++;
      }
      *dst = '\0';
      str = dst;
   }
   *result= MEM_alloc(sizeof(char)* ((int)tc_strlen(str)+1));
	tc_strcpy(*result,str);

   TC_write_syslog("\n Exit FVE_trim_trailing_invalidChars \n");
}

/*
Recursive function to get the bomline with given name
*/

int FV_get_bomLine_withName(tag_t topBl, char *objName, tag_t *tagMatchingBl)
{
	int ifail	=	ITK_ok;
	char	*function_name	=		"FV_get_bomLine_withName";
	int		cntChildLine	=		0;
	tag_t*	tagsChildLines	=		NULL;
	int		iCnt			=		0;
	char*	itemName		=		NULL;
	char*	itemType		=		NULL;
	logical flag			=		FALSE;
	tag_t	itemTag			=	NULLTAG;
	tag_t	itemRevTag		=	NULLTAG;
	logical     isParmGrpDef				=	FALSE;
	char*       representsValue				=	NULL;

	TC_write_syslog("\n Entering %s\n", function_name);
	ITK(AOM_ask_value_string(topBl, bomAttr_itemName, &itemName))
	if((itemName) && (objName) && (tc_strcmp(itemName,objName) == 0) )
	{
		/*Crosscheck if bomline of type Parameter Group*/
		ITK(AOM_ask_value_string(topBl, bomAttr_itemType, &itemType))
		ITK(AOM_ask_value_tag(topBl,bomAttr_lineItemTag,&itemTag))
		ITK(AOM_ask_value_tag(topBl,bomAttr_lineItemRevTag,&itemRevTag))
		if(itemRevTag)
			ITK(FV_object_is_typeof(itemRevTag, FVE_ParmGrpsRevisionTYPE, &isParmGrpDef))
		if(isParmGrpDef)
		{
			ITK(AOM_get_value_string(itemTag, representsPROP, &representsValue))
			if ( representsValue && tc_strcmp(PARM_GRP, representsValue) == 0)
			{
				*tagMatchingBl=topBl;
				flag	=	TRUE;
				return ifail;
			}
		}
	}
	FVE_FREE(itemName)

	ITK(BOM_line_ask_child_lines(topBl, &cntChildLine, &tagsChildLines))
	for(iCnt = 0; iCnt < cntChildLine; iCnt++)
	{
		ITK(FV_get_bomLine_withName(tagsChildLines[iCnt],objName,tagMatchingBl))
		if(ifail == ITK_ok && flag	==	TRUE)
			return ifail;
	}

	FVE_FREE(tagsChildLines)
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}
/*
Recursive function to check if bomline with the given name for parameter usage exist in structure or not.
*/
int FV_check_bomLineExist_inStruct(tag_t topBl,char *objName,tag_t *tagMatchingBl)
{
	int ifail	=	ITK_ok;
	char	*function_name	=		"FV_check_bomLineExist_inStruct";
	int		cntChildLine	=		0;
	tag_t*	tagsChildLines	=		NULL;
	int		iCnt			=		0;
	char*	itemName		=		NULL;
	char*	itemType		=		NULL;
	logical flag			=		FALSE;

	
	TC_write_syslog("\n Entering %s\n", function_name);
	
	ITK(AOM_ask_value_string(topBl, bomAttr_itemName, &itemName))
	if((itemName != NULL) && (objName != NULL) && (tc_strcmp(itemName,objName) == 0) )
	{
		/*cross check here , bomline is of type parameter usage */
		ITK(AOM_ask_value_string(topBl, bomAttr_itemType, &itemType))
			if( (itemType != NULL) &&  ( (tc_strcmp(itemType,FV9ParmDfIntUsgTYPE)== 0) || (tc_strcmp(itemType,FVE_ParmDefIntTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfStrUsgTYPE)== 0) || (tc_strcmp(itemType,FVE_ParmDefStrTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfDblUsgTYPE)== 0) || (tc_strcmp(itemType,FVE_ParmDefDblTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfHexUsgTYPE)== 0) || (tc_strcmp(itemType,FVE_ParmDefHexTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfSEDUsgTYPE)== 0) || (tc_strcmp(itemType,FVE_ParmDefSEDTYPE)== 0)))
		{
			*tagMatchingBl=topBl;
			flag	=	TRUE;
			return ifail;
		}
	}
	FVE_FREE(itemName)
	FVE_FREE(itemType)

	ITK(BOM_line_ask_child_lines(topBl, &cntChildLine, &tagsChildLines))
	for(iCnt = 0; iCnt < cntChildLine; iCnt++)
	{
		ITK(FV_check_bomLineExist_inStruct(tagsChildLines[iCnt],objName,tagMatchingBl))
		if(ifail == ITK_ok && flag	==	TRUE)
			return ifail;
	}

	FVE_FREE(tagsChildLines)
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

/*
function to search the object with given name and get the bomline tag from structure.
*/
int FVE_check_objName_existIn_Structure(tag_t dictBl,char *name,tag_t *retunObj)
{
	int		ifail							=	ITK_ok;
	char	*function_name					=	"FVE_check_objName_existIn_Structure";
	tag_t	*childlines						=	NULL;
	int		iCount_children					=	0;
	int		i								=	0;
	int		parmDefMatchCnt					=	0;
	tag_t	*arrSig_bom_line				=	NULL;

	char	*itemName						=	NULL;
	char	*time_stamp				    =	NULL;
		
	TC_write_syslog("\n Enter %s",function_name);

	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	TC_write_syslog("Function %s Start Time: %s\n", function_name, time_stamp);
	FVE_FREE(time_stamp);
	

   /* Get the immediate children of the selected assembly */
   ITK(BOM_line_ask_child_lines(dictBl,&iCount_children,&childlines))
   
   get_time_stamp(DATE_FORMAT_STR, &time_stamp);
   TC_write_syslog("BOM_line_ask_child_lines: %s\n", time_stamp);
   FVE_FREE(time_stamp);
	
   for(i = 0; i < iCount_children; i++)
   {
	   ITK(AOM_ask_value_string(childlines[i],bomAttr_itemName,&itemName))
	   if(itemName != NULL && tc_strlen(itemName) > 0 && name != NULL && tc_strlen(name) > 0)
	   {
		   if(tc_strcmp(itemName,name) == 0)
		   {
			    if(parmDefMatchCnt == 0)
				{
					 arrSig_bom_line = (tag_t *) MEM_alloc(1 * sizeof(tag_t));
				}else
				{
					   arrSig_bom_line = (tag_t *) MEM_realloc(arrSig_bom_line,
						(parmDefMatchCnt + 1) * sizeof(tag_t));
				}
				arrSig_bom_line[parmDefMatchCnt]=childlines[i];
				parmDefMatchCnt ++;
				if(parmDefMatchCnt == 1)
				{
					break;
				}
		   }
	   }
	   FVE_FREE(itemName)
   }
   if(parmDefMatchCnt > 0)
   {
      TC_write_syslog("\n In %s: Found old Parameter Def %s in Structure ", function_name,name);
      *retunObj=arrSig_bom_line[0];
   }else
   {
	  *retunObj=NULLTAG;
   }

	FVE_FREE(childlines);
	FVE_FREE(arrSig_bom_line);
	TC_write_syslog("\n Leave %s",function_name);

	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    TC_write_syslog("\n Leave %s time = %s\n",function_name, time_stamp);
    FVE_FREE(time_stamp);
	
	return ifail;
}


/*
function to update the process object information
*/
int FVE_compare_process_object(struct FVEProcessInfostruct *processInfo,int counter,tag_t tagOldProcessObject)
{

	int		ifail							=	ITK_ok;
	char	*function_name					=	"FVE_compare_process_object";
	char	*newProcessType					=	NULL;
	char	*newTaskRate					=	NULL;
	char	*newEcuAcronym					=	NULL;
	double	taskRateDbl						=	0.0;
	char	*oldProcessType					=	NULL;
	char	*oldTaskRate					=	NULL;
	char	*oldECUAcr						=	NULL;
	logical	isProcessTypeModify					=	FALSE;
	logical	isTaskRateModify					=	FALSE;
	logical isECUAcrModify					=	FALSE;
	logical	modify							=	FALSE;
	char	*trimTaskRate					=	NULL;
	char	*remPartAfterTrim				=	NULL;
	tag_t         ecu_rev_class_id                = NULLTAG;
	tag_t         acronym_attr_id                 = NULLTAG;
	tag_t         enqid                           = NULLTAG;
    tag_t         relation_type                   = NULLTAG;
    tag_t         relation                        = NULLTAG;

    tag_t*        ecu_revs                        = NULL;
	 char*         value[1]                        = {""};
	  int           ecu_count                       = 0;


	TC_write_syslog("\n Enter %s",function_name);
	newProcessType		=	processInfo[counter].processType;
	newTaskRate			=	processInfo[counter].taskRate;
	newEcuAcronym		=	ecuAcronym;
	if(tagOldProcessObject)
	{
		ITK(AOM_ask_value_string(tagOldProcessObject,FVE_ProcessTypePROP,&oldProcessType))
		ITK(AOM_ask_value_string(tagOldProcessObject,FVE_ECUAcronymPROP,&oldECUAcr))
		ITK(AOM_ask_value_double(tagOldProcessObject,FVE_TaskRatePROP,&taskRateDbl))
		FVE_truncate_double_values(taskRateDbl, &oldTaskRate);

		//ecu Acronym
		if(newEcuAcronym)
		{
			if(oldECUAcr)
			{
				if( tc_strcmp(FV_trim_blanks(oldECUAcr),FV_trim_blanks(newEcuAcronym)) != 0 )
				{
					isECUAcrModify=TRUE;
					TC_write_syslog("\n In %s: ECU Acronym modified:", function_name);
					TC_write_syslog("\n Old ECUAcronym = %s \n New ECUAcronym = %s \n",
					 oldECUAcr,newEcuAcronym);
				}

			}else
			{
				isECUAcrModify=TRUE;
			}
		}

		if(newProcessType)
		{
			//process type
			if(oldProcessType)
			{
				if( tc_strcmp(FV_trim_blanks(oldProcessType),FV_trim_blanks(newProcessType)) != 0 )
				{
					isProcessTypeModify=TRUE;
					TC_write_syslog("\n In %s: Process Type modified:", function_name);
					TC_write_syslog("\n Old ProcessType = %s \n New ProcessType = %s \n",
					 oldProcessType,newProcessType);
				}
			}else
			{
				isProcessTypeModify=TRUE;
			}
		}

		//taskRate
		if(newTaskRate)
		{
			if(oldTaskRate)
			{
				//check if newTaskRate contains string ms
				char *locName =strstr(newTaskRate, "ms");
				if(locName != NULL)
				{
					ifail=fve_get_val_line("ms",newTaskRate,locName,&trimTaskRate,&remPartAfterTrim);
					if(trimTaskRate && tc_strlen(trimTaskRate) > 0)
					{
						if( tc_strcmp(FV_trim_blanks(oldTaskRate),FV_trim_blanks(trimTaskRate)) != 0 )
						{
							isTaskRateModify=TRUE;
							TC_write_syslog("\n In %s: Task Rate modified:", function_name);
							TC_write_syslog("\n Old TaskRate = %s \n New TaskRate = %s \n",
							 oldTaskRate,trimTaskRate);
						}
					}
				}else
				{
					if( tc_strcmp(FV_trim_blanks(oldTaskRate),FV_trim_blanks(newTaskRate)) != 0 )
					{
						isTaskRateModify=TRUE;
						TC_write_syslog("\n In %s: Task Rate modified:", function_name);
						TC_write_syslog("\n Old TaskRate = %s \n New TaskRate = %s \n",
						 oldTaskRate,newTaskRate);
					}
				}
			}else
			{
				isTaskRateModify=TRUE;
			}
		}

		if(isECUAcrModify || isProcessTypeModify || isTaskRateModify)
		{
			modify=TRUE;
		}

		if(modify)
		{
			AM__set_application_bypass(TRUE);
			/*
			 If different ECU is used during import for same set of  process files
			 create the relation "FVE_Mod_Proc_Relation" between the new ECU and existing process object.
			*/
			ITK(AOM_refresh(tagOldProcessObject,TRUE))
			if(isProcessTypeModify)
			{
				ITK(AOM_set_value_string(tagOldProcessObject,FVE_ProcessTypePROP,newProcessType))
			}
			if(isTaskRateModify)
			{
				ITK(AOM_set_value_double(tagOldProcessObject,FVE_TaskRatePROP,atof(newTaskRate)))
			}
			if(isECUAcrModify)
			{
				 value[0] = newEcuAcronym;
 
				 ITK(POM_class_id_of_class("FVE_ECURevision", &ecu_rev_class_id))
				 ITK(POM_attr_id_of_attr("FVE_ECUAcronym", "FVE_ECURevision", &acronym_attr_id))
                 ITK(POM_create_enquiry_on_string(ecu_rev_class_id, acronym_attr_id, POM_is_equal_to, value, &enqid)) 
                 ITK(POM_execute_enquiry(enqid, &ecu_count, &ecu_revs)) 

   
				ITK(GRM_find_relation_type(MODULE_PROCESS_RELATION, &relation_type))
				ITK(GRM_create_relation(ecu_revs[0], tagOldProcessObject, relation_type, NULLTAG, &relation))
				ITK(GRM_save_relation(relation))

				FVE_FREE(ecu_revs)
  
			}

			ITK(AOM_save(tagOldProcessObject))
			ITK(AOM_refresh(tagOldProcessObject,FALSE))
			AM__set_application_bypass(FALSE);

			if( (mode != NULL) && (tc_strlen(mode) > 0) &&  (tc_strcmp(mode,PROCESS_MODE) == 0))
			{
				fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
			}
			if( (mode != NULL) && (tc_strlen(mode) > 0) &&  (tc_strcmp(mode,ALL_MODE) == 0) )
			{
				fprintf(logfileptr,"Comment: %s\n","Process attributes Updated");
			}

		}else
		{

			if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,PROCESS_MODE) == 0))
			{
				fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport.");
			}
			if( (mode != NULL) && (tc_strlen(mode) > 0) &&  (tc_strcmp(mode,ALL_MODE) == 0) )
			{
				fprintf(logfileptr,"Comment: No updates in the attribute values during reimport of <%s> \n",processInfo[counter].processName);
			}

		}

	}//tagOldProcessObject



	TC_write_syslog("\n Enter %s",function_name);
	return ifail;
}


/*
function to compare the properties of old object with new object
*/
int FVE_compare_properties(struct FVEParmDefInfostruct *parameterInfo,int counter,tag_t tagOldParmRevBl,tag_t	*newBomLineTag)
{
	int		ifail							=	ITK_ok;
	char	*function_name					=	"FVE_compare_properties";
	tag_t	tagOldParmRevObj				=	NULLTAG;
	tag_t	tagOldParmItemObj				=	NULLTAG;
	char	*bomlineItemType				=	NULL;

	int		oldNumRows=0, oldNumCols		=	0;
	int		newNumRows=0, newNumCols		=	0;
	int		rowIndex						=	0;
	int		lengthBeforeDotNew				=	0;
	int		lengthAfterDotNew				=	0;
    int     errorCode                       =   0;

	char	*newParmTypeVal					=	NULL;
	char	*newParmUsageVal				=	NULL;
	char	*newDescrVal					=	NULL;
	char	*newUnitVal						=	NULL;
	char	*newNumeratorVal				=	NULL;
	char	*newDenominatorVal				=	NULL;
	char	*newToleranceVal				=	NULL;
	char	*newPrecisionVal				=	NULL;
	char	*newMinVal						=	NULL;
	char	*newMaxVal						=	NULL;
	char	*newInitVal						=	NULL;
	char	*newfaultVal					=	NULL;
	char	*newRestrictedVal				=	NULL;
	char	*newInhaleExhaleVal				=	NULL;
	char	*newAsBuiltVehOpVal				=	NULL;
	char	*newModuleManfVal				=	NULL;
	char	*newFcsdCustPrefVal				=	NULL;

	char	*oldParmTypeVal					=	NULL;
	char	*oldParmUsageVal				=	NULL;
	char	*oldDescrVal					=	NULL;
	char	*oldUnitVal						=	NULL;
	char	**oldMinValues					=	NULL;
	char	**oldMaxValues					=	NULL;
	char	**oldInitValues					=	NULL;
	char	*old_sedInitialValue			=	NULL;
	double	oldNumeratorValDbl				=	0.0;
	double	oldDenominatorValDbl			=	0.0;
	int		oldNumeratorValInt				=	0;
	int		oldDenominatorValInt			=	0;
	double	oldToleranceValDbl				=	0.0;
	int		oldPrecisionVal					=	0;
	char	*oldNumeratorValue				=	NULL;
	char	*oldDenominatorValue			=	NULL;
	char	*oldToleranceValue				=	NULL;
	char	*oldPrecisionValue				=	NULL;
	char	*oldfaultVal					=	NULL;
	char	*oldRestrictedVal				=	NULL;
	char	*oldInhaleExhaleVal				=	NULL;
	char	*oldAsBuiltVehOpVal				=	NULL;
	char	*oldModuleManfVal				=	NULL;
	char	*oldFcsdCustPrefVal				=	NULL;
	char	**oldValidValues				=	NULL;
	char	**oldDomainElNames				=	NULL;
	char	*oldSectionVal					=	NULL;
	char	*newSectionVal					=	NULL;
	char*		oldSize						=	NULL;
	char*		newSize						=	NULL;
	logical	oldIsSignedVal					=	FALSE;
	logical	newIsSignedVal					=	FALSE;


	tag_t	tableDefTag						=	NULLTAG;

	logical	modify							=	FALSE;
	logical	compareMinMaxInit				=	FALSE;
	logical	isDescrModify					=	FALSE;
	logical	isSectionModify					=	FALSE;
	logical	isSizeModify					=	FALSE;
	logical	isParmTypeModify				=	FALSE;
	logical	isParmUsageModify				=	FALSE;
	logical	isUnitModify					=	FALSE;
	logical	isFaultValModify				=	FALSE;
	logical	isRestrictedValModify				=	FALSE;
	logical	isInhaleExhaleValModify				=	FALSE;
	logical	isAsBuiltVehOpValModify				=	FALSE;
	logical	isModuleManfValModify				=	FALSE;
	logical	isFcsdCustPrefValModify				=	FALSE;

	logical	isSignedModify					=	FALSE;
	logical	isNumerModify					=	FALSE;
	logical	isDenomiModify					=	FALSE;
	logical	isPrecisionModify				=	FALSE;
	logical	isToleranceModify				=	FALSE;
	logical	isRowCntModify					=	FALSE;
	logical	isColCntModify					=	FALSE;
	logical	isMinValModify					=	FALSE;
	logical	isMaxValModify					=	FALSE;
	logical	isInitValModify					=	FALSE;
	logical	isValidValModify				=	FALSE;
	logical	lgDomainElName					=	false;
	logical	lgDomainElValue					=	false;
	logical	lgDomainDDModify				=	false;
	logical	lgInitValMatchFound				=	false;
	logical	lgMisMatchCount					=	false;
	logical	flagMsg							=	false;

	//logical flags based on the parmDef Type
	logical isObjDblType					=	FALSE;
	logical isObjIntType					=	FALSE;
	logical isObjSedType					=	FALSE;
	logical	isObjStrType					=	FALSE;
	logical	isObjHexType					=	FALSE;

	logical	intReqPropModify				=	FALSE;
	logical	doubleReqPropModify				=	FALSE;
	logical	sedReqPropModify				=	FALSE;
	logical	strReqPropModify				=	FALSE;
	logical	hexReqPropModify				=	FALSE;
	logical	commonReqPropModify				=	FALSE;

	logical isRowLabelModify				=	false;
	logical isColumnLabelModify				=	false;
	logical	lgRowLabelMisMatchFound			=	false;
	logical	lgColumnLabelMisMatchFound		=	false;
	logical	lgInitialValMisMatchFound		=	false;
	logical	lgMinValMisMatchFound			=	false;
	logical	lgMaxValMisMatchFound			=	false;
	logical validRowCol_basedStrOfdata		=	true;

	double		numerator_val_dbl			=	0.0;
	double		denominator_val_dbl			=	0.0;
	double		precision_val_dbl			=	0.0;
	double		tolerance_val_dbl			=	0.0;

	//SED -domain element specific attributes
	int			indexCounter		=	0;
	int			iCounter		=	0;
	int			jCounter		=	0;
	char		*domainElVal[]		=	{""};  //newInitial value for SED type
	char		*trimDomainElName	=	NULL;
	char		*trimInitValue		=	NULL;
	int			cntDomainElName		=	0;
	char		**valDomainElName	=	NULL;
	int			cntDomainElVal		=	0;
	char		**valDomainElVal	=	NULL;   //newValidValues for SED type
	char		*newDomainDescriptionVal=NULL;
	char		**oldDomainDescrVal		=	NULL;
	char		**newDomainDescrVal		=	NULL;
	char		*finalStrDD				=	NULL;
	int			newCntDD				=	0;
	int			oldCntDD				=	0;
	int			oldDomainElNameCnt		=	0;
	int			minVal					=	0;
	int			maxVal					=	0;
	int			initVal					=	0;

	int		newRowLabelCnt		=	0;
	char	**newRowLabelNames	=	NULL;
	int		newColLabelCnt		=	0;
	char	**newColLabelNames	=	NULL;
	int		oldRowLabelCnt		=	0;
	char	**oldRowLabelNames	=	NULL;
	int		oldColLabelCnt		=	0;
	char	**oldColLabelNames	=	NULL;
	int     newInitValArrayCnt	=	0;
	char	**newInitValArray	=	NULL;
	int		dummyInitValArrayCnt	=	0;
	char	**dummyInitValArray		=	NULL;
	int     newMinValArrayCnt	=	0;
	char	**newMinValArray	=	NULL;
	int     dummyMinValArrayCnt	=	0;
	char	**dummyMinValArray	=	NULL;
	int     newMaxValArrayCnt	=	0;
	char	**newMaxValArray	=	NULL;
	int     dummyMaxValArrayCnt	=	0;
	char	**dummyMaxValArray	=	NULL;
	char	*commaDelimExist	=	NULL;
	char	*semiColonDelimExist	=	NULL;
	logical		isMinNegative		=	false;
	logical		isMaxNegative		=	false;
	logical		isInitNegative		=	false;
	char	*newVal					=	NULL;
	char	*newVal1				=	NULL;
	char*       indexOfX      = NULL;


	logical  compareRowLabelFlag	=	false;
	logical  compareColumnLabelFlag	=	false;
	/* based on the structure of data , no of rows and columns should satisfy the requirment
	e.g. 1D array , 1D Lookup should always contain row =1 and column>=1
	     2D lookup , 2D array should always contain row>1 and column>=1
	*/
	
	
	char *indexFirstMin				=NULL;
	char *indexFirstMax				=NULL;
	char *indexFirstInit			=NULL;
	char line_starts_withMin[128]	= "";
	char line_starts_withMax[128]	= "";
	char line_starts_withInit[128]	= "";
	int	index=0;

    logical  isPartTypeValValid = FALSE;
    tag_t    partTypeLovTag = NULLTAG;

	//validator
	int	validatorIntCnt	=	0;
	char **validatorIntArray	=	NULL;
	int	validatorMinCnt	=	0;
	char **validatorMinArray	=	NULL;
	int	validatorMaxCnt	=	0;
	char **validatorMaxArray	=	NULL;
	
	tag_t	newlyAddedBl		=	NULLTAG;
	tag_t	newParmRevTag		=	NULLTAG;
    time_t      clock;

	TC_write_syslog("\n Enter %s",function_name);
    time( &clock );
    TC_write_syslog("Start time: %s\n", ctime(&clock));

	newDescrVal			=	parameterInfo[counter].descr;
	newParmTypeVal		=	parameterInfo[counter].paraType;
	newParmUsageVal		=	parameterInfo[counter].paraUsage;
	newfaultVal			=	parameterInfo[counter].faultVal;
	newRestrictedVal	=	parameterInfo[counter].restricted;
	newInhaleExhaleVal	=	parameterInfo[counter].inhaleExhale;
	newFcsdCustPrefVal	=	parameterInfo[counter].fcsdCustPref;
	newModuleManfVal	=	parameterInfo[counter].moduleManf;
	newAsBuiltVehOpVal	=	parameterInfo[counter].asBuiltVehOp;
	newDomainDescriptionVal =parameterInfo[counter].domainElDescr;
	newSectionVal		=	parameterInfo[counter].configGrp;
	newSize				=	parameterInfo[counter].size;
	
	// Check if given Part Type is valid lov value
	ITK(LOV_find_attached_prop(ParmDefRevisionTYPE, fv9PartTypePROP, &partTypeLovTag))
    if(partTypeLovTag != NULLTAG)
		ITK(LOV_is_value_valid_string(partTypeLovTag, parameterInfo[counter].configGrp, &isPartTypeValValid))

	if(parameterInfo[counter].type != NULL && tc_strcmp(parameterInfo[counter].type,FVE_ParmDefDblTYPE) == 0)
	{
		compareMinMaxInit	=	TRUE;
		isObjDblType		=	TRUE;
		newUnitVal			=	parameterInfo[counter].engUnit;
		newNumRows			=	parameterInfo[counter].rowCnt;
		newNumCols			=	parameterInfo[counter].colCnt;
		newNumeratorVal		=	parameterInfo[counter].numerator;
		newDenominatorVal	=	parameterInfo[counter].denominator;
		newPrecisionVal		=	parameterInfo[counter].precision;

		if(parameterInfo[counter].tolerance && tc_strlen(parameterInfo[counter].tolerance)> 0)
		{
			newToleranceVal		=	parameterInfo[counter].tolerance;
			//printf("\n tolerance value from csv file \n");
		}else if(toleranceExistInConfigFile && tc_strlen(toleranceExistInConfigFile)> 0)
		{
			newToleranceVal=toleranceExistInConfigFile;
			//printf("\n tolerance value from configuration file \n");
		}else
		{
			newToleranceVal="1";
			//printf("\n defaulting tolerance value to 1 \n");
		}
	}
	else if(parameterInfo[counter].type != NULL && tc_strcmp(parameterInfo[counter].type,FVE_ParmDefIntTYPE) == 0)
	{
		compareMinMaxInit	=	TRUE;
		isObjIntType		=	TRUE;
		newUnitVal			=	parameterInfo[counter].engUnit;
		newNumRows			=	parameterInfo[counter].rowCnt;
		newNumCols			=	parameterInfo[counter].colCnt;
		newNumeratorVal		=	parameterInfo[counter].numerator;
		newDenominatorVal	=	parameterInfo[counter].denominator;
	}
    else if(parameterInfo[counter].type != NULL && tc_strcmp(parameterInfo[counter].type,FVE_ParmDefSEDTYPE) == 0)
	{
		isObjSedType		=	TRUE;
		newInitVal			=	parameterInfo[counter].initVal;
		//newValidValues		=	parameterInfo[counter].validValues;

		//check for domain element name
		if( (parameterInfo[counter].domainElName != NULL) && (tc_strlen(parameterInfo[counter].domainElName )> 0))
		{
			//get the rows
			split_the_string(parameterInfo[counter].domainElName,COMMA_DELIM,&cntDomainElName,&valDomainElName);
			if((cntDomainElName > 0) && (valDomainElName != NULL))
			{
				lgDomainElName=true;
				newNumRows	=	cntDomainElName;
				newNumCols	=	1;
			}
		}

		//check for domain element values
		if( (parameterInfo[counter].domainElVal != NULL) && (tc_strlen(parameterInfo[counter].domainElVal )> 0))
		{
			//get the valid values
			split_the_string(parameterInfo[counter].domainElVal,COMMA_DELIM,&cntDomainElVal,&valDomainElVal);
			if((cntDomainElVal > 0) && (valDomainElVal != NULL))
			{
				lgDomainElValue=true;
			}
		}

		//check for initial value
		if( (parameterInfo[counter].initVal != NULL) && (tc_strlen(parameterInfo[counter].initVal )> 0))
		{
			ifail=FVE_remove_invalidChars(parameterInfo[counter].initVal,&trimInitValue);
			if(cntDomainElName == cntDomainElVal)
			{
				//check if initial value exist in domain element values
				if((lgDomainElValue == true) && (cntDomainElVal > 0) && (valDomainElVal != NULL) )
				{
					if((lgDomainElName == true) && (cntDomainElName > 0) && (valDomainElName != NULL))
					{
						for(indexCounter =0; indexCounter<cntDomainElName ; indexCounter++)
						{
							ifail=FVE_remove_invalidChars(valDomainElName[indexCounter],&trimDomainElName);
							if(trimInitValue && trimDomainElName && tc_strlen(trimDomainElName)> 0 && tc_strlen(trimInitValue)> 0)
							{
								if( stricmp(trimInitValue,trimDomainElName) == 0)
								{
									lgInitValMatchFound=true;
									*domainElVal	=valDomainElVal[indexCounter];
									break;
								}
							}
							FVE_FREE(trimDomainElName)
						}//for
					}//lgDomainElName
				}//lgDomainElValue
			}//cntDomainElName == cntDomainElVal
			else
			{
				lgMisMatchCount=true;
			}
			FVE_FREE(trimInitValue)
		}//initial value
		//Validator 
		if(lgInitValMatchFound == false)
		{
			//
			 errorCode = FV_CCDM_ERROR_INVALID_INITVALUE;
             ifail = ITK_ok;
             if(logFilePtrFailure == NULL)
		     {
			        logFilePtrFailure = fopen(file_pathFailure, "w+");
			        fprintf(logFilePtrFailure,"Failed parameter List\n");
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"\n");
			        if(logFilePtrFailure)
			        {
				        fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
			        }
			        fprintf(logFilePtrFailure,"Logged in successfully.\n");
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"Dictionary Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
			        fprintf(logFilePtrFailure,"\n");
		     }
             failureCntParameter++;
             ITK(FV_log_validation_error(errorCode, parameterInfo[counter].name))
             goto CLEANUP;
		}

	}//SED Type
	else if(parameterInfo[counter].type != NULL && tc_strcmp(parameterInfo[counter].type,FVE_ParmDefStrTYPE) == 0)
	{
		compareMinMaxInit	=	TRUE;
		isObjStrType		=	TRUE;
		newUnitVal			=	parameterInfo[counter].engUnit;
		newNumRows			=	parameterInfo[counter].rowCnt;
		newNumCols			=	parameterInfo[counter].colCnt;
	}
	else if(parameterInfo[counter].type != NULL && tc_strcmp(parameterInfo[counter].type,FVE_ParmDefHexTYPE) == 0)
	{
		compareMinMaxInit	=	TRUE;
		isObjHexType		=	TRUE;
		newUnitVal			=	parameterInfo[counter].engUnit;
		newNumRows			=	parameterInfo[counter].rowCnt;
		newNumCols			=	parameterInfo[counter].colCnt;
	}
    time( &clock );
    TC_write_syslog("Start time tagOldParmRevBl: %s\n", ctime(&clock));

	//get the itemRevision from Bomline
	if(tagOldParmRevBl)
	{
		ITK(AOM_ask_value_tag(tagOldParmRevBl,bomAttr_lineItemRevTag, &tagOldParmRevObj))
		ITK(AOM_ask_value_tag(tagOldParmRevBl,bomAttr_lineItemTag,&tagOldParmItemObj))
		ITK(AOM_ask_value_string(tagOldParmRevBl,bomAttr_itemType,&bomlineItemType))

		//get the properties for current item
		ITK(AOM_ask_value_string(tagOldParmItemObj,parmTypePROP,&oldParmTypeVal))
		ITK(AOM_ask_value_string(tagOldParmItemObj,FVE_ParameterUsagePROP,&oldParmUsageVal))

		//get the properties for current revision
		ITK(AOM_ask_value_string(tagOldParmRevObj,object_descPROP,&oldDescrVal))

		ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_FaultValuePROP,&oldfaultVal))
		ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_RestrictedPROP,&oldRestrictedVal))
		ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_ModulemanfIndPROP,&oldModuleManfVal))
		ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_InhaleExhaleIndPROP,&oldInhaleExhaleVal))
		ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_AsBuiltVehOpsPROP,&oldAsBuiltVehOpVal))
		ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_FCSDCustPrefPROP,&oldFcsdCustPrefVal))
		ITK(AOM_ask_value_string(tagOldParmRevObj,fv9PartTypePROP,&oldSectionVal))
		ITK(AOM_UIF_ask_value(tagOldParmRevObj, sizePROP, &oldSize));

		
		/*ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_CommentsPROP,&oldDomainDescriptionVal));
		//get the old domain descr stored on IR seperated by "\n"
		if(oldDomainDescriptionVal && tc_strlen(oldDomainDescriptionVal)> 0)
		{
			split_the_string(oldDomainDescriptionVal,"\n",&oldCntDD,&oldDomainDescrVal);
		}
		*/
		//get the new domain descr from csv file seperated by delimiter $$
		if(newDomainDescriptionVal && tc_strlen(newDomainDescriptionVal)> 0)
		{
			split_the_string(newDomainDescriptionVal,CSV_DOMAINDESCR_DELIMITER,&newCntDD,&newDomainDescrVal);
		}

		//get the number of rows & column information
		ITK(AOM_ask_value_tag(tagOldParmRevObj,"tableDefinition",&tableDefTag))
		//get the old count for rows and column
		if(tableDefTag != NULLTAG)
		{
			ITK(AOM_ask_value_int(tableDefTag, colsPROP, &oldNumCols));
			ITK(AOM_ask_value_int(tableDefTag, rowsPROP, &oldNumRows));
		}
		
		if( (bomlineItemType) && ((tc_strcmp(bomlineItemType ,FVE_ParmDefStrTYPE) == 0)))
		{
			ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_EngUnitPROP,&oldUnitVal))

			ITK(FVE_get_value_arrays(tagOldParmRevObj,minValuesPROP,&oldMinValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,maxValuesPROP,&oldMaxValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,initialValuesPROP,&oldInitValues))
		}
		if( (bomlineItemType) && ((tc_strcmp(bomlineItemType ,FVE_ParmDefHexTYPE) == 0)))
		{
			//for hex type irrespective od structure of data , rowLabels ,columnLabels exist.
			ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_EngUnitPROP,&oldUnitVal))

			ITK(FVE_get_value_arrays(tagOldParmRevObj,minValuesPROP,&oldMinValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,maxValuesPROP,&oldMaxValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,initialValuesPROP,&oldInitValues))
			if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup2DInfo) == 0)
			{
				//get the rowlabels and columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows >1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup1DInfo) == 0)
			{
				//get the columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows ==1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Array1DInfo) == 0)
			{
				//get the columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows ==1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Array2DInfo) == 0)
			{
				//get the columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows >1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}
		}
		if( (bomlineItemType) && ((tc_strcmp(bomlineItemType ,FVE_ParmDefDblTYPE) == 0)))
		{
			ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_EngUnitPROP,&oldUnitVal))

			ITK(FVE_get_value_arrays(tagOldParmRevObj,minValuesPROP,&oldMinValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,maxValuesPROP,&oldMaxValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,initialValuesPROP,&oldInitValues))

			ITK(AOM_ask_value_double(tagOldParmRevObj,resolution_numeratorPROP,&oldNumeratorValDbl))
			ITK(AOM_ask_value_double(tagOldParmRevObj,resolution_denominatorPROP,&oldDenominatorValDbl))
			ITK(AOM_ask_value_double(tagOldParmRevObj,tolerancePROP,&oldToleranceValDbl))

			//truncate zeros for numerator , denominator , precision ,tolerance , min ,max and initial values
			FVE_truncate_double_values(oldNumeratorValDbl, &oldNumeratorValue);
			FVE_truncate_double_values(oldDenominatorValDbl, &oldDenominatorValue);
			FVE_truncate_double_values(oldToleranceValDbl, &oldToleranceValue);

			ITK(AOM_ask_value_int(tagOldParmRevObj,precisionPROP,&oldPrecisionVal))
			oldPrecisionValue = (char *) MEM_alloc((int)(oldPrecisionVal + 1) * sizeof(char));
			sprintf(oldPrecisionValue,"%d",oldPrecisionVal);


			if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup2DInfo) == 0)
			{
				//get the rowlabels and columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows >1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}

			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup1DInfo) == 0)
			{
				//get the columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows ==1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Array1DInfo) == 0)
			{
				//get the columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows ==1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Array2DInfo) == 0)
			{
				//get the columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;

				if(newNumRows >1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}

		}
		if( (bomlineItemType) &&  ((tc_strcmp(bomlineItemType ,FVE_ParmDefIntTYPE) == 0)) )
		{
			ITK(AOM_ask_value_string(tagOldParmRevObj,FVE_EngUnitPROP,&oldUnitVal))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,minValuesPROP,&oldMinValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,maxValuesPROP,&oldMaxValues))
			ITK(FVE_get_value_arrays(tagOldParmRevObj,initialValuesPROP,&oldInitValues))

			ITK(AOM_ask_value_int(tagOldParmRevObj, resolution_numeratorPROP, &oldNumeratorValInt))
			ITK(AOM_ask_value_int(tagOldParmRevObj, resolution_denominatorPROP, &oldDenominatorValInt))

			oldNumeratorValue = (char*)MEM_alloc((int)(oldNumeratorValInt + 1) * sizeof(char));
			sprintf(oldNumeratorValue, "%d", oldNumeratorValInt);

			oldDenominatorValue = (char*)MEM_alloc((int)(oldDenominatorValInt + 1) * sizeof(char));
			sprintf(oldDenominatorValue, "%d", oldDenominatorValInt);


			if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup2DInfo) == 0)
			{
				//get the rowlabels and columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows >1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}

			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup1DInfo) == 0)
			{
				//get the columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows ==1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Array1DInfo) == 0)
			{
				//get the rowlabels and columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;
				if(newNumRows ==1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}else if( tc_strcmp(parameterInfo[counter].structureOfData,Array2DInfo) == 0)
			{
				//get the rowlabels and columlabels for revision
				ifail=FVE_get_labels(tagOldParmRevObj,rowLabelsPROP,&oldRowLabelCnt,&oldRowLabelNames);
				ifail=FVE_get_labels(tagOldParmRevObj,colLabelsPROP,&oldColLabelCnt,&oldColLabelNames);
				compareRowLabelFlag=true;
				compareColumnLabelFlag=true;

				if(newNumRows >1 && newNumCols>=1)
				{
					validRowCol_basedStrOfdata=true;
				}else
				{
					validRowCol_basedStrOfdata=false;
				}
			}


		}
		if( (bomlineItemType) &&  ((tc_strcmp(bomlineItemType ,FVE_ParmDefSEDTYPE) == 0)) )
		{
			//get the valid values for SED type
			ITK(FVE_get_value_arrays(tagOldParmRevObj, validValuesPROP,&oldValidValues));
			//get the description i.e. domain element name for the sed
			ITK(FVE_get_desc_array(tagOldParmRevObj, validValuesPROP,"desc",&oldDomainElNames,&oldDomainElNameCnt));
			//get the domain description for sed type
			ITK(FVE_get_desc_array(tagOldParmRevObj, validValuesPROP,"fnd0DomainElementDesc",&oldDomainDescrVal,&oldCntDD));
			ITK(AOM_ask_value_string(tagOldParmRevObj, initialValuePROP, &old_sedInitialValue))
		}

	}//tagOldParmRevBl
    time( &clock );
    TC_write_syslog("End time tagOldParmRevBl: %s\n", ctime(&clock));

	//Now compare properties of old rev with current values from csv file
	if(isObjSedType)
	{
		if(newCntDD == oldCntDD)
		{
			if(newDomainDescrVal && oldDomainDescrVal && tc_strlen(*newDomainDescrVal)> 0 && tc_strlen(*oldDomainDescrVal)> 0)
			{
				for(rowIndex=0;rowIndex<newCntDD;rowIndex++)
				{
					if(tc_strcmp(FV_trim_blanks(newDomainDescrVal[rowIndex]),FV_trim_blanks(oldDomainDescrVal[rowIndex]))!=0)
					{
							lgDomainDDModify=true;
							break;
					}
					if(lgDomainDDModify == true)
						break;
				}//rowIndex=0
			}
		}else
		{
			lgDomainDDModify	=	true;
		}
	}//isObjSedType
	
	
	if(newDescrVal && tc_strlen(newDescrVal)> 0)
	{
		if(oldDescrVal && tc_strlen(oldDescrVal)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldDescrVal),FV_trim_blanks(newDescrVal)) != 0)
			{
				if(tc_strcmp(FV_trim_blanks(oldDescrVal),"Description is more than the specified length. Refer to the extended description field for full description") ==0)
				{
				}else
				{
					isDescrModify=TRUE;
					TC_write_syslog("\n In %s: Description modified:", function_name);
					TC_write_syslog("\n Old Descr = %s \n New Descr = %s \n",
					oldDescrVal,newDescrVal);
				}
			}
		}else
		{
			isDescrModify=TRUE;
		}
	}else if(oldDescrVal && tc_strlen(oldDescrVal)> 0)
	{
		isDescrModify=TRUE;
	}

	//section
	if(isPartTypeValValid)
	{
		if(newSectionVal && tc_strlen(newSectionVal)>0)
		{
			if(oldSectionVal && tc_strlen(oldSectionVal)> 0)
			{
				if(tc_strcmp(FV_trim_blanks(oldSectionVal),FV_trim_blanks(newSectionVal)) != 0)
				{
					isSectionModify=TRUE;
				}
			}else
			{
				isSectionModify=TRUE;
			}
		}else if(oldSectionVal && tc_strlen(oldSectionVal)> 0)
		{
			isSectionModify=TRUE;
		}
	}else
	{
		TC_write_syslog("\n WARNING: Could not Compare Configuration Group as \"%s\" is not a valid value. \n", parameterInfo[counter].configGrp);
	}
	
	//size
	if(newSize && tc_strlen(newSize) > 0)
	{
		if(oldSize && tc_strlen(oldSize)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldSize),FV_trim_blanks(newSize)) !=0 )
			{
				isSizeModify=TRUE;
			}
		}else
		{
			isSizeModify=TRUE;
		}
	}else if(oldSize && tc_strlen(oldSize)> 0)
	{
		isSizeModify=TRUE;
	}
	if(newParmTypeVal && tc_strlen(newParmTypeVal)> 0)
	{
		if(oldParmTypeVal && tc_strlen(oldParmTypeVal)> 0)
		{
			if( tc_strcmp(FV_trim_blanks(oldParmTypeVal),FV_trim_blanks(newParmTypeVal)) != 0 )
			{
				isParmTypeModify=TRUE;
				TC_write_syslog("\n In %s: Parameter Type modified:", function_name);
				TC_write_syslog("\n Old ParmType = %s \n New ParmType = %s \n",
                  oldParmTypeVal,newParmTypeVal);
			}
		}else
		{
			isParmTypeModify=TRUE;
		}
	}

	if(newParmUsageVal && tc_strlen(newParmUsageVal)> 0)
	{
		if(oldParmUsageVal && tc_strlen(oldParmUsageVal)> 0)
		{
			if( tc_strcmp(FV_trim_blanks(oldParmUsageVal),FV_trim_blanks(newParmUsageVal)) != 0 )
			{
				isParmUsageModify=TRUE;
				TC_write_syslog("\n In %s: Parameter Usage modified:", function_name);
				TC_write_syslog("\n Old ParmUsage = %s \n New ParmUsage = %s \n",
                  oldParmUsageVal,newParmUsageVal);
			}
		}else
		{
			isParmUsageModify=TRUE;
		}
	}

	if(newfaultVal && tc_strlen(newfaultVal)> 0)
	{
		if(oldfaultVal && tc_strlen(oldfaultVal)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldfaultVal),FV_trim_blanks(newfaultVal)) != 0)
			{
				isFaultValModify = TRUE;
				TC_write_syslog("\n In %s: Fault Value modified:", function_name);
				TC_write_syslog("\n Old FaultVal= %s \n New FaultVal= %s \n",
                  oldfaultVal,newfaultVal);
			}
		}else
		{
			isFaultValModify = TRUE;
		}
	}else if(oldfaultVal && tc_strlen(oldfaultVal)> 0)
	{
		isFaultValModify = TRUE;
	}

	if(newRestrictedVal && tc_strlen(newRestrictedVal)> 0)
	{
		if(oldRestrictedVal && tc_strlen(oldRestrictedVal)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldRestrictedVal),FV_trim_blanks(newRestrictedVal)) != 0)
			{
				isRestrictedValModify = TRUE;
			}
		}else
		{
			isRestrictedValModify = TRUE;
		}
	}else if(oldRestrictedVal && tc_strlen(oldRestrictedVal)> 0)
	{
		isRestrictedValModify = TRUE;
	}

	if(newModuleManfVal && tc_strlen(newModuleManfVal)> 0)
	{
		if(oldModuleManfVal && tc_strlen(oldModuleManfVal)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldModuleManfVal),FV_trim_blanks(newModuleManfVal)) != 0)
			{
				isModuleManfValModify=TRUE;
			}

		}else
		{
			isModuleManfValModify=TRUE;
		}
	}else if(oldModuleManfVal && tc_strlen(oldModuleManfVal)> 0)
	{
		isModuleManfValModify=TRUE;
	}

	if(newInhaleExhaleVal && tc_strlen(newInhaleExhaleVal) > 0)
	{
		if(oldInhaleExhaleVal && tc_strlen(oldInhaleExhaleVal)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldInhaleExhaleVal),FV_trim_blanks(newInhaleExhaleVal)) != 0)
			{
				isInhaleExhaleValModify=TRUE;
			}
		}else
		{
			isInhaleExhaleValModify=TRUE;
		}
	}else if(oldInhaleExhaleVal && tc_strlen(oldInhaleExhaleVal)> 0)
	{
		isInhaleExhaleValModify=TRUE;
	}

	if(newFcsdCustPrefVal && tc_strlen(newFcsdCustPrefVal)> 0)
	{
		if(oldFcsdCustPrefVal && tc_strlen(oldFcsdCustPrefVal) > 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldFcsdCustPrefVal),FV_trim_blanks(newFcsdCustPrefVal)) != 0)
			{
				isFcsdCustPrefValModify=TRUE;
			}
		}else
		{
			isFcsdCustPrefValModify=TRUE;
		}
	}else if(oldFcsdCustPrefVal && tc_strlen(oldFcsdCustPrefVal) > 0)
	{
		isFcsdCustPrefValModify=TRUE;
	}

	if(newAsBuiltVehOpVal && tc_strlen(newAsBuiltVehOpVal)> 0)
	{
		if(oldAsBuiltVehOpVal && tc_strlen(oldAsBuiltVehOpVal)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(oldAsBuiltVehOpVal),FV_trim_blanks(newAsBuiltVehOpVal)) != 0)
			{
				isAsBuiltVehOpValModify=TRUE;
			}
		}else
		{
			isAsBuiltVehOpValModify=TRUE;
		}
	}else if(oldAsBuiltVehOpVal && tc_strlen(oldAsBuiltVehOpVal)> 0)
	{
		isAsBuiltVehOpValModify=TRUE;
	}



	if(isObjDblType == TRUE || isObjIntType == TRUE || isObjStrType == TRUE || isObjHexType == TRUE)
	{
		if(newUnitVal != NULL && tc_strlen(newUnitVal)> 0)
		{
			if( (tc_strcmp(newUnitVal,UNITLESS_UNIT)== 0) )
			{
				//unit not modified
			}else if( (tc_strcmp(newUnitVal,oldUnitVal) != 0) )
			{
				//unit modified
				isUnitModify = TRUE;
				TC_write_syslog("\n In %s: Unit modified:", function_name);
				TC_write_syslog("\n Old Unit = %s \n New Unit = %s \n",
                 oldUnitVal, newUnitVal);
			}
		}

		if(newNumRows != oldNumRows)
		{
			isRowCntModify = TRUE;
			TC_write_syslog("\n In %s: Row Count modified:", function_name);
			TC_write_syslog("\n Old RowCount = %d \n New RowCount = %d \n",
                  oldNumRows,newNumRows);
		}
		if(newNumCols != oldNumCols)
		{
			isColCntModify = TRUE;
			TC_write_syslog("\n In %s: Column Count modified:", function_name);
			TC_write_syslog("\n Old ColumnCount = %d \n New ColumnCount = %d \n",
                 oldNumCols, newNumCols);
		}
	}

	/*Get the set of new Min/Max/Initial Values based on the structure of data...
		  In csv file following use cases may exist.
		  matching parmdefrev	2D LOOKUP  = 2X3
								1D LOOKUP  = 1X5
								2D array   = 3X9
								1D array   = 1X4
			csv file may contain single value for Min/Max/Initial  or its equal to newNumRows*newNumCols
	 		so before comparing we need to parse newMinVal/newMaxVal/newInitVal to make sure if this string contains single value or multiple values(rows*columns)

	*/
	if(compareMinMaxInit && validRowCol_basedStrOfdata)
	{
		if(isObjDblType == TRUE || isObjIntType == TRUE)
		{
			ITK(AOM_ask_value_logical(tagOldParmRevObj,isSignedPROP,&oldIsSignedVal))
		}
		if(parameterInfo[counter].structureOfData && tc_strlen(parameterInfo[counter].structureOfData)> 0)
		{
			if( tc_strcmp(parameterInfo[counter].structureOfData,ScalarInfo) == 0)
			{
				newInitVal		=	 parameterInfo[counter].initVal;
				newMaxVal		=	 parameterInfo[counter].maxVal;
				newMinVal		=	 parameterInfo[counter].minVal;

				if(isObjDblType == TRUE || isObjIntType == TRUE)
				{
					//minVal	=	atoi(parameterInfo[counter].minVal);
					//maxVal	=	atoi(parameterInfo[counter].maxVal);
					//initVal	=	atoi(parameterInfo[counter].initVal);
                    if(parameterInfo[counter].minVal != NULL)
                    {
					    indexFirstMin=strchr(parameterInfo[counter].minVal,'-');
                        if(indexFirstMin != NULL)
                        {
					        index = (int)(indexFirstMin - parameterInfo[counter].minVal);
					        sprintf(line_starts_withMin,"%.*s",(index+1)-0,&parameterInfo[counter].minVal[0]);
					        index=0;
					        if(tc_strcmp(line_starts_withMin,"-") == 0)
					        {
						        minVal=-1;
					        }
                        }
                    }

					if(parameterInfo[counter].maxVal != NULL)
                    {
                        indexFirstMax=strchr(parameterInfo[counter].maxVal,'-');
                        if(indexFirstMax != NULL)
                        {
					        index = (int)(indexFirstMax - parameterInfo[counter].maxVal);
					        sprintf(line_starts_withMax,"%.*s",(index+1)-0,&parameterInfo[counter].maxVal[0]);
					        index=0;
					        if(tc_strcmp(line_starts_withMax,"-") == 0)
					        {
						        maxVal=-1;
					        }
                        }
                    }

					if(parameterInfo[counter].initVal != NULL)
                    {
                        indexFirstInit=strchr(parameterInfo[counter].initVal,'-');
                        if(indexFirstInit != NULL)
                        {
					        index = (int)(indexFirstInit - parameterInfo[counter].initVal);
					        sprintf(line_starts_withInit,"%.*s",(index+1)-0,&parameterInfo[counter].initVal[0]);
					        index=0;
					        if(tc_strcmp(line_starts_withInit,"-") == 0)
					        {
						        initVal=-1;
					        }
                        }
                    }
					if(minVal < 0 || maxVal < 0 || initVal < 0)
					{
						newIsSignedVal=TRUE;
					}
				}
			}
			if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup2DInfo) == 0)
			{
				//get the rowlables and columnLabels
				if(parameterInfo[counter].rowLabels && tc_strlen(parameterInfo[counter].rowLabels)> 0)
				{
					split_the_string(parameterInfo[counter].rowLabels,COMMA_DELIM,&newRowLabelCnt,&newRowLabelNames);
					if(newRowLabelCnt == newNumRows)
					{
					}else
					{
						lgRowLabelMisMatchFound=true;
					}
				}

				if(parameterInfo[counter].colLabels && tc_strlen(parameterInfo[counter].colLabels) > 0)
				{
					split_the_string(parameterInfo[counter].colLabels,COMMA_DELIM,&newColLabelCnt,&newColLabelNames);
					if(newColLabelCnt == newNumCols)
					{
					}else
					{
						lgColumnLabelMisMatchFound=true;
					}
				}

				//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
				//check if semicolon exist in initial value string
				if(parameterInfo[counter].initVal && tc_strlen(parameterInfo[counter].initVal)> 0)
				{
					semiColonDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].initVal),SEMICOLON_DELIM);
					if(semiColonDelimExist)
					{
						split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
						semiColonDelimExist=NULL;
						if(dummyInitValArrayCnt == newNumRows)
						{
							if(dummyInitValArray && dummyInitValArrayCnt> 0)
							{
								//store this info in initValArrayCnt,&initValArray
								for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
								{
									commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
									if(commaDelimExist)
									{
										split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&newInitValArrayCnt,&newInitValArray);
										commaDelimExist=NULL;
									}else
									{
										split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&newInitValArrayCnt,&newInitValArray);
									}
								}
								if(newInitValArrayCnt == newNumRows * newNumCols)
								{
								}else
								{
									lgInitialValMisMatchFound=true;
								}
							}
						}else
						{
							lgInitialValMisMatchFound=true;
						}
					}else
					{
						/*If 2d Lookup didnt contains semicolon , it means single row
						 e.g string = 1,0 ,2  or
							string=1 0 2
							 string =1
						*/
						commaDelimExist=strstr(FV_trim_invalidChars(parameterInfo[counter].initVal),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),COMMA_DELIM,&newInitValArrayCnt,&newInitValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),"' '",&newInitValArrayCnt,&newInitValArray);
						}
						if( (newInitValArrayCnt == newNumRows * newNumCols) || (newInitValArrayCnt == 1) )
						{
						}else
						{
							lgInitialValMisMatchFound=true;
						}

					}
				}

				//check if semicolon exist in maximum value string
				if(parameterInfo[counter].maxVal && tc_strlen(parameterInfo[counter].maxVal) > 0)
				{
					semiColonDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].maxVal),SEMICOLON_DELIM);
					if(semiColonDelimExist)
					{
						split_the_string(parameterInfo[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
						semiColonDelimExist=NULL;
						if(dummyMaxValArrayCnt == newNumRows)
						{
							if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
							{
								//store this info in maxValArrayCnt,maxValArray
								for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
								{
									commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
									if(commaDelimExist)
									{
										split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&newMaxValArrayCnt,&newMaxValArray);
										commaDelimExist=NULL;
									}else
									{
										split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&newMaxValArrayCnt,&newMaxValArray);
									}
								}
								if(newMaxValArrayCnt == newNumRows * newNumCols)
								{
								}else
								{
									lgMaxValMisMatchFound=true;
								}
							}
						}else
						{
							lgMaxValMisMatchFound=true;
						}
					}else
					{
						/*If 2d Lookup didnt contains semicolon , it means single row
						 e.g string = 1,0 ,2  or
							string=1 0 2
							string =1
						*/
						commaDelimExist=strstr(FV_trim_invalidChars(parameterInfo[counter].maxVal),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].maxVal),COMMA_DELIM,&newMaxValArrayCnt,&newMaxValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].maxVal),"' '",&newMaxValArrayCnt,&newMaxValArray);
						}
						if( (newMaxValArrayCnt == newNumRows * newNumCols) || (newMaxValArrayCnt == 1))
						{
						}else
						{
							lgMaxValMisMatchFound=true;
						}

					}
				}

				//check if semicolon exist in minimum value string
				if(parameterInfo[counter].minVal && tc_strlen(parameterInfo[counter].minVal)> 0)
				{
					semiColonDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].minVal),SEMICOLON_DELIM);
					if(semiColonDelimExist)
					{
						split_the_string(parameterInfo[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
						semiColonDelimExist=NULL;
						if(dummyMinValArrayCnt == newNumRows)
						{
							//store this info in minValArrayCnt,minValArray
							if(dummyMinValArrayCnt > 0 && dummyMinValArray)
							{
								for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
								{
									commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
									if(commaDelimExist)
									{
										split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&newMinValArrayCnt,&newMinValArray);
										commaDelimExist=NULL;
									}else
									{
										split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&newMinValArrayCnt,&newMinValArray);
									}
								}
								if(newMinValArrayCnt == newNumRows*newNumCols)
								{
								}else
								{
									lgMinValMisMatchFound=true;
								}
							}
						}else
						{
							lgMinValMisMatchFound=true;
						}
					}else
					{
						/*If 2d Lookup didnt contains semicolon , it means single row
							e.g string = 1,0 ,2  or
								string=1 0 2
								string =1
						*/
						commaDelimExist=strstr(FV_trim_invalidChars(parameterInfo[counter].minVal),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].minVal),COMMA_DELIM,&newMinValArrayCnt,&newMinValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].minVal),"' '",&newMinValArrayCnt,&newMinValArray);
						}
						if( (newMinValArrayCnt == newNumRows * newNumCols) || (newMinValArrayCnt == 1) )
						{
						}else
						{
							lgMinValMisMatchFound=true;
						}
					}
				}

				if(isObjDblType == TRUE || isObjIntType == TRUE)
				{
					//get the isSigned value based on Min,max and Initial Value
					if(newInitValArrayCnt > 0 && newInitValArray)
					{
						for(iCounter=0;iCounter<newInitValArrayCnt;iCounter++)
						{
							//initVal	=	atoi(newInitValArray[iCounter]);
							indexFirstInit=strchr(newInitValArray[iCounter],'-');
							index = (int)(indexFirstInit - newInitValArray[iCounter]);
							sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(newInitValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withInit,"-") == 0)
							{
								initVal=-1;
							}
							if(initVal < 0)
							{
								isInitNegative=true;
								break;
							}
						}
					}

					if(newMaxValArrayCnt > 0 && newMaxValArray)
					{
						for(iCounter=0;iCounter<newMaxValArrayCnt;iCounter++)
						{
							//maxVal	=	atoi(newMaxValArray[iCounter]);
							indexFirstMax=strchr(newMaxValArray[iCounter],'-');
							index = (int)(indexFirstMax - newMaxValArray[iCounter]);
							sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(newMaxValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMax,"-") == 0)
							{
								maxVal=-1;
							}
							if(maxVal < 0)
							{
								isMaxNegative=true;
								break;
							}
						}
					}

					if(newMinValArrayCnt > 0 && newMinValArray)
					{
						for(iCounter=0;iCounter<newMinValArrayCnt;iCounter++)
						{
							//minVal	=	atoi(newMinValArray[iCounter]);
							indexFirstMin=strchr(newMinValArray[iCounter],'-');
							index = (int)(indexFirstMin - newMinValArray[iCounter]);
							sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(newMinValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMin,"-") == 0)
							{
								minVal=-1;
							}
							if(minVal < 0)
							{
								isMinNegative=true;
								break;
							}
						}
					}

					if(isMinNegative || isMaxNegative || isInitNegative)
					{
						newIsSignedVal=TRUE;
					}
				}
			}
			if( tc_strcmp(parameterInfo[counter].structureOfData,Array2DInfo) == 0)
			{
				//get the rowlables and columnLabels
				if(parameterInfo[counter].rowLabels && tc_strlen(parameterInfo[counter].rowLabels)> 0)
				{
					split_the_string(parameterInfo[counter].rowLabels,COMMA_DELIM,&newRowLabelCnt,&newRowLabelNames);
					if(newRowLabelCnt == newNumRows)
					{
					}else
					{
						lgRowLabelMisMatchFound=true;
					}
				}

				if(parameterInfo[counter].colLabels && tc_strlen(parameterInfo[counter].colLabels) > 0)
				{
					split_the_string(parameterInfo[counter].colLabels,COMMA_DELIM,&newColLabelCnt,&newColLabelNames);
					if(newColLabelCnt == newNumCols)
					{
					}else
					{
						lgColumnLabelMisMatchFound=true;
					}
				}
				//[ 3.00,1.00,0, 3.50, 7.00;3.00,1.00,0,3.50,4.00;3.00,1.00, 0,1.00,1.00]
				//check if semicolon exist in initial value string
				if(parameterInfo[counter].initVal && tc_strlen(parameterInfo[counter].initVal)> 0)
				{
					semiColonDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].initVal),SEMICOLON_DELIM);
					if(semiColonDelimExist)
					{
						split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),SEMICOLON_DELIM,&dummyInitValArrayCnt,&dummyInitValArray);
						semiColonDelimExist=NULL;
						if(dummyInitValArrayCnt == newNumRows)
						{
							if(dummyInitValArray && dummyInitValArrayCnt> 0)
							{
								//store this info in initValArrayCnt,&initValArray
								for(iCounter=0;iCounter<dummyInitValArrayCnt;iCounter++)
								{
									commaDelimExist=strstr(FV_trim_blanks(dummyInitValArray[iCounter]),COMMA_DELIM);
									if(commaDelimExist)
									{
										split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),COMMA_DELIM,&newInitValArrayCnt,&newInitValArray);
										commaDelimExist=NULL;
									}else
									{
										split_the_string(FV_trim_invalidChars(dummyInitValArray[iCounter]),"' '",&newInitValArrayCnt,&newInitValArray);
									}
								}
								if(newInitValArrayCnt == newNumRows*newNumCols)
								{
								}else
								{
									lgInitialValMisMatchFound=true;
								}
							}
						}else
						{
							lgInitialValMisMatchFound=true;
						}
					}else
					{
						/*If 2d Array didnt contains semicolon , it means single row
						 e.g string = 1,0 ,2  or
							string=1 0 2
							 string =1
						*/
						commaDelimExist=strstr(FV_trim_invalidChars(parameterInfo[counter].initVal),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),COMMA_DELIM,&newInitValArrayCnt,&newInitValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),"' '",&newInitValArrayCnt,&newInitValArray);
						}
						if( (newInitValArrayCnt == newNumRows * newNumCols) || (newInitValArrayCnt == 1) )
						{
						}else
						{
							lgInitialValMisMatchFound=true;
						}

					}
				}

				//check if semicolon exist in maximum value string
				if(parameterInfo[counter].maxVal && tc_strlen(parameterInfo[counter].maxVal)> 0)
				{
					semiColonDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].maxVal),SEMICOLON_DELIM);
					if(semiColonDelimExist)
					{
						split_the_string(parameterInfo[counter].maxVal,SEMICOLON_DELIM,&dummyMaxValArrayCnt,&dummyMaxValArray);
						semiColonDelimExist=NULL;
						if(dummyMaxValArrayCnt == newNumRows)
						{
							if(dummyMaxValArrayCnt > 0 && dummyMaxValArray)
							{
								//store this info in maxValArrayCnt,maxValArray
								for(iCounter=0;iCounter<dummyMaxValArrayCnt;iCounter++)
								{
									commaDelimExist=strstr(FV_trim_blanks(dummyMaxValArray[iCounter]),COMMA_DELIM);
									if(commaDelimExist)
									{
										split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),COMMA_DELIM,&newMaxValArrayCnt,&newMaxValArray);
										commaDelimExist=NULL;
									}else
									{
										split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&newMaxValArrayCnt,&newMaxValArray);
									}
								}
								if(newMaxValArrayCnt == newNumRows*newNumCols)
								{
								}else
								{
									lgMaxValMisMatchFound=true;
								}
							}
						}else
						{
							lgMaxValMisMatchFound=true;
						}
					}else
					{
						/*If 2d Array didnt contains semicolon , it means single row
						e.g string = 1,0 ,2  or
							string=1 0 2
							string =1
						*/
						commaDelimExist=strstr(FV_trim_invalidChars(parameterInfo[counter].maxVal),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].maxVal),COMMA_DELIM,&newMaxValArrayCnt,&newMaxValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].maxVal),"' '",&newMaxValArrayCnt,&newMaxValArray);
						}
						if( (newMaxValArrayCnt == newNumRows * newNumCols) || (newMaxValArrayCnt == 1))
						{
						}else
						{
							lgMaxValMisMatchFound=true;
						}
					}
				}

				//check if semicolon exist in minimum value string
				if(parameterInfo[counter].minVal && tc_strlen(parameterInfo[counter].minVal)> 0)
				{
					semiColonDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].minVal),SEMICOLON_DELIM);
					if(semiColonDelimExist)
					{
						split_the_string(parameterInfo[counter].minVal,SEMICOLON_DELIM,&dummyMinValArrayCnt,&dummyMinValArray);
						semiColonDelimExist=NULL;
						if(dummyMinValArrayCnt == newNumRows)
						{
							//store this info in minValArrayCnt,minValArray
							if(dummyMinValArrayCnt > 0 && dummyMinValArray)
							{
								for(iCounter=0;iCounter<dummyMinValArrayCnt;iCounter++)
								{
									commaDelimExist=strstr(FV_trim_blanks(dummyMinValArray[iCounter]),COMMA_DELIM);
									if(commaDelimExist)
									{
										split_the_string(FV_trim_invalidChars(dummyMinValArray[iCounter]),COMMA_DELIM,&newMinValArrayCnt,&newMinValArray);
										commaDelimExist=NULL;
									}else
									{
										split_the_string(FV_trim_invalidChars(dummyMaxValArray[iCounter]),"' '",&newMinValArrayCnt,&newMinValArray);
									}
								}
								if(newMinValArrayCnt == newNumRows*newNumCols)
								{
								}else
								{
									lgMinValMisMatchFound=true;
								}
							}
						}else
						{
							lgMinValMisMatchFound=true;
						}

					}else
					{
						/*If 2d Array didnt contains semicolon , it means single row
						 e.g string = 1,0 ,2  or
							string=1 0 2
							string =1
						*/
						commaDelimExist=strstr(FV_trim_invalidChars(parameterInfo[counter].minVal),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].minVal),COMMA_DELIM,&newMinValArrayCnt,&newMinValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].minVal),"' '",&newMinValArrayCnt,&newMinValArray);
						}
						if( (newMinValArrayCnt == newNumRows * newNumCols) || (newMinValArrayCnt == 1) )
						{
						}else
						{
							lgMinValMisMatchFound=true;
						}
					}
				}

				if(isObjDblType == TRUE || isObjIntType == TRUE)
				{
					//get the isSigned value based on Min,max and Initial Value
					if(newInitValArrayCnt > 0 && newInitValArray)
					{
						for(iCounter=0;iCounter<newInitValArrayCnt;iCounter++)
						{
							//initVal	=	atoi(newInitValArray[iCounter]);
							indexFirstInit=strchr(newInitValArray[iCounter],'-');
							index = (int)(indexFirstInit - newInitValArray[iCounter]);
							sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(newInitValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withInit,"-") == 0)
							{
								initVal=-1;
							}
							if(initVal < 0)
							{
								isInitNegative=true;
								break;
							}
						}
					}

					if(newMaxValArrayCnt > 0 && newMaxValArray)
					{
						for(iCounter=0;iCounter<newMaxValArrayCnt;iCounter++)
						{
							//maxVal	=	atoi(newMaxValArray[iCounter]);
							indexFirstMax=strchr(newMaxValArray[iCounter],'-');
							index = (int)(indexFirstMax - newMaxValArray[iCounter]);
							sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(newMaxValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMax,"-") == 0)
							{
								maxVal=-1;
							}
							if(maxVal < 0)
							{
								isMaxNegative=true;
								break;
							}
						}
					}

					if(newMinValArrayCnt > 0 && newMinValArray)
					{
						for(iCounter=0;iCounter<newMinValArrayCnt;iCounter++)
						{
							//minVal	=	atoi(newMinValArray[iCounter]);
							indexFirstMin=strchr(newMinValArray[iCounter],'-');
							index = (int)(indexFirstMin - newMinValArray[iCounter]);
							sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(newMinValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMin,"-") == 0)
							{
								minVal=-1;
							}
							if(minVal < 0)
							{
								isMinNegative=true;
								break;
							}
						}
					}

					if(isMinNegative || isMaxNegative || isInitNegative)
					{
						newIsSignedVal=TRUE;
					}
				}
			}
			if( tc_strcmp(parameterInfo[counter].structureOfData,Lookup1DInfo) == 0)
			{
				//get the row lables
				if(parameterInfo[counter].rowLabels && tc_strlen(parameterInfo[counter].rowLabels)> 0)
				{
					split_the_string(parameterInfo[counter].rowLabels,COMMA_DELIM,&newRowLabelCnt,&newRowLabelNames);
					if(newRowLabelCnt == newNumRows)
					{
					}else
					{
						lgRowLabelMisMatchFound=true;
					}
				}
				if(parameterInfo[counter].colLabels && tc_strlen(parameterInfo[counter].colLabels)> 0)
				{
					split_the_string(parameterInfo[counter].colLabels,COMMA_DELIM,&newColLabelCnt,&newColLabelNames);
					if(newColLabelCnt == newNumCols)
					{
					}else
					{
						lgColumnLabelMisMatchFound=true;
					}
				}

				//get the initial Values
				//check which delimiter exist in CSV file for  initial values.either space or comma.
				if(parameterInfo[counter].initVal && tc_strlen(parameterInfo[counter].initVal)>0)
				{
					
					commaDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].initVal),COMMA_DELIM);
					if(commaDelimExist != NULL)
					{
						split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),COMMA_DELIM,&newInitValArrayCnt,&newInitValArray);
						commaDelimExist=NULL;
					}else
					{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),"' '",&newInitValArrayCnt,&newInitValArray);
					}
					
					if( (newInitValArrayCnt == newNumRows*newNumCols) || (newInitValArrayCnt == 1))
					{
					}else
					{
						lgInitialValMisMatchFound=true;
					}
				}
				//get the min values
				if(parameterInfo[counter].minVal && tc_strlen(parameterInfo[counter].minVal)> 0)
				{
					
					commaDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].minVal),COMMA_DELIM);
					if(commaDelimExist != NULL)
					{
						split_the_string(FV_trim_invalidChars(parameterInfo[counter].minVal),COMMA_DELIM,&newMinValArrayCnt,&newMinValArray);
						commaDelimExist=NULL;
					}else
					{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].minVal),"' '",&newMinValArrayCnt,&newMinValArray);
					}
					
					if( (newMinValArrayCnt == newNumRows*newNumCols) || (newMinValArrayCnt == 1))
					{
					}else
					{
						lgMinValMisMatchFound=true;
					}
				}

				//get the max values
				if(parameterInfo[counter].maxVal && tc_strlen(parameterInfo[counter].maxVal)> 0)
				{
					commaDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].maxVal),COMMA_DELIM);
					if(commaDelimExist != NULL)
					{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].maxVal),COMMA_DELIM,&newMaxValArrayCnt,&newMaxValArray);
							commaDelimExist=NULL;
					}else
					{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].maxVal),"' '",&newMaxValArrayCnt,&newMaxValArray);
					}
					
					if( (newMaxValArrayCnt == newNumRows*newNumCols) || (newMaxValArrayCnt == 1))
					{
					}else
					{
						lgMaxValMisMatchFound=true;
					}
				}

				if(isObjDblType == TRUE || isObjIntType == TRUE)
				{
					//get the isSigned value based on Min,max and Initial Value
					if(newInitValArrayCnt > 0 && newInitValArray)
					{
						for(iCounter=0;iCounter<newInitValArrayCnt;iCounter++)
						{
							//initVal	=	atoi(newInitValArray[iCounter]);
							indexFirstInit=strchr(newInitValArray[iCounter],'-');
							index = (int)(indexFirstInit - newInitValArray[iCounter]);
							sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(newInitValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withInit,"-") == 0)
							{
								initVal=-1;
							}
							if(initVal < 0)
							{
								isInitNegative=true;
								break;
							}
						}
					}

					if(newMaxValArrayCnt > 0 && newMaxValArray)
					{
						for(iCounter=0;iCounter<newMaxValArrayCnt;iCounter++)
						{
							//maxVal	=	atoi(newMaxValArray[iCounter]);
							indexFirstMax=strchr(newMaxValArray[iCounter],'-');
							index = (int)(indexFirstMax - newMaxValArray[iCounter]);
							sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(newMaxValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMax,"-") == 0)
							{
								maxVal=-1;
							}
							if(maxVal < 0)
							{
								isMaxNegative=true;
								break;
							}
						}
					}

					if(newMinValArrayCnt > 0 && newMinValArray)
					{
						for(iCounter=0;iCounter<newMinValArrayCnt;iCounter++)
						{
							//minVal	=	atoi(newMinValArray[iCounter]);
							indexFirstMin=strchr(newMinValArray[iCounter],'-');
							index = (int)(indexFirstMin - newMinValArray[iCounter]);
							sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(newMinValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMin,"-") == 0)
							{
								minVal=-1;
							}
							if(minVal < 0)
							{
								isMinNegative=true;
								break;
							}
						}
					}

					if(isMinNegative || isMaxNegative || isInitNegative)
					{
						newIsSignedVal=TRUE;
					}
				}// dbl or int

			}
			if( tc_strcmp(parameterInfo[counter].structureOfData,Array1DInfo) == 0)
			{
				//get the rowlables and columnLabels
				if(parameterInfo[counter].rowLabels && tc_strlen(parameterInfo[counter].rowLabels)> 0)
				{
					split_the_string(parameterInfo[counter].rowLabels,COMMA_DELIM,&newRowLabelCnt,&newRowLabelNames);
					if(newRowLabelCnt == newNumRows)
					{
					}else
					{
						lgRowLabelMisMatchFound=true;
					}
				}

				if(parameterInfo[counter].colLabels && tc_strlen(parameterInfo[counter].colLabels) > 0)
				{
					split_the_string(parameterInfo[counter].colLabels,COMMA_DELIM,&newColLabelCnt,&newColLabelNames);
					if(newColLabelCnt == newNumCols)
					{
					}else
					{
						lgColumnLabelMisMatchFound=true;
					}
				}
				//get the initial Values
				//check which delimiter exist in CSV file for  initial values.either space or comma
				if(parameterInfo[counter].initVal && tc_strlen(parameterInfo[counter].initVal)> 0)
				{
					if(parameterInfo[counter].typeOfData && tc_strlen(parameterInfo[counter].typeOfData)> 0 && tc_strcmp(parameterInfo[counter].typeOfData,PARM_TYPE_CHARACTER) == 0)
					{
						
						newInitValArrayCnt=1;
						newInitValArray = (char **)MEM_alloc( 1 * sizeof(char *));
						newInitValArray[0] = (char *)MEM_alloc( ((int)tc_strlen(parameterInfo[counter].initVal) + 1) * sizeof(char ));
						tc_strcpy((newInitValArray)[0], FV_trim_blanks(parameterInfo[counter].initVal));

					}else
					{
						commaDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].initVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),COMMA_DELIM,&newInitValArrayCnt,&newInitValArray);
						}else
						{
							split_the_string(FV_trim_invalidChars(parameterInfo[counter].initVal),"' '",&newInitValArrayCnt,&newInitValArray);
						}
					}
					if( (newInitValArrayCnt == newNumRows*newNumCols) || (newInitValArrayCnt == 1))
					{
					}else
					{
						lgInitialValMisMatchFound=true;
					}
				}

				//get the min values
				if(parameterInfo[counter].minVal && tc_strlen(parameterInfo[counter].minVal) > 0)
				{
					if(parameterInfo[counter].typeOfData && tc_strlen(parameterInfo[counter].typeOfData)> 0 && tc_strcmp(parameterInfo[counter].typeOfData,PARM_TYPE_CHARACTER) == 0)
					{
						newMinValArrayCnt=1;
						newMinValArray = (char **)MEM_alloc( 1 * sizeof(char *));
						newMinValArray[0] = (char *)MEM_alloc( ((int)tc_strlen(parameterInfo[counter].minVal) + 1) * sizeof(char ));
						tc_strcpy((newMinValArray)[0], FV_trim_blanks(parameterInfo[counter].minVal));
					}else
					{
						commaDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].minVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(parameterInfo[counter].minVal,COMMA_DELIM,&newMinValArrayCnt,&newMinValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(parameterInfo[counter].minVal,"' '",&newMinValArrayCnt,&newMinValArray);
						}
					}
					if( (newMinValArrayCnt == newNumRows*newNumCols) || (newMinValArrayCnt == 1))
					{
					}else
					{
						lgMinValMisMatchFound=true;
					}
				}
				

				//get the max values
				if(parameterInfo[counter].maxVal && tc_strlen(parameterInfo[counter].maxVal) > 0)
				{
					if(parameterInfo[counter].typeOfData && tc_strlen(parameterInfo[counter].typeOfData)> 0 && tc_strcmp(parameterInfo[counter].typeOfData,PARM_TYPE_CHARACTER) == 0)
					{
						newMaxValArrayCnt=1;
						newMaxValArray = (char **)MEM_alloc( 1 * sizeof(char *));
						newMaxValArray[0] = (char *)MEM_alloc( ((int)tc_strlen(parameterInfo[counter].maxVal) + 1) * sizeof(char ));
						tc_strcpy((newMaxValArray)[0], FV_trim_blanks(parameterInfo[counter].maxVal));
					}else
					{
						commaDelimExist=strstr(FV_trim_blanks(parameterInfo[counter].maxVal),COMMA_DELIM);
						if(commaDelimExist != NULL)
						{
							split_the_string(parameterInfo[counter].maxVal,COMMA_DELIM,&newMaxValArrayCnt,&newMaxValArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(parameterInfo[counter].maxVal,"' '",&newMaxValArrayCnt,&newMaxValArray);
						}
					}
					if( (newMaxValArrayCnt == newNumRows*newNumCols) || (newMaxValArrayCnt == 1))
					{
					}else
					{
						lgMaxValMisMatchFound=true;
					}
				}
				

				if(isObjDblType == TRUE || isObjIntType == TRUE)
				{
					//get the isSigned value based on Min,max and Initial Value
					if(newInitValArrayCnt > 0 && newInitValArray)
					{
						for(iCounter=0;iCounter<newInitValArrayCnt;iCounter++)
						{
							//initVal	=	atoi(newInitValArray[iCounter]);
							indexFirstInit=strchr(newInitValArray[iCounter],'-');
							index = (int)(indexFirstInit - newInitValArray[iCounter]);
							sprintf(line_starts_withInit,"%.*s",(index+1)-0,&(newInitValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withInit,"-") == 0)
							{
								initVal=-1;
							}
							if(initVal < 0)
							{
								isInitNegative=true;
								break;
							}
						}
					}

					if(newMaxValArrayCnt > 0 && newMaxValArray)
					{
						for(iCounter=0;iCounter<newMaxValArrayCnt;iCounter++)
						{
							//maxVal	=	atoi(newMaxValArray[iCounter]);
							indexFirstMax=strchr(newMaxValArray[iCounter],'-');
							index = (int)(indexFirstMax - newMaxValArray[iCounter]);
							sprintf(line_starts_withMax,"%.*s",(index+1)-0,&(newMaxValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMax,"-") == 0)
							{
								maxVal=-1;
							}
							if(maxVal < 0)
							{
								isMaxNegative=true;
								break;
							}
						}
					}

					if(newMinValArrayCnt > 0 && newMinValArray)
					{
						for(iCounter=0;iCounter<newMinValArrayCnt;iCounter++)
						{
							//minVal	=	atoi(newMinValArray[iCounter]);
							indexFirstMin=strchr(newMinValArray[iCounter],'-');
							index = (int)(indexFirstMin - newMinValArray[iCounter]);
							sprintf(line_starts_withMin,"%.*s",(index+1)-0,&(newMinValArray[iCounter])[0]);
							index=0;
							if(tc_strcmp(line_starts_withMin,"-") == 0)
							{
								minVal=-1;
							}
							if(minVal < 0)
							{
								isMinNegative=true;
								break;
							}
						}
					}

					if(isMinNegative || isMaxNegative || isInitNegative)
					{
						newIsSignedVal=TRUE;
					}
				}//dbl or int
			}
		}
	}



	/*
		Min/Max/Initial values exist for Type Int/Dbl/String/Date/BCD/HEX
		For Int/Dbl -->get the precision and then compare
		For String -->compare as it is
		For Hex type -->when retriving old values from Item Revision , its in the format "0x5".So when comparing new value with old value
		                make sure , if new value is with prefix "0x" ->compare new with old as it is
			                        if new value is not with prefix "0x" -->append "0x" to new value and then compare
		
		As new type introduse in POC , below function needs modification.

	*/
	if(compareMinMaxInit)
	{
		if(oldNumRows == newNumRows && oldNumCols == newNumCols)
		{
			//check the minimum values of old revision with new values
			for(rowIndex=0;rowIndex<oldNumRows*oldNumCols;rowIndex++)
			{
				lengthBeforeDotNew,lengthAfterDotNew =0;
				if(newMinValArray && newMinValArrayCnt == newNumRows*newNumCols)
				{
					if(newMinValArray[rowIndex])
					{
						if(isObjDblType || isObjIntType)
						{
							ifail=FVE_get_precision(FV_trim_blanks(newMinValArray[rowIndex]),&lengthBeforeDotNew,&lengthAfterDotNew);
							newVal1=NULL;
							FVE_truncate_double_values(atof(FV_trim_blanks(newMinValArray[rowIndex])),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen( newMinValArray[rowIndex] )+1)* sizeof(char));
							strcpy(newVal, newMinValArray[rowIndex] );
						}
						else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(FV_trim_blanks(newMinValArray[rowIndex]),'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newMinValArray[rowIndex]) )+1)* sizeof(char));
								strcpy(newVal, FV_trim_blanks(newMinValArray[rowIndex] ));
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newMinValArray[rowIndex])) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal, FV_trim_blanks(newMinValArray[rowIndex]));
							}
						}//isObjHexType
					}
				}
				else if(newMinValArray && newMinValArrayCnt == 1)
				{
					if(newMinValArray[0])
					{
						if(isObjDblType || isObjIntType)
						{
							ifail=FVE_get_precision(FV_trim_blanks(newMinValArray[0]),&lengthBeforeDotNew,&lengthAfterDotNew);
							newVal1=NULL;
							FVE_truncate_double_values(atof(FV_trim_blanks(newMinValArray[0])),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newMinValArray[0]) )+1)* sizeof(char));
							strcpy(newVal, FV_trim_blanks(newMinValArray[0]));
						}
						else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newMinValArray[0],'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newMinValArray[0]) )+1)* sizeof(char));
								strcpy(newVal, newMinValArray[0] );
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newMinValArray[0])) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal,FV_trim_blanks(newMinValArray[0]));
							}
						}//isObjHexType
					}
				}
				else if(newMinValArray == NULL)
				{
					if(newMinVal)
					{
						if(isObjDblType || isObjIntType)
						{
							ifail=FVE_get_precision(FV_trim_blanks(newMinVal),&lengthBeforeDotNew,&lengthAfterDotNew);
							newVal1=NULL;
							//truncate newValue
							FVE_truncate_double_values(atof(FV_trim_blanks(newMinVal)),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen( newMinVal )+1)* sizeof(char));
							strcpy(newVal, newMinVal);
						}else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newMinVal,'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newMinVal))+1)* sizeof(char));
								strcpy(newVal,newMinVal);
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newMinVal)) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal, FV_trim_blanks(newMinVal));
							}
						}//isObjHexType
					}
				}
				if( (oldMinValues[rowIndex] && newVal)&&(tc_strcmp(FV_trim_blanks(oldMinValues[rowIndex]),FV_trim_blanks(newVal)) != 0) )
				{
						isMinValModify = TRUE;
				}
				FVE_FREE(newVal)
				if(isMinValModify == TRUE)
					break;
			}//for rowIndex

			//check the maximum values of old revision with new values
			for(rowIndex=0;rowIndex<oldNumRows*oldNumCols;rowIndex++)
			{
				lengthAfterDotNew,lengthBeforeDotNew=0;
				if(newMaxValArray && newMaxValArrayCnt == newNumRows*newNumCols)
				{
					if(newMaxValArray[rowIndex])
					{
						if(isObjDblType || isObjIntType)
						{
							ifail=FVE_get_precision(FV_trim_blanks(newMaxValArray[rowIndex]),&lengthBeforeDotNew,&lengthAfterDotNew);
							newVal1=NULL;
							FVE_truncate_double_values(atof(FV_trim_blanks(newMaxValArray[rowIndex])),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen( newMaxValArray[rowIndex] )+1)* sizeof(char));
							strcpy(newVal, newMaxValArray[rowIndex] );
						}else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newMaxValArray[rowIndex],'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newMaxValArray[rowIndex]))+1)* sizeof(char));
								strcpy(newVal, FV_trim_blanks(newMaxValArray[rowIndex]));
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newMaxValArray[rowIndex])) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal, FV_trim_blanks(newMaxValArray[rowIndex]));
							}
						}//isObjHexType
					}
				}
				else if(newMaxValArray && newMaxValArrayCnt == 1)
				{
					if(newMaxValArray[0])
					{
						if(isObjDblType || isObjIntType)
						{
							ifail=FVE_get_precision(FV_trim_blanks(newMaxValArray[0]),&lengthBeforeDotNew,&lengthAfterDotNew);
							newVal1=NULL;
							FVE_truncate_double_values(atof(FV_trim_blanks(newMaxValArray[0])),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen( newMaxValArray[0] )+1)* sizeof(char));
							strcpy(newVal, newMaxValArray[0] );
						}else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newMaxValArray[0],'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newMaxValArray[0]))+1)* sizeof(char));
								strcpy(newVal, FV_trim_blanks(newMaxValArray[0]));
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newMaxValArray[0])) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal,FV_trim_blanks(newMaxValArray[0]));
							}
						}//isObjHexType
					}
				}
				else if(newMaxValArray == NULL)
				{
					if(newMaxVal)
					{
						if(isObjDblType || isObjIntType)
						{
							ifail=FVE_get_precision(FV_trim_blanks(newMaxVal),&lengthBeforeDotNew,&lengthAfterDotNew);
							newVal1=NULL;
							FVE_truncate_double_values(atof(FV_trim_blanks(newMaxVal)),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen(newMaxVal)+1)* sizeof(char));
							strcpy(newVal,newMaxVal);
						}else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newMaxVal,'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newMaxVal))+1)* sizeof(char));
								strcpy(newVal,FV_trim_blanks(newMaxVal));
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newMaxVal))+ strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal, FV_trim_blanks(newMaxVal));
							}
						}//isObjHexType
					}
				}
				if((oldMaxValues[rowIndex] && newVal) && (tc_strcmp(FV_trim_blanks(oldMaxValues[rowIndex]),FV_trim_blanks(newVal)) != 0) )
				{
						isMaxValModify = TRUE;
				}
				FVE_FREE(newVal)
				if(isMaxValModify == TRUE)
					break;
			}//rowIndex = 0;

			//check the old initial values with new values
			for(rowIndex=0;rowIndex<oldNumRows*oldNumCols;rowIndex++)
			{
				if(newInitValArray && newInitValArrayCnt == newNumRows*newNumCols)
				{
					if(newInitValArray[rowIndex])
					{
						newVal1=NULL;
						if(isObjDblType || isObjIntType)
						{
							FVE_truncate_double_values(atof(FV_trim_blanks(newInitValArray[rowIndex])),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
								newVal= (char*) MEM_alloc((int) (strlen( newInitValArray[rowIndex] )+1)* sizeof(char));
								strcpy(newVal, newInitValArray[rowIndex] );
						}else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newInitValArray[rowIndex],'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newInitValArray[rowIndex]) )+1)* sizeof(char));
								strcpy(newVal, FV_trim_blanks(newInitValArray[rowIndex]));
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newInitValArray[rowIndex])) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal, FV_trim_blanks(newInitValArray[rowIndex]));
							}
						}//isObjHexType
					}
				}
				else if(newInitValArray && newInitValArrayCnt == 1)
				{
					if(newInitValArray[0])
					{
						newVal1=NULL;
						if(isObjDblType || isObjIntType)
						{
							FVE_truncate_double_values(atof(FV_trim_blanks(newInitValArray[0])),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen( newInitValArray[0] )+1)* sizeof(char));
							strcpy(newVal, newInitValArray[0] );
						}else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newInitValArray[0],'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newInitValArray[0]))+1)* sizeof(char));
								strcpy(newVal, FV_trim_blanks(newInitValArray[0]));
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newInitValArray[0])) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal, FV_trim_blanks(newInitValArray[0]));
							}
						}//isObjHexType
					}
				}
				else if(newInitValArray == NULL)
				{
					if(newInitVal)
					{
						newVal1=NULL;
						if(isObjDblType || isObjIntType)
						{
							FVE_truncate_double_values(atof(FV_trim_blanks(newInitVal)),&newVal1);
							newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
							strcpy(newVal,newVal1);
						}
						else if(isObjStrType)
						{
							newVal= (char*) MEM_alloc((int) (strlen( newInitVal )+1)* sizeof(char));
							strcpy(newVal, newInitVal);
						}else if(isObjHexType)
						{
							//check if new value is with prefix "0x"
							indexOfX=NULL;
							indexOfX=strchr(newInitVal,'x');
							if(indexOfX != NULL)
							{
								newVal= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(newInitVal))+1)* sizeof(char));
								strcpy(newVal,FV_trim_blanks(newInitVal));
							}else
							{
								newVal = (char *) MEM_alloc((int) (strlen(FV_trim_blanks(newInitVal)) + strlen(HEX) + 1) * sizeof(char));
								strcpy(newVal, HEX);
								strcat(newVal,FV_trim_blanks(newInitVal));
							}
						}//isObjHexType
					}
				}
				if( (oldInitValues[rowIndex] && newVal) &&(tc_strcmp(FV_trim_blanks(oldInitValues[rowIndex]),FV_trim_blanks(newVal)) == 0))
				{
						isInitValModify = FALSE;
				}else
				{
						isInitValModify = TRUE;
				}
				FVE_FREE(newVal)
				if(isInitValModify == TRUE)
					break;
			}//rowIndex=0
		}//oldNumRows == newNumRows
		else
		{
			 isMinValModify = TRUE;
			 isMaxValModify = TRUE;
			 isInitValModify = TRUE;
		}
	}//compareMinMaxInit

	//compare labels
	if(compareColumnLabelFlag && lgColumnLabelMisMatchFound == false)
	{
		if(oldNumCols == newNumCols)
		{
			if(oldColLabelNames  && newColLabelNames)
			{
				for(iCounter=0;iCounter<oldNumCols;iCounter++)
				{
					 if(oldColLabelNames[iCounter] && newColLabelNames[iCounter] && tc_strlen(oldColLabelNames[iCounter]) > 0 && tc_strlen( newColLabelNames[iCounter])> 0 )
					 {
						if(tc_strcmp(FV_trim_blanks(oldColLabelNames[iCounter]),FV_trim_blanks(newColLabelNames[iCounter])) == 0)
						{
							isColumnLabelModify = false;
						}else
						{
							isColumnLabelModify = true;
						}
					 }
					 if(isColumnLabelModify == true)
						 break;
				}//iCounter
			}
		}else
		{
			isColumnLabelModify=true;
		}

	}
	if(compareRowLabelFlag && lgRowLabelMisMatchFound == false)
	{
		if(oldNumRows == newNumRows)
		{
			if(oldRowLabelNames && newRowLabelNames)
			{
				for(iCounter=0;iCounter<oldNumRows;iCounter++)
				{
					if(oldRowLabelNames[iCounter] && newRowLabelNames[iCounter] && tc_strlen(oldRowLabelNames[iCounter])> 0 && tc_strlen(newRowLabelNames[iCounter])>0 )
					{
						if(tc_strcmp(FV_trim_blanks(oldRowLabelNames[iCounter]),FV_trim_blanks(newRowLabelNames[iCounter])) ==0)
						{
							isRowLabelModify=false;
						}else
						{
							isRowLabelModify=true;
						}
					}
					if(isRowLabelModify==true)
						break;
				}//iCounter
			}
		}else
		{
			isRowLabelModify=true;
		}

	}

	if(isObjDblType || isObjIntType)
	{
		if(oldIsSignedVal != newIsSignedVal)
		{
			isSignedModify=TRUE;
		}
		if( (oldNumeratorValue) && (tc_strlen(oldNumeratorValue)> 0) && (newNumeratorVal) && (tc_strlen(newNumeratorVal)> 0))
		{
			newVal1=NULL;
			FVE_truncate_double_values(atof(FV_trim_blanks(newNumeratorVal)),&newVal1);
			if(tc_strcmp(newVal1,oldNumeratorValue) != 0)
			{
				isNumerModify = TRUE;
			}
		}
		if((oldDenominatorValue) && ( tc_strlen(oldDenominatorValue)> 0) && (newDenominatorVal) && (tc_strlen(newDenominatorVal)> 0))
		{
			newVal1=NULL;
			FVE_truncate_double_values(atof(FV_trim_blanks(newDenominatorVal)),&newVal1);
			if(tc_strcmp(newVal1,oldDenominatorValue) != 0)
			{
				isDenomiModify = TRUE;
			}
		}

	}

	//for 2dlookup , 1dlookup , 2d array  if any mismatch found , ser Min/Max/Initial/RowlabelMisMatch/columnlabelMismatch
	if(validRowCol_basedStrOfdata == false ||lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound || lgRowLabelMisMatchFound || lgColumnLabelMisMatchFound)
	{
		isMinValModify = FALSE;
		isMaxValModify = FALSE;
		isInitValModify = FALSE;
		isRowCntModify = FALSE;
		isColCntModify = FALSE;
	}

	if(isDescrModify || isUnitModify || isParmTypeModify || isParmUsageModify || isRowCntModify || isColCntModify ||
		isFaultValModify || isInhaleExhaleValModify || isRestrictedValModify || isModuleManfValModify || isFcsdCustPrefValModify || isAsBuiltVehOpValModify || isSectionModify || isSizeModify)
	{
		commonReqPropModify=TRUE;
	}

	//check for sed
	if(isObjSedType)
	{
		if(newNumRows != oldNumRows)
		{
			isRowCntModify = TRUE;
			TC_write_syslog("\n In %s: Row Count modified:", function_name);
			TC_write_syslog("\n Old RowCount = %d \n New RowCount = %d \n",
                  oldNumRows,newNumRows);
		}
		/*if  rows modified ,
				check if initial value is in the range of valid values.If yes - update valid values and initial value
																	   if no  - current valid values will not be set.
	      if rows didnt modified ,
				1.check if valid values are changed .If yes ->check if given initial value is in the range -->If yes -->modify
													|													 -->If no -->dont modify any value
													|
													|if no -->check if initial value is changed-->if yes-->check if initial value is in range
																								|
																								| if no -->No any changes
		*/

		//check if initial value changed
		if(domainElVal[0] && tc_strlen(domainElVal[0])> 0)
		{
			if( old_sedInitialValue && tc_strlen(old_sedInitialValue)> 0)
			{
				if(tc_strcmp(FV_trim_blanks(domainElVal[0]),FV_trim_blanks(old_sedInitialValue)) == 0)
				{
				}else
				{
					isInitValModify = TRUE;
				}
			}
		}

		/*if initial value is in range then only check for valid values*/
		if(lgInitValMatchFound==true && domainElVal[0] && tc_strlen(domainElVal[0]) > 0)
		{
			if(isRowCntModify)
			{
				isValidValModify=TRUE;
				//ifail=FVE_set_rowColumns(parmDefRev,Rows,Columns);
				/*write a function to create SED cells for newly row value.
					if newNumRows < oldNumRows  --delete cells for rows=(oldNumRows - newNumRows)
					or
					newNumRows > oldNumRows -- create cells for additional rows=(newNumRows -oldNumRows)
					*/
			}else
			{
				//check if valid values are changed.
				for(iCounter=0;iCounter<oldNumRows;iCounter++)
				{
					for(jCounter=0;jCounter<oldNumRows;jCounter++)
					{
						if(tc_strcmp(FV_trim_blanks(oldValidValues[iCounter]),FV_trim_blanks(valDomainElVal[jCounter]))==0)
						{
							isValidValModify = FALSE;
							break;
						}
						else
						{
							isValidValModify = TRUE;
						}
					}//jCounter = 0
					if(isValidValModify == TRUE)
					{
						TC_write_syslog("\n In %s : Valid Values modified....", function_name);
						break;
					}
				}//icounter = 0

				//if valid values didnt modified , check if domain name get modify or not
				if(isValidValModify == FALSE)
				{
					for(iCounter=0;iCounter<oldNumRows;iCounter++)
					{
						for(jCounter=0;jCounter<oldNumRows;jCounter++)
						{
							if(tc_strcmp(FV_trim_blanks(oldDomainElNames[iCounter]),FV_trim_blanks(valDomainElName[jCounter]))==0)
							{
								isValidValModify = FALSE;
								break;
							}
							else
							{
								isValidValModify = TRUE;
							}
						}//jCounter=0

						if(isValidValModify == TRUE)
						{
							TC_write_syslog("\n In %s : Domain Element Names modified....", function_name);
							break;
						}
					}// icounter = 0
				}//isValidValModify == FALSE
			}//rowcntModify didnt modify
		}//init value is in range

		if(isValidValModify == TRUE || isInitValModify == TRUE || lgDomainDDModify)
		{
			sedReqPropModify = TRUE;
		}

		if(commonReqPropModify == TRUE || sedReqPropModify == TRUE)
		{
			modify=TRUE;
		}
	}


	//check modified properties for Integer
	if(isObjIntType)
	{
		if(isNumerModify == TRUE || isDenomiModify == TRUE || isMaxValModify || isMinValModify || isInitValModify || isSignedModify || isColumnLabelModify || isRowLabelModify)
		{
			intReqPropModify= TRUE;
		}

		if(commonReqPropModify == TRUE || intReqPropModify == TRUE)
		{
			modify=TRUE;
		}

	}

	//check modified properties for Double
	if(isObjDblType)
	{
		if((oldToleranceValue) && ( tc_strlen(oldToleranceValue)> 0) && (newToleranceVal) && (tc_strlen(newToleranceVal)> 0)
			&& (tc_strcmp(FV_trim_blanks(newToleranceVal),oldToleranceValue) != 0) )
		{
			isToleranceModify = TRUE;
		}
		if((oldPrecisionValue) && ( tc_strlen(oldPrecisionValue)> 0) && (newPrecisionVal) && (tc_strlen(newPrecisionVal)> 0)
			&& (tc_strcmp(FV_trim_blanks(newPrecisionVal),oldPrecisionValue) != 0) )
		{
			isPrecisionModify = TRUE;
		}

		if(isNumerModify == TRUE || isDenomiModify == TRUE || isPrecisionModify == TRUE || isToleranceModify == TRUE || isMinValModify || isMaxValModify || isInitValModify || isSignedModify || isColumnLabelModify || isRowLabelModify)
		{
				doubleReqPropModify=TRUE;
		}

		if(commonReqPropModify == TRUE || doubleReqPropModify == TRUE)
		{
			modify=TRUE;
		}
	}
	if(isObjStrType)
	{
		if(isMinValModify || isMaxValModify || isInitValModify)
		{
				strReqPropModify=TRUE;
		}
		if(commonReqPropModify == TRUE || strReqPropModify == TRUE)
		{
			modify=TRUE;
		}

	}
	if(isObjHexType)
	{
		if(isMinValModify || isMaxValModify || isInitValModify || isColumnLabelModify || isRowLabelModify)
		{
				hexReqPropModify=TRUE;
		}
		if(commonReqPropModify == TRUE || hexReqPropModify == TRUE)
		{
			modify=TRUE;
		}
	}

	//create failure file when
	if(validRowCol_basedStrOfdata == false ||lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound || lgRowLabelMisMatchFound || lgColumnLabelMisMatchFound || lgMisMatchCount)
	{
		if(logFilePtrFailure == NULL)
		{
			logFilePtrFailure = fopen(file_pathFailure, "w+");
			fprintf(logFilePtrFailure,"Failed parameter List\n");
			fprintf(logFilePtrFailure,"\n");
			fprintf(logFilePtrFailure,"\n");
			if(logFilePtrFailure)
			{
				fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
				//time( &clock );
				//fprintf(logFilePtrFailure,"Start time: %s\n", ctime(&clock));
			}
			fprintf(logFilePtrFailure,"Logged in successfully.\n");
			fprintf(logFilePtrFailure,"\n");
			fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
			fprintf(logFilePtrFailure,"\n");
			fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
			fprintf(logFilePtrFailure,"\n");
			fprintf(logFilePtrFailure,"Dictionary Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
			fprintf(logFilePtrFailure,"\n");
		}
	}

    // If any of table related attr are modified, validate new values.
    if((isObjDblType || isObjIntType || isObjHexType ||isObjStrType) && (isNumerModify == TRUE || isDenomiModify == TRUE || isPrecisionModify == TRUE || isToleranceModify == TRUE 
        || isMinValModify || isMaxValModify || isInitValModify || isSignedModify))
	{
        /* Parameter Defintion Validation */
		/* If structure of data is scalar , construct the array for single values and then call the validator function.*/
		if(newMinValArray == NULL && newMinValArrayCnt ==0 && newMaxValArray == NULL && newMaxValArrayCnt ==0 && newInitValArray == NULL && newInitValArrayCnt == 0)
		{
			if(newInitVal && newMaxVal && newMinVal)
			{
				// copy newInitVal , newMaxVal & newMinVal in a array and call the function for validator
				CLEANUP(FV_copy_string_to_array (&validatorIntCnt, &validatorIntArray, newInitVal))
				CLEANUP(FV_copy_string_to_array (&validatorMaxCnt, &validatorMaxArray, newMaxVal))
				CLEANUP(FV_copy_string_to_array (&validatorMinCnt, &validatorMinArray, newMinVal))
				if(validatorIntArray && validatorMaxArray && validatorMinArray)
				{
					ifail = FV_validate_import_parameters(validatorMinArray, validatorMinCnt, validatorMaxArray, validatorMaxCnt, validatorIntArray, validatorIntCnt, newIsSignedVal
						 , newPrecisionVal, newToleranceVal, newNumeratorVal, newDenominatorVal, tagOldParmRevObj);
				}
			}
            // If mim/max/initial table values is blank for types other than string & if for string initial table is blank
            else if(((newInitVal == NULL || newMaxVal == NULL || newMinVal == NULL) && !isObjStrType) || (isObjStrType && newInitVal == NULL))
            {
                ifail = FV_CCDM_ERROR_NOT_IN_RANGE;
            }
		}
        // If mim/max/initial table values is blank for types other than string & if for string initial table is blank
        else if(((newMinValArray == NULL || newMinValArrayCnt == 0 || newMaxValArray == NULL || newMaxValArrayCnt ==0 || newInitValArray == NULL || newInitValArrayCnt == 0)
            && !isObjStrType) || (isObjStrType && (newInitValArray == NULL || newInitValArrayCnt == 0)))
        {
            ifail = FV_CCDM_ERROR_NOT_IN_RANGE;
        }
        else
		{
			ifail = FV_validate_import_parameters(newMinValArray, newMinValArrayCnt, newMaxValArray, newMaxValArrayCnt, newInitValArray, newInitValArrayCnt, newIsSignedVal
            , newPrecisionVal, newToleranceVal, newNumeratorVal, newDenominatorVal, tagOldParmRevObj);
		}
        if(ifail != ITK_ok)
        {
            errorCode = ifail;
            ifail = ITK_ok;
            if(logFilePtrFailure == NULL)
	        {
		        logFilePtrFailure = fopen(file_pathFailure, "w+");
		        fprintf(logFilePtrFailure,"Failed parameter List\n");
		        fprintf(logFilePtrFailure,"\n");
		        fprintf(logFilePtrFailure,"\n");
		        if(logFilePtrFailure)
		        {
			        fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
		        }
		        fprintf(logFilePtrFailure,"Logged in successfully.\n");
		        fprintf(logFilePtrFailure,"\n");
		        fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
		        fprintf(logFilePtrFailure,"\n");
		        fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
		        fprintf(logFilePtrFailure,"\n");
		        fprintf(logFilePtrFailure,"Dictionary Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
		        fprintf(logFilePtrFailure,"\n");
	        }
            failureCntParameter++;
            ITK(FV_log_validation_error(errorCode, parameterInfo[counter].name))
            goto CLEANUP;
        }
    }

    time( &clock );
    TC_write_syslog("Start time modify: %s\n", ctime(&clock));

	if(modify == TRUE)
	{
        
        char*       pcOldParamItemId        =   NULLTAG;
        //Change Management for uploader
		/*
			Depending on the itemId used for utility , call the common function to revise the structure.
		*/
		//if(isDictionary)
		//{

            int     iParamDefLine_Attachments       = 0;
            tag_t*  ptParamDefLine_Attachments      =   NULL;

            // Tags to hold all process objects.
            tag_t*  ptProcessObjects                =   NULL;

            // Int to hold attribute id.
            int     iAttrRevId                      =   0;

            // String to hold dic id. - delete this
            char*   pcDicRevId                      =   NULL;

            // Tag to hold dic rev.
            tag_t   tDicItemRev                     =   NULLTAG;

            // Tag to hold process object.
            tag_t       tProcessObj     =   NULLTAG;

            // String to hold current relation name of process object with param def rev.
            char*       pcRelToParamDefRevLine =   NULL;

            tag_t       tParamGrpLineTag        =   NULLTAG;

            // tagOldParmRevBl

            ITK(AOM_ask_value_tags(tagOldParmRevBl, "bl_attachments", &iParamDefLine_Attachments, &ptParamDefLine_Attachments))

            ptProcessObjects = (tag_t*)MEM_alloc( iParamDefLine_Attachments * sizeof(tag_t));

            // Traverse through attachments to find process objects.
            for(iCounter = 0; iCounter < iParamDefLine_Attachments; iCounter++)
            {
                tag_t       propType    =   NULLTAG;
                char typeName[TCTYPE_name_size_c + 1];

                char*       pcObjectType    =   NULL;

                // Pointer to hold process id.
                char*       pcProcessId     =   NULL;

                // Number of process objects found.
                int         iProcessObjects =   0;

                ITK(TCTYPE_ask_object_type(ptParamDefLine_Attachments[iCounter],&propType))
                ITK(TCTYPE_ask_name(propType,typeName))
                if(strcmp(typeName, "CfgAbsOccAttachmentLine")==0)
                {
                    ITK(AOM_ask_value_string(ptParamDefLine_Attachments[iCounter],"al_source_type",&pcObjectType))
                    if(pcObjectType && tc_strcmp(pcObjectType, "FVE_ProcessRevision") == 0)
                    {
                        iProcessObjects++;

                        // Get relation of process object with param def rev line.
                        ITK(AOM_ask_value_string(ptParamDefLine_Attachments[iCounter], "al_context", &pcRelToParamDefRevLine))
                        ITK(AOM_ask_value_tag(ptParamDefLine_Attachments[iCounter],"al_object",&tProcessObj))

                        ITK(AOM_ask_value_string(tProcessObj, "item_id",&pcProcessId));
                        ptProcessObjects[iCounter]  =   tProcessObj;

                        //tProcessObj =   NULLTAG;

                    }
                    FVE_FREE(pcObjectType)
                 }
             }//for

            CLEANUP(AOM_ask_value_string(tagOldParmRevBl, "bl_item_item_id", &pcOldParamItemId))

            /* If input is ECCT project revision, assign correspoding
            *  top line tag and window tag.
            */
            if(isECCTProjectRev)
            {
                topDicBomLine   =   topBlPrimeDic;
                windowDic       =   windowPrimeDic;
            }

            CLEANUP(FV_revise_bomline_and_limited_parents_BT(tagOldParmRevBl,topDicBomLine,windowDic,&revisedObjsCnt,
                &revisedObjs, &newlyAddedBl,TRUE, pcOldParamItemId))

            FVE_FREE(pcOldParamItemId);

            if(newlyAddedBl)
            {
                // take parent of newlyAddedBl - parent
                CLEANUP(AOM_ask_value_tag(newlyAddedBl,bomAttr_lineParentTag, &tParamGrpLineTag))
                orgBlTag   = tParamGrpLineTag;
            }

            

            // Get new param def rev id from bomline.
            CLEANUP(BOM_line_look_up_attribute(bomAttr_lineItemRevTag, &iAttrRevId))
            CLEANUP(BOM_line_ask_attribute_tag(newlyAddedBl, iAttrRevId, &tDicItemRev))
            CLEANUP(WSOM_ask_id_string(tDicItemRev, &pcDicRevId))

            ITK(BOM_save_window(windowDic))

            //performance
			//ITK(BOM_refresh_window(windowDic))

            // Get dictionary item rev tag from topDicBomLine
            CLEANUP(BOM_line_look_up_attribute(bomAttr_lineItemRevTag, &iAttrRevId))
            CLEANUP(BOM_line_ask_attribute_tag(topDicBomLine, iAttrRevId, &tDicItemRev))
            CLEANUP(WSOM_ask_id_string(tDicItemRev, &pcDicRevId))

            // If mode is not parameter then only add process object.
            if( tc_strcmp(mode, PARAMETER_MODE) !=0 )
            {
                ifail = FVE_add_process_with_relation(tDicItemRev, newlyAddedBl, tProcessObj, pcRelToParamDefRevLine, windowDic);
            }

			ITK(BOM_save_window(windowDic))

            //performance
			//ITK(BOM_refresh_window(windowDic))

            FVE_FREE(ptParamDefLine_Attachments);
		//}
        /*
		if(isECCTProjectRev)
		{
            CLEANUP(AOM_ask_value_string(tagOldParmRevBl, "bl_item_item_id", &pcOldParamItemId))
			CLEANUP(FV_revise_bomline_and_limited_parents_BT(tagOldParmRevBl,topBlPrimeDic,windowPrimeDic,&revisedObjsCnt, &revisedObjs, &newlyAddedBl,TRUE,pcOldParamItemId ))

            FVE_FREE(pcOldParamItemId);
		}
        */

		if(newlyAddedBl)
		{
			*newBomLineTag=newlyAddedBl;
			CLEANUP(AOM_ask_value_tag(newlyAddedBl, bomAttr_lineItemRevTag, &newParmRevTag))
			if(newParmRevTag)
				tagOldParmRevObj=newParmRevTag;
		}else
		{
			*newBomLineTag=NULLTAG;
		}
		
		AM__set_application_bypass(TRUE);
		ITK(AOM_refresh(tagOldParmRevObj,TRUE))
		//set updated properties on Item
		ITK(AOM_refresh(tagOldParmItemObj,TRUE))
		if(isParmUsageModify)
		{
			ITK(AOM_set_value_string(tagOldParmItemObj,FVE_ParameterUsagePROP,newParmUsageVal))
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		if(isParmTypeModify)
		{
			ITK(AOM_set_value_string(tagOldParmItemObj,parmTypePROP,newParmTypeVal))
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		ITK(AOM_save(tagOldParmItemObj))
		//ITK(AOM_refresh(tagOldParmItemObj,FALSE))

		if(isDescrModify)
		{
			if(newDescrVal && tc_strlen(newDescrVal)<=240)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,object_descPROP,newDescrVal))
			}
			if(newDescrVal ==  NULL || tc_strlen(newDescrVal) == 0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,object_descPROP,newDescrVal))
			}
			if(newDescrVal && tc_strlen(newDescrVal)>240)
			{
				//Description is more than the specified length. Refer to the comment filed for full description
				if(tc_strlen(newDescrVal)<=2000)
				{
					fprintf(logfileptr,"WARNING: Description is more than the specified length. Refer to the extended description field for full description.");
					ITK(AOM_set_value_string(tagOldParmRevObj,object_descPROP,"Description is more than the specified length. Refer to the extended description field for full description"))
					if(ifail != ITK_ok)
						ifail=ITK_ok;

					//ITK(AOM_refresh(tagOldParmItemObj,TRUE))
					ITK(AOM_set_value_string(tagOldParmItemObj,FVE_CommentPROP,newDescrVal))
					if(ifail != ITK_ok)
						ifail=ITK_ok;
					ITK(AOM_save(tagOldParmItemObj))
					//ITK(AOM_refresh(tagOldParmItemObj,FALSE))
				}else
				{
					fprintf(logfileptr,"WARNING: Could not set the Description as the length is more than 2000 characters.\n");
				}
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		if(isSectionModify)
		{
			// Check if given Part Type is valid lov value
            //ITK(LOV_find_attached_prop(ParmDefRevisionTYPE, fv9PartTypePROP, &partTypeLovTag))
            //if(partTypeLovTag != NULLTAG)
                //ITK(LOV_is_value_valid_string(partTypeLovTag, newSectionVal, &isPartTypeValValid))
            if(isPartTypeValValid)
            {
                ITK(AOM_set_value_string(tagOldParmRevObj,fv9PartTypePROP,newSectionVal))
                // Update COnf group on ECCT Project/Parameter Dictionary
                ITK(FVE_update_conf_group_on_update(oldSectionVal, newSectionVal))
            }
            else
            {
                fprintf(logfileptr,"WARNING: Could not set Configuration Group as \"%s\" is not a valid value. \n", newSectionVal);
            }
		}
		if(isSizeModify)
		{
			ITK(AOM_UIF_set_value(tagOldParmRevObj,sizePROP,newSize))
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		/*
		if(lgDomainDDModify)
		{
			//**newDomainDescrVal
			if(newDomainDescriptionVal && tc_strlen(newDomainDescriptionVal)<= 1024)
			{
				//append newLine after each value and then set it.
				if(newDomainDescrVal && tc_strlen(*newDomainDescrVal)> 0)
				{
					finalStrDD= (char*) MEM_alloc((int)(strlen(newDomainDescrVal[0])+1)* sizeof(char));
					tc_strcpy(finalStrDD,FV_trim_blanks(newDomainDescrVal[0]));
					for(indexCounter=1;indexCounter<newCntDD;indexCounter++)
					{
						finalStrDD= (char*) MEM_realloc(finalStrDD,(int)(strlen(finalStrDD)+tc_strlen(FV_trim_blanks(newDomainDescrVal[indexCounter]))+tc_strlen("\n")+1)* sizeof(char));
						tc_strcat(finalStrDD,"\n");
						tc_strcat(finalStrDD,FV_trim_blanks(newDomainDescrVal[indexCounter]));
					}
					tc_strcat(finalStrDD ,'\0');
					ifail=AOM_set_value_string(tagOldParmRevObj,FVE_CommentsPROP,finalStrDD);
					if(ifail != ITK_ok)
						ifail=ITK_ok;
				}
			}
			if(newDomainDescriptionVal == NULL || tc_strlen(newDomainDescriptionVal) == 0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_CommentsPROP,newDomainDescriptionVal))
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		} */
		if(isUnitModify)
		{
			ITK(AOM_set_value_string(tagOldParmRevObj,"FVE_EngUnit",newUnitVal))
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}

		if(isFaultValModify)
		{
			if(newfaultVal && tc_strlen(newfaultVal)<=500)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_FaultValuePROP,newfaultVal))
			}
			if(newfaultVal == NULL || tc_strlen(newfaultVal) == 0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_FaultValuePROP,newfaultVal))
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		if(isModuleManfValModify)
		{
			if(newModuleManfVal && tc_strlen(newModuleManfVal) <=10)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_ModulemanfIndPROP,newModuleManfVal))
			}
			if(newModuleManfVal == NULL || tc_strlen(newModuleManfVal) == 0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_ModulemanfIndPROP,newModuleManfVal))
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		if(isInhaleExhaleValModify)
		{
			if(newInhaleExhaleVal && tc_strlen(newInhaleExhaleVal)<=10)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_InhaleExhaleIndPROP,newInhaleExhaleVal))
			}
			if(newInhaleExhaleVal == NULL || tc_strlen(newInhaleExhaleVal)==0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_InhaleExhaleIndPROP,newInhaleExhaleVal))
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		if(isAsBuiltVehOpValModify)
		{
			if(newAsBuiltVehOpVal && tc_strlen(newAsBuiltVehOpVal)<=10)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_AsBuiltVehOpsPROP,newAsBuiltVehOpVal))
			}
			if(newAsBuiltVehOpVal == NULL || tc_strlen(newAsBuiltVehOpVal) == 0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_AsBuiltVehOpsPROP,newAsBuiltVehOpVal))
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		if(isFcsdCustPrefValModify)
		{
			if(newFcsdCustPrefVal && tc_strlen(newFcsdCustPrefVal)<=10)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_FCSDCustPrefPROP,newFcsdCustPrefVal))
			}
			if(newFcsdCustPrefVal == NULL || tc_strlen(newFcsdCustPrefVal) == 0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_FCSDCustPrefPROP,newFcsdCustPrefVal))
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}
		if(isRestrictedValModify)
		{
			if(newRestrictedVal && tc_strlen(newRestrictedVal) <=20)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_RestrictedPROP,newRestrictedVal))
			}
			if(newRestrictedVal == NULL || tc_strlen(newRestrictedVal) ==0)
			{
				ITK(AOM_set_value_string(tagOldParmRevObj,FVE_RestrictedPROP,newRestrictedVal))
			}
			if(ifail != ITK_ok)
				ifail=ITK_ok;
		}

		if(isNumerModify == TRUE)
		{
			if(isObjDblType)
			{
				numerator_val_dbl=atof(newNumeratorVal);
				ITK(AOM_set_value_double(tagOldParmRevObj,resolution_numeratorPROP,numerator_val_dbl))
				if(ifail != ITK_ok)
						ifail=ITK_ok;
			}
			if(isObjIntType)
			{
				ITK(AOM_set_value_int(tagOldParmRevObj,resolution_numeratorPROP,atoi(newNumeratorVal)))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}
		}
		if(isDenomiModify == TRUE)
		{
			if(isObjDblType)
			{
				denominator_val_dbl=atof(newDenominatorVal);
				ITK(AOM_set_value_double(tagOldParmRevObj,resolution_denominatorPROP,denominator_val_dbl))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}
			if(isObjIntType)
			{
				ITK(AOM_set_value_int(tagOldParmRevObj,resolution_denominatorPROP,atoi(newDenominatorVal)))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}
		}
		if(isPrecisionModify == TRUE)
		{
			if(isObjDblType)
			{
				precision_val_dbl=atof(newPrecisionVal);
				ITK(AOM_set_value_int(tagOldParmRevObj,precisionPROP,atoi(newPrecisionVal)))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}
		}
		if(isToleranceModify == TRUE)
		{
			if(isObjDblType)
			{
				tolerance_val_dbl=atof(newToleranceVal);
				ITK(AOM_set_value_double(tagOldParmRevObj,tolerancePROP,tolerance_val_dbl))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}
		}

		ITK(AOM_save(tagOldParmRevObj))
		ITK(AOM_refresh(tagOldParmRevObj,FALSE))

        if(isObjDblType || isObjIntType || isObjHexType ||isObjStrType)
		{
            /* Parameter Defintion Validation 
			/* If structure of data is scalar , construct the array for single values and then call the validator function.
			if(newMinValArray == NULL && newMinValArrayCnt ==0 && newMaxValArray == NULL && newMaxValArrayCnt ==0 && newInitValArray == NULL && newInitValArrayCnt == 0)
			{
				if(newInitVal && newMaxVal && newMinVal)
				{
					// copy newInitVal , newMaxVal & newMinVal in a array and call the function for validator
					CLEANUP(FV_copy_string_to_array (&validatorIntCnt, &validatorIntArray, newInitVal))
					CLEANUP(FV_copy_string_to_array (&validatorMaxCnt, &validatorMaxArray, newMaxVal))
					CLEANUP(FV_copy_string_to_array (&validatorMinCnt, &validatorMinArray, newMinVal))
					if(validatorIntArray && validatorMaxArray && validatorMinArray)
					{
						ifail = FV_validate_import_parameters(validatorMinArray, validatorMinCnt, validatorMaxArray, validatorMaxCnt, validatorIntArray, validatorIntCnt, newIsSignedVal
							 , newPrecisionVal, newToleranceVal, newNumeratorVal, newDenominatorVal, tagOldParmRevObj);
					}
				}
			}else
			{
				ifail = FV_validate_import_parameters(newMinValArray, newMinValArrayCnt, newMaxValArray, newMaxValArrayCnt, newInitValArray, newInitValArrayCnt, newIsSignedVal
                , newPrecisionVal, newToleranceVal, newNumeratorVal, newDenominatorVal, tagOldParmRevObj);
			}
            if(ifail != ITK_ok)
            {
                errorCode = ifail;
                ifail = ITK_ok;
                if(logFilePtrFailure == NULL)
		        {
			        logFilePtrFailure = fopen(file_pathFailure, "w+");
			        fprintf(logFilePtrFailure,"Failed parameter List\n");
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"\n");
			        if(logFilePtrFailure)
			        {
				        fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
			        }
			        fprintf(logFilePtrFailure,"Logged in successfully.\n");
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
			        fprintf(logFilePtrFailure,"\n");
			        fprintf(logFilePtrFailure,"Dictionary Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
			        fprintf(logFilePtrFailure,"\n");
		        }
                failureCntParameter++;
                ITK(FV_log_validation_error(errorCode, parameterInfo[counter].name))
                goto CLEANUP;
            }*/
           // else
            //{
                if(isRowCntModify || isColCntModify)
			    {
                    if(validRowCol_basedStrOfdata == true && lgColumnLabelMisMatchFound == false && lgRowLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
				    {
					    //Make sure correct labels are provided
					    ifail=FVE_set_rowColumns(tagOldParmRevObj,newNumRows,newNumCols,true,true,newRowLabelNames,newColLabelNames);
					    if(ifail != ITK_ok)
						    ifail=ITK_ok;
				    }
				    if(ifail != ITK_ok)
					    ifail=ITK_ok;

				    //set the Max Values
				    if( (tc_strcmp(parameterInfo[counter].structureOfData,Lookup2DInfo) == 0) || 
					    (tc_strcmp(parameterInfo[counter].structureOfData,Array2DInfo) == 0)  ||
					    (tc_strcmp(parameterInfo[counter].structureOfData,Lookup1DInfo) == 0) || 
					    (tc_strcmp(parameterInfo[counter].structureOfData,Array1DInfo) == 0) ||
					    (tc_strcmp(parameterInfo[counter].structureOfData,ScalarInfo) == 0))
				    {
					    if(validRowCol_basedStrOfdata == true && lgRowLabelMisMatchFound == false && lgColumnLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
					    {
						    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
						    {
							    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
						    }
						    else if(newMaxValArray && newMaxValArrayCnt == 1)
						    {
							    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray[0]);
						    }
						    else if(newMaxValArray == NULL && newMaxVal)
						    {
							    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxVal);
						    }
                            else if(newMaxValArray == NULL && newMaxVal == NULL)
                            {
                                ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
                            }
						    if(ifail != ITK_ok)
							    ifail=ITK_ok;

						    //set the Min Values
						    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
						    {
							    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
						    }
						    else if(newMinValArray && newMinValArrayCnt ==   1)
						    {
							    //ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinValArray[0]);
							    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray[0]);
						    }
						    else if(newMinValArray == NULL && newMinVal)
						    {
							    //ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinVal);
							    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinVal);
						    }
                            else if(newMinValArray == NULL && newMinVal == NULL)
                            {
                                ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
                            }
						    if(ifail != ITK_ok)
							    ifail=ITK_ok;

						    //set the Initial Values
						    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
						    {
							    //ifail=FVE_set_values(tagOldParmRevObj,initialValuesPROP,newInitValArray,newInitValArrayCnt);
							    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray,NULL,NULL);
						    }
						    else if(newInitValArray && newInitValArrayCnt ==  1)
						    {
							    //ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitValArray[0]);
							    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray[0]);
						    }
						    else if(newInitValArray == NULL && newInitVal)
						    {
							    //ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitVal);
							    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitVal);
						    }
						    if(ifail != ITK_ok)
							    ifail=ITK_ok;
					    }
				    }
			    }else //rowCnt , colCnt didnt modify
			    {
				    if( (tc_strcmp(parameterInfo[counter].structureOfData,Lookup2DInfo) == 0))
				    {
					    //if  row labels or column labels get changed
					    if(isColumnLabelModify || isRowLabelModify)
					    {
						    if(validRowCol_basedStrOfdata== true && lgRowLabelMisMatchFound == false && lgColumnLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
						    {
							    //Delete existing cells and recreate the cells for Min/Max/Initial/Labels
							    ifail=FVE_set_rowColumns(tagOldParmRevObj,oldNumRows,newNumCols,true,true,newRowLabelNames,newColLabelNames);
							    if(ifail != ITK_ok)
								    ifail=ITK_ok;

							    //set the Max  Values
							    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
							    {
								    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
							    }
							    else if(newMaxValArray && newMaxValArrayCnt == 1)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray[0]);
							    }
							    else if(newMaxValArray == NULL && newMaxVal)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxVal);
							    }
                                else if(newMaxValArray == NULL && newMaxVal == NULL)
                                {
                                    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
                                }
							    if(ifail != ITK_ok)
								    ifail=ITK_ok;

							    //set the Min Values
							    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
							    {
								    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
							    }
							    else if(newMinValArray && newMinValArrayCnt ==   1)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray[0]);
							    }
							    else if(newMinValArray == NULL && newMinVal)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinVal);
							    }
                                else if(newMinValArray == NULL && newMinVal == NULL)
                                {
                                    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
                                }
							    if(ifail != ITK_ok)
								    ifail=ITK_ok;

							    //set the Initial Values
							    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
							    {
								    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray,NULL,NULL);
							    }
							    else if(newInitValArray && newInitValArrayCnt ==  1)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray[0]);
							    }
							    else if(newInitValArray == NULL && newInitVal)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitVal);
							    }
							    if(ifail != ITK_ok)
								    ifail=ITK_ok;
						    }//lgRowLabelMisMatchFound == false
					    }//isColumnLabelModify || isRowLabelModify
					    else
					    {
						    if(validRowCol_basedStrOfdata == true && lgRowLabelMisMatchFound == false && lgColumnLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
						    {
							    if(isMaxValModify == TRUE)
							    {
								    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,maxValuesPROP,newMaxValArray,newMaxValArrayCnt);
								    }
								    else if(newMaxValArray && newMaxValArrayCnt == 1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxValArray[0]);
								    }
								    else if(newMaxValArray == NULL && newMaxVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;

							    }
							    if(isMinValModify == TRUE )
							    {
								    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,minValuesPROP,newMinValArray,newMinValArrayCnt);
								    }
								    else if(newMinValArray && newMinValArrayCnt ==   1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinValArray[0]);
								    }
								    else if(newMinValArray == NULL && newMinVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinVal);
								    }

								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
							    if(isInitValModify == TRUE)
							    {
								    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,initialValuesPROP,newInitValArray,newInitValArrayCnt);
								    }
								    else if(newInitValArray && newInitValArrayCnt ==  1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitValArray[0]);
								    }
								    else if(newInitValArray == NULL && newInitVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitVal);
								    }
								    if(ifail != ITK_ok)
								    ifail=ITK_ok;
							    }
						    }//lgRowLabelMisMatchFound == false || lgColumnLabelMisMatchFound == false || lgInitialValMisMatchFound == false || lgMinValMisMatchFound == false || lgMaxValMisMatchFound == false
					    }//else
				    }else if((tc_strcmp(parameterInfo[counter].structureOfData,Array2DInfo) == 0))
				    {
					    if(isColumnLabelModify || isRowLabelModify)
					    {
							    if(validRowCol_basedStrOfdata== true && lgRowLabelMisMatchFound == false && lgColumnLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
							    {
								    //Delete existing cells and recreate the cells for Min/Max/Initial/Labels
								    ifail=FVE_set_rowColumns(tagOldParmRevObj,oldNumRows,newNumCols,true,true,newRowLabelNames,newColLabelNames);
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
    								
								    //set the Max  Values
								    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
								    }
								    else if(newMaxValArray && newMaxValArrayCnt == 1)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray[0]);
								    }
								    else if(newMaxValArray == NULL && newMaxVal)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxVal);
								    }
                                    else if(newMaxValArray == NULL && newMaxVal == NULL)
                                    {
                                        ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
                                    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
    								
								    //set the Min Values
								    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
								    }
								    else if(newMinValArray && newMinValArrayCnt ==   1)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray[0]);
								    }
								    else if(newMinValArray == NULL && newMinVal)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinVal);
								    }
                                    else if(newMinValArray == NULL && newMinVal == NULL)
								    {
									    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;

								    //set the Initial Values
								    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray,NULL,NULL);
								    }
								    else if(newInitValArray && newInitValArrayCnt ==  1)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray[0]);
								    }
								    else if(newInitValArray == NULL && newInitVal)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
					    }else
					    {
						    if(validRowCol_basedStrOfdata == true && lgRowLabelMisMatchFound == false && lgColumnLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
						    {
							    if(isMaxValModify == TRUE)
							    {
								    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,maxValuesPROP,newMaxValArray,newMaxValArrayCnt);
								    }
								    else if(newMaxValArray && newMaxValArrayCnt == 1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxValArray[0]);
								    }
								    else if(newMaxValArray == NULL && newMaxVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
							    if(isMinValModify == TRUE )
							    {
								    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,minValuesPROP,newMinValArray,newMinValArrayCnt);
								    }
								    else if(newMinValArray && newMinValArrayCnt ==   1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinValArray[0]);
								    }
								    else if(newMinValArray == NULL && newMinVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
							    if(isInitValModify == TRUE)
							    {
								    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,initialValuesPROP,newInitValArray,newInitValArrayCnt);
								    }
								    else if(newInitValArray && newInitValArrayCnt ==  1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitValArray[0]);
								    }
								    else if(newInitValArray == NULL && newInitVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
						    }//lgInitialValMisMatchFound == false || lgMinValMisMatchFound == false || lgMaxValMisMatchFound == false
					    }
				    }else if( (tc_strcmp(parameterInfo[counter].structureOfData,Lookup1DInfo) == 0))
				    {
					    if(validRowCol_basedStrOfdata == true && lgColumnLabelMisMatchFound == false && lgRowLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
					    {
						    /*If column labels modified for 1D Lookup , delete existing cells and recreate cells to set Min/Max/Initial Values and labels.*/
						    if(isColumnLabelModify || isRowLabelModify)
						    {
							    ifail=FVE_set_rowColumns(tagOldParmRevObj,newNumRows,newNumCols,true,true,newRowLabelNames,newColLabelNames);
							    //set the max values
							    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
							    {
								    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
							    }
							    else if(newMaxValArray && newMaxValArrayCnt == 1)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray[0]);
							    }
							    else if(newMaxValArray == NULL && newMaxVal)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxVal);
							    }
                                else if(newMaxValArray == NULL && newMaxVal == NULL)
                                {
                                    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
                                }
							    if(ifail != ITK_ok)
								    ifail=ITK_ok;

							    //set the Min Values
							    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
							    {
								    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
							    }
							    else if(newMinValArray && newMinValArrayCnt ==   1)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray[0]);
							    }
							    else if(newMinValArray == NULL && newMinVal)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinVal);
							    }
                                else if(newMinValArray == NULL && newMinVal == NULL)
							    {
								    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
							    }
							    if(ifail != ITK_ok)
								    ifail=ITK_ok;

							    //set the Initial Values
							    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
							    {
								    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray,NULL,NULL);
							    }
							    else if(newInitValArray && newInitValArrayCnt ==  1)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray[0]);
							    }
							    else if(newInitValArray == NULL && newInitVal)
							    {
								    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitVal);
							    }
							    if(ifail != ITK_ok)
								    ifail=ITK_ok;
						    }
						    else
						    {
							    if(isMaxValModify == TRUE)
							    {
								    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,maxValuesPROP,newMaxValArray,newMaxValArrayCnt);
								    }
								    else if(newMaxValArray && newMaxValArrayCnt == 1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxValArray[0]);
								    }
								    else if(newMaxValArray == NULL && newMaxVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
							    if(isMinValModify == TRUE )
							    {
								    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,minValuesPROP,newMinValArray,newMinValArrayCnt);
								    }
								    else if(newMinValArray && newMinValArrayCnt ==   1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinValArray[0]);
								    }
								    else if(newMinValArray == NULL && newMinVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
							    if(isInitValModify == TRUE)
							    {
								    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,initialValuesPROP,newInitValArray,newInitValArrayCnt);
								    }
								    else if(newInitValArray && newInitValArrayCnt ==  1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitValArray[0]);
								    }
								    else if(newInitValArray == NULL && newInitVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
						    }//else
					    }//lgRowLabelMisMatchFound == false
				    }else if((tc_strcmp(parameterInfo[counter].structureOfData,Array1DInfo) == 0) ||
					        (tc_strcmp(parameterInfo[counter].structureOfData,ScalarInfo) == 0))
				    {
					    if(isColumnLabelModify || isRowLabelModify)
					    {
							    if(validRowCol_basedStrOfdata== true && lgRowLabelMisMatchFound == false && lgColumnLabelMisMatchFound == false && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
							    {
								    //Delete existing cells and recreate the cells for Min/Max/Initial/Labels
								    ifail=FVE_set_rowColumns(tagOldParmRevObj,oldNumRows,newNumCols,true,true,newRowLabelNames,newColLabelNames);
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
    								
								    //set the Max  Values
								    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
								    }
								    else if(newMaxValArray && newMaxValArrayCnt == 1)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray[0]);
								    }
								    else if(newMaxValArray == NULL && newMaxVal)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxVal);
								    }
                                    else if(newMaxValArray == NULL && newMaxVal == NULL)
                                    {
                                        ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,maxValuesPROP,newMaxValArray,NULL,NULL);
                                    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
    								
								    //set the Min Values
								    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray,NULL,NULL);
								    }
								    else if(newMinValArray && newMinValArrayCnt ==   1)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinValArray[0]);
								    }
								    else if(newMinValArray == NULL && newMinVal)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinVal);
								    }
                                    else if(newMinValArray == NULL && newMinVal == NULL)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,minValuesPROP,newMinVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;

								    //set the Initial Values
								    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray,NULL,NULL);
								    }
								    else if(newInitValArray && newInitValArrayCnt ==  1)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitValArray[0]);
								    }
								    else if(newInitValArray == NULL && newInitVal)
								    {
									    ifail=FVE_create_cells_MinMaxInit(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,initialValuesPROP,newInitVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
					    }
					    else
					    {
						    if(validRowCol_basedStrOfdata == true && lgInitialValMisMatchFound == false && lgMinValMisMatchFound == false && lgMaxValMisMatchFound == false)
						    {
							    if(isMaxValModify == TRUE)
							    {
								    if(newMaxValArray && newMaxValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,maxValuesPROP,newMaxValArray,newMaxValArrayCnt);
								    }
								    else if(newMaxValArray && newMaxValArrayCnt == 1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxValArray[0]);
								    }
								    else if(newMaxValArray == NULL && newMaxVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,maxValuesPROP,newMaxVal);
								    }
								    if(ifail != ITK_ok)
								    ifail=ITK_ok;
							    }
							    if(isMinValModify == TRUE )
							    {
								    if(newMinValArray && newMinValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,minValuesPROP,newMinValArray,newMinValArrayCnt);
								    }
								    else if(newMinValArray && newMinValArrayCnt ==   1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinValArray[0]);
								    }
								    else if(newMinValArray == NULL && newMinVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,minValuesPROP,newMinVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
							    if(isInitValModify == TRUE)
							    {
								    if(newInitValArray && newInitValArrayCnt ==   newNumRows*newNumCols)
								    {
									    ifail=FVE_set_values(tagOldParmRevObj,initialValuesPROP,newInitValArray,newInitValArrayCnt);
								    }
								    else if(newInitValArray && newInitValArrayCnt ==  1)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitValArray[0]);
								    }
								    else if(newInitValArray == NULL && newInitVal)
								    {
									    ifail=FVE_set_value(tagOldParmRevObj,initialValuesPROP,newInitVal);
								    }
								    if(ifail != ITK_ok)
									    ifail=ITK_ok;
							    }
						    }
					    }
				    }
			    }//else rowCnt ,colCnt didnt modify
          //  } // comment
		}//		if(isObjDblType || isObjIntType || isObjHexType ||isObjStrType)

		/*set isSigned attribute after setting Min/max/Initial values*/
		if(isSignedModify == TRUE)
		{
			ITK(AOM_refresh(tagOldParmRevObj,TRUE))
			if(isObjDblType || isObjIntType)
			{
				ITK(AOM_set_value_logical(tagOldParmRevObj,isSignedPROP,newIsSignedVal))
				if(ifail != ITK_ok)
					ifail=ITK_ok;
			}
			ITK(AOM_save(tagOldParmRevObj))
			ITK(AOM_refresh(tagOldParmRevObj,FALSE))
		}

		if(isObjSedType)
		{
			//set valid values
			if(isValidValModify)
			{
				if(isRowCntModify)
				{
					ifail=FVE_set_rowColumns(tagOldParmRevObj,newNumRows,newNumCols,false,false,NULL,NULL);
					ifail=FVE_create_cells(tagOldParmRevObj,newNumRows,oldNumRows,newNumCols,oldNumCols,validValuesPROP,valDomainElName,valDomainElVal,newDomainDescrVal);
					if(newNumRows < oldNumRows)
					{
						/*From TC 9 - sed contains 3rd column for domain description.So modify function signature*/
						ifail=FVE_set_sedValidValues(tagOldParmRevObj,validValuesPROP,valDomainElName,valDomainElVal,newDomainDescrVal);
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}

				}else
				{   
					/*From TC 9 - sed contains 3rd column for domain description.So modify function signature*/
					ifail=FVE_set_sedValidValues(tagOldParmRevObj,validValuesPROP,valDomainElName,valDomainElVal,newDomainDescrVal);
					if(ifail != ITK_ok)
						ifail=ITK_ok;
				}

			}
			//set initial values
			if(isInitValModify == TRUE && domainElVal[0] && tc_strlen(domainElVal[0])> 0)
			{
					ITK(AOM_refresh(tagOldParmRevObj,TRUE))
					ITK(AOM_set_value_string(tagOldParmRevObj, initialValuePROP, domainElVal[0]))
					ITK(AOM_save(tagOldParmRevObj))
					ITK(AOM_refresh(tagOldParmRevObj,FALSE))
			}
		}//isObjSedType


		if(isObjSedType)
		{
			if(lgMisMatchCount == true)
			{

				fprintf(logfileptr,"Domain Element Name Count=%d\n",cntDomainElName);
				fprintf(logfileptr,"Domain Element Value Count=%d\n",cntDomainElVal);
				fprintf(logfileptr,"Different count exist for domain element name and values.\n");
				fprintf(logfileptr,"Status: Failed\n");
				fprintf(logfileptr,"ERROR: Required attributes are missing during update of %s\n",parameterInfo[counter].name);

				fprintf(logFilePtrFailure,"Parameter Name:%s \n",parameterInfo[counter].name);
				fprintf(logFilePtrFailure,"Domain Element Name Count= %d\n",cntDomainElName);
				fprintf(logFilePtrFailure,"Domain Element Value Count= %d\n",cntDomainElVal);
				fprintf(logFilePtrFailure,"Different count exist for domain element name and values.\n");
				fprintf(logFilePtrFailure,"Status: Failed.\n");
				fprintf(logFilePtrFailure,"ERROR: Required attributes are missing during update of %s\n",parameterInfo[counter].name);
				fprintf(logFilePtrFailure,"\n");

			    if(isUnitModify || isParmTypeModify || isParmUsageModify || isRowCntModify || isColCntModify ||
				isFaultValModify || isInhaleExhaleValModify || isRestrictedValModify || isModuleManfValModify || isFcsdCustPrefValModify || isAsBuiltVehOpValModify || sedReqPropModify)
				{
					fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
				}else if(isDescrModify)
				{
					if((newDescrVal && tc_strlen(newDescrVal) <= 240))
					{
							fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
							flagMsg=true;
					}if( (newDescrVal == NULL || tc_strlen(newDescrVal) == 0))
					{
						if(flagMsg == false)
						{
							fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
							flagMsg=true;
						}
					}if((newDescrVal && tc_strlen(newDescrVal) > 1024) )
					{
						if(flagMsg == false)
						{
							fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport");
							flagMsg=true;
						}

					}
				}
			}else
			{

				if(isUnitModify || isParmTypeModify || isParmUsageModify || isRowCntModify || isColCntModify ||
				isFaultValModify || isInhaleExhaleValModify || isRestrictedValModify || isModuleManfValModify || isFcsdCustPrefValModify || isAsBuiltVehOpValModify || sedReqPropModify)
				{

					fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
				}else if(isDescrModify)
				{
					if((newDescrVal && tc_strlen(newDescrVal) <= 240) )
					{
							fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
							flagMsg=true;
					}if( (newDescrVal == NULL || tc_strlen(newDescrVal) == 0))
					{
						if(flagMsg == false)
						{
							fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
							flagMsg=true;
						}
					}if((newDescrVal && tc_strlen(newDescrVal) > 2000) )
					{
						if(flagMsg == false)
						{
							fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport");
							flagMsg=true;
						}

					}
				}
			}
		}else
		{
			if(validRowCol_basedStrOfdata == false ||lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound || lgRowLabelMisMatchFound || lgColumnLabelMisMatchFound)
			{
				 fprintf(logFilePtrFailure,"Parameter Name:%s \n",parameterInfo[counter].name);
				 fprintf(logFilePtrFailure,"Row count=%d \n",newNumRows);
				 fprintf(logFilePtrFailure,"Column count=%d \n",newNumCols);
				 fprintf(logFilePtrFailure,"Structure Of Data:%s \n",parameterInfo[counter].structureOfData);

				if(validRowCol_basedStrOfdata == false)
				{
					fprintf(logfileptr,"Row X Column size is not provided correctly based on the structure of data.\n");
					fprintf(logFilePtrFailure,"Row X Column size is not provided correctly based on the structure of data.\n");
				}
				if(lgInitialValMisMatchFound)
				{
					fprintf(logfileptr,"Initial Value array size do not match with the row and column sizes.\n");
					fprintf(logFilePtrFailure,"Initial Value array size do not match with the row and column sizes.\n");
				}
				if(lgMinValMisMatchFound)
				{
					fprintf(logfileptr,"Minimum Value array size do not match with the row and column sizes.\n");
					fprintf(logFilePtrFailure,"Minimum Value array size do not match with the row and column sizes.\n");
				}
				if(lgMaxValMisMatchFound)
				{
					fprintf(logfileptr,"Maximum Value array size do not match with the row and column sizes.\n");
					fprintf(logFilePtrFailure,"Maximum Value array size do not match with the row and column sizes.\n");
				}
				if(lgRowLabelMisMatchFound)
				{
					fprintf(logfileptr,"Row Labels size do not match with the row count.\n");
					fprintf(logFilePtrFailure,"Row Labels size do not match with the row count.\n");
				}
				if(lgColumnLabelMisMatchFound)
				{
					fprintf(logfileptr,"Column Labels size do not match with the column count.\n");
					fprintf(logFilePtrFailure,"Column Labels size do not match with the column count.\n");
				}

				fprintf(logFilePtrFailure,"Status: Failed\n");
				fprintf(logFilePtrFailure,"ERROR: Required attributes are missing during update of %s\n", parameterInfo[counter].name);
				fprintf(logfileptr,"Status: Failed\n");
				fprintf(logfileptr,"ERROR: Required attributes are missing during update of %s\n", parameterInfo[counter].name);
			}   fprintf(logfileptr,"\n");


			if(isUnitModify || isParmTypeModify || isParmUsageModify || isRowCntModify || isColCntModify ||
				isFaultValModify || isInhaleExhaleValModify || isRestrictedValModify || isModuleManfValModify || isFcsdCustPrefValModify || isAsBuiltVehOpValModify 
				|| intReqPropModify || doubleReqPropModify ||strReqPropModify || hexReqPropModify)
			{
				fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
			}else if(isDescrModify)
			{
				if((newDescrVal && tc_strlen(newDescrVal) <= 2000))
				{
					fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
					flagMsg=true;
				}else if( (newDescrVal == NULL || tc_strlen(newDescrVal) == 0) )
				{
					if(flagMsg == false)
					{
						fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
						flagMsg=true;
					}
				}else if((newDescrVal && tc_strlen(newDescrVal) > 2000) )
				{
					if(flagMsg == false)
					{
						fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport");
						flagMsg=true;
					}
				}
			}
		}
        //set updated properties on Item
		ITK(AOM_refresh(tagOldParmItemObj,FALSE))
		AM__set_application_bypass(FALSE);
	}else
	{
		if(isObjSedType)
		{
			if(lgMisMatchCount == true)
			{
				fprintf(logfileptr,"Domain Element Name Count=%d\n",cntDomainElName);
				fprintf(logfileptr,"Domain Element Value Count=%d\n",cntDomainElVal);
				fprintf(logfileptr,"Different count exist for domain element name and values.\n");
				fprintf(logfileptr,"Status: Failed\n");
				fprintf(logfileptr,"ERROR: Required attributes are missing during update of %s\n",parameterInfo[counter].name);

				fprintf(logFilePtrFailure,"Parameter Name:%s \n",parameterInfo[counter].name);
				fprintf(logFilePtrFailure,"Domain Element Name Count= %d\n",cntDomainElName);
				fprintf(logFilePtrFailure,"Domain Element Value Count= %d\n",cntDomainElVal);
				fprintf(logFilePtrFailure,"Different count exist for domain element name and values.\n");
				fprintf(logFilePtrFailure,"Status: Failed.\n");
				fprintf(logFilePtrFailure,"ERROR: Required attributes are missing during update of %s\n", parameterInfo[counter].name);
				fprintf(logFilePtrFailure,"\n");
			}
		}else if(isObjIntType || isObjDblType || isObjHexType || isObjStrType)
		{
			if(validRowCol_basedStrOfdata == false ||lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound || lgRowLabelMisMatchFound || lgColumnLabelMisMatchFound)
			{
				 fprintf(logFilePtrFailure,"Parameter Name:%s \n",parameterInfo[counter].name);
				 fprintf(logFilePtrFailure,"Row count=%d \n",newNumRows);
				 fprintf(logFilePtrFailure,"Column count=%d \n",newNumCols);
				 fprintf(logFilePtrFailure,"Structure Of Data:%s \n",parameterInfo[counter].structureOfData);

				if(validRowCol_basedStrOfdata == false)
				{
					fprintf(logfileptr,"Row X Column size is not provided correctly based on the structure of data.\n");
					fprintf(logFilePtrFailure,"Row X Column size is not provided correctly based on the structure of data.\n");
				}
				if(lgInitialValMisMatchFound)
				{
					fprintf(logfileptr,"Initial Value array size do not match with the row and column sizes.\n");
					fprintf(logFilePtrFailure,"Initial Value array size do not match with the row and column sizes.\n");
				}
				if(lgMinValMisMatchFound)
				{
					fprintf(logfileptr,"Minimum Value array size do not match with the row and column sizes.\n");
					fprintf(logFilePtrFailure,"Minimum Value array size do not match with the row and column sizes.\n");
				}
				if(lgMaxValMisMatchFound)
				{
					fprintf(logfileptr,"Maximum Value array size do not match with the row and column sizes.\n");
					fprintf(logFilePtrFailure,"Maximum Value array size do not match with the row and column sizes.\n");
				}
				if(lgRowLabelMisMatchFound)
				{
					fprintf(logfileptr,"Row Labels size do not match with the row size.\n");
					fprintf(logFilePtrFailure,"Row Labels size do not match with the row size.\n");
				}
				if(lgColumnLabelMisMatchFound)
				{
					fprintf(logfileptr,"Column Labels size do not match with the column size.\n");
					fprintf(logFilePtrFailure,"Column Labels size do not match with the column size.\n");
				}

				 fprintf(logFilePtrFailure,"Status: Failed\n");
				 fprintf(logFilePtrFailure,"ERROR: Required attributes are missing during update of %s\n", parameterInfo[counter].name);

				 fprintf(logfileptr,"Status: Failed\n");
				 fprintf(logfileptr,"ERROR: Required attributes are missing during update of %s\n", parameterInfo[counter].name);
			}
		}

		fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport");
	}
	if(validRowCol_basedStrOfdata == false ||lgInitialValMisMatchFound || lgMinValMisMatchFound || lgMaxValMisMatchFound || lgRowLabelMisMatchFound || lgColumnLabelMisMatchFound || lgMisMatchCount)
	{
		failureCntParameter++;
	}else
	{
		successCntParameter++;
	}

CLEANUP:
    FVE_FREE(bomlineItemType)
	FVE_FREE_ARRAY(valDomainElName,cntDomainElName)
	cntDomainElName =0;
	FVE_FREE_ARRAY(valDomainElVal,cntDomainElVal)
	cntDomainElVal=	0;
	FVE_FREE_ARRAY(newDomainDescrVal,newCntDD)
	newCntDD=0;
	FVE_FREE_ARRAY(oldDomainDescrVal,oldCntDD)
	oldCntDD=0;
	FVE_FREE(oldValidValues)
	FVE_FREE(oldDomainElNames)
	FVE_FREE(finalStrDD)

	FVE_FREE(oldParmTypeVal)
	FVE_FREE(oldParmUsageVal)
	FVE_FREE(oldDescrVal)
	FVE_FREE(oldUnitVal)
	FVE_FREE(old_sedInitialValue)
	FVE_FREE(oldNumeratorValue)
	FVE_FREE(oldDenominatorValue)
	FVE_FREE(oldToleranceValue)
	FVE_FREE(oldPrecisionValue)
	FVE_FREE(oldfaultVal)
	FVE_FREE(oldRestrictedVal)
	FVE_FREE(oldInhaleExhaleVal)
	FVE_FREE(oldAsBuiltVehOpVal)
	FVE_FREE(oldModuleManfVal)
	FVE_FREE(oldFcsdCustPrefVal)
	FVE_FREE(oldMinValues)
	FVE_FREE(oldMaxValues)
	FVE_FREE(oldInitValues)

	FVE_FREE_ARRAY(newInitValArray,newInitValArrayCnt)
	newInitValArrayCnt	=	0;
	FVE_FREE_ARRAY(dummyInitValArray,dummyInitValArrayCnt)
	dummyInitValArrayCnt=0;
	FVE_FREE_ARRAY(newMinValArray,newMinValArrayCnt)
	newMinValArrayCnt	=	0;

	FVE_FREE_ARRAY(dummyMinValArray,dummyMinValArrayCnt)
	dummyMinValArrayCnt	=	0;

	FVE_FREE_ARRAY(newMaxValArray,newMaxValArrayCnt);
	newMaxValArrayCnt	=	0;

	FVE_FREE_ARRAY(dummyMaxValArray,dummyMaxValArrayCnt)
	dummyMaxValArrayCnt	=	0;

	FVE_FREE_ARRAY(newColLabelNames,newColLabelCnt)
	newColLabelCnt	=	0;

	FVE_FREE_ARRAY(newRowLabelNames,newRowLabelCnt)
	newRowLabelCnt	=	0;

	FVE_FREE_ARRAY(oldRowLabelNames,oldRowLabelCnt)
	oldRowLabelCnt	=	0;

	FVE_FREE_ARRAY(oldColLabelNames,oldColLabelCnt)
	oldColLabelCnt		=	0;

	FV_FREE_STRINGS (validatorIntArray)
	FV_FREE_STRINGS (validatorMaxArray)
	FV_FREE_STRINGS (validatorMinArray)



	TC_write_syslog("\n Leave %s",function_name);
    time( &clock );
    TC_write_syslog("End time : %s\n", ctime(&clock));
	return ifail;
}

int FV_log_validation_error(int errorCode, char* parameterName)
{
    int     ifail = ITK_ok;
    char*   message = NULL;

    if(logfileptr != NULL && logFilePtrFailure != NULL)
    {
        EMH_ask_error_text (errorCode, &message);
        fprintf(logFilePtrFailure,"Parameter Name:%s \n",parameterName);

        if(errorCode == FV_CCDM_ERROR_INVALID_ISSIGNED)
        {
            fprintf(logFilePtrFailure,"Status: Failed\n");
            fprintf(logFilePtrFailure,"ERROR: %s\n","Invalid isSigned Value\n");

            fprintf(logfileptr,"Status: Failed\n");
            fprintf(logfileptr,"ERROR: %s\n","Invalid isSigned Value.");
        }
        else if(errorCode == FV_CCDM_ERROR_NOT_IN_RANGE)
        {
            fprintf(logFilePtrFailure,"Status: Failed\n");
            fprintf(logFilePtrFailure,"ERROR: %s\n","The minimum, maximum and initial table cell values are not in range.\n");

            fprintf(logfileptr,"Status: Failed\n");
            fprintf(logfileptr,"ERROR: %s\n","The minimum, maximum and initial table cell values are not in range.");
        }
        else if(errorCode == FV_CCDM_ERROR_INVALID_VALUE)
        {
            fprintf(logFilePtrFailure,"Status: Failed\n");
            fprintf(logFilePtrFailure,"ERROR: %s\n","The minimum, maximum and initial table cell values are not hex.\n");

            fprintf(logfileptr,"Status: Failed\n");
            fprintf(logfileptr,"ERROR: %s\n","The minimum, maximum and initial table cell values are not hex.");
        }
        else if(errorCode == FV_CCDM_ERROR_VALUE_NOT_ACTUAL_INCREMENT_OF_RES)
        {
            fprintf(logFilePtrFailure,"Status: Failed\n");
            fprintf(logFilePtrFailure,"ERROR: %s\n","The initial value is not an actual increment of resolution with respect to minimum value.\n");

            fprintf(logfileptr,"Status: Failed\n");
            fprintf(logfileptr,"ERROR: %s\n","The initial value is not an actual increment of resolution with respect to minimum value.");
        }
        else if(errorCode == FV_CCDM_ERROR_INSUFFICIENT_INCREMENT)
        {
            fprintf(logFilePtrFailure,"Status: Failed\n");
            fprintf(logFilePtrFailure,"ERROR: %s\n","The increment is insufficient.\n");

            fprintf(logfileptr,"Status: Failed\n");
            fprintf(logfileptr,"ERROR: %s\n","The increment is insufficient.");
        }else if(errorCode == FV_CCDM_ERROR_INVALID_INITVALUE)
		{
			fprintf(logFilePtrFailure,"Status: Failed\n");
            fprintf(logFilePtrFailure,"ERROR: %s\n","The initial value is invalid.\n");

            fprintf(logfileptr,"Status: Failed\n");
            fprintf(logfileptr,"ERROR: %s\n","The initial value is invalid.");

		}
        else
        {
            fprintf(logFilePtrFailure,"Status: Failed\n");
            fprintf(logFilePtrFailure,"ERROR: %s\n",message);

            fprintf(logfileptr,"Status: Failed\n");
            fprintf(logfileptr,"ERROR: %s\n",message);
        }
		fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport.");
    }

CLEANUP:
    FVE_FREE(message)

    return ifail;
}

/*
   Function to reCreate cells with multiple values during update of Parameter Definition ...
   Additional argument "domainElVal" is required for SED type.
*/
int FVE_reCreate_cells_multipleValues(tag_t parmDefRev,int newNumRows,int newNumCols,char *propName,char **values,char **domainElVal,char **domainElDescr)
{
	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_reCreate_cells_multipleValues";

	int			iCounter						=	0;
	int			jCounter						=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		intColBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		* rowNumber						=   NULL;
	char		* colNumber						=   NULL;
	tag_t		tableCellTypeTag				=	NULLTAG;
	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		tableCellInputTag				= NULLTAG;

	tag_t		item							=	NULLTAG;
	char	item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		attrIdValueTag					=	NULLTAG;
	tag_t		attrIdDescTag					=	NULLTAG;
	tag_t		attrIdDomainDescTag				=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;
	tag_t      tableTag = NULLTAG;

	int    incrCounter			=	0;

	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))

	if(parmDefRev && propName)
	{
		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || 
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || 
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellSEDCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellSEDCLASS,&attrIdDescTag))
				ITK(POM_attr_id_of_attr("fnd0DomainElementDesc",TableCellSEDCLASS,&attrIdDomainDescTag))
			}
			else if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||  (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellIntCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellIntCLASS,&attrIdDescTag))
			}else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellDoubleCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellDoubleCLASS,&attrIdDescTag))
			}else if((tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellStringCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellStringCLASS,&attrIdDescTag))
			} // Nikhil Patil - Added if block for hex type.
            else if((tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellHexCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellHexCLASS,&attrIdDescTag))
			}

			// Get *any* TypedReference Table object for the Parameter Definition Revision.
			ITK(AOM_ask_value_tag(parmDefRev,propName,&tableTag));

			ITK(POM_refresh_instances_any_class(1,&tableTag,POM_no_lock))
			ITK(POM_load_instances_any_class(1,&tableTag,POM_no_lock))

			ITK(AOM_refresh(parmDefRev,TRUE))
			ITK(AOM_refresh(tableTag,TRUE))

			for(iCounter=0;iCounter<newNumRows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;

				for(jCounter=0;jCounter<newNumCols;jCounter++)
				{
					sprintf(intColBuf, "%d",jCounter);
   					colNumber = intColBuf;
					if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellIntCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag && values && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
						{
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdValueTag,atoi(values[incrCounter])));
							incrCounter++;
						}
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}else if( (tc_strcmp(item_type,FVE_ParmDefStrTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellStringCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));
						//set value
						if(attrIdValueTag && values && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,values[incrCounter]));
							incrCounter++;
						}
                        else if (attrIdValueTag && values == NULL)
                        {
                            ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,""));
                        }
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}
					else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellDoubleCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag && values && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
						{
							ITK(POM_set_attr_double(1,&tableCellInputTag,attrIdValueTag,atof(values[incrCounter])));
							incrCounter++;
						}
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}else if( (tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellSEDCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))

						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set desc
						if(attrIdDescTag && values && values[iCounter] && tc_strlen(values[iCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdDescTag,values[iCounter]));
						}

						//set value
						if(attrIdValueTag && domainElVal[iCounter] && tc_strlen(domainElVal[iCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,domainElVal[iCounter]));
							//incrCounter++;
						}
						//set domain descrption
						if(attrIdDomainDescTag && domainElDescr[iCounter] && tc_strlen(domainElDescr[iCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdDomainDescTag,domainElDescr[iCounter]));
							//incrCounter++;
						}

						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))
					}//objSED
                    // Nikhil Patil - FVE_ParmDefHexTYPE
                    else if( (tc_strcmp(item_type,FVE_ParmDefHexTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValHexTYPE) == 0))
                    {
                        ITK(POM_class_id_of_class(TableCellHexCLASS, &tableCellTypeTag))
                        ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
                        //set row value
                        if(attrIdRowTag)
                            ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
                        //set column value
                        if(attrIdColTag)
                            ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

                        //set value
                        if(attrIdValueTag && values && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
                        {
                            ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,values[incrCounter]));
                            incrCounter++;
                        }
                        ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

                    } // object hex.

						// Add array cell input tag to array of tags.
					ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTag))
				}//jCounter
			}//iCounter
			if(tableTag && prop_tagCell && cellInputTags)
				ITK(POM_set_attr_tags(1,&tableTag,prop_tagCell,0,cellCnt,cellInputTags))

			ITK(AOM_save(tableTag))
			ITK(AOM_refresh(tableTag,FALSE))

			ITK(AOM_save(parmDefRev))
			ITK(AOM_refresh(parmDefRev,FALSE))

		}//itemType

	}//parmDefRev

	return ifail;
}

/* Function to reCreate cells with single value during update of Parameter Definition ...
*/
int FVE_reCreate_cells_singleValue(tag_t parmDefRev,int newNumRows,int newNumCols,char *propName,char *value)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_reCreate_cells_singleValue";

	int			iCounter						=	0;
	int			jCounter						=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		intColBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		* rowNumber						=   NULL;
	char		* colNumber						=   NULL;
	tag_t		tableCellTypeTag				=	NULLTAG;
	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		tableCellInputTag				= NULLTAG;

	tag_t		item							=	NULLTAG;
	char	item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		attrIdValueTag					=	NULLTAG;
	tag_t		attrIdDescTag					=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;
	tag_t      tableTag = NULLTAG;


	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))

	if(parmDefRev && propName && value && tc_strlen(value)> 0)
	{
		ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))

		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if(tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0)
			{
				ITK(POM_attr_id_of_attr("value",TableCellSEDCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellSEDCLASS,&attrIdDescTag))
			}
			else if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) )
			{
				ITK(POM_attr_id_of_attr("value",TableCellIntCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellIntCLASS,&attrIdDescTag))
			}else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellDoubleCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellDoubleCLASS,&attrIdDescTag))
			} // Add if block for hex type.
            else if((tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellHexCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellHexCLASS,&attrIdDescTag))
			} // Add if block for string
            else if((tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellStringCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellStringCLASS,&attrIdDescTag))
			}

			// Get *any* TypedReference Table object for the Parameter Definition Revision.
			ITK(AOM_ask_value_tag(parmDefRev,propName,&tableTag));

			ITK(POM_refresh_instances_any_class(1,&tableTag,POM_no_lock))
			ITK(POM_load_instances_any_class(1,&tableTag,POM_no_lock))

			ITK(AOM_refresh(parmDefRev,TRUE))
			ITK(AOM_refresh(tableTag,TRUE))

			for(iCounter=0;iCounter<newNumRows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;

				for(jCounter=0;jCounter<newNumCols;jCounter++)
				{
					sprintf(intColBuf, "%d",jCounter);
   					colNumber = intColBuf;
					if(tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0)
					{
						ITK(POM_class_id_of_class(TableCellIntCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdValueTag,atoi(value)));
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}else if(tc_strcmp(item_type,FVE_ParmDefDblTYPE) ==0)
					{
						ITK(POM_class_id_of_class(TableCellDoubleCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag)
							ITK(POM_set_attr_double(1,&tableCellInputTag,attrIdValueTag,atof(value)));
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}
                    else if(tc_strcmp(item_type,FVE_ParmDefHexTYPE) ==0)
					{
						ITK(POM_class_id_of_class(TableCellHexCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag)
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,value));
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					} // Nikhil Patil - Add if block for string.
                    else if(tc_strcmp(item_type,FVE_ParmDefStrTYPE) ==0)
					{
						ITK(POM_class_id_of_class(TableCellStringCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag)
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,value));
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}
					// Add array cell input tag to array of tags.
					ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTag))
				}//jCounter
			}//iCounter
			if(tableTag && prop_tagCell && cellInputTags)
				ITK(POM_set_attr_tags(1,&tableTag,prop_tagCell,0,cellCnt,cellInputTags))

			ITK(AOM_save(tableTag))
			ITK(AOM_refresh(tableTag,FALSE))

			ITK(AOM_save(parmDefRev))
			ITK(AOM_refresh(parmDefRev,FALSE))

		}//itemType

	}//parmDefRev

	FVE_FREE(cellInputTags);
	cellCnt=0;
	return ifail;
}
/*
Function to create the cells based on the item type and set the single value(Min/Max/Initial) for rows*columns.
For SED type its columns are fixed (domain Name and Description) , it will never modify as of TC8.1.

Nikhil Patil change - 
    Added if block for hex param def and hex param value object.
*/
int FVE_create_cells_MinMaxInit(tag_t parmDefRev,int newNumRows,int oldNumRows,int newNumCols,int oldNumCols,char *propName,char *value)
{
	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_create_cells_MinMaxInit";

	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;

	tag_t		item							=	NULLTAG;
	char		item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;

	tag_t	*cells				=	NULL;
	int		num_cells			=	0;

	tag_t	attr_value			=	NULLTAG;
	tag_t	table_def=NULLTAG;


	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))

	if(parmDefRev && propName && value && tc_strlen(value)> 0)
	{
		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || 
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || 
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}

		ITK(AOM_get_value_tag(parmDefRev,propName, &attr_value))
		ITK(AOM_get_value_tag(attr_value, definitionPROP, &table_def))
		ITK(AOM_get_value_tags(attr_value, cellsPROP, &num_cells, &cells))

		/*Delete existing cells during update and then reCreate the cells based on the itemtype */
		ITK(AOM_refresh(parmDefRev,TRUE))
		ITK(AOM_refresh(table_def,TRUE))

		//set references to NULL and then delete existing cells
		ITK(AOM_refresh(attr_value,TRUE))
		ifail=AOM_set_value_tags(attr_value,"cells",0,NULL);
		ITK(AOM_save(attr_value))
		ITK(AOM_refresh(attr_value,FALSE))
		ifail=FV_delete_pom_objects(oldNumRows*oldNumCols,cells);

		ITK(AOM_save(table_def))
		ITK(AOM_refresh(table_def,FALSE))

		ITK(AOM_save(parmDefRev))
		ITK(AOM_refresh(parmDefRev,FALSE))

		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || (tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) || 
				(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
                (tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValHexTYPE) == 0) )
			{
				//reCreate the cells for a property and set the values
				ifail=FVE_reCreate_cells_singleValue(parmDefRev,newNumRows,newNumCols,propName,value);
			}
		}
	}//parmDefRev

	TC_write_syslog("\n Entering %s\n", function_name);
	FVE_FREE(cellInputTags);
	cellCnt=0;
	return ifail;
}


/*
Function to create the cells based on the item type and set the array of values(Min/Max/Initial).
For SED type its columns are fixed (domain Name , value) , it will never modify as of TC8.1.
From TC 9  -columns for SED are name , value and description.
*/
int FVE_create_cells(tag_t parmDefRev,int newNumRows,int oldNumRows,int newNumCols,int oldNumCols,char *propName,char **valDomainElName,char **valDomainElVal,char **valDomainElDescr)
{
	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_create_cells";

	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;

	tag_t		item							=	NULLTAG;
	char	item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;

	tag_t	*cells				=	NULL;
	int		num_cells			=	0;

	//tag_t   valueTag = NULLTAG;


	tag_t	attr_value			=	NULLTAG;
	tag_t	table_def=NULLTAG;


	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))


	if(parmDefRev && propName && tc_strlen(propName)> 0)
	{
		ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
		//get the item type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))

		ITK(AOM_ask_value_tag(parmDefRev,propName, &attr_value))
		ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
		ITK(AOM_ask_value_tags(attr_value, cellsPROP, &num_cells, &cells))

		//first delete cells and then recreate cells for property based on itemType.
		ITK(AOM_refresh(parmDefRev,TRUE))
		ITK(AOM_refresh(table_def,TRUE))

		//set references to NULL and then delete the cells
		ITK(AOM_refresh(attr_value,TRUE))
		ifail=AOM_set_value_tags(attr_value,"cells",0,NULL);
		ITK(AOM_save(attr_value))
		ITK(AOM_refresh(attr_value,FALSE))
		ifail=FV_delete_pom_objects(oldNumRows*oldNumCols,cells);

		ITK(AOM_save(table_def))
		ITK(AOM_refresh(table_def,FALSE))

		ITK(AOM_save(parmDefRev))
		ITK(AOM_refresh(parmDefRev,FALSE))

		//now recreate the cells for a property and set the values based on itemType
		/*For SED , 2 value arrays required i.e. domain name and decription.
		  For Other types only value array is required.*/
		if(item_type && tc_strlen(item_type)> 0)
		{
			if(tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0)
			{
				if(valDomainElName && valDomainElVal)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,valDomainElVal,valDomainElDescr);
				}
			}else if((tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0))
			{
				if(valDomainElName)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,NULL,NULL);
				}
			}else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0))
			{
				if(valDomainElName)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,NULL,NULL);
				}
			}else if((tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0))
			{
				// For String parameter, values can be null i.e. min/max tables are not mandatory.
                //if(valDomainElName)
				//{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,NULL,NULL);
				//}
			} // Nikhil Patil - Added if block for hex type parameter.
            else if((tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0))
			{
				// For hex parameter, values can be null i.e. min/max tables are not mandatory.
                if(valDomainElName)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,NULL,NULL);
				}
			}
		}//item_type

	}//parmDefRev

	FVE_FREE(cellInputTags)
	cellCnt=0;


	TC_write_syslog("\n Entering %s\n", function_name);
	return ifail;
}

/*
function to set the modified row , column value on revision and accordingly create/delete required cells.

Arguments : revision
            modified row value
			modified column value
			logical value true/false to set rowlabelName
			logical value true/false to set columnLabel
			array rowLabelNames
			array colLabelNames
*/
int FVE_set_rowColumns(tag_t parmDefRev,int Rows,int Columns,logical flagRowLabel,logical flagColLabel,char **rowlabelArr,char **colLabelArr)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_set_rowColumns";
	int			old_num_cols					=	0;
	int			old_num_rows					=	0;
	tag_t		tableDefTag						=	NULLTAG;
	char        rev_type[ITEM_type_size_c + 1]  =	"";
	tag_t		item							=	NULLTAG;
	char		item_type[ITEM_type_size_c+1];

	TC_write_syslog("\n Entering %s\n", function_name);

	if(parmDefRev)
	{
		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		ITK(ITEM_ask_rev_type(parmDefRev, rev_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || 
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || 
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValHexTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}
	}

	if(tableDefTag)
	{
		ITK(AOM_ask_value_int(tableDefTag, colsPROP, &old_num_cols))
		ITK(AOM_ask_value_int(tableDefTag, rowsPROP, &old_num_rows))

		ITK(AOM_refresh(parmDefRev,TRUE))
		ITK(AOM_refresh(tableDefTag,TRUE))

		ITK(AOM_set_value_int(tableDefTag,colsPROP,Columns))
		ITK(AOM_set_value_int(tableDefTag,rowsPROP,Rows))
		ITK(AOM_save(tableDefTag))
		ITK(AOM_refresh(tableDefTag,FALSE))

		ITK(AOM_save(parmDefRev))
		ITK(AOM_refresh(parmDefRev,FALSE))

		if ( (tc_strcmp(rev_type, FVE_ParmDefIntRevisionTYPE)==0) || (tc_strcmp(rev_type, FVE_ParmDefDblRevisionTYPE)==0) || (tc_strcmp(rev_type, FVE_ParmDefStrRevisionTYPE)==0) || (tc_strcmp(rev_type, FVE_ParmDefHexRevisionTYPE)==0) || 
			 (tc_strcmp(rev_type, FV9ParmValIntRevisionTYPE)==0) ||  (tc_strcmp(rev_type, FV9ParmValDblRevisionTYPE)==0) ||  (tc_strcmp(rev_type, FV9ParmValStrRevisionTYPE)==0) ||  (tc_strcmp(rev_type, FV9ParmValHexRevisionTYPE)==0))
		{
			//create /delete row cells
			if( (flagRowLabel && rowlabelArr) || (flagColLabel && colLabelArr) )
			{
				ifail=FV_create_cells_labels(parmDefRev,Rows,old_num_rows,rowLabelsPROP,rowlabelArr,Columns,old_num_cols,colLabelsPROP,colLabelArr);
			}
		}
	}//tableDefTag != NULLTAG

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}

/*
Function to reCreate cells during update
*/
int FVE_reCreate_cellsLabels(tag_t revision,int new_count,char *propName,char **propValues)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_reCreate_cellsLabels";
	tag_t		tableDefTag						=	NULLTAG;
	int			cnt_row							=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	int			locationCounter					=	0;
	char		*rowCountStr					=	NULL;
	tag_t       pomClassIdLabel					=	NULLTAG;
	tag_t       attrIdLabelTag					=	NULLTAG;
	tag_t		attrIdLocationTag				=	NULLTAG;
	tag_t		tableRowLabelInputTag			=	NULLTAG;
	tag_t*      cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		prop_tag						=	NULLTAG;
	char	item_type[ITEM_type_size_c+1];
	tag_t	item								=	NULLTAG;

	logical		isParmDefObject					=	FALSE;
	logical		isFv9ValObject					=	FALSE;



	TC_write_syslog("\n Enter %s\n", function_name);

	if(revision)
	{
		ITK(ITEM_ask_item_of_rev(revision, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || 
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || 
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(revision,"tableDefinition",&tableDefTag))
					isParmDefObject=TRUE;
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValHexTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(revision,"fv9TableDefinition",&tableDefTag))
					isFv9ValObject=TRUE;
				}
		}
		ITK(POM_class_id_of_class("TableLabel", &pomClassIdLabel))
		if(tableDefTag && propValues)
		{
			//create required label cells for rows or columns
			ITK(POM_refresh_instances_any_class(1,&tableDefTag,POM_no_lock))
			ITK(POM_load_instances_any_class(1,&tableDefTag,POM_no_lock))

			ITK(AOM_refresh(revision,TRUE))
			ITK(AOM_refresh(tableDefTag,TRUE))
			for(cnt_row = 0; cnt_row < new_count; cnt_row++)
			{
				sprintf(intRowBuf, "%d",cnt_row);
   				rowCountStr = intRowBuf;
				locationCounter=locationCounter+1;

				// Create POM object
				ITK(POM_create_instance(pomClassIdLabel, &tableRowLabelInputTag))
				/* Get Attribute Id */
				ITK(POM_attr_id_of_attr("label","TableLabel",&attrIdLabelTag))
				if(propValues[cnt_row] && tc_strlen(propValues[cnt_row]) > 0)
				{
					ITK(POM_set_attr_string(1,&tableRowLabelInputTag,attrIdLabelTag,FV_trim_blanks(propValues[cnt_row])))
				}
				ITK(POM_attr_id_of_attr("location","TableLabel",&attrIdLocationTag))
				ITK(POM_set_attr_int(1,&tableRowLabelInputTag,attrIdLocationTag,cnt_row));
				ITK(POM_save_instances(1, &tableRowLabelInputTag, TRUE))

				//Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableRowLabelInputTag))
			}

			//set rowLabels or columnLabels on tableDefinition
			ITK(POM_attr_id_of_attr(propName,"TableDefinition", &prop_tag))
			ITK(POM_set_attr_tags(1,&tableDefTag,prop_tag,0,cellCnt,cellInputTags))

			ITK(AOM_save(tableDefTag))
			ITK(AOM_refresh(tableDefTag,FALSE))

			ITK(AOM_save(revision))
			ITK(AOM_refresh(revision,FALSE))

		}//tableDefTag

	}//revision
	return ifail;
}
/*
Function to create/delete row/column labels during update of parameter definition revision.
I/P : revision
      new_Rcount
	  old_Rcount
	  rowPropName
	  rowPropValues
	  new_Colcount
	  old_Colcount
	  colPropName
	  colPropValues

*/
int FV_create_cells_labels(tag_t revision,int new_Rcount,int old_Rcount , char *rowPropName ,char **rowPropValues,int new_Colcount,int old_Colcount , char *colPropName ,char **colPropValues)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FV_create_cells_labels";
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       pomClassIdLabel					=	NULLTAG;
	int			rowLabelNumber					=	0;
	tag_t		*rowLabelValues					=	NULL;
	int			colLabelNumber					=	0;
	tag_t		*colLabelValues					=	NULL;
	char	item_type[ITEM_type_size_c+1];
	tag_t	item								=	NULLTAG;

	logical		isParmDefObject					=	FALSE;
	logical		isFv9ValObject					=	FALSE;


	TC_write_syslog("\n Enter %s\n", function_name);

	/* When row/column count get modified , first delete existing  labels and reCreate new Labels.*/
	if(revision)
	{
		ITK(ITEM_ask_item_of_rev(revision, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || 
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || 
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(revision,"tableDefinition",&tableDefTag))
					isParmDefObject=TRUE;
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValHexTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(revision,"fv9TableDefinition",&tableDefTag))
					isFv9ValObject=TRUE;
				}
		}
		
		ITK(POM_class_id_of_class("TableLabel", &pomClassIdLabel))

		if(tableDefTag)
		{
			ITK(AOM_ask_value_tags(tableDefTag, rowPropName, &rowLabelNumber,&rowLabelValues))
			ITK(AOM_ask_value_tags(tableDefTag, colPropName, &colLabelNumber,&colLabelValues))

			if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) ||  (strcmp(item_type, FVE_ParmDefIntTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type ,FVE_ParmDefBoolTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefDateTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type ,FVE_ParmDefStrTYPE) == 0)	||
				(tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  || 
				(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0) ||(tc_strcmp(item_type,FV9ParmValHexTYPE) == 0))
			{
				ITK(AOM_refresh(tableDefTag,TRUE))
				ifail=AOM_set_value_tags(tableDefTag,rowPropName,0,NULL);
				ifail=AOM_set_value_tags(tableDefTag,colPropName,0,NULL);
				ITK(AOM_save(tableDefTag))
				ITK(AOM_refresh(tableDefTag,FALSE))

				//AM__set_application_bypass(TRUE);
				ITK(AOM_lock(revision))
				if(isParmDefObject == TRUE)
				{
					ifail=AOM_set_value_tag(revision,"tableDefinition",NULLTAG);
				}
				if(isFv9ValObject == TRUE)
				{
					ifail=AOM_set_value_tag(revision,"fv9TableDefinition",NULLTAG);
				}
				ITK(AOM_save(revision))
				ITK(AOM_unlock(revision))
				//ITK(AOM_refresh(revision,FALSE))
				//AM__set_application_bypass(FALSE);

				if(rowLabelValues)
					ifail=FV_delete_pom_objects(rowLabelNumber,rowLabelValues);

				if(colLabelValues)
					ifail=FV_delete_pom_objects(colLabelNumber,colLabelValues);

				//recrete cell_labels again
				if(rowPropValues && rowPropName && tc_strlen(rowPropName)> 0)
				{
					ifail=FVE_reCreate_cellsLabels(revision,new_Rcount,rowPropName,rowPropValues);
				}

				if(colPropValues && colPropName && tc_strlen(colPropName)> 0)
				{
					ifail=FVE_reCreate_cellsLabels(revision,new_Colcount,colPropName,colPropValues);
				}
			}
		}//tableDefTag
	} //revision

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}


// Given an array of POM_objects, unload and delete them.
// WARNING! This deletes objects from the database.
// NOTE: this function will fail if any input objects are referenced.
extern int FV_delete_pom_objects(int pomObjCnt, tag_t* pomObjTags)
{
    int         ifail = ITK_ok;
    char*       function_name = "FV_delete_pom_objects";
    tag_t*      unloadTags = NULL;
    int         unloadCnt=0;
    int         tagIdx = 0;
    logical     isLoaded = FALSE;

    TC_write_syslog("Entering %s, deleting %d objects\n", function_name, pomObjCnt);

    if (pomObjTags == NULL)
       ITK(FV_handle_missing_arg_error(function_name, "pomObjTags"))

    for (tagIdx=0; tagIdx<pomObjCnt; tagIdx++)
    {
        ITK(POM_is_loaded(pomObjTags[tagIdx], &isLoaded))
        if (isLoaded)
           ITK(FV_add_unique_tag_to_array(&unloadCnt, &unloadTags, pomObjTags[tagIdx]))
    }

    if (unloadCnt > 0)
    {
       TC_write_syslog("In %s, unloading %d objects\n", function_name, unloadCnt);
       ITK(POM_unload_instances(unloadCnt, unloadTags))
    }

    TC_write_syslog("In %s, deleting %d objects\n", function_name, pomObjCnt);
    ITK(POM_delete_instances(pomObjCnt, pomObjTags))

    TC_write_syslog("Exiting %s\n", function_name);
    FVE_FREE(unloadTags)

    return ifail;
}


// This allocates/reallocates the array and adds the tag to the end of the array.
// Adds tag only if not already in the array.
// I/O argument tagCnt is incremented on exit if tag was added.
// Handles out-of-memory error.
extern int FV_add_unique_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag)
{
    int   ifail = ITK_ok;

    // Ignore a duplicate tag.
    if (FV_find_tag_in_array(*tagCnt, *tagArray, addTag) > -1)
       goto CLEANUP;

    CLEANUP(FV_add_tag_to_array(tagCnt, tagArray, addTag))

CLEANUP:
   return (ifail);
}

// Returns index in array of first tag found. If not found, returns -1.
extern int FV_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag)
{
    int   i = 0;
    int foundIdx = -1;

    if (!tagArray || (tagCnt < 1))
       goto CLEANUP;

    for (i=0; i<tagCnt; i++)
    {
        if (tagArray[i] == tag)
        {
           foundIdx = i;
	   goto CLEANUP;
        }
    }

CLEANUP:
    return foundIdx;
}

/*function to set valid values for sed

*/
int FVE_set_sedValidValues(tag_t rev,char *attr,char **valDomainElName,char **valDomainElVal,char **valDomainElDescr)
{

	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_set_sedValidValues";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	char	item_type[ITEM_type_size_c+1];

	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	tag_t	item				=	NULLTAG;

	TC_write_syslog("\n Enter %s\n", function_name);
	ITK(ITEM_ask_item_of_rev(rev, &item))
	ITK(ITEM_ask_type(item, item_type))

	ITK(AOM_ask_value_tag(rev, attr, &attr_value))
	ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
	ITK(AOM_ask_value_int(table_def,colsPROP, &num_cols))
	ITK(AOM_ask_value_int(table_def,rowsPROP, &num_rows))

	ITK(AOM_ask_value_tags(attr_value,cellsPROP, &num_cells, &cells))

	ITK(AOM_refresh(rev,TRUE))
	ITK(AOM_refresh(table_def,TRUE))

	for(k = 0; k < num_rows; k++)
	{
		if(cells[k] != NULLTAG)
		{
			ITK(AOM_refresh(cells[k],TRUE))
			if(strcmp(item_type, FVE_ParmDefSEDTYPE) == 0)
			{
				ITK(AOM_set_value_string(cells[k], "desc",valDomainElName[k]))
				ITK(AOM_set_value_string(cells[k], valuePROP,valDomainElVal[k]))
				ITK(AOM_set_value_string(cells[k], "fnd0DomainElementDesc",valDomainElVal[k]))
				ITK(AOM_save(cells[k]))
				ITK(AOM_refresh(cells[k],FALSE))
			}
		}
	}
	ITK(AOM_save(table_def))
	ITK(AOM_refresh(table_def,FALSE))
	ITK(AOM_save(rev))
	ITK(AOM_refresh(rev,FALSE))

	FVE_FREE(cells)
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;
}

/*
Function to set multiple values on cells of Min/Max/Initial tables on revision.
*/
int FVE_set_values(tag_t rev,char *propName,char **valArray,int valCnt)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_set_values";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	char	item_type[ITEM_type_size_c+1];

	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	tag_t	item				=	NULLTAG;
	double	val_dbl				=	0.0;
	char	*valueSubstring		=	NULL;
	int		index				=	0;
	char*  indexOfX				=	NULL;

	TC_write_syslog("\n Enter %s\n", function_name);
	if(rev && propName && valArray && valCnt > 0)
	{
		ITK(ITEM_ask_item_of_rev(rev, &item))
		ITK(ITEM_ask_type(item, item_type))

		ITK(AOM_ask_value_tag(rev, propName, &attr_value))
		ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
		ITK(AOM_ask_value_int(table_def,colsPROP, &num_cols))
		ITK(AOM_ask_value_int(table_def,rowsPROP, &num_rows))

		ITK(AOM_ask_value_tags(attr_value,cellsPROP, &num_cells, &cells))

		if(num_cells == valCnt)
		{
			ITK(AOM_refresh(rev,TRUE))
			ITK(AOM_refresh(table_def,TRUE))
			for(k = 0; k < num_cells; k++)
			{
				if(cells[k] && valArray[k])
				{
					ITK(AOM_refresh(cells[k],TRUE))
					if( (tc_strcmp(item_type, FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
					{
						ITK(AOM_set_value_string(cells[k], valuePROP,valArray[k]))
					}
					else if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValDblTYPE) == 0) )
					{
						val_dbl=atof(valArray[k]);
						ITK(AOM_set_value_double(cells[k],valuePROP,val_dbl))
					}
					else if( (tc_strcmp(item_type, FVE_ParmDefIntTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValIntTYPE) == 0))
					{
						ITK(AOM_set_value_int(cells[k],valuePROP,atoi(valArray[k])))
					}
					else if( (tc_strcmp(item_type, FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValHexTYPE) == 0))
					{
						//check if value is with prefix "0x"
						indexOfX=NULL;
						indexOfX=strchr(valArray[k],'x');
						if(indexOfX != NULL)
						{
							index = (int)(indexOfX - valArray[k]);
							valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(valArray[k])+1));
							sprintf(valueSubstring,"%s",&(valArray[k])[index+1]);
							if(valueSubstring)
							{
								ITK(AOM_set_value_string(cells[k], valuePROP,valueSubstring))
							}
							FVE_FREE(valueSubstring)
							index=0;
						}else
						{
							ITK(AOM_set_value_string(cells[k], valuePROP,valArray[k]))
						}
					}
					ITK(AOM_save(cells[k]))
					ITK(AOM_refresh(cells[k],FALSE))
				}
			}//k = 0
			ITK(AOM_save(table_def))
			ITK(AOM_refresh(table_def,FALSE))
			ITK(AOM_save(rev))
			ITK(AOM_refresh(rev,FALSE))
		}//num_cells == valCnt
		FVE_FREE(cells)
	}
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

/*
function to set single value for number of cells of Min/Max/Initial table on revision
*/
int FVE_set_value(tag_t rev,char *attr,char *val)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_set_value";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	char	item_type[ITEM_type_size_c+1];

	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	tag_t	item				=	NULLTAG;
	double	val_dbl				=	0.0;
	char	*valueSubstring		=	NULL;
	int		index				=	0;
	char*  indexOfX				=	NULL;


	TC_write_syslog("\n Enter %s\n", function_name);
	ITK(ITEM_ask_item_of_rev(rev, &item))
	ITK(ITEM_ask_type(item, item_type))

	ITK(AOM_ask_value_tag(rev, attr, &attr_value))
	ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
	ITK(AOM_ask_value_int(table_def,colsPROP, &num_cols))
	ITK(AOM_ask_value_int(table_def,rowsPROP, &num_rows))

	ITK(AOM_ask_value_tags(attr_value,cellsPROP, &num_cells, &cells))

	ITK(AOM_refresh(rev,TRUE))
	ITK(AOM_refresh(table_def,TRUE))
	for(k = 0; k < num_cells; k++)
	{
		if(cells[k] && val && tc_strlen(val)> 0)
		{
			ITK(AOM_refresh(cells[k],TRUE))
			if( (tc_strcmp(item_type, FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
			{
				ITK(AOM_set_value_string(cells[k], valuePROP,val))
			}
			else if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValDblTYPE) == 0) )
			{
				val_dbl=atof(val);
				ITK(AOM_set_value_double(cells[k],valuePROP,val_dbl))
			}
			else if( (tc_strcmp(item_type, FVE_ParmDefIntTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValIntTYPE) == 0))
			{
				ITK(AOM_set_value_int(cells[k],valuePROP,atoi(val)))
			}else if( (tc_strcmp(item_type, FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValHexTYPE) == 0))
			{
				//check if value is with prefix "0x"
				indexOfX=NULL;
				indexOfX=strchr(val,'x');
				if(indexOfX != NULL)
				{
					index = (int)(indexOfX - val);
					valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(val)+1));
					//sprintf(valueSubstring,"%d%s",strlen(initValArray[incrCounter])-(index+1),&(initValArray[incrCounter])[index+1]);
					sprintf(valueSubstring,"%s",&(val)[index+1]);
					if(valueSubstring)
					{
						ITK(AOM_set_value_string(cells[k], valuePROP,valueSubstring))
					}
					FVE_FREE(valueSubstring)
					index=0;
				}else
				{
					ITK(AOM_set_value_string(cells[k], valuePROP,val))
				}
			}

			ITK(AOM_save(cells[k]))
			ITK(AOM_refresh(cells[k],FALSE))
		}
	}
	ITK(AOM_save(table_def))
	ITK(AOM_refresh(table_def,FALSE))
	ITK(AOM_save(rev))
	ITK(AOM_refresh(rev,FALSE))

	FVE_FREE(cells)
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;
}

/*
get the description Name for Valid Values of SED type
*/
int FVE_get_desc_array(tag_t rev, char *attr,char *cellsProp,char *** value_array,int * retCnt)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_get_desc_array";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	char	item_type[ITEM_type_size_c+1];
	char	*cell_value			=	NULL;
	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	tag_t	item				=	NULLTAG;
	int		returnCnt			=	0;


	TC_write_syslog("\n Enter %s\n", function_name);
	if(rev && attr && tc_strlen(attr)> 0 && cellsProp && tc_strlen(cellsProp) > 0)
	{
		ITK(ITEM_ask_item_of_rev(rev, &item))
		ITK(ITEM_ask_type(item, item_type))

		ITK(AOM_ask_value_tag(rev, attr, &attr_value))
		ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
		ITK(AOM_ask_value_int(table_def, colsPROP, &num_cols))
		ITK(AOM_ask_value_int(table_def, rowsPROP, &num_rows))

		ITK(AOM_ask_value_tags(attr_value, cellsPROP, &num_cells, &cells))

		(*value_array) = (char**) MEM_alloc((num_cells) * sizeof(char *));
		for(k = 0; k < num_cells; k++)
		{
			if(strcmp(item_type, FVE_ParmDefSEDTYPE) == 0)
			{
				//ITK(AOM_ask_value_string(cells[k], "desc", &cell_value))
				ITK(AOM_ask_value_string(cells[k], cellsProp, &cell_value))
				if(cell_value && tc_strlen(cell_value)> 0)
				{
					returnCnt++;
					(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_value)+ 1) * sizeof(char));
					strcpy((*value_array)[k], cell_value);
				}
			}
		}
		if(returnCnt == 0)
		{
				(*value_array) = NULL;
		}
		*retCnt=returnCnt;
		FVE_FREE(cells)
	}
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;

}
/*
	Get the Attribute Values for Max , Min and Initial.
*/
int FVE_get_value_arrays(tag_t rev, char *attr,char *** value_array)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_get_value_arrays";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	int		cell_value_int		=	0;
	char	item_type[ITEM_type_size_c+1];
	char	cell_val_int[32]	 = "";
	char	*cell_value			=	NULL;
	char	cell_val_dbl[128]	=	"";

	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	double	cell_value_dbl		=	0.0;
	tag_t	item				=	NULLTAG;
	char	*cell_value_double	=	NULL;


	TC_write_syslog("\n Enter %s\n", function_name);
	ITK(ITEM_ask_item_of_rev(rev, &item))
	ITK(ITEM_ask_type(item, item_type))

	ITK(AOM_ask_value_tag(rev, attr, &attr_value))
	ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
	ITK(AOM_ask_value_int(table_def, colsPROP, &num_cols))
	ITK(AOM_ask_value_int(table_def, rowsPROP, &num_rows))

	ITK(AOM_ask_value_tags(attr_value, cellsPROP, &num_cells, &cells))

	(*value_array) = (char**) MEM_alloc((num_cells) * sizeof(char *));
	for(k = 0; k < num_cells; k++)
	{

		if( (tc_strcmp(item_type, FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) )
		{
			ITK(AOM_ask_value_string(cells[k], valuePROP, &cell_value))
			(*value_array)[k] = cell_value;
		}
		else if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
		{
			ITK(AOM_ask_value_double(cells[k], valuePROP, &cell_value_dbl))
			FVE_truncate_double_values(cell_value_dbl,&cell_value_double);
			sprintf(cell_val_dbl, "%s", cell_value_double);
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_val_dbl) + 1) * sizeof(char));
			strcpy((*value_array)[k], cell_val_dbl);
		}else if((tc_strcmp(item_type, FVE_ParmDefIntTYPE) == 0) ||(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
		{
			ITK(AOM_ask_value_int(cells[k], valuePROP, &cell_value_int))
			sprintf(cell_val_int, "%d", cell_value_int);
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_val_int) + 1) * sizeof(char));
			strcpy((*value_array)[k], cell_val_int);

		}else if( (tc_strcmp(item_type, FVE_ParmDefBCDTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValBCDTYPE) == 0) ||
				  (tc_strcmp(item_type, FVE_ParmDefSEDTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
		{
			ITK(AOM_ask_value_string(cells[k], valuePROP, &cell_value))
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_value)+ 1) * sizeof(char));
			strcpy((*value_array)[k], cell_value);
		}else if( (tc_strcmp(item_type, FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValHexTYPE) == 0))
		{
			ITK(AOM_ask_value_string(cells[k], valuePROP, &cell_value))
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_value) + strlen(HEX) + 1) * sizeof(char));
			strcpy((*value_array)[k], HEX);
			strcat((*value_array)[k], cell_value);
		}
	}

	FVE_FREE(cells)
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;
}

/*
function to set value for string property on object
*/
int FV_set_stringValue_object(tag_t objTag,char *propName,char *propVal)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FV_set_stringValue_object";


	TC_write_syslog("\n Entering %s\n", function_name);

	if(objTag != NULLTAG && propName && tc_strlen(propName)> 0)
	{
		AM__set_application_bypass(TRUE);
		ITK(AOM_refresh(objTag,TRUE))
		if(propVal != NULL && tc_strlen(propVal)> 0)
			ITK(AOM_set_value_string(objTag,propName,propVal))

		ITK(AOM_save(objTag))
		ITK(AOM_refresh(objTag,FALSE))
		AM__set_application_bypass(FALSE);
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

/*
function to set UIF value for Integer property on object
*/
int FV_set_uifValue_object(tag_t objTag,char *propName,char *propVal)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FV_set_uifValue_object";


	TC_write_syslog("\n Entering %s\n", function_name);

	if(objTag != NULLTAG && propName && tc_strlen(propName)> 0)
	{
		AM__set_application_bypass(TRUE);
		ITK(AOM_refresh(objTag,TRUE))
		ITK(AOM_UIF_set_value(objTag, propName,propVal))

		ITK(AOM_save(objTag))
		ITK(AOM_refresh(objTag,FALSE))
		AM__set_application_bypass(FALSE);
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

int FVE_find_rev(char* item_id,	char* rev_id, tag_t* rev)
{
	int ifail = ITK_ok;
	int num = 0;
	tag_t* revs = NULL;
	char** attrs = (char**)MEM_alloc(1*sizeof(char*));
	char** vals = (char**)MEM_alloc(1*sizeof(char*));

	attrs[0] = "item_id";
	vals[0] = item_id;
	ITK(ITEM_find_item_revs_by_key_attributes(1, attrs, vals, rev_id, &num, &revs))
	if(num == 0 || revs == NULL)
	{
		*rev = NULLTAG;
		TC_write_syslog("+++VSEM ERROR+++ Item Revision with id=%s and rev=%s cannot be located.\n", item_id, rev_id);
	}
	else
	{
		*rev = revs[0];
		FVE_FREE(revs)
	}

	FVE_FREE(attrs)
	FVE_FREE(vals)

	return ifail;
}


/*
Get the processes attached to parameter definition revision with relation in context of dictionary.
*/
int FVE_get_related_proces(char *dict_id,char *rev_id, char *parm_id, char *rel_name, int *proc_cnt, char ***proc_names, tag_t **process_tags)
{

	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_get_related_proces";
	int		num_proc_found		=	0;
	int		counter				=	0;
	char	* process_name		=	NULL;
	char*	qry_field_names[4]	=	{RELATION_NAME, DIC_ID, DIC_REV_ID, PARMDEF_ID};
	char*	qry_value_names[4]	=	{"", "", "", ""};
	tag_t	find_proc_qry_tag	=	NULLTAG;
	tag_t	* proc_tags			=	NULL;
	int		allocCounter		=	0;

	TC_write_syslog("\n Entering %s\n", function_name);

	if(dict_id && rev_id && parm_id && rel_name && tc_strlen(dict_id) > 0 && tc_strlen(rev_id)>0 && tc_strlen(parm_id)> 0 && tc_strlen(rel_name)> 0)
	{
		qry_value_names[0] = rel_name;
		qry_value_names[1] = dict_id;
		qry_value_names[2] = rev_id;
		qry_value_names[3] = parm_id;

		ITK(QRY_find(FIND_PROCESS_IN_CONTEXT, &find_proc_qry_tag))
		ITK(QRY_execute(find_proc_qry_tag, 4, qry_field_names, qry_value_names, &num_proc_found,  &proc_tags))

		for(counter = 0; counter < num_proc_found; counter++)
		{
			if(allocCounter ==0)
			{
				(*process_tags) = (tag_t *) MEM_alloc(1 * sizeof(tag_t));
			}else
			{
				(*process_tags) = (tag_t *) MEM_realloc((*process_tags),(allocCounter + 1) * sizeof(tag_t));
			}
			if(proc_tags[counter])
			{
				(*proc_names) = (char **) MEM_realloc((*proc_names), (*proc_cnt + 1) * sizeof(char *));
				ITK(AOM_ask_name(proc_tags[counter], &process_name))
				(*proc_names)[*proc_cnt] = (char *) MEM_alloc ((int)((strlen(process_name) + 1)) * sizeof(char));
				(*process_tags)[(*proc_cnt)]=proc_tags[counter];
				if(process_name && tc_strlen(process_name) > 0)
				{
					strcpy((*proc_names)[(*proc_cnt)], process_name);
				}
				(*proc_cnt)++;
				allocCounter++;
				FVE_FREE(process_name)
			}
		}
		FVE_FREE(proc_tags)
		num_proc_found=0;
	}

	TC_write_syslog("\n Leaving %s\n", function_name);
	return ifail;
}

/*
	Compare the process object attched to paramneter definition with current processes from sample file.
	During update ,if any process object attached to parameter definition didnt exist in sample process file
		           remove the relation between Process object and parameter in context of dictionary.
*/

int FVE_compare_process_basedRelation(struct FVEParmDefInfostruct *parmInfoStr,int counter,tag_t bomLine,char *relName)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_compare_process_basedRelation";
	char	*itemId				=	NULL;
	int		oldProCnt			=	0;
	char	**oldProcNames		=	NULL;
	tag_t	*oldProcessTags		=	NULL;
	int		oldCounter			=	0;
	int		newCounter			=	0;
	logical	matchFound          =   false;
	tag_t   *removeProcTags		=	NULL;
	int		removeProcCounter	=	0;
	int		index				=	0;
	char	*newProcList		=	NULL;
	char	**newProcNames		=	NULL;
	int		newProCnt			=	0;
	static int line_item_id_attr = -1;
	logical	isDictFreez			=	FALSE;

	TC_write_syslog("\n Entering %s\n", function_name);


	//get the name from parmInfoStr based on the relation
	if(relName && tc_strlen(relName)> 0)
	{
		if(tc_strcmp(relName,FVE_SOURCE_RELATION) == 0)
		{
			newProcList=parmInfoStr[counter].src;
		}
		if(tc_strcmp(relName,FVE_SINK_RELATION)==0)
		{
			newProcList=parmInfoStr[counter].snk;
		}
		if(tc_strcmp(relName,FVE_LOCAL_RELATION)==0)
		{
			newProcList=parmInfoStr[counter].local;
		}
		if(tc_strcmp(relName,FVE_SOURCE_SINK_RELATION)==0)
		{
			newProcList=parmInfoStr[counter].srcSnk;
		}

	}

	//get the  new processes seperated by comma
	if(newProcList && tc_strlen(newProcList)> 0)
		ifail=split_the_string(newProcList,COMMA_DELIM,&newProCnt,&newProcNames);

	if(bomLine)
	{
		ITK(BOM_line_look_up_attribute(bomAttr_itemId,&line_item_id_attr))
		ITK(BOM_line_ask_attribute_string(bomLine,line_item_id_attr,&itemId))
	}

	ifail=FVE_get_related_proces(dicId,dicRevId,itemId,relName,&oldProCnt,&oldProcNames,&oldProcessTags);

	//compare old process Name with new Process names
	for(oldCounter=0;oldCounter<oldProCnt;oldCounter++)
	{
		matchFound          =   false;
		for(newCounter=0;newCounter<newProCnt;newCounter++)
		{
			if(oldProcNames[oldCounter] && newProcNames[newCounter] && tc_strlen(oldProcNames[oldCounter])> 0 && tc_strlen(newProcNames[newCounter])> 0)
			{
				if(tc_strcmp(oldProcNames[oldCounter],newProcNames[newCounter]) == 0)
				{
                    
					matchFound =  true;
					break;
				}
			}
		}//newCounter=0
		if(matchFound == true)
		{
			break;
		}else
		{
			if(removeProcCounter == 0)
			{
				//printf("\n Process=%s not found in new file \n",*(oldProcNames[oldCounter]))
				(removeProcTags) = (tag_t *) MEM_alloc(1 * sizeof(tag_t));
			}else
			{
				(removeProcTags) = (tag_t *) MEM_realloc((removeProcTags),(removeProcCounter + 1) * sizeof(tag_t));

			}
			removeProcTags[removeProcCounter]=oldProcessTags[oldCounter];
			removeProcCounter++;
		}
	}//oldCounter=0

    //Remove the relation
    if(isDictionary)
    {
        /* If old param def has same process as mentioned in new process file
           do not add it to new param def rev.
        */

        if(matchFound == true)
        {
            ifail=FVE_get_dictionary_status(dicRevTag,&isDictFreez);
            if(isDictFreez == FALSE)
            {
                for(index=0;index<removeProcCounter;index++)
                {
                    ifail=FVE_remove_process_with_relation(dicRevTag,bomLine,removeProcTags[index],windowDic);
                }
            }else
            {
                fprintf(logfileptr,"\n Dictionary is locked.You cant remove processes.\n");
            }
        }

	}
	if(isECCTProjectRev)
	{
		ifail=FVE_get_dictionary_status(primeDicRevision,&isDictFreez);
		//ifail=FVE_get_dictionary_status(ecctRevTag,&isECCTPrjFreez);

		if(isDictFreez == FALSE)
		{
			for(index=0;index<removeProcCounter;index++)
			{
				ifail=FVE_remove_process_with_relation(primeDicRevision,bomLine,removeProcTags[index],windowPrimeDic);
			}
		}else
		{
			fprintf(logfileptr,"\n Dictionary is locked.You cant remove processes.\n");
		}
		
		/*if(isECCTPrjFreez == FALSE)
		{
			for(index=0;index<removeProcCounter;index++)
			{
				ifail=FVE_remove_process_with_relation(ecctRevTag,bomLine,removeProcTags[index],windowECCTPrj);
			}
		}else
		{
			fprintf(logfileptr,"\n ECCT project is locked.You cant remove processes.\n");
		}
		*/
	}

	TC_write_syslog("\n Leaving %s\n", function_name);
	FVE_FREE(itemId)
	FVE_FREE(oldProcessTags)
	FVE_FREE_ARRAY(oldProcNames,oldProCnt)
	oldProCnt=0;
	FVE_FREE_ARRAY(newProcNames,newProCnt)
	newProCnt=0;
	FVE_FREE(removeProcTags)
	return ifail;
}

/*
function to check if dictionary is released with any status other then "Dictionary Locked" or "ECCT Frozen".
*/
int FVE_get_dictionary_status(tag_t parentDictRev,logical *flag)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FVE_get_dictionary_status";
	int		status_count	=	0;
	int		sCounter		=	0;
	tag_t	*status_list	=	NULL;
	char	*status_name	=	NULL;
	char	*object_id		=	NULL;

	TC_write_syslog("\n Entering %s\n", function_name);
	if(parentDictRev)
	{
		//get the status for ParentDictionaryRev
		ITK(WSOM_ask_object_id_string(parentDictRev,&object_id))
		ITK(AOM_ask_value_tags(parentDictRev,"release_status_list",&status_count,&status_list))
		/* if dictionary not released with any status */
		if(status_count == 0)
		{
			*flag=FALSE;
		}
		for(sCounter=0;sCounter<status_count;sCounter++)
		{
			ITK(AOM_ask_name(status_list[sCounter],&status_name))
			if((strcmp(status_name,DICTN_LOCK_STATUSTYPE) != 0 ) &&
			    (strcmp(status_name,FREEZE_STATUSTYPE) !=0 ))
			{
				*flag=FALSE;
			}
			else
			{
				*flag=TRUE;
			}

			/* release mem for status list */
			FVE_FREE(status_name);
		}
		/* release mem for status list */
		FVE_FREE(status_list);
	}
	TC_write_syslog("\n Leave %s\n", function_name);
	return ifail;
}


/*
Remove the relation between Parameter and Process Object in context of dictionary.
*/
int FVE_remove_process_with_relation(tag_t parentDictRev,tag_t selectedParamDefLine,tag_t objToBeRemoved,tag_t bomWindow)
{
	int		ifail				=	ITK_ok;
	tag_t	attachRootLine		=	NULLTAG;
	int		attach_count		=	0;
	int		iCounter			=	0;
	tag_t	*attachmentLines	=	NULL;
	tag_t	attachedProcessObj	=	NULLTAG;
	char	*type				=	NULL;
	tag_t	propType			=	NULLTAG;
	char	typeName[TCTYPE_name_size_c + 1];

	TC_write_syslog("Enter In function FVE_remove_process_with_relation... \n");

	ITK(AOM_ask_value_tags(selectedParamDefLine,"bl_attachments",&attach_count,&attachmentLines))
	for(iCounter=0;iCounter<attach_count;iCounter++)
	{
		ITK(TCTYPE_ask_object_type(attachmentLines[iCounter],&propType))
		ITK(TCTYPE_ask_name(propType,typeName))
		if(strcmp(typeName, "CfgAbsOccAttachmentLine")==0)
		{
			ITK(AOM_ask_value_tag(attachmentLines[iCounter],"me_cl_parent",&attachRootLine))
			ITK(AOM_ask_value_string(attachmentLines[iCounter],"al_source_type",&type))
			if(strcmp(type, "FVE_ProcessRevision") == 0)
			{
				MEM_free(type);
				type = NULL;
				attachedProcessObj = NULLTAG;
				ITK(AOM_ask_value_tag(attachmentLines[iCounter],"al_object",&attachedProcessObj))
				//if form exist check value on it set or not
				if(attachedProcessObj && objToBeRemoved)
				{
					if(attachedProcessObj == objToBeRemoved)
					{
						ITK(ME_line_remove(attachRootLine,attachmentLines[iCounter]))
						ITK(BOM_save_window(bomWindow))
						break;
					}
				}
			}//type
		}//typeName
	}//iCounter

	TC_write_syslog("Leave function FVE_remove_process_with_relation... \n");
	return ifail;
}


/*
	Search the process object read from parameter definition file in ProcessInfo Structure
	if found , check if process object alreday exist.If not exist create it.
	Add process object to parameter definition incontext of dictionary with given relation.
*/
int FVE_process_object(tag_t parmDefBl,int cntObjects,char **valObjects,char *relName,tag_t inContextRev,tag_t window)
{

	int		ifail				= ITK_ok;
	int		iCounter			=	0;
	int		iPrCounter			=	0;
	int		processObjCount		=	0;
	char	*processName		=	NULL;
	tag_t	*processObjTags		=	NULL;
	tag_t	processObject		=	NULLTAG;
	tag_t	processObjRevTag	=	NULLTAG;
	logical	flag				=	FALSE;
	logical	processObjExistFlag	=	FALSE;
	char	*parmDef_ItemId		=	NULL;
	char	*parmDef_ItemRevId	=	NULL;
	int		oldProCnt			=	0;
	char	**oldProcNames		=	NULL;
	tag_t	*oldProcessTags		=	NULL;
	int		index				=	0;
	char		itemId[ITEM_id_size_c+1] = {'\0'};
	char		rev_id[ITEM_id_size_c + 1] = "";
	tag_t	itemTag	=	NULLTAG;

	TC_write_syslog("Enter function FVE_process_object... \n");
	//from incontextRev get itemid and RevId
	if(inContextRev)
	{
		//swap
		ITK(ITEM_ask_item_of_rev(inContextRev,&itemTag))
		ITK(ITEM_ask_id(itemTag,itemId))
		ITK(ITEM_ask_rev_id(inContextRev,rev_id))

	}
	for(iCounter=0;iCounter<cntObjects;iCounter++)
	{
		if( valObjects[iCounter] != NULL && tc_strlen(valObjects[iCounter])> 0)
		{
			flag=FALSE;
			processObjExistFlag=FALSE;
			for(iPrCounter =0 ;iPrCounter <totalNoOfProcess ;iPrCounter++)
			{
				processName=strProcessInfo[iPrCounter].processName;
				if(processName != NULL && tc_strlen(processName) > 0)
				{
					if( (tc_strcmp(FV_trim_blanks(valObjects[iCounter]),FV_trim_blanks(processName))==0))
					{
						flag=TRUE;
						ifail=FVE_gsdb_find_wso_with_attr("FVE_process","object_name",FV_trim_blanks((valObjects)[iCounter]),&processObjTags,&processObjCount);
						if(processObjCount == 0)
						{
							ifail=FVE_create_processObject(FV_trim_blanks((valObjects)[iCounter]),FV_trim_blanks(strProcessInfo[iPrCounter].processType),FV_trim_blanks(strProcessInfo[iPrCounter].featureName),FV_trim_blanks(strProcessInfo[iPrCounter].taskRate),&processObject);
						}else
						{
							//get the latest revision for processObjTags[0]
							if(processObjTags[0])
							{
								if(relName && tc_strcmp(relName,FVE_SOURCE_RELATION)==0)
								{
									fprintf(logfileptr,"<SOURCE> Process object <%s> \n",(valObjects)[iCounter]);
								}

								if(relName && tc_strcmp(relName,FVE_SINK_RELATION)==0)
								{
									fprintf(logfileptr,"<SINK> Process object <%s> \n",(valObjects)[iCounter]);
								}

								if(relName && tc_strcmp(relName,FVE_LOCAL_RELATION)==0)
								{
									fprintf(logfileptr,"<LOCAL> Process object <%s> \n",(valObjects)[iCounter]);
								}

								if(relName && tc_strcmp(relName,FVE_SOURCE_SINK_RELATION)==0)
								{
									fprintf(logfileptr,"<SOURCE AND SINK> Process object <%s> \n",(valObjects)[iCounter]);
								}

								//before adding any process object , first get the already attached process object with the relation
								if(parmDefBl)
								{
									ITK(AOM_ask_value_string(parmDefBl,bomAttr_itemId,&parmDef_ItemId))
									ITK(AOM_ask_value_string(parmDefBl,bomAttr_itemRevId,&parmDef_ItemRevId))
								}
								
									
								//ifail=FVE_get_related_proces(dicId,dicRevId,parmDef_ItemId,relName,&oldProCnt,&oldProcNames,&oldProcessTags);
								ifail=FVE_get_related_proces(itemId,rev_id,parmDef_ItemId,relName,&oldProCnt,&oldProcNames,&oldProcessTags);
								
								if(oldProCnt > 0)
								{
									for(index=0;index<oldProCnt;index++)
									{
										if(tc_strcmp(FV_trim_blanks(valObjects[iCounter]),FV_trim_blanks(oldProcNames[index])) ==0)
										{
											processObjExistFlag=TRUE;
											break;
										}
									}
								}
								//Free memory
								FVE_FREE_ARRAY(oldProcNames,oldProCnt)
								oldProCnt=0;
								FVE_FREE(oldProcessTags)


								processObjRevTag=NULLTAG;
								// Get the new item revision tag.
								ITK(ITEM_ask_latest_rev(processObjTags[0],&processObjRevTag))
								processObject=processObjRevTag;
								if(processObjExistFlag == FALSE)
								{
									ifail=FVE_add_process_with_relation(inContextRev,parmDefBl,processObject,relName,window);
								}

								if(ifail == ITK_ok)
								{
										if(relName && tc_strcmp(relName,FVE_SOURCE_RELATION)==0)
											fprintf(logfileptr,"Parameter to Process Association with <SOURCE> relation:%s\n","Success");
										if(relName && tc_strcmp(relName,FVE_SINK_RELATION)==0)
											fprintf(logfileptr,"Parameter to Process Association with <SINK> relation:%s\n","Success");
										if(relName && tc_strcmp(relName,FVE_LOCAL_RELATION)==0)
											fprintf(logfileptr,"Parameter to Process Association with <LOCAL> relation:%s\n","Success");
										if(relName && tc_strcmp(relName,FVE_SOURCE_SINK_RELATION)==0)
										 fprintf(logfileptr,"Parameter to Process Association with <SOURCE AND SINK> relation:%s\n","Success");
								}else
								{
										if(relName && tc_strcmp(relName,FVE_SOURCE_RELATION)==0)
											fprintf(logfileptr,"Parameter to Process Association with <SOURCE> relation:%s\n","Failed");
										if(relName && tc_strcmp(relName,FVE_SINK_RELATION)==0)
											fprintf(logfileptr,"Parameter to Process Association with <SINK> relation:%s\n","Failed");
										if(relName && tc_strcmp(relName,FVE_LOCAL_RELATION)==0)
											fprintf(logfileptr,"Parameter to Process Association with <LOCAL> relation:%s\n","Failed");
										if(relName && tc_strcmp(relName,FVE_SOURCE_SINK_RELATION)==0)
											fprintf(logfileptr,"Parameter to Process Association with <SOURCE AND SINK> relation:%s\n","Failed");
								}
								/*else
								{
									printf("\n Process %s alreday attched with relation %s \n",processName,relName);
								}*/
							}
						}
						//free memory for process objects
						FVE_FREE(processObjTags)
						processObjCount=0;
						break;
					}
				}//processName != NULL
				if(	flag == TRUE)
				 break;
			}//for each process
			if(	flag == FALSE)
			{
				if(relName && tc_strcmp(relName,FVE_SOURCE_RELATION)==0)
					fprintf(logfileptr,"<SOURCE> Process object %s does not exist in process definition file\n",(valObjects)[iCounter]);
				if(relName && tc_strcmp(relName,FVE_SINK_RELATION)==0)
					fprintf(logfileptr,"<SINK> Process object %s does not exist in process definition file\n",(valObjects)[iCounter]);
				if(relName && tc_strcmp(relName,FVE_LOCAL_RELATION)==0)
					fprintf(logfileptr,"<LOCAL> Process object %s does not exist in process definition file\n",(valObjects)[iCounter]);
				if(relName && tc_strcmp(relName,FVE_SOURCE_SINK_RELATION)==0)
					fprintf(logfileptr,"<SOURCE AND SINK> Process object %s does not exist in process definition file\n",(valObjects)[iCounter]);
			}
		}//
	}//for each <source> process object
	FVE_FREE_ARRAY(valObjects,cntObjects)
	cntObjects=0;
	FVE_FREE(parmDef_ItemId)
	TC_write_syslog("Leave function FVE_process_object... \n");
	return ifail;

}

/*
Function to get rowlabels and columnLabels
*/
int FVE_get_labels(tag_t revision,char *propName,int *labelCnt, char *** labelNames)
{
	int		ifail				= ITK_ok;
	char	*functionName		=	"FVE_get_labels";
	int		labelNumber			=	0;
	tag_t	*labelTags			=	NULL;
	char	*labelValue			= NULL;
	char	item_type[ITEM_type_size_c+1];
	int		iCounter=0;
	tag_t	item				=	NULLTAG;
	tag_t	tableDefTag			=	NULLTAG;

	TC_write_syslog("Enter function %s\n",functionName);

	if(revision && propName && tc_strlen(propName) > 0)
	{
		ITK(ITEM_ask_item_of_rev(revision, &item))
		ITK(ITEM_ask_type(item, item_type))
		if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) ||  (strcmp(item_type, FVE_ParmDefIntTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefBCDTYPE) == 0) ||
			(tc_strcmp(item_type ,FVE_ParmDefBoolTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefDateTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefHexTYPE) == 0) ||
			(tc_strcmp(item_type ,FVE_ParmDefStrTYPE) == 0))
		{
			ITK(AOM_ask_value_tag(revision,"tableDefinition",&tableDefTag))
			if(tableDefTag)
			{
				ITK(AOM_ask_value_tags(tableDefTag, propName, &labelNumber,&labelTags))
				if(labelNumber > 0 && labelTags)
				{
					for(iCounter=0;iCounter<labelNumber;iCounter++)
					{
						ITK(AOM_ask_value_string(labelTags[iCounter],"label",&labelValue))
						if(labelValue && tc_strlen(labelValue) > 0)
						{
							(*labelNames) = (char **) MEM_realloc((*labelNames), (*labelCnt + 1) * sizeof(char *));
							(*labelNames)[*labelCnt] = (char *) MEM_alloc ((int)((strlen(labelValue) + 1)) * sizeof(char));

							strcpy((*labelNames)[(*labelCnt)], labelValue);
							(*labelCnt)++;
						}
					}//for
				}//labelNumber > 0
			}//tableDefTag
		}//itemType
	}//revision
	FVE_FREE(labelTags);
	labelNumber=0;
	TC_write_syslog("Leave function %s\n",functionName);
	return ifail;

}


/*
bulk upload function that will create Repository structure and Prime Dictionary Structure
*/
int FV_build_project_structure(tag_t ecctProjectRevTag,struct FVEParmDefInfostruct *parmInfoStr,int totalNoOfParameters)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FV_build_project_structure";
	TC_write_syslog("\n Enter function %s",function_name);
	if(ecctProjectRevTag && totalNoOfParameters > 0)
	{
		ecctRevTag=ecctProjectRevTag;
		ITK(ITEM_ask_item_of_rev(ecctRevTag, &ecctItemTag))
		//Create Prime Dictionary Structure
		ifail=FV_create_prime_dic_structure(ecctRevTag,parmInfoStr,totalNoOfParameters);

	}
	TC_write_syslog("\n Leaving function %s",function_name);
	return ifail;
}

/*
Function to create Prime Dictionary Structure
*/
int FV_create_prime_dic_structure(tag_t ecctRevisionTag,struct FVEParmDefInfostruct *parmInfoStr,int totalNoOfParameters)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FV_create_prime_dic_structure";
	int			iParmCounter		=	0;
	tag_t		dummyECCTRevTag		=	NULLTAG;
	tag_t		new_ECCTRevTag		=	NULLTAG;
	tag_t		newECCTItemTag		=	NULLTAG;
	tag_t		dummyPrimeDicRevTag	=	NULLTAG;
	tag_t		newPrimeDicRevTag	=	NULLTAG;
	tag_t		newPrimeDicItemTag	=	NULLTAG;
	tag_t		dictLockedStatusTag	=	NULLTAG;
	
	char		*dicItemIdOnECCTRev	=	NULL;
	char        *dicRevIdOnECCTRev  =   NULL;

    char*       dicTargetTypenames   = {ParmDefRevisionTYPE}; 
    char*       dicTraverseTypenames[2]   = {FVE_ParmGrpsRevisionTYPE, FVE_ParmGrpDefRevisionTYPE};
    tag_t*      dicChildlineTags = NULL;
    int         dicChildlineCnt = 0;

    int         revisePendingCnt = 0;
    tag_t*      revisePendingObjects = NULL;

    char*       ecctReleaseStatus = NULL;
	
	TC_write_syslog("\n Enter function %s",function_name);
	if(ecctRevisionTag && totalNoOfParameters > 0)
	{
		ITK(AOM_ask_value_string(ecctRevisionTag, object_namePROP, &ecctItemName))
		if(ecctItemName && tc_strlen(ecctItemName)> 0)
		{
			//get the value for dicId stored on ECCT Project Revision.If value is null , revise false.
			ITK(AOM_ask_value_string(ecctRevisionTag,FVE_DicIDPROP,&dicItemIdOnECCTRev))
			ITK(AOM_ask_value_string(ecctRevisionTag,"fv9DicRevisionId",&dicRevIdOnECCTRev))
			if(dicItemIdOnECCTRev && tc_strlen(dicItemIdOnECCTRev)> 0 && dicRevIdOnECCTRev && tc_strlen(dicRevIdOnECCTRev)> 0)
			{
				//get the prime dictionary item and revision from ID.
				ITK(FVE_find_rev(dicItemIdOnECCTRev,dicRevIdOnECCTRev, &primeDicRevision))
				if(primeDicRevision == NULLTAG)
				{
					fprintf(stderr,"\nERROR: Prime Dictionary Item with %s does not exist\n",dicItemIdOnECCTRev);
				}else
				{
					ITK(ITEM_ask_item_of_rev(primeDicRevision, &primeDicItem))
					fprintf(logfileptr,"Prime Dictionary Id/Revision: %s%s%s\n",dicItemIdOnECCTRev,"/",dicRevIdOnECCTRev);
					fprintf(logfileptr,"\n");
					isRevise=TRUE;
				}
			}
			if(isRevise == FALSE)
			{
				//create the prime dictionary and set it as a topBomline
				ifail=FV_create_parmDefGroups(PARM_GRP_DEF,ecctItemName,ecuAcronym,Parameter_DictionaryVALUE,&primeDicItem,&primeDicRevision);
				if(primeDicItem && primeDicRevision)
				{
					ITK(ITEM_ask_id(primeDicItem,itemIdForPrimeDic))
					ITK(ITEM_ask_rev_id(primeDicRevision,primeDicRevId))
					fprintf(logfileptr,"Prime Dictionary Id/Revision: %s%s%s\n",itemIdForPrimeDic,"/",primeDicRevId);
					fprintf(logfileptr,"\n");
					//set the value of prime dicId on ECCT Project Revision.
					AM__set_application_bypass(TRUE);
					ITK(AOM_refresh(ecctRevisionTag,TRUE))
					//ITK(AOM_lock(ecctRevisionTag))
					if(itemIdForPrimeDic && tc_strlen(itemIdForPrimeDic) > 0)
					{
						ITK(AOM_set_value_string(ecctRevisionTag,FVE_DicIDPROP,itemIdForPrimeDic))
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
					if(primeDicRevId && tc_strlen(primeDicRevId)> 0)
					{
						ITK(AOM_set_value_string(ecctRevisionTag,"fv9DicRevisionId",primeDicRevId))
						if(ifail != ITK_ok)
							ifail=ITK_ok;
					}
					ITK(AOM_set_value_string(ecctRevisionTag,FVE_DicIDPROP,itemIdForPrimeDic))
					if(ifail != ITK_ok)
						ifail=ITK_ok;
					ITK(AOM_save(ecctRevisionTag))
					ITK(AOM_refresh(ecctRevisionTag,FALSE))
					AM__set_application_bypass(FALSE);
					
					/*
					   Prime Dictionary should be set in "IN-CONTEXT" mode because "Process Object/s" get attach any time during lifecycle of dictionary.
					   For ECCT project i.e. for repository structure no question of "process object/s" .so for this do not set top bomline in "IN-CONTEXT" mode.
					
					*/
					//create precise Assembly structure for Repository Structure .
					ifail=FV_createPreciseStructure(ecctItemTag,ecctRevTag,&topBlECCTPrj,&windowECCTPrj,FALSE);
					
					//create precise Assembly structure for Prime Dictionary .Get the BVR of prime dictionary rev
					ifail=FV_createPreciseStructure(primeDicItem,primeDicRevision,&topBlPrimeDic,&windowPrimeDic,TRUE);
				}
			}else
			{
				//get the bomline tag for ECCT Rev
				//ifail=FV_get_set_window_fromRev(ecctRevTag,&windowECCTPrj,&topBlECCTPrj);
				//get the bomline tag for Prime Dictionary Revision
				//ifail=FV_get_set_window_fromRev(primeDicRevision,&windowPrimeDic,&topBlPrimeDic);
				
				//Change management
				/*Revise the prime dictionary */
				dummyPrimeDicRevTag=primeDicRevision;
				AM__set_application_bypass(TRUE);
				ITK(AOM_refresh(dummyPrimeDicRevTag,TRUE))
				//revise dictionary revision
				ITK(ITEM_copy_rev(dummyPrimeDicRevTag,NULL,&newPrimeDicRevTag))
				if(ifail== ITK_ok && newPrimeDicRevTag)
				{
					ITK(ITEM_ask_item_of_rev(newPrimeDicRevTag,&newPrimeDicItemTag))
					primeDicItem=newPrimeDicItemTag;
					TC_write_syslog("\n In %s: Revised Prime Dictionary",function_name);
					primeDicRevision = newPrimeDicRevTag;
					
					//get the itemId and rev id for revised prime dictionary
					ITK(ITEM_ask_id(primeDicItem,itemIdForPrimeDic))
					ITK(ITEM_ask_rev_id(primeDicRevision,primeDicRevId))
				}
				
				ITK(AOM_refresh(dummyPrimeDicRevTag,FALSE))
				AM__set_application_bypass(FALSE);

				/*Revise the Repository Structure if released */
                ITK(FV_ask_release_status(ecctRevTag, &ecctReleaseStatus))
                if(ecctReleaseStatus != NULL)
                {
				    dummyECCTRevTag=ecctRevTag;
				    AM__set_application_bypass(TRUE);
				    ITK(AOM_refresh(dummyECCTRevTag,TRUE))
				    ITK(ITEM_copy_rev(dummyECCTRevTag,NULL,&new_ECCTRevTag))
				    if(ifail== ITK_ok && new_ECCTRevTag)
				    {
					    ITK(ITEM_ask_item_of_rev(new_ECCTRevTag,&newECCTItemTag))
					    ecctItemTag=newECCTItemTag;
					    TC_write_syslog("\n In %s: Revised Repository Structure",function_name);
					    ecctRevTag = new_ECCTRevTag;
				    }
    				
				    ITK(AOM_refresh(dummyECCTRevTag,FALSE))
				    AM__set_application_bypass(FALSE);
                }

			    //set the value of prime dictionary revision Id on ECCT Project Revision.
			    AM__set_application_bypass(TRUE);
			    //ITK(AOM_lock(ecctRevTag))
			    ITK(AOM_refresh(ecctRevTag,TRUE))
			    if(itemIdForPrimeDic && tc_strlen(itemIdForPrimeDic)> 0 && primeDicRevId && tc_strlen(primeDicRevId)> 0)
			    {
				    //fprintf(logfileptr,"Prime Dictionary Id/Revision: %s%s%s\n",itemIdForPrimeDic,"/",primeDicRevId);
				    ITK(AOM_set_value_string(ecctRevTag,"fv9DicRevisionId",primeDicRevId))
				    if(ifail != ITK_ok)
					    ifail=ITK_ok;
			    }
			    ITK(AOM_save(ecctRevTag))
			    ITK(AOM_refresh(ecctRevTag,FALSE))
			    AM__set_application_bypass(FALSE);
				
				//set this newly revision in a structure
				if(ecctItemTag && ecctRevTag)
				{
					ifail=FV_createPreciseStructure(ecctItemTag,ecctRevTag,&topBlECCTPrj,&windowECCTPrj,FALSE);
				}

				//set this newly revision in a structure
				if(primeDicItem && primeDicRevision)
				{
					ifail=FV_createPreciseStructure(primeDicItem,primeDicRevision,&topBlPrimeDic,&windowPrimeDic,TRUE);
				}
			}

			if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,ALL_MODE) == 0))
			{
				ifail=FVE_getProcessModeOnly(strProcessInfo,totalNoOfProcess);
			}
			if(totalNoOfParameters > 0)
			{
				fprintf(logfileptr,"Start Processing Parameter Definitions \n");
				fprintf(logfileptr,"\n");
			}

            // Remove parameters use case handled starts.
            if(isRevise)
            {
                if( ( mode != NULL ) &&
                ( tc_strlen(mode) > 0 ) &&
                ( tc_strcmp(mode, PROCESS_MODE) != 0) )
                {
                    /*  First, check if param present in current dictionary structure is
                        present in csv(struct) file.
                        If not present, remove it from dictionary structure.
                    */

                    ifail = FVE_DeleteLineFromBVRStructure(parmInfoStr, topBlPrimeDic, windowPrimeDic);

                }
            }

            // Gather all childlines of dictionary 
            ITK(FV_gather_child_bomlines(topBlPrimeDic, FV_ALL_LEVELS, FV_LEVEL_ZERO,
                1, &dicTargetTypenames, 2, &dicTraverseTypenames,
                FV_UNIQUE_VALUES, 0, &dicChildlineCnt, &dicChildlineTags))

			for(iParmCounter=0;iParmCounter<totalNoOfParameters;iParmCounter++)
			{
				if(isRevise == FALSE)
				{
					ifail=FVE_create_operations(parmInfoStr,iParmCounter, TRUE, 0, NULL);
				}else
				{
                    ifail=FVE_update_operations(parmInfoStr,iParmCounter, dicChildlineCnt, dicChildlineTags, &revisePendingCnt, &revisePendingObjects);
				}
				fprintf(logfileptr,"\n");
			}//for loop
			
			//start for sync ECCT project with revised dictionary
			CLEANUP(FV_sync_proj_with_dict(topBlPrimeDic,topBlECCTPrj,windowECCTPrj,TRUE));

            if(revisePendingCnt > 0 && revisePendingObjects)
            {
                int indx = 0;
                tag_t dicLockedStatusTag = NULLTAG;
                for(indx = 0; indx < revisePendingCnt; indx++)
                {
                    ITK(FV_set_object_status(revisePendingObjects[indx],DICTN_LOCK_STATUSTYPE,TRUE,&dicLockedStatusTag))
                }
            }
			
			fprintf(logfileptr,"\n");
			fprintf(logfileptr,"Completed Processing Parameter Definitions \n");
			printf("\nCompleted Processing Parameter Definitions.\n");
			fprintf(logfileptr,"\n");
			if( (mode != NULL) && (tc_strlen(mode) > 0) &&  ( tc_strcmp(mode,ALL_MODE) == 0))
			{
				fprintf(logfileptr,"\n");
				fprintf(logfileptr,"Total Count Of Processes: %d\n",totalNoOfProcess);

				fprintf(logfileptr,"Successfully Processed Processes: %d\n",successCntProcesses);
				fprintf(logfileptr,"Failure Count Processes: %d\n",failureCntProcesses);
				fprintf(logfileptr,"\n");
			}
			fprintf(logfileptr,"Total Count Of Parameters: %d\n",totalNoOfParameters);
			fprintf(logfileptr,"Successfully Processed Parameters: %d\n",successCntParameter);
			fprintf(logfileptr,"Failure Count Parameters: %d\n",failureCntParameter);
			fprintf(logfileptr,"\n");
			fprintf(logfileptr,"\n");

			if(logFilePtrFailure)
			{
				fprintf(logFilePtrFailure,"\n");
				fprintf(logFilePtrFailure,"\n");
				fprintf(logFilePtrFailure,"Total Count Of Parameters: %d\n",totalNoOfParameters);
				fprintf(logFilePtrFailure,"Successfully Processed Parameters: %d\n",successCntParameter);
				fprintf(logFilePtrFailure,"Failure Count Parameters: %d\n",failureCntParameter);
				fprintf(logFilePtrFailure,"\n");
				fprintf(logFilePtrFailure,"\n");
			}
		}//revise true
		
		//released Prime Dictionary Revision and ECCT Project Revision
		ITK(FV_set_object_status(primeDicRevision,DICTN_LOCK_STATUSTYPE,TRUE,&dictLockedStatusTag))
        
        // Release only when released ECCT Project is sent for update.
        if(ecctReleaseStatus != NULL)
        {
		    ITK(FV_set_object_status(ecctRevTag,DICTN_LOCK_STATUSTYPE,TRUE,&dictLockedStatusTag))
        }
		
	}//ecctRevisionTag
	TC_write_syslog("\n Leaving function %s",function_name);
CLEANUP:
    FVE_FREE(ecctReleaseStatus)
    FVE_FREE(revisePendingObjects)
	return ifail;
}

int FV_create_parameter_usage_instance(char* objectType, tag_t refObj, char* refPropName, tag_t refObjRev,
                                        char* refRevPropName, tag_t *usgItemRev)
{
    int     ifail = 0;
	char	*function_name="FV_create_parameter_usage_instance";
    char*   usgItemId = NULL;
    char*   revId = NULL;
    char*   dicLineObjRevName = NULL;
    tag_t   usgItem = NULLTAG;
	tag_t   tNewItemRev =NULLTAG;

    TC_write_syslog("\n Enter function %s",function_name);
	CLEANUP(AOM_ask_value_string(refObj, object_namePROP, &dicLineObjRevName))
    //CLEANUP(ITEM_create_item (usgItemId, dicLineObjRevName,objectType, revId, &usgItem, usgItemRev))//Deprecated
	CLEANUP(FV_ITEM_create_item(usgItemId, dicLineObjRevName,objectType, revId, &usgItem, &tNewItemRev))
	usgItem=&tNewItemRev;
    CLEANUP(AOM_save_with_extensions(usgItem))
	CLEANUP(AOM_refresh(usgItem, true))
    CLEANUP(AOM_set_value_tag(usgItem, refPropName, refObj))
    CLEANUP(AOM_save(usgItem))
	CLEANUP(AOM_refresh(usgItem, false))
    if(refObjRev)
    {
	     CLEANUP(AOM_refresh(*usgItemRev, true))
         CLEANUP(AOM_set_value_tag(*usgItemRev, refRevPropName, refObjRev))
         CLEANUP(AOM_save(*usgItemRev))
	     CLEANUP(AOM_refresh(*usgItemRev, false))
    }
    
	TC_write_syslog("\n Leaving function %s",function_name);

CLEANUP:
    FVE_FREE(dicLineObjRevName)

    return ifail;
}

// Given an input string and a delimiter string,
// parse the input string and return an array of strings.
// NOTE: This does NOT use strtok, it uses strstr.
//       The match is done on the *entire* input string.
// Values for input arg trim_blanks...
//  - FV_TRIM_BLANKS: leading and trailing blanks are trimmed from returned strings.
//  - FV_NO_TRIM: blanks are not trimmed
extern int FV_parse_string_with_string(char* targetString, const char* delimiterString,
	                               int* stringCnt, char*** stringArray)
{
    int     ifail = ITK_ok;
    char*   foundString = NULL;
    char*   parsedStr = NULL;
    unsigned int     delimiterLen = 0;

   // This is a recursive function. Do NOT initialize returned values.

   if ((targetString == NULL) || (delimiterString == NULL))
      goto CLEANUP;

   if (tc_strlen(targetString) == 0)
      goto CLEANUP;

   delimiterLen = tc_strlen(delimiterString);
   if (delimiterLen == 0)
      goto CLEANUP;

   foundString = tc_strstr(targetString, delimiterString);

   // If no delimiter found, add string tail to array. 
   if (foundString == NULL)
   {
      CLEANUP(FV_copy_string_to_array(stringCnt, stringArray, targetString)) 
   }
   else
   {
      CLEANUP(FV_strndup(targetString, &parsedStr, foundString-targetString))
      CLEANUP(FV_add_string_pointer_to_array(stringCnt, stringArray, parsedStr)) 
      parsedStr = NULL;

      // Recurse if there's more string beyond the delimiter string.
      if (tc_strlen(foundString) > delimiterLen)
         CLEANUP(FV_parse_string_with_string(foundString+delimiterLen, delimiterString, stringCnt, stringArray))
   }

CLEANUP:

    return (ifail);
}

// Add a copy of a string to an array.
// This allocates/reallocates the input/output array -and- allocates the added array element string.
// I/O argument stringCnt is incremented on exit.
// Handles out-of-memory error.
extern int FV_copy_string_to_array(int* stringCnt, char*** stringArray, char* addString)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_copy_string_to_array";

    // Do not initialize stringArray. It can be extended (reallocated).

   // Allocate or reallocate the array.
   *stringArray = MEM_realloc(*stringArray, sizeof(char*) * (*stringCnt+1));

   // Duplicate the string in the next element of the array.
   if (*stringArray != NULL)
   {
      CLEANUP(FV_strdup(addString, &((*stringArray)[*stringCnt])))
      (*stringCnt)++;
   }
   else
   {
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, FV_int_to_static_string(*stringCnt), function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

CLEANUP:

   return (ifail);
}

// Allocate a buffer and copy a null-terminated string which can be freed using a Teamcenter MEM_ api.
// Handles out-of-memory error.
// The caller is responsible for freeing returned outputString with MEM_free(). 
//
// IMPORTANT: Use this function instead of tc_strdup().
// tc_strdup() is just a wrapper around C strdup() and the string it returns must deallocated using the C free() function.
// (This is not documented anywhere - learned by trial and error.)
//
extern int FV_strdup(const char* inputString, char** outputString)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_strdup";

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   *outputString = MEM_alloc(sizeof(char)*(tc_strlen(inputString)+1));

   if (*outputString != NULL)
   {
      tc_strcpy(*outputString, inputString);
   }
   else
   {
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, FV_int_to_static_string(tc_strlen(inputString)+1), function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}

// Allocate a buffer and copy a string which can be freed using a Teamcenter MEM_ api.
// String does not need to be null-terminated. Input arg charCnt determines how many chars are copied.
// This function appends a NULL terminator if not present in the copied string.
// Handles out-of-memory error.
// The caller is responsible for freeing returned outputString with MEM_free(). 
extern int FV_strndup(const char* inputString, char** outputString, int charCnt)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_strndup";

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   if (inputString[charCnt-1] != '\0')
      *outputString = MEM_alloc(sizeof(char)*(charCnt+1));
   else
      *outputString = MEM_alloc(sizeof(char)*charCnt);

   if (*outputString != NULL)
   {
      if (inputString[charCnt-1] != '\0')
      {
         tc_strncpy(*outputString, inputString, charCnt);
         (*outputString)[charCnt] = '\0';
      }
      else
      {
         tc_strcpy(*outputString, inputString);
      }
   }
   else
   {
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, FV_int_to_static_string(charCnt+1), function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}

// Convert an integer to a string and return the string.
// NOTE: The returned string is stored in static memory.
//       Use it immediately and do NOT free it.
extern char* FV_int_to_static_string(int intValue)
{
   static char* intString = NULL;

   // Allocate the static string only once to max integer length.
   if (intString == NULL)
      intString = MEM_alloc(FV_INTEGER_LEN+1); 

   sprintf(intString, "%d", intValue);

   return intString;
}

// Add a string pointer to an array. This does NOT allocate memory for the added element string.
// This allocates/reallocates the input/output array.
// I/O argument stringCnt is incremented on exit.
// Handles out-of-memory error.
extern int FV_add_string_pointer_to_array(int* stringCnt, char*** stringArray, char* addString)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_add_string_pointer_to_array";

    // Do not initialize stringArray. It can be extended (reallocated).

   // Allocate or reallocate the array.
   *stringArray = MEM_realloc(*stringArray, sizeof(char*) * (*stringCnt+1));

   // Add the string in the next element of the array.
   if (*stringArray != NULL)
   {
      (*stringArray)[*stringCnt] = addString;
      (*stringCnt)++;
   }
   else
   {
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, FV_int_to_static_string(*stringCnt), function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}


/*
Function to check if value is with prefic "0x".
*/
int fve_check_param_type(char *value,char *structureOfdata,char **parmType)
{
	int		ifail			= ITK_ok;
	char	*function_name = "fve_check_param_type";
	int		valueCnt	=	0;
	char	**valueArray	=	NULL;
	int		dummyCnt	=	0;
	char	**dummyValArray		=	NULL;
	char	*semiColonDelimExist	=	NULL;
	char	*commaDelimExist		=	NULL;
	int		iCounter			=	0;
	char *indexFirstX=NULL;
	char line_starts_with[128] = "";
	int	index=0;
	char *valueStr		=	NULL;
    int  lengthBeforeDot = 0;
    int  lengthAfterDot = 0;

	if(structureOfdata && tc_strlen(structureOfdata)> 0 && value && tc_strlen(value)> 0)
	{
		if( tc_strcmp(structureOfdata,ScalarInfo) == 0)
		{
			valueCnt=1;
			valueArray = (char **)MEM_alloc( 1 * sizeof(char *));
			valueArray[0] = (char *)MEM_alloc( (strlen(value) + 1) * sizeof(char ));
			strcpy(valueArray[0],value);
		}else if(tc_strcmp(structureOfdata,Lookup1DInfo) == 0)
		{
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(value),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(value),COMMA_DELIM,&valueCnt,&valueArray);
				commaDelimExist=NULL;
			}else
			{
				split_the_string(FV_trim_invalidChars(value),"' '",&valueCnt,&valueArray);
			}

		}else if(tc_strcmp(structureOfdata,Lookup2DInfo) == 0)
		{
			semiColonDelimExist=strstr(FV_trim_blanks(value),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_blanks(value),SEMICOLON_DELIM,&dummyCnt,&dummyValArray);
				semiColonDelimExist=NULL;
				if(dummyValArray && dummyCnt> 0)
				{
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),COMMA_DELIM,&valueCnt,&valueArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),"' '",&valueCnt,&valueArray);
						}
					}
				}
			}else
			{
				//Check : if 2d lookup and initial string didnt contains semicolon , its mean its single value
				valueCnt=1;
				valueArray = (char **)MEM_alloc( 1 * sizeof(char *));
				valueArray[0] = (char *)MEM_alloc( (strlen(value) + 1) * sizeof(char ));
				strcpy(valueArray[0],value);
			}
		}else if(tc_strcmp(structureOfdata,Array1DInfo) == 0)
		{
			//check which delimiter exist in CSV file for  initial values.either space or comma.
			commaDelimExist=strstr(FV_trim_blanks(value),COMMA_DELIM);
			if(commaDelimExist != NULL)
			{
				split_the_string(FV_trim_invalidChars(value),COMMA_DELIM,&valueCnt,&valueArray);
			}else
			{
				split_the_string(FV_trim_invalidChars(value),"' '",&valueCnt,&valueArray);
			}
		}else if(tc_strcmp(structureOfdata,Array2DInfo) == 0)
		{
			semiColonDelimExist=strstr(FV_trim_blanks(value),SEMICOLON_DELIM);
			if(semiColonDelimExist)
			{
				split_the_string(FV_trim_blanks(value),SEMICOLON_DELIM,&dummyCnt,&dummyValArray);
				semiColonDelimExist=NULL;
				if(dummyValArray && dummyCnt> 0)
				{
					//store this info in initValArrayCnt,&initValArray
					for(iCounter=0;iCounter<dummyCnt;iCounter++)
					{
						commaDelimExist=strstr(FV_trim_blanks(dummyValArray[iCounter]),COMMA_DELIM);
						if(commaDelimExist)
						{
							split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),COMMA_DELIM,&valueCnt,&valueArray);
							commaDelimExist=NULL;
						}else
						{
							split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),"' '",&valueCnt,&valueArray);
						}
					}
				}
			}else
			{
				valueCnt=1;
				valueArray = (char **)MEM_alloc( 1 * sizeof(char *));
				valueArray[0] = (char *)MEM_alloc( (strlen(value) + 1) * sizeof(char ));
				strcpy(valueArray[0],value);
			}
		}//array2Dinfo

		//check if any value is starting with prefix "0x"
		if(valueArray && valueCnt > 0)
		{
			for(iCounter=0;iCounter<valueCnt;iCounter++)
			{
				valueStr = (char *) MEM_alloc((int)(strlen(FV_trim_blanks(valueArray[iCounter])) + 1) * sizeof(char));
				tc_strcpy(valueStr,FV_trim_blanks(valueArray[iCounter]));
				//get the first index of x from the string
				indexFirstX=strchr(valueStr,'x');
				index = (int)(indexFirstX - valueStr);
				sprintf(line_starts_with,"%.*s",(index+1)-0,&valueStr[0]);
				index=0;
				if(tc_strcmp(line_starts_with,"0x") == 0)
				{
					ITK(FV_strdup(FVE_ParmDefHexTYPE, parmType))
					break;
				}
                else
                {
                    ifail=FVE_get_precision(FV_trim_blanks(valueStr),&lengthBeforeDot,&lengthAfterDot);
					if(lengthAfterDot > 0)
					{
						ITK(FV_strdup(FVE_ParmDefDblTYPE, parmType))
					    break;
					}
                }
				FVE_FREE(valueStr)
                lengthBeforeDot = 0;
                lengthAfterDot = 0;
			}//for
		}//if
	}

	FVE_FREE_ARRAY(valueArray,valueCnt)
	valueCnt	=	0;
	FVE_FREE_ARRAY(dummyValArray,dummyCnt)
	dummyCnt=0;

	return ifail;
}


/****************************************************************************/
/* Function Name :    fve_Get_Precision_Value                               */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description :   

/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  04/17/2013       Nikhil Patil           Initial Creation              */
/****************************************************************************/
int fve_Get_Precision_Value(char *value,char *structureOfdata,int* iPrecisionValue)
{
    int		ifail			= ITK_ok;
    char	*function_name = "fve_check_param_type";
    int		valueCnt	=	0;
    char	**valueArray	=	NULL;
    int		dummyCnt	=	0;
    char	**dummyValArray		=	NULL;
    char	*semiColonDelimExist	=	NULL;
    char	*commaDelimExist		=	NULL;
    int		iCounter			=	0;
    char *valueStr		=	NULL;
    int  lengthBeforeDot = 0;
    int  iCurrent_lengthAfterDot = 0;

    if(structureOfdata && tc_strlen(structureOfdata)> 0 && value && tc_strlen(value)> 0)
    {
        if( tc_strcmp(structureOfdata,ScalarInfo) == 0)
        {
            valueCnt=1;
            valueArray = (char **)MEM_alloc( 1 * sizeof(char *));
            valueArray[0] = (char *)MEM_alloc( (strlen(value) + 1) * sizeof(char ));
            strcpy(valueArray[0],value);
        }else if(tc_strcmp(structureOfdata,Lookup1DInfo) == 0)
        {
            //check which delimiter exist in CSV file for  initial values.either space or comma.
            commaDelimExist=strstr(FV_trim_blanks(value),COMMA_DELIM);
            if(commaDelimExist != NULL)
            {
                split_the_string(FV_trim_invalidChars(value),COMMA_DELIM,&valueCnt,&valueArray);
                commaDelimExist=NULL;
            }else
            {
                split_the_string(FV_trim_invalidChars(value),"' '",&valueCnt,&valueArray);
            }

        }else if(tc_strcmp(structureOfdata,Lookup2DInfo) == 0)
        {
            semiColonDelimExist=strstr(FV_trim_blanks(value),SEMICOLON_DELIM);
            if(semiColonDelimExist)
            {
                split_the_string(FV_trim_blanks(value),SEMICOLON_DELIM,&dummyCnt,&dummyValArray);
                semiColonDelimExist=NULL;
                if(dummyValArray && dummyCnt> 0)
                {
                    //store this info in initValArrayCnt,&initValArray
                    for(iCounter=0;iCounter<dummyCnt;iCounter++)
                    {
                        commaDelimExist=strstr(FV_trim_blanks(dummyValArray[iCounter]),COMMA_DELIM);
                        if(commaDelimExist)
                        {
                            split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),COMMA_DELIM,&valueCnt,&valueArray);
                            commaDelimExist=NULL;
                        }else
                        {
                            split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),"' '",&valueCnt,&valueArray);
                        }
                    }
                }
            }else
            {
                //Check : if 2d lookup and initial string didnt contains semicolon , its mean its single value
                valueCnt=1;
                valueArray = (char **)MEM_alloc( 1 * sizeof(char *));
                valueArray[0] = (char *)MEM_alloc( (strlen(value) + 1) * sizeof(char ));
                strcpy(valueArray[0],value);
            }
        }else if(tc_strcmp(structureOfdata,Array1DInfo) == 0)
        {
            //check which delimiter exist in CSV file for  initial values.either space or comma.
            commaDelimExist=strstr(FV_trim_blanks(value),COMMA_DELIM);
            if(commaDelimExist != NULL)
            {
                split_the_string(FV_trim_invalidChars(value),COMMA_DELIM,&valueCnt,&valueArray);
            }else
            {
                split_the_string(FV_trim_invalidChars(value),"' '",&valueCnt,&valueArray);
            }
        }else if(tc_strcmp(structureOfdata,Array2DInfo) == 0)
        {
            semiColonDelimExist=strstr(FV_trim_blanks(value),SEMICOLON_DELIM);
            if(semiColonDelimExist)
            {
                split_the_string(FV_trim_blanks(value),SEMICOLON_DELIM,&dummyCnt,&dummyValArray);
                semiColonDelimExist=NULL;
                if(dummyValArray && dummyCnt> 0)
                {
                    //store this info in initValArrayCnt,&initValArray
                    for(iCounter=0;iCounter<dummyCnt;iCounter++)
                    {
                        commaDelimExist=strstr(FV_trim_blanks(dummyValArray[iCounter]),COMMA_DELIM);
                        if(commaDelimExist)
                        {
                            split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),COMMA_DELIM,&valueCnt,&valueArray);
                            commaDelimExist=NULL;
                        }else
                        {
                            split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),"' '",&valueCnt,&valueArray);
                        }
                    }
                }
            }else
            {
                valueCnt=1;
                valueArray = (char **)MEM_alloc( 1 * sizeof(char *));
                valueArray[0] = (char *)MEM_alloc( (strlen(value) + 1) * sizeof(char ));
                strcpy(valueArray[0],value);
            }
        }//array2Dinfo

        //check if any value is starting with prefix "0x"
        if(valueArray && valueCnt > 0)
        {
            for(iCounter=0;iCounter<valueCnt;iCounter++)
            {
                iCurrent_lengthAfterDot  =   0;

                valueStr = (char *) MEM_alloc((int)(strlen(FV_trim_blanks(valueArray[iCounter])) + 1) * sizeof(char));
                tc_strcpy(valueStr,FV_trim_blanks(valueArray[iCounter]));

                // Get precision value.
                ifail=FVE_get_precision(valueStr,&lengthBeforeDot,&iCurrent_lengthAfterDot);

                if( iCurrent_lengthAfterDot == 0 )
                {
                    // No precision for current value.
                    continue;
                }

                if( iCurrent_lengthAfterDot > *iPrecisionValue )
                {
                    *iPrecisionValue =   iCurrent_lengthAfterDot;
                }

                /*

                //get the first index of x from the string
                indexFirstX=strchr(valueStr,'x');
                index = (int)(indexFirstX - valueStr);
                sprintf(line_starts_with,"%.*s",(index+1)-0,&valueStr[0]);
                index=0;
                if(tc_strcmp(line_starts_with,"0x") == 0)
                {
                    //ITK(FV_strdup(FVE_ParmDefHexTYPE, parmType))
                    break;
                }
                else
                {
                    ifail=FVE_get_precision(FV_trim_blanks(valueStr),&lengthBeforeDot,&lengthAfterDot);
                    if(lengthAfterDot > 0)
                    {
                        //ITK(FV_strdup(FVE_ParmDefDblTYPE, parmType))
                        break;
                    }
                }
                */

                FVE_FREE(valueStr)
                lengthBeforeDot = 0;
                //iCurrent_lengthAfterDot = 0;
            }//for
        }//if
    }

    FVE_FREE_ARRAY(valueArray,valueCnt)
    valueCnt	=	0;
    FVE_FREE_ARRAY(dummyValArray,dummyCnt)
    dummyCnt=0;

    return ifail;
}

// Add a string to a string.
// This allocates/reallocates the input/output string and concatenates input addString to it.
extern int FV_strcat(char** string, char* addString)
{
   int   ifail = ITK_ok;
    
	if ((*string) == NULL)
	{
		// Since the string is empty use mem alloc
		(*string) = (char *)MEM_alloc((int)(tc_strlen(addString)+1)*sizeof(char) );
		 tc_strcpy ((*string), addString);
		 tc_strcat ((*string), '\0');
	}
	else
	{
		// Reallocate the string
		(*string) = MEM_realloc((*string), sizeof(char) * ( ((int) (tc_strlen (*string))) + ((int) (tc_strlen (addString))) + 1 ));

		tc_strcat ((*string), addString);
		tc_strcat ((*string), '\0');
	}

   return (ifail);
}

// Function to update Conf Grou pon ECCT Project & Parameter Dictionary
int FVE_update_conf_group_on_update(char* oldSectionVal, char* newSectionVal)
{
    int    ifail = ITK_ok;

    if(newSectionVal != NULL && tc_strlen(newSectionVal) > 0)
    {
        if(primeDicRevision != NULLTAG)
        {
            CLEANUP(AOM_refresh(primeDicRevision, TRUE))
            CLEANUP(FV_check_set_value_string_at(primeDicRevision, fv9PartTypeListPROP, newSectionVal))
            CLEANUP(AOM_refresh(primeDicRevision, FALSE))
        }
        else
        {
            CLEANUP(AOM_refresh(dicRevTag, TRUE))
            CLEANUP(FV_check_set_value_string_at(dicRevTag, fv9PartTypeListPROP, newSectionVal))
            CLEANUP(AOM_refresh(dicRevTag, FALSE))
        }
    }
    if(oldSectionVal != NULL && tc_strlen(oldSectionVal) > 0 && newSectionVal != NULL && tc_strlen(newSectionVal) > 0
        && tc_strcmp(oldSectionVal, newSectionVal) != 0)
    {
        //FV_check_conf_grp_exist()
    }

CLEANUP:

    return ifail;
}

/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                  */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  02/25/2013      	Kalyan	              Initial Creation              */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;


    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );        
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        printf( "ERROR: Invalid format for password file '%s'\n", passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);

    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");        
        return !ITK_ok ;
    }

    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;

    return ifail;
}


/****************************************************************************/
/* Function Name :    deleteLineFromBVRStructure                               */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description :   1.  Traverse topline from window.
/*                      2.  Check if current bomline exists in param structure.
/*                          If exists,
/*                              continue
/*                            Else
/*                              Take parent of that bomline.
/*                              Revise it using _BT
/*                              Delete that found bomline.
/*                      Here, it is assumed that input dicbomline will have only 
/*                      one parameter group bomline.
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  03/15/2013       Nikhil Patil           Initial Creation              */
/****************************************************************************/

int FVE_DeleteLineFromBVRStructure(struct FVEParmDefInfostruct *parmInfoStr,
                                        tag_t   tTopDicBOMLine,
                                        tag_t   windowDic)
{

    int             ifail           =   0;

    // Tag to hold param group line.
    tag_t       tParamGrpLine       =   NULLTAG;

    logical     isRevised           =   FALSE;

    // Number of param def revs found.
    int         iParamDefChildRevs       =   0;

    // Tag to hold all param def revs.
    tag_t*      ptParamDefRevs      =   NULLTAG;

    // Tag to hold matching param def line.
    tag_t       tParamDefRevLineFound   =   NULLTAG;

    tag_t       tNewAddedOrgGrpLine     =   NULLTAG;

    int indexCounter                    =   0;

    int structCounter                   =   0;

    // Array containing param names to be removed.
    char**  ppcParamNamesToRemove       =   NULL;

    // Total number of params to be removed.
    int     iNoParamToRemove            =   0;

    // String to hold param grp id.
    char*           pcParamGrpId   =   NULL;


    char*           parmGrp_ItemRevId   =   NULL;
	char  dic_rev_id[ITEM_id_size_c+1] = "";


    if(isDictionary)
    {
            // 1. Get param group bom line from top line.
        ifail = FVE_get_organizationChild(tTopDicBOMLine, &tParamGrpLine, &isRevised);

        // If param grp not present return.
        if( tParamGrpLine == NULLTAG)
        {
            fprintf(logfileptr,"\nNo param group present in this structure.");
            tParamGrpLine   =   tTopDicBOMLine;
        }

        // Get all param def rev child lines from grp line.
        CLEANUP( BOM_line_ask_child_lines(tParamGrpLine, &iParamDefChildRevs, &ptParamDefRevs) );

        // If param def rev not present return.
        if(iParamDefChildRevs == 0)
        {
            fprintf(logfileptr,"\nNo param definitions are present in this structure.");
            goto CLEANUP;
        }
    }
    if(isECCTProjectRev)
    {
        // Get param defs lines from top dic bomline;
        CLEANUP( BOM_line_ask_child_lines(tTopDicBOMLine, &iParamDefChildRevs, &ptParamDefRevs) )
		
    }



    for( indexCounter = 0; indexCounter < iParamDefChildRevs; indexCounter++)
    {
        // Get name of param def rev.

        parmGrp_ItemRevId   =   NULL;

        CLEANUP(AOM_ask_value_string(ptParamDefRevs[indexCounter],"bl_item_object_name",&parmGrp_ItemRevId))

        // Check if that param name exists in struct.

        for( structCounter = 0; structCounter < totalNoOfParameters; structCounter++)
        {
            if( tc_strcmp( parmInfoStr[structCounter].name, parmGrp_ItemRevId) == 0 )
            {
                break;
            }
        }

        // If param def rev not found in file, add it to array.
        if ( structCounter == totalNoOfParameters)
        {
                // Param name does not exists in file, so store it in array.
                FV_add_string_pointer_to_array(&iNoParamToRemove, &ppcParamNamesToRemove, parmGrp_ItemRevId);
        }
    }

    if( iNoParamToRemove > 0)
    {
		if(isDictionary)
		{
			ITK(ITEM_ask_rev_id(dicRevTag, dic_rev_id))
			fprintf(logfileptr,"Below missing parameters from the csv file are removed from Revision <%s> of the Dictionary Structure.\n",dic_rev_id);
		}else
		{
			ITK(ITEM_ask_rev_id(ecctRevTag, dic_rev_id))
			fprintf(logfileptr,"Below missing parameters from the csv file are removed from Revision <%s> of the Project Structure.\n",dic_rev_id);

		}
		if( isECCTProjectRev )
        {
            tParamGrpLine   =   tTopDicBOMLine;
        }
        // Get item id of dic.
        CLEANUP(AOM_ask_value_string(tParamGrpLine,"bl_item_item_id", &pcParamGrpId))

        // Revise org line first.
        ifail = FV_revise_bomline_and_limited_parents_BT(tParamGrpLine,
                                                            tTopDicBOMLine,
                                                            windowDic,
                                                            &revisedObjsCnt,
                                                            &revisedObjs,
                                                            &tNewAddedOrgGrpLine,
                                                            TRUE,
                                                            pcParamGrpId);

        if ( tNewAddedOrgGrpLine )
        {
            for( structCounter = 0; structCounter < iNoParamToRemove; structCounter++)
            {
                ifail = FV_check_bomLineExist_inStruct(tNewAddedOrgGrpLine, ppcParamNamesToRemove[structCounter], &tParamDefRevLineFound);

                CLEANUP( BOM_line_cut(tParamDefRevLineFound) )
                CLEANUP( BOM_save_window(windowDic) )
				fprintf(logfileptr,"%d : %s\n",structCounter+1,ppcParamNamesToRemove[structCounter]);
            }
			fprintf(logfileptr,"\n");
			fprintf(logfileptr,"\n");

        }

        orgBlTag = tNewAddedOrgGrpLine;


     }

CLEANUP:
    FVE_FREE(ptParamDefRevs);
    FVE_FREE(parmGrp_ItemRevId);
    FVE_FREE(pcParamGrpId);

    return ifail;

}
