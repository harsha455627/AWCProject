/******************************************************************************
 * Filename        :   fve_a2l_import_offline
 * Description     :   Utility is called from dispatcher to load A2L files in offline mode
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * Mar 2013         Monika A          Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_A2L_IMPORT_OFFLINE_H
#define FVE_A2L_IMPORT_OFFLINE_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include<stdlib.h>
#include <fclasses/tc_string.h>

#include <FV_includes.h>

/*************************************************
* Macros Definition
**************************************************/
#define PASSWORDKEY     "PASSWORDKEY"


#define FV_GET_ECCT_PROJ	"__FVGetParmGrpDefRevision"
					 
void print_usage(void);


#endif /* FVE_PAR_IMPORT_OFFLINE_H  */
