/*==================================================================================================

File description:

    Filename: fve_a2l_import_offline.c
    Module  : main

Utility to import A2L File in Offline Mode        

===============================================================================
Date            Name                       Description of Change
Mar '2013		Ravindra Chaugule          Initial version
===============================================================================*/

#include "fve_a2l_import_offline.h"

extern int DecryptPasswd(char *encrptedPasswd,
                         char *keyValue,
                         char **actualPasswd);

/*--------------------------Function Prototypes-------------------------------*/

int readAndDecryptPasswd( char *passwdFile, char **passwd );

/*-------------------------------End------------------------------------------*/

extern int ITK_user_main( int argc, char **  argv )
{
	int			ifail					= ITK_ok;
    char*		function_name			= "fve_a2l_import_offline";
	char*		login_user				= NULL;
    char* 		login_password			= NULL;
	char* 		login_group				= NULL;
	char*		pw_file_location		= NULL;
    char*		owning_user				= NULL;
    char*		owning_group			= NULL;
    char*		ecct_project_item_id	= NULL;
    char*		ecct_project_rev_id		= NULL;
	char*		isReviseStr				= NULL;
	logical		isRevise				= false;
	tag_t		query_tag				= NULLTAG;
	int			sizeofquery             = 0;
    int			entryarraycnt           = 0;
	int			items_count             = 0;
	tag_t*		itemsTags               = NULL;
	char**		entries                 = NULL;
	char**		queryValues1            = NULL;
	char*		foundObjStr				= NULL;

	tag_t   ecctProjObj = NULLTAG;
	int     attachedDatasetCnt = 0;
	int     dicCnt = 0;
	int     returnStrCnt = 0;
	int datasetIndx = 0;
	char*   projDicId = NULL;
	char*   attrNames[1] = {item_idPROP};
    char*   attrValues[1] = {'\0'};
    char*   returnStr = NULL;
    char*   datasetType = NULL;
    tag_t   relationType = NULLTAG;
    tag_t	dicRevTag = NULLTAG;
    tag_t	a2lDataset = NULLTAG;
    tag_t	parDataset = NULLTAG;
    tag_t	diffReportDataset = NULLTAG;
    tag_t*  dicTags = NULL;
    tag_t*  attachedDatasets = NULL;

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }
	
	
	printf("\nBefore Reading Arguments...");
		
	owning_user = ITK_ask_cli_argument("-u=");
	printf ("\n owning_user=%s", owning_user);
	owning_group = ITK_ask_cli_argument("-g=");
	printf ("\n owning_group=%s", owning_group);
	ecct_project_item_id = ITK_ask_cli_argument("-i=");
	printf ("\n ecct_project_item_id=%s", ecct_project_item_id);
	ecct_project_rev_id = ITK_ask_cli_argument("-r=");
	printf ("\n ecct_project_rev_id=%s", ecct_project_rev_id);
	isReviseStr = ITK_ask_cli_argument("-revise=");
	printf("\n isRevise=%s", isReviseStr);


	printf("\nAfter Reading Arguments...");
	
	
    CLEANUP(ITK_initialize_text_services(ITK_BATCH_TEXT_MODE))

	/*------------------------------------------------------------------------------*/
    /* This utility is invoked via Dispatcher User. Need to know                    */
	/* this user-id                                                                 */
    /*------------------------------------------------------------------------------*/
	login_user = getenv("FV_TC_DISP_USERID");
   
	if(login_user == NULL || tc_strlen(login_user) == 0)
	{
		printf("\nERROR: Environment variable FV_TC_DISP_USERID is not set. Exiting...");
		exit(0);

	}
	
	/*------------------------------------------------------------------------------*/
    /* This utility is invoked via Dispatcher User. Need to know                    */
	/* this group                                                                 */
    /*------------------------------------------------------------------------------*/
	login_group = getenv("FV_TC_DISP_GROUP");
   
	if(login_group == NULL || tc_strlen(login_group) == 0)
	{
		printf("\nERROR: Environment variable FV_TC_DISP_GROUP is not set. Exiting...");
		exit(0);

	}

	/*------------------------------------------------------------------------------*/
    /* This utility is invoked via Dispatcher User. Need to know                    */
	/* this password. If Password is not provided check for cncrypted password file */
    /*------------------------------------------------------------------------------*/
	login_password = getenv("FV_TC_DISP_PASSWORD");
   
	if(login_password == NULL || tc_strlen(login_password) == 0)
	{
	
		/*------------------------------------------------------------------------------*/
		/* This utility is invoked via Dispatcher User. Need to know                    */
		/* the location of encrypted password file                                      */
		/*------------------------------------------------------------------------------*/
		pw_file_location = getenv("FV_TC_DISP_PASSWORD_FILE");
   
		if(pw_file_location == NULL || tc_strlen(pw_file_location) == 0)
		{
			printf("\nERROR: Environment variable FV_TC_DISP_PASSWORD_FILE is not set. Exiting...");
			exit(0);
    
		}
		
		/*-------------------------------------------*/	
		/*          Decrypt the password             */
		/*-------------------------------------------*/
		if( pw_file_location != 0 )
		{
			readAndDecryptPasswd( pw_file_location, &login_password) ;
		}

	}

	if ( owning_user != NULL && (tc_strlen(owning_user) > 0) &&  
	     owning_group != NULL && (tc_strlen(owning_group) > 0) &&  
		 ecct_project_item_id != NULL && (tc_strlen(ecct_project_item_id) > 0) &&
		 ecct_project_rev_id != NULL && (tc_strlen(ecct_project_rev_id) > 0) &&
		 isReviseStr && (tc_strlen(isReviseStr)> 0)
		)
	{

   		CLEANUP(ITK_init_module (login_user, login_password, login_group))
		if(ifail != ITK_ok)
		{
			printf("Login with user id: %s, group:%s is unsuccessful\n", login_user, login_group);
			exit(0);
		}
	}
	
	printf("\nInvoking A2L Import...");

	if(tc_strcmp(isReviseStr, "true") == 0)
	{
		isRevise = true;
	}
	else
	{
		isRevise = false;
	}

	//Saved query to find out all the sequences....
    CLEANUP(QRY_find(TC_text(FV_GET_ECCT_PROJ), &query_tag))

	if(query_tag == NULLTAG)
	{
		printf("Failed to find saved query with name %s\n", FV_GET_ECCT_PROJ);
		exit(0);
	}
	CLEANUP(FV_copy_string_to_array(&entryarraycnt, &entries, TC_text("Item ID")))
	CLEANUP(FV_copy_string_to_array(&sizeofquery, &queryValues1, ecct_project_item_id))
	
	CLEANUP(FV_copy_string_to_array(&entryarraycnt, &entries,TC_text("Revision ID")))
	CLEANUP(FV_copy_string_to_array(&sizeofquery, &queryValues1, ecct_project_rev_id))

	CLEANUP(QRY_execute(query_tag, 2, entries, queryValues1, &items_count, &itemsTags))
	if(itemsTags != NULL && items_count>0)
	{
		printf("\n\n Found objects");
		CLEANUP(AOM_ask_value_string(itemsTags[0], object_stringPROP, &foundObjStr))
		printf("\n %s", foundObjStr);
		ecctProjObj = itemsTags[0];

	}

	if(ecctProjObj != NULLTAG)
	{
		CLEANUP(AOM_ask_value_string(ecctProjObj, FVE_DicIDPROP, &projDicId))
		FV_DEBUG_TXT(("\n Dictionary Id on ECCT Project - %s\n", projDicId))
		attrValues[0] = projDicId;

	    CLEANUP(FV_search_objects_by_attrs(ParmGrpDefTYPE, 1, attrNames, attrValues, &dicCnt,  &dicTags));
	    FV_DEBUG_TXT(("\n Found Dictionary count - %d\n", dicCnt));

	    if(dicCnt > 0 && dicTags != NULL)
	    {
	    	CLEANUP(ITEM_ask_latest_rev(dicTags[0], &dicRevTag));
	    	CLEANUP(GRM_find_relation_type(FVE_PARAM_SRC_RELTYPE, &relationType));
	    	if(relationType != NULLTAG)
			{
	    		CLEANUP(GRM_list_secondary_objects_only(dicRevTag,relationType, &attachedDatasetCnt, &attachedDatasets));
			}
	    	FV_DEBUG_TXT(("\n Count of dataset attached to Dictionary with relation FVE_Param_Src_relation - %d", attachedDatasetCnt));
	    	if(attachedDatasets != NULL)
	    	{
	    		for(datasetIndx = 0; datasetIndx < attachedDatasetCnt; datasetIndx++)
	    		{
	    			CLEANUP(AOM_ask_value_string(attachedDatasets[datasetIndx], fv9object_typePROP, &datasetType));
	    			if(tc_strcmp(datasetType, FVE_A2LFileStorageTYPE) == 0)
	    			{
	    				FV_DEBUG_TXT(("\n A2l dataset found"));
	    				a2lDataset = attachedDatasets[datasetIndx];
	    			}
	    			else if(tc_strcmp(datasetType, FVE_PARFileStorageTYPE) == 0)
					{
	    				FV_DEBUG_TXT(("\n PAR dataset found"));
	    				parDataset = attachedDatasets[datasetIndx];
					}
	    			FVE_FREE(datasetType);
	    		}
	    		FVE_FREE(attachedDatasets);
	    		attachedDatasetCnt = 0;
	    	}
	    	CLEANUP(GRM_find_relation_type(IMAN_specificationTYPE, &relationType));
			if(relationType != NULLTAG)
			{
				CLEANUP(GRM_list_secondary_objects_only(dicRevTag,relationType, &attachedDatasetCnt, &attachedDatasets));
				if(attachedDatasets != NULL)
				{
					for(datasetIndx = 0; datasetIndx < attachedDatasetCnt; datasetIndx++)
					{
						CLEANUP(AOM_ask_value_string(attachedDatasets[datasetIndx], fv9object_typePROP, &datasetType));
						if(tc_strcmp(datasetType, MISCTYPE) == 0)
						{
							FV_DEBUG_TXT(("\n Difference Report dataset found"));
							diffReportDataset = attachedDatasets[datasetIndx];
						}
						FVE_FREE(datasetType);
					}
				}
			}
			FV_DEBUG_TXT(("\n Start : A2l import by invoking server method FV_import_A2L"));
			CLEANUP(FV_import_A2L(a2lDataset,parDataset,ecctProjObj,dicRevTag, diffReportDataset,
				isRevise, owning_user, owning_group, &returnStr, &returnStrCnt));
			if(ifail == ITK_ok)
			{
				FV_DEBUG_TXT(("\n End : Successfully completed a2l import"));
			}
	    }
	}


	
CLEANUP:
    
	FV_FREE_STRINGS(entries)
	FV_FREE_STRINGS(queryValues1)
	FVE_FREE(itemsTags)

	FVE_FREE(datasetType)
	FVE_FREE(projDicId)
	FVE_FREE(attachedDatasets)
	FVE_FREE(returnStr)
	
	FV_DEBUG_TXT(("Exiting %s\n", function_name))
				
    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}



/*--------------------------------------------------------------------------*/

void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: fve_a2l_import_offline <args>\n\n");
        printf(" Where args include the following:\n\n");
		printf(" -u=<owning user id> \n");
		printf(" -g=<owning user group> \n");
        printf(" -i=<ECCT Project ID> \n");
		printf(" -r=<ECCT Project Revision ID> \n");
		printf(" -iR=<Is to be revised>  Value should be either true/false\n");
        printf("\n");
        printf(" NOTE:- \n");
        printf("**********************************************************************************\n\n");
}

/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                  */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;


    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );        
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        printf( "ERROR: Invalid format for password file '%s'\n", passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);

    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");        
        return !ITK_ok ;
    }

    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;

    return ifail;
}



