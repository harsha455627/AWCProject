//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================


#ifndef TEAMCENTER_CLIENTX_SOACREDENTIALMANAGER_HXX
#define TEAMCENTER_CLIENTX_SOACREDENTIALMANAGER_HXX





#include <string>


#include <teamcenter/schemas/soa/_2006_03/exceptions/InvalidCredentialsException.hxx>
#include <teamcenter/schemas/soa/_2006_03/exceptions/InvalidUserException.hxx>
#include <teamcenter/soa/client/CredentialManager.hxx>






namespace Teamcenter
{
    namespace ClientX
    {
        class AppXCredentialManager;



/**
 * The CredentialManager is used by the Teamcenter Services framework to get the
 * user's credentials when challanged by the server. This can occur after a period
 * of inactivity and the server has timed-out the user's session, at which time
 * the client application will need to re-authenitcate. The framework will
 * call one of the getCredentials methods (depending on circumstances) and will
 * send the SessionService.login service request. Upon successfull completion of
 * the login service request. The last service request (one that cuased the challange)
 * will be resent.
 *
 * The framework will also call the setUserPassword setGroupRole methods when ever
 * these credentials change, thus allowing this implementation of the CredentialManager
 * to cache these values so prompting of the user is not requried for  re-authentication.
 *
 */
class  AppXCredentialManager: public Teamcenter::Soa::Client::CredentialManager
{
public:

    AppXCredentialManager();

    /**
     * Return the type of credentials this implementation provides,
     * standard (user/password) or Single-Sign-On. In this case
     * Standard credentials are returned.
     *
     */
    virtual Teamcenter::Soa::Client::CredentialManager::CredentialsType getCredentialType();

    /**
     * Prompt's the user for credentials.
     * This method will only be called by the framework when a login attempt has
     * failed.
     *
     */
    virtual Teamcenter::Soa::Client::CredentialManager::Credentials getCredentials(
        Teamcenter::Schemas::Soa::_2006_03::Exceptions::InvalidCredentialsException e);

    /**
     * Return the cached credentials.
     * This method will be called when a service request is sent without a valid
     * session ( session has expired on the server).
     *
     */
    virtual Teamcenter::Soa::Client::CredentialManager::Credentials getCredentials(
        Teamcenter::Schemas::Soa::_2006_03::Exceptions::InvalidUserException e);

    /**
     * Cache the group and role
     * This is called after the SessionService.setSessionGroupMember service
     * operation is called.
     *
     */
    virtual void setGroupRole(const std::string& group, const std::string& role);

    /**
     * Cache the User and Password
     * This is called after the SessionService.login service operation is called.
     *
     */
    virtual void setUserPassword(const std::string& user, const std::string& password, const std::string& discriminator);


    Teamcenter::Soa::Client::CredentialManager::Credentials promptForCredentials();

private:
    Teamcenter::Soa::Client::CredentialManager::Credentials credentials;

};


}} //end namespace
#endif

