/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: Fve_create_signal_unit.c
    Module  : main

        Used to allow creation of WSOs.
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>.
        
===============================================================================
Date               Name                    Description of Change
06/03/2010         Bakul Bernard           Initial version
07/15/2010         Vishal                  Modified code for new FVDTSTDSignalClass. 
                                           Changed search criteria for FVDTSTDSignalClass 
                                           and added new attribite while FVDTSTDSignalClass's 
                                           object creation.
05/02/2011         Alok                    Supporting FVRECUDocSetName Class. 
05/02/2011         Alok                    Setting SUBSYS_ID_ATTR explicitly to sub-sys name
                                           Changed the bypass location explicitly to delete
04/25/2012         Saroj                   Changes done for "Abbreviated Signal Name"
09/24/2014         Brian Lobo              Added System Reviewer Name
===============================================================================*/

#include <sys/stat.h>
#include "FVDT_import_std_names.h"


/*--------------------------Function Prototypes-------------------------------*/


static void print_usage(void);

static logical verbose_flag = false;
FILE *logfileptr = NULL;

/*******************************************************************************/
/* Function Name    : FVDT_String_to_StringArray                               */
/*                                                                             */
/* Description      : Convert string to string array on the basis of given     */
/*                    delimitor                                                */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

void FVDT_String_to_StringArray  (char* line, char ***Attributes, char * delim, int *count )
{
   char     *str = NULL;   
   char**  AttributesDup = NULL;
   int      i              = 0;
   char    *trimStr = NULL;

   /* *Attributes  = NULL;   */
   str = tc_strtok (line, delim);  

   while (str != NULL)
   {
       
       AttributesDup = (char**)MEM_realloc(AttributesDup, sizeof(char*)*(i+1));
       AttributesDup[i] = (char*)MEM_alloc( sizeof(char)*((int)strlen (str)+1));
       
       // Trim the blank spece
       trimStr = stripBlanks(str);
       strcpy( AttributesDup [i], str);
         
       str = tc_strtok (NULL,delim);
       
       //If str is null then do not increment counter
       if (str != NULL)
          i++;
  
   }
   *Attributes = AttributesDup;
   *count = i;
}

/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                    */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */                                                                          
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  10/21/2004      Ramesh Ramaiah            Initial Creation              */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;
    
    
    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        if( logfileptr )
        fprintf( logfileptr, "ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);
    
    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }
    
    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;
    
    return ifail;
        
}

extern int FVDT_find_dynamic_picklist_values(char *className, tag_t **objTags, int *numValues)
{
    int stat = ITK_ok;
    char* function_name = "FVDT_find_dynamic_picklist_values";
    int number_found = 0;
    tag_t* list_of_WSO_tags = NULL;

    WSO_search_criteria_t criteria;


    if ( className != NULL )
    {
        WSOM_clear_search_criteria(&criteria);
        strcpy(criteria.class_name,className);
        stat = WSOM_search(criteria, &number_found,&list_of_WSO_tags);
        if (stat != ITK_ok) goto CLEANUP;
	}

    *numValues = number_found;
    *objTags = list_of_WSO_tags;

CLEANUP:
    TC_write_syslog("\nExit %s\n", function_name);
    return stat;
}

extern int ITK_user_main( int argc, char **  argv )
{   
    FILE * fileptr = NULL;
    
   int line_count    = 0;
	int ifail         = ITK_ok;
	int len           = 0;
	int num_created   = 0;
	int num_failed    = 0;
	int num_notExits  = 0;
   int isValid       =0;
   char         *upwf             = NULL;
  	char			 **Attributes     = NULL;      
   char line_in[555 + 1] = "";
   char * ptr = 0;
   char logfilename[255 + 1] = "";
	char * classname = NULL;
   char * stdname = NULL;
	const char * verbose = NULL;
   const char * filename = NULL;
   char line_temp[555 + 1] ="";
	char *  login_group = NULL;
   char *  login_user = NULL;
   char * login_password = NULL;
	char * time_stamp = NULL;
   int   num = 0;  
   int   count = 0;
   int cleanInstall = 0;
   struct stat file_stat;
	char* id = NULL;
  	logical exists = FALSE;
    char       *tmp_dir_path                    = NULL;    
    tag_t                 *foundtags = NULL;
	int  numberfound = 0;
	int i = 0;
	int deleteCounter=0;


	/*----------------------------------------------------------*/
    /*  Log files are placed in the directory specified by the  */
    /*  environment variable TC_TMP_DIR. If this is not set   */
    /*  the files are created in the current directory where    */
    /*  the executable is being run.                            */
    /*----------------------------------------------------------*/
    tmp_dir_path = getenv( DT_TMP_DIR_VAR );

    /*Append the log file name with the date and time stamp 
    along with Process ID */
	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	if (tmp_dir_path == NULL)
	{
		sprintf(logfilename,"IMPORT_STDNAMES_%s.log",time_stamp); 
	}
	else
	{
#ifdef UNX
		sprintf(logfilename,"%s/IMPORT_STDNAMES_%s.log",tmp_dir_path, time_stamp); 
#else
		sprintf(logfilename,"%s\\IMPORT_STDNAMES_%s.log",tmp_dir_path, time_stamp); 
#endif
	}
	
	logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(logfileptr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);
        
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
		  FVDT_FREE(time_stamp)
    }	    	
    /*if( argc != 5)
    {
      fprintf(logfileptr,"All the required arguments are not present\n");
      fclose( logfileptr );
      print_usage();
      exit(0);
    }*/
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }    
    
   classname = ITK_ask_cli_argument("-class=");
   filename = ITK_ask_cli_argument("-file=");
	login_user = ITK_ask_cli_argument("-u=");
	login_password = ITK_ask_cli_argument("-p=");
	login_group = ITK_ask_cli_argument("-g=");
   upwf = ITK_ask_cli_argument("-pf=");/* gets the password file*/

    if( ITK_ask_cli_argument( "-clean" ) )
    {
        cleanInstall = 1;
    }


   if (filename== NULL || strlen(filename)==0)
   {
        printf("ERROR: File Name is missing");fflush(stdout);
        fprintf(logfileptr,"ERROR: File Name is missing\n\n");
        print_usage();
        exit(0);

   }

   if (classname== NULL || strlen(classname)==0)
   {
        printf("ERROR: classname is missing");fflush(stdout);
        fprintf(logfileptr,"ERROR: classname is missing\n\n");
        print_usage();
        exit(0);

   }

	printf("filename is %s\n", filename);fflush(stdout);

  	/*-------------------------------------------*/
   /*          Decrypt the password             */
   /*-------------------------------------------*/
   if( upwf != 0 )
   {                                        
      readAndDecryptPasswd( upwf, &login_password) ;  
   }

   if ( login_user != NULL && strlen(login_user)!=0 &&  login_password != NULL && strlen(login_password)!=0 &&  login_group != NULL && strlen(login_group)!=0)
   {
      ITK(ITK_init_module (login_user, login_password, login_group))
      if(ifail != ITK_ok)
         fprintf(logfileptr,"Login with uid: %s, group:%s is unsuccessful\n", login_user, login_group);		
      else
         fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n", login_user, login_group);
   }
   else
   {      
      ITK_initialize_text_services (0);
      ITK (ITK_auto_login ())
      if(ifail != ITK_ok)
         fprintf(logfileptr,"Auto Login unsuccessful\n");		
      else
         fprintf(logfileptr,"Auto Login successful\n");
   }  
    

    
   if ( verbose != 0 )
   {
      verbose_flag = true;
   } 
    
   if ( filename != NULL)
   {
      fileptr = fopen(filename, "r");
      if (fileptr == NULL)
      {
         fprintf(logfileptr, "ERROR: Can not open input file:%s\n", filename);
         get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
         fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
         FVDT_FREE(time_stamp)
         fclose(logfileptr);
         ITK_exit_module( true );
         exit(1);
      }
   }    
    stat( filename, &file_stat);
    
    /*If input file size is Zero, Exit*/
   if( file_stat.st_size == 0 )
   {
      printf("ERROR: Input File [%s] is empty!!.\n", filename);
      fprintf(logfileptr,"ERROR: Input File [%s] is empty!!.\n", filename);
      get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
      fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
      FVDT_FREE(time_stamp)
      fclose( logfileptr );
      ITK_exit_module( true );
      exit(1);
   }
    
   /* If clean argument is supplied then clear the existing data first */
   if (cleanInstall)
   {
      ITK (FVDT_find_dynamic_picklist_values(classname,&foundtags, &numberfound))

      fprintf(logfileptr,"No. of objects found: %d\n", numberfound);

	  for (i = 0; i < numberfound; i++)
	  {
			ifail = AOM_load (foundtags[i]);
			if (ifail)
			{
				TC_write_syslog ("Error in loading the object with tag %d\n", foundtags[i]);
				continue;
			}
	  AM__set_application_bypass(TRUE);
			ifail = AOM_delete (foundtags[i]);
	  AM__set_application_bypass(FALSE);
			if (ifail)
			{
				ifail = ITK_ok;
				TC_write_syslog ("Error in deleting the object with tag %d\n", foundtags[i]);
				continue;
			}
			deleteCounter++;
	  }
      fprintf(logfileptr,"No. of objects successfully deleted: %d\n", deleteCounter);


	  if (numberfound)
		  FVDT_FREE(foundtags)
   }


   if ( fileptr != NULL )
   {
      line_count = 0;
      while (fgets(line_in, 1110, fileptr) != 0)
      {    
         id = NULL;
         stdname = NULL;
         line_count++;
         len = (int) strlen(line_in);
         if (len > 0 && line_in[len-1] == '\n')
             line_in[len-1] = '\0'; 
         if ( strlen(  line_in ) == 0 )
             continue;
             
         strcpy( line_temp, line_in);

         ITK(POM_does_class_exist (classname, &exists))
         if (!exists)
         {
            fprintf(logfileptr,"ERROR: %s is not a valid class name\n", classname);
            exit(0);
         }

		 /*
         FVDT_String_to_StringArray(line_temp, &Attributes, "|", &count);
		 */

		 FV_parse_delimited_string(line_temp,"|",TRUE,&count,&Attributes);


         ITK(FVDT_validate_data_in_file(Attributes, count, classname, line_count, &isValid));

         if (isValid)
            continue;
         

         //printf("\nAttributes[0] %s, Attributes[1] %s\n", Attributes[0], Attributes[1]);fflush(stdout);

         FVDT_WSO_uniq_check( Attributes, classname, &num);

         if(num ==0)
         {
            FVE_create_name(Attributes, &num_created, classname, &num_failed);
         }
         else
         {
            if (tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
               fprintf(logfileptr,"Name %s already exists in %s.\n",Attributes[0],classname);
            else
               fprintf(logfileptr,"Name %s already exists in %s.\n",Attributes[0],classname);
               num_notExits++;
         }
                  
         FVDT_FREE_ARRAY( Attributes, count);

      }
             
     /* Reset the input file to begin reading from the begining*/
     fseek( fileptr, 0, 0 );
   }  
     
   printf("\nImport  successful.\n\n");
   fprintf(logfileptr,"\nImport  successful\n");              
        
   printf("Processing Completed.\n");
   fprintf(logfileptr,"Processing completed.\n");

   ITK_exit_module( true );
             
   fprintf(logfileptr,"\nNumber of Standards Names CREATED are %d\n\n", num_created);
   fprintf(logfileptr,"\nNumber of Standard Names ALREADY EXISTS are %d\n\n", num_notExits);
   fprintf(logfileptr,"\nNumber of Standard Names FAILED are %d\n\n", num_failed);

   printf("Utility completed successfully.\n\n");
   fprintf(logfileptr,"\nUtility completed successfully.\n\n");
   get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
   fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
   FVDT_FREE(time_stamp)   

   if (logfileptr ) fclose( logfileptr);
   if (fileptr ) fclose( fileptr);

   return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


int FVDT_WSO_uniq_check(char** Attributes, char *classname, int* num)
{
	int ifail = ITK_ok;
  	WSO_search_criteria_t criteria;
  	tag_t StdSignalName  = NULLTAG;
	tag_t SigSysName     = NULLTAG;
	tag_t SigSubSysName  = NULLTAG;
	tag_t SignalName     = NULLTAG;
	tag_t SigCiruitNum    = NULLTAG;
  	tag_t enqid1   = NULLTAG;
	tag_t enq_id1  = NULLTAG;
	tag_t enq_id2  = NULLTAG;
	tag_t enq_id3  = NULLTAG;
	tag_t enq_id4  = NULLTAG;
	tag_t enq_id5  = NULLTAG;	
  	tag_t * StdSignalName_objs = NULL;

   *num = 0;

/*   printf("\n class %s+++ SIG_CLASSNAME_CONST %s+++\n", classname, SIG_CLASSNAME_CONST);fflush(stdout);*/

   /*
   if (tc_strcmp(SIG_CLASSNAME_CONST, classname)==0 )
   {  
      ITK(POM_class_id_of_class(SIG_CLASSNAME_CONST, &StdSignalName))

      ITK(POM_attr_id_of_attr(SIG_CIRCUIT_NUM_ATTR, SIG_CLASSNAME_CONST, &SigCiruitNum))
      ITK(POM_attr_id_of_attr(SIG_SYS_NAME_ATTR, SIG_CLASSNAME_CONST, &SigSysName))
      ITK(POM_attr_id_of_attr(SIG_SUB_SYS_NAME_ATTR, SIG_CLASSNAME_CONST, &SigSubSysName))
      ITK(POM_attr_id_of_attr(SIG_NAME_ATTR, SIG_CLASSNAME_CONST, &SignalName))

      ITK(POM_create_enquiry_on_string(StdSignalName, SigCiruitNum, POM_is_equal_to, &Attributes[0], &enq_id1))
      ITK(POM_create_enquiry_on_string(StdSignalName, SigSubSysName, POM_is_equal_to, &Attributes[7], &enq_id2))
      ITK(POM_create_enquiry_on_string(StdSignalName, SignalName, POM_is_equal_to, &Attributes[8], &enq_id3))

      ITK(POM_combine_enquiries(enq_id1, POM_and, enq_id2, &enq_id4))
      ITK(POM_combine_enquiries(enq_id4, POM_and, enq_id3, &enq_id5))

      ITK(POM_execute_enquiry(enq_id5, num, &StdSignalName_objs))

   }
   else
   {
   */
      ITK(WSOM_clear_search_criteria(&criteria));
      tc_strcpy(criteria.class_name, classname);
      tc_strcpy(criteria.name, Attributes[0]);
      ITK(WSOM_search(criteria, num, &StdSignalName_objs));     
/*
   }

  	FVDT_FREE(StdSignalName_objs);
	*/
   return ifail;
}


/*--------------------------------------------------------------------------*/

static void print_usage(void)
{
   printf("\n**********************************************************************************\n");
   printf("Usage: FVDT_import_std_names <args>\n\n");
   printf(" Where args include the following:\n\n");
   printf(" [-u=<login user id> {-p=password | -pf=passwordFile}] -g=<login group> -class=<ClassName> -file=<filename>\n\n");
   printf("Each record in the file contains the following in the order specified:\n\n");
   printf("SystemName|SubSystemName|SignalName for signal\n\n");
   printf("StdCompName for component\n\n");
   printf("StdSubSysName|id for sub system\n\n");
   printf(" -v is a flag that will turn on verbose mode\n");
   printf("\n");
   printf(" NOTE:- \n");
   printf("For Class FVDTStdCompName   use Import File : dev_gdt2db_load.txt  \n");
   printf("For Class FVDTStdSignalName use Import File : psf_gdt2db_load.txt  \n");
   printf("In order to create Corporate PAAT Rating, use class name as FV9CorpPAATRating \n");
   printf("**********************************************************************************\n\n");        
}
/*input id is just needed for subsystem*/
int FVE_create_name(char ** Attributes, int * created_cnt, char *classname, int * failed_cnt)
{
	int ifail = ITK_ok;
	int unit_cnt = 0;

	logical verdict = FALSE;
	tag_t ObjType = NULLTAG;
	tag_t ObjInputTag = NULLTAG;
	tag_t Obj = NULLTAG;
	tag_t desc_prop_tag = NULLTAG;

	ITK(TCTYPE_find_type(classname, NULL,&ObjType))
	ITK(TCTYPE_construct_create_input(ObjType, &ObjInputTag)) 
	
	if(tc_strcmp(classname,ECU_DOCSET_CLASSNAME_CONST)==0)
   {
     	ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, FILEMGMT_ECU_NAME_ATTR, 1, (const char**)&Attributes[1]))
   }

	else if(tc_strcmp(classname,COMP_CLASSNAME_CONST)==0)
   {
     	int length =0;
        ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, COMP_NAME_ATTR, 1, (const char**)&Attributes[0]))
        
        length = tc_strlen(Attributes[1]);
        if ((Attributes[1]!=NULL) && (length>0)) 
            AOM_set_value_string(ObjInputTag,COMP_SYSTEM_REVIEWER,Attributes[1]);
		
		length = 0;
		length = tc_strlen(Attributes[2]);
        if ((Attributes[2]!=NULL) && (length>0)) 
		  AOM_set_value_string(ObjInputTag,COMP_DESIGNATION,Attributes[2]);
				
   }
	else if(tc_strcmp(classname,SUBSYS_CLASSNAME_CONST)==0)
	{
     	ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, SUBSYS_NAME_ATTR, 1, (const char**)&Attributes[0]))
		/*if id specified is null then set it to std name*/
		/** NO NEED to populate addtional attribute as template with sub-system names have changed and doesn't require addtional attr
		if(Attributes[1]!=NULL && strlen(Attributes[1]) > 0)
			ITK(TCTYPE_set_create_display_value(ObjInputTag, SUBSYS_ID_ATTR, 1, (const char**)&Attributes[1]))
		else
		**/
			ITK(TCTYPE_set_create_display_value(ObjInputTag, SUBSYS_ID_ATTR, 1, (const char**)&Attributes[0]))

	}
	else if(tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
   {
      
     	ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_SYS_NAME_ATTR, 1, (const char**)&Attributes[6]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_SUB_SYS_NAME_ATTR, 1, (const char**)&Attributes[7]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_NAME_ATTR, 1, (const char**)&Attributes[8]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_CIRCUIT_NUM_ATTR, 1, (const char**)&Attributes[0]))
      //Changes done for "Abbreviated Signal Name"
      ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_ABB_SIG_NAME_ATTR, 1, (const char**)&Attributes[9]))
   }
	else if(tc_strcmp(classname,PAAT_CLASSNAME_CONST)==0)
   {
     	ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
		ITK(TCTYPE_set_create_display_value(ObjInputTag, PAAT_RATING_ATTR, 1, (const char**)&Attributes[1]))
   }
	else
	{
     	ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
	}
  	ITK(TCTYPE_create_object(ObjInputTag, &Obj))
	ITK(AOM_save(Obj))	
	if(ifail == ITK_ok)
	{
		/*ITK(POM_modifiable(Obj, &verdict))
		if(verdict == FALSE)
			ITK(AOM_refresh(Obj, TRUE))
		
		if(stdname != NULL)
		{
			ITK(PROP_ask_property_by_name(Obj, "FVDTCompName", &desc_prop_tag))
			ITK(PROP_set_value_string(desc_prop_tag, stdname))	
		}
		ITK(AOM_save(Obj))
		ITK(AOM_refresh(Obj, FALSE))	*/
		(*created_cnt)++;
      if (tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
	  {
		  fprintf(logfileptr,"SUCCESS:: %s : %s has been created successfully in %s\n", Attributes[0],Attributes[8], classname);
		  fflush (logfileptr);
		  fflush (stdout);
		  fflush (stderr);
	  }
      else
	  {
		  fprintf(logfileptr,"SUCCESS:: %s has been created successfully in %s\n", Attributes[0], classname);
		  fflush (logfileptr);
		  fflush (stdout);
		  fflush (stderr);
	  }
	}
	else
	{
      if (tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
	  {
		  fprintf(logfileptr,"FAILED:: Creation of %s : $s in %s failed\n",Attributes[0],Attributes[8], classname);
		  fflush (logfileptr);
		  fflush (stdout);
		  fflush (stderr);
	  }
      else
	  {
		  fprintf(logfileptr,"FAILED:: Creation of %s in %s failed\n",Attributes[0], classname);
		  fflush (logfileptr);
		  fflush (stdout);
		  fflush (stderr);
	  }
		(*failed_cnt)++;
	}
	return ifail;
}

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );           
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
}

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}

int FVDT_validate_data_in_file (char ** Attributes, int count, char *classname, int line_count,int *isValid)
{
   int ifail = ITK_ok, i=0;
   *isValid = 0;

   if (strcmp(classname, SIG_CLASSNAME_CONST)== 0)
   {

      //Changes done for "Abbreviated Signal Name"
      if (count != 10 )  
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, number of column expected \n", line_count);
         
      }

      else
      {
		 if (strstr (Attributes[8], "DO NOT USE"))
		 {
               *isValid = 1;
               fprintf(logfileptr,"Skipping line no %d, DO NOT USE \n", line_count);
		 }

      }
   }
   else if (strcmp(classname, SUBSYS_CLASSNAME_CONST)== 0)
   {
      if (count < 1 ||  Attributes[0]==NULL || strlen(Attributes[0])==0)
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, first column of the line is blank\n", line_count);         
      }


   }
   else if (strcmp(classname, COMP_CLASSNAME_CONST)== 0)
   {
      if (count < 1 ||  Attributes[0]==NULL || strlen(Attributes[0])==0)
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, first column of the line is blank\n", line_count);         
      }
   }
   else if (strcmp(classname, ECU_DOCSET_CLASSNAME_CONST)== 0)
   {
      if (count < 2 ||  Attributes[0]==NULL || strlen(Attributes[0])==0)
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, first column of the line is blank\n", line_count);         
      }
   }
   else if (strcmp(classname, PAAT_CLASSNAME_CONST)== 0)
   {
      if (count != 2 ||  Attributes[0]==NULL || strlen(Attributes[0])==0 || Attributes[1]==NULL || strlen(Attributes[1])==0)
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, one or more column value in this line is blank\n", line_count);         
      }
   }
	return ifail;

}

