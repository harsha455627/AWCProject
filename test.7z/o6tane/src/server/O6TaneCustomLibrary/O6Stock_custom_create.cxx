//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6Stock_custom_create
 *
 */
#include <O6TaneCustomLibrary/O6Stock_custom_create.hxx>
#include <O6TaneCustomLibrary/method.hxx>
#include <metaframework/CreateInput.hxx>

int O6Stock_custom_create( METHOD_message_t * /*msg*/, va_list args )
{
	int verdict=ITK_ok, error_level=ITK_serious_error, irc=ITK_ok;

	va_list largs;
	va_copy( largs, args);
	Teamcenter::CreateInput *creInput = va_arg(largs, Teamcenter::CreateInput*);
	va_end( largs );

	{
	int count_s2p=0;
	tag_t rel_type=NULLTAG, *s2p=NULL;
	tag_t secondary_object = NULLTAG;
	bool isNull = true;
	irc = ITK_CALL ( creInput->getTag ( "secondary_object", secondary_object, isNull ) );
	irc = ITK_CALL(GRM_find_relation_type (GOODSINWAREHOUSE, &rel_type));
	if (rel_type!=NULLTAG){
	irc = ITK_CALL(GRM_list_primary_objects_only (secondary_object, rel_type, &count_s2p, &s2p));
	if (count_s2p == 0){
	verdict=error_level;
	irc = ITK_CALL(EMH_store_error ( EMH_severity_error, 919111 ));
	}

	}
	else{
	}

	}
	return (verdict);
}
