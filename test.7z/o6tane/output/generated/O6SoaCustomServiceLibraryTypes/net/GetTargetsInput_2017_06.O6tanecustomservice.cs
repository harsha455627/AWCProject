/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;

using Teamcenter.Schemas.Soa._2006_03.Base;


namespace O6.Schemas.Customservicelibrary._2017_06.O6tanecustomservice 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://o6.com/Schemas/CustomServiceLibrary/2017-06/O6TaneCustomService", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class GetTargetsInput 
  {

         private Teamcenter.Schemas.Soa._2006_03.Base.ModelObject ObjField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("obj")]
     public Teamcenter.Schemas.Soa._2006_03.Base.ModelObject Obj
     { 
        get { return this.ObjField;}
        set { this.ObjField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public Teamcenter.Schemas.Soa._2006_03.Base.ModelObject getObj()
     { 
       return this.ObjField;
     }
     public void setObj(Teamcenter.Schemas.Soa._2006_03.Base.ModelObject val)
     { 
       this.ObjField = val;
     }



    
    


  } // type
} // ns
            





