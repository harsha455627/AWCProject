//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object O6_ContenanceImpl
//

#ifndef O6TANE__O6_CONTENANCEIMPL_HXX
#define O6TANE__O6_CONTENANCEIMPL_HXX

#include <O6TaneCustomLibrary/O6_ContenanceGenImpl.hxx>

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>


namespace o6tane
{
    class O6_ContenanceImpl; 
    class O6_ContenanceDelegate;
}

class  O6TANECUSTOMLIBRARY_API o6tane::O6_ContenanceImpl
    : public o6tane::O6_ContenanceGenImpl
{
public:

    ///
    /// Getter for a Double Property
    /// @param value - Parameter Value
    /// @param isNull - Returns true if the Parameter value is null
    /// @return - Status. 0 if successful
    ///
    int  getO6_rt_net_wt_ozBase( double &value, bool &isNull ) const;


protected:
    ///
    /// Constructor for a O6_Contenance
    explicit O6_ContenanceImpl( O6_Contenance& busObj );

    ///
    /// Destructor
    virtual ~O6_ContenanceImpl();

private:
    ///
    /// Default Constructor for the class
    O6_ContenanceImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    O6_ContenanceImpl( const O6_ContenanceImpl& );

    ///
    /// Copy constructor
    O6_ContenanceImpl& operator=( const O6_ContenanceImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class o6tane::O6_ContenanceDelegate;

};

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
#endif // O6TANE__O6_CONTENANCEIMPL_HXX
