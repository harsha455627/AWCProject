/*
 * @file
 *
 *   This file contains the all the custom action handler headers.
 *   Note: For custom rule handler, create a new source and a header file.
 *
 */
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/tc_arguments.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <tc/preferences.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tc/tc_util.h>
#include <sa/tcfile.h>
#include <epm/epm.h>
#include <string>
#include <iostream>
#include <sstream>

/**
 * Handler arguments
 */
#define INCLUDE_TYPE "include_type"
#define ATTACHMENT "attachment"
#define RELATION "relation"
#define DATASET_TYPE "dataset_type"
#define ACTION "action"
#define FDS_STATUS "fds_status"

/**
 * Attributes
 */
#define TARGET "target"
#define REFERENCE "reference"
#define OBJECT_TYPE "object_type"
#define ITEMID "item_id"
#define REVID "item_revision_id"
#define XML_DATASET_TYPE "MISC"
#define XML_NMD_REF_NAME "MISC_TEXT"

/*Constants*/
#define UNDERSCORE "_"
#define CSV_FILE_EXTENSION ".csv"

typedef struct arguments
{
	string sObjectType;
	string sFdsStatus;
	string sTargetOrReference;
}csvArguments;

int O6_SEEDS_Sec_extract_csv ( EPM_action_message_t msg );
