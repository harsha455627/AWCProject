/*===============================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
=================================================================================
File description:

    Filename: fv_import_picklist_values.c
    Module  : main

    Used to import the feature dictionary structure.
    Requires a login account specified by -u=<user> -p=<pass> -g=<group>.


	Assumptions:
	1. Run Exe with -u=infodba -p=infodba -g=dba -file=filename
	2. Deafult delimeter "|" will be considered for parsing csv files.Make sure csv file contains this parameter.
	3. log file will be created with name "fv_import_picklist_values" on time stamp basis where utility is executed.
	
===============================================================================
Date               Name                    Description of Change
 2012        Ram Sisodia             Initial Version.
===============================================================================*/

#include <sys/stat.h>
#include "fv_import_picklist_values.h"


/*--------------------------Function Prototypes-------------------------------*/


static void print_usage(void);



FILE *logfileptr = NULL;

FILE *summary_file_ptr = NULL;
/*-------------------------------End------------------------------------------*/

extern int ITK_user_main(int retCount, char **retValue)
{

FILE *fileptr                                                =           NULL;

char line_in[2047 + 1]                                       =           "";
//char line[555 + 1]                                           =           "";
char line_temp[2047 + 1]                                     =           "";
const char * filename                                        =           NULL;
const char * mode                                            =           "r+";
char * ptr						                             =           NULL;
char logfilename[255 + 1]                                    =           "";
//char *  my_name                                              =           NULL;
//char *  login_group                                          =           NULL;
//char *  login_user                                           =           NULL;
//char * login_password                                        =           NULL;
char * time_stamp                                            =           NULL;
//char * user_id                                               =           NULL;
//char* file_val                                               =           NULL;
int   ifail                                                  =           ITK_ok;
int   len                                                    =           0;
int line_count                                               =           0;
int array_cnt                                                =           0;


//logical is_null                                              =           FALSE;


char **          Picklist_Type_array                         =           NULL;
char **          Picklist_Value_array                        =           NULL;
char **          Description_array                           =           NULL;
char **          Region_Country_array                        =           NULL;



    //Get the time stamp.
	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"fv_import_picklist_values_error_%s.log",time_stamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
		FVE_FREE(time_stamp)
        exit(1);
    }
    printf("\n Error information will be written into %s\n\n",logfilename);


	if(logfileptr)
    {
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
		FVE_FREE(time_stamp)
    }
     
	if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }


	/*login_user = ITK_ask_cli_argument("-u=");
	login_password = ITK_ask_cli_argument("-p=");
	login_group = ITK_ask_cli_argument("-g=");*/
	filename = ITK_ask_cli_argument("-file=");

        /* Check input arguments */
        if (!filename)
        {
            print_usage();
            return !ITK_ok ;
        }

    ITK_initialize_text_services (0);
 //   ITK(ITK_init_module (login_user, login_password, login_group))
	ifail = fve_autologin();
	if(ifail != ITK_ok)
	{
		fprintf(logfileptr,"Auto Login Unsuccessful\n");
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
		FVE_FREE(time_stamp)
		fclose( logfileptr );
		exit(1);
	}
	else
	{
		char*		userName = NULL;
		ITK(POM_get_user_id( &userName ))
		fprintf(logfileptr,"Login with User: %s successful\n", userName);
		FVE_FREE(userName)
	}

	printf("filename is %s\n", filename);

    fileptr = fopen (filename, mode);

	 if ( fileptr != NULL )
    {
		line_count = 0;
        while (fgets(line_in, 2048, fileptr) != 0)
        {
			line_count++;
			len = (int) strlen(line_in);
            if (len > 0 && line_in[len-1] == '\n')
                line_in[len-1] = '\0';
            if ( strlen(  line_in ) == 0 )
                continue;

            if(line_count == 1)
			 continue;
            tc_strcpy( line_temp, line_in);
			array_cnt ++;
			//ptr = tc_strtok(line_temp, "|");
			
            ptr = tc_strtok(line_temp, "|");
			if(tc_strlen(ptr) == 0)
				ptr = tc_strtok(NULL, "|");
			FV_get_value_and_store(ptr, array_cnt, &Picklist_Type_array);

			ptr = tc_strtok(NULL, "|");
			FV_get_value_and_store(ptr, array_cnt, &Picklist_Value_array);

			ptr = tc_strtok(NULL, "|");
			FV_get_value_and_store(ptr, array_cnt, &Description_array);

			ptr = tc_strtok(NULL, "|");
			FV_get_value_and_store(ptr, array_cnt, &Region_Country_array);
        }
		//Get the time stamp.
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		fprintf(logfileptr,"Input file parsing is completed successfully %s \n\n",time_stamp);

        //Function for creating the workspace objects.
	    ITK(FV_create_workspace_objects(Picklist_Type_array,Picklist_Value_array,Description_array,Region_Country_array,array_cnt))
	
		FVE_FREE_ARRAY(Picklist_Type_array, array_cnt)
		FVE_FREE_ARRAY(Picklist_Value_array, array_cnt)
		FVE_FREE_ARRAY(Description_array, array_cnt)
        FVE_FREE_ARRAY(Region_Country_array, array_cnt)

		}


    ITK_exit_module( true );

	fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	printf("Utility Completed successfully");
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
	FVE_FREE(time_stamp)

    if (logfileptr ) fclose( logfileptr);
    if (fileptr ) fclose( fileptr);

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


/*--------------------------------------------------------------------------*/

static void print_usage(void)
{		printf(" This program is intended to import the picklist values.\n\n");
        printf("\n******************************************************************************\n");
        printf("Usage: fv_import_picklist_values <args>\n\n");
        printf(" Where args include the following:\n\n");
		/*printf(" -u=<login user id>\n");
		printf(" -p=<login password>\n");
		printf(" -g=<login group>\n");*/
		printf(" -file=<filename>  input file to import structure\n");
        printf("Each record in the file contains the following in the order specified:|Picklist Type|Picklist Value|Description|\n");
        printf("\n\n");
        printf(" -h=<any value> for usage help\n");
		printf("\n");
        printf(" NOTE:- \n");
        printf("******************************************************************************\n\n");
}

//Function for read value from file and store it.
void FV_get_value_and_store(char * init_value, int cnt, char *** str_array)
{
	(*str_array) = (char **) MEM_realloc ((*str_array), (int) cnt * sizeof(char *));

	if(tc_strcmp(init_value, "") != 0)
	{
		(*str_array)[cnt -1] = (char *) MEM_alloc ((int) (tc_strlen(init_value) + 1) * sizeof(char));
		tc_strcpy((*str_array)[cnt -1], init_value);
	}
	else
	{ 
		(*str_array)[cnt -1] = NULL;
	}
}

//Function For creating Objects.
int FV_create_workspace_objects(char **EPicklist_Type_array,char **EPicklist_Value_array,char **EDescription_array,char **ERegion_Country_array,int num_column)
{

int ifail                                 =                            ITK_ok;

tag_t target_type_tag                     =                             NULLTAG;
tag_t target_obj_tag                      =                             NULLTAG;
tag_t createInputTag                      =                             NULLTAG;
tag_t picklist_class_id                   =                             NULLTAG;
tag_t object_id_class                     =                             NULLTAG;
tag_t enqid1                              =                             NULLTAG;
tag_t *tag_revs                           =                             NULL;

char *time_stamp                          =                            NULL;
//char *trim_desc_string                    =                            NULL;
char summarylogfilename[255 + 1]          =                            "";

int no_cnt                                =                            0;
//int ret_cnt                               =                            0;
//int tag_cnt                               =                            0;
int counter_first                         =                            0;
int line_number                           =                            0;
int summary_counter                       =                            0;
int success_line_counter                  =                            0;


//Error log file.

    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(summarylogfilename,"fv_import_picklist_values_summary_%s.log",time_stamp);

    summary_file_ptr = fopen( summarylogfilename, "w+");
    if (summary_file_ptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", summarylogfilename);
		FVE_FREE(time_stamp)
    }
    printf("\nSummary information will be written into %s\n\n",summarylogfilename);

	if(summary_file_ptr)
    {
        fprintf(summary_file_ptr,"Start time: %s\n\n", time_stamp);
		FVE_FREE(time_stamp)
    }
     
for(counter_first=0;counter_first<num_column;counter_first++)
{

    
	line_number++;

	fprintf(summary_file_ptr,"Processing started for line number %d \n",line_number);
	fprintf(summary_file_ptr,"The name of the picklist type at this line is  %s \n",EPicklist_Type_array[counter_first]);


	//Find the type tag of the given picklist type.
	if(EPicklist_Type_array[counter_first] != NULL)
	{
    ITK(TCTYPE_find_type(EPicklist_Type_array[counter_first],NULL,&target_type_tag))
			if (ifail != ITK_ok)
				   {
					   fprintf(logfileptr,"Error:Unable to find the tag of the given type %s\n\n",EPicklist_Type_array[counter_first]);
					   ifail = ITK_ok;
				   }
	}
	else 
	{
		fprintf(logfileptr,"Error:Picklist type value is not exist in input file : %s\n\n", EPicklist_Value_array[counter_first]);
	     continue;
	}
	if(EPicklist_Value_array[counter_first] != NULL)
	{
     //Create the pom enquiry to check whether the objects is exist in teamcenter or not.
     ITK(POM_class_id_of_class(EPicklist_Type_array[counter_first], &picklist_class_id))
     ITK(POM_attr_id_of_attr("object_name",EPicklist_Type_array[counter_first], &object_id_class))  
     ITK(POM_create_enquiry_on_string(picklist_class_id, object_id_class, POM_is_equal_to, &(EPicklist_Value_array[counter_first]), &enqid1))
	 ITK(POM_execute_enquiry(enqid1, &no_cnt, &tag_revs))
	}
       if(tag_revs != NULL)
		{
			 fprintf(logfileptr,"The picklist value %s is already in Teamcenter \n\n",EPicklist_Value_array[counter_first]);
			 ifail = ITK_ok; 
			 continue;
		}
	else
	{
	//Get the create input tag for creating the target busniss object.
    ITK(TCTYPE_construct_create_input(target_type_tag,&createInputTag))
    //create picklist value with the given name.
	ITK(TCTYPE_set_create_display_value(createInputTag, "object_name", 1, (const char**)&EPicklist_Value_array[counter_first]))
     //create picklist value with the given region-country.
	if((tc_strcmp(EPicklist_Type_array[counter_first], "FV9CountryByRegion") == 0))
	{
	   ITK(TCTYPE_set_create_display_value(createInputTag, "fv9Region", 1, (const char**)&(ERegion_Country_array[counter_first])))
	}
	//For the creation of objects.
    ITK(TCTYPE_create_object(createInputTag,&target_obj_tag))
	if( ifail != ITK_ok)
		{
			fprintf(logfileptr,"Error:The Value %s for Region-Country for Picklist type Country By Region is not valid \n\n",ERegion_Country_array[counter_first]);
			ifail = ITK_ok;
			summary_counter++;
			continue;
		}
	ITK( AOM_save_with_extensions(target_obj_tag))
	} 
	if(EDescription_array[counter_first] != NULL)
	{
	if(FVDT_check_property_exists(target_obj_tag, "object_desc") == 0)
	{
	ITK(AOM_UIF_set_value(target_obj_tag, Picklist_description_cons, EDescription_array[counter_first]))
	ITK(AOM_save(target_obj_tag))
	}
	else 
		fprintf(logfileptr,"Error:Property is not exist on this picklist %s \n\n",EPicklist_Value_array[counter_first]);
	if (ifail != ITK_ok)
				   {
					   fprintf(summary_file_ptr,"Processing for picklist name %s  have some error pl check error log file for line number %d \n", EPicklist_Value_array[counter_first],line_number);
					   fprintf(logfileptr,"Error encountered at line number %d of input file \n",line_number);
					   fprintf(logfileptr,"Error:Unable to set value %s on property object_desc\n\n",EPicklist_Value_array[counter_first]);
					   ifail = ITK_ok;
					   summary_counter++;
				   }
	}

	    fprintf(summary_file_ptr,"Processing was successful for the Picklist type %s \n",EPicklist_Type_array[counter_first]);
		fprintf(summary_file_ptr,"Processing ends for line number %d\n\n",line_number);

}

 //Get the timestamp value.
        get_time_stamp(DATE_FORMAT_STR, &time_stamp);
        
        fprintf(summary_file_ptr,"=======================\n");
        fprintf(summary_file_ptr,"Summary\n");
        fprintf(summary_file_ptr,"Total number of lines processed is %d\n",line_number);
		if(summary_counter == 0)
		{
		fprintf(summary_file_ptr,"Successful %d\n",line_number);
		fprintf(summary_file_ptr,"Failed %d\n",summary_counter);
		fprintf(summary_file_ptr,"=======================\n");
		}
		else
		{
		success_line_counter=line_number - summary_counter;
		fprintf(summary_file_ptr,"Successful %d\n",success_line_counter);
		fprintf(summary_file_ptr,"Failed %d\n\n",summary_counter);
		fprintf(summary_file_ptr,"=======================\n");
		}
 FVE_FREE(tag_revs)

 if (summary_file_ptr) fclose(summary_file_ptr);
 return ifail;
 }


void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fprintf(logfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fflush(logfileptr);
}

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = (byte) newTime->tm_mon;
	currentTime.year = (short) newTime->tm_year + 1900;
	currentTime.day = (byte) newTime->tm_mday;
	currentTime.hour = (byte) newTime->tm_hour;
	currentTime.minute = (byte) newTime->tm_min;
	currentTime.second = (byte) newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}
