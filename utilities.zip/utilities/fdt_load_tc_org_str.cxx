/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: fdt_load_tc_org_str.cxx
    Module  : main

        Used to allow creation of users, groups, persons roles (and members), and
        volume.
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>.
        If the object specified already exists then that operation is ignored.
        Instances created are determined by the following arguments;

         -user=<user_id>
         -group=<group name>
         -person=<person name>
         -role=<role name>
         -email=<email address>
    
        Note: if user and group are specifed the user is made a member
        of that group. If no person is specified the user will reference
        a person with the same name as the user has user id - this
        person will be created if necessary. If a role is given as well
        a user/group then the member created will be given that role.
     
        Duplicate person, group or role is OK,
        creating a duplicate user is an error.

===============================================================================
Date               Name                    Description of Change
09/22/2009         Anand Pajjuru           Created
===============================================================================*/

extern "C"
{
#include <tccore/aom.h>
#include <tc/tc.h>
#include <sa/imanvolume.h>
#include <tc/iman_errors.h>
#include <fclasses/iman_string.h>
#include <sa/sa.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>
#include <textsrv/textserver.h>  // PR #4097059
#include <ctype.h>
#include <sys/stat.h>
#ifdef UNX
#include <grp.h>
#include <pwd.h>
#include <tc/emh.h>
#include <unistd.h>
#endif
}

//#define DEBUG

#define ALLOWABLE_NON_ALPHANUM_CHARS  "./-_ &()'+,\"#:"
#define GIVEN_ROLE_DOESNOT_EXIST 919101
#define GIVEN_GRP_DOESNOT_EXIST 919102
#define PASSWORDKEY     "PASSWORDKEY"
#define VALID_NO_PIPES 10
/*--------------------------Function Prototypes-------------------------------*/

static int  create_role( const char *  role_name, tag_t *  a_role_tag , const char * user,
                        const char *group);
static int  create_person( const char *  person_name, char *  person_email, char * phone_no, char* dept_name,char* dept_no, tag_t *  a_person_tag );
static int  create_group( const char *  group_name, tag_t  a_vol_tag, tag_t *  a_group_tag ,
                         const char * user , const char *role);
static int  create_role_in_group( const char * user, tag_t  group_tag, tag_t  role_tag );
static int  create_user( const char * user_id, const char * user_name, const char * password, const char * osuser,
                        tag_t role_tag, tag_t a_group_tag, tag_t * a_user_tag,
                        logical *new_user_created );
static int  find_volume( const char *  volname, tag_t *  a_volume_tag );
static int  create_groupmember( tag_t  user_tag, tag_t  group_tag, tag_t  role_tag, logical, tag_t *  member_tag,
                               const char * grp_admin, const char * default_grp );
static int  assign_volume_to_group( tag_t  volume_tag, tag_t  group_tag );
static void print_usage(void);
int         readAndDecryptPasswd( char *passwdFile,  char **passwd );

extern "C"
{
    extern void DecryptPasswd( char * chrPtr, char *key, char **out_passwd );
	extern int fve_autologin();
}

static logical verbose_flag = false;
static char * supplier_only = NULL;
FILE *logfileptr = NULL;

/*-------------------------------End------------------------------------------*/
extern int ITK_user_main( int argc, char **  argv )
{
  
    logical          more_users = false;
    FILE             *fileptr = 0;
    
    int              line_count = 0;
    logical          hasError = false;
    
    char             persons[SA_name_size_c + 1] = "";
    char             users[SA_user_size_c + 1] = "";
    char             passwords[SA_password_size_c + 1] = "";
    char             groups[SA_full_path_size_c + 1] = "";
    char             roles[SA_name_size_c + 1] = "";
    char             emails[SA_name_size_c + 1] = "";
    char             phone_nos[SA_phone_size_c + 1] = "";
    char             dept_names[SA_name_size_c + 1] = "";
    char             dept_nos[SA_name_size_c + 1] = "";
    char             osusers[SA_name_size_c + 1] = "";
    char             default_grps[SA_name_size_c + 1] = "";
    char             grp_admins[SA_name_size_c + 1] = "";
    char             volumes[SA_name_size_c + 1] = "";
    char             line_in[555 + 1] = "";
    char             *ptr = 0;
   // char             *pwdFile = NULL;
    char             logfilename[255 + 1] = "";
    char             *group = NULL;
    char             *email = NULL;
    char             *phone_no = NULL;
    char             *dept_name = NULL;
    char             *dept_no = NULL;
    const char       *person = NULL;
    const char       *role = NULL;
    const char       *user = NULL;
    const char       *password = NULL;
    const char       *osuser = NULL;
    const char       *default_grp = NULL;
    const char       *grp_admin = NULL;
    const char       *verbose = NULL;
    const char       *volume = NULL;
    const char       *filename = NULL;
    char             line_temp[555 + 1] ="";
      
    time_t           clock;
    struct           stat file_stat;
    
    
    
    supplier_only = NULL;
    
    if( argc == 1 )
    {
        print_usage();
        exit(0);
    }
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }
    
    
    ITK_initialize_text_services (0);
    int  ifail;
  /*  const char *  login_group = getenv("FVE_GROUP");
    const char *  login_user = getenv("FVE_USER");
    char *  login_password = getenv("FVE_PASSWORD");
    */    
    time( &clock );
    struct tm *time_struct= localtime(&clock);
    
    /*Append the log file name with the date and time stamp 
    along with Process ID */
    
    #ifdef UNX
        sprintf(logfilename,"%s_%d_%02d_%02d_%d_%02d:%02d.log",argv[0],getpid(),
                 (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );
    
       #else
       sprintf(logfilename,"%s_%02d_%02d_%d_%02d_%02d.log",argv[0],
                    (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );
   #endif
            
    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);
    
    
    if( logfileptr )
    {
        fprintf(logfileptr,"Utility name: %s\n\n",argv[0]);
        fprintf(logfileptr,"Start time: %s\n", ctime( &clock ) );
    }
  /*  pwdFile = ITK_ask_cli_argument("-pf=");
    
    
    if( pwdFile != 0 )
    {                                        
        ifail = readAndDecryptPasswd( pwdFile, &login_password ) ;  
        if( ifail != ITK_ok )
        {
            if( logfileptr )
            {
                time( &clock );
                fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
                fclose( logfileptr );
            }
            exit(1);
        }
    }
    if( pwdFile != 0 )
    {
        if ( (login_user == NULL) || (login_group == NULL ) )
        {
            printf("ERROR-- The login environment not set.\n\n");
            printf(" Set the following Environment Variables   \n");
            printf(" FVE_USER - Valid Teamcenter Engineering Login User Id ( Should   \n");
            printf("                be infodba or any other user with dba \n");
            printf("                privelages )                          \n");
            printf( " FVE_GROUP - Teamcenter Engineering Login Group ( Should be dba or  \n");
            printf( "                 any group with DBA Privelages )      \n");
            if( logfileptr )
            {
                fprintf(logfileptr,"ERROR-- The login environment not set.\n\n");
                time( &clock );
                fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
                fclose( logfileptr );
            }
            exit(1);
        }
        
    }
    else 
    {
        if ( (login_user == NULL) || (login_password == NULL ) || (login_group == NULL ))
        {
            printf(" ERROR-- The login environment not set.\n\n");
            printf(" Set the following Environment Variables   \n");
            printf(" FVE_USER - Valid Teamcenter Engineering Login User Id ( Should   \n");
            printf("                be infodba or any other user with dba \n");
            printf("                privelages )                          \n");
            printf( " FVE_PASSWORD - Teamcenter Engineering Login Password for above User\n");
            printf( " FVE_GROUP - Teamcenter Engineering Login Group ( Should be dba or  \n");
            printf( "                 any group with DBA Privelages )      \n");
            if( logfileptr )
            {
                fprintf(logfileptr,"ERROR-- The login environment not set.\n\n");
                time( &clock );
                fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
                fclose( logfileptr );
            }
            exit(1);
        }
    }*/
	ifail = fve_autologin();

	if(ifail != ITK_ok)
	{
		fprintf(logfileptr,"Auto Login Unsuccessful\n");
		fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) );
		fclose( logfileptr );
		exit(1);
	}
	else
	{
		char*		userName = NULL;
		ifail =POM_get_user_id( &userName );
		fprintf(logfileptr,"Login with User: %s successful\n", userName);
		MEM_free(userName);
	}
	
    person = ITK_ask_cli_argument( "-person=" );
    role = ITK_ask_cli_argument( "-role=" );
    group = ITK_ask_cli_argument( "-group=" );
    user = ITK_ask_cli_argument( "-user=" );
    password = ITK_ask_cli_argument( "-password=" );
    osuser = ITK_ask_cli_argument( "-OSuser=" );
    email = ITK_ask_cli_argument( "-email=" );
	dept_name = ITK_ask_cli_argument( "-dept_name=" );
	dept_no = ITK_ask_cli_argument( "-dept_no=" );
	phone_no = ITK_ask_cli_argument( "-ph_no=" );
    default_grp = ITK_ask_cli_argument( "-default_grp" );
    grp_admin = ITK_ask_cli_argument( "-grp_admin" );
    verbose = ITK_ask_cli_argument( "-v" );
    volume = ITK_ask_cli_argument( "-volume=" );
      supplier_only = ITK_ask_cli_argument( "-supplier_only" );
	 
    filename = ITK_ask_cli_argument("-file=");
    
    if( (user == NULL ) && ( group == NULL ) && ( role == NULL) && ( filename == NULL ) )
    {
        print_usage();
        exit(0);
    }
    // When run in supplier_only mode, restrict tool to create groups and
    // group/role associations
    if( supplier_only && ( (person != 0 ) || (user != 0) || (password != 0 ) 
                || ( osuser != 0 ) || (email != 0 ) ) )
    {
        printf("ERROR:Invalid input. Tool will only create group and group/role association when run in \"supplier_only\" mode.\n");
        fprintf(logfileptr,"ERROR:Invalid input. Tool will only create group and group/role association when run in \"supplier_only\" mode.\n");
        time( &clock );
        fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
        fclose( logfileptr );
        exit(1);
    }
    
    if( role != 0 )
    {
    	if( supplier_only  && (group == 0 ))
        {
             printf("ERROR:Invalid input. Tool will not create roles when run in \"supplier_only\" mode.\n");
            fprintf(logfileptr,"ERROR:Invalid input. Tool will not create roles when run in \"supplier_only\" mode.\n");
            time( &clock );
            fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
            fclose( logfileptr );
            exit(1);
        }
    }
        
    if ( verbose != 0 )
    {
        verbose_flag = true;
    }
    
    
    if ( filename != 0 )
    {
        fileptr = fopen(filename, "r");
        if (fileptr == 0)
        {
            fprintf(stderr, "ERROR: Can not open input file:%s\n", filename);
            fprintf(logfileptr, "ERROR: Can not open input file:%s\n", filename);
            time( &clock );
            fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
            fclose( logfileptr );
            exit(1);
        }
    }
    
    /***********************************************************************
    BEGIN Validation of input file per CR requirements before logging in
    ***********************************************************************/
    
    stat( filename, &file_stat);
    
    //If input file size is Zero, Exit
    if( file_stat.st_size == 0 )
    {
        printf("ERROR: Input File [%s] is empty!!.\n", filename);
        fprintf(logfileptr,"ERROR: Input File [%s] is empty!!.\n", filename);
        time( &clock );
        fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );
        fclose( logfileptr );
        exit(1);
    }
    
    // Check for invalid characters
    if ( fileptr != 0 )
    {
        line_count = 0;
        while (fgets(line_in, 555, fileptr) != 0)
        {
            line_count++;
            int len = strlen(line_in);
            if (len > 0 && line_in[len-1] == '\n')
                line_in[len-1] = '\0'; 
            if ( strlen(  line_in ) == 0 )
                continue;
                
            strcpy( line_temp, line_in);
            
            // Check for valid number of pipes when supplier_only flag is used
             
            if( supplier_only )
            {
                int pipe_count = 0;
                for( int inm = 0 ; inm < strlen(line_in) ; inm++ )
                {
                    if( line_in[inm] == '|' )
                    {
                        pipe_count++;
                    }
                }
                if( pipe_count != VALID_NO_PIPES )
                {
                    fprintf(logfileptr,"ERROR:%s on line number %d has invalid number of pipe(|)characters.\n", 
                                                           line_in, line_count);
                    hasError = true;
                    continue;
                }

            }
            ptr = iman_strtok(line_temp, "|");
            iman_strcpy(persons, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(users, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(passwords, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(osusers, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(emails, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(groups, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(roles, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(volumes, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(default_grps, ptr);
            ptr = iman_strtok(NULL, "|");
            iman_strcpy(grp_admins, ptr);
	    
            ptr = iman_strtok(NULL, "|");
            if(ptr!= NULL && strlen(ptr)>0)
               iman_strcpy(phone_nos, ptr);			
            ptr = iman_strtok(NULL, "|");
            if(ptr!= NULL && strlen(ptr)>0)
               iman_strcpy(dept_names, ptr);
            ptr = iman_strtok(NULL, "|");
            if(ptr!= NULL && strlen(ptr)>0)
               iman_strcpy(dept_nos, ptr);

            
            person = (strlen(persons) > 0) ? persons : 0;
            user = (strlen(users) > 0) ? users : 0;
            password = (strlen(passwords) > 0) ? passwords : 0;
            group = (strlen(groups) > 0) ? groups : 0;
            role = (strlen(roles) > 0) ? roles : 0;
            email = (strlen(emails) > 0) ? emails : 0;
	         phone_no = (strlen(phone_nos) > 0) ? phone_nos : 0;
			   dept_name = (strlen(dept_names) > 0) ? dept_names : 0;
			   dept_no = (strlen(dept_nos) > 0) ? dept_nos : 0;
            osuser = (strlen(osusers) > 0) ? osusers : 0;
            volume = (strlen(volumes) > 0) ? volumes : 0;
            default_grp = (strlen(default_grps) > 0) ? default_grps : 0;
            grp_admin = (strlen(grp_admins) > 0) ? grp_admins : 0;
            
            // When run in supplier_only mode, restrict tool to create groups and
            // group/role associations
            
            if( supplier_only && ( (person != 0 ) || (user != 0) || (password != 0 ) 
                || ( osuser != 0 ) || (email != 0 ) ) )
            {
                fprintf(logfileptr,"ERROR:Invalid input on Line %d. Tool will only create group and group/role association when run in \"supplier_only\" mode.\n", line_count);
                hasError = true;
                continue;
            }
            if( role != 0 )
            {
    	        if( supplier_only  && (group == 0 ))
                {
                     
                    fprintf(logfileptr,"ERROR:Invalid input on Line %d. Tool will not create roles when run in \"supplier_only\" mode.\n",line_count );
                    hasError = true;
                    continue;
                }
            } 
            
            if( person )
            {
                
                                                       
                for( int inm = 0 ; inm < strlen(person) ; inm++ )
                {
                    if( !isalnum( person[inm] ) )
                    {

                        if( strchr( ALLOWABLE_NON_ALPHANUM_CHARS, person[inm] ) == NULL )
                        {

                            /* If input file has any alpha-numeric character other 
                               than the ones allowed, Write error and line number in log file */
                            fprintf(logfileptr,"ERROR:Person [%s] in Line %d has invalid [%c] character.\n", 
                                                       person, line_count,person[inm]);
                            hasError = true;
                            break;
                        }
                    }
                }
            }
            if( user )
            {
                for( int inm = 0 ; inm < strlen(user) ; inm++ )
                {
                    if( !isalnum( user[inm] ) )
                    {

                        if( strchr( ALLOWABLE_NON_ALPHANUM_CHARS, user[inm] ) == NULL )
                        {

                            /* If input file has any alpha-numeric character other 
                               than the ones allowed, Write error and line number in log file */
                            fprintf(logfileptr,"ERROR:User ID [%s] in Line %d has invalid [%c] character.\n", 
                                                       user, line_count,user[inm]);
                            hasError = true;
                            break;
                        }
                    }
                }
            }
            if ( osuser )
            {
                for( int inm = 0 ; inm < strlen(osuser) ; inm++ )
                {
                    if( !isalnum( osuser[inm] ) )
                    {

                        if( strchr( ALLOWABLE_NON_ALPHANUM_CHARS, osuser[inm] ) == NULL )
                        {

                            /* If input file has any alpha-numeric character other 
                               than the ones allowed, Write error and line number in log file */
                            fprintf(logfileptr,"ERROR:OS User ID [%s] in Line %d has invalid [%c] character.\n", 
                                                       osuser, line_count,osuser[inm]);
                            hasError = true;
                            break;
                        }
                    }
                }
            }
            if( group )
            {
                for( int inm = 0 ; inm < strlen(group) ; inm++ )
                {
                    if( !isalnum( group[inm] ) )
                    {

                        if( strchr( ALLOWABLE_NON_ALPHANUM_CHARS, group[inm] )!= NULL )
                        {
                            /* If input file is for supplier only, Exit if supplier group
                                 name has a . character */

                            if( supplier_only )
                            {
                                if( group[inm] == '.' )
                                {
                                    //Write error and line number in log file
                                    fprintf(logfileptr,"ERROR:Group [%s] in Line %d has a dot(.)character.\n", 
                                                       group,line_count);
                                    hasError = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            /* If input file has any alpha-numeric character other 
                               than the ones allowed, Write error and line number in log file */
                            fprintf(logfileptr,"ERROR:Group [%s] in Line %d has invalid [%c] character.\n", 
                                                       group, line_count,group[inm]);
                            hasError = true;
                            break;
                        }
                    }
                }
            }
            if ( role )
            {
                for( int inm = 0 ; inm < strlen(role) ; inm++ )
                {
                    if( !isalnum( role[inm] ) )
                    {

                        if( strchr( ALLOWABLE_NON_ALPHANUM_CHARS, role[inm] ) == NULL )
                        {

                            /* If input file has any alpha-numeric character other 
                               than the ones allowed, Write error and line number in log file */
                            fprintf(logfileptr,"ERROR:Role [%s] in Line %d has invalid [%c] character.\n", 
                                                       role, line_count,role[inm]);
                            hasError = true;
                            break;
                        }
                    }
                }
            }
            
        }
        
        
        // Rest the input file to begin reading from the begining
        fseek( fileptr, 0, 0 );
        
        
        person = NULL;
        role = NULL;
        group = NULL;
        user = NULL;
        password = NULL;
        osuser = NULL;
        email = NULL;
	      phone_no = NULL;
        dept_name = NULL;
        dept_no = NULL;
        default_grp = NULL;
        grp_admin = NULL;
        volume = NULL;
        
        if( hasError == true )
        {
            printf("Input file validation failed. Refer log file.\n\n");
            fprintf(logfileptr,"\nInput file validation failed.\n\n");
            time( &clock );
            fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) );
            fclose( logfileptr );
            exit(1);
        }
        else
        {
            printf("\nInput file validation successful.\n\n");
            fprintf(logfileptr,"\nInput file validation successful.\n");
        }
        
    }
    /***********************************************************************
    END Validation of input file per CR requirements before logging in
    ***********************************************************************/
    
    /***********************************************************************
    Login and start processing each line
    ***********************************************************************/
    
  /*  printf("Logging in...\n");
    fprintf(logfileptr,"Logging in...\n");
    if (( ifail = ITK_init_module(login_user,login_password,login_group)) != ITK_ok)
    {
        fprintf(stderr,"\nERROR: %d, Failed to login, See syslog file for details\n", ifail);
        if( logfileptr )
        {
            fprintf(logfileptr,"ERROR: Failed to login.See syslog file for details\n" ); 
            time( &clock );
            fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) ); 
            fclose( logfileptr );
        }
        exit(1);
    }
    printf("Logged in successfully.\n", argv[0]);
    fprintf(logfileptr,"Logged in successfully.\n");
    */
    printf("\nProcessing...\n");
    fprintf(logfileptr,"Processing...\n");
    
    ifail = SA_init_module();
    if (ifail != ITK_ok)
    {
        fprintf(stderr,"Failed to initialise the SA module %d - see \"%s.jnl\" file\n", ifail, argv[0]);
        fprintf(logfileptr,"Failed to initialise the SA module %d - see \"%s.jnl\" file\n", ifail, argv[0]);
        time( &clock );
        fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );
        exit(1);
    }
    
    line_count = 0;
    
    /* process each line in input file or the given command line arguments */
    do 
    {
         tag_t  a_volume_tag = NULLTAG;
        if ( volume != 0 )
        {
            ifail = find_volume( volume, &a_volume_tag );
            if( ( a_volume_tag == NULLTAG ) || ( ifail != ITK_ok ) )
            {
                if ( logfileptr )
                {
                    if( line_count )
                    {
                        fprintf(logfileptr,"ERROR: Volume [%s] specified in Line [%d] does not exist.\n",
                                    volume, line_count);
                    }
                    else
                    {
                        fprintf(logfileptr,"ERROR: Volume [%s] does not exist.\n",volume, line_count);
                    }
                }
                hasError = true;                    
                break;
            }
        }
        
        tag_t  a_person_tag = NULLTAG;
        if ( (ifail == ITK_ok)  &&  (person != 0) )
        {
            ifail = create_person( person, email, phone_no,dept_name,dept_no,&a_person_tag );
            if( ifail != ITK_ok )
            {
                hasError = true;
            }
        }

        tag_t  a_role_tag = NULLTAG;
        if ( (ifail == ITK_ok)  &&  (role != 0) )
        {
            ifail = create_role( role, &a_role_tag , user, group);
            if ( ifail != ITK_ok )
            {
                if( ifail == GIVEN_ROLE_DOESNOT_EXIST )
                {
                    if ( logfileptr )
                    {
                        if ( line_count )
                        {
                            fprintf(logfileptr,"ERROR: Role [%s] specified in Line [%d] does not exist.\n",role,
                                                line_count);
                        }
                        else
                        {
                            fprintf(logfileptr,"ERROR: Role [%s] does not exist.\n",role);
                        }
                    }
                }
                hasError = true;
                break;
            }
        }

        tag_t  a_group_tag = NULLTAG;
        if ( (ifail == ITK_ok)  &&  (group != 0) )
        {
               
            if( supplier_only )
            {
                strcat(group,".SUPPLIERS.FORD MOTOR COMPANY");
            }
            ifail = create_group( group, a_volume_tag, &a_group_tag , user, role);
            if ( ifail != ITK_ok )
            {
                
                if ( ifail == GIVEN_GRP_DOESNOT_EXIST )
                {
                    if ( logfileptr )
                    {
                        if( line_count )
                        {
                            fprintf(logfileptr,"ERROR: Group [%s] specified in Line [%d] does not exist.\n",
                                                    group, line_count);
                        }
                        else
                        {
                            fprintf(logfileptr,"ERROR: Group [%s] does not exist.\n",group);
                        }
                    }
                }
                hasError = true;
                break;
            }

            if( ( a_role_tag != NULLTAG ) && ( a_group_tag != NULLTAG ) )
            {
                ifail = create_role_in_group( user,a_group_tag, a_role_tag );
                if( ifail != ITK_ok )
                {
                    hasError = true;
                    break;
                }
            }
        }
    
        // RB - invocation of create_user method will be flagged for use in create_groupmember
        logical new_user_created = false;

        if ( (ifail == ITK_ok) && (user != 0) )
        {
            tag_t  a_user_tag = NULLTAG;
            
            if ( (a_role_tag != NULLTAG) && (a_group_tag != NULLTAG) )
            {
                //  create a new user

                ifail = create_user( user, person, (password != 0) ? password : user,
                                     osuser, a_role_tag, a_group_tag, &a_user_tag,
                                     &new_user_created );
			    if( ifail != ITK_ok )
                {
                    hasError = true;
                }
                if ( ifail == ITK_ok )
                {
                    tag_t  member_tag;
                    ifail = create_groupmember( a_user_tag, a_group_tag, a_role_tag,
                            new_user_created, &member_tag, grp_admin, default_grp );
                    if( ifail != ITK_ok )
                    {
                        hasError = true;
                    }
                }
            }
            else
            {
                if( line_count )
                {
                    fprintf(logfileptr,"ERROR: No Group/Role Specified to create user [%s] in line [%d].\n",user, line_count);
                    hasError = true;
                }
                else
                {
                    fprintf(logfileptr,"ERROR: No Group/Role Specified to create user [%s].\n",user);
                    hasError = true;
                }
            }
        }
        
        more_users = false;
        
        // Are we reading from a file?
        if ( fileptr != 0 )
        {
            // reset values
            strcpy(persons, "");
            strcpy(users, "");
            strcpy(passwords, "");
            strcpy(groups, "");
            strcpy(roles, "");
            strcpy(emails, "");
	    strcpy(phone_nos, "");
            strcpy(dept_names, "");
            strcpy(dept_nos, "");
            strcpy(volumes, "");
            strcpy(osusers, "");
            strcpy(default_grps, "");
            strcpy(grp_admins, "");
            
            
            if (fgets(line_in, 555, fileptr) != 0)
            {
                int len = strlen(line_in);
                if (len > 0 && line_in[len-1] == '\n')
                line_in[len-1] = '\0';
                ptr = iman_strtok(line_in, "|");
                iman_strcpy(persons, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(users, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(passwords, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(osusers, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(emails, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(groups, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(roles, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(volumes, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(default_grps, ptr);
                ptr = iman_strtok(NULL, "|");
                iman_strcpy(grp_admins, ptr);
		
		         ptr = iman_strtok(NULL, "|");
               if(ptr!= NULL && strlen(ptr)>0)
                   iman_strcpy(phone_nos, ptr);
               ptr = iman_strtok(NULL, "|");
               if(ptr!= NULL && strlen(ptr)>0)
                  iman_strcpy(dept_names, ptr);
               ptr = iman_strtok(NULL, "|");
               if(ptr!= NULL && strlen(ptr)>0)
                  iman_strcpy(dept_nos, ptr);
                more_users = true;
                line_count++;
                if ( verbose_flag )
                {
                    printf("Input Person \"%s\", User \"%s\", ", persons,users);
                    if (strlen(passwords) == 0)
                        printf("Password <none>, ");
                    else
                        printf("Password <secret>, ");
                    printf("Group \"%s\", Role \"%s\"\n", groups,roles);
                }
                person = (strlen(persons) > 0) ? persons : 0;
                user = (strlen(users) > 0) ? users : 0;
                password = (strlen(passwords) > 0) ? passwords : 0;
                group = (strlen(groups) > 0) ? groups : 0;
                role = (strlen(roles) > 0) ? roles : 0;
                email = (strlen(emails) > 0) ? emails : 0;
		phone_no = (strlen(phone_nos) > 0) ? phone_nos : 0;
				dept_name = (strlen(dept_names) > 0) ? dept_names : 0;
				dept_no = (strlen(dept_nos) > 0) ? dept_nos : 0;
                osuser = (strlen(osusers) > 0) ? osusers : 0;
                volume = (strlen(volumes) > 0) ? volumes : 0;
                default_grp = (strlen(default_grps) > 0) ? default_grps : 0;
                grp_admin = (strlen(grp_admins) > 0) ? grp_admins : 0;
            }
        }
    } while (more_users);
    
    printf("Processing Completed.\n");
    fprintf(logfileptr,"Processing completed.\n");
    
    ITK_exit_module( true );
            
    if ( ( hasError == true ) ) 
    {
        printf("Utility completed with Errors. Refer log file.\n\n");
        fprintf(logfileptr,"\nUtility completed with Errors.\n\n");
        time( &clock );       
        fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );
    }
    else
    {
        printf("Utility completed successfully.\n\n");
        fprintf(logfileptr,"\nUtility completed successfully.\n\n");
        time( &clock );
        fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );
    }
    
    if (logfileptr ) fclose( logfileptr);
    if (fileptr ) fclose( fileptr);
    
    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}

/*--------------------------------------------------------------------------*/

static int  create_role( const char *  role_name, tag_t *  role_tag , 
                         const char * user , const char * group)
{
    int  stat = SA_find_role( role_name, role_tag );
    if (stat != ITK_ok)
    {
        fprintf( logfileptr, "ERROR finding role \"%s\": %d from SA_find_role.\n", role_name, stat );
        return stat;
    }

    if ( (*role_tag != NULLTAG) )
    {
        //  already exists - that's fine
        if( verbose_flag) fprintf( stderr,"Role [%s] already exists.\n",role_name);
        if( group == 0 )
        {
            fprintf( logfileptr,"Role [%s] already exists.\n", role_name );
        }
        return ITK_ok;
    }
    else   
    {
        //Removed check for use_existing as its use was made implicit
        // Do not create role when creating users or when associating roles with groups
        if ( ( user !=0 ) || ( group !=0 ) )
        {
            
            return GIVEN_ROLE_DOESNOT_EXIST;
        }
    }

    //  Doesn't yet exist - so create the role
    stat = SA_create_role( role_name, role_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR creating role \"%s\": %d from SA_create_role.\n", role_name, stat );
        return stat;
    }

    stat = AOM_save( *role_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR saving role \"%s\": %d from AOM_save.\n", role_name, stat );
        return stat;
    }
    stat = AOM_unlock( *role_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR unlocking role \"%s\": %d from AOM_unlock.\n", role_name, stat );
        return stat;
    }

    if ( verbose_flag )
    {
        printf( "Created Role [%s]\n", role_name );
    }
    return ITK_ok;
}

/*--------------------------------------------------------------------------*/

static int  create_person( const char *  person_name, char *  person_email, char * phone_no,char* dept_name,char* dept_no, tag_t *  person_tag )
{
    char attribute_name[SA_name_size_c + 1] = "PA9";

    int  stat = SA_find_person( person_name, person_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr, "ERROR creating person \"%s\": %d from SA_find_person.\n", person_name, stat );
        return stat;
    }
    if ( *person_tag != NULLTAG) 
    {
        if( verbose_flag) fprintf( stderr,"Person \"%s\" already exists.\n",person_name);
    }
    if ( *person_tag == NULLTAG )
    {
        
        //  Doesn't yet exist - so create the person
        stat = SA_create_person( person_name, person_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr, "ERROR creating person \"%s\": %d from SA_create_person.\n", person_name, stat );
            return stat;
        }
        stat = AOM_save( *person_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR creating person \"%s\": %d from AOM_save.\n", person_name, stat );
            return stat;
        }
        if ( verbose_flag )
        {
            printf( "Created Person \"%s\"\n", person_name );
        }
    }
    stat = AOM_refresh( *person_tag , TRUE);
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR creating person \"%s\": %d from AOM_refresh.\n", person_name, stat );
        return stat;
    }

    // Check to see if email was input
    if ( person_email != 0)
    {
        if(verbose_flag) fprintf(stderr,"Re-setting E-mail\n");
        
        // Verify that email is of correct size
        size_t length;
        length = strlen( person_email );

        //printf( "strlen: %d\n", length);

        //if ( person_email[0] != '\0')
        if ( person_email != NULL)
        {
            if ( strlen(person_email) > SA_name_size_c )
            {
                fprintf( logfileptr, "WARNING: E-Mail address is more than 32 Characters. This attribute will be truncated!!!\n");
                fprintf( logfileptr, "WARNING: Person: '%s'\n", person_name);
                fprintf( logfileptr, "WARNING: E-Mail: '%s' - (%d Chars)\n", person_email, length);
                //fprintf( stderr, "WARNING: EMail address is more than %d Characters and it will be cut off.\n", strlen( SA_name_size_c ));
            }
			else
			{
				// Set the email attribute
				stat = SA_set_person_attr( *person_tag, attribute_name, person_email);
				//printf( "attribute_name:'%s'\nperson_email:'%s'\n", attribute_name, person_email);
				if ( stat != ITK_ok )
				{
					fprintf( logfileptr,"ERROR setting email \"%s\": %d from SA_set_person_attr.\n", person_email, stat );
					return stat;
				}
			}
        }
        
    }

   if(phone_no != NULL)
	{

		if ( strlen(phone_no) > SA_phone_size_c )
     {
         size_t length;
         length = strlen( phone_no );
         fprintf( logfileptr, "WARNING: Phone no is more than 32 Characters. This attribute will be truncated!!!\n");
         fprintf( logfileptr, "WARNING: Person: '%s'\n", person_name);
         fprintf( logfileptr, "WARNING: Phone no: '%s' - (%d Chars)\n", phone_no, length);
     }
		else
		{// Set the dept name attribute
			stat = SA_set_person_attr( *person_tag, "PA10", phone_no);
			if ( stat != ITK_ok )
            {
                fprintf( logfileptr,"ERROR setting phone no \"%s\": %d from SA_set_person_attr.\n", phone_no, stat );
                return stat;
            }
		}
	}


    if(dept_name != NULL)
	{

		if ( strlen(dept_name) > SA_name_size_c )
     {
         size_t length;
         length = strlen( dept_name );
         fprintf( logfileptr, "WARNING: Dept Name is more than 32 Characters. This attribute will be truncated!!!\n");
         fprintf( logfileptr, "WARNING: Person: '%s'\n", person_name);
         fprintf( logfileptr, "WARNING: Dept Name: '%s' - (%d Chars)\n", dept_name, length);
     }
		else
		{// Set the dept name attribute
			stat = SA_set_person_attr( *person_tag, "PA6", dept_name);
			if ( stat != ITK_ok )
            {
                fprintf( logfileptr,"ERROR setting email \"%s\": %d from SA_set_person_attr.\n", dept_name, stat );
                return stat;
            }
		}
	}
	if(dept_no != NULL)
	{
		if ( strlen(dept_no) > SA_name_size_c )
        {
		   size_t length;
		   length = strlen( dept_no );
           fprintf( logfileptr, "WARNING: Dept Number is more than 32 Characters. This attribute will be truncated!!!\n");
           fprintf( logfileptr, "WARNING: Person: '%s'\n", person_name);
           fprintf( logfileptr, "WARNING: Dept Number: '%s' - (%d Chars)\n", dept_no, length);
        }
		else
		{// Set the dept name attribute
			stat = SA_set_person_attr( *person_tag, "PA7", dept_no);
			if ( stat != ITK_ok )
            {
                fprintf( logfileptr,"ERROR setting email \"%s\": %d from SA_set_person_attr.\n", dept_no, stat );
                return stat;
            }
		}
	}
	
	stat = AOM_save( *person_tag );
	if ( stat != ITK_ok )
	{    
		fprintf( logfileptr,"ERROR updating person info \"%s\": %d from AOM_save.\n", person_name, stat );
		return stat;
	}
	
	stat = AOM_refresh( *person_tag, FALSE );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR unlock person \"%s\": %d from AOM_refresh.\n", person_name, stat );
        return stat;
    }
    return ITK_ok;
}

/*--------------------------------------------------------------------------*/

static int create_group( const char *  group_name, tag_t  vol_tag, tag_t *  group_tag ,
                         const char *user, const char * role)
{
    #ifdef DEBUG
        printf("Into create_group for <%s> \n",group_name);
    #endif
    int  stat = SA_find_group( group_name, group_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR finding group \"%s\": %d from SA_find_group.\n", group_name, stat );
        return stat;
    }
    
    if( *group_tag != NULLTAG )
    {
        if( verbose_flag ) fprintf(stderr,"Group [%s] already exists.\n",group_name);
        if( role == 0 )
        {
            fprintf( logfileptr,"Group [%s] already exists.\n", group_name );
        }
        return ITK_ok;
    }
    else 
    {
        // Removed used_existing check as its use was made implicit
        // Do not create group when creating users or when associating roles to groups
        if ( ( user != 0 || role != 0 ))
        {
            return GIVEN_GRP_DOESNOT_EXIST;
        }
    }
        
    
    if ( *group_tag == NULLTAG )
    {
        // Group does not yet exist.

        // Take a copy of the name to stomp on - we want to create each
        // component as needed. We do this recursively, but we don't assign the
        // volume to any of the parent groups.

        // Replaced SM_string_copy with strcpy
        // char * copyName = SM_string_copy ( group_name );
        char * copyName = NULL;
        copyName = (char *)MEM_alloc ( (strlen(group_name)+1) * sizeof(char ) );;
        strcpy ( copyName, group_name );
        char * firstDot = strstr ( copyName, "." );
        char * parentName = 0;
        tag_t parentGroupTag = NULLTAG;
        if ( firstDot != 0 )
        {
            parentName = firstDot + 1;
            *firstDot = '\0';
        }

        if ( parentName != 0 )
        {
            stat = SA_find_group ( parentName, &parentGroupTag );
            if ( stat != ITK_ok )
            {
                fprintf( logfileptr, "ERROR finding parent group \"%s\": %d from SA_find_group.\n", parentName, stat );
                MEM_free( copyName );
                return stat;
            }
            if ( parentGroupTag == NULLTAG )    // create parent first
            {
                int stat = create_group( parentName, NULLTAG, &parentGroupTag , user, role );
                if ( stat != ITK_ok )
                {
                    return stat;
                }
                if ( parentGroupTag == NULLTAG )    // should never happen if stat is ITK_ok
                {
                    fprintf ( logfileptr, "ERROR creating group \"%s\"\n", parentName );
                    return ITK_internal_error;
                }
            }
        }

        //  Create a user privileged group - SA groups must be created interactively.

        stat = SA_create_h_group ( copyName, 0, parentGroupTag, group_tag );
        MEM_free ( copyName );

        if ( stat != ITK_ok )
        {
            fprintf( logfileptr, "ERROR creating group \"%s\": %d from SA_create_group.\n", group_name, stat );
            return stat;
        }
        

        stat = AOM_save( *group_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr, "ERROR creating group \"%s\": error %d from AOM_save\n", group_name, stat );
            return stat;
        }
        stat = AOM_unlock( *group_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr, "ERROR unlock group \"%s\": error %d from AOM_unlock\n", group_name, stat );
            return stat;
        }
        if ( verbose_flag )
        {
            printf( "Created Group  \"%s\"\n", group_name );
        }
        
    }

    //  Assign volume to group
    if ( vol_tag != NULLTAG )
    {
        return assign_volume_to_group( vol_tag, *group_tag );
    }
    
    #ifdef DEBUG
        printf("Outof create_group for <%s> with stat <%d> \n",group_name,stat);
    #endif
    
    return ITK_ok;
}

/*--------------------------------------------------------------------------*/

static int  create_role_in_group( const char * user, tag_t  group_tag, tag_t  role_tag )
{
    char  role_name[SA_name_size_c + 1];
    SA_ask_role_name( role_tag, role_name );
    char  *group_name;
    SA_ask_group_full_name( group_tag, &group_name );
    
    int  stat = AOM_refresh( group_tag, true );
    if (stat != ITK_ok)
    {
        fprintf(logfileptr,"ERROR %d locking group from AOM_refresh.\n", stat);
        return stat;
    }
    stat = SA_add_role_to_group (group_tag, role_tag);
    if ( stat != ITK_ok )
    {
        fprintf(logfileptr,"ERROR %d in SA_add_role_to_group().\n", stat);
        return stat;
    }
    stat = AOM_save(group_tag);
    if (stat != ITK_ok)
    {
        fprintf(logfileptr,"ERROR saving group : error %d from AOM_save\n", stat);
        return stat;
    }
    stat = AOM_unlock(group_tag);
    if (stat != ITK_ok)
    {
        fprintf(logfileptr,"ERROR unlock group : error %d from AOM_unlock\n", stat);
        return stat;
    }
    
    return ITK_ok;
}

/*--------------------------------------------------------------------------*/

static int  create_user( const char *  user_id, const char *  user_name, const char *  password, const char *  osuser,
                         tag_t role_tag , tag_t  group_tag, tag_t *  user_tag,
                         logical *new_user_created )
{
    int  purchased_lic = 0;
    int  used_lic     = 0;
   
    int  stat = SA_find_user( user_id, user_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR creating user \"%s\": %d from SA_find_user.\n", user_id, stat );
        return stat;
    }
    if ( *user_tag != NULLTAG) 
    {
        if( verbose_flag) fprintf( stderr,"User \"%s\" already exists.\n",user_id);
        *new_user_created = false;
        return stat;
    }

    //  If the user does not exist, create it
    if ( *user_tag == NULLTAG )
    {
        if ( user_name != 0 )
        {
            *new_user_created = true;
            
            /* Create a user privileged user - SA users must be created interactively. */
            stat = SA_create_user( user_id, user_name, password, user_tag );
            if ( stat != ITK_ok )
            {
                fprintf( logfileptr,"ERROR creating user \"%s\": %d from SA_create_user.\n", user_id, stat );
                if( stat == SA_person_not_found )
                {
                    if ( logfileptr )
                        fprintf( logfileptr,"ERROR: Person not found\n");
                
                }
                return stat;
            }
            stat = SA_set_os_user_name( *user_tag, (osuser != 0) ? (char *)osuser : (char *)user_id );
            if ( stat != ITK_ok )
            {
                fprintf( logfileptr,"ERROR creating user \"%s\": %d from SA_set_os_user_name.\n", user_id, stat );
                return stat;
            }
        }
        else
        {
            if( logfileptr )
            {
                fprintf(logfileptr,"ERROR: No Person Name specified for user [%s].\n",user_id);
            }
            return !ITK_ok;
        }
        
    }
    // If the group is specfied, set this group as the login group
    if ( group_tag != NULLTAG )
    {
        stat = SA_set_user_login_group( *user_tag, group_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR creating user \"%s\": %d from SA_set_user_login_group.\n", user_id, stat );
            return stat;
        }
        
        
        stat = AOM_save( *user_tag );
        if ( stat != ITK_ok )
        {
            AOM_unlock( *user_tag );
            fprintf( logfileptr,"ERROR saving user \"%s\": %d from AOM_save.\n", user_id, stat );
            return stat;
        }
        
        stat = AOM_unlock( *user_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR unlocking user \"%s\": %d from AOM_unlock.\n", user_id, stat );
            return stat;
        }
    }

    if ( *user_tag != NULLTAG )
    {

         /*------------------------------------------------------*/
         /* Setting newly created user license level to "Author" */
         /*------------------------------------------------------*/

         stat = AOM_lock( *user_tag );
         if ( stat != ITK_ok )
         {
            fprintf( logfileptr,"ERROR unlocking user \"%s\": %d from AOM_unlock.\n", user_id, stat );
            return stat;
         }
         stat = POM_set_user_license_status( *user_tag, 0, 0, &purchased_lic, &used_lic );
         if ( stat != ITK_ok )
         {
            fprintf( logfileptr,"ERROR setting license level to user \"%s\": %d from POM_set_user_license_status.\n", user_id, stat );
            return stat;
         }
         stat = AOM_save( *user_tag );
         if ( stat != ITK_ok )
         {
            fprintf( logfileptr,"ERROR saving user \"%s\": %d from AOM_save.\n", user_id, stat );
            return stat;
         }
         stat = AOM_unlock( *user_tag );
         if ( stat != ITK_ok )
         {
            fprintf( logfileptr,"ERROR unlocking user \"%s\": %d from AOM_unlock.\n", user_id, stat );
            return stat;
         }

    }
    
    if ( verbose_flag )
    {
        printf( "Created User [%s].\n", user_id );
    }
    
    return ITK_ok;
}

/*--------------------------------------------------------------------------*/

static int  create_groupmember( tag_t  user_tag, tag_t  group_tag, tag_t  role_tag,
    logical new_user_created, tag_t *  member_tag, const char * grp_admin, const char * default_grp )
{
    logical admin_option = false;

    char  user_id[SA_user_size_c + 1];
    SA_ask_user_identifier( user_tag, user_id );
    char  *group_name;
    SA_ask_group_full_name( group_tag, &group_name );

    logical groupmember_needs_to_be_created = true;
    
    
    if( verbose_flag ) fprintf( stderr,"Assigning user to given group\n");
    
    int  n_members;
    tag_t *  member_tags;
    int stat = SA_find_groupmembers( user_tag, group_tag, &n_members, &member_tags );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR %d finding groupmembers.\n", stat );
        return stat;
    }
    //  Check to see if such a member already exists - if so, no need to do anything, return success
    for ( int  inx = 0; inx < n_members; inx++ )
    {
        tag_t  gm_role;
        stat = SA_ask_groupmember_role( member_tags[inx], &gm_role );
        if ( stat != ITK_ok )
        {
            MEM_free( member_tags );
            fprintf( logfileptr,"ERROR %d asking role of groupmember.\n", stat );
            return stat;
        }
        #ifdef DEBUG
        printf( "n_members: '%d'\n", n_members );
        printf( "inx: '%d'\n", inx );
        #endif

        if ( gm_role == role_tag )
        {
            // If the member is found and has the intended role
            #ifdef DEBUG
            printf( "member found with given role\n" );
            #endif
            if ( grp_admin != NULL )
            {
                stat = AOM_refresh( member_tags[inx], true );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d locking group member.\n", stat );
                    return stat;
                }

                stat = SA_set_groupmember_group_priv( member_tags[inx], TRUE );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d set group member admin.\n", stat );
                    return stat;
                }

                stat = AOM_save( member_tags[inx] );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d save group member admin.\n", stat );
                    return stat;
                }

                stat = AOM_unlock( member_tags[inx] );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d unlock group member admin.\n", stat );
                    return stat;
                }

#ifdef DEBUG
    printf( "-set group admin (member exists)\n" );
#endif
            }
            if ( default_grp != NULL )
            {
                stat = AOM_refresh( user_tag, true );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d locking group member.\n", stat );
                    return stat;
                }

        #ifdef DEBUG
                printf( "group_tag: '%d'\n", group_tag );
                printf( "member_tags[inx]: '%d'\n", member_tags[inx] );
                printf( "user_tag]: '%d'\n", user_tag );
        #endif
                stat = AOM_refresh( group_tag, true );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d locking group .\n", stat );
                    return stat;
                }
                stat = SA_set_group_default_role( group_tag, role_tag );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR setting default role: %d from SA_set_group_default_role.\n", stat );
                    return stat;
                }
                stat = AOM_save( group_tag );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d save group.\n", stat );
                    return stat;
                }

                stat = AOM_unlock( group_tag );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d unlock group .\n", stat );
                    return stat;
                }
                stat = SA_set_user_login_group( user_tag, group_tag );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR setting default group: %d from SA_set_user_login_group.\n", stat );
                    return stat;
                }
                stat = AOM_save( user_tag );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d save group member admin.\n", stat );
                    return stat;
                }

                stat = AOM_unlock( user_tag );
                if ( stat != ITK_ok )
                {
                    fprintf( logfileptr,"ERROR %d unlock group member admin.\n", stat );
                    return stat;
                }

        #ifdef DEBUG
            printf( "-set default group (member exists)\n" );
        #endif
            }
            //  groupmember with correct role already exists, so Return NOW
            MEM_free( member_tags );
            
            return ITK_ok;
        }
        else
        {
#ifdef DEBUG
            printf( "Member with correct Role not found\n" );
#endif
            // If this user is created afresh and a member is found 
            // but with a incorrect role, delete the member.
            /*if( new_user_created )
            /{
                stat = POM_delete_member(member_tags[inx]);
            }
            new_user_created = false;*/
        }

    }
    if (new_user_created)
    {
        groupmember_needs_to_be_created = false;
        *member_tag = member_tags[0];
    }
    MEM_free( member_tags );
    
    // In this case, user is created, is being assigned to group now
    if ( grp_admin != NULL )
        admin_option = true;
    else
        admin_option = false;

    if (groupmember_needs_to_be_created)
    {
        //stat = SA_create_groupmember( group_tag, user_tag, false, member_tag );
        stat = SA_create_groupmember( group_tag, user_tag, admin_option, member_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d create group member.\n", stat );
            return stat;
        }
           /** Assign the new Role to the Group Member */
        stat = AOM_refresh( *member_tag, true );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d locking group member.\n", stat );
            return stat;
        }
        stat = SA_set_groupmember_role( *member_tag, role_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d set group member role.\n", stat );
            return stat;
        }

        stat = AOM_save( *member_tag );
        if ( stat != ITK_ok )
        {
            AOM_unlock( *member_tag );
            char  user_id[SA_user_size_c + 1];
            SA_ask_user_identifier( user_tag, user_id );
            char  group_name[SA_name_size_c + 1];
            SA_ask_group_name( group_tag, group_name );
            fprintf( logfileptr, "ERROR assign user \"%s\" to group \"%s\": %d from AOM_save.\n", user_id, group_name, stat );
            return stat;
        }
        stat = AOM_unlock( *member_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR unlock member : %d from AOM_unlock.\n", stat );
            return stat;
        }
                
    #ifdef DEBUG
        printf( "-set group admin (create member)\n" );
    #endif
    }
    if ( new_user_created && grp_admin != NULL)
    {
        stat = AOM_refresh( *member_tag, true );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d locking group member.\n", stat );
            return stat;
        }

        stat = SA_set_groupmember_group_priv( *member_tag, TRUE );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d set group member admin.\n", stat );
            return stat;
        }
        
        stat = AOM_save( *member_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d save group member admin.\n", stat );
            return stat;
        }

        stat = AOM_unlock( *member_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d unlock group member admin.\n", stat );
            return stat;
        }
    }
    if ( !new_user_created && default_grp != NULL )
    {
        stat = AOM_refresh( user_tag, true );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d locking group member.\n", stat );
            return stat;
        }

#ifdef DEBUG
        printf( "group_tag: '%d'\n", group_tag );
        printf( "member_tags[inx]: '%d'\n", member_tags[inx] );
        printf( "user_tag]: '%d'\n", user_tag );
#endif
        stat = AOM_refresh( group_tag, true );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d locking group .\n", stat );
            return stat;
        }
        stat = SA_set_group_default_role( group_tag, role_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR setting default role: %d from SA_set_group_default_role.\n", stat );
            return stat;
        }
        stat = AOM_save( group_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d save group.\n", stat );
            return stat;
        }

        stat = AOM_unlock( group_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d unlock group .\n", stat );
            return stat;
        }
        stat = SA_set_user_login_group( user_tag, group_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR setting default group: %d from SA_set_user_login_group.\n", stat );
            return stat;
        }
        stat = AOM_save( user_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d save group member admin.\n", stat );
            return stat;
        }

        stat = AOM_unlock( user_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d unlock group member admin.\n", stat );
            return stat;
        }

#ifdef DEBUG
    printf( "-set default group (member exists)\n" );
#endif
    }
    if( new_user_created )
    {
        /** Assign the new Role to the Group Member */
        stat = AOM_refresh( *member_tag, true );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d locking group member.\n", stat );
            return stat;
        }
        stat = SA_set_groupmember_role( *member_tag, role_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR %d set group member role.\n", stat );
            return stat;
        }

        stat = AOM_save( *member_tag );
        if ( stat != ITK_ok )
        {
            AOM_unlock( *member_tag );
            char  user_id[SA_user_size_c + 1];
            SA_ask_user_identifier( user_tag, user_id );
            char  group_name[SA_name_size_c + 1];
            SA_ask_group_name( group_tag, group_name );
            fprintf( logfileptr, "ERROR assign user \"%s\" to group \"%s\": %d from AOM_save.\n", user_id, group_name, stat );
            return stat;
        }
        stat = AOM_unlock( *member_tag );
        if ( stat != ITK_ok )
        {
            fprintf( logfileptr,"ERROR unlock member : %d from AOM_unlock.\n", stat );
            return stat;
        }
        
    }
    if ( verbose_flag )
    {
        
#ifdef DEBUG
        printf( "Assigned User %s to Group %s\n", user_id, group_name );
#endif
    }
    MEM_free(group_name);
    return ITK_ok;
}

/*--------------------------------------------------------------------------*/

static int  find_volume( const char *  vol_name, tag_t *  vol_tag )
{
    int         retcode;
    const char *paths[SS_NUM_MTYPES];
    static const char *empty = "";
    

    /*  Does the volume exist in the database? */
    if((retcode = VM_find(vol_name,vol_tag)) != ITK_ok)
    {
        fprintf(logfileptr, "ERROR in VM_find(), error %d\n", retcode);
        return retcode;
    }

    return ITK_ok;
}

/*--------------------------------------------------------------------------*/

//  grant the access to the group with the specified volume name from command line
static int  assign_volume_to_group( tag_t  vol_tag, tag_t  group_tag )
{
    char  volume_name[VM_name_size_c + 1];
    int  stat = VM_ask_name( vol_tag, volume_name );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr, "ERROR in VM_ask_name : %d\n", stat );
        return stat;
    }

    //  grant the access to group with specified volume
    stat = VM_grant_access( vol_tag, group_tag );
    if ( stat != ITK_ok )
    {
        char  group_name[SA_name_size_c + 1];
        SA_ask_group_name( group_tag, group_name );
        fprintf(logfileptr,
            "ERROR in VM_grant_access: group = \"%s\" volume = \"%s\": %d \n",
            group_name, volume_name, stat );
        return stat;
    }

    if ( verbose_flag )
    {
        char  group_name[SA_name_size_c + 1];
        SA_ask_group_name( group_tag, group_name );
        printf( "Granted access to volume \"%s\" for group \"%s\" \n", volume_name, group_name );
    }

    //  if group has default volume
    char  defvolname[ SA_volume_name_size_c + 1];
    stat = SA_ask_group_volume_name( group_tag, defvolname );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR in SA_ask_group_volume name : %d.\n", stat );
        return stat;
    }

    if ( strlen( defvolname ) > 0 )
    {
        //  already has a default volume set
        return ITK_ok;
    }

    //  set the group default volume to specified volume
    stat = AOM_lock( group_tag );
    if ( stat != ITK_ok )
    {
        char  group_name[SA_name_size_c + 1];
        SA_ask_group_name( group_tag, group_name );
        fprintf( logfileptr,"ERROR locking group \"%s\": %d from SA_set_group_volume_name.\n", group_name, stat );
        return stat;
    }

    stat = SA_set_group_volume_name( group_tag, volume_name );
    if ( stat != ITK_ok )
    {
        char  group_name[SA_name_size_c + 1];
        SA_ask_group_name( group_tag, group_name );
        fprintf( logfileptr,"ERROR  in SA_set_group_volume_name: group = \"%s\" volume = \"%s\": %d \n",
                 group_name, volume_name, stat );
        return stat;
    }

    stat = AOM_save( group_tag );
    if ( stat != ITK_ok )
    {
        char  group_name[SA_name_size_c + 1];
        SA_ask_group_name( group_tag, group_name );
        fprintf( logfileptr,"ERROR assigning volume \"%s\" to group \"%s\": %d from AOM_save.\n",
                 volume_name, group_name, stat);
        return stat;
    }

    stat = AOM_unlock( group_tag );
    if ( stat != ITK_ok )
    {
        char  group_name[SA_name_size_c + 1];
        SA_ask_group_name( group_tag, group_name );
        fprintf( logfileptr, "ERROR unlock group \"%s\": %d from AOM_unlock.\n",
                 group_name, stat);
        return stat;
    }

    if ( verbose_flag )
    {
        char  group_name[SA_name_size_c + 1];
        SA_ask_group_name( group_tag, group_name );
        printf( "Set group \"%s\" default volume to \"%s\".\n", group_name, volume_name );
    }
    return ITK_ok;
}
/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                    */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */                                                                          
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  10/21/2004      Ramesh Ramaiah            Initial Creation              */
/****************************************************************************/
/*
int readAndDecryptPasswd( char *passwdFile, // <I>
                            char **passwd )    // <O> 
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;
    
    
    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
       //  Remove the trailing new-line added by fgets 
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        if( logfileptr )
        fprintf( logfileptr, "ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);
    
    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }
    
    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;
    
    return ifail;
        
}*/

/*--------------------------------------------------------------------------*/

static void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: fdt_load_tc_org_str <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -person=<name>    creates a person of the given name.\n");
        printf(" -user=<User ID>   creates a user of the given name.\n");
        printf(" -password=<pswd>  ensure the user has the given password.\n");
        printf(" -OSuser=<os user> the os user id.\n");
        printf(" -email=<email>    the email address of the person.\n");
		printf(" -ph_no=<Phone no>   Phone number of the person.\n");
		printf(" -dept_name=<dept name>  the department name of the person.\n");
		printf(" -dept_no=<dept no>  the department number of the person.\n");
        printf(" -group=<name>     creates a group of the given name.\n");
        printf(" -role=<name>      creates a role of the given name.\n");
        printf(" -volume=<name>    specifies name of volume to be assigned to given group\n");
        printf(" -default_grp      is a flag that makes the given group the default group for the user.\n" );
        printf(" -grp_admin        is a flag that makes the given user a group admin of the given group.\n" );
        printf(" -file=<filename>  input file to create users,groups,roles etc after other args are processed.\n");
        printf("                   Each record in the file contains the    following in the order specified:\n\n");
        printf("                   person|user|password|osuser|e-mail|group|role|volume|default_grp|grp_admin|ph_no|dept_name|dept_no|\n\n");
        printf("                   where, a [X] will be used to specify that the given group is the Default Group\n");
        printf("                   or the given user is a Group    Administrator in the last two fields respectively\n\n");
        printf(" -v                is a flag that will turn on verbose mode\n");
        printf("\n");
        printf(" NOTE:- \n");
        printf(" A Person, Group and Role must be specified for a new user.\n\n");
        printf(" A Group and Role must be specified for an existing user.\n\n");
        printf(" While Creating a user if Password and/or OS User is not specified,\n");
        printf(" the User ID will be used.\n\n");
        printf("**********************************************************************************\n\n");
        
}
