/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#include <string>
#include <map>

#include <o6tanecustomservice1706.hxx>


#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace O6::Soa::CustomServiceLibrary::_2017_06;

const std::string O6TaneCustomService::XSD_NAMESPACE ="http://o6.com/Schemas/CustomServiceLibrary/2017-06/O6TaneCustomService";




void O6TaneCustomService::TargetObjecs::serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName )
{


    _sdmStream->writeOpenElement2( O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomService::XSD_NAMESPACE, elementName );
    _sdmStream->writeOpenElementClose(  O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomService::XSD_NAMESPACE, false );
    std::string _prefix =  _sdmStream->getNamespacePrefix( O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomService::XSD_NAMESPACE );

    _sdmStream->writeStructMember( _prefix+"displaynames", displaynames );
    _sdmStream->writeStructMember( _prefix+"realnames", realnames );
    _sdmStream->writeStructMember( _prefix+"nrPattern", nrPattern );
    _sdmStream->writeCloseElement(  O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomService::XSD_NAMESPACE, elementName  );
}




O6TaneCustomService::O6TaneCustomService()
{
}

O6TaneCustomService::~O6TaneCustomService()
{
}

