/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_06_O6TANECUSTOMSERVICE_IMPL_HXX 
#define TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_06_O6TANECUSTOMSERVICE_IMPL_HXX

#include <vector>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <iostream>
#include <cstring>

#include <textsrv/textserver.h>
#include <o6tanecustomservice1706.hxx>

#include <CustomServiceLibrary_exports.h>
#include <tc/emh.h>
#include <common/emh_const.h>


#define SEEDS_SAVEAS_TARGET_MAPPINGS "SEEDS_SaveAs_target_mappings"
#define SEEDS_SAVEAS_DEEP_COPY_RULES "SEEDS_SaveAs_deep_copy_rules"
#define SEEDS_PERCENT_VALUE_ATTRIBUTE "SEEDS_INCI_percent_attribute_name"
#define SEEDS_CUSTOM_ERROR_BASE (EMH_USER_error_base + 600)

using namespace Teamcenter::Soa::Server;

struct targetInfo
{
	char* targettype = NULL;
	char* relation = NULL;
	char* actiontype = NULL;
	char* bomaction = NULL;
	struct targetInfo *next = NULL;
};

struct deepCopyTargetInfo
{
	char* targettype = NULL;
	char* primsec = NULL;
	char* relation = NULL;
	char* actiontype = NULL;
	struct deepCopyTargetInfo *next = NULL;
};

struct SkippedINCIInfo
{
	char* pcINCIId               = NULL;
	char* pcINCName              = NULL;
	char* pcAllergenValue        = NULL;
	char* pcApplType             = NULL;
	char* pcImpurete             = NULL;

	double dTotalPercentage      = 0.0;

	struct SkippedINCIInfo *next = NULL;
};

#define ITK( argument )						                                \
{									                                        \
	if (retcode == ITK_ok)													\
	{																		\
		retcode = argument;                                                 \
		if ( retcode != ITK_ok )											\
		{																	\
			char* s;                                                        \
			TC_write_syslog( " "#argument "\n" );                           \
			TC_write_syslog( "  returns [%d]\n", retcode );                 \
			EMH_ask_error_text (retcode, &s);                               \
			EMH_store_error(EMH_severity_error,retcode);                    \
			TC_write_syslog( "  Teamcenter Error: [%s]\n", s);              \
			TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
			if (s != 0) MEM_free (s);                                       \
		}                                                                   \
	}																		\
}

int getTargetTypeInfo(tag_t, struct targetInfo **, char*);
int getTargetTypeInfo(tag_t, struct deepCopyTargetInfo **, char*);
int isUpdateRequired(tag_t, struct targetInfo *, bool *, tag_t *);
int create_target_and_copy_attrs_from_source(tag_t,tag_t, struct targetInfo *, string, string, ServiceData *);

namespace O6
{
    namespace Soa
    {
        namespace CustomServiceLibrary
        {
            namespace _2017_06
            {
                class O6TaneCustomServiceImpl;
            }
        }
    }
}


class SOACUSTOMSERVICELIBRARY_API O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomServiceImpl : public O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomService

{
public:

    virtual O6TaneCustomServiceImpl::TargetObjecs getTargets ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj );
	virtual Teamcenter::Soa::Server::ServiceData copyObjectAndCreateRelation ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj, const std::string targetItemtype );
    virtual Teamcenter::Soa::Server::ServiceData calculateINCIs ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj );

};

#include <CustomServiceLibrary_undef.h>
#endif
