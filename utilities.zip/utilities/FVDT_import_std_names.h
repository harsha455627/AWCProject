/******************************************************************************
 * Filename        :   fve_create_std_names.h
 * Description     :   Defines the macro used in fve_create_std_names.c
 * Module          :   fve_create_signal_unit.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * June, 18 2010    Bakul Bernard      Initial Code
 * Apr , 25 2012    Saroj Kumar        Added fv9AbbSignalName for "Abbreviated Signal Name"
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_CREATE_STD_NAMES_H
#define FVE_CREATE_STD_NAMES_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>

/*************************************************
* Macros Definition
**************************************************/

#define OBJ_NAME_ATTR			"object_name"
#define COMP_NAME_ATTR			"FVDTCompName"
#define SUBSYS_NAME_ATTR			"FVDTSubSysName"
#define SUBSYS_ID_ATTR			"FVDTSubSysID"
#define SIG_NAME_ATTR			"FVDTSignalName"
#define SIG_SUB_SYS_NAME_ATTR			"FVDTSigSubSysName"
#define SIG_SYS_NAME_ATTR			"FVDTSigSysName"
#define SIG_CIRCUIT_NUM_ATTR			"FVDTCircuitNum"
#define FILEMGMT_ECU_NAME_ATTR			"FVR_ECUName"
#define SIG_ABB_SIG_NAME_ATTR			"fv9AbbSignalName"
#define PAAT_RATING_ATTR            "fv9CorpPAATRating"

#define COMP_CLASSNAME_CONST			"FVDTStdCompName"
#define SUBSYS_CLASSNAME_CONST			"FVDTStdSubSysName"
#define SIG_CLASSNAME_CONST			"FVDTStdSignalName"
#define ECU_DOCSET_CLASSNAME_CONST			"FVRECUDocSetName"
#define COMP_SYSTEM_REVIEWER        "fv9SystemReviewer"
#define COMP_DESIGNATION            "fv9ComponentDesignation"
#define PAAT_CLASSNAME_CONST        "FV9CorpPAATRating"

#define PASSWORDKEY     "PASSWORDKEY"
#define DT_TMP_DIR_VAR  "FVDT_UTIL_IMP_LOG_DIR"

#define DATE_FORMAT_STR			"%m%d%Y_%H%M%S"

#define MAXINPUTLINELEN 2000
/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\

#define FVDT_FREE(p) {\
    if ( p != NULL ) {\
        MEM_free(p);\
        p = NULL;\
    }\
}
/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

#define DATE_FORMAT      "%d-%b-%Y"

#define ITK(x) \
{\
   if ( ifail == ITK_ok )\
   {\
      if((ifail = (x)) != ITK_ok)\
      {\
         dump_itk_errors ( ifail, #x, __LINE__, __FILE__ );\
      }\
   }\
}\

#define FVDT_FREE_ARRAY(p, count) {\
	int i = 0;\
   if ( p != NULL ) {\
        for(i = 0; i < count; i++) {\
            if(p[i] != NULL) {\
                MEM_free(p[i]);\
                p[i] = NULL;\
            }\
        }\
        MEM_free(p);\
        p = NULL;\
    }\
}\


void dump_itk_errors( int stat, const char * prog_name, int lineNumber, 
					 const char * fileName );

void get_time_stamp(char* format, char** timestamp);
int FVDT_WSO_uniq_check(char** Attributes, char*className, int* num);
int FVE_create_name(char ** Attributes, int * created_cnt, char *className,
					int * failed_cnt);
int FVDT_validate_data_in_file (char ** Attributes, int count, char *classname, int line_count,int *isValid);

#endif /* FVE_CREATE_STD_NAMES_H */
