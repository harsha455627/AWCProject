//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#ifndef TEAMCENTER_CLIENTX_SOAPARTIALERRORLISTENER_HXX
#define TEAMCENTER_CLIENTX_SOAPARTIALERRORLISTENER_HXX





#include <string>
#include <vector>



#include <teamcenter/soa/client/ErrorStack.hxx>
#include <teamcenter/soa/client/PartialErrorListener.hxx>





namespace Teamcenter
{
    namespace ClientX
    {
        class AppXPartialErrorListener;



/**
 * Implementation of the PartialErrorListener. Print out any partial errors
 * returned.
 *
 */
class  AppXPartialErrorListener: public Teamcenter::Soa::Client::PartialErrorListener
{
public:

    virtual void handlePartialErrors( const std::vector< Teamcenter::Soa::Client::ErrorStack >& stacks);

};


}} //end namespace
#endif



