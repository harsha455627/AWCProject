//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6RegisterHandlers
 *
 */
#include <O6TaneCustomLibrary/O6RegisterHandlers.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <O6TaneCustomLibrary/O6ActionHandlers.hxx>
#include <O6TaneCustomLibrary/O6ExtractCSV.hxx>
#include <O6TaneCustomLibrary/O6_EPM_set_property.hxx>


/**
 * Function    :  o6Register_action_handler
 * Description :  Used to register custom action handlers.
 * Input       :
 */
/*
int o6Register_rule_handler(){
	int retcode = ITK_ok;

	 // add code here to register rule handler.

	return retcode;
}
*/

/**
 * Function    :  o6Register_action_handler
 * Description :  Used to register custom action handlers.
 * Input       :
 */
int o6Register_action_handler(){
	int retcode = ITK_ok;

	 //add code here to register action handler.
	ITK ( EPM_register_action_handler ( "O6_Hdlr_SharepointPublishing", "O6_Hdlr_SharepointPublishing", O6_export_data ) );
	ITK ( EPM_register_action_handler ( "O6_Hdlr_QQCalculation", "Quali-Quanti Calculation", o6_quali_quanti_calc ) );
	ITK ( EPM_register_action_handler ( "O6_SEEDS_SEC_CSV_Extraction", "CSV Extraction for Formule and GEN RM", O6_SEEDS_Sec_extract_csv ) );
	ITK ( EPM_register_action_handler ( "O6_Hdlr_SetProperty", "Handler to set cost calculation property value", O6_EPM_set_property ) );

	//Extra set of Handlers merged with BMIDE later
	ITK ( EPM_register_action_handler ( "O6Stock_manage_request", "", O6Stock_manage_request ) );
	ITK ( EPM_register_action_handler ( "O6Stock_manage_goods", "", O6Stock_manage_goods ) );
	ITK ( EPM_register_action_handler ( "O6Stock_set_goods_request_as_approved", "", O6Stock_set_goods_request_as_approved ) );
	ITK ( EPM_register_action_handler ( "O6Stock_set_goods_request_as_rejected", "", O6Stock_set_goods_request_as_rejected ) );
	ITK ( EPM_register_action_handler ( "O6Stock_set_goods_request_as_cancelled", "", O6Stock_set_goods_request_as_cancelled ) );

	return retcode;
}


/**
 * Function    :  O6RegisterHandlers
 * Description :  Extension function to register custom handlers.
 * Input       :
 */
int O6RegisterHandlers( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
   int retcode = ITK_ok;

   /**
    * Uncomment below function to register rule handler.
    */
   //ITK(o6Register_rule_handler());

   /**
    * Function to register action handler.
    */
   ITK(o6Register_action_handler());

 return retcode;

}
