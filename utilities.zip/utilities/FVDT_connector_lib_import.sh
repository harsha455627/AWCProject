#!/usr/bin/ksh

# ---------------------------------------------------------------------------------------------
#NOTE - This is the only utility to import standard mating connector into Teamcenter


# Inputs:
# 1. InputFile - Input file containing metadata for connector that is extracted from CHS. 
# 2. InputDir - Directory contains all the images for connector
# 3. emailID - The person who would be notified with email attachment


# Set the TC environment

export TC_ROOT=/apps/tc_vsem/11.2/sun
export TC_DATA=/data/fna1lv1/cfg1

. $TC_DATA/tc_profilevars
export TC_USE_LOV_SHARED_MEMORY=FALSE
export LOG_FILE_DIR=/data/fna1lv1/cfg1/../log

export FVDT_UTIL_IMP_LOG_DIR=$LOG_FILE_DIR/CONNECTOR_IMPORT_`date +%b_%d_%Y_%H_%M`

mkdir $FVDT_UTIL_IMP_LOG_DIR 2> /dev/null

if [ ! -f "$1" ]
then
      echo "ERROR: Input file $1 does not exist.\n" | \
      mailx -s "FVDT_connector_lib_import.sh failure" $2
      exit 1
fi

if [ ! -d "$2" ]
then
      echo "ERROR: Input Image Directory $2 does not exist.\n" | \
      mailx -s "FVDT_connector_lib_import.sh failure" $2
      exit 1
fi


$TC_ROOT/fve_kit/server/utilities/FVDT_connector_lib_import -f=$1 -dir=$2 

if [ ! -z $3 ]
then
   cd $FVDT_UTIL_IMP_LOG_DIR

   command=""
   for i in `ls *.txt *.log`
   do
     command=$command"uuencode $i $i;"
   done

   (echo "Standard Connector Import logs" ; eval $command)  | mailx -s 'Standard Connector Import Reports' $3
fi

