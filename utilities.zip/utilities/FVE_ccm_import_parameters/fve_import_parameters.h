/******************************************************************************
 * Filename        :   fve_import_parameters.h
 * Description     :   Defines the macro used in fve_import_parameters.c
 * Module          :   fve_import_parameters.exe
 * ENVIRONMENT     :   C,ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * 03-Apr-2012    Swapnal Shewale	      Initial Code
 * 08-June-2012   Swapnal Shewale     Added function to create the Cells(Min/Max/Init) during update of Int/Dbl Parameter Definition.
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_IMPORT_PARAMETERS_H
#define FVE_IMPORT_PARAMETERS_H

/*************************************************
* System Header Files
**************************************************/
#include <fve_includes.h>

#define PASSWORDKEY     "PASSWORDKEY"

//structure to store  information related to Parameter Definitions
struct FVEParmDefInfostruct
{
	char*	name;
	char*	type;
	char*	descr;
	char*	paraUsage;
	char*	paraType;
	char*	engUnit;
	char*   msaUnit;
	int		rowCnt;
	int		colCnt;
	char*	size;
	char*	numerator;
	char*	denominator;
	char*   precision;
	char*	tolerance;
	char*	structureOfData;
	char*	rowLabels;
	char*	colLabels;
	char*   minVal;
	char*	initVal;
	char*	maxVal;
	char*	validValues;
	logical overWritable;   //attr on Model Specific Attr Form
	char*	implDataType;
	char*	implResolution;
	char*	offset;        //this offset will used for Model Specific Attribues(FVE_MSAOffset) or for ParmDef(FVE_Offset) or for both?
	char*	src;
	char*	snk;
	char*	local;
	char*	srcSnk;
	char	*faultVal;     
	char*	restricted;    
	char*   inhaleExhale; 
	char*	asBuiltVehOp;  
	char*	moduleManf;    
	char*	fcsdCustPref;  
	char*   configGrp;
	char*	domainElName;  
	char*	domainElVal;
	char*	domainElDescr;
	char*	groupName;
	char*   typeOfData;
};

//structure to store  information related to Process Object
struct FVEProcessInfostruct
{
	char *processName;
	char *processType;
	char *featureName;
	char *taskRate;
};

//structure to store information for configuration file
struct FVEConfigFileInfostruct
{
	char	*constantName;
	char	*lofFileName;
	char	*logFilePath;
	char	*logFileExt;
	char	*csvFileDelim;
	char	*tolerance;
};


static void print_usage(void);

//validate file arguments
int FVE_validate_arguments(char *modeName);
int FVE_validate_file(char *modeName);
//validate required arguments before creating object for Int/Dbl/Sed
int FVE_validate_required_attributes(FILE *filePtr,struct FVEParmDefInfostruct *parmInfoStruct,int counter, logical *reqAttrPresent);

//parse the line with given delimeter.get the strings before delimeter and after delimeter.
int fve_get_val_line(char *delim,char *line_temp,char *locName,char **firstStr,char **secondStr);

//common functions used from other files
int FV_handle_missing_arg_error(const char* functionName, char* argumentName);
int FV_object_is_typeof(tag_t obj_tag, char* typename, logical* answer);
void get_time_stamp(char* format, char** timestamp);
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );
void fve_get_value(char * init_value, char ** attr, logical * is_value_null);
int FVE_get_precision(char *str, int *lengthBeforeDot,int *lengthAfterDot);
int FV_createPreciseStructure(tag_t itemTag,tag_t revisionTag,tag_t *topDicBl,tag_t *topWindow,logical inContextMode);
int FVE_gsdb_find_wso_with_attr( char *class_name, char *attr_name, char *attr_value,tag_t **obj_tags, int *num_values );
extern int FV_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag);
int FV_check_bom_views_exist(tag_t revision);
int FV_set_stringValue_object(tag_t objTag,char *propName,char *propVal);
int FVE_find_rev(char* item_id,	char* rev_id, tag_t* rev);
extern int FV_parse_string_with_string(char* targetString, const char* delimiterString,int* stringCnt, char*** stringArray);
extern char* FV_int_to_static_string(int intValue);
extern int FV_strndup(const char* inputString, char** outputString, int charCnt);
extern int FV_strdup(const char* inputString, char** outputString);
extern int FV_copy_string_to_array(int* stringCnt, char*** stringArray, char* addString);
extern int FV_add_string_pointer_to_array(int* stringCnt, char*** stringArray, char* addString);
extern int FV_strcat(char** string, char* addString);

//update parameter definitions
int FVE_set_rowColumns(tag_t parmDefRev,int Rows,int Columns,logical flagRowLabel,logical flagColLabel,char **rowlabelArr,char **colLabelArr);
int FVE_create_cells(tag_t parmDefRev,int newNumRows,int oldNumRows,int newNumCols,int oldNumCols,char *propName,char **valDomainElName,char **valDomainElVal,char **valDomainElDescr);
int FV_create_cells_labels(tag_t revision,int new_Rcount,int old_Rcount , char *rowPropName ,char **rowPropValues,int new_Colcount,int old_Colcount , char *colPropName ,char **colPropValues);


int FVE_set_value(tag_t rev,char *attr,char *val);
int FVE_set_sedValidValues(tag_t rev,char *attr,char **valDomainElName,char **valDomainElVal,char **valDomainElDescr);
int FVE_get_value_arrays(tag_t rev, char *attr,char *** value_array);
int FVE_get_desc_array(tag_t rev, char *attr,char *cellsProp,char *** value_array,int * retCnt);
int FVE_create_cells_MinMaxInit(tag_t parmDefRev,int newNumRows,int oldNumRows,int newNumCols,int oldNumCols,char *propName,char *value);
int FVE_set_values(tag_t rev,char *propName,char **valArray,int valCnt);
int FVE_get_labels(tag_t revision,char *propName,int *labelCnt, char *** labelNames);


//navigate structure on name to get the tag , 
int FVE_check_objName_existIn_Structure(tag_t dictBl,char *name,tag_t *retunObj);

//compare properties
//int FVE_compare_properties(struct FVEParmDefInfostruct *parameterInfo,int counter,tag_t tagOldParmRevBl);
int FVE_compare_properties(struct FVEParmDefInfostruct *parameterInfo,int counter,tag_t tagOldParmRevBl,tag_t	*newBomLineTag);
int FVE_compare_process_object(struct FVEProcessInfostruct *processInfo,int counter,tag_t tagOldProcessObject);

//common function for string
int fv_strdup(const char* inputString, char** outputString);
extern int FV_strdup_plus(const char* inputString, int extraCnt, char** outputString);
extern char* FV_trim_blanks(char* inputStr);
extern char* FV_trim_invalidChars(char* inputStr);
int split_the_string(char *consolidated_str,char *delim, int * str_cnt, char *** splitted_strings);
int FVE_remove_invalidChars(char *str,char **result);

//free memory for structure variables
void FVE_initialize_ParmStructure(struct FVEParmDefInfostruct * parmReportStruct);
void FVE_initialize_ProcessStructure(struct FVEProcessInfostruct * parmProcessStruct);
void FVE_initialize_ConfigFiletructure(struct FVEConfigFileInfostruct * configInfoStruct);
void FVE_MemFreeStructParameter(struct FVEParmDefInfostruct * parmReportStruct);
void FVE_MemFreeStructProcess(struct FVEProcessInfostruct *parmProcessStruct);
void FVE_MemFreeStructConfigFile(struct FVEConfigFileInfostruct *configInfoStruct);

//parse file functions
//int FVE_parse_parmDefFile(FILE  *flPtrParmDef,char *delim,struct FVEParmDefInfostruct *parameterInfo);
int FVE_parse_parmDefFile(FILE  *flPtrParmDef,char *delim);
int FVE_parse_processFile(FILE *flPtrProcess,char *delim,struct FVEProcessInfostruct *processInfo);
int fve_parse_configFile(FILE *configFlPtr,char *delim,struct FVEConfigFileInfostruct *configInfo);

//function to create/update process objects
int FVE_getProcessModeOnly(struct FVEProcessInfostruct *processInfoStr,int totalNoOfProcess);

//recursive function to get the child line for "Parameter Group"
int FVE_recur_getChildParmGrpBl(tag_t bomLine,int *countGrpObject,int *countParmDefObject,tag_t *tagGrpBL);
int FVE_get_organizationChild(tag_t dictBl,tag_t *retunObj,logical *isRevise);


int FVE_createParameterDefinitions(struct FVEParmDefInfostruct *parmInfoStr,int totalNoOfParameters);

//Create/Update operations on parameter definitions based on object type
int FVE_create_operations(struct FVEParmDefInfostruct *parmInfoStruct,int counter, logical isParmTypeSame, int* revisePendingCnt, tag_t** revisePendingObjects);
int FVE_update_operations(struct FVEParmDefInfostruct *parmInfoStruct,int counter, int dicChildlineCnt, tag_t* dicChildlineTags, int* revisePendingCnt, tag_t **revisePendingObjects);


//create objects
int FVE_create_parmHex(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision);
int FVE_create_parmStr(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision);
int FVE_create_parmDbl(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision);
int FVE_create_parmInt(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision);
int FVE_create_parmSed(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t *parmDefItem,tag_t *parmDefRevision);
int FV_create_parmDefGroups(char *objType,char *objectName,char *ecuAcr,char *representsVal,tag_t *itemTag,tag_t *revTag);
int FVE_create_processObject(char *prName,char *prType,char *featureName,char *taskRate, tag_t *processObject);
int FV_createObject(char *itemTypeName,int itemAttrCnt,char **itemAttrNames,char **itemAttrValues,int revAttrCnt,char **revAttrNames,char** revAttrValues,tag_t *revTag);
int FVE_create_MSAForm(struct FVEParmDefInfostruct *parmInfoStruct,int counter,tag_t parmDefItemRev,tag_t *msaFormTag);

//FVE_Process Object
int FVE_process_object(tag_t parmDefBl,int cntObjects,char **valObjects,char *relName,tag_t inContextRev,tag_t window);
int FVE_add_process_with_relation(tag_t parentDictRev,tag_t selectedParamDefLine,tag_t fveprocess,char *relation,tag_t bomWindow);
int FVE_compare_process_basedRelation(struct FVEParmDefInfostruct *parmInfoStr,int counter,tag_t bomLine,char *relName);
int FVE_remove_process_with_relation(tag_t parentDictRev,tag_t selectedParamDefLine,tag_t objToBeRemoved,tag_t bomWindow);

//update log file contents
int FVE_update_log_file(FILE *filePtr,struct FVEParmDefInfostruct *parmInfoStruct,int counter);

int FVE_get_dictionary_status(tag_t parentDictRev,logical *flag);

int FV_add_unique_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag);
int FV_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag);
int FV_delete_pom_objects(int pomObjCnt, tag_t* pomObjTags);

int fve_check_param_type(char *value,char *structureOfdata,char **parmType);
int fve_Get_Precision_Value(char *value,char *structureOfdata,int* iPrecisionValue);

int FV_log_validation_error(int errorCode, char* parameterName);

int FVE_update_conf_group_on_update(char* oldSectionVal, char* newSectionVal);
#endif /* fve_create_grproleusr.h*/
