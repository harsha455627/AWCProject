/*************************************************************************************
* Filename	    :   FV_Reminder_Notification.c			 	
* Description   :	This utility will send reminder notifications based on the 
*					WSO- FV9_ReminderNotification.
* ENVIRONMENT	:   C, C++, ITK					
*									
* History							       
*-------------------------------------------------------------------------------------
* Date         	   Name                      Description of Change
* 03 Sep 2015      Robert Williams D         Created
* 07 Sep 2015      Robert Williams D         Changed the creteria for the recipients.
* 10 Oct 2015	   Robert Williams D		 Changed the utility with auto login.
* ------------------------------------------------------------------------------------
*							
**************************************************************************************/
#include "FV_Reminder_Notification.h"

/*******************************************************************************
 * Function Name	: FVE_reminderWSO_get_values
 * Description		: This queries the WSO-FV9_ReminderNotification and gets its 
 *					  properties values.
 * RETURN VALUE		: ifail = ITK success/failure ifail
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name                        Description of Change
 * 03 Sep 2015          Robert Williams D			Created
 *------------------------------------------------------------------------------
 ******************************************************************************/
int FVE_reminderWSO_get_values()
{
	int         ifail							 = ITK_ok;
	int         entry_count                      = 0;
	int         numWSOFound                      = 0;
	int         numEPMtaskFound                  = 0;
	int			iCntWSO							 = 0;
	int			iCntepmtask						 = 0;
	int  	    numofRecipients                  = 0;
	//int  	      numofAddRecipients               = 0;
	int			attrValCount					 = 0;
	tag_t       qry_tag                          = NULLTAG;
	tag_t       epmTask_qry_tag                  = NULLTAG;
	tag_t*      WSOResult                        = NULL;	
	tag_t*      EPMTaskResult                    = NULL;

	date_t		dPostDueDate					 = NULLDATE;
	char*		cWfName							 = NULL;
	char*		cTaskName						 = NULL;
	char*		cFrequency						 = NULL;
	char*		cStartBefore					 = NULL;
	//char*       qry_name                         = NULL;
	//char*       epmTask_qry_name                 = NULL;
	char*		caSubject						 = NULL;
	char*		caComment    					 = NULL;
	char*	    epmQryAttrNames[2]		         = { "state_value", "Template Name" };	
	char**	    epmQryAttrValues				 = NULL;	
	char**      caRecipients                     = NULL;
	//char**      caAddRecipients                  = NULL;
	char**      entries                          = NULL;
    char**      values                           = NULL;

	logical     isTaskPending					 = FALSE;

	FV_DEBUG_TXT(("Function FVE_reminderWSO_get_values started \n"))

	//qry_name = IMAN_text(FVE_REMINDER_NOTIFICATION_QRY);

    ITK(QRY_find(FVE_REMINDER_NOTIFICATION_QRY, &qry_tag))   // gets the tag of __FV9_ReminderNotification query.
    if(qry_tag == NULLTAG)
	   {
		  printf("\n\"FV9_ReminderNotification \" query is not available in tc server\n");
		  FV_DEBUG_TXT(("\n\"FV9_ReminderNotification \" query is not available in tc server\n"))
	   }
    ITK(QRY_find_user_entries(qry_tag, &entry_count, &entries, &values))
    ITK(QRY_execute(qry_tag, entry_count, entries, values, &numWSOFound, &WSOResult))
	
	for(iCntWSO = 0; iCntWSO < numWSOFound; iCntWSO++)    //gets the value of all the properties from the WSO.
    {
		cWfName							 = NULL;
		cTaskName						 = NULL;
		cFrequency						 = NULL;
		dPostDueDate					 = NULLDATE;
		cStartBefore					 = NULL;
		caSubject						 = NULL;
		caComment    					 = NULL;
		caRecipients                     = NULL;

		CLEANUP(AOM_ask_value_string (WSOResult[iCntWSO], FVE_WF_NAME,      &cWfName))
		CLEANUP(AOM_ask_value_string (WSOResult[iCntWSO], FVE_TASK_NAME,    &cTaskName))
		CLEANUP(AOM_ask_value_date   (WSOResult[iCntWSO], FVE_POSTDUE_DATE, &dPostDueDate))
		CLEANUP(AOM_ask_value_string (WSOResult[iCntWSO], FVE_START_BEFORE, &cStartBefore))
		CLEANUP(AOM_ask_value_string (WSOResult[iCntWSO], FVE_FREQUENCY,    &cFrequency))
		CLEANUP(AOM_ask_value_string (WSOResult[iCntWSO], FVE_SUBJECT,      &caSubject))
		CLEANUP(AOM_ask_value_strings(WSOResult[iCntWSO], FVE_RECIPIENTS,			   &numofRecipients,     &caRecipients))
		//CLEANUP(AOM_ask_value_strings(WSOResult[iCntWSO], FVE_ADDITIONAL_RECIPIENTS,   &numofAddRecipients,  &caAddRecipients))
		CLEANUP(AOM_ask_value_string (WSOResult[iCntWSO], FVE_COMMENTS,     &caComment))
		if(numWSOFound!=0)
		{
			//epmTask_qry_name = FVE_EPM_TASK_QRY;
			ITK(QRY_find(FVE_EPM_TASK_QRY, &epmTask_qry_tag))
			if(epmTask_qry_tag == NULLTAG)
			   {
				  printf("\n\"EPMTask_Query \" query is not available in tc server\n");
				  FV_DEBUG_TXT(("\n\"EPMTask_Query \" query is not available in tc server\n"))
			   }
			attrValCount = 0;
			epmQryAttrValues = NULL;

			CLEANUP(FV_copy_string_to_array(&attrValCount,&epmQryAttrValues,"4"))				// assigning values to the epmQryAttrValues for execution.
			CLEANUP(FV_copy_string_to_array(&attrValCount,&epmQryAttrValues,cTaskName))

			ITK(QRY_execute(epmTask_qry_tag, attrValCount, epmQryAttrNames, epmQryAttrValues, &numEPMtaskFound, &EPMTaskResult))
			for( iCntepmtask = 0; iCntepmtask < numEPMtaskFound; iCntepmtask++)
				{
					IMCALL( ifail, FVE_recursive_process_qry(&isTaskPending, EPMTaskResult[iCntepmtask],dPostDueDate,cStartBefore,cFrequency,caSubject,caRecipients,caComment,numofRecipients));
					isTaskPending = FALSE;
				}
		}
	}

	FVE_FREE(cWfName);
	FVE_FREE(cTaskName);
	FVE_FREE(cStartBefore);
	FVE_FREE(cFrequency);
	FVE_FREE(caSubject);
	FVE_FREE_ARRAY(caRecipients,numofRecipients);
	FVE_FREE(caComment);
	FVE_FREE(values);
	FVE_FREE(WSOResult);
	FVE_FREE(EPMTaskResult);

CLEANUP:
	FV_DEBUG_TXT(("Function FVE_reminderWSO_get_values ended \n"))
	FV_FREE_STRINGS(epmQryAttrValues)
	return ifail;
} 
/*******************************************************************************
 * Function Name	: FVE_recursive_process_qry
 * Description		: This finds out the subtasks.
 * RETURN VALUE		: ifail = ITK success/failure ifail
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name                        Description of Change
 * 03 Sep 2015          Robert Williams D			Created
 *------------------------------------------------------------------------------
 ******************************************************************************/
int FVE_recursive_process_qry( logical* isNotificationSent, tag_t epmtask, date_t dPostDueDate,char* cStartBefore, char* cFrequency, char*	caSubject,char** caRecipients, char*	caComment,int numofRecipients)
{
	int				iFail		 = ITK_ok;
	int   	        subtaskcount = 0;
	int		        iSubTaskCnt  = 0;
	tag_t*          subtasks     = NULL;
    char            task_type[WSO_name_size_c+1] = "";
	char*           id           = NULL;
	EPM_state_t  	state;
	EPM_state_t  	subTaskState;

	FV_DEBUG_TXT(("Function FVE_recursive_process_qry started \n"))
	if( *isNotificationSent == TRUE)
	{

		return iFail;
	}

	IMCALL( iFail , EPM_ask_state( epmtask, &state) );		// checks whether the task was started or not.

	if( state == EPM_started )
	{

		IMCALL( iFail , WSOM_ask_id_string  (  epmtask, &id));
		IMCALL( iFail , WSOM_ask_object_type(  epmtask, task_type));
		IMCALL( iFail , EPM_ask_sub_tasks( epmtask, &subtaskcount, &subtasks));			//gets the sub-tasks of the epmtask if there are any.
		for( iSubTaskCnt = 0; iSubTaskCnt < subtaskcount; iSubTaskCnt++)
		{
			IMCALL( iFail , EPM_ask_state( subtasks[ iSubTaskCnt], &subTaskState) );
			if( subTaskState == EPM_started )
			{
				IMCALL( iFail , FVE_recursive_process_qry( isNotificationSent, subtasks[ iSubTaskCnt],dPostDueDate,cStartBefore,cFrequency,caSubject,caRecipients,caComment,numofRecipients));
			}
		}
		if( *isNotificationSent == FALSE)
		{
			IMCALL( iFail , processNotifications( epmtask,dPostDueDate,cStartBefore,cFrequency,caSubject,caRecipients,caComment,numofRecipients));
			*isNotificationSent = TRUE;
		}
	}
	FV_DEBUG_TXT(("Function FVE_recursive_process_qry ended \n"))
    
	FVE_FREE(id);
	FVE_FREE(subtasks);

	return iFail;
}
int processNotifications( tag_t epmtask,date_t dPostDueDate,char* cStartBefore, char* cFrequency, char*	caSubject,char** caRecipients, char*	caComment,int numofRecipients )
{
	int     iFail                = ITK_ok;
	logical requiresNotification = FALSE;
	char    duration[ 256]       = "";
	FV_DEBUG_TXT(("Function processNotifications started \n"))
	IMCALL( iFail, doesTaskRequireNotification( epmtask, &requiresNotification, duration,dPostDueDate,cStartBefore,cFrequency,caSubject,caRecipients,caComment,numofRecipients));
	FV_DEBUG_TXT(("Function processNotifications ended \n"))
	return iFail;
}
/*******************************************************************************
 * Function Name	: doesTaskRequireNotification
 * Description		: This checks whether to send notification or not based on 
 *					  the frequency.
 * RETURN VALUE		: ifail = ITK success/failure ifail
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name                        Description of Change
 * 03 Sep 2015          Robert Williams D			Created
 *------------------------------------------------------------------------------
 ******************************************************************************/

int doesTaskRequireNotification( tag_t epmtask, logical* requiresNotification, char* duration,date_t dPostDueDate,char* cStartBefore, char* cFrequency, char*	caSubject,char** caRecipients, char*	caComment,int numofRecipients )
{
	int			ifail		     = ITK_ok;	
	int         diff_day         = 0;
	int			inumofdaysCount  = 0;
	int         outcount         = 0;
	int			iCount			 = 0;
	int*        freqValues       = NULL;
	int*        numofdays        = NULL;
	
	date_t		dueDate		     = NULLDATE;
	
	char*       formattedDueDate = NULL;
	//char*       value            = NULL;
	char*		freq			 = {"Daily"};
	FV_DEBUG_TXT(("Function doesTaskRequireNotification started  \n"))

	//CLEANUP(AOM_ask_value_string(epmtask, "object_name",&value))
	CLEANUP(AOM_ask_value_date (epmtask, "due_date",  &dueDate))    // getting the due date of the task.
	IMCALL (ifail,  DATE_date_to_string( dueDate, DATE_FORMAT_STR, &formattedDueDate ));
	diff_day = FV_compare_dates(dueDate,NULLDATE,true);
	diff_day = diff_day/(24*60*60);									// converting to number of days.
	if(diff_day<0)
	{
		//CLEANUP(sendMail( epmtask, formattedDueDate,caSubject,caRecipients,caComment,numofRecipients))
		return ifail;
	}else
	{
		CLEANUP(FV_parse_delimited_string_to_int(cStartBefore,"-",&outcount,&freqValues));		//parsing the frequency specified.
		/*numofdays = (int*)MEM_alloc(15);
		numofdays[0] = freqValues[0];*/
		FV_add_int_to_array(&iCount,&numofdays,freqValues[0]);
		
		if(strcmp(cFrequency,freq) == 0)
		{
			if( numofdays[0] == diff_day)
			{
				CLEANUP(sendMail( epmtask, formattedDueDate,caSubject,caRecipients,caComment,numofRecipients))
			}
			else{
			for(inumofdaysCount = 0; !(numofdays[inumofdaysCount]<=0); inumofdaysCount++)
				{
					//numofdays[inumofdaysCount+1] = numofdays[inumofdaysCount]-freqValues[1];
					FV_add_int_to_array(&iCount,&numofdays,numofdays[inumofdaysCount]-freqValues[1]);
				
					//printf_s("%d,%d",numofdays[i+1],freqValues[1]);
					if( numofdays[iCount-1] == diff_day)
					{	
						CLEANUP(sendMail( epmtask, formattedDueDate,caSubject,caRecipients,caComment,numofRecipients))
					}
				}
			}
		}else
		{
			if( numofdays[0] == diff_day)
			{
				CLEANUP(sendMail( epmtask, formattedDueDate,caSubject,caRecipients,caComment,numofRecipients))
			}
			else{
			for(inumofdaysCount = 0; !(numofdays[inumofdaysCount]<=0); inumofdaysCount++)
				{
					//numofdays[inumofdaysCount+1] = numofdays[inumofdaysCount]-7;
					FV_add_int_to_array(&iCount,&numofdays,numofdays[inumofdaysCount]-7);
					//printf_s("%d,%d",numofdays[i+1],freqValues[1]);
					if( numofdays[iCount-1] == diff_day)
					{	
						CLEANUP(sendMail(epmtask, formattedDueDate,caSubject,caRecipients,caComment,numofRecipients))
					}
				}
			}
		}
	}

	FVE_FREE(numofdays);
	//FVE_FREE(value);

CLEANUP:
	FV_DEBUG_TXT(("Function doesTaskRequireNotification ended  \n"))
	return ifail;
}
/*******************************************************************************
 * Function Name	: sendMail
 * Description		: This builts the body part of the mail and gets the user 
 *					  based on the recipients specified.
 * RETURN VALUE		: ifail = ITK success/failure ifail
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name                        Description of Change
 * 03 Sep 2015          Robert Williams D			Created
 *------------------------------------------------------------------------------
 ******************************************************************************/
int sendMail( tag_t reminderTask, char* dueDate, char*	caSubject,char** caRecipients,char*	caComment,int numofRecipients)
{
	int ifail = ITK_ok;
	int iattachmentCount	  = 0;
	int irecipientCount	      = 0;
	int rec					  = 0;
	int count				  = 0;
	int userCount			  = 0;
	tag_t* attachment         = NULLTAG;
	tag_t* userTags			  = NULLTAG;
	tag_t  memberTag		  = NULLTAG;
	tag_t  user_tag			  = NULLTAG;
	tag_t  job				  = NULLTAG;
	tag_t  owning_user		  = NULLTAG;
	tag_t  responsible_party  = NULLTAG;
	
	SIGNOFF_TYPE_t			memberType ;
	CR_signoff_decision_t 	decision = CR_no_decision;//modified by harsha //initialized a variable
	char  comments[4001];
	char* body				= NULL;
	char* jobName			= NULL;
	char* richclienturl		= NULL;
	char* url				= NULL;
	char* recipient			= NULL;
	char* recipientvalue[]  = {"$REVIEWERS","$RESPONSIBLE_PARTY","$PROCESSOWNER","$TARGETOWNER","$UNDECIDED"};

	date_t 	decision_date = NULLDATE;

	FV_DEBUG_TXT(("Function sendMail started  \n"))

	EPM_ask_job(reminderTask,&job);															// building the body part of the mail.
	CLEANUP(FV_strcat(&body, "Job Name : "))
	CLEANUP(AOM_ask_value_string(job,"object_name",&jobName))
	CLEANUP(FV_strcat(&body, jobName))
	CLEANUP(FV_strcat(&body, FV_LINEFEED));
	CLEANUP(FV_strcat(&body, "Due Date  : "));
	CLEANUP(FV_strcat(&body, dueDate));
	CLEANUP(FV_strcat(&body, FV_DBL_LINEFEED));
	CLEANUP(FV_strcat(&body, caComment));
	CLEANUP(FV_strcat(&body, FV_DBL_LINEFEED));

	TC_tag_to_url  (reminderTask,PORTAL,&richclienturl);
	TC_tag_to_url  (reminderTask,DHTML,&url);
	
	CLEANUP(FV_strcat(&body, "To Perform the task,please click one of the link below: "));
	CLEANUP(FV_strcat(&body, FV_LINEFEED));
	CLEANUP(FV_strcat(&body, "Rich Client url : "));
	CLEANUP(FV_strcat(&body, richclienturl));
	CLEANUP(FV_strcat(&body, FV_LINEFEED));
	CLEANUP(FV_strcat(&body, "Thin Client url : "));
	CLEANUP(FV_strcat(&body, url));
	CLEANUP(FV_strcat(&body, FV_DBL_LINEFEED));
	CLEANUP(FV_strcat(&body, "Thank You"));

	for(irecipientCount =0; irecipientCount < numofRecipients; irecipientCount++)
	{									
		// getting the user based on the recipients specified by user.
		recipient = caRecipients[irecipientCount];
		userCount = 0;
		userTags = NULL;

		rec = FV_strcmp_array(recipient, 5, recipientvalue);
		if(rec == 0) 
		{
			CLEANUP(EPM_ask_attachments	(reminderTask,EPM_signoff_attachment,&count,&attachment))
			for ( iattachmentCount =0; iattachmentCount < count; iattachmentCount++)
			{
			  CLEANUP( EPM_ask_signoff_member(attachment[iattachmentCount], &memberTag, &memberType))
			  CLEANUP( SA_ask_groupmember_user(memberTag , &user_tag))
			  if(user_tag != NULLTAG)
				{
					CLEANUP(FV_add_tag_to_array(&userCount,&userTags,user_tag))
				}
			}
			if(attachment) FVE_FREE(attachment)
		}
		if(rec == 1 )
		{
			CLEANUP( EPM_ask_responsible_party ( reminderTask, &responsible_party))
			if(responsible_party != NULLTAG)
				{
					CLEANUP(FV_add_tag_to_array(&userCount,&userTags,responsible_party))
				}
		}		
		if(rec == 2)
		{
			CLEANUP(AOM_ask_owner(reminderTask, &owning_user))
			CLEANUP(FV_add_tag_to_array(&userCount,&userTags,owning_user))
		}	
		if(rec == 3)
		{
			CLEANUP(EPM_ask_attachments	(reminderTask,EPM_target_attachment,&count,&attachment))
			for (iattachmentCount =0; iattachmentCount < count; iattachmentCount++)
			{
			IMCALL(ifail ,AOM_ask_owner(attachment[iattachmentCount], &owning_user));
			  if(owning_user != NULLTAG)
				{
					CLEANUP(FV_add_tag_to_array(&userCount,&userTags,owning_user))
				}
			}
			if(attachment) FVE_FREE(attachment)
		}
		if(rec == 4)
		{
			CLEANUP(EPM_ask_attachments	(reminderTask,EPM_signoff_attachment,&count,&attachment))
			for ( iattachmentCount =0; iattachmentCount < count; iattachmentCount++)
			{
				if(attachment[iattachmentCount] != NULLTAG)
				{
				  // CLEANUP( CR_ask_decision(reminderTask,NULL,user_tag,&decision,comments,decision_date))
				  CLEANUP(CR_ask_signoff_decision(attachment[iattachmentCount],&decision,comments,&decision_date))
				  if(decision ==  CR_no_decision)
					  {
						 CLEANUP( EPM_ask_signoff_member(attachment[iattachmentCount], &memberTag, &memberType))
						 CLEANUP( SA_ask_groupmember_user(memberTag , &user_tag))
						 CLEANUP( FV_add_tag_to_array(&userCount,&userTags,user_tag))
					  }
				}
			}
			if(attachment) FVE_FREE(attachment)
		}
		CLEANUP(FV_send_mail2(caSubject,body,userTags,userCount))
		
	}

CLEANUP:
	
	FVE_FREE(body);
	FVE_FREE(userTags);
	FVE_FREE(jobName);
	FV_DEBUG_TXT(("Function sendMail ended  \n"))
	return ifail;
}
static void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: FV_Reminder_Notification <args>\n\n");
        printf("**********************************************************************************\n\n");
}
/* Global Attributes */
FILE *			logfilesuccessptr				= NULL;
FILE *			logfileerrorptr					= NULL;

extern int ITK_user_main(int argc, char **argv)
{
   int			   ifail                           = ITK_ok;
   char            successlogfilename[255 + 1]     = "";
   char            errorlogfilename[255 + 1]       = "";
   char*           time_stamp                      = NULL;

   /*Append the log file name with the date and time stamp*/
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);

    sprintf(successlogfilename,"FV_Reminder_Notification_UTILITY_LOG_%s.log",time_stamp);
	sprintf(errorlogfilename,"FV_Reminder_Notification_UTILITY_ERRORS_%s.log",time_stamp);
	#ifdef UNX
		logfilesuccessptr = fopen( successlogfilename, "w+");
	#else
		  fopen_s(&logfilesuccessptr,successlogfilename, "w+");
	#endif
    
    if (logfilesuccessptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file :%s\n", successlogfilename);
        exit(1);
    }

	#ifdef UNX
		logfileerrorptr = fopen( errorlogfilename, "w+");
	#else
		  fopen_s(&logfileerrorptr,errorlogfilename, "w+");
	#endif

    if (logfileerrorptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create error log file :%s\n", errorlogfilename);
        exit(1);
    }


    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }
    printf("\nSUCCESS Log information will be written into %s",successlogfilename);
	printf("\nERROR Log information will be written into %s\n\n",errorlogfilename);
        
    if(logfilesuccessptr)
    {        
        fprintf(logfilesuccessptr,"Start time: %s\n", time_stamp);
        fprintf(logfilesuccessptr,"argc: %d\n", argc);
		fflush(logfilesuccessptr);
    
    }
	if(logfileerrorptr)
    {        
        fprintf(logfileerrorptr,"Start time: %s\n", time_stamp);
        fprintf(logfileerrorptr,"argc: %d\n", argc);
		fflush(logfileerrorptr);
   }

    ITK_initialize_text_services (0);

	ifail = ITK_auto_login();
    if(ifail != ITK_ok)
    {
		printf("Auto Login is unsuccessful\n");
        fprintf(logfileerrorptr,"ERROR: Auto Login is unsuccessful\n");   
        fclose( logfileerrorptr );		
        print_usage();
        exit(0);
    }
    else
	{
        printf("Auto Login is successful\n");
	    fprintf(logfilesuccessptr,"Auto Login is successful\n");
		fflush(logfilesuccessptr);
	    CLEANUP(FVE_reminderWSO_get_values())
	}

CLEANUP:
    ITK_exit_module	(true);
    return ifail;
}