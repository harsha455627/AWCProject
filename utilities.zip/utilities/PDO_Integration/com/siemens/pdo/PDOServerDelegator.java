/* ===================================================================================
 *                   Copyright (c) Siemens PLM Software Inc 2009
 *                     Unpublished - All rights reserved
 * ===================================================================================
 * File Description: PDOServerDelegator.java
 *                   This class will trigger the PDOServlet to retrieve the Feature codes from PDO server
 *                   Also pass encrypted password as parameter to servlet
 * ===================================================================================
 * Revision History
 * ===================================================================================
 * Date                 Name          Description of Change
 * -----------      ---------------   ---------------------
 * Apr 2016         Gulshan Kumar         PDOServerDelegator: Created.
 * Jun 2016			Gulshan Kumar		  Updated Email error message
 * 
 * ==================================================================================*/
package com.siemens.pdo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.logging.LogManager;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class PDOServerDelegator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   URL url;
		   URLConnection conn =null;
		   BufferedReader in = null; 
		   boolean is_Error = false;
		try {
			log.info("Reading properties file...");
			readFromPropertyFile();
			postURL =  pdoServletHost + DELIMITER1 + SERVLETNAME;
			url = new URL(postURL);
			conn = url.openConnection();
			conn.setDoOutput(true);
			BufferedWriter out = 
		                new BufferedWriter( new OutputStreamWriter( conn.getOutputStream() ) );
		            out.write("pval="+URLEncoder.encode(encryptPwd,"UTF-8"));
					out.append("&");
					out.append("ws="+URLEncoder.encode(CRON,"UTF-8"));
		            out.flush();
		            out.close();
		            in = 
		                new BufferedReader( new InputStreamReader( conn.getInputStream() ) );
		            
		            String response;
		            while ( (response = in.readLine()) != null ) {
		                System.out.println( response );
		            }
		            in.close();
		       
			
		}		catch (MalformedURLException e1) {
				is_Error = true;
			// TODO Auto-generated catch block
			log.error("MalformedURLExceptione1 :"+e1.getMessage());
			e1.printStackTrace();
		} catch (ConnectException e) {
			is_Error = true;
			// TODO Auto-generated catch block
			log.error("Connect Exception : Connection failed !!!\n" +e.getMessage());
			e.printStackTrace();
		}catch (IOException io) {
			is_Error = true;
			// TODO Auto-generated catch block
			log.error("IOException :" +io.getMessage());
			io.printStackTrace();
		}
		catch (Exception e) {
			is_Error = true;
			// TODO Auto-generated catch block
			log.error("Exception :" +e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try {
				if(is_Error)
				{
					log.error("***************Sending Error mail**********************");
					log.setLevel(Level.INFO);
					String subject = "VSCS Delegator: VSEM-PDO failure message";
					String bodyMessage = "There appear to be some error in PDO processing based on VSEM request. Please find attached the error log file for additional diagnostic message to be used for trouble-shooting.";

					sendEmailWithAttachments(mailHost, mailPort, mailFromAddress, null, mailToAddress,
							subject, bodyMessage);
					log.error("Mail sent sccessfully....");
				}
				
				} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage());
				e.printStackTrace();
			}
			log.info("Exit Delegator");
		   
		}

	}
	private static void readFromPropertyFile() throws IOException {
		log.info("Into readFromPropertyFile()...");
		System.out.println("Into readFromPropertyFile()...");
		BufferedReader dis = null;
		String record = "";

		try {

			File f = new File("FVEPDODelegator.properties");
			FileInputStream fis = new FileInputStream(f);
			BufferedInputStream bis = new BufferedInputStream(fis);
			dis = new BufferedReader(new InputStreamReader(bis));

			// System.out.println("Starting to read file
			// FVERequestDelegator.properties");

			while ((record = dis.readLine()) != null) {
				 	int delimiterPos = record.indexOf('=');
			        String key = record.substring(0, delimiterPos).trim();
			        String value = record.substring(delimiterPos + 1).trim();

				if (key.equals(PDO_SERVLET_HOST))
					pdoServletHost = value;

				if (key.equals(MAILHOST))
					mailHost = value;
				if (key.equals(MAILPORT))
					mailPort = value;
				if (key.equals(MAILTOADDRESS))
					mailToAddress = value;
				if (key.equals(MAILFROMADDRESS))
					mailFromAddress = value;
				if (key.equals(ENCRYPTPWD))
					encryptPwd = value;
			}


			if (pdoServletHost != null)
				log.info(PDO_SERVLET_HOST + " : " + pdoServletHost);
			// if (password != null) log.info(PASSWORD+" :
			// "+password);
			if (mailHost != null)
				log.info(MAILHOST + " : " + mailHost);
			if (mailPort != null)
				log.info(MAILPORT + " : " + mailPort);
			if (mailToAddress != null)
				log.info(MAILTOADDRESS + " : " + mailToAddress);
			if (mailFromAddress != null)
				log.info(MAILFROMADDRESS + " : " + mailFromAddress);
			if (ENCRYPTPWD != null)
				log.info(ENCRYPTPWD + " : " + encryptPwd);

			// System.out.println("End reading file
			// FVERequestDelegator.properties");
			// System.out.println("End reading file
			// FVERequestDelegator.properties");
		} catch (IOException e) {
			throw new IOException(e);
			/*
			 * System.out.println("IO Exception: Exit Code = "+
			 * PROPERTY_FILE_EXCEPTION_ERROR_CODE); System.out.println(
			 * "IO Exception: Exception Message = "+ e.getMessage());
			 * e.printStackTrace();
			 * System.exit(PROPERTY_FILE_EXCEPTION_ERROR_CODE);
			 */
		} finally {
			// if the file opened, make sure we close it
			if (dis != null) {
				try {
					dis.close();
				} catch (IOException ioe) {
					throw new IOException(ioe);
					/*
					 * System.out.println("FVERequestDelegator.properties error"
					 * ); System.out.println("IO Exception: Exit Code = "+
					 * PROPERTY_FILE_EXCEPTION_ERROR_CODE); System.out.println(
					 * "IO Exception: Exception Message = "+ ioe.getMessage());
					 * ioe.printStackTrace();
					 * System.exit(PROPERTY_FILE_EXCEPTION_ERROR_CODE);
					 */
				}
			}
		}
	}
	public static void sendEmailWithAttachments(String host, String port, final String userName, final String password,
			String toAddress, String subject, String message) throws AddressException, MessagingException {
		log.error("Entering into Send Mail....");
		// sets SMTP server properties
		Properties properties = new Properties();
		properties.put("mail.smtp.host", host.trim());
		properties.put("mail.smtp.port", port.trim());
		// properties.put("mail.smtp.auth", "true");
		// properties.put("mail.smtp.starttls.enable", "true");
		// properties.put("mail.user", userName);
		// properties.put("mail.password", password);

		// creates a new session with an authenticator
		/*
		 * Authenticator auth = new Authenticator() { public
		 * PasswordAuthentication getPasswordAuthentication() { return new
		 * PasswordAuthentication(userName, password); } };
		 */
		Session session = Session.getInstance(properties, null);

		// creates a new e-mail message
		Message msg = new MimeMessage(session);

		msg.setFrom(new InternetAddress(userName.trim()));
		
		String[] recipientList = toAddress.split(",");
		InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
		int counter = 0;
		for (String recipient : recipientList) {
		    recipientAddress[counter] = new InternetAddress(recipient.trim());
		    counter++;
		}
		msg.setRecipients(Message.RecipientType.TO, recipientAddress);
		
//		InternetAddress[] toAddresses = { new InternetAddress(toAddress.trim()) };
//		msg.setRecipients(Message.RecipientType.TO, toAddresses);
		msg.setSubject(subject);
		msg.setSentDate(new Date());

		// creates message part
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setText(message);
		messageBodyPart.setContent(message, "text/html");

		// creates multi-part
		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);

		// messageBodyPart = new MimeBodyPart();
		MimeBodyPart attachmentBodyPart = new MimeBodyPart();

		String error_FilePath = System.getProperty(JAVA_TMPDIR_PROP) + "/"+LOG_FILE_NAME+".log";

		log.error("Error log path " + error_FilePath);

		// adds attachments
		if (error_FilePath != null && !error_FilePath.equals("")) {

			DataSource source = new FileDataSource(error_FilePath);
			attachmentBodyPart.setDataHandler(new DataHandler(source));
			attachmentBodyPart.setFileName(LOG_FILE_NAME + getDateTime() + ".log");
			multipart.addBodyPart(attachmentBodyPart);

			// attachPart.setFileName(filePath);

			// multipart.addBodyPart(attachPart);

		}

		// sets the multi-part as e-mail's content
		msg.setContent(multipart);

		// sends the e-mail
		Transport.send(msg);

	}
	public final static String getDateTime() {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss");
		df.setTimeZone(TimeZone.getTimeZone("PST"));
		return df.format(new Date());
	}
	private static String mailHost = "";
	private static String mailPort = "";
	private static String mailToAddress = "";
	private static String mailFromAddress = "";
	private static String pdoServletHost = "";
	private static String encryptPwd = "";
	private static String postURL = "";
	static Logger log = Logger.getLogger(PDOServerDelegator.class);
	private final static String DELIMITER1 = "/";
	private final static String PDO_SERVLET_HOST = "PDOServletHost";
	private final static String MAILPORT = "MailPort";
	private final static String MAILHOST = "MailHost";
	private final static String MAILTOADDRESS = "MailToAddress";
	private final static String MAILFROMADDRESS = "MailFromAddress";
	private final static String ENCRYPTPWD = "EncryptPwd";
	private final static String SERVLETNAME = "PDORetrieveFeature";
	private final static String JAVA_TMPDIR_PROP = "java.io.tmpdir";
	private final static String LOG_FILE_NAME = "FVEPDODelegator_Error";
	private static String CRON = "CRON";
}
