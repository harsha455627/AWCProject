//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object O6_FleRootRevisionImpl
//

#ifndef O6TANE__O6_FLEROOTREVISIONIMPL_HXX
#define O6TANE__O6_FLEROOTREVISIONIMPL_HXX

#include <O6TaneCustomLibrary/O6_FleRootRevisionGenImpl.hxx>

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>


namespace o6tane
{
    class O6_FleRootRevisionImpl; 
    class O6_FleRootRevisionDelegate;
}

class  O6TANECUSTOMLIBRARY_API o6tane::O6_FleRootRevisionImpl
    : public o6tane::O6_FleRootRevisionGenImpl
{
public:

    ///
    /// Getter for a Double Property
    /// @param value - Parameter Value
    /// @param isNull - Returns true if the Parameter value is null
    /// @return - Status. 0 if successful
    ///
    int  getO6_total_costBase( double &value, bool &isNull ) const;


protected:
    ///
    /// Constructor for a O6_FleRootRevision
    explicit O6_FleRootRevisionImpl( O6_FleRootRevision& busObj );

    ///
    /// Destructor
    virtual ~O6_FleRootRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    O6_FleRootRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    O6_FleRootRevisionImpl( const O6_FleRootRevisionImpl& );

    ///
    /// Copy constructor
    O6_FleRootRevisionImpl& operator=( const O6_FleRootRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class o6tane::O6_FleRootRevisionDelegate;

};

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
#endif // O6TANE__O6_FLEROOTREVISIONIMPL_HXX
