//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object BOMLineImpl
//

#ifndef O6__O6TANE__BOMLINEIMPL_HXX
#define O6__O6TANE__BOMLINEIMPL_HXX

#include <O6TaneCustomLibrary/BOMLineGenImplExt.hxx>

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>


namespace o6
{
    namespace o6tane
    {
        class BOMLineImpl; 
        class BOMLineDelegate;
    }
}

class  O6TANECUSTOMLIBRARY_API o6::o6tane::BOMLineImpl
    : public o6::o6tane::BOMLineGenImpl
{
public:

    ///
    /// Getter for a Double Property
    /// @param value - Parameter Value
    /// @param isNull - Returns true if the Parameter value is null
    /// @return - Status. 0 if successful
    ///
    int  getO6_valueBase( double &value, bool &isNull ) const;

    ///
    /// Getter for a Double Property
    /// @param value - Parameter Value
    /// @param isNull - Returns true if the Parameter value is null
    /// @return - Status. 0 if successful
    ///
    int  getO6_value_percentBase( double &value, bool &isNull ) const;

    ///
	/// Getter for a Double Property
	/// @param value - Parameter Value
	/// @param isNull - Returns true if the Parameter value is null
	/// @return - Status. 0 if successful
	///
    int  getO6_sap_costBase( double &value, bool &isNull ) const;


protected:
    ///
    /// Constructor for a BOMLine
    explicit BOMLineImpl( BOMLine& busObj );

    ///
    /// Destructor
    virtual ~BOMLineImpl();

private:
    ///
    /// Default Constructor for the class
    BOMLineImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    BOMLineImpl( const BOMLineImpl& );

    ///
    /// Copy constructor
    BOMLineImpl& operator=( const BOMLineImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class o6::o6tane::BOMLineDelegate;

};

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
#endif // O6__O6TANE__BOMLINEIMPL_HXX
