fve_import_parameters utility
-----------------------------
fve_import_parameters: This utility is intended for 
                         a) Bulk create / update of parameters, 
			 b) Create / update the Model Specific Forms and associate the same to the above created parameter definitions,
			 c) Create the Proccess definition objects and relate them to the desired parameter definitions in the context of the dictionary
						   
USAGE:
    fve_import_parameters -u=<user id> -p=<password | password file> - g=<group>
                               -dicid=<Dictionary | Repository item Id> -revid=<Revision Id>
	                       -mode=parameter | process | all -parmdeffile=<parameter definition file>
			       -processdeffile=<process definition file>
					
NOTE:   
        - This utility can be executed by any user with a Software Engineer or Module Supervisor Roles only
		- The utility requires a valid Dictionary item and rev id. It is expected that the parameter dictionary item is created manually upfront.
		- If the Dictionary item has the Organization group and a Parameter group underneath it, then the utility will import all the parameters
		  and associate them to the parameter group. Else, the utility will create the Organization and parameter groups dynamically and attach
		  all the parameters to the parameter group.
		- The utility can be executed in 3 modes, namely parameter mode or process mode or all. 
		     a) If the -mode option is set to "parameter", then it only creates / updates the parameter definitions, 
                        creates the model specific forms, relates them to the parameters definitions, but ignores importing
                        the process definitions.
                     b) If the -mode option is set to "process", then it creates associates the process objects to the 
                        parameter definitions objects using Sink / Source relations, in the context of the dictionary object.
                     c) If the -mode option is set to "all", then the utility performs both a) and b).
		- The script will accept only .csv file formats for parameter and process definition files, with a "||" delimiter.
                - FVE_ccm_config.txt file is the config file needed for the execution of the utility. It is expected to specify the log file name and the path
                  in this file. The fve_import_parameters script will read the config file runtime, gets the log file name and the path where the log file needs
                  to be written to.	
                - The above config file needs to be in the same location from where the script will be executed.		  
						   

