
#ifndef METHOD_H_INCLUDED
#define METHOD_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <tc/emh_errors.h>
#include <tc/preferences.h>
#include <textsrv/textserver.h>
#include <pom/pom/pom.h>
#include <pom/enq/enq.h>
#include <tccore/custom.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/item_msg.h>
#include <tccore/item_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/workspaceobject.h>
#include <tccore/method.h>
#include <tccore/grm_msg.h>
#include <tccore/tc_msg.h>
#include <user_exits/user_exit_msg.h>
#include <ps/ps.h>
#include <qry/qry.h>
#include <bom/bom_msg.h>
#include <epm/epm.h>
#include <me/me_msg.h>
#include <ae/dataset.h>
#include <ict/ict_userservice.h>
#include <dispatcher/dispatcher_itk.h>
#include <O6TaneCustomLibrary/commun.hxx>

#define	Q_CLS	"Item"
#define	Q_CLS_ATT	"item_id"
#define	OBJTYPE "object_type"
#define TRG_SLAVE_ATT "o6_stock_item_name"
#define TRG_SLAVE_ATT_UOM "o6_stock_item_uom"
#define TRG_SLAVE_ATT_UOM_AR "o6_stock_item_uom_ar"
#define RSLT_SLAVE_ATT "object_name"
#define TRG_MASTER_ATT "o6_stock_item_id"
#define EMPTY_VALUE "-"
#define CURR_OBJ_STR "o6_tc_intern_lot_nb"
#define CURR_REQ_STR "o6_GoodsReqestID"
#define MVT_ATT "o6_mouv_qtt"
#define QTY_ATT "o6_stock_qtt"
#define QTY_ATT_O_R "o6_Qty"
#define CMP_CDE "o6_compute_code"
#define PURGE "o6_Purged"
#define GOODSINWAREHOUSE "O6_WHGoodsRel"
#define GOODSPURGEDINWAREHOUSE "O6_Purged_Goods"
#define GOODSSUMWAREHOUSE "O6_Goods_Summary"
#define SUPRMGENRM "O6_GenToSupplRM"
#define BRMGENRM "O6_BatchDefRel"
#define BFLEDEFFLE "O6_BatchDefRel"
#define TP_1_1 "O6_GenRM"
#define TP_1_2 "O6_RMBatch"
#define TP_1_3 "O6_SupRM"
#define TP_2_1 "O6_FleBatch"
#define TP_2_2 "O6_Fle"
#define TP_3_1 "O6_Conso"
#define TP_4_1 "O6_GenAC"

extern int O6Stock_custom_acl ( METHOD_message_t * m, va_list args );

extern int summarize_stock_level ( tag_t sk);
#endif /* METHOD_H_INCLUDED */
