
This sample demonstrates the basic functionality of the Teamcenter Services.



Before running the sample application, you must have a Teamcenter Web Tier server
and Pool Manager up and running.

To build this project from Visual Studio 2008(9.0).
1. Add the location of the Teamcenter Services libraries to the PATH environment variable
        SET PATH=<soa_client>\cpp\libs\wnti32;%PATH%
   Where <soa_client> is the root folder of the soa_client from the Teamcenter CD-ROM distribution. 
2. Load the project
   Open the Open dialog ( File --> Open --> Project... )
   Browse to .../soa_clients/cpp/samples/HelloTeamcenter/HelloTeamcenter.vcproj
3. Compile the project  
4. Execute the client application
   To connect to a server other than http://localhost:7001/tc, change this URI
   on Project Properties dialog ( Project --> Properties, Configuration Properties -->
   Debuging). In the 'Command Arguments' field add '-host http://server:port/tc'.
   
   In case the application needs to operate in TCCS mode, change the URI to the form
   tccs://<envname> For eg. tccs://dev.
 
To build this project on a Unix system
1. Add the location of the Teamcenter Services libraries to the LD_LIBRARY_PATH environment variable
   export LD_LIBRARY_PATH=<soa_client>/cpp/libs/<platform>:$LD_LIBRARY_PATH
2. Set the environment variable TEAMCENTER_SERVICES_HOME
   export TEAMCENTER_SERVICES_HOME=<full path to soa_client root folder>
3. Build the source
   cd ..
   ./compile HelloTeamcenter
4. Execute the client applicaiton
   HelloTeamcenter.<platform>
   To connect to a server other than http://localhost:7001/tc, change this URI on  the
   command line
   HelloTeamcenter.<platform> -host http://server:port/tc
   
Running in TCCS mode
1. To run in TCCS mode, ensure that TCCS and its configuration files are installed and TCCS is 
   already running.
2. In the command line use tccs://<tccs_envname> (TCCS protocol and envrionment name) has the 
   host URI instead of http://hostname:port/tc
   
 
 The source file Hello.java has the main function for the application. This is the 
 best place to start browsing the code. There are several classes prefixed with 
 the name AppX (AppXCredentialManager). These classes are implementations of 
 Teamcenter Services framework interfaces. Each client application is responsible 
 for providing an implementation to these interfaces:
 
     CredentialManager       Used by the framework to re-authenticate as user.
     ExceptionHandler        Provide a mechanism for the client application to
                             handle low level exception in the communication framework.
     PartialErrorListener    Optional listener for notification when a service operation
                             has returned partial errors.
     ModelEventListener      Optional listener for notification when a service operation
                             has returned ModelObject with updated property values, 
                             or when objects have been deleted from the database.

 
 The remaining classes in this sample the use  a few of the service operations 
 to demonstrate some basic features of Teamcenter Services.
 
     Session                 This class shows how to establish a session with the
                             Teamcenter Server using the SessionService login and 
                             logout methods. A session must be established before
                             any other service operation are called.
     HomeFolder              This class lists the contents of the user's home folder
     Query                   This class performs a simple query.
     DataManagement          This class creates, revises, and deletes a set of Items
     
 Each of these examples performs the same basic steps
     1. Construct the desired service stub.
     2. Gather the data for the opeation's input arguments,
     3. Call the service operation
     4. Process the results.
     
 A few of the service operations will make use of the ModelEventListener.
 Under normal circumstances the ExeptionHandler and PartialErrorListner will not
 be called.
 
 
 
