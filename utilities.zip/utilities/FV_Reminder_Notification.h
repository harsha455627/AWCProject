/****************************************************************************
* Filename	    :   FV_Reminder_Notification.h			 	
*									
* ENVIRONMENT	:   C, C++, ITK					
*									
* History							       
*--------------------------------------------------------------------------
* Date         	   Name                      Description of Change
* 03 Sep 2015      Robert Williams D         Created
* -------------------------------------------------------------------------
*							
****************************************************************************/


/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <epm/epm.h>
#include <tccore/aom_prop.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <tc/tc_util.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <epm/signoff.h>
#include <sa/groupmember.h>
#include <FV_prototypes.h>
#include <FV_macros.h>
#include <FVE_user_common.h>


/*************************************************
* Macros Definition
**************************************************/
#define     FVE_REMINDER_NOTIFICATION_QRY "__FV9_ReminderNotification"
#define     FVE_WF_NAME					  "fv9_WorkflowName"
#define     FVE_TASK_NAME				  "fv9_TaskName"
#define     FVE_POSTDUE_DATE		      "fv9_PostDueDate"
#define     FVE_START_BEFORE		      "fv9_StartBefore"
#define     FVE_FREQUENCY				  "fv9_Frequency"
#define     FVE_SUBJECT					  "fv9_Subject"
#define     FVE_RECIPIENTS				  "fv9_Recipient"
#define     FVE_COMMENTS				  "fv9_Comments"
#define     FVE_EPM_TASK_QRY              "__EPMTask_Query"


FILE *logfileptr = NULL;
#define IMCALL( iFail, func) {											\
	char *err_string = NULL;														\
	if( (iFail = (func)) != ITK_ok)											\
	{																		\
	EMH_ask_error_text(iFail, &err_string);                 \
    fprintf(logfileptr,"ERROR: %d ERROR MSG: %s.", iFail, err_string);\
	fprintf (logfileptr, "FUNCTION: %sFILE: %s LINE: %d",#func, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	return iFail;\
	}																		\
}

int sendMail( tag_t reminderTask, char* dueDate, char*	caSubject,char** caRecipients,char*	caComment,int numofRecipients);
int FVE_recursive_process_qry( logical* isNotificationSent, tag_t epmtask, date_t dPostDueDate,char* cStartBefore, char* cFrequency, char*	caSubject,char** caRecipients, char*	caComment,int numofRecipients);
int processNotifications( tag_t epmtask,date_t dPostDueDate,char* cStartBefore, char* cFrequency, char*	caSubject,char** caRecipients, char*	caComment,int numofRecipients );
int doesTaskRequireNotification( tag_t epmtask, logical* requiresNotification, char* duration,date_t dPostDueDate,char* cStartBefore, char* cFrequency, char*	caSubject,char** caRecipients, char*	caComment,int numofRecipients );


