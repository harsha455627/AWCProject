#!/usr/bin/ksh

# ---------------------------------------------------------------------------------------------
#NOTE - This is the only utility to import standard mating connector into Teamcenter


# Inputs:
# 1. old_id - Item ID that has to be renumbered. 
# 2. new_id - New ID to be assigned


# Set the TC environment

if [ $# -ne 2 ]
then
    echo "Error in $0 - Invalid Argument Count"
    echo "Syntax: $0 <old_item_id> <new_item_id>"
    exit
fi

export TC_ROOT=/apps/tc_vsem/11.2/sun
export TC_DATA=/data/fna1lv1/cfg1

. $TC_DATA/tc_profilevars

export VSEM_UTIL_LOG_DIR=/data/fna1lv1/cfg1/../log

$TC_ROOT/fve_kit/server/utilities/fve_change_item_id -old_id=$1 -new_id=$2 

