/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: FreezeUtil.c
    Module  : main

        Reead input text file of item id and freeze objects.  
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>
===============================================================================
Date               Name                    Description of Change
Nov 2013          Prasmit Pansare             Initial version
Feb 2013          Prasmit Pansare          Added support for VSEM2.2 requirement. To freeze input item revision , accept any requirement object as input.
===============================================================================*/
#include <time.h>
#include "FreezeUtil.h"

/*--------------------------Function Prototypes-------------------------------*/

static void print_usage(void);
int freezeDataset();
int changeBomViewOwnership();
int freezeBVR();

static logical verbose_flag = false;
FILE *logfileptr = NULL;
int datasetFreezeCnt = 0 ;

/*-------------------------------End------------------------------------------*/

extern int ITK_user_main( int argc, char **  argv )
{   
	
	
	char   *timeStamp                      = NULL;
    char   *loginGroup                     = NULL;
    char   *loginUser                      = NULL;
    char   *inputFile                      = NULL;
    char   *loginPassword                  = NULL;


	char   *entryNames[1]                  = {"Item ID"};
	char   *entryValues[1]                 = {""};

	char    logfilename[255 + 1]           = "";
    char    fileline[257]                  = "";
    char    fileline_tmp[257]              = "";
	
    tag_t   query_tag                      = NULLTAG;
    tag_t  *itemRevTags                    = NULL;
	
    int     ifail                          = ITK_ok;
    int     itemsRevCnt                    = 0;
    int     errorCnt                       = 0;
	int     lineCnt                        = 0;
	int     successCnt                     = 0;
	FILE *  inputfileptr                   = NULL;

	
    //Append the log file name with the date and time stamp 
    get_time_stamp(DATE_FORMAT_STR, &timeStamp);
    sprintf(logfilename,"FreezeUtil_%s.log",timeStamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", timeStamp);
        fprintf(logfileptr,"argc: %d\n", argc);
        FVE_FREE(timeStamp)
    }
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }    
    
    // Processing input arguments
    loginUser     = ITK_ask_cli_argument("-u=");
    loginPassword = ITK_ask_cli_argument("-p=");
    loginGroup    = ITK_ask_cli_argument("-g=");
    inputFile     = ITK_ask_cli_argument("-i=");
    
    ITK_initialize_text_services (0);
    CLEANUP(ITK_init_module (loginUser, loginPassword, loginGroup))
    if(ifail != ITK_ok)
    {
        fprintf(logfileptr,"Login with uid: %s, group:%s is unsuccessful\n\n", loginUser, loginGroup);    
        fclose( logfileptr );
        print_usage();
        exit(0);
    }
	else
    {
        fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n\n", loginUser, loginGroup);   
    }
     
    /*Read input file */
    inputfileptr = fopen( inputFile, "r");
    if (!inputfileptr)
    {
       printf("Unable to read input file , utility terminating.\n\n");
	   fprintf(logfileptr,"Unable to read definition file , utility terminating.\n\n");
       goto CLEANUP;
    }

    /* Process input file */
    while (fgets(fileline, 256, inputfileptr) != NULL) 
    {
         
          char*   queryName        = "Item Revision...";
          char*   itemId           = NULL;
          char*   itemType         = NULL;
          char*   targetTypename   = ItemRevisionTYPE;
          char*   traverseTypename = ItemRevisionTYPE;
          char*   statusName       = NULL;
          
          int     cnt              = 0;
          int     revIdx           = 0;
          int     statusCnt        = 0;
          int     statIdx          = 0;
          int     allObjCnt        = 0;

          tag_t   bomWindowTag     = NULLTAG;
          tag_t   topLineTag       = NULLTAG;
          tag_t   FrozenStatusTag  = NULLTAG;
          tag_t*  allObjectTags    = NULL;
          tag_t*  statusListTags   = NULL;

          logical isPackageSpecRev = false;

          lineCnt++ ;

          fprintf(logfileptr,"-------------------------------------------------------\n");
	      fprintf(logfileptr,"Processing for Line Number %d.\n", lineCnt);
	      fflush(logfileptr);

          if(fileline && tc_strlen(fileline)> 0)
          {
		        FV_trim_blanks(fileline);
                tc_strcpy( fileline_tmp, fileline);
        		
		        CLEANUP(FV_strdup(fileline_tmp,&itemId))
		        if((itemId)&&(tc_strlen(itemId))> 0)
                {
                   fprintf(logfileptr,"Item id = %s\n",itemId);
		           fflush(logfileptr);
		        }
                else
                {
		           fprintf(logfileptr,"Can not process the line %s is NULL\n",fileline);
		           fflush(logfileptr);
		           FVE_FREE(itemId)
		           continue;
		        }
        		
                query_tag = NULLTAG;
                /* Find Component Revision */   
                CLEANUP(QRY_find(TC_text (queryName), &query_tag))
                if(!query_tag)
		        {
		          fprintf(logfileptr, "cannot proceed, Query not found.\n");
	              fflush(logfileptr);
		          FVE_FREE(itemId)
		          continue;
		        }
   	            else
	            {
		             entryValues[0] = itemId;
                     itemsRevCnt = 0;
		             itemRevTags = NULLTAG;

                     CLEANUP(QRY_execute ( query_tag, 1, entryNames, entryValues, &itemsRevCnt, &itemRevTags))
                     if (itemsRevCnt > 0)
                     {
                       fprintf(logfileptr, "After query,Total Number of revisions found = %d.\n",itemsRevCnt);
	                   fflush(logfileptr);
                     }
		             else
                     {
                       fprintf(logfileptr, "After query,For Object Type with id=%s ,No revsion was found\n",itemId);
                       // fprintf(logfileptr, "Update failed.\n");
	                   fflush(logfileptr);
                       FVE_FREE(itemId)
		               // errorCnt++;
		               continue;
	                 }
                     // loop through the Items found
                     AM__set_application_bypass(TRUE);
                     
                     if(itemsRevCnt>0)
		             {
                        for(cnt = 0; cnt < itemsRevCnt; cnt++)
                        {
                              CLEANUP(AOM_ask_value_string(itemRevTags[cnt], item_idPROP, &itemId))
                              CLEANUP(AOM_ask_value_string(itemRevTags[cnt],object_typePROP, &itemType))
                              
                              fprintf(logfileptr, "Processing for  = %s  - %s\n",itemId,itemType);
                              
                              FVE_FREE(itemId);
                              FVE_FREE(itemType);

                              //Create bomline from revision and traverse structure
                              changeBomViewOwnership(itemRevTags[cnt], logfileptr);
                              
                              CLEANUP(BOM_create_window(&bomWindowTag))
                              CLEANUP(BOM_set_window_top_line(bomWindowTag, NULLTAG ,itemRevTags[cnt],NULLTAG ,&topLineTag))

                              CLEANUP(FV_gather_bom_child_item_revs(topLineTag,FV_ALL_LEVELS,FV_LEVEL_ZERO,1,&targetTypename,0,
                                                                      &traverseTypename,FV_GET_ACTIVE_ONLY,&allObjCnt,&allObjectTags))
                              //printf("\n Total objects found in structure = %d", allObjCnt);
                              CLEANUP(FV_add_unique_tag_to_array(&allObjCnt,&allObjectTags ,itemRevTags[cnt]))

                              for(revIdx = 0; revIdx < allObjCnt; revIdx++)
                              {
                                    CLEANUP(AOM_ask_value_string(allObjectTags[revIdx], item_idPROP, &itemId))
                                    CLEANUP(AOM_ask_value_string(allObjectTags[revIdx],object_typePROP, &itemType))
                                    CLEANUP(FV_object_is_typeof (allObjectTags[revIdx], FV9PackageSpecRevisionTYPE,&isPackageSpecRev))
                                
                                    if(!isPackageSpecRev)
                                    {
                                      CLEANUP(AOM_ask_value_tags(allObjectTags[revIdx], release_status_listPROP, &statusCnt, &statusListTags))
                                      if(statusCnt>0)
                                      {
                                           for (statIdx = 0; statIdx < statusCnt; statIdx++)
                                           {
                                              CLEANUP(AOM_ask_name(statusListTags[statIdx], &statusName))
                                              
                                              if (tc_strcmp(statusName, FROZEN_STATUS) == 0)
                                              {
                                                   fprintf(logfileptr, "Object already frozen = %s  - %s\n",itemId,itemType);
                                                   errorCnt++;
                                                   FVE_FREE(statusName);
                                                   continue;
                                              }
                                              else
                                              {
                                                  changeBomViewOwnership(allObjectTags[revIdx], logfileptr);
                                                  freezeBVR(allObjectTags[revIdx]);

                                                  // paste cut code here

                                                  CLEANUP(AOM_lock(allObjectTags[revIdx]))
                                                  CLEANUP(CR_create_release_status(FROZEN_STATUS,&FrozenStatusTag))
                                                  CLEANUP(EPM_add_release_status(FrozenStatusTag, 1, &(allObjectTags[revIdx]), TRUE))

                                                  freezeDataset(allObjectTags[revIdx],logfileptr );

                                                  CLEANUP(AOM_refresh(itemRevTags[cnt], false))
                                                  successCnt++;
                                                  fprintf(logfileptr, "Successfully freezed = %s  - %s\n",itemId,itemType);
                                              }

                                           }
                                           //FVE_FREE(bomViewTags)
                                           FVE_FREE(statusName)
                                           FVE_FREE(statusListTags)
                                      }
                                      else
                                      {
                                          // paste cut code here
                                           changeBomViewOwnership(allObjectTags[revIdx],logfileptr);
                                           freezeBVR(allObjectTags[revIdx]);
                                           
                                           CLEANUP(AOM_lock(allObjectTags[revIdx]))
                                           CLEANUP(CR_create_release_status(FROZEN_STATUS,&FrozenStatusTag))
                                           CLEANUP(EPM_add_release_status(FrozenStatusTag, 1,&(allObjectTags[revIdx]), TRUE))

                                           freezeDataset(allObjectTags[revIdx], logfileptr);
                                          
                                           CLEANUP(AOM_refresh(allObjectTags[revIdx], false))
                                           successCnt++;
                                           fprintf(logfileptr, "Successfully freezed = %s  - %s\n",itemId,itemType);
                                           //FVE_FREE(bomViewTags)

                                      }
                             }
                             else
                             {
                               changeBomViewOwnership(allObjectTags[revIdx], logfileptr);
                               fprintf(logfileptr, "Found Package spec type object..Changed onwership = %s  - %s\n",itemId,itemType);
                             }
                           }
                          FVE_FREE(allObjectTags);
                       }
                      FVE_FREE(itemId)
                      FVE_FREE(itemType)
                      //FVE_FREE(bomviewCurName)
                      
                      fflush(logfileptr);
	               }
                   FVE_FREE(itemRevTags)
		           AM__set_application_bypass(FALSE);
              }
          }//End of input line check
    }//End of while loop
      
    fprintf(logfileptr,"-------------------------------------------------------\n");
	printf("Total number of Lines processed = %d\n", lineCnt);
    
    fprintf(logfileptr,"\n\nTotal number of Lines processed = %d\n", lineCnt);
    printf("Total number of objects successfully set to frozen status  = %d\n", successCnt);

    fprintf(logfileptr,"\n\nTotal number of datasets  successfully set to frozen status  = %d\n", datasetFreezeCnt);
    printf("\n\nTotal number of datasets  successfully set to frozen status  = %d\n", datasetFreezeCnt);
    
    fprintf(logfileptr,"Total number of objects successfully set to frozen status  = %d\n", successCnt);
	printf("Total number of objects already frozen  = %d\n", errorCnt);

    fprintf(logfileptr,"Total number of objects already frozen  = %d\n", errorCnt);
   
    AM__set_application_bypass(FALSE);
    ITK_exit_module( true );
    printf("Utility completed successfully.\n\n");
    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &timeStamp); 
    fprintf(logfileptr,"\nEnd time: %s\n", timeStamp); 
    FVE_FREE(timeStamp)    
    
    if (logfileptr ) fclose( logfileptr);
    
CLEANUP:
    FVE_FREE(itemRevTags)
	/*******/

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


/*--------------------------------------------------------------------------*/


static void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: RM_Data_Migration <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<login user id>\n");
        printf(" -p=<login password>\n");
        printf(" -g=<login group>\n");
        printf(" -i=<input file path>\n");
        printf("\n");
        printf("**********************************************************************************\n\n");        
}



int freezeBVR(tag_t objectTag)
{

    int    ifail             = ITK_ok;
    int    bomViewIdx        = 0;
    int    bomViewCnt        = 0;
    int    statusCnt         = 0;
    int    statIdx           = 0;
    

    tag_t   FrozenStatusTag  = NULLTAG;
    tag_t*  bomViewTags      = NULL;
    tag_t*  statusListTags   =  NULL;

    char*   statusName       = NULL;

    logical isFrozen         = false;


     CLEANUP(AOM_ask_value_tags(objectTag,"structure_revisions",&bomViewCnt,&bomViewTags))
     
     for( bomViewIdx = 0; bomViewIdx<bomViewCnt ; bomViewIdx++)
     {
        CLEANUP(AOM_ask_value_tags(bomViewTags[bomViewIdx], release_status_listPROP, &statusCnt, &statusListTags))
        if(statusCnt>0)
        {
             for (statIdx = 0; statIdx < statusCnt; statIdx++)
             {
                CLEANUP(AOM_ask_name(statusListTags[statIdx], &statusName))
                if (tc_strcmp(statusName, FROZEN_STATUS) == 0)
                {
                    isFrozen  = true;
                    FVE_FREE(statusName);
                    break;
                }
             }
             if(!isFrozen)
             {

                 CLEANUP(AOM_lock(bomViewTags[bomViewIdx]))
                 CLEANUP(CR_create_release_status(FROZEN_STATUS,&FrozenStatusTag))
                 CLEANUP(EPM_add_release_status(FrozenStatusTag, 1,&(bomViewTags[bomViewIdx]), TRUE))
                 CLEANUP(AOM_refresh(bomViewTags[bomViewIdx], false))
             }
        }
        else
        {
            // set freeze status to BVR
             CLEANUP(AOM_lock(bomViewTags[bomViewIdx]))
             CLEANUP(CR_create_release_status(FROZEN_STATUS,&FrozenStatusTag))
             CLEANUP(EPM_add_release_status(FrozenStatusTag, 1,&(bomViewTags[bomViewIdx]), TRUE))
             CLEANUP(AOM_refresh(bomViewTags[bomViewIdx], false))
        }
     }

CLEANUP:
      FVE_FREE(bomViewTags)
      FVE_FREE(statusListTags)
      FVE_FREE(statusName);
       return ifail;
}




int changeBomViewOwnership(tag_t objectTag, FILE* logfileptr)
{
    int     ifail            = ITK_ok;

    int     bomViewCnt       = 0;
    int     bomViewIdx       = 0;

    tag_t   itemTag          = NULLTAG;
    tag_t   itemOwnerTag     = NULLTAG;
    tag_t   itemGroupTag     = NULLTAG;
    tag_t   bomViewOwnerTag  = NULLTAG;
    tag_t*  bomViewTags      = NULLTAG;

    char*   bomviewCurName   = NULL;
    char*   itemId           = NULL;
    char*   objectType       = NULL;



    CLEANUP(AOM_ask_value_string(objectTag, item_idPROP , &itemId))
    CLEANUP(AOM_ask_value_string(objectTag, object_typePROP, &objectType))


    CLEANUP(ITEM_ask_item_of_rev(objectTag,&itemTag))
    CLEANUP(AOM_ask_owner(itemTag,&itemOwnerTag))
    CLEANUP(AOM_get_value_tag(itemTag, owning_groupPROP, &itemGroupTag))
    CLEANUP(AOM_ask_value_tags(itemTag, "bom_view_tags", &bomViewCnt,&bomViewTags))
      
    for( bomViewIdx = 0; bomViewIdx<bomViewCnt ; bomViewIdx++)
    {

           CLEANUP(AOM_ask_value_string(bomViewTags[bomViewIdx] , "current_name", &bomviewCurName))
           CLEANUP(AOM_ask_owner(bomViewTags[bomViewIdx] ,&bomViewOwnerTag))
           if(itemOwnerTag !=bomViewOwnerTag)
           {

             CLEANUP(AOM_lock(bomViewTags[bomViewIdx]))
             CLEANUP(AOM_set_value_tag(bomViewTags[bomViewIdx], owning_userPROP, itemOwnerTag))
             CLEANUP(POM_set_owning_group(bomViewTags[bomViewIdx], itemGroupTag))
             CLEANUP(AOM_save(bomViewTags[bomViewIdx]))
             CLEANUP(AOM_unlock(bomViewTags[bomViewIdx]))
             CLEANUP(AOM_refresh(bomViewTags[bomViewIdx] , false))
             // fprintf(logfileptr, "Changed ownership of BV for = %s  - %s  -%s\n",itemId,itemType,bomviewCurName );
             fprintf(logfileptr, "Changed ownership of BOM View for = %s  - %s\n",itemId,objectType);
           }
    }

CLEANUP:
    FVE_FREE(itemId);
    FVE_FREE(objectType);
    FVE_FREE(bomViewTags);
    FVE_FREE(bomviewCurName);
     return ifail;


}




/* Function takes "item revision tag" as input, find attached datasets.
   For all related datasets if not already Frozen, freezes them.
*/
int freezeDataset(tag_t objectTag, FILE* logfileptr)
{
    int     ifail = ITK_ok;
   
    int     dsIdx                 = 0;
    int     datasetCnt            = 0;
    int     statusCnt             = 0;
    int     statusIdx             = 0;

    int     relCnt                = 0;
    int     relationIdx           = 0;
    int     relationTypeCnt       = 0;

    char*   itemId = NULL;
    char*   objectType = NULL;
    char*   statusName            = NULL;
    char*   expandRelTypenames[2] = {IMAN_specificationTYPE, TC_AttachesTYPE};

    tag_t   relTypeTag            = NULLTAG;
    tag_t   FrozenStatusTag       = NULLTAG;

    tag_t*  statusListTags        = NULL;
    tag_t*  datasetTags           = NULL;
    tag_t*  relationTypeTags      = NULL;

   
    CLEANUP(AOM_ask_value_string(objectTag, item_idPROP , &itemId))
    CLEANUP(AOM_ask_value_string(objectTag, object_typePROP, &objectType))


    
    for( relCnt = 0; relCnt <2 ; relCnt++)
    {
        CLEANUP(GRM_find_relation_type(expandRelTypenames[relCnt], &relTypeTag))
        CLEANUP(FV_add_unique_tag_to_array(&relationTypeCnt, &relationTypeTags,relTypeTag))
    }
      
    for( relationIdx = 0; relationIdx< relationTypeCnt ; relationIdx++)
    {
       CLEANUP(GRM_list_secondary_objects_only(objectTag , relationTypeTags[relationIdx], &datasetCnt, &datasetTags))
       for(dsIdx = 0; dsIdx < datasetCnt; dsIdx ++)
       {
          CLEANUP(AOM_ask_value_tags(datasetTags[dsIdx], release_status_listPROP, &statusCnt, &statusListTags))
          if(statusCnt>0)
          {
               for( statusIdx =0; statusIdx < statusCnt ; statusIdx++)
               {
                      CLEANUP(AOM_ask_name(statusListTags[statusIdx], &statusName))
                      if (tc_strcmp(statusName, FROZEN_STATUS) == 0)
                      {
                        //fprintf(logfileptr, "Object already frozen = %s  - %s\n",itemId,itemType);
                        //errorCnt++;
                        FVE_FREE(statusName);
                        continue;
                      }
                     else
                     {
                        CLEANUP(AOM_lock(datasetTags[dsIdx]))
                        CLEANUP(CR_create_release_status(FROZEN_STATUS,&FrozenStatusTag))
                        CLEANUP(EPM_add_release_status(FrozenStatusTag, 1, &(datasetTags[dsIdx]), TRUE))
                        CLEANUP(AOM_refresh(datasetTags[dsIdx], false))
                        datasetFreezeCnt++;
                     }
               }
            FVE_FREE(statusListTags)
            FVE_FREE(statusName)
         }
         else
         {
             CLEANUP(AOM_lock(datasetTags[dsIdx]))
             CLEANUP(CR_create_release_status(FROZEN_STATUS,&FrozenStatusTag))
             CLEANUP(EPM_add_release_status(FrozenStatusTag, 1, &(datasetTags[dsIdx]), TRUE))
             CLEANUP(AOM_refresh(datasetTags[dsIdx], false))
             datasetFreezeCnt++;
             fprintf(logfileptr, "Freezed dataset for = %s  - %s\n",itemId,objectType);

          }
       }
       FVE_FREE(datasetTags)
    }

CLEANUP:
      FVE_FREE(itemId);
      FVE_FREE(objectType);
      FVE_FREE(relationTypeTags);
      FVE_FREE(statusListTags)
      FVE_FREE(datasetTags)
      FVE_FREE(statusName)
      return ifail;
}

