/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: Fve_create_milestones.c
    Module  : main

        Used to allow creation of WSOs.
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>.

===============================================================================
Date               Name                    Description of Change
===============================================================================*/

#include <sys/stat.h>
#include "FVDT_create_milestones.h"

/*--------------------------Function Prototypes-------------------------------*/


static void print_usage(void);

static logical verbose_flag = false;
FILE *logfileptr = NULL;

/*-------------------------------End------------------------------------------*/

/*******************************************************************************/
/* Function Name    : FVDT_String_to_StringArray                               */
/*                                                                             */
/* Description      : Convert string to string array on the basis of given     */
/*                    delimitor                                                */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      		                  Created                              */
/*******************************************************************************/

void FVDT_String_to_StringArray  (char* line, char ***Attributes, char * delim, int *count )
{
   char     *str = NULL;
   char**  AttributesDup = NULL;
   int      i              = 0;

   /* *Attributes  = NULL;   */
   str = tc_strtok (line, delim);
   while (str != NULL)
   {

       AttributesDup = (char**)MEM_realloc(AttributesDup, sizeof(char*)*(i+1));
       AttributesDup[i] = (char*)MEM_alloc( sizeof(char)*((int)strlen (str)+1));
       strcpy( AttributesDup [i], str);
       str = tc_strtok (NULL,delim);
       i++;

   }
   *Attributes = AttributesDup;
   *count = i;
}

/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                  */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  10/21/2004      			              Initial Creation              */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;


    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        if( logfileptr )
        fprintf( logfileptr, "ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);

    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }

    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;

    return ifail;

}


extern int ITK_user_main( int argc, char **  argv )
{
    FILE * fileptr = NULL;

   int line_count    = 0;
	int ifail         = ITK_ok;
	int len           = 0;
	int num_created   = 0;
	int num_failed    = 0;
	int num_notExits  = 0;
  // int isValid       =0;
   char         *upwf             = NULL;
  	char			 **Attributes     = NULL;
   char line_in[555 + 1] = "";
   char * ptr = 0;
   char logfilename[255 + 1] = "";
	char * classname = "FVE_Milestone";
   char * stdname = NULL;
	const char * verbose = NULL;
   const char * filename = NULL;
   char line_temp[555 + 1] ="";
	char *  login_group = NULL;
   char *  login_user = NULL;
   char * login_password = NULL;
	char * time_stamp = NULL;
   int   num = 0;
   int   count = 0;
   struct stat file_stat;
	char* id = NULL;
  	logical exists = FALSE;
    char       *tmp_dir_path                    = NULL;


	/*----------------------------------------------------------*/
    /*  Log files are placed in the directory specified by the  */
    /*  environment variable TC_TMP_DIR. If this is not set   */
    /*  the files are created in the current directory where    */
    /*  the executable is being run.                            */
    /*----------------------------------------------------------*/
    tmp_dir_path = getenv( DT_TMP_DIR_VAR );

    /*Append the log file name with the date and time stamp
    along with Process ID */
	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	if (tmp_dir_path == NULL)
	{
		sprintf(logfilename,"CREATE_MILESTONES_%s.log",time_stamp);
	}
	else
	{
#ifdef UNX
		sprintf(logfilename,"%s/CREATE_MILESTONES_%s.log",tmp_dir_path, time_stamp);
#else
		sprintf(logfilename,"%s\\CREATE_MILESTONES_%s.log",tmp_dir_path, time_stamp);
#endif
	}

	logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(logfileptr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);

    if(logfileptr)
    {
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
		  FVDT_FREE(time_stamp)
    }
    /*if( argc != 5)
    {
      fprintf(logfileptr,"All the required arguments are not present\n");
      fclose( logfileptr );
      print_usage();
      exit(0);
    }*/
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

   filename = ITK_ask_cli_argument("-file=");
	login_user = ITK_ask_cli_argument("-u=");
	login_password = ITK_ask_cli_argument("-p=");
	login_group = ITK_ask_cli_argument("-g=");
   upwf = ITK_ask_cli_argument("-pf=");/* gets the password file*/

   if (filename== NULL || strlen(filename)==0)
   {
        printf("ERROR: File Name is missing");fflush(stdout);
        fprintf(logfileptr,"ERROR: File Name is missing\n\n");
        print_usage();
        exit(0);

   }


	printf("filename is %s\n", filename);fflush(stdout);

  	/*-------------------------------------------*/
   /*          Decrypt the password             */
   /*-------------------------------------------*/
   if( upwf != 0 )
   {
      readAndDecryptPasswd( upwf, &login_password) ;
   }

   if ( login_user != NULL && strlen(login_user)!=0 &&  login_password != NULL && strlen(login_password)!=0 &&  login_group != NULL && strlen(login_group)!=0)
   {
      ITK(ITK_init_module (login_user, login_password, login_group))
      if(ifail != ITK_ok)
         fprintf(logfileptr,"Login with uid: %s, group:%s is unsuccessful\n", login_user, login_group);
      else
         fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n", login_user, login_group);
   }
   else
   {
      ITK_initialize_text_services (0);
      ITK (ITK_auto_login ())
      if(ifail != ITK_ok)
         fprintf(logfileptr,"Auto Login unsuccessful\n");
      else
         fprintf(logfileptr,"Auto Login successful\n");
   }



   if ( verbose != 0 )
   {
      verbose_flag = true;
   }

   if ( filename != NULL)
   {
      fileptr = fopen(filename, "r");
      if (fileptr == NULL)
      {
         fprintf(logfileptr, "ERROR: Can not open input file:%s\n", filename);
         get_time_stamp(DATE_FORMAT_STR, &time_stamp);
         fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
         FVDT_FREE(time_stamp)
         fclose(logfileptr);
         ITK_exit_module( true );
         exit(1);
      }
   }
    stat( filename, &file_stat);

    /*If input file size is Zero, Exit*/
   if( file_stat.st_size == 0 )
   {
      printf("ERROR: Input File [%s] is empty!!.\n", filename);
      fprintf(logfileptr,"ERROR: Input File [%s] is empty!!.\n", filename);
      get_time_stamp(DATE_FORMAT_STR, &time_stamp);
      fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
      FVDT_FREE(time_stamp)
      fclose( logfileptr );
      ITK_exit_module( true );
      exit(1);
   }

   if ( fileptr != NULL )
   {
      line_count = 0;
      while (fgets(line_in, 1110, fileptr) != 0)
      {
         id = NULL;
         stdname = NULL;
         line_count++;
         len = (int) strlen(line_in);
         if (len > 0 && line_in[len-1] == '\n')
             line_in[len-1] = '\0';
         if ( strlen(  line_in ) == 0 )
             continue;

		 if( strstr(line_in, "#" ) == NULL )
		 {
         	strcpy( line_temp, line_in);

         	 ITK(POM_does_class_exist (classname, &exists))
			 if (!exists)
			 {
				fprintf(logfileptr,"ERROR: %s is not a valid class name\n", classname);
				exit(0);
			 }

			 FVDT_String_to_StringArray(line_temp, &Attributes, "|", &count);

		   /*  ITK(FVDT_validate_data_in_file(Attributes, count, classname, line_count, &isValid));

			 if (isValid)
				continue; */


			 //printf("\nAttributes[0] %s, Attributes[1] %s\n", Attributes[0], Attributes[1]);fflush(stdout);

			 FVDT_WSO_uniq_check( Attributes, classname, &num);

			 if(num ==0)
			 {
				FVE_create_name(Attributes, &num_created, classname, &num_failed);
			 }
			else
			{
				fprintf(logfileptr,"Name %s already exists in %s.\n",Attributes[0],classname);
				num_notExits++;
			}
	 	 }
		 else
		 {
			 printf("Skipping the comment line\n");
		 }


         FVDT_FREE_ARRAY( Attributes, count);

      }

     /* Reset the input file to begin reading from the begining*/
     fseek( fileptr, 0, 0 );
   }

   printf("\nImport  successful.\n\n");
   fprintf(logfileptr,"\nImport  successful\n");

   printf("Processing Completed.\n");
   fprintf(logfileptr,"Processing completed.\n");

   ITK_exit_module( true );

   fprintf(logfileptr,"\nNumber of Build Point CREATED are %d\n\n", num_created);
   fprintf(logfileptr,"\nNumber of Build Point ALREADY EXISTS are %d\n\n", num_notExits);
   fprintf(logfileptr,"\nNumber of Build Point FAILED are %d\n\n", num_failed);

   printf("Utility completed successfully.\n\n");
   fprintf(logfileptr,"\nUtility completed successfully.\n\n");
   get_time_stamp(DATE_FORMAT_STR, &time_stamp);
   fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
   FVDT_FREE(time_stamp)

   if (logfileptr ) fclose( logfileptr);
   if (fileptr ) fclose( fileptr);

   return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


int FVDT_WSO_uniq_check(char** Attributes, char *classname, int* num)
{
	int ifail = ITK_ok;
  	WSO_search_criteria_t criteria;
  	tag_t StdSignalName  = NULLTAG;
	tag_t SigSysName     = NULLTAG;
	tag_t SigSubSysName  = NULLTAG;
	tag_t SignalName     = NULLTAG;
  	tag_t enqid1   = NULLTAG;
	tag_t enq_id1  = NULLTAG;
	tag_t enq_id2  = NULLTAG;
	tag_t enq_id3  = NULLTAG;
	tag_t enq_id4  = NULLTAG;
	tag_t enq_id5  = NULLTAG;
  	tag_t * StdSignalName_objs = NULL;

   *num = 0;


   ITK(WSOM_clear_search_criteria(&criteria));
   tc_strcpy(criteria.class_name, classname);
   tc_strcpy(criteria.name, Attributes[0]);
   ITK(WSOM_search(criteria, num, &StdSignalName_objs));

  	FVDT_FREE(StdSignalName_objs);
   return ifail;
}


/*--------------------------------------------------------------------------*/

static void print_usage(void)
{
   printf("\n**********************************************************************************\n");
   printf("Usage: FVDT_create_milestones <args>\n\n");
   printf(" Where args include the following:\n\n");
   printf(" [-u=<login user id> {-p=password | -pf=passwordFile}] -g=<login group> -class=FVE_Milestone -file=<Full path of FVE_build_points.txt>\n\n");
   printf("Each record in the file contains the following in the order specified:\n\n");
   printf("Milestone ID|Milestone Name|Milestone Description|Milestone Sort Order|Milestone Build Point|Milestone Active\n\n");
   printf(" -v is a flag that will turn on verbose mode\n");
   printf("\n");
   printf(" NOTE:- \n");
   printf("**********************************************************************************\n\n");
}
/*input id is just needed for subsystem*/
int FVE_create_name(char ** Attributes, int * created_cnt, char *classname, int * failed_cnt)
{
	int ifail = ITK_ok;
	int unit_cnt = 0;

	logical verdict = FALSE;
	tag_t ObjType = NULLTAG;
	tag_t ObjInputTag = NULLTAG;
	tag_t Obj = NULLTAG;
	tag_t desc_prop_tag = NULLTAG;

	tag_t pomInstanceTag = NULLTAG;
	tag_t instanceClassTag = NULLTAG;

	printf ("Creating object with id %s for class %s\n", Attributes[0],classname );

	ITK(TCTYPE_find_type(classname, NULL,&ObjType))
	ITK(TCTYPE_construct_create_input(ObjType, &ObjInputTag)) 

    ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
	ITK(TCTYPE_set_create_display_value(ObjInputTag, FVE_MILESTONE_ID_ATTR, 1, (const char**)&Attributes[0]))
	ITK(TCTYPE_set_create_display_value(ObjInputTag, FVE_MILESTONE_NAME_ATTR, 1, (const char**)&Attributes[1]))
	ITK(TCTYPE_set_create_display_value(ObjInputTag, FVE_MILESTONE_DESC_ATTR, 1, (const char**)&Attributes[2]))
	ITK(TCTYPE_set_create_display_value(ObjInputTag, FVE_MILESTONE_SORT_ORDER_ATTR, 1, (const char**)&Attributes[3]))
	ITK(TCTYPE_set_create_display_value(ObjInputTag, FVE_MILESTONE_UNIT_NUM_ATTR, 1, (const char**)&Attributes[4]))
	ITK(TCTYPE_set_create_display_value(ObjInputTag, FVE_MILESTONE_ACTIVE_MILESTONE_ATTR, 1, (const char**)&Attributes[5]))

  	ITK(TCTYPE_create_object(ObjInputTag, &Obj))
	ITK(AOM_save(Obj))

	if(ifail == ITK_ok)
	{
		(*created_cnt)++;
         fprintf(logfileptr,"SUCCESS: %s has been created successfully in %s\n", Attributes[0], classname);
	}
	else
	{
		fprintf(logfileptr,"FAILED: Creation of %s in %s failed\n",Attributes[0], classname);
		(*failed_cnt)++;
	}
	return ifail;
}

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
}

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}

/* int FVDT_validate_data_in_file (char ** Attributes, int count, char *classname, int line_count,int *isValid)
{
   int ifail = ITK_ok, i=0;
   *isValid = 0;

   if (strcmp(classname, SIG_CLASSNAME_CONST)== 0)
   {
      if (count < 3 )
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, number of coulmn is less than three \n", line_count);

      }
      else
      {
         for ( i =0 ;i<count ;i++ )
         {
            if (Attributes[i]==NULL || strlen(Attributes[i])==0)
            {
               *isValid = 1;
               fprintf(logfileptr,"Error: line no %d, one of the column is blank\n", line_count);
            }
         }
      }
   }
   else if (strcmp(classname, SUBSYS_CLASSNAME_CONST)== 0)
   {
      if (count < 1 ||  Attributes[0]==NULL || strlen(Attributes[0])==0)
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, first column of the line is blank\n", line_count);
      }


   }
   else if (strcmp(classname, COMP_CLASSNAME_CONST)== 0)
   {
      if (count < 1 ||  Attributes[0]==NULL || strlen(Attributes[0])==0)
      {
         *isValid = 1;
         fprintf(logfileptr,"Error: line no %d, first column of the line is blank\n", line_count);
      }
   }

	return ifail;

} */

