//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6Stock_custom_acl
 *
 */
#include <O6TaneCustomLibrary/O6Stock_custom_acl.hxx>
#include <O6TaneCustomLibrary/method.hxx>

int O6Stock_custom_acl ( METHOD_message_t * /*m*/, va_list args )
{
	tag_t object = va_arg( args, tag_t );
	//logical *p_is_modifiable = va_arg( args, logical *);
	/*=*/
	int irc=ITK_ok, itk_stored_error=ITK_ok;
	logical is_modifiable=FALSE;

	//(*p_is_modifiable)=FALSE;
	//{
		//tag_t object=NULLTAG;
		int compute_cde=0;

		//irc = ITK_CALL(PROP_ask_owning_object( tg_property, &object ));
		irc = ITK_CALL(AOM_ask_value_int(object, CMP_CDE, &compute_cde));

		if ( compute_cde != 100 )
		{
			is_modifiable=TRUE;
		}

		/*=*/
		if ( !is_modifiable )
		itk_stored_error=919109;
	//}

	if ( itk_stored_error != ITK_ok )
	{
		irc = ITK_CALL(EMH_store_error ( EMH_severity_information, itk_stored_error ));
	}

	//(*p_is_modifiable)=is_modifiable;

	return ITK_ok;
}
