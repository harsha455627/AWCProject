#!/bin/ksh
export TC_ROOT=$TC_ROOT
export TC_DATA=$TC_DATA

. $TC_DATA\tc_profilevars

$TC_ROOT\FVE_kit\server\bin\SUN\FVE_reminder_notification.exe -u=$FVE_USER -p=$FVE_PASSWORD -g=$FVE_GROUP