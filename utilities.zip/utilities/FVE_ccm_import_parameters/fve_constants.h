/******************************************************************************
 * Filename        :   fve_constants.h
 * Description     :   Defines the macro used in fve_import_parameters.c
 * Module          :   fve_import_parameters.exe 
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * 03-Apr-2012    Swapnal Shewale	      Initial Code
 * 08-June-2012   Swapnal Shewale     Added constants for structure data i.e.1D LOOKUP 2D LOOKUP...
 * 21-June-2012   Swapnal Shewale     Added constants for rowLabels and colLabels
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_CONSTANTS_H
#define FVE_CONSTANTS_H


#define FV_error_base								(920000)
#define FVE_error_base								(919000)

#define FV_ALLOCATE_MEMORY_FAILURE   	             (FV_error_base +23)
#define FV_ITEMREV_WITHOUT_BVR						 (FV_error_base +48)
#define FV_INVALID_RELATION_TYPE                     (FV_error_base +26)
#define DICT_LOCK_CANT_ADD_FVEPROCESSREV			 (FVE_error_base + 90)
#define FV_CCDM_ERROR_INVALID_ISSIGNED    				(FV_error_base + 103)
#define FV_CCDM_ERROR_NOT_IN_RANGE       				(FV_error_base + 104)
#define FV_CCDM_ERROR_INVALID_VALUE       				(FV_error_base + 105)
#define FV_CCDM_ERROR_VALUE_NOT_ACTUAL_INCREMENT_OF_RES (FV_error_base + 106)
#define FV_CCDM_ERROR_INSUFFICIENT_INCREMENT            (FV_error_base + 107)
#define FV_CCDM_ERROR_INVALID_INITVALUE					(FV_error_base + 121)
#define FV_CCDM_ERROR_INVALID_LENGTH                    (FV_error_base + 122)


//#define MAX_STRCT									(10000)
#define MAX_STRCT									(20000)

//delimeter used to parse file
#define	CSV_DEFAULT_FILE_DELIM						("||")
#define CSV_DOMAINDESCR_DELIMITER					("$$")
#define	TXT_FILE_DELIM								("=")
#define	COMMA_DELIM									(",")
#define	SEMICOLON_DELIM								(";")
#define FV_INTEGER_LEN								(15)
#define DATE_FORMAT									("%d-%b-%Y")
#define FV_SW_ENGG_ROLE								("Software Engineer")
#define FV_Module_SVR_ROLE							("Module Supervisor")
#define	DBA_ROLE									("DBA")
#define CONF_COORD_ROLE                             ("Configuration Coordinator")
#define PARM_GRP_DEF								("FVE_ParmGrpDef")
#define PARM_GRPS								    ("FVE_ParmGrps")
#define FVE_ParmGrpDefRevisionTYPE                  ("FVE_ParmGrpDefRevision")
#define FVE_ParmGrpsRevisionTYPE                    ("FVE_ParmGrpsRevision")
#define FVE_ECCTProjectRevisionTYPE                 ("FVE_ECCTProjectRevision")
#define ParmGrpDefRevisionTYPE						("ParmGrpDefRevision")
#define representsPROP								("represents")
#define Parameter_DictionaryVALUE					("Parameter Dictionary")
#define Organizational_GroupVALUE					("Organizational Group")
#define PARM_GRP									("Parameter Group")
#define ECCTProjectVALUE							("ECCT Project")
#define	CONTENTS_ATTR_NAME							("contents")
#define ParmDefRevisionTYPE							("ParmDefRevision")


//Parm types map from cvs file for CCM
#define PARM_TYPE_DISCRETE							("Discrete")
#define	PARM_TYPE_NUMERIC							("Numeric")
#define PARM_TYPE_CHARACTER							("Character")

//Structure data Map from csv file for CCM
#define ScalarInfo									("Scalar")
#define Lookup2DInfo								("2D Lookup")
#define Lookup1DInfo								("1D Lookup")
#define	Array2DInfo									("2D array")
#define Array1DInfo									("1D array")


//unit from csv file
#define	UNITLESS_UNIT								("Unitless")
#define NONE_UNIT									("None")
#define PARAMETER_TYPE_DEFAULT_VAL					("Configuration")
#define NAUNIT										("N/A")

//Actual value for parameter value object for BCM
#define DEFAULTValue								("DEFAULT")

//mode
#define PARAMETER_MODE								("parameter")
#define	PROCESS_MODE								("process")
#define	ALL_MODE									("all")

#define	object_stringPROP							("object_string")
#define	viewVIEW									("view")

//denominator constant for Integer
#define FVE_Int_Denominator_Value					("1")

#define FV_LEVEL_ZERO (0)
#define FV_ALL_LEVELS (-1)

#define FV_UNIQUE_VALUES (TRUE)
#define FV_ALL_VALUES (FALSE)

//custom Item Types
#define	FVE_ParmDefIntTYPE							("FVE_ParmDefInt")
#define	FVE_ParmDefDblTYPE							("FVE_ParmDefDbl")
#define	FVE_ParmDefSEDTYPE							("FVE_ParmDefSED")
#define FVE_ParmDefStrTYPE							("FVE_ParmDefStr")
#define FVE_ParmDefBoolTYPE							("FVE_ParmDefBool")
#define FVE_ParmDefBCDTYPE							("FVE_ParmDefBCD")
#define FVE_ParmDefBitDfTYPE						("FVE_ParmDefBitDf")
#define FVE_ParmDefDateTYPE							("FVE_ParmDefDate")
#define FVE_ParmDefHexTYPE							("FVE_ParmDefHex")
#define FVE_ECCTProjectTYPE							("FVE_ECCTProject")
#define FVE_ECCTProjectRevisionTYPE					("FVE_ECCTProjectRevision")
#define FV9ParmDfIntUsgTYPE							("FV9ParmDfIntUsg")
#define FV9ParmDfDblUsgTYPE							("FV9ParmDfDblUsg")
#define FV9ParmDfBCDUsgTYPE							("FV9ParmDfBCDUsg")
#define FV9ParmDfBitDUsgTYPE						("FV9ParmDfBitDUsg")
#define FV9ParmDfBoolUsgTYPE						("FV9ParmDfBoolUsg")
#define FV9ParmDfDateUsgTYPE						("FV9ParmDfDateUsg")
#define FV9ParmDfStrUsgTYPE							("FV9ParmDfStrUsg")
#define FV9ParmDfSEDUsgTYPE							("FV9ParmDfSEDUsg")
#define FV9ParmDfHexUsgTYPE							("FV9ParmDfHexUsg")
#define FV9ParmDfUsgRevisionTYPE					("FV9ParmDfUsgRevision")

#define	FV9ParmValStrTYPE							("FV9ParmValStr")
#define	FV9ParmValHexTYPE							("FV9ParmValHex")
#define	FV9ParmValSEDTYPE							("FV9ParmValSED")
#define	FV9ParmValIntTYPE							("FV9ParmValInt")
#define	FV9ParmValDblTYPE							("FV9ParmValDbl")
#define	FV9ParmValBCDTYPE							("FV9ParmValBCD")


//custom Item Revision Types
#define	FVE_ParmDefIntRevisionTYPE					("FVE_ParmDefIntRevision")
#define FVE_ParmDefDblRevisionTYPE					("FVE_ParmDefDblRevision")
#define FVE_ParmDefSEDRevisionTYPE					("FVE_ParmDefSEDRevision")
#define FVE_ParmDefStrRevisionTYPE					("FVE_ParmDefStrRevision")
#define FVE_ParmDefHexRevisionTYPE					("FVE_ParmDefHexRevision")


#define	FV9ParmValStrRevisionTYPE					("FV9ParmValStrRevision")
#define	FV9ParmValHexRevisionTYPE					("FV9ParmValHexRevision")
#define	FV9ParmValSEDRevisionTYPE					("FV9ParmValSEDRevision")
#define	FV9ParmValIntRevisionTYPE					("FV9ParmValIntRevision")
#define	FV9ParmValDblRevisionTYPE					("FV9ParmValDblRevision")
#define	FV9ParmValBCDRevisionTYPE					("FV9ParmValBCDRevision")

#define FV9ParmDfIntUsgRevisionTYPE					("FV9ParmDfIntUsgRevision")
#define FV9ParmDfDblUsgRevisionTYPE					("FV9ParmDfDblUsgRevision")
#define FV9ParmDfBCDUsgRevisionTYPE					("FV9ParmDfBCDUsgRevision")
#define FV9ParmDfBitDUsgRevisionTYPE				("FV9ParmDfBitDUsgRevision")
#define FV9ParmDfBoolUsgRevisionTYPE				("FV9ParmDfBoolUsgRevision")
#define FV9ParmDfDateUsgRevisionTYPE				("FV9ParmDfDateUsgRevision")
#define FV9ParmDfStrUsgRevisionTYPE					("FV9ParmDfStrUsgRevision")
#define FV9ParmDfSEDUsgRevisionTYPE					("FV9ParmDfSEDUsgRevision")
#define FV9ParmDfHexUsgRevisionTYPE					("FV9ParmDfHexUsgRevision")

//custom form types
#define FVE_ModelSpAttrFormTYPE						("FVE_ModelSpAttrForm")

#define	TableCellSEDCLASS							("TableCellSED")
#define	TableCellDoubleCLASS						("TableCellDouble")
#define	TableCellIntCLASS							("TableCellInt")
#define	TableCellStringCLASS						("TableCellString")
#define	TableCellHexCLASS							("TableCellHex")

//Relation Names
#define FVE_Model_spec_attrs_Rel_RELATION			("FVE_Model_spec_attrs_Rel")
#define FVE_SINK_RELATION							("FVE_Snk_Relation")
#define FVE_SOURCE_RELATION							("FVE_Srce_Relation")
#define FVE_SOURCE_SINK_RELATION					("FVE_Snk_Srce_Relation")
#define FVE_LOCAL_RELATION							("FVE_Loc_Relation")


//property names
#define	parmTypePROP								("parmType")
#define	FVE_EngUnitPROP								("FVE_EngUnit")
#define	FVE_ParameterUsagePROP						("FVE_ParameterUsage")
#define FVE_OverwritablePROP						("FVE_Overwritable")
#define	FVE_MSAUnitPROP								("fv9_MSAUnit")
#define	FVE_MSAResolutionPROP						("fv9_MSAResolution")
#define	FVE_MSAImplDataTypePROP						("fv9_MSAImplDataType")
#define	FVE_FaultValuePROP							("FVE_FaultValue")
#define	FVE_RestrictedPROP							("FVE_Restricted")
#define	FVE_OffsetPROP								("FVE_Offset")
#define	FVE_MSAOffsetPROP							("fv9_MSAOffset")
#define	FVE_InhaleExhaleIndPROP						("FVE_InhaleExhaleInd")
#define	FVE_AsBuiltVehOpsPROP						("FVE_AsBuiltVehOps")
#define	FVE_ModulemanfIndPROP						("FVE_ModuleManfInd")
#define	FVE_FCSDCustPrefPROP						("FVE_FCSDCustPref")
#define FVE_CommentsPROP							("FVE_Comments")
#define isSignedPROP								("isSigned")
#define	sizePROP									("size")
#define	FVE_CommentPROP								("FVE_Comment")
#define	FVE_DicIDPROP								("FVE_DicID")
#define fv9RefParmDefRevPROP						("fv9RefParmDefRev")
#define fv9RefParmDefPROP							("fv9RefParmDef")
#define fv9PartTypePROP								("fv9PartType")
#define fv9PartTypeListPROP							("fv9PartTypeList")

#define	FVE_ECUAcronymPROP							("FVE_ECUAcronym")
#define	FVE_ProcessNamePROP							("FVE_ProcessName")
#define FVE_ProcessTypePROP							("FVE_ProcessType")
#define FVE_TaskRatePROP							("FVE_TaskRate")


#define revisionPROP								("revision")
#define object_namePROP								("object_name")
#define object_descPROP								("object_desc")

#define FREEZE_STATUSTYPE							("ECCT Frozen")
#define DICTN_LOCK_STATUSTYPE						("Dictionary locked")

#define FV_NULL_VALUE								("NULL")

//constants used in configuration file
#define FVE_CCM_CONFIG_FILE_NAME					("FVE_ccm_config.txt")
#define LOG_FILE_NAME								("CCM_LOG_FILENAME")
#define LOG_FILE_PATH								("CCM_LOG_FILE_PATH")
#define LOG_FILE_EXTENSION							("CCM_LOG_FILE_EXTENSION")
#define CCM_CSV_FILE_DELIMITER						("CCM_INPUT_FILE_DELIMITER")
#define	CCM_TOLERANCE_VALUE							("CCM_TOLERANCE_VALUE")

#define	precisionPROP								("precision")
#define	tolerancePROP								("tolerance")
#define resolution_numeratorPROP					("resolution_numerator")
#define resolution_denominatorPROP					("resolution_denominator")
#define	maxValuesPROP								("maxValues")
#define	minValuesPROP								("minValues")
#define	initialValuesPROP							("initialValues")
#define initialValuePROP							("initialValue")
#define	validValuesPROP								("validValues")
#define definitionPROP								("definition")
#define colsPROP									("cols")
#define rowsPROP									("rows")
#define	cellsPROP									("cells")
#define colLabelsPROP								("colLabels")
#define rowLabelsPROP								("rowLabels")
#define bl_item_object_namePROP                     ("bl_item_object_name")
#define bl_item_item_idPROP                         ("bl_item_item_id")
#define bl_revisionPROP                             ("bl_revision")

//properties for parameter value object
#define	fv9ValuesPROP								("fv9Values")
#define	fv9TableDefinitionPROP						("fv9TableDefinition")
#define	fv9RefParmDefRevPROP						("fv9RefParmDefRev")


#define HEX											("0x")

#define	valuePROP									("value")

#define DATE_FORMAT_STR								"%Y%m%d_%H%M%S"

//query entries
#define FIND_PROCESS_IN_CONTEXT						("FVEFindProcessesInContext")
#define RELATION_NAME								("RelationName")
#define DIC_ID										("DictionaryID")
#define DIC_REV_ID									("DictionaryRevID")
#define PARMDEF_ID									("ParamDefID")

#define MODULE_PROCESS_RELATION						("FVE_Mod_Proc_Relation")

#if defined(WNT)
	//#define FILEPATH_DELIMITER       "\\"
      #define FILEPATH_DELIMITER       "/"
#else
	#define FILEPATH_DELIMITER       "/"
#endif

#endif
