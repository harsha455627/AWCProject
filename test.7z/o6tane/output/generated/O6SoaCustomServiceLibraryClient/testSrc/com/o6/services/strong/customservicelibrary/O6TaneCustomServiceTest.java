/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
@<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

package com.o6.services.strong.customservicelibrary;


import com.teamcenter.soa.client.Connection;
import com.teamcenter.soa.client.model.ModelManager;
import com.teamcenter.utest.SoaSession;

import junit.framework.TestCase;

public class O6TaneCustomServiceTest extends TestCase
{
    private Connection        connection;
    private ModelManager      manager;
    private O6TaneCustomServiceService   service;
    

    public O6TaneCustomServiceTest( String name )
    {
        super( name );
    }

    protected void setUp( ) throws Exception
    {
        super.setUp( );

        connection  = SoaSession.getConnection();
        manager     = connection.getModelManager();       
        service     = O6TaneCustomServiceService.getService(connection);

    }
        
    
    public void testCalculateINCIs()
    {
        // TODO write test code, then remove fail()
        // service.calculateINCIs(  )
        fail("This test has not been implemented yet");
    }

    public void testCopyObjectAndCreateRelation()
    {
        // TODO write test code, then remove fail()
        // service.copyObjectAndCreateRelation(  )
        fail("This test has not been implemented yet");
    }

    public void testGetTargets()
    {
        // TODO write test code, then remove fail()
        // service.getTargets(  )
        fail("This test has not been implemented yet");
    }

    public void testCopyObjectAndCreateRelation()
    {
        // TODO write test code, then remove fail()
        // service.copyObjectAndCreateRelation(  )
        fail("This test has not been implemented yet");
    }

    public void testCalculateQSP()
    {
        // TODO write test code, then remove fail()
        // service.calculateQSP(  )
        fail("This test has not been implemented yet");
    }


}

