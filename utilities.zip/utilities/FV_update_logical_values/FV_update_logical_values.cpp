/******************************************************************************
File        : FV_update_logical_values.cpp
Description : Utility to get objects of given type(s) which have blank values for given boolean properties
              and update the values to false.

Date          Author                    Reason
08/21/2017    VenuBabu Avala            Initial Version
****************************************************************************/  

/*
Compile
%TC_ROOT%\sample\compile -DIPLIB=none FV_update_logical_values.cpp

Link and Create Executable File
%TC_ROOT%\sample\linkitk -o FV_update_logical_values FV_update_logical_values.obj
*/

#include <tc/tc.h>
#include <tccore/tctype.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <tc/folder.h>
#include <epm/epm.h>
#include <res/res_itk.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <pom/pom/pom.h>
#include <pom/enq/enq.h>
#include <tccore/grmtype.h>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_basic.h>
#include <fclasses/tc_date.h>
#include <fclasses/tc_string.h>
#include <time.h>

#define ITK( argument )                                             \
{                                                                   \
	int retCode = argument;                                         \
	if ( retCode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retCode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retCode );                        \
	EMH_ask_error_text (retCode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	}                                                               \
}

#define ERROR_CHECK( argument )                                     \
{                                                                   \
	int retCode = argument;                                         \
	if ( retCode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retCode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retCode );                        \
	EMH_ask_error_text (retCode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	return retCode;                                                 \
	}                                                               \
}

/********************************* start function declarations ***********************************/

int FV_get_and_update_logical_values(char *object_type, FILE *fp_report, FILE *fp_success, FILE *fp_error, FILE *fp_log, logical update_flag );

int fve_set_usr_and_mod_date_back( tag_t objectTag,  date_t lastModifiedDate, tag_t lastModifiedByUser);

void displayHelp();

/****************************** end function declarations *******************************************/

int ITK_user_main(int argc,char* argv[])
{
	int retcode = ITK_ok;

	ITK_initialize_text_services(0);

	if ( ITK_ask_cli_argument( "-h" ) != 0 )
	{
		displayHelp();
		return retcode;
	}

	char *user = ITK_ask_cli_argument("-u=");
	char *passwd = ITK_ask_cli_argument("-p=");
	char *group = ITK_ask_cli_argument("-g=");
	char *object_types = ITK_ask_cli_argument("-object_types=");
	char *update = ITK_ask_cli_argument("-update=");

	if( user == NULL || passwd == NULL || group == NULL )
	{
		displayHelp();
		return retcode;
	}
	
	ERROR_CHECK(ITK_init_module(user, passwd, group));

	logical bypass = false;

    ERROR_CHECK(ITK_ask_bypass( &bypass ));

    if( !bypass )
    {
        ITK(ITK_set_bypass( true ));
        bypass = true;
    }

	time_t start,end;
    double dif;
	
	time (&start);
	
	if ( object_types != NULL && tc_strlen( object_types ) > 0 )
	{
		int n_types = 0;
		char **type_names = NULL;
				
		ITK(EPM__parse_string(object_types, ",", &n_types, &type_names));
		
		for (int inx = 0; inx < n_types; inx++)
		{
			FILE *fp_report = NULL;
			FILE *fp_success = NULL;
			FILE *fp_error = NULL;
			FILE *fp_log = NULL;
			
			char *report_name = NULL;
			char *success_name = NULL;
			char *error_name = NULL;
			char *log_name = NULL;
			
			printf("Object Type [%d] : [%s]\n", inx, type_names[inx]);
		
			report_name = (char *) MEM_alloc((tc_strlen("RM_logical_values_report_")+tc_strlen(type_names[inx])+tc_strlen(".txt")+1)*sizeof(char));
			tc_strcpy(report_name, "RM_logical_values_report_");
			tc_strcat(report_name, type_names[inx]);
			tc_strcat(report_name, ".txt");
			
			success_name = (char *) MEM_alloc((tc_strlen("success_")+tc_strlen(type_names[inx])+tc_strlen(".txt")+1)*sizeof(char));
			tc_strcpy(success_name, "success_");
			tc_strcat(success_name, type_names[inx]);
			tc_strcat(success_name, ".txt");
			
			error_name = (char *) MEM_alloc((tc_strlen("error_")+tc_strlen(type_names[inx])+tc_strlen(".txt")+1)*sizeof(char));
			tc_strcpy(error_name, "error_");
			tc_strcat(error_name, type_names[inx]);
			tc_strcat(error_name, ".txt");
			
			log_name = (char *) MEM_alloc((tc_strlen("log_")+tc_strlen(type_names[inx])+tc_strlen(".log")+1)*sizeof(char));
			tc_strcpy(log_name, "log_");
			tc_strcat(log_name, type_names[inx]);
			tc_strcat(log_name, ".txt");
		
			fp_report = fopen(report_name, "w+");			
			fp_log = fopen(log_name, "w+");
			
			if ( fp_report == NULL )
			{
				fprintf(stderr, "ERROR: Cannot create report file : %s\n", report_name);
				return retcode;
			}			
			
			if ( fp_log == NULL )
			{
				fprintf(stderr, "ERROR: Cannot create log file : %s\n", log_name);
				return retcode;
			}
			
			if (update != NULL && (tc_strcmp( update, "Yes") == 0 || tc_strcmp( update, "Y") == 0 ))
			{
				fp_success = fopen(success_name, "w+");
				fp_error = fopen(error_name, "w+");
				
				if ( fp_success == NULL )
				{
					fprintf(stderr, "ERROR: Cannot create success file : %s\n", success_name);
					return retcode;
				}
				if ( fp_error == NULL )
				{
					fprintf(stderr, "ERROR: Cannot create error file : %s\n", error_name);
					return retcode;
				}
				
				ITK(FV_get_and_update_logical_values(type_names[inx], fp_report, fp_success, fp_error, fp_log, true));
			}
			else
			{
				ITK(FV_get_and_update_logical_values(type_names[inx], fp_report, fp_success, fp_error, fp_log, false));
			}
			
			if ( fp_report != NULL )
			{
				fclose(fp_report);
				fp_report = NULL;
			}
			if ( fp_success != NULL )
			{
				fclose(fp_success);
				fp_success = NULL;
			}
			if ( fp_error != NULL )
			{
				fclose(fp_error);
				fp_error = NULL;
			}
			if ( fp_log != NULL )
			{
				fclose(fp_log);
				fp_log = NULL;
			}
			MEM_free(report_name);
			MEM_free(success_name);
			MEM_free(error_name);
			MEM_free(log_name);
		}
		MEM_free(type_names);
	}
	
    time (&end);

	dif = difftime (end,start);
	printf ("It took %.2lf seconds OR %.2lf minutes to generate the report.\n", dif,dif/60 );
	TC_write_syslog ("It took %.2lf seconds OR %.2lf minutes to generate the report.\n", dif,dif/60 );

	ERROR_CHECK(ITK_exit_module(true));

	return retcode;
}

void displayHelp()
{
	printf("************************************************************************************\n");
	printf("This utility will retrive the blank logical values of fv9Mil, fv9Hil, fv9BreadBoard, fv9Vehicle, fv9Sil, fv9Pil for given object types\n");
	printf("and updates them to false.\n\nThis utility accepts the following arguments.\nplease run with dba previleges and turn on bypass before running this utility.\n\n");
	printf("-u=<userid>..\n");
	printf("-p=<password>..\n");
	printf("-g=<dba>..\n");
	printf("-object_types=<coma separated values of object types>..\n");
	printf("-update=<Yes or No. If No, Only report will be generated and attributes will not be updated>..\n");
	printf("************************************************************************************");
}

int FV_get_and_update_logical_values(char *object_type, FILE *fp_report, FILE *fp_success, FILE *fp_error, FILE *fp_log, logical update_flag )
{
	int retcode = ITK_ok;
	int rows = 0;
	int columns = 0;
	int null_operator = 0;
	int active_seq = 0;

	void ***report = NULL;
	
	const char *select_attr_list_item[] = {"puid","item_id"};
	const char *select_attr_list_rev[] = {"puid","item_revision_id","last_mod_user", "last_mod_date", "fv9Mil", "fv9Hil", "fv9BreadBoard", "fv9Vehicle", "fv9Sil", "fv9Pil"};
	const char *select_attr_list_user[] = {"user_id", "user_name"};
	const char *QUERY_NAME = "FV_get_objects";

	ITK(POM_enquiry_create(QUERY_NAME));
	
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME, "Item", 2, select_attr_list_item));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME, object_type, 10, select_attr_list_rev));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME, "User", 2, select_attr_list_user));
	
	ITK(POM_enquiry_set_int_value(QUERY_NAME, "active_seq", 1, &active_seq, POM_enquiry_const_value));
	
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp1", object_type, "items_tag", POM_enquiry_equal, "Item", "puid"));
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp2", object_type, "last_mod_user", POM_enquiry_equal, "User", "puid"));
	
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp3", object_type, "active_seq", POM_enquiry_not_equal, "active_seq"));
	
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp4", object_type, "fv9Mil", POM_enquiry_is_null,""));
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp5", object_type, "fv9Sil", POM_enquiry_is_null,""));
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp6", object_type, "fv9Hil", POM_enquiry_is_null,""));
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp7", object_type, "fv9BreadBoard", POM_enquiry_is_null,""));
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp8", object_type, "fv9Pil", POM_enquiry_is_null,""));
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp9", object_type, "fv9Vehicle", POM_enquiry_is_null,""));
	
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp10","exp4",POM_enquiry_or,"exp5"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp11","exp6",POM_enquiry_or,"exp7"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp12","exp8",POM_enquiry_or,"exp9"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp13","exp10",POM_enquiry_or,"exp11"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp14","exp13",POM_enquiry_or,"exp12"));
	
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp15","exp1",POM_enquiry_and,"exp2"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp16","exp15",POM_enquiry_and,"exp3"));
	
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp17","exp16",POM_enquiry_and,"exp14"));

	ITK(POM_enquiry_set_where_expr(QUERY_NAME,"exp17"));

	ITK(POM_enquiry_add_order_attr(QUERY_NAME, "Item", "item_id", POM_enquiry_asc_order));
	ITK(POM_enquiry_add_order_attr(QUERY_NAME, object_type, "item_revision_id", POM_enquiry_asc_order));
	/* execute the query */
	ITK(POM_enquiry_execute(QUERY_NAME,&rows,&columns,&report));
	ITK(POM_enquiry_delete(QUERY_NAME));

	if( rows > 0 )
	{
		fprintf(fp_log,"No of Item Revisions with Blank Logical Values : %d\n", rows);
		fprintf(fp_report, "Item_ID|Rev_ID|Object_Type|fv9Mil|fv9Hil|fv9BreadBoard|fv9Vehicle|fv9Sil|fv9Pil|last_mod_user_id|last_mod_user_name|last_modified_date\r\n");
		
		for(int inx = 0; inx < rows; inx++)
		{
			char *date_string = NULL;
			tag_t item_rev_tag = (tag_t)(*((tag_t*) report[inx][2]));
			tag_t last_modified_user = (tag_t)(*((tag_t*) report[inx][4]));
			
			char *item_id = (char *) report[inx][1];
			char *item_revision_id = (char *) report[inx][3];
			char *user_id = (char *) report[inx][12];
			char *user_name = (char *) report[inx][13];
			
			logical fv9Mil = (logical) report[inx][6];
			logical fv9Hil = (logical) report[inx][7];
			logical fv9BreadBoard = (logical) report[inx][8];
			logical fv9Vehicle = (logical) report[inx][9];
			logical fv9Sil = (logical) report[inx][10];
			logical fv9Pil = (logical) report[inx][11];
							
			date_t last_modified_date = (date_t) (*((date_t*) report[inx][5]));
			
			ITK(ITK_date_to_string(last_modified_date, &date_string));
			
			fprintf(fp_report, "%s|%s|%s|%d|%d|%d|%d|%d|%d|%s|%s|%s\r\n",report[inx][1], report[inx][3], object_type, fv9Mil, fv9Hil, fv9BreadBoard, fv9Vehicle, fv9Sil, fv9Pil, user_id, user_name, date_string);
			
			if ( update_flag )
			{
				fprintf(fp_log,"Updating Item Revision %s/%s\r\n", item_id, item_revision_id);
				
				logical is_checked_out = false;
				logical process_rev = true;
				
                ITK(RES_is_checked_out(item_rev_tag, &is_checked_out))
				
		    	if( is_checked_out )
				{
					fprintf(fp_log,"\tItem Revision is checked out\r\n");
					fprintf(fp_log,"\tTrying to Check In...\r\n");
			    	ITK(RES_checkin(item_rev_tag));
					if( retcode != ITK_ok )
				    {
						fprintf(fp_log,"\tERROR: Unable to Check In. Error Code : %d\r\n", retcode);
						fflush(fp_log);
						retcode = ITK_ok;
						process_rev = false;
					}
					else
					{
						process_rev = true;
					}
				}
				if ( process_rev )
				{
					fprintf(fp_log,"\tLocking Item Revision for modification\r\n");
					
					ITK(AOM_lock(item_rev_tag));
				
					if ( fv9Mil == NULL )
					{
						ITK(AOM_set_value_logical(item_rev_tag, "fv9Mil", false));
						fprintf(fp_log,"\tUpdating fv9Mil to false\n");
					}				
					if ( fv9Hil == NULL )
					{
						ITK(AOM_set_value_logical(item_rev_tag, "fv9Hil", false));
						fprintf(fp_log,"\tUpdating fv9Hil to false\n");
					}
					if ( fv9BreadBoard == NULL )
					{
						ITK(AOM_set_value_logical(item_rev_tag, "fv9BreadBoard", false));
						fprintf(fp_log,"\tUpdating fv9BreadBoard to false\n");
					}				
					if ( fv9Vehicle == NULL )
					{
						ITK(AOM_set_value_logical(item_rev_tag, "fv9Vehicle", false));
						fprintf(fp_log,"\tUpdating fv9Vehicle to false\n");
					}
					if ( fv9Sil == NULL )
					{
						ITK(AOM_set_value_logical(item_rev_tag, "fv9Sil", false));
						fprintf(fp_log,"\tUpdating fv9Sil to false\n");
					}
					if ( fv9Pil == NULL )
					{
						ITK(AOM_set_value_logical(item_rev_tag, "fv9Pil", false));
						fprintf(fp_log,"\tUpdating fv9Pil to false\n");
					}
					fprintf(fp_log,"\tUpdating last_mod_user and last_mod_date back to original\r\n");
					ITK(fve_set_usr_and_mod_date_back(item_rev_tag, last_modified_date, last_modified_user));
					
					fprintf(fp_log,"\tSaving Item Revision after modification\r\n");
					
					ITK(AOM_save(item_rev_tag));
					if ( retcode != ITK_ok )
					{
						fprintf(fp_log,"\tUnable to save Item Revision\r\n");
					}
					else
					{
						fprintf(fp_success,"%s/%s|SUCCESS\r\n", item_id, item_revision_id);
					}
					ITK(AOM_unlock(item_rev_tag));
					fprintf(fp_log,"\tUnlocking Item Revision\r\n");					
				}
				else
				{
					fprintf(fp_error,"%s/%s|ERROR: Unable to Process Revision. Please check the log file\r\n", item_id, item_revision_id);
					fprintf(fp_log,"%s/%s|ERROR: Unable to Process Revision. Please check the log file\r\n", item_id, item_revision_id);
				}
				
			}
			MEM_free(date_string);
		}
	}
	
	return retcode;
}

int fve_set_usr_and_mod_date_back( tag_t objectTag,  date_t lastModifiedDate, tag_t lastModifiedByUser)
{
    int    retcode   =   ITK_ok;
	
	ITK( POM_set_env_info(POM_bypass_attr_update, true, 0, 0, NULLTAG, NULL) );
	ITK( POM_set_modification_user( objectTag, lastModifiedByUser ) );
	ITK( POM_set_modification_date( objectTag, lastModifiedDate) );
	ITK( POM_set_env_info(POM_bypass_attr_update, false, 0, 0, NULLTAG, NULL) );

	return retcode;
}