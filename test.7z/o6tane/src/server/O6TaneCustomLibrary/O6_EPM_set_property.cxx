
#include <O6TaneCustomLibrary/O6_EPM_set_property.hxx>
#include <O6TaneCustomLibrary/O6ActionHandlers.hxx>
#include <O6TaneCustomLibrary/O6ParseObjMapXML.hpp>
#include <cstdio>
#include <iostream>
#include <ctime>
#include <stdio.h>
#include <tccore/grm.h>
#include <stdio.h>
#include <pom/pom/pom.h>
#include <tccore/item.h>
#include <ps/ps.h>
#include <bom/bom.h>
#include <ae/tool.h>

#define SOURCE_PROPERTY "source_property"
#define TARGET_PROPERTY "target_property"
#define O6_FLE_REVISION "O6_FleRevision"
#define SET_PROP_HANDLER_ARG_NOT_FOUND ( SEEDS_CUSTOM_ERROR_BASE + 8 )

/**
 * Function    :  readArguments
 * Description :  Read handler arguments.
 * Input       :
 * 		 msg  <I>  - EPM_action_message
 * 		 args <OF> - Output structure
 *
 */
int readArgs ( EPM_action_message_t msg, handlerArgs &args )
{
	int retcode           = ITK_ok;
	int numberOfArguments = 0;

	numberOfArguments = TC_number_of_arguments ( msg.arguments );

	for ( int iInx = 0; iInx < numberOfArguments; iInx++ )
	{
		char* pcKey   = NULL;
		char* pcValue = NULL;

		ITK ( ITK_ask_argument_named_value ( TC_next_argument ( msg.arguments ), &pcKey, &pcValue ) );

		if ( tc_strcmp ( pcKey, SOURCE_PROPERTY ) == 0 && pcValue != NULL && ! string ( pcValue ).empty() )
		{
			args.sSourceProperty = string ( pcValue );
		}
		if ( tc_strcmp ( pcKey, TARGET_PROPERTY ) == 0 && pcValue != NULL && ! string ( pcValue ).empty() )
		{
			args.sTargetProperty = string ( pcValue );
		}
		if ( pcKey != NULL )
		{
			MEM_free ( pcKey );
			pcKey = NULL;
		}
		if ( pcValue != NULL )
		{
			MEM_free ( pcValue );
			pcValue = NULL;
		}
	}
	return retcode;
}

/**
 * Function    :  O6_EPM_set_property
 * Description :  Wrapper function to set one property value on another for the same target object.
 *
 * Input       :
 *		msg - Handler message
 *
 * Output
 *
 */
int O6_EPM_set_property ( EPM_action_message_t msg )
{
	handlerArgs args;

	int retcode           = ITK_ok;

	tag_t tRootTask       = NULLTAG;

	ITK ( readArgs ( msg, args ) );

	if ( retcode == ITK_ok && ( tc_strcmp ( ( args.sSourceProperty).c_str(), "" ) != 0 ) && ( tc_strcmp ( ( args.sTargetProperty ).c_str(), "" ) != 0 ) )
	{
		ITK ( EPM_ask_root_task ( msg.task, &tRootTask ) );

		if ( retcode == ITK_ok && tRootTask != NULLTAG )
		{
			int iTargetCount          = 0;

			tag_t* tTargetAttachments = NULL;

			ITK ( EPM_ask_attachments ( tRootTask, EPM_target_attachment, &iTargetCount, &tTargetAttachments ) );

			for ( int iInx = 0; iInx < iTargetCount; iInx++ )
			{
				tag_t tTargetClassID  = NULLTAG;
				tag_t tFLERevClassID  = NULLTAG;

				ITK ( POM_class_of_instance	( tTargetAttachments[iInx], &tTargetClassID ) );

				ITK ( POM_class_id_of_class	( O6_FLE_REVISION, &tFLERevClassID ) );

				if ( retcode == ITK_ok && tTargetClassID == tFLERevClassID )
				{
					double dTotCost = 0.0;

					ITK ( AOM_ask_value_double ( tTargetAttachments[iInx], args.sSourceProperty.c_str(), &dTotCost ) );

					if ( retcode == ITK_ok )
					{
						ITK ( AOM_refresh ( tTargetAttachments[iInx], true ) );
						ITK ( AOM_set_value_double ( tTargetAttachments[iInx], args.sTargetProperty.c_str(), dTotCost ) );

						if ( retcode == ITK_ok )
						{
							ITK ( AOM_save ( tTargetAttachments[iInx] ) );
							ITK ( AOM_refresh ( tTargetAttachments[iInx], false ) );
						}
					}
				}
			}
			if ( tTargetAttachments != NULL )
			{
				MEM_free ( tTargetAttachments );
				tTargetAttachments = NULL;
			}
		}
	}
	else
	{
		EMH_store_error ( EMH_severity_error, SET_PROP_HANDLER_ARG_NOT_FOUND );
		retcode = SET_PROP_HANDLER_ARG_NOT_FOUND;
	}
	return retcode;
}
