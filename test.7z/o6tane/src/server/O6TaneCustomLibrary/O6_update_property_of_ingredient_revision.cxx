//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6_update_property_of_ingredient_revision
 *
 */
#include <O6TaneCustomLibrary/O6_update_property_of_ingredient_revision.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <metaframework/CreateInput.hxx>
#include <tccore/method.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <stdarg.h>
#include <string>
#include <string.h>
#include <iostream>
#include <cstdlib>

#define OBJECT_NAME "object_name"
#define O6_IMPURETE "o6_impurete"
#define O6_INCI_USA "o6_inci_usa"
#define O6_INCI_EURO "o6_inci_euro"
#define O6_INCI_MIXTE "o6_inci_mixte"

/**
 * Function    :  O6_update_property_of_ingredient_revision
 * Description :  Update "o6_inci_mixte" of Ingredient Revision based on values of "o6_inci_euro" and "o6_inci_usa" if "o6_impurete" is false.
 * Input       :
 */

int O6_update_property_of_ingredient_revision( METHOD_message_t * /*msg*/, va_list args )
{
	int retcode = ITK_ok;

    tag_t tIngRevision = NULLTAG;
    char *cpUSAVal = NULL;
    char *cpEuroVal = NULL;
    char *Temp = NULL;
	logical lVal = false; ;
	va_list largs;
	va_copy( largs, args);
	tIngRevision = va_arg(largs,tag_t);
	va_end(largs);

	if(tIngRevision != NULLTAG )
	{
	 ITK(AOM_refresh(tIngRevision,TRUE));
	 ITK(AOM_ask_value_logical(tIngRevision,O6_IMPURETE,&lVal));
	 if(retcode == ITK_ok && lVal == false)
	  {
	   ITK(AOM_ask_value_string(tIngRevision,O6_INCI_USA,&cpUSAVal));
	   ITK(AOM_ask_value_string(tIngRevision,O6_INCI_EURO,&cpEuroVal));
	   if(retcode == ITK_ok && cpEuroVal != NULL && cpUSAVal != NULL)
		{
		  int iUSA = tc_strlen(cpUSAVal);
		  int iEURO = tc_strlen(cpEuroVal);
		  Temp = (char*)MEM_alloc(((iUSA * iEURO)+2) * sizeof(char));
		  if(tc_strcmp(cpUSAVal,cpEuroVal)==0)
		   {
			//TC_write_syslog("\n Both values are equal \n");
			tc_strcpy (Temp,cpEuroVal);
			ITK(AOM_set_value_string(tIngRevision,O6_INCI_MIXTE,Temp));
			//TC_write_syslog("\n Temp = %s \n",Temp);
		   }
		  else
		   {
		//	TC_write_syslog("\n Both values are not equal \n");
			tc_strcpy (Temp,cpEuroVal);
			tc_strcat(Temp,"/");
			tc_strcat(Temp,cpUSAVal);
			ITK(AOM_set_value_string(tIngRevision,O6_INCI_MIXTE,Temp));
			//TC_write_syslog("\n Temp = %s \n",Temp);
		   }
		  ITK(AOM_save_without_extensions(tIngRevision));
		}
	  }

	 ITK(AOM_refresh(tIngRevision,FALSE));
	 }
	 MEM_free(cpUSAVal);
	 MEM_free(cpEuroVal);
	 MEM_free(Temp);

	 return retcode;

}
