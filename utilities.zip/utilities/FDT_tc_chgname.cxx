/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: fdt_tc_chgname.cxx
    Module  : main


==============================================================================
Date               Name                    Description of Change
08/22/2011         Anirban Sarkar           Created
===============================================================================*/

extern "C"
{
#include <tccore/aom.h>
#include <tc/tc.h>
#include <sa/imanvolume.h>
#include <tc/iman_errors.h>
#include <fclasses/iman_string.h>
#include <sa/sa.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>
#include <textsrv/textserver.h>  // PR #4097059
#include <ctype.h>
#include <sys/stat.h>
#ifdef UNX
#include <grp.h>
#include <pwd.h>
#include <tc/emh.h>
#include <unistd.h>
#endif
}

#define GIVEN_GRP_DOESNOT_EXIST 919102
#define GIVEN_ROL_DOESNOT_EXIST 919103
#define PASSWORDKEY     "PASSWORDKEY"


static int change_group_name( const char *  old_name, const char * new_name );
static int change_role_name( const char *  old_name, const char * new_name );
static void print_usage(void);
int readAndDecryptPasswd( char *passwdFile, char **passwd ) ;

extern "C"
{
    extern void DecryptPasswd( char * chrPtr, char *key, char **out_passwd );
}

FILE *logfileptr = NULL;

extern int ITK_user_main( int argc, char **  argv )
{
    char             *pwdFile = NULL;
    char             logfilename[255 + 1] = "";
	char             *old_name = NULL;
	char             *new_name = NULL;
	char				 *type = NULL;

	 logical          hasError = false;


	time_t           clock;
    struct           stat file_stat;


	if( argc == 1 )
    {
        print_usage();
        exit(0);
    }
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

	 ITK_initialize_text_services (0);
    int  ifail;
    const char *  login_group = getenv("FVE_GROUP");
    const char *  login_user = getenv("FVE_USER");
    char *  login_password = getenv("FVE_PASSWORD");
        
    time( &clock );
    struct tm *time_struct= localtime(&clock);
    
    /*Append the log file name with the date and time stamp 
    along with Process ID */
    
    #ifdef UNX
        sprintf(logfilename,"%s_%d_%02d_%02d_%d_%02d:%02d.log",argv[0],getpid(),
                 (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );
    
       #else
       sprintf(logfilename,"%s_%02d_%02d_%d_%02d_%02d.log",argv[0],
                    (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );
   #endif
            
    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);
    
    
    if( logfileptr )
    {
        fprintf(logfileptr,"Utility name: %s\n\n",argv[0]);
        fprintf(logfileptr,"Start time: %s\n", ctime( &clock ) );
    }
    pwdFile = ITK_ask_cli_argument("-pf=");
    
    
    if( pwdFile != 0 )
    {                                        
        ifail = readAndDecryptPasswd( pwdFile, &login_password ) ;  
        if( ifail != ITK_ok )
        {
            if( logfileptr )
            {
                time( &clock );
                fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
                fclose( logfileptr );
            }
            exit(1);
        }
    }
    if( pwdFile != 0 )
    {
        if ( (login_user == NULL) || (login_group == NULL ) )
        {
            printf("ERROR-- The login environment not set.\n\n");
            printf(" Set the following Environment Variables   \n");
            printf(" FVE_USER - Valid Teamcenter Engineering Login User Id ( Should   \n");
            printf("                be infodba or any other user with dba \n");
            printf("                privelages )                          \n");
            printf( " FVE_GROUP - Teamcenter Engineering Login Group ( Should be dba or  \n");
            printf( "                 any group with DBA Privelages )      \n");
            if( logfileptr )
            {
                fprintf(logfileptr,"ERROR-- The login environment not set.\n\n");
                time( &clock );
                fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
                fclose( logfileptr );
            }
            exit(1);
        }
        
    }
    else 
    {
        if ( (login_user == NULL) || (login_password == NULL ) || (login_group == NULL ))
        {
            printf(" ERROR-- The login environment not set.\n\n");
            printf(" Set the following Environment Variables   \n");
            printf(" FVE_USER - Valid Teamcenter Engineering Login User Id ( Should   \n");
            printf("                be infodba or any other user with dba \n");
            printf("                privelages )                          \n");
            printf( " FVE_PASSWORD - Teamcenter Engineering Login Password for above User\n");
            printf( " FVE_GROUP - Teamcenter Engineering Login Group ( Should be dba or  \n");
            printf( "                 any group with DBA Privelages )      \n");
            if( logfileptr )
            {
                fprintf(logfileptr,"ERROR-- The login environment not set.\n\n");
                time( &clock );
                fprintf(logfileptr,"\nEnd time: %s\n", ctime( &clock ) ); 
                fclose( logfileptr );
            }
            exit(1);
        }
    }


	type = ITK_ask_cli_argument( "-type=" );
    old_name = ITK_ask_cli_argument( "-old=" );
    new_name = ITK_ask_cli_argument( "-new=" );

	if( (type == NULL ) && ( old_name == NULL ) && ( new_name == NULL))
    {
        print_usage();
        exit(0);
    }

	/***********************************************************************
    Login 
    ***********************************************************************/
    
    printf("Logging in...\n");
    fprintf(logfileptr,"Logging in...\n");
    if (( ifail = ITK_init_module(login_user,login_password,login_group)) != ITK_ok)
    {
        fprintf(stderr,"\nERROR: %d, Failed to login, See syslog file for details\n", ifail);
        if( logfileptr )
        {
            fprintf(logfileptr,"ERROR: Failed to login.See syslog file for details\n" ); 
            time( &clock );
            fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) ); 
            fclose( logfileptr );
        }
        exit(1);
    }
    printf("Logged in successfully.\n", argv[0]);
    fprintf(logfileptr,"Logged in successfully.\n");
    
    printf("\nProcessing...\n");
    fprintf(logfileptr,"Processing...\n");
    
    ifail = SA_init_module();
    if (ifail != ITK_ok)
    {
        fprintf(stderr,"Failed to initialise the SA module %d - see \"%s.jnl\" file\n", ifail, argv[0]);
        fprintf(logfileptr,"Failed to initialise the SA module %d - see \"%s.jnl\" file\n", ifail, argv[0]);
        time( &clock );
        fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );
        exit(1);
    }

	/***********************
	 start processing request
	 ************************/

	if ( strcmp( type , "group") == 0 )
	{
		  ifail = change_group_name( old_name, new_name);
            if ( ifail != ITK_ok )
            {
                
                if ( ifail == GIVEN_GRP_DOESNOT_EXIST )
                {
                    if ( logfileptr )
                    {
                           fprintf(logfileptr,"ERROR: Group [%s] does not exist.\n",old_name);
                     }
                }

				hasError = true;
			 }
	}
	if ( strcmp( type , "role") == 0 )
	{
		  ifail = change_role_name( old_name, new_name);
            if ( ifail != ITK_ok )
            {
                
                if ( ifail == GIVEN_ROL_DOESNOT_EXIST )
                {
                    if ( logfileptr )
                    {
                           fprintf(logfileptr,"ERROR: Role [%s] does not exist.\n",old_name);
                     }
                }

				hasError = true;
			 }
	}


	if ( ( hasError == true ) ) 
    {
        printf("Utility completed with Errors. Refer log file.\n\n");
        fprintf(logfileptr,"\nUtility completed with Errors.\n\n");
        time( &clock );       
        fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );
    }
    else
    {
        printf("Utility completed successfully.\n\n");
        fprintf(logfileptr,"\nUtility completed successfully.\n\n");
        time( &clock );
        fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );
    }
    
    if (logfileptr ) fclose( logfileptr);
      
    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


static int change_group_name( const char *  old_name, const char * new_name )
{
	tag_t  group_tag = NULLTAG ;

	#ifdef DEBUG
       printf("Into change_group_name for <%s> \n",old_name);
    #endif
    int  stat = SA_find_group( old_name, &group_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR finding group \"%s\": %d from SA_find_group.\n", old_name, stat );
        return stat;
    }
    
    if( group_tag == NULLTAG )
    {
        fprintf( logfileptr,"Group [%s] already exists.\n", old_name );
        return ITK_ok;
    }

	stat = AOM_refresh( group_tag, true );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR %d locking group.\n", stat );
		return stat;
    }

	stat = SA_set_group_name( group_tag, new_name);
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR setting group name: %d from SA_set_group_name.\n", stat );
        return stat;
     }

	stat = AOM_save( group_tag );
    if ( stat != ITK_ok )
    {
          fprintf( logfileptr,"ERROR %d save group. \n", stat );
          return stat;
    }

    stat = AOM_unlock(group_tag );
    if ( stat != ITK_ok )
    {
          fprintf( logfileptr,"ERROR %d unlock group.\n", stat );
          return stat;
    }


	 #ifdef DEBUG
        printf("Outof change_group name for <%s> with stat <%d> \n",old_name,stat);
    #endif
    
    return ITK_ok;
}

static int change_role_name( const char *  old_name, const char * new_name )
{
	tag_t  role_tag = NULLTAG ;

	#ifdef DEBUG
       printf("Into change_role_name for <%s> \n",old_name);
    #endif
    int  stat = SA_find_role( old_name, &role_tag );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR finding role \"%s\": %d from SA_find_role.\n", old_name, stat );
        return stat;
    }
    
    if( role_tag == NULLTAG )
    {
        fprintf( logfileptr,"Role [%s] does not exists.\n", old_name );
        return ITK_ok;
    }

	stat = AOM_refresh( role_tag, true );
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR %d locking role.\n", stat );
		return stat;
    }

	stat = SA_set_role_name( role_tag, new_name);
    if ( stat != ITK_ok )
    {
        fprintf( logfileptr,"ERROR setting group name: %d from SA_set_role_name.\n", stat );
        return stat;
     }

	stat = AOM_save( role_tag );
    if ( stat != ITK_ok )
    {
          fprintf( logfileptr,"ERROR %d save role. \n", stat );
          return stat;
    }

    stat = AOM_unlock(role_tag );
    if ( stat != ITK_ok )
    {
          fprintf( logfileptr,"ERROR %d unlock role.\n", stat );
          return stat;
    }


	 #ifdef DEBUG
        printf("Outof change_role name for <%s> with stat <%d> \n",old_name,stat);
    #endif
    
    return ITK_ok;
}


/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                    */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */                                                                          
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  10/21/2004      Ramesh Ramaiah            Initial Creation              */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;
    
    
    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        if( logfileptr )
        fprintf( logfileptr, "ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);
    
    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }
    
 //   DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;
    
    return ifail;
        
}

static void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: FDT_tc_chgname <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -type=<group/user/role>    type of the item.\n");
        printf(" -old=<old name>   old name of the item.For group we need fully qualified name.\n");
        printf(" -new=<new name>   new name of the item.\n");
		printf("**********************************************************************************\n\n");
        
}