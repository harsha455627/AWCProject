/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/


#include <unidefs.h>
#if defined(SUN)
#    include <unistd.h>
#endif

#include<O6TaneCustomService1711IiopSkeleton.hxx>


#include <teamcenter/soa/internal/common/PolicyMarshaller.hxx>
#include <teamcenter/soa/internal/server/PolicyManager.hxx>
#include <teamcenter/soa/internal/server/PerServicePropertyPolicy.hxx>
#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace std;
using namespace Teamcenter::Soa::Server;
using namespace Teamcenter::Soa::Internal::Server;
using namespace Teamcenter::Soa::Internal::Common;
using namespace Teamcenter::Soa::Common::Exceptions;


namespace O6
{
    namespace Services
    {
    
        namespace CustomServiceLibrary
        {
             namespace _2017_11
             {




    O6TaneCustomServiceIiopSkeleton::O6TaneCustomServiceIiopSkeleton():
        IiopSkeleton()
    {
        m_serviceName = "O6TaneCustomService";
    
       _svcMap[ "copyObjectAndCreateRelation" ]   = copyObjectAndCreateRelation;

    }
    
    O6TaneCustomServiceIiopSkeleton::~O6TaneCustomServiceIiopSkeleton()
    {
    	// If the implementing class did not implement the ServicePolicy
    	// then delete it, since it was allocated here in the skeleton
	 	Teamcenter::Soa::Server::ServicePolicy* sp = dynamic_cast<Teamcenter::Soa::Server::ServicePolicy *>(_service);
    	if(sp == NULL)
    	{
    		delete _servicePolicy;
    	}
        delete _service;
    }



     void O6TaneCustomServiceIiopSkeleton::initialize()
    {
   	// If the impl class has not implemented the ServicePolicy interface
    	// Create an instance of the default ServicePolicy
	 	_servicePolicy = dynamic_cast<Teamcenter::Soa::Server::ServicePolicy *>(_service);
    	if(_servicePolicy == NULL)
    	{
    		_servicePolicy = new Teamcenter::Soa::Server::ServicePolicy;
    	}
    }




    static O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomServiceImpl* _service;
	static Teamcenter::Soa::Server::ServicePolicy*  	 _servicePolicy;


    void O6TaneCustomServiceIiopSkeleton::copyObjectAndCreateRelation( const std::string& xmlOrJsonDoc, Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse )
    {
        ScopedJournal _journalSkeleton( "O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomService::O6TaneCustomServiceIiopSkeleton::copyObjectAndCreateRelation" );

        std::string _contentType;
        BusinessObjectRef<Teamcenter::WorkspaceObject>  obj;
        std::string  targetItemtype;
        std::string  targetItemPattern;
        std::string  targetItemVersion;
        Teamcenter::Soa::Server::ServiceData _out;

        //  ========== Parse the input XML or JSON document to the local input arguments ==========
        {
            ScopedJournal _journalParse( "O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomService::O6TaneCustomServiceIiopSkeleton::copyObjectAndCreateRelation - Parse input document" );
            Teamcenter::Soa::Internal::Server::SdmParser _sdmParser( xmlOrJsonDoc );
            _contentType = _sdmParser.getDocumentType();
            _sdmParser.parseStructMember( "obj", obj );
            _sdmParser.parseStructMember( "targetItemtype", targetItemtype );
            _sdmParser.parseStructMember( "targetItemPattern", targetItemPattern );
            _sdmParser.parseStructMember( "targetItemVersion", targetItemVersion );
        }        


        //  ===================== Call the service operation implementation  ======================
        {
            ScopedJournal journalExecute( "O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomService::O6TaneCustomServiceImpl::copyObjectAndCreateRelation" );
            _out = _service->copyObjectAndCreateRelation( obj, targetItemtype, targetItemPattern, targetItemVersion );
        }

        //  ================== Serialize the response to a XML or JSON document  ==================
        {
            ScopedJournal _journalSerialize(  "O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomService::O6TaneCustomServiceIiopSkeleton::copyObjectAndCreateRelation - Serialize output document" );
            Teamcenter::Soa::Internal::Server::SdmStream _sdmStream(  _contentType, gatewayResponse.getBodyOutputStream() );
            _sdmStream.setServiceData( &_out );
            _sdmStream.writeFrameworkMember( _out );          
        }
    }




O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomServiceImpl* O6TaneCustomServiceIiopSkeleton::_service = new O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomServiceImpl;
Teamcenter::Soa::Server::ServicePolicy*  	  O6TaneCustomServiceIiopSkeleton::_servicePolicy = NULL;
static Teamcenter::Soa::Internal::Gateway::T2LService* me_O6TaneCustomService = Teamcenter::Soa::Internal::Gateway::TcServiceManager::instance().registerService( "CustomServiceLibrary-2017-11-O6TaneCustomService", new O6TaneCustomServiceIiopSkeleton );

 //register the service for getServiceList()
 static std::string registeredServiceOnStartup_O6TaneCustomService = Teamcenter::Soa::Internal::Server::ServiceManager::instance().registerService("CustomServiceLibrary-2017-11-O6TaneCustomService");

}}}}    // End Namespace

