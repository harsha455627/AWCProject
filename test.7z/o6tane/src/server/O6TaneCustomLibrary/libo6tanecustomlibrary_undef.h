//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBO6TANECUSTOMLIBRARY) && !defined(IPLIB)
#   error IPLIB or LIBO6TANECUSTOMLIBRARY is not defined
#endif

#undef O6TANECUSTOMLIBRARY_API
#undef O6TANECUSTOMLIBRARYEXPORT
#undef O6TANECUSTOMLIBRARYGLOBAL
#undef O6TANECUSTOMLIBRARYPRIVATE
