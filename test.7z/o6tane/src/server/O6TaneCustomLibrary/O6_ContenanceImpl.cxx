//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object O6_ContenanceImpl
//

#include <O6TaneCustomLibrary/O6_ContenanceImpl.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <algorithm>

#include <fclasses/tc_string.h>
#include <tc/tc.h>

#define O6_CONTENANCE_UNITE "o6_contenance_unite"
#define O6_CONTENANCE_AFFICHEE "o6_contenance_affiche"
#define O6_DENSITE_REELE "o6_cpd_densite_reelle"
#define UOM_ML "ml"
#define UOM_G "g"

using namespace o6tane;

//----------------------------------------------------------------------------------
// O6_ContenanceImpl::O6_ContenanceImpl(O6_Contenance& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
O6_ContenanceImpl::O6_ContenanceImpl( O6_Contenance& busObj )
   : O6_ContenanceGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// O6_ContenanceImpl::~O6_ContenanceImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
O6_ContenanceImpl::~O6_ContenanceImpl()
{
}

//----------------------------------------------------------------------------------
// O6_ContenanceImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int O6_ContenanceImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = O6_ContenanceGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

/**
 * Function		: findCountOfChar
 * Description	: Finding count of characters in a string
 * Input		:
 * 		sDensite 		 - String in which character to be found
 * 		pcDecimalSymbol  - Character to be found in the string
 * Output		:
 * 		count            - Count of characters found in the string
 */
int findCountOfChar ( string sDensite, char pcDecimalSymbol )
{
	int i       = 0;
	int count   = 0;
	int contain = 0;

	while ( ( contain = sDensite.find ( pcDecimalSymbol, i ) ) != string::npos )
	{
	    count++;
	    i = contain + 1;
	}

	return count;
}

///
/// Getter for a Double Property
/// @param value - Parameter Value
/// @param isNull - Returns true if the Parameter value is null
/// @return - Status. 0 if successful
///
int  O6_ContenanceImpl::getO6_rt_net_wt_ozBase( double & value, bool & /*isNull*/ ) const
{
    int retcode = ITK_ok;

    // Your Implementation
    tag_t tFormTag = NULLTAG;

    tFormTag = this->getO6_Contenance()->getTag();

    if ( tFormTag != NULLTAG )
    {
    	char* pcUnite = NULL;

    	ITK ( AOM_ask_value_string ( tFormTag, O6_CONTENANCE_UNITE, &pcUnite ) );

    	if ( retcode == ITK_ok && pcUnite != NULL && strlen ( pcUnite ) > 0 )
    	{
    		if ( tc_strcmp ( pcUnite, UOM_ML ) == 0 )
    		{
    			char* pcDensiteReele = NULL;

    			ITK ( AOM_ask_value_string ( tFormTag, O6_DENSITE_REELE, &pcDensiteReele ) );

    			if ( retcode == ITK_ok && pcDensiteReele != NULL && strlen ( pcDensiteReele ) > 0 )
    			{
    				double dDensiteReele = 0.0;

    				string sDensite      = "";

    				sDensite = string ( pcDensiteReele );

    				if ( ! ( sDensite.find_first_not_of ( "01234567890,." ) != std::string::npos ) )	// Validation for string to allow only double values
    				{
    					int iCommaCount = 0;
    					int iPointCount = 0;

    					iCommaCount = findCountOfChar ( sDensite, ',' );
    					iPointCount = findCountOfChar ( sDensite, '.' );

    					if ( ! ( iCommaCount > 0 && iPointCount > 0 ) ) // Ensuring presence of only one comma or semicolon in the string value
    					{
							if ( iCommaCount == 0 ) // Condition to check for '.' in absence of ','
							{
								if ( iPointCount == 0 || iPointCount == 1 ) // If it contains a decimal point or whole number
								{
									dDensiteReele = stod ( sDensite );
								}
							}
							else if ( iCommaCount == 1 ) // If it contains single ','
							{
								std::replace ( sDensite.begin(), sDensite.end(), ',', '.' ); // Replacing ',' with '.' for conversion to double
								dDensiteReele = stod ( sDensite );
							}
    					}
    				}

    				if ( dDensiteReele > 0 ) // If valid double value
    				{
    					double dAffichee = 0.0;
    					ITK ( AOM_ask_value_double ( tFormTag, O6_CONTENANCE_AFFICHEE, &dAffichee ) );

    					if ( retcode == ITK_ok )
    					{
    						double dValue = 0.0;

    						int iCast     = 0;

    						dValue = dAffichee * dDensiteReele / 28.3495;

    						iCast = ( int )( dValue * 10 );
    						dValue = ( ( double ) iCast ) / 10;

    						value = dValue;
    					}
    				}
    			}
    			if ( pcDensiteReele != NULL )
    			{
    				MEM_free ( pcDensiteReele );
    				pcDensiteReele = NULL;
    			}
    		}
    		if ( tc_strcmp ( pcUnite, UOM_G ) == 0 )
    		{
    			double dAffichee = 0.0;

				ITK ( AOM_ask_value_double ( tFormTag, O6_CONTENANCE_AFFICHEE, &dAffichee ) );

				if ( retcode == ITK_ok )
				{
					double dValue = 0.0;

					int iCast     = 0;

					dValue = dAffichee / 28.3495;

					iCast = ( int )( dValue * 10 );
					dValue = ( ( double ) iCast ) / 10;
					value = dValue;
				}
    		}
    	}
    	if ( pcUnite != NULL )
    	{
    		MEM_free ( pcUnite );
    		pcUnite = NULL;
    	}
    }
    return retcode;
}
