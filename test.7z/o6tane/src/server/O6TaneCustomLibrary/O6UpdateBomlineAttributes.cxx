//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6UpdateBomlineAttributes
 *
 */
#include <O6TaneCustomLibrary/O6UpdateBomlineAttributes.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <bom/bom.h>

#define FLE_BATCH_REV "O6_FleBatchRevision"
#define OBJECT_TYPE "object_type"

/**
 * Function    :  O6UpdateBomlineAttributes
 * Description :  It calls the BOMWindow Save extension.
 * Input
 * 		args - Arguments
 */
int O6UpdateBomlineAttributes( METHOD_message_t * /*msg*/, va_list args )
{
	int retcode = ITK_ok;
	int skipBVRUpdate =0;

	tag_t flebatchRevTag = NULLTAG;

	va_list largs;
	va_copy( largs, args);
	flebatchRevTag = va_arg(largs, tag_t);

	skipBVRUpdate = va_arg(largs, int);

	va_end( largs );

	// Call only if skipBVRUpdate == 0 i.e. it is calling update operation
	if (flebatchRevTag != NULLTAG && skipBVRUpdate == 0) {
TC_write_syslog("Entered into this function O6UpdateBomlineAttributes..............\n");
		char* objtype = NULL;
		ITK(AOM_ask_value_string(flebatchRevTag, OBJECT_TYPE, &objtype));
		if (retcode == ITK_ok && objtype != NULL) {
			if (tc_strcmp(objtype, FLE_BATCH_REV) == 0) {
				TC_write_syslog("Entered into this function O6UpdateBomlineAttributes as object type is fle batch..............\n");
				int nbvrs = 0;
				tag_t *bvrs = NULL;
				ITK(AOM_ask_value_tags(flebatchRevTag, "structure_revisions",&nbvrs, &bvrs));
				if (nbvrs > 0 && bvrs != NULL) {

					tag_t newwindow = NULLTAG;
					tag_t newbom_line = NULLTAG;
					ITK(BOM_create_window(&newwindow));
					ITK(BOM_set_window_pack_all (newwindow, false));
					if (retcode == ITK_ok && newwindow != NULLTAG ) {
						ITK(BOM_set_window_top_line(newwindow, NULLTAG, flebatchRevTag, NULLTAG, &newbom_line));
						if (retcode == ITK_ok && newbom_line != NULL) {
							int chld_cnt =0;
							tag_t *children = NULLTAG;

							ITK(BOM_line_ask_child_lines (newbom_line, &chld_cnt, &children));
							/* Do not remove this if condition otherwise the code will go in infinite loop
							 */
							if(chld_cnt > 0 && children != NULL){

								MEM_free(children);
								children = NULL;
							/*
							 * No need to put any logic here since all the logic to calculate
							 * bom line attribute values are placed on extension which is being
							 * calls when BOM_save_window API calls.
							 */
							ITK(BOM_save_window(newwindow));
							}
						}
						ITK(BOM_close_window(newwindow));
					}
					MEM_free(bvrs);
					bvrs = NULL;
				}
			}
			MEM_free(objtype);
			objtype = NULL;
		}
	}
	TC_write_syslog("Exit out of this function O6UpdateBomlineAttributes..............\n");
 return retcode;

}
