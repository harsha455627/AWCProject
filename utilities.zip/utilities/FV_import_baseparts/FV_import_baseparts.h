/******************************************************************************
 * Filename        :   FV_import_baseparts.h
 * Description     :   Defines the macro used in FV_import_baseparts
 * Module          :   FV_import_baseparts.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * August 2016      Vinay Deshmukh    Intial Verison.
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/

#pragma once
#ifndef FV_IMPORT_PICKLIST_VALUES_H
#define FV_IMPORT_PICKLIST_VALUES_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>
#include <string.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <FV_prototypes.h>
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>
#include <ps/ps.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <FVDT_common.h>

#if defined(_WIN32)
#include <windows.h>
#include <strsafe.h>
#else
#include <unistd.h>
#include <dirent.h>
#include <sys/wait.h>
#endif

/*************************************************
* Macros Definition
**************************************************/
#define FV9ECUBasePartNumberTYPE    ("FV9ECUBasePartNumber")
#define FVE_ECURevisionTYPE		    ("FVE_ECURevision")
#define DELIMITER					("|")


/* Property Constant
****************************************************/


/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
//#define LOG_STATUS \
//{\
//   if (ifail != ITK_ok)\
//   {\
//      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
//      ifail = ITK_ok;\
//   }\
//}\

//#define CLEANUP(x)                                             \
//{                                                              \
//    if ( ifail == ITK_ok )                                     \
//    {                                                          \
//        if ( (ifail = (x)) != ITK_ok )                         \
//        {                                                      \
//           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
//           goto CLEANUP;                                       \
//        }                                                      \
//    }                                                          \
//}
 

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
/*#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\*/

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

int FV_create_workspace_objects(char **PartBase_array,char **PartClass_array,char **PartDesc_array,char **PartStatus_array,char **ECUAcronym_array,int num_column);
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );
void get_time_stamp(char* format, char** timestamp);
void FV_get_value_and_store(char * init_value, int cnt, char *** str_array);
#endif
