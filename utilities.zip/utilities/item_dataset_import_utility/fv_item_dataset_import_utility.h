/******************************************************************************
 * Filename        :   fv_item_dataset_import_utility.h
 * Description     :   Defines the macro used in fv_item_dataset_import_utility
 * Module          :   fv_import_item_dataset_utility.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name					Description of Change
 * Jan 2016			Pournima Hawaldar       Intial Verison.
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FV_ITEM_DATASET_IMPORT_UTILITY_H
#define FV_ITEM_DATASET_IMPORT_UTILITY_H
#ifdef __cplusplus
extern "C" {
#endif

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>
#include <string.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <FV_prototypes.h>
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>
#include <ps/ps.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <FV_prototypes.h>
#include <FVDT_common.h>
#include "FV_includes.h"
#include <FV_macros.h>

/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\


#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}	 
/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );
void get_time_stamp(char* format, char** timestamp);
int FV_create_item(int createTypeCnt, char** createTypeNames, int bitMaskMode,
		                 int inputItemAttrCnt, char** inputItemAttrNames, char** inputItemAttrValues,
		                 int inputRevAttrCnt, char** inputRevAttrNames, char** inputRevAttrValues, tag_t* newRevTag);
int FV_set_application_bypass(logical trueFalseAction, char* callingFunctionName);
int ask_populated_datasets(tag_t objectTag,char* relationTypename,int *datasetCnt, tag_t** datasetTags);
void find_column_indexes(int column_array_cnt ,char ** column_array);
int fve_autologin();
int createDataset(char *datasetName, char *DTstTypeName ,tag_t *dataset);
void print_usage(void);
void ask_property_value_by_name(tag_t object, char *prop_name,char **prop_value);
int ask_dataset_imanfile_named_references(tag_t dataset,int* referenceNameCount, char ***reference_names, int* referenceObjCount, tag_t **reference_objects);
int report_imanfile_references(int n, char **reference_names,tag_t *reference_objects);
int ask_imanfile_path(tag_t fileTag, char *path);
int delete_dataset_named_reference(tag_t dataset, char *reference_name,tag_t reference_object);
int ask_file_format(char *path);
tag_t import_os_file(char *os_path_name, char *new_os_name);
int add_dataset_named_reference(tag_t dataset, char *reference_name,tag_t imported_file);
int add_or_delete_dataset_named_reference(tag_t newRevTag,char *DTstTypeName,char** itemDSRelNames,int namedRefNameCnt,char** namedRefValues);
int FV_find_type_valid_attrs(char* createTypeNames,char* column,char* columnAttrValue,int* itemAttrNameCnt,char*** itemAttrNames,int* itemAttrValuesCnt,char*** itemAttrValues);
int get_all_unique_dataset_type_names_from_input_file_for_relation(char* itemDSRelTypeNm, char** itemDSRelNames, int namedRefNameCnt,char** namedRefValues, int* uniqueDSTypeNamesFromInputCount, char*** uniqueDSTypeNamesFromInput);
int get_all_unique_dataset_type_names_for_relation(tag_t revTag, char* itemDSRelTypeNm, int* uniqueDSTypeNamesCount, char*** uniqueDSTypeNames, int* secondaryDatasetsCnt, tag_t** secondaryDatasets);

#endif 
