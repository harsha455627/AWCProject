/******************************************************************************
 * Filename        :   FVE_milestone_notification.h
 * Description     :   Defines the macro used in FVE_milestone_notification.c
 * Module          :   FVE_milestone_notification.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * April,30 2010    Arvind Kumar      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_MILESTONE_NOTIFICATION_H
#define FVE_MILESTONE_NOTIFICATION_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <epm/epm.h>
#include <tccore/aom_prop.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <tcinit/tcinit.h>

/*************************************************
* Macros Definition
**************************************************/
#define     FVE_STARTED_WORKFLOW_TASK_QRY "InParamvalueWorkflow_query"
#define     FVE_VEH_NOTIFICATION_CLASS    "FVE_VehNotificationStorage"
#define     FVE_WF_TASK_ASSIGNMENT_CLASS  "FVE_WfTaskMSAssignmtStorage"
#define     FVE_JOB_NAME                  "job_name"
#define     FVE_OBJECT_NAME               "object_name"
#define     FVE_PARENT_NAME               "parent_name"
#define     FVE_MONTHLY                   "Monthly"
#define     FVE_WEEKLY                    "Weekly"
#define     FVE_DAILY                     "Daily"
#define     FVE_WF_PROCESS_ID_ATTR        "FVE_WorkflowProcessID"
#define     FVE_WORKFLOW_TASK             "FVE_WorkflowTask"
#define     FVE_MILESTONE_ID_ATTR         "FVE_MilestoneID"
#define     FVE_VEH_PRG_ID_ATTR           "FVE_VehPrgID"
#define     FVE_VEH_PRG_REV_ATTR          "FVE_VehPrgRev"
#define     FVE_NOTIF_STATUS_ATTR         "FVE_NotifStatus"
#define     FVE_WEEKS_BEFORE_MS_ATTR      "FVE_WeeksBeforeMS"
#define     FVE_VEH_MS_ASSIGNMT_CLASS     "FVE_VehMSAssignmentStorage"
#define     FVE_MS_DUE_DATE_ATTR          "FVE_MilestoneDueDate"  
#define     FVE_BEFORE_TWO_MONTH_ATTR     "FVE_BeforeTwoMonths"
#define     FVE_BEFORE_ONE_MONTH_ATTR     "FVE_BeforeOneMonth"
#define     FVE_BEFORE_ONE_WEEK_ATTR      "FVE_BeforeOneWeek"
#define     FVE_AFTER_N_DAYS_ATTR         "FVE_AfterNDays"

/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

// Date format is DD-MMM-YYYY
#define DATE_FORMAT      "%d-%b-%Y"

#define ITK(x) \
{\
   if ( ifail == ITK_ok )\
   {\
      if((ifail = (x)) != ITK_ok)\
      {\
         dump_itk_errors ( ifail, #x, __LINE__, __FILE__ );\
      }\
   }\
}\

// date_t   date  (O)
// Returns the current date.
#define GET_CURRENT_DATE_TIME(date) \
{\
   struct tm *now;\
   time_t cdt;\
   time(&cdt);\
   now = (struct tm*)localtime(&cdt);\
   date.year   = (byte)now->tm_year + 1900;\
   date.month  = (byte)now->tm_mon;\
   date.day    = (byte)now->tm_mday;\
   date.hour   = (byte)now->tm_hour;\
   date.minute = (byte)now->tm_min;\
   date.second = (byte)now->tm_sec;\
}\

// date_t   SrcDate  (I)
// int      days     (I)
// date_t   NextDate (O)
// Returns previous/next date for the given date and number of days(can be +ve or -ve)
#define GET_NEXT_DATE(SrcDate, days, NextDate) \
{\
   struct tm tp;\
   struct tm* ts;\
   time_t temp;\
   tp.tm_sec  = (int) SrcDate.second;\
   tp.tm_min  = (int) SrcDate.minute;\
   tp.tm_hour = (int) SrcDate.hour;\
   tp.tm_mday = ((int) SrcDate.day) + days;\
   tp.tm_mon  = (int) SrcDate.month;\
   tp.tm_year = ((int) SrcDate.year) - 1900;\
   tp.tm_isdst= 1;\
   temp = mktime(&tp);\
   ts = localtime(&temp);\
   NextDate.second = ( byte) ts->tm_sec;\
   NextDate.minute = (byte) ts->tm_min ;\
   NextDate.hour =  (byte) ts->tm_hour;\
   NextDate.day = (byte)ts->tm_mday;\
   NextDate.month = ( byte)ts->tm_mon;\
   NextDate.year = (short) ( ts->tm_year + 1900);\
}\

// date_t   Date1   (I)
// date_t   Date2   (I)
// int      answer  (O)
// Return -1 if Date1 is less than Date2
// Return 0 if Date1 is equal to Date2
// Return 1 if Date1 is greater than Date2
#define COMPARE_DATES(Date1, Date2, answer) \
{\
   int year, month, day;\
   year = Date1.year - Date2.year;\
   month = Date1.month - Date2.month;\
   day = Date1.day - Date2.day;\
   if(year == 0 && month == 0 && day == 0)\
      answer = 0;\
   else if(year > 0)\
      answer = 1;\
   else if(year < 0)\
      answer = -1;\
   else if(month > 0)\
      answer = 1;\
   else if(month < 0)\
      answer = -1;\
   else if(day > 0)\
      answer = 1;\
   else if(day < 0)\
      answer = -1;\
}\

#endif /* FVE_MILESTONE_NOTIFICATION_H */