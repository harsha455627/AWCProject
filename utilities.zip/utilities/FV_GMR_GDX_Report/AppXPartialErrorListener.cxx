//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#include <teamcenter/clientx/AppXPartialErrorListener.hxx>

#include <iostream>

#include <teamcenter/soa/client/ModelObject.hxx>

using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Soa::Client;


void AppXPartialErrorListener::handlePartialErrors( const std::vector< Teamcenter::Soa::Client::ErrorStack >& stacks)
{
    if (stacks.size() == 0) return;

    cout <<  "" << endl;
    cout <<  "*****"<< endl;
    cout <<  "Partial Errors caught in Teamcenter::ClientX::AppXPartialErrorListener."<< endl;

    for (size_t i = 0; i < stacks.size(); i++)
    {
        cout <<  "Partial Error for ";

        // The different service implementation may optionally associate
        // an ModelObject, client ID, or nothing, with each partial error
        if (stacks[i].hasAssociatedObject())
        {
            cout << "object " << stacks[i].getAssociatedObject()->getUid() << endl;
        }
        else if (stacks[i].hasClientId())
        {
            cout << "client id " <<  stacks[i].getClientId() << endl;
        }
        else if ( stacks[i].hasClientIndex())
            cout << "client index " <<  stacks[i].getClientIndex() << endl;

        // Each Partial Error will have one or more contributing error messages
        for (int j = 0; j < stacks[i].getErrorValueCount(); j++)
        {
            ErrorValue  error = stacks[i].getErrorValue( j );
            cout << "    Code: " << error.code << "\tSeverity: " <<
                error.level << "\t" << error.message << endl;
        }
    }

}


