//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#include <teamcenter/hello/GDXReport.hxx>
#include <teamcenter/hello/Hello.hxx>
#include <teamcenter/clientx/AppXSession.hxx>

#include <teamcenter/schemas/soa/_2006_03/exceptions/ServiceException.hxx>
#include <teamcenter/services/query/SavedqueryService.hxx>
#include <teamcenter/services/core/DatamanagementService.hxx>
#include <teamcenter/services/core/FilemanagementService.hxx>
#include <teamcenter/services/core/SessionService.hxx>
#include <teamcenter/soa/client/model/ImanQuery.hxx>
#include <teamcenter/soa/client/FccProxy.hxx>
#include <teamcenter/soa/client/NotLoadedException.hxx>
#include <teamcenter/soa/client/RuntimeException.hxx>
#include <teamcenter/services/importexport/FileimportexportService.hxx>
#include <teamcenter/services/importexport/_2011_06/Fileimportexport.hxx>
#include <teamcenter/services/core/_2010_04/Datamanagement.hxx>


using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Hello;
using namespace Teamcenter::Schemas::Soa::_2006_03::Exceptions;
using namespace Teamcenter::Services::Importexport;
using namespace Teamcenter::Services::Query;
using namespace Teamcenter::Services::Core;
using namespace Teamcenter::Soa::Common;
using namespace Teamcenter::Soa::Client;
using namespace Teamcenter::Soa::Client::Model;

void GDXReport::generateReport(FILE *gdxLogFile ,std::string directory,std::vector<std::string> templateNames,std::vector<std::string> reportNames)
{
	int		ifail			= ITK_ok;
	char*	filePath		= NULL;
//	char*	filePath1		= NULL;
	//std::string templateName = "FV9_GMRDB_Excel_Export_Template";

	if((templateNames.empty()) || (templateNames.size() < 1))
	{
		fprintf(gdxLogFile,"\nInput Template Names is Null.\n");
		fflush(gdxLogFile);
        return;
	}

	if((reportNames.empty()) || (reportNames.size() < 1))
	{
		fprintf(gdxLogFile,"\nInput Report Names is Null.\n");
		fflush(gdxLogFile);
        return;
	}

	if(directory.empty() || directory.length() < 1)
	{
		fprintf(gdxLogFile,"\nInput NAS Directory Path is Null.\n");
		fflush(gdxLogFile);
        return;
	}

	if(reportNames.size() != templateNames.size())
	{
		cout<< "Number of Input Templates and report Names do not Match."<< endl;
		cout<< "Please confirm you have provided report Names for all templates..,"<<endl;
		fprintf(gdxLogFile,"\n Number of Input Templates and report Names do not Match.\n Please confirm you have provided report Names for all templates..\n");
		fflush(gdxLogFile);
        return;
	}

	//AutoPtr<ImanQuery>queryGeneral;	
	AutoPtr<ImanQuery>queryDID;
	AutoPtr<ImanQuery>queryDTC;
	AutoPtr<ImanQuery>queryECU;
	AutoPtr<ImanQuery>queryRTN;
	AutoPtr<ImanQuery>queryFTB;

	vector<AutoPtr<ModelObject> > foundObjs;
	vector<AutoPtr<ModelObject> > foundECUObjs;
	vector<AutoPtr<ModelObject> > exportObjs;

	// Get the service stubs
    SavedqueryService* queryService = SavedqueryService::getService(AppXSession::getConnection());
    DatamanagementService* dmService= DatamanagementService::getService(AppXSession::getConnection());
	FileimportexportService* ieService =  FileimportexportService::getService(AppXSession::getConnection());
	try
	{
		//*****************************
        // Find Required Queries
        //*****************************

		SavedqueryService::GetSavedQueriesResponse savedQueries = queryService->getSavedQueries();
        if (savedQueries.queries.size() == 0)
        {
			fprintf(gdxLogFile,"\nThere are no saved queries in the system.\n");
			fflush(gdxLogFile);
            return;
        }
        for (size_t i = 0; i < savedQueries.queries.size(); i++)
        {
            if (savedQueries.queries[i].name == DIDQUERY)
            {
                queryDID = savedQueries.queries[i].query;
            }
			else if (savedQueries.queries[i].name == DTCQUERY)
            {
                queryDTC = savedQueries.queries[i].query;
            }
			else if (savedQueries.queries[i].name == ECUQUERY)
            {
                queryECU = savedQueries.queries[i].query;
            }
			else if (savedQueries.queries[i].name == RTNQUERY)
            {
                queryRTN = savedQueries.queries[i].query;
            } 
			else if (savedQueries.queries[i].name == FTBQUERY)
            {
                queryFTB = savedQueries.queries[i].query;
            } 
        }

		if (queryDID.isNull() || queryDTC.isNull() ||queryECU.isNull() || queryRTN.isNull() || queryFTB.isNull()) 
		{
			fprintf(gdxLogFile,"A Required Query is missing from system.\n");
			fflush(gdxLogFile);
			return;
		}

        //*****************************
        // Build query input 
        //*****************************

        vector<Teamcenter::Services::Query::_2008_06::Savedquery::QueryInput> savedQueryInputs;
        vector< AutoPtr<ModelObject> > limitList;
        vector< string > entries;
        vector< string > values;
        entries.push_back( "Name" );
        values.push_back ( "*" );
		Teamcenter::Services::Query::_2008_06::Savedquery::QueryInput savedQueryInputDID = {};
        savedQueryInputDID.query = queryDID;
        savedQueryInputDID.limitList = limitList;
        savedQueryInputDID.entries = entries;
        savedQueryInputDID.values = values;
        savedQueryInputDID.resultsType = 0;

        savedQueryInputs.push_back(savedQueryInputDID);

		Teamcenter::Services::Query::_2008_06::Savedquery::QueryInput savedQueryInputDTC = {};
        savedQueryInputDTC.query = queryDTC;
        savedQueryInputDTC.limitList = limitList;
        savedQueryInputDTC.entries = entries;
        savedQueryInputDTC.values = values;
        savedQueryInputDTC.resultsType = 0;

        savedQueryInputs.push_back(savedQueryInputDTC);

		Teamcenter::Services::Query::_2008_06::Savedquery::QueryInput savedQueryInputECU = {};
        savedQueryInputECU.query = queryECU;
        savedQueryInputECU.limitList = limitList;
        savedQueryInputECU.entries = entries;
        savedQueryInputECU.values = values;
        savedQueryInputECU.resultsType = 0;

        savedQueryInputs.push_back(savedQueryInputECU);

		Teamcenter::Services::Query::_2008_06::Savedquery::QueryInput savedQueryInputRTN = {};
        savedQueryInputRTN.query = queryRTN;
        savedQueryInputRTN.limitList = limitList;
        savedQueryInputRTN.entries = entries;
        savedQueryInputRTN.values = values;
        savedQueryInputRTN.resultsType = 0;

        savedQueryInputs.push_back(savedQueryInputRTN);

		Teamcenter::Services::Query::_2008_06::Savedquery::QueryInput savedQueryInputFTB= {};
        savedQueryInputFTB.query = queryFTB;
        savedQueryInputFTB.limitList = limitList;
        savedQueryInputFTB.entries = entries;
        savedQueryInputFTB.values = values;
        savedQueryInputFTB.resultsType = 0;

        savedQueryInputs.push_back(savedQueryInputFTB);

        
        //***********************************************
        // Execute executeSavedQueries service operation
        //***********************************************
        SavedqueryService::SavedQueriesResponse queryResponse = queryService->executeSavedQueries( savedQueryInputs );
		if(queryResponse.arrayOfResults.size() == 5)
		{
				SavedqueryService::QueryResults foundDIDs = queryResponse.arrayOfResults[0];
				SavedqueryService::QueryResults foundDTCs = queryResponse.arrayOfResults[1];
				SavedqueryService::QueryResults foundECUs = queryResponse.arrayOfResults[2];
				SavedqueryService::QueryResults foundRTNs = queryResponse.arrayOfResults[3];
				SavedqueryService::QueryResults foundFTBs = queryResponse.arrayOfResults[4];
		          
				cout << "" << endl;
				cout << "Found Items:" << endl;

				 cout << "DIDS:  "<< ends;
				 cout << foundDIDs.objectUIDS.size() << endl;
				 cout << "DTCs:  "<<ends;
				 cout << foundDTCs.objectUIDS.size() << endl;
				 cout << "ECUs:  "<<ends;
				 cout << foundECUs.objectUIDS.size() << endl;
				 cout << "Routine:  "<<ends;
				 cout << foundRTNs.objectUIDS.size() << endl;
				 cout << "Failure Type Bytes:  "<<ends;
				 cout << foundFTBs.objectUIDS.size() << endl;

				vector<string> uids;
				for(size_t i=0; i< foundDIDs.objectUIDS.size(); i++)
				{
						uids.push_back(foundDIDs.objectUIDS[i]);
				}
				for(size_t i=0; i< foundDTCs.objectUIDS.size(); i++)
				{
						uids.push_back(foundDTCs.objectUIDS[i]);
				}				
				for(size_t i=0; i< foundRTNs.objectUIDS.size(); i++)
				{
						uids.push_back(foundRTNs.objectUIDS[i]);
				}
				for(size_t i=0; i< foundFTBs.objectUIDS.size(); i++)
				{
						uids.push_back(foundFTBs.objectUIDS[i]);
				}	

				for(size_t i=0; i< foundECUs.objectUIDS.size(); i++)
				{					
					uids.push_back(foundECUs.objectUIDS[i]);
				}


				ServiceData sd = dmService->loadObjects( uids );
				foundObjs = sd.getPlainObjs();
				//
				//ServiceData sd1 = dmService->loadObjects( ecuUids );
				//foundECUObjs = sd1.getPlainObjs();
				//vector< string > properties;
				//properties.push_back("fv9_ECUDiscontinued");

				//ServiceData sd2 = dmService->getProperties(foundECUObjs,properties);
				//for (size_t i = 0; i < foundECUObjs.size(); i++)
				//{
				//	Teamcenter::Soa::Client::Property* prop = NULL;
				//	try
				//	{
				//		prop= foundECUObjs[i]->getProperty("fv9_ECUDiscontinued");
				//	}
				//	catch ( NotLoadedException& ){}

				//	// Only if prop is not null, we fetch value
				//	if ( prop != NULL )
				//	{ 
				//		if( prop->getBoolValue() != 1)
				//		{
				//			foundObjs.push_back(foundECUObjs[i]);
				//		}
				//	}
				//}				
		}

		//***********************************************
        // Export object to GMRDB Excel report
        //**********************************************

		fprintf(gdxLogFile,"Exporting %d Objects to Excel .\n", foundObjs.size());
		fflush(gdxLogFile);

		vector <FileimportexportService::ExportToApplicationInputData2> inputDatas;
		FileimportexportService::ExportToApplicationInputData2 inputData = {};

		vector <Teamcenter::Services::Importexport::_2011_06::Fileimportexport::ImportExportOptions> exportOptions;
		Teamcenter::Services::Importexport::_2011_06::Fileimportexport::ImportExportOptions exportOption1 = {};
		exportOption1.option="";
		exportOption1.value ="";
		exportOptions.push_back(exportOption1);
		
		std::vector< FileimportexportService::TemplateOverride > objectTemplateOverride1;

		for (size_t i = 0; i < templateNames.size(); i++)
		{
			inputData.applicationFormat = "MSExcel"; 
			inputData.objectsToExport = foundObjs;
			inputData.templateId = templateNames.at(i); 
			inputData.templateType = "ExcelTemplate";		
			inputData.exportOptions = exportOptions;
			inputData.objectTemplateOverride = objectTemplateOverride1;

			inputDatas.push_back(inputData);
			

			printf ("\n\nStarting Export Action for template \n");

			FileimportexportService::ExportToApplicationResponse1 resp =ieService->exportToApplication(inputDatas);

			printf ("\n\n Export Completed Successfully..\n");

			if(resp.transientFileReadTickets.size() >0)
			{
				//Upload files to dataset
				ifail = IMF_get_absolute_transient_volume_file_path(4,(char* )resp.transientFileReadTickets[0].c_str(),&filePath);
				if(ifail != ITK_ok)
				{
					fprintf(gdxLogFile,"Failed To get Transient volume file Path\n");
					fflush(gdxLogFile);
				}
			}
			else
			{
				fprintf(gdxLogFile,"Failed To generate the excel Report\n");
				fflush(gdxLogFile);
			}
			if(filePath != NULL)
			{				
				int		sysResult = 0;
				std::string finalPath = directory + FV_FILEPATH_DELIMITER + reportNames.at(i) + "_" + currentDateTime() + ".xlsm";
				#if defined(WNT)
					sysResult = rename(filePath,finalPath.c_str());					
				#else
					char*	executable_command				= NULL;
					executable_command = (char *)MEM_alloc((int)(2048)*sizeof(char) );
					strcpy(executable_command,FV_Move_Command);
					strcat(executable_command," ");
					strcat(executable_command,filePath);
					strcat(executable_command," ");
					strcat(executable_command,finalPath.c_str());

					fprintf(gdxLogFile,"\nCommand : %s\n",executable_command);
					fflush(gdxLogFile);


					sysResult = system(executable_command);

				#endif

				if(sysResult == 0)
				{
					cout << "\n\nGDX EXCEL Report Generated at location : " << finalPath<< endl;
					fprintf(gdxLogFile,"\nGDX EXCEL Report Generated at location : %s\n",finalPath.c_str());
					fflush(gdxLogFile);
				}
				else
				{
					cout << "\n\nFailed to download file at  : \n" << finalPath<< endl;
					fprintf(gdxLogFile,"\nFailed to download file at  : %s\n",finalPath);
					fflush(gdxLogFile);
				}
			}
			else
			{
				fprintf(gdxLogFile,"\nERROR:Failed to get path for the exported file\n");
				fflush(gdxLogFile);
				cout << "\n\nERROR:Failed to get path for the exported file\n" <<  endl;
			}

			inputDatas.pop_back();
			MEM_free(filePath);
			filePath = NULL;
		}

	}
	 catch (RuntimeException& e)
    {
        cout << "ExecuteSavedQuery service request failed." << endl;
        cout << e.getMessage() << endl;
        return;
    }
    catch (ServiceException& e)
    {
        cout << "ExecuteSavedQuery service request failed." << endl;
        cout << e.getMessage() << endl;
        return;
    }

}
	


const std::string GDXReport::currentDateTime() {
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime(&now);

    strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", &tstruct);

    return buf;
}

