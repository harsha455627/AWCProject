/******************************************************************************
File        : FVE_gsdb_get_and_remove_duplicate_tx_rx.cpp
Description : Utility to report the duplicate Tx and Rx details and delete the duplicate Tx or Rx.

Date          Author                    Reason
07/27/2017    VenuBabu Avala            Initial Version
****************************************************************************/  

/*
Compile
%TC_ROOT%\sample\compile -DIPLIB=none FV_gsdb_get_and_remove_duplicate_tx_rx.cpp

Link and Create Executable File
%TC_ROOT%\sample\linkitk -o FV_gsdb_get_and_remove_duplicate_tx_rx FVE_gsdb_get_and_remove_duplicate_tx_rx.obj
*/

#include <tc/tc.h>
#include <tccore/tctype.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <tc/folder.h>
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <pom/pom/pom.h>
#include <pom/enq/enq.h>
#include <tccore/grmtype.h>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_basic.h>
#include <fclasses/tc_date.h>
#include <fclasses/tc_string.h>
#include <time.h>

#define ITK( argument )                                             \
{                                                                   \
	int retCode = argument;                                         \
	if ( retCode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retCode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retCode );                        \
	EMH_ask_error_text (retCode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	}                                                               \
}

#define ERROR_CHECK( argument )                                     \
{                                                                   \
	int retCode = argument;                                         \
	if ( retCode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retCode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retCode );                        \
	EMH_ask_error_text (retCode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	return retCode;                                                 \
	}                                                               \
}

/********************************* start function declarations ***********************************/

int FVE_getTxAndRx_details_of_signal_revs(char* ecu_type, int* ecu_rev_count, tag_t** ecu_rev_tags, int* dup_form_count, tag_t** dup_form_tags);

void add_tag_to_tags(tag_t add_tag, int *n_tags, tag_t **tags);

int isDuplicateTag(tag_t add_tag, int n_tags, tag_t *tags, logical *is_duplicate);

int is_descendant_of_folder(tag_t object_tag, logical *is_descendant);

int remove_references(tag_t object_tag);

void displayHelp();

/****************************** end function declarations *******************************************/

int ITK_user_main(int argc,char* argv[])
{
	int retcode = ITK_ok;

	ITK_initialize_text_services(0);

	if ( ITK_ask_cli_argument( "-h" ) != 0 )
	{
		displayHelp();
		return retcode;
	}

	char *user = ITK_ask_cli_argument("-u=");
	char *passwd = ITK_ask_cli_argument("-p=");
	char *group = ITK_ask_cli_argument("-g=");
	char *ecu_type = ITK_ask_cli_argument("-ecu_type=");
	char *delete_duplicate = ITK_ask_cli_argument("-delete_duplicate=");

	if( user == NULL || passwd == NULL || group == NULL )
	{
		displayHelp();
		return retcode;
	}
	
	ERROR_CHECK(ITK_init_module(user, passwd, group));

	logical bypass = false;

    ERROR_CHECK(ITK_ask_bypass( &bypass ));

    if( !bypass )
    {
        ITK(ITK_set_bypass( true ));
        bypass = true;
    }

	time_t start,end;
    double dif;
	
	time (&start);
	
	int tx_rx_count = 0;
	int dup_form_count = 0;
	
	tag_t *tx_rx_tags = NULL;
	tag_t *dup_form_tags = NULL;
	
	if ( ecu_type != NULL )
	{
		ITK(FVE_getTxAndRx_details_of_signal_revs(ecu_type, &tx_rx_count, &tx_rx_tags, &dup_form_count, &dup_form_tags));
	}
	else
	{
		ITK(FVE_getTxAndRx_details_of_signal_revs("", &tx_rx_count, &tx_rx_tags, &dup_form_count, &dup_form_tags));
	}
	
	printf("Number of Duplcate Forms Found : %d\n", dup_form_count);
	
	if ( delete_duplicate != NULL && (tc_strcmp(delete_duplicate, "Yes") == 0 || tc_strcmp(delete_duplicate, "Y") == 0 || tc_strcmp(delete_duplicate, "yes") == 0 || tc_strcmp(delete_duplicate, "y") == 0))
	{
		for (int inx = 0; inx < dup_form_count; inx++)
		{
			char *dup_form_name = NULL;
			
			//Remove the references if any
			ITK(remove_references(dup_form_tags[inx]));
			
			//Delete the duplicate form
			ITK(AOM_ask_value_string(dup_form_tags[inx], "object_name", &dup_form_name));
			ITK(AOM_lock_for_delete(dup_form_tags[inx]));
			ITK(AOM_delete(dup_form_tags[inx]));
			
			printf("DELETED Form : %s\n", dup_form_name);
			
			MEM_free(dup_form_name);
		}
	}
	else
	{
		printf("Duplicate Tx and Rx cannot be deleted since delete_duplicate option is not specified\n");
	}

	MEM_free(tx_rx_tags);
	MEM_free(dup_form_tags);

    time (&end);

	dif = difftime (end,start);
	printf ("It took %.2lf seconds OR %.2lf minutes to generate the report.\n", dif,dif/60 );
	TC_write_syslog ("It took %.2lf seconds OR %.2lf minutes to generate the report.\n", dif,dif/60 );

	ERROR_CHECK(ITK_exit_module(true));

	return retcode;
}

void displayHelp()
{
	printf("************************************************************************************\n");
	printf("This utility updates the release status of DCR objects which have perform-signoffs status with the status of signals attached to them.\n\n");
	printf("This utility accepts the following arguments.\nplease run with dba previleges and turn on bypass before running this utility.\n\n");
	printf("-u=<userid>..\n");
	printf("-p=<password>..\n");
	printf("-g=<dba>..\n");
	printf("-ecu_type=<Specify the type if ECU information you want to retrive. Tx or Rx. If none, both will be extracted>..\n");
	printf("-delete_duplciate=<Yes or No>..\n");
	printf("************************************************************************************");
}

/* 
This function will retrieve the Tx and Rx ECUs of all Signal Revisions in VSEM. It also retrives the duplicate Tx and Rx forms.
You can specify Tx or Rx for ecu_type argument. If you dont specify anything both Tx and Rx ECU's will be retrieved.
*/
int FVE_getTxAndRx_details_of_signal_revs(char* ecu_type, int* ecu_rev_count, tag_t** ecu_rev_tags, int* dup_form_count, tag_t** dup_form_tags)
{
	int retcode = ITK_ok;
	int rows = 0;
	int columns = 0;
	int null_operator = 0;

	void ***report = NULL;
	
	const char *select_attr_list_item[] = {"puid","item_id"};
	const char *select_attr_list_signal_rev[] = {"puid","item_revision_id"};
	const char *select_attr_list_ecurev[] = {"puid","item_revision_id","FVE_ECUAcronym"};
	const char *select_attr_list_form[] = {"puid"};
	const char *select_attr_list_wsobject[] = {"object_name"};
	const char *select_attr_list_storform[] = {"FVE_SamplingInterval"};
	const char *QUERY_NAME = "get_tx_or_rx_ecus";

	*dup_form_count = 0;
	*ecu_rev_count = 0;
	
	*ecu_rev_tags = NULL;
	*dup_form_tags = NULL;
	
	FILE* fp_signal_tx_rx = NULL;
	
	fp_signal_tx_rx = fopen("Signal_Tx_Rx_Report.txt", "w+");
	
	if ( fp_signal_tx_rx == NULL )
	{
		fprintf(stderr, "ERROR: Cannot create log file : Signal_Tx_Rx_Report.txt\n");
		return retcode;
	}
	
	if ( tc_strcmp(ecu_type, "Rx") == 0 )
	{
		null_operator = POM_enquiry_is_not_null;
	}
	else if ( tc_strcmp(ecu_type, "Tx") == 0 )
	{
		null_operator = POM_enquiry_is_null;
	}
	else
	{
		printf("Retrieving both Tx and Rx\r\n");
	}

	ITK(POM_enquiry_create(QUERY_NAME));
	ITK(POM_enquiry_create_class_alias(QUERY_NAME, "Item", true, "signal_item"));
	ITK(POM_enquiry_create_class_alias(QUERY_NAME, "Item", true, "ecu_item"));
	ITK(POM_enquiry_create_class_alias(QUERY_NAME, "Workspaceobject", true, "form_ws"));
	ITK(POM_enquiry_create_class_alias(QUERY_NAME, "Workspaceobject", true, "item_ws"));
	
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME, "signal_item", 2, select_attr_list_item));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME, "ecu_item", 2, select_attr_list_item));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"FVE_GSSignalRevision",2,select_attr_list_signal_rev));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"FVE_ECURevision",3,select_attr_list_ecurev));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"form_ws",1,select_attr_list_wsobject));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"item_ws",1,select_attr_list_wsobject));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"FVE_SigECURelFormStorage",1,select_attr_list_storform));
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"Form",1,select_attr_list_form));

	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp1","FVE_GSSignalRevision","items_tag", POM_enquiry_equal, "signal_item", "puid"));
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp2","signal_item","item_id", POM_enquiry_equal, "FVE_SigECURelFormStorage", "FVE_GSSignalId"));
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp3","FVE_GSSignalRevision","item_revision_id", POM_enquiry_equal, "FVE_SigECURelFormStorage", "FVE_GSSignalRevId"));
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp4","FVE_SigECURelFormStorage","FVE_SignalECURef", POM_enquiry_equal, "FVE_ECURevision", "puid"));
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp5","FVE_ECURevision","items_tag", POM_enquiry_equal, "ecu_item", "puid"));
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp6","FVE_SigECURelFormStorage","puid", POM_enquiry_equal, "Form", "data_file"));	
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp7","Form","puid", POM_enquiry_equal, "form_ws", "puid"));
	ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp8","signal_item","puid", POM_enquiry_equal, "item_ws", "puid"));
	
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp9","exp1",POM_enquiry_and,"exp2"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp10","exp9",POM_enquiry_and,"exp3"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp11","exp10",POM_enquiry_and,"exp4"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp12","exp11",POM_enquiry_and,"exp5"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp13","exp12",POM_enquiry_and,"exp6"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp14","exp13",POM_enquiry_and,"exp7"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp15","exp14",POM_enquiry_and,"exp8"));
	
	if ( null_operator != 0 )
	{
		ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp16","FVE_SigECURelFormStorage","FVE_SamplingInterval",null_operator,""));
		ITK(POM_enquiry_set_expr(QUERY_NAME,"exp17","exp15",POM_enquiry_and,"exp16"));
		ITK(POM_enquiry_set_where_expr(QUERY_NAME,"exp17"));
	}
	else
	{
		ITK(POM_enquiry_set_where_expr(QUERY_NAME,"exp15"));
	}

	ITK(POM_enquiry_add_order_attr(QUERY_NAME, "item_ws", "object_name", POM_enquiry_asc_order));
	ITK(POM_enquiry_add_order_attr(QUERY_NAME, "signal_item", "item_id", POM_enquiry_asc_order));
	ITK(POM_enquiry_add_order_attr(QUERY_NAME, "FVE_GSSignalRevision", "item_revision_id", POM_enquiry_asc_order));
	/* execute the query */
	ITK(POM_enquiry_execute(QUERY_NAME,&rows,&columns,&report));
	ITK(POM_enquiry_delete(QUERY_NAME));

	if( rows > 0 )
	{
		int inx = 0;
		int rx_ecu_count = 0;
		int tx_ecu_count = 0;
		
		tag_t prev_signal_rev = NULLTAG;
		tag_t *rx_ecu_rev_list = NULL;
		tag_t *tx_ecu_rev_list = NULL;
		tag_t *rel_form_tags = NULL;

		*ecu_rev_tags = (tag_t *) MEM_alloc(rows*sizeof(tag_t));
		rel_form_tags = (tag_t *) MEM_alloc(rows*sizeof(tag_t));
		
		*ecu_rev_count = rows;
		
		fprintf(fp_signal_tx_rx, "Signal_Name|Signal_Item_ID|Signal_Rev_ID|ECU_Item_ID|ECU_Rev_ID|ECU_Acronym|Tx_or_Rx|ECU Sampling Interval|ECU_Rel_Form_Name|is_duplicate?\r\n");
		
		for(inx = 0; inx < rows; inx++)
		{
			tag_t current_signal_rev = (tag_t)(*((tag_t*) report[inx][4]));
			
			char *ecu_sampling_interval = (char *) report[inx][11];
			
			rel_form_tags[inx] = (tag_t)(*((tag_t*) report[inx][12]));
			(*ecu_rev_tags)[inx] = (tag_t)(*((tag_t*) report[inx][6]));
			
			if ( inx == 0 )
			{
				prev_signal_rev = current_signal_rev;
			}
			
			if ( prev_signal_rev == current_signal_rev )
			{
				if ( ecu_sampling_interval != NULL ) //Rx
				{
					logical is_duplicate = false;
					
					ITK(isDuplicateTag((*ecu_rev_tags)[inx], rx_ecu_count, rx_ecu_rev_list, &is_duplicate));
					
					if ( is_duplicate )
					{
						add_tag_to_tags(rel_form_tags[inx], dup_form_count, dup_form_tags);
						fprintf(fp_signal_tx_rx, "%s|%s|%s|%s|%s|%s|Rx|%s|%s|Yes\r\n",report[inx][10], report[inx][1], report[inx][5], report[inx][3], report[inx][7], report[inx][8], report[inx][11], report[inx][9]);
					}
					else
					{
						add_tag_to_tags((*ecu_rev_tags)[inx], &rx_ecu_count, &rx_ecu_rev_list);
						fprintf(fp_signal_tx_rx, "%s|%s|%s|%s|%s|%s|Rx|%s|%s|No\r\n",report[inx][10], report[inx][1], report[inx][5], report[inx][3], report[inx][7], report[inx][8], report[inx][11], report[inx][9]);
					}
				}
				else
				{
					logical is_duplicate = false;
					
					ITK(isDuplicateTag((*ecu_rev_tags)[inx], tx_ecu_count, tx_ecu_rev_list, &is_duplicate));
					
					if ( is_duplicate )
					{
						add_tag_to_tags(rel_form_tags[inx], dup_form_count, dup_form_tags);
						fprintf(fp_signal_tx_rx, "%s|%s|%s|%s|%s|%s|Tx|%s|%s|Yes\r\n",report[inx][10], report[inx][1], report[inx][5], report[inx][3], report[inx][7], report[inx][8], report[inx][11], report[inx][9]);
					}
					else
					{
						add_tag_to_tags((*ecu_rev_tags)[inx], &tx_ecu_count, &tx_ecu_rev_list);
						fprintf(fp_signal_tx_rx, "%s|%s|%s|%s|%s|%s|Tx|%s|%s|No\r\n",report[inx][10], report[inx][1], report[inx][5], report[inx][3], report[inx][7], report[inx][8], report[inx][11], report[inx][9]);
					}
				}
			}
			else
			{
				prev_signal_rev = current_signal_rev;
				
				if ( rx_ecu_count > 0 )
				{
					rx_ecu_count = 0;
					MEM_free(rx_ecu_rev_list);					
					rx_ecu_rev_list = NULL;
				}
				if ( tx_ecu_count > 0 )
				{
					tx_ecu_count = 0;
					MEM_free(tx_ecu_rev_list);
					tx_ecu_rev_list = NULL;
				}
				
				if ( ecu_sampling_interval != NULL ) //Rx
				{
					add_tag_to_tags((*ecu_rev_tags)[inx], &rx_ecu_count, &rx_ecu_rev_list);
					fprintf(fp_signal_tx_rx, "%s|%s|%s|%s|%s|%s|Rx|%s|%s|No\r\n",report[inx][10], report[inx][1], report[inx][5], report[inx][3], report[inx][7], report[inx][8], report[inx][11], report[inx][9]);
				}
				else
				{
					add_tag_to_tags((*ecu_rev_tags)[inx], &tx_ecu_count, &tx_ecu_rev_list);
					fprintf(fp_signal_tx_rx, "%s|%s|%s|%s|%s|%s|Tx|%s|%s|No\r\n",report[inx][10], report[inx][1], report[inx][5], report[inx][3], report[inx][7], report[inx][8], report[inx][11], report[inx][9]);
				}
			}

		}
		MEM_free(rel_form_tags);
	}
	
	if ( fp_signal_tx_rx != NULL )
	{
		fclose(fp_signal_tx_rx);
		printf("please find the Signal_Tx_Rx_Report.txt report in current directoty and share it with BA\n");
	}
	
	return retcode;
}
/*
This function adds the given tag to given tag list.
Input:
	tag_t add_tag, <I> 

Output:	
	int n_tags,    <O>
	tag_t *tags,   <OF>
*/
void add_tag_to_tags(tag_t add_tag, int *n_tags, tag_t **tags)
{
    int count = *n_tags;
	
    count++;
	
    if (count == 1)
    {
		(*tags) = (tag_t *) MEM_alloc(sizeof(tag_t));
    }
    else
    {
		(*tags) = (tag_t *) MEM_realloc((*tags), count * sizeof(tag_t));
    }
    (*tags)[count - 1] = add_tag;
    *n_tags = count;
}

/*
This function checks if the given tag exists in the given list and returns if the given tag is duplicate or not.
Input:
	tag_t add_tag, <I> 
	int n_tags,    <I>
	tag_t *tags,   <I>
Output:	
	logical *is_duplicate <O>
*/
int isDuplicateTag(tag_t add_tag, int n_tags, tag_t *tags, logical *is_duplicate)
{
	int retcode = ITK_ok;
	
	*is_duplicate = false;
	
	for (int inx = 0; inx < n_tags; inx++)
	{
		if ( add_tag == tags[inx] )
		{
			*is_duplicate = true;
			break;
		}
	}
	
	return retcode;
}

int is_descendant_of_folder(tag_t object_tag, logical *is_descendant)
{
	int retcode = ITK_ok;
	
    tag_t parent_class = NULLTAG;
	tag_t class_tag = NULLTAG;
	
	*is_descendant = false;
	
    ITK(POM_class_id_of_class("Folder", &parent_class));
    
    ITK(POM_class_of_instance(object_tag, &class_tag));
    
    ITK(POM_is_descendant(parent_class, class_tag, is_descendant));

    return retcode;
}

int remove_references(tag_t object_tag)
{
	int retcode = ITK_ok;
    int n_references = 0;
    int *levels = NULL;
	
    tag_t *reference_tags = NULL;
	
    char **relation_type_name = NULL;
	
    ITK(WSOM_where_referenced(object_tag, 1, &n_references, &levels, &reference_tags, &relation_type_name));

    for (int ii = 0; ii < n_references; ii++)
    {
        char *type_name = NULL;
		
		logical is_descendant = false;
		
        ITK(WSOM_ask_object_type2(reference_tags[ii], &type_name));
		
		ITK(is_descendant_of_folder(reference_tags[ii], &is_descendant))

        if ( is_descendant )
        {
            tag_t folder = reference_tags[ii];
			
            ITK(AOM_refresh(folder, TRUE));
            ITK(FL_remove(folder, object_tag));
            ITK(AOM_save(folder));
            ITK(AOM_refresh(folder, FALSE));
        }
        else if ( (relation_type_name[ii] != NULL) && (strlen(relation_type_name[ii]) > 0 ) )
        {
            tag_t relation_type_tag = NULLTAG;
			tag_t relation_tag = NULLTAG;
			
            ITK(GRM_find_relation_type(relation_type_name[ii], &relation_type_tag));
            
            // GRM_delete_relation requires the relation object which we don't have
            // First try relation using the reference as a primary object
            tag_t primary_object = reference_tags[ii];
            tag_t second_object = object_tag;
			
            ITK(GRM_find_relation(primary_object, second_object, relation_type_tag, &relation_tag));

            // If no relation is found try the reference as a secondary object
            if (relation_tag == NULLTAG)
            {
                primary_object = object_tag;
                second_object = reference_tags[ii];
				
                ITK(GRM_find_relation(primary_object, second_object, relation_type_tag, &relation_tag));
            }
            ITK(GRM_delete_relation(relation_tag ));
        }
        else if(strcmp(type_name, "EPMTask") == 0 )
        {
            tag_t task = reference_tags[ii];
            
			char *state_string = NULL;
			EPM_state_t state;
			
            ITK(EPM_ask_state(task, &state));
            
            ITK(EPM_ask_state_string2(state, &state_string));

            if(strcmp(state_string, "Completed") == 0)
            {
                printf("\n Can't remove targets of completed jobs! \n");
            }
            else
            {
                ITK_set_bypass(TRUE);
                ITK(EPM_remove_attachments(task, 1, &object_tag));
            }
        }

    }
    if(levels) MEM_free(levels);
    if(reference_tags) MEM_free(reference_tags);
    if(relation_type_name) MEM_free(relation_type_name);
	
	return retcode;
}