
#include <O6TaneCustomLibrary/O6ExtractCSV.hxx>
#include <O6TaneCustomLibrary/O6ActionHandlers.hxx>
#include <O6TaneCustomLibrary/O6ParseObjMapXML.hpp>
#include <cstdio>
#include <iostream>
#include <ctime>
#include <stdio.h>
#include <tccore/grm.h>
#include <stdio.h>
#include <pom/pom/pom.h>
#include <tccore/item.h>
#include <ps/ps.h>
#include <bom/bom.h>
#include <ae/tool.h>
#include <fstream>

#define SEEDS_SECURITY_PATH_NOT_FOUND ( SEEDS_CUSTOM_ERROR_BASE + 6 )
#define CSV_HANDLER_ARG_NOT_FOUND ( SEEDS_CUSTOM_ERROR_BASE + 7 )
#define FLEREV "O6_FleRevision"
#define GENRMREV "O6_GenRMRevision"

#define OBJECT_TYPE "object_type"
#define OBJECT_NAME "object_name"
#define CPD_STATUS "o6_cpd_status"
#define ITEM_ID "item_id"
#define STRUCTURE_REVISIONS "structure_revisions"
#define SEEDS_CSV_FILE_PATH "SEEDS_SECURITY_CSV_extract_path"
#define SEMICOLON_SYMBOL ";"
#define E "E;"
#define L "L;"
#define FORMULE_FILE_PREFIX "FL_"
#define RM_FILE_PREFIX "RM_"
#define bomAttr_bl_occ_o6_percent_theoric "bl_occ_o6_percent_theoric"

/**
 * Function    :  initialise_attribute
 * Description :  Initialize BOM attributes.
 * Input       :
 */
int initialiseAttribute (void)
{
	int retcode = ITK_ok;

	ITK ( BOM_line_look_up_attribute ( bomAttr_lineItemRevTag, &item_revtag_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_lineItemTag, &item_tag_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemId, &item_id_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemRevName, &item_rev_name_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_realOccurrence, &bl_occ_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemUom, &item_uom_attribute ) );

	/* Custom Attributes */
	ITK ( BOM_line_look_up_attribute ( bomAttr_bl_occ_o6_percent_theoric, &bl_occ_o6_percent_theoric_attribute ) );

	return retcode;
}

/**
 * Function    :  readArguments
 * Description :  Read handler arguments.
 * Input       :
 * 		 msg  <I>  - EPM_action_message
 * 		 args <OF> - Output structure
 *
 */
int readArguments ( EPM_action_message_t msg, csvArguments &args )
{
	int retcode           = ITK_ok;
	int numberOfArguments = 0;

	numberOfArguments = TC_number_of_arguments ( msg.arguments );

	for ( int iInx = 0; iInx < numberOfArguments; iInx++ )
	{
		char* pcKey   = NULL;
		char* pcValue = NULL;

		ITK ( ITK_ask_argument_named_value ( TC_next_argument ( msg.arguments ), &pcKey, &pcValue ) );

		if ( tc_strcmp ( pcKey, INCLUDE_TYPE ) == 0 && pcValue != NULL && ! string ( pcValue ).empty() )
		{
			args.sObjectType = string ( pcValue );
		}
		if ( tc_strcmp ( pcKey, FDS_STATUS ) == 0 && pcValue != NULL && ! string ( pcValue ).empty() )
		{
			args.sFdsStatus = string ( pcValue );
		}
		if ( tc_strcmp ( pcKey, ATTACHMENT ) == 0 && pcValue != NULL && ! string ( pcValue ).empty() )
		{
			args.sTargetOrReference = string ( pcValue );
		}
		if ( pcKey != NULL )
		{
			MEM_free ( pcKey );
			pcKey = NULL;
		}
		if ( pcValue != NULL )
		{
			MEM_free ( pcValue );
			pcValue = NULL;
		}
	}
	return retcode;
}

/**
 * Function    :  getObjectTypes
 * Description :  Seperate handler argument's delimited value of obj type to vector.
 * Input       :
 * 		 sObjectType  <I>  - object type string
 * 		 vObjectTypes <OF> - Output vector
 *
 */
void getObjectTypes ( string sObjectType, vector<string> &vObjectTypes )
{
	std::istringstream ss( sObjectType );

	string sItemType;

	while ( std::getline ( ss, sItemType, ',' ) )
	{
		vObjectTypes.push_back ( sItemType );
	}
}

/**
 * Function    :  addChildrenEntries
 * Description :  Add Formule children to csv file.
 * Input       :
 * 		 objTag	   <I>	- Object Tag
 * 		 csvReport <OF> - OutPut File
 *
 */
int addChildrenEntries ( tag_t tFLERevTag, ofstream &csvReport )
{
	int retcode   	    = ITK_ok;
	int iBVRCount 	    = 0;

	tag_t* tBVRTags     = NULL;

	ITK ( initialiseAttribute() );

	ITK ( AOM_ask_value_tags ( tFLERevTag, STRUCTURE_REVISIONS, &iBVRCount, &tBVRTags ) );

	if ( iBVRCount != 0 )
	{
		int iTopLineChildren = 0;

		tag_t tBOMWindowTag  = NULLTAG;
		tag_t tBOMTopLine    = NULLTAG;

		tag_t* tBOMLines     = NULLTAG;

		ITK ( BOM_create_window ( &tBOMWindowTag ) );
		ITK ( BOM_set_window_top_line ( tBOMWindowTag, NULLTAG, tFLERevTag, NULLTAG, &tBOMTopLine ) );
		ITK ( BOM_set_window_pack_all ( tBOMWindowTag, false ) );

		if ( retcode == ITK_ok && tBOMTopLine != NULLTAG )
		{
			char* pcItemId = NULL;

			ITK ( BOM_line_ask_all_child_lines ( tBOMTopLine, &iTopLineChildren, &tBOMLines ) );

			for ( int iInx = 0; iInx < iTopLineChildren; iInx++ )
			{
				char* pcChildId    = NULL;
				char* pcPercentage = NULL;

				ITK ( BOM_line_ask_attribute_string ( tBOMLines[iInx], item_id_attribute, &pcChildId ) );
				ITK ( BOM_line_ask_attribute_string ( tBOMLines[iInx], bl_occ_o6_percent_theoric_attribute, &pcPercentage ) );

				csvReport<< L + string ( pcChildId ) + SEMICOLON_SYMBOL + string ( pcPercentage ) + "\n"; // Writing each child entry to file

				if ( pcChildId != NULL )
				{
					MEM_free ( pcChildId );
					pcChildId = NULL;
				}
				if ( pcPercentage != NULL )
				{
					MEM_free ( pcPercentage );
					pcPercentage = NULL;
				}
			}
			if ( pcItemId != NULL )
			{
				MEM_free ( pcItemId );
				pcItemId = NULL;
			}
		}
		if ( tBOMLines != NULL )
		{
			MEM_free ( tBOMLines );
			tBOMLines = NULL;
		}
		ITK ( BOM_close_window ( tBOMWindowTag ) );
	}
	if ( tBVRTags != NULL )
	{
		MEM_free ( tBVRTags );
		tBVRTags = NULL;
	}
	return retcode;
}

/**
 * Function    :  O6_SEEDS_Sec_extract_csv
 * Description :  Wrapper function to extract CSV data for SEEDS security.
 *
 * Input       :
 *		msg - Handler message
 *
 * Output
 *
 */
int O6_SEEDS_Sec_extract_csv ( EPM_action_message_t msg )
{
	csvArguments args;

	int retcode           = ITK_ok;

	tag_t tRootTask       = NULLTAG;

	ITK ( readArguments ( msg, args ) );

	/* All 3 handler arguments are mandatory */
	if ( retcode == ITK_ok && ( tc_strcmp ( ( args.sObjectType).c_str(), "" ) != 0 ) && ( tc_strcmp ( ( args.sFdsStatus ).c_str(), "" ) != 0 ) && ( tc_strcmp ( ( args.sTargetOrReference ).c_str(), "" ) != 0 ) )
	{
		vector<string> vObjectTypes;

		getObjectTypes ( args.sObjectType, vObjectTypes );

		ITK ( EPM_ask_root_task ( msg.task, &tRootTask ) );

		if ( retcode == ITK_ok && tRootTask != NULLTAG )
		{
			int iTargetCount          = 0;

			tag_t* tTargetAttachments = NULL;

			if ( tc_strcmp ( args.sTargetOrReference.c_str(), TARGET ) == 0 )
			{
				ITK ( EPM_ask_attachments ( tRootTask, EPM_target_attachment, &iTargetCount, &tTargetAttachments ) );
			}
			else if ( tc_strcmp ( args.sTargetOrReference.c_str(), REFERENCE ) == 0 )
			{
				ITK ( EPM_ask_attachments ( tRootTask, EPM_reference_attachment, &iTargetCount, &tTargetAttachments ) );
			}

			for ( int iInx = 0; iInx < iTargetCount; iInx++ )
			{
				tag_t tTargetClassID = NULLTAG;

				ITK ( POM_class_of_instance	( tTargetAttachments[iInx], &tTargetClassID ) );

				if ( retcode == ITK_ok && tTargetClassID != NULLTAG )
				{
					char* pcClassName = NULL;

					ITK ( POM_name_of_class ( tTargetClassID, &pcClassName ) );

					if ( retcode == ITK_ok && pcClassName != NULL )
					{
						char* pcPrefValue = NULL;

						if ( ! ( std::find ( vObjectTypes.begin(), vObjectTypes.end(), string ( pcClassName ) ) != vObjectTypes.end() ) )
						{
							if ( pcClassName != NULL )
							{
								MEM_free ( pcClassName );
								pcClassName = NULL;
							}
							continue;
						}

						ITK ( PREF_ask_char_value ( SEEDS_CSV_FILE_PATH, 0, &pcPrefValue ) ); // Getting path to place the CSV file

						if ( retcode == ITK_ok && pcPrefValue != NULL && ! string ( pcPrefValue ).empty() )
						{
							if ( tc_strcmp ( pcClassName, FLEREV ) == 0 )
							{
								char* pcItemId     = NULL;
								char* pcObjectName = NULL;
								char* pcSAPStatus  = NULL;

								ITK ( AOM_ask_value_string ( tTargetAttachments[iInx], ITEM_ID, &pcItemId ) );
								ITK ( AOM_ask_value_string ( tTargetAttachments[iInx], OBJECT_NAME, &pcObjectName ) );
								ITK ( AOM_ask_value_string ( tTargetAttachments[iInx], CPD_STATUS, &pcSAPStatus ) );

								string sCSVReportPath = string ( pcPrefValue ) + "\\" + FORMULE_FILE_PREFIX + pcItemId + CSV_FILE_EXTENSION;

								ofstream csvReport ( sCSVReportPath  ); // Using ofstream class's object to make csv file

								/* Writing to CSV file */
								csvReport<< E + string ( pcItemId ) + SEMICOLON_SYMBOL + string ( pcObjectName ) + SEMICOLON_SYMBOL + args.sFdsStatus + SEMICOLON_SYMBOL + string ( pcSAPStatus ) + "\n";

								ITK ( addChildrenEntries ( tTargetAttachments[iInx], csvReport ) );

								csvReport.close();

								if ( pcItemId != NULL )
								{
									MEM_free ( pcItemId );
									pcItemId = NULL;
								}
								if ( pcObjectName != NULL )
								{
									MEM_free ( pcObjectName );
									pcObjectName = NULL;
								}
								if ( pcSAPStatus != NULL )
								{
									MEM_free ( pcSAPStatus );
									pcSAPStatus = NULL;
								}
							}
							if ( tc_strcmp ( pcClassName, GENRMREV ) == 0 )
							{
								char* pcItemId     = NULL;
								char* pcObjectName = NULL;
								char* pcSAPStatus  = NULL;

								ITK ( AOM_ask_value_string ( tTargetAttachments[iInx], ITEM_ID, &pcItemId ) );
								ITK ( AOM_ask_value_string ( tTargetAttachments[iInx], OBJECT_NAME, &pcObjectName ) );
								ITK ( AOM_ask_value_string ( tTargetAttachments[iInx], CPD_STATUS, &pcSAPStatus ) );

								string sCSVReportPath = string ( pcPrefValue ) + "\\" + RM_FILE_PREFIX + pcItemId + CSV_FILE_EXTENSION;

								ofstream csvReport( sCSVReportPath  );

								csvReport<< string ( pcItemId ) + SEMICOLON_SYMBOL + string ( pcObjectName ) + SEMICOLON_SYMBOL + args.sFdsStatus + SEMICOLON_SYMBOL + string ( pcSAPStatus )+ "\n";

								if ( pcItemId != NULL )
								{
									MEM_free ( pcItemId );
									pcItemId = NULL;
								}
								if ( pcObjectName != NULL )
								{
									MEM_free ( pcObjectName );
									pcObjectName = NULL;
								}
								if ( pcSAPStatus != NULL )
								{
									MEM_free ( pcSAPStatus );
									pcSAPStatus = NULL;
								}
							}
						}
						else
						{
							EMH_store_error ( EMH_severity_error, SEEDS_SECURITY_PATH_NOT_FOUND ); // Throwing error if preference value empty
							retcode = SEEDS_SECURITY_PATH_NOT_FOUND;
						}
						if ( pcPrefValue != NULL )
						{
							MEM_free ( pcPrefValue );
							pcPrefValue = NULL;
						}
					}
					if ( pcClassName != NULL )
					{
						MEM_free ( pcClassName );
						pcClassName = NULL;
					}
				}
			}
			if ( tTargetAttachments != NULL )
			{
				MEM_free ( tTargetAttachments );
				tTargetAttachments = NULL;
			}
		}
	}
	else // Throwing error if mandatory handler arguments not filled
	{
		EMH_store_error ( EMH_severity_error, CSV_HANDLER_ARG_NOT_FOUND );
		retcode = CSV_HANDLER_ARG_NOT_FOUND;
	}
	return retcode;
}
