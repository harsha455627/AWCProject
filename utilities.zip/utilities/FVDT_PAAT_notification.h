/*==================================================================================================

                    Copyright (c) 2016 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
 ******************************************************************************
 * Filename        :   FVDT_PAAT_notification.h
 * Module          :   FVDT_PAAT_notification.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name                    Description of Change
 * Apr-2016        Bhagwan Moondra             Initial implementation
 * Sept 2017       Sansruti Khade              Added Preference constant
 *
 *****************************************************************************/
#pragma once
#ifndef FVDT_PAAT_NOTIFICATION_H
#define FVDT_PAAT_NOTIFICATION_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <FV_includes.h>
#include <PasswdFunction.h>

#define PASSWORDKEY									"PASSWORDKEY"
#define PAAT_NOTIFY_DUEDATE_PREFERENCE				"PAAT_notification_due_date_interval"
#define PAAT_VP_NOTIFY_TIME_INTERVAL_PREFERENCE     "PAAT_notification_vp_time_interval"

typedef struct PAAT_owners_struct
{
    tag_t       owning_user;
    int         cnt_owning_paats;
    tag_t*      owning_paat_tags;
} PAAT_owners_struct_t;

#endif /* FVDT_PAAT_NOTIFICATION_H */

int FVDT_PAAT_notification();
int sortPAATsToBeNotified(int vp_time_interval,int cnt_paat,int number_of_due_days,int* cnt_wip_paat, tag_t** paat_tags,  tag_t** wip_paat_tags);
int FVDT_send_PAAT_notification(int cnt_paat, tag_t* paat_tags);
void initialize_PAAT_owners_struct(struct PAAT_owners_struct* paatOwners);
void free_PAAT_owners_struct(struct PAAT_owners_struct* paatOwners);
double FVDT_get_date_difference(date_t target, date_t input);
