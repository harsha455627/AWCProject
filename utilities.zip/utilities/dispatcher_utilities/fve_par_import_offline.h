/******************************************************************************
 * Filename        :   fve_par_import_offline
 * Description     :   Utility is called from dispatcher to load PAR files in offline mode
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * Mar 2013         Monika A          Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_PAR_IMPORT_OFFLINE_H
#define FVE_PAR_IMPORT_OFFLINE_H
/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>

#include <FV_includes.h>



/*************************************************
* Macros Definition
**************************************************/

#define PASSWORDKEY     "PASSWORDKEY"

				 
void print_usage(void);


#endif /* FVE_PAR_IMPORT_OFFLINE_H  */
