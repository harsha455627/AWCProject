//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBO6TANEDISPATCH) && !defined(IPLIB)
#   error IPLIB or LIBO6TANEDISPATCH is not defined
#endif

#undef O6TANEDISPATCH_API
#undef O6TANEDISPATCHEXPORT
#undef O6TANEDISPATCHGLOBAL
#undef O6TANEDISPATCHPRIVATE
