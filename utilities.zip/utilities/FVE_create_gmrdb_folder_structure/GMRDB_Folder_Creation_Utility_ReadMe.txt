Command for running the GMRDB folder creation utility for VSEM 4.2
--------------------------------------------------------------------
FVE_gmrdb_create_folder_structure -u=userid -p=password -g=dba -file=FVE_gmrdb_folder_structure_4_2.txt -move_items_to_child=Yes
-----------------------------------------------------------------------------
when -move_items_to_child is not specified, the items will not be moved from parent folder to newly created sub folders.
FVE_gmrdb_folder_structure_4_2.txt should exist in the current directory and should have the latest VSEM 4.2 GMRDB structure.

