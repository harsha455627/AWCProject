//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#ifndef TEAMCENTER_CLIENTX_SESSION_HXX
#define TEAMCENTER_CLIENTX_SESSION_HXX


#include <string>
#include <vector>
#include <map>


#include <teamcenter/clientx/AppXCredentialManager.hxx>
#include <teamcenter/clientx/AppXExceptionHandler.hxx>
#include <teamcenter/clientx/AppXPartialErrorListener.hxx>
#include <teamcenter/clientx/AppXModelEventListener.hxx>
#include <teamcenter/clientx/AppXRequestListener.hxx>
#include <teamcenter/clientx/AppXMemoryAllocator.hxx>

#include <teamcenter/soa/client/Connection.hxx>
#include <teamcenter/soa/client/model/User.hxx>



namespace Teamcenter
{
    namespace ClientX
    {
        class AppXSession;



class AppXSession
{
public:

    /**
     * Create an instance of the AppXSession with a connection to the specified
     * server.
     *
     * Add implementations of the ExceptionHandler, PartialErrorListener,
     * ChangeListener, and DeleteListeners.
     *
     * @param host      Address of the host to connect to, http://serverName:port/tc
     */
    AppXSession(const std::string& host,const std::string& certFile);

    /**
     * Get the single Connection object for the application
     *
     * @return  connection
     */
    static Teamcenter::Soa::Client::Connection* getConnection();


    /**
     * Login to the Teamcenter Server
     *
     */
    Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::Model::User> login(const std::string& uName,const std::string& uPwd);

    /**
     * Terminate the session with the Teamcenter Server
     *
     */
    void logout();

    /**
     * Print some basic information for a list of objects
     *
     * @param objects
     */
    static void printObjects( const std::vector<Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject> >& objects);

    void dumpMemoryInfo( const char* pSectionTitle);

    virtual ~AppXSession();

private:

    static void getUsers( const std::vector<Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject> >& objects );

    /**
     * Single instance of the Connection object that is shared throughtout
     * the application. This Connection object is needed whenever a Service
     * stub is instantiated.
     */
    static Teamcenter::Soa::Client::Connection*           connection;

    /**
     * The credentialManager is used both by the AppXSession class and the Teamcenter
     * Services Framework to get user credentials.
     *
     */
    static Teamcenter::ClientX::AppXCredentialManager* credentialManager;



    static Teamcenter::ClientX::AppXExceptionHandler*       exceptionHandler;
    static Teamcenter::ClientX::AppXPartialErrorListener*   errorListener;
    static Teamcenter::ClientX::AppXModelEventListener*     modelEventListener;
    static Teamcenter::ClientX::AppXRequestListener*        requestListener;
    static Teamcenter::ClientX::AppXMemoryAllocator*        memoryAllocator;

    FILE* m_pMemLogFile;
    bool  m_bTrackMemory;

};


}} //end namespace
#endif

