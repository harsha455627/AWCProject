/*==================================================================================================

                    Copyright (c) 2016 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: FVDT_PAAT_notification.c
    Module  : main

        This utility finds all PAAT Records in VSEM which are in 
        Work in Progress stage & send notification to D&R engineers
        asking to start assessment process

===============================================================================
    Date               Name                    Description of Change
 Apr-2016        Bhagwan Moondra             Initial implementation
 Apr 2016        Bhagwan Moondra             Changes to include HTML table in notification
 Oct 2016        Bhagwan Moondra             Changes to send late notification only if calculated due days
                                             is exact multiple of due days preference value.
                                             Also handle for rejected PAAT to be considered for notification
Sept 2017        Sansruti Khade              Changes to read comp designation and accordingly check the VP milestone ID
                                             Changes to consider send late notification acc to the vp notify preference value
											 Changes to check if VP is excluded for PAAT and also if DT base part is excluded,
											 if so exclude PAAT from notification
===============================================================================*/

#include "FVDT_PAAT_notification.h"

int readAndDecryptPasswd( char *passwdFile,  char **passwd )
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;

    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        printf("ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);
    
    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }
    
    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;    
    return ifail;
}

//Main function
extern int ITK_user_main( int argc, char **  argv )
{
    int     ifail                   = ITK_ok;
    char*   login_group             = NULL;
    char*   login_user              = NULL;
    char*   login_password          = NULL;
    char*   password_file           = NULL;

    login_user = ITK_ask_cli_argument("-u=");
    login_password = ITK_ask_cli_argument("-p=");
    password_file = ITK_ask_cli_argument("-pf=");
    login_group = ITK_ask_cli_argument("-g=");
    if( password_file != NULL )
    {
        readAndDecryptPasswd( password_file, &login_password) ;  
    }

    if ( login_user != NULL && strlen(login_user)!=0 &&  login_password != NULL && strlen(login_password)!=0 &&  login_group != NULL && strlen(login_group)!=0)
    {
        ITK(ITK_init_module (login_user, login_password, login_group))
            if(ifail != ITK_ok)
                printf("\n Login with user ID: %s, group:%s is unsuccessful\n", login_user, login_group);
            else
                printf("\n Login with uid: %s, group:%s is successful\n", login_user, login_group);
    }
    else
    {      
        ITK_initialize_text_services (0);
        ITK (ITK_auto_login ())
            if(ifail != ITK_ok)
                printf("\n Auto Login unsuccessful\n");
            else
                printf("\n Auto Login successful\n");
    }

    if(ifail == ITK_ok)
    {
        ITK(FVDT_PAAT_notification())
    }

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;

}

//Base function which queries all PAAT records & check their status
//Send notification to start assessment process
int FVDT_PAAT_notification()
{
    
    int     ifail                    = ITK_ok;

    int     count_paat               = 0;
    int     cnt                      = 0;
    int     cnt_wip_paat             = 0;
    int     number_of_due_days       = 0;
    int     vp_time_interval         = 0;

    tag_t   query_tag                = NULLTAG;
    tag_t*  paat_tags                = NULL;
    tag_t*  wip_paat_tags            = NULL;

    date_t  current_date_t           = NULLDATE;
 
    char*   vpTimeInterval           = NULL;
    char*   object_name_attr         = object_namePROP;
    char*   due_days                 = NULL;
    char**  entry_names              = NULL;
    char**  entry_values             = NULL;

    CLEANUP(FV_get_current_date_t(&current_date_t))

    //Find the late notification preference value
    CLEANUP(PREF_ask_char_value(PAAT_NOTIFY_DUEDATE_PREFERENCE, 0, &due_days))
    if(due_days == NULL || tc_strlen(due_days) == 0)
    {
        TC_write_syslog("+++ERROR: The value set for PAAT_notification_due_date_interval preference is invalid or undefined. Please contact your System Administrator\n",FV_INVALID_PREFERENCE_VALUE);
        printf("\n+++ERROR: The value set for PAAT_notification_due_date_interval preference is invalid or undefined. Please contact your System Administrator\n");
        EMH_store_initial_error_s2(EMH_severity_error, FV_INVALID_PREFERENCE_VALUE, PAAT_NOTIFY_DUEDATE_PREFERENCE, due_days);
        ifail = FV_INVALID_PREFERENCE_VALUE;
        goto CLEANUP;
    }

    number_of_due_days = atoi(due_days);
    FVE_FREE(due_days)
    
    //Find the PAAT_notification_vp_time_interval value
    CLEANUP(PREF_ask_char_value(PAAT_VP_NOTIFY_TIME_INTERVAL_PREFERENCE, 0, &vpTimeInterval))
    if(vpTimeInterval == NULL || tc_strlen(vpTimeInterval) == 0)
    {
        TC_write_syslog("+++ERROR: The value set for PAAT_notification_vp_time_interval preference is invalid or undefined. Please contact your System Administrator\n",FV_INVALID_PREFERENCE_VALUE);
        printf("\n+++ERROR: The value set for PAAT_notification_vp_time_interval preference is invalid or undefined. Please contact your System Administrator\n");
        EMH_store_initial_error_s2(EMH_severity_error, FV_INVALID_PREFERENCE_VALUE, PAAT_VP_NOTIFY_TIME_INTERVAL_PREFERENCE, vpTimeInterval);
        ifail = FV_INVALID_PREFERENCE_VALUE;
        goto CLEANUP;
    }

    vp_time_interval = atoi(vpTimeInterval);
    FVE_FREE(vpTimeInterval)

    // Find all PAAT Records in the database
    CLEANUP(QRY_find(TC_text ("PAAT Records"), &query_tag))
    entry_names = (char**)MEM_alloc((1) * sizeof(char*));
    entry_names[0]  = TC_text (object_name_attr);
    CLEANUP(FV_copy_string_to_array (&cnt, &entry_values, "*"))

    CLEANUP(QRY_execute( query_tag, 1, entry_names, entry_values, &count_paat, &paat_tags))

    printf("\n Total number of PAAT Records found - %d\n", count_paat);
    if (ifail == ITK_ok)
    {
        CLEANUP(sortPAATsToBeNotified(vp_time_interval,count_paat,number_of_due_days,&cnt_wip_paat,&paat_tags,&wip_paat_tags))
    }

    if(cnt_wip_paat > 0)
        CLEANUP(FVDT_send_PAAT_notification(cnt_wip_paat, wip_paat_tags))

CLEANUP:
     FVE_FREE(paat_tags)
     return ifail;

}

//Function to sort out for which PAAT to send notifications
int sortPAATsToBeNotified(int vp_time_interval,int cnt_paat,int number_of_due_days,int* cnt_wip_paat, tag_t** paat_tags,  tag_t** wip_paat_tags)
{
    int         ifail                           = ITK_ok;
    int         indx                            = 0;
    int         assignedCnt                     = 0;
    int         tempIdx                         = 0;
    int         compIndx                        = 0;
    int         noOfeachComps                   = 0;
    int         noOfCompsID                     = 0;
    int         noOfComps                       = 0;
    int         time_left_for_mlstn             = 0;
    int         time_diff                       = 0;
    int         compIDIndx                      = 0;
    int         countUN                         = 0;
    int         countUP                         = 0;
    int         countmID                        = 0;

    char*       vehPrgRefProp                   = "fv9VehPrgRef";
    char*       milestoneID                     = NULL;
    char*       releaseStatusName               = NULL;
    char*       mID                             = NULL;
    char*       attr_names                      = {item_idPROP};
    char*       isVehPrgExcludedForPAAT         = NULL;
    char*       basePartNum                     = NULL;
    char**      componentArr                    = NULL;

    tag_t       dtRevision                      = NULLTAG;
    tag_t       vehPrgRevTag                    = NULLTAG;
    tag_t*      assignedTags                    = NULL;
    tag_t*      eachCompTags                    = NULL;
    tag_t*      componentTags                   = NULL;

    date_t      MilestoneDueDate                = NULLDATE;
    date_t      current_date_t                  = NULLDATE;

   logical      isSuperseded                    = FALSE;
   logical      isBasePartExcludedForPAAT       = FALSE;

    CLEANUP(FV_get_current_date_t(&current_date_t))
    for(indx=0; indx<cnt_paat; indx++)
    {
        dtRevision      =  NULLTAG;
        isSuperseded    =  FALSE;

        // Get the Veh Prog from PAAT  
        CLEANUP( AOM_ask_value_tag(paat_tags[0][indx],vehPrgRefProp,& vehPrgRevTag))

        /*check if Veh Prgm is excluded for PAAT*/
        CLEANUP(AOM_UIF_ask_value(vehPrgRevTag, fv9IsExcludedForPAATPROP, &isVehPrgExcludedForPAAT))

        //if null,consider false
        if(isVehPrgExcludedForPAAT == NULL || tc_strcmp(isVehPrgExcludedForPAAT,"")==0)
            isVehPrgExcludedForPAAT="N";

        if(tc_strcmp(isVehPrgExcludedForPAAT, "Y") == 0)
        {
            continue;
        }

        //Check for assessment status of this PAAT Record
        //Notification to be sent only for WIP or Rejected PAAT record
        CLEANUP(FV_ask_release_status(paat_tags[0][indx], &releaseStatusName))
        if(releaseStatusName == NULL)
        {
            date_t  creation_date = NULLDATE;
            CLEANUP(AOM_ask_creation_date(paat_tags[0][indx], &creation_date))
            time_diff = (FVDT_get_date_difference(current_date_t, creation_date))/(60*60*24);
        }
        else if(tc_strcmp(releaseStatusName, RejectedSTATUS) == 0)
        {
            date_t  reject_date  = NULLDATE;
            CLEANUP(AOM_ask_value_date(paat_tags[0][indx], RELEASED_DATE, &reject_date))
            time_diff = (FVDT_get_date_difference(current_date_t, reject_date))/(60*60*24);
        }
        else
        {
            continue;
        }
        FVE_FREE(releaseStatusName)
        releaseStatusName = NULL;

        //Filter PAATs which are not contained in the latest revision of DT
        CLEANUP(AOM_ask_value_tag(paat_tags[0][indx], fv9DTRevisionPROP, &dtRevision))
        if(dtRevision == NULLTAG) continue;

        CLEANUP(AOM_ask_value_logical(dtRevision, fv9SupersededPROP, &isSuperseded))
        if(TRUE == isSuperseded) continue;

        /*check if base part number of DT is excluded for PAAT*/
        isBasePartExcludedForPAAT = FVDT_is_dt_has_excluded_base_part(dtRevision, &basePartNum);
        if(isBasePartExcludedForPAAT)
        {
            continue;
        }

        // Get the components of the Veh Prg
        CLEANUP( AOM_ask_value_strings(paat_tags[0][indx],fv9ComponentNumbersPROP,&noOfCompsID, &componentArr))
        noOfComps=0;
        for(compIDIndx=0;compIDIndx<noOfCompsID;compIDIndx++)
        {
            if (componentArr[compIDIndx] != NULL && tc_strlen(componentArr[compIDIndx]) > 0)
            {
                //query to get the component tags
                FV_execute_saved_query("GDT Component Revision...",1, &attr_names,&componentArr[compIDIndx],&noOfeachComps,&eachCompTags);

                if(noOfeachComps>0)
                {
                    FV_add_unique_tag_to_array(&noOfComps, &componentTags, eachCompTags[0]);
                    FVE_FREE(eachCompTags)
                }
            }
        }
        FV_FREE_STRINGS(componentArr)

        //check the no of components
        countUN=0;
        countUP=0;
        for(compIndx=0;compIndx<noOfComps;compIndx++)
        {
            char* compDesignation      = NULL;

            //find out the designation of the component 
            CLEANUP(AOM_ask_value_string(componentTags[compIndx], fv9ComponentDesignationRuntimePROP, &compDesignation))

            if (compDesignation==NULL || tc_strcmp(compDesignation, "") == 0) 
            {
                continue;
            }
            else if(tc_strcmp(compDesignation, "UN")==0 || tc_strcmp(compDesignation, "UN+UP")==0)
            {
                countUN++;
                continue;
            }  
            else if(tc_strcmp(compDesignation, "UP")==0)
            {
                countUP++;
                continue;
            }
            FVE_FREE(compDesignation)
        }
        FVE_FREE(componentTags)

        //According to designations of the components, decide on which Milestone to check
        if(countUN>0)
        {
            mID  ="UNV1";
        }
        else if (countUN<=0 && countUP>0)
        {
            mID="UPV1";
        }
        else 
        {
            mID="";
        }

        if (tc_strcmp(mID, "")==0 ||mID==NULL)
        {
            if(time_diff % number_of_due_days == 0 && time_diff > 0)
                CLEANUP(FV_add_unique_tag_to_array(cnt_wip_paat, wip_paat_tags, paat_tags[0][indx])) 
        }
        else
        {
            assignedCnt=0;
            countmID=0;

            //Get the  milestones  for given VP  
            CLEANUP(FV_find_vehicle_milestone_assignments(vehPrgRevTag,FV_ALL_MILESTONE_ASSIGNMENTS,&assignedCnt, &assignedTags))
            for(tempIdx=0; tempIdx<assignedCnt; tempIdx++)
            {
                CLEANUP(AOM_ask_value_string(assignedTags[tempIdx], FVE_MilestoneIDPROP, &milestoneID))
                if(milestoneID != NULL && tc_strlen(milestoneID)>0 && tc_strcmp(milestoneID, mID)==0)
                {
                    countmID++;
                    CLEANUP(AOM_ask_value_date(assignedTags[tempIdx], FVE_MilestoneDueDatePROP, &MilestoneDueDate))

                    // if the milestone date has not passed , send notification when 30 or less days are left ,acc to due days 
                    if ((FV_compare_dates(MilestoneDueDate, NULLDATE, FV_COMPARE_DATE_ONLY) > 0) )
                    {
                        time_left_for_mlstn = (FVDT_get_date_difference(MilestoneDueDate,current_date_t))/(60*60*24);

                        // send  a notification only if the milestone date is within 30 days and the time diff is a multiple of the due days
                        if  (time_left_for_mlstn <=vp_time_interval && time_diff % number_of_due_days == 0 && time_diff > 0 && time_left_for_mlstn > 0)
                        {
                            CLEANUP(FV_add_unique_tag_to_array(cnt_wip_paat, wip_paat_tags, paat_tags[0][indx]))
                        }
                    }

                    //if milestone has passed,send notification acc to due days  
                    else
                    {
                        if  (time_diff % number_of_due_days == 0 && time_diff > 0)
                        {
                            CLEANUP(FV_add_unique_tag_to_array(cnt_wip_paat, wip_paat_tags, paat_tags[0][indx]))
                        }
                    }
                }
                FVE_FREE(milestoneID)
                milestoneID = NULL;
            } 

            if(0==countmID )
            {
                // if the milestone has not been set, send notification acc to due days 
                if  (time_diff % number_of_due_days == 0 && time_diff > 0)
                {
                    CLEANUP(FV_add_unique_tag_to_array(cnt_wip_paat, wip_paat_tags, paat_tags[0][indx]))
                }
            }
            FVE_FREE(assignedTags)
        }     
    }

CLEANUP:
     return ifail;
  }


//Function to send notification
//Send notification to D&R Engg for all the owned PAAT as single mail
int FVDT_send_PAAT_notification(int cnt_paat, tag_t* paat_tags)
{
    int         ifail                           = ITK_ok;
    int         Process_id                      = 0;
    int         indx                            = 0;
    int         size_paat_owners                = 0;
    int         prefValueCnt                    = 0;

    char*       custom_name                     = NULL;
    char*       pref_val_htmlfile               = NULL;
    char**      prefValues                      = NULL;
    char        Processid_val[FV_INTEGER_LEN+1] = {'\0'};
    struct      stat stat_struct;
    PAAT_owners_struct_t* paat_owners           = NULL;
    FILE*       log_file_ptr                    = NULL;

    printf("\n Sending notification to users...\n");

    //Segregate PAAT records for their owners
    for(indx=0; indx<cnt_paat; indx++)
    {
        int     i           = 0;
        tag_t   owner       = NULLTAG;
        logical found       = false;

        CLEANUP(AOM_ask_owner(paat_tags[indx], &owner))

        for(i=0; i<size_paat_owners; i++)
        {
            if(owner == paat_owners[i].owning_user)
            {
                 CLEANUP(FV_add_unique_tag_to_array(&(paat_owners[i].cnt_owning_paats), &(paat_owners[i].owning_paat_tags), paat_tags[indx]))
                 found = true;
                 break;
            }
        }
        if(found == false)
        {
            paat_owners = (PAAT_owners_struct_t*)MEM_realloc(paat_owners, sizeof(PAAT_owners_struct_t) * (size_paat_owners+1));
            initialize_PAAT_owners_struct(&(paat_owners[size_paat_owners]));

            paat_owners[size_paat_owners].owning_user = owner;
            CLEANUP(FV_add_tag_to_array(&(paat_owners[size_paat_owners].cnt_owning_paats), &(paat_owners[size_paat_owners].owning_paat_tags), paat_tags[indx]))
            size_paat_owners++;
        }
    }

    FV_strdup("\"",&custom_name);
    FV_strcat(&custom_name , "Late Notification - PAAT Assessment Pending");
    FV_strcat(&custom_name , "\"");
    FV_strcat(&custom_name , "\0");

    //Get the path for creating file from preference.
    CLEANUP(PREF_ask_char_value(FVE_TMP_DIR_PREF, 0, &pref_val_htmlfile))
    if(tc_strcmp(pref_val_htmlfile, "") == 0)
    {
           TC_write_syslog("+++ERROR: Preference %s doesn't exist\n", FVE_TMP_DIR_PREF);
           ifail = FVE_TMP_NOT_PRESENT;
           goto CLEANUP;
    }
    else if(stat(pref_val_htmlfile,&stat_struct) != 0)
    {
        TC_write_syslog("+++ERROR: The value set for FVE_TMP_DIR preference is invalid. 'Value' does not exist in your system. Please create the directory in the path specified or contact your System Administrator\n",FVE_TMP_IS_INVALID);
        ifail = FVE_TMP_IS_INVALID;
        goto CLEANUP;
    }

    Process_id =(int) getpid();
    //Convert the process id value from int to string.
    sprintf(Processid_val, "%d", Process_id);

    for(indx=0; indx<size_paat_owners; indx++)
    {
        int         indx_paat       = 0;
        char*       file_path       = NULL;
        char        file_no[FV_INTEGER_LEN+1] = {'\0'};

        //Sort the PAAT objects with their display names
        CLEANUP(FV_sort_tags_by_attr(paat_owners[indx].cnt_owning_paats,
                                    &paat_owners[indx].owning_paat_tags,
                                    object_stringPROP, FV_SORT_ASCENDING))

        //Make the file with unique name.
        sprintf(file_no, "%d", indx);
        FV_strdup(pref_val_htmlfile,&file_path);
        FV_strcat(&file_path,FV_FILEPATH_DELIMITER);
        FV_strcat(&file_path,Processid_val);
        FV_strcat(&file_path,file_no);
        FV_strcat(&file_path, "Email_PAAT_Notification.htm");
        FV_strcat(&file_path , '\0');

        log_file_ptr =fopen(file_path, "w+");
        fprintf(log_file_ptr,"%s\n","<html> <head> <style> ");
        fprintf(log_file_ptr,"%s\n\n","table, th, td {border: 1px solid black; border-collapse: collapse;}");
        fprintf(log_file_ptr,"%s\n","th, td { padding: 5px;} </style> </head>");

        fprintf(log_file_ptr,"%s","<body style=\"font-size:11pt;font-family:Calibri\">");
        fprintf(log_file_ptr,"%s", MAIL_HTML_SINGLE_LINE_BR);
        fprintf(log_file_ptr,"%s", "This message is to inform you that assessment process is due for following PAAT Records:");
        fprintf(log_file_ptr,"%s", MAIL_HTML_DOUBLE_LINE_BR);
        fprintf(log_file_ptr,"%s", "<table style=\"width:100% font-size:11pt;font-family:Calibri\";>");
        fprintf(log_file_ptr,"%s", "<tr> <th>PAAT Name</th> <th>PAAT Risk Number</th> <th>PAAT Status</th> </tr>");

        for(indx_paat=0; indx_paat<paat_owners[indx].cnt_owning_paats; indx_paat++)
        {
            char*   object_string   = NULL;
            char*   paat_url        = NULL;
            char*   risk_str        = NULL;
            char*   status          = NULL;

            CLEANUP(TC_tag_to_url(paat_owners[indx].owning_paat_tags[indx_paat], PORTAL, &paat_url))
            CLEANUP(AOM_ask_value_string(paat_owners[indx].owning_paat_tags[indx_paat], object_stringPROP, &object_string))
            CLEANUP(AOM_ask_value_string(paat_owners[indx].owning_paat_tags[indx_paat], fv9RiskNumberPROP, &risk_str))
            CLEANUP(FV_ask_release_status(paat_owners[indx].owning_paat_tags[indx_paat], &status))

            if(status == NULL)
                FV_strdup(" ", &status);

            fprintf(log_file_ptr,"%s","<tr>");

            fprintf(log_file_ptr,"%s","<td>");
            fprintf(log_file_ptr,"%s","<a href=\"");
            fprintf(log_file_ptr,"%s",paat_url);
            fprintf(log_file_ptr,"%s","\">");
            fprintf(log_file_ptr,"%s",object_string);
            fprintf(log_file_ptr,"%s"," <\/a>");
            fprintf(log_file_ptr,"%s","<\/td>");

            fprintf(log_file_ptr,"%s","<td> ");
            fprintf(log_file_ptr,"%s",risk_str);
            fprintf(log_file_ptr,"%s"," <\/td>");

            fprintf(log_file_ptr,"%s","<td> ");
            fprintf(log_file_ptr,"%s",status);
            fprintf(log_file_ptr,"%s"," <\/td>");

            fprintf(log_file_ptr,"%s","<\/tr>");
            fprintf(log_file_ptr,"%s","\0");

            FVE_FREE(object_string)
            FVE_FREE(paat_url)
            FVE_FREE(risk_str)
            FVE_FREE(status)
        }
        fprintf(log_file_ptr,"%s","</table>");
        fprintf(log_file_ptr,"%s", MAIL_HTML_DOUBLE_LINE_BR);
        fprintf(log_file_ptr,"%s","Please fill out the above PAAT assessment record(s) & submit for assessment process.");
        fprintf(log_file_ptr,"%s", MAIL_HTML_DOUBLE_LINE_BR);

        //CR No:14906640- Adding PAAT training material information in PAAT notification
        //read the Preference Value to display the Training Material Information Link
        CLEANUP(PREF_ask_char_values(PAAT_NOTIFICATION_TRAINING_LINK_PREF,&prefValueCnt,&prefValues))
        if(prefValueCnt==1)
        {
            tag_t   item = NULLTAG;
            CLEANUP(ITEM_find_item(prefValues[0], &item))
            if(item != NULLTAG)
            {
                char* item_desc = NULL;
                CLEANUP(AOM_ask_value_string(item, object_descPROP, &item_desc))

                fprintf(log_file_ptr ,"%s","PAAT Training Material Link: ");
                fprintf(log_file_ptr ,"%s", "<a href=\"");
                fprintf(log_file_ptr ,"%s" ,item_desc );
                fprintf(log_file_ptr ,"%s", "\">");
                fprintf(log_file_ptr ,"%s",item_desc);
                fprintf(log_file_ptr ,"%s", "</a>");
                FVDT_FREE(item_desc)
            }
        }

        fprintf(log_file_ptr," %s", "</body>");
        fprintf(log_file_ptr," %s", "</HTML>");
        fclose(log_file_ptr);

        CLEANUP(FV_send_mail(&file_path ,custom_name, &(paat_owners[indx].owning_user), 1, NULL, 0))
        FVE_FREE(file_path)
    }

CLEANUP:

    for(indx=0; indx<size_paat_owners; indx++)
        free_PAAT_owners_struct(&(paat_owners[indx]));

    FVE_FREE(pref_val_htmlfile)
    FVE_FREE(custom_name)
    return ifail;
}

void initialize_PAAT_owners_struct(struct PAAT_owners_struct* owners)
{
    owners->owning_user = NULLTAG;
    owners->owning_paat_tags = NULL;
    owners->cnt_owning_paats = 0;
}

void free_PAAT_owners_struct(struct PAAT_owners_struct* owners)
{
    if(owners != NULL)
    {
        FVE_FREE(owners->owning_paat_tags)
    }
}



//Tells the differnce of dates in terms of number of seconds
double FVDT_get_date_difference(date_t target, date_t input)
{
    double diff = 0;
    struct  tm compare_tm;
    struct  tm target_tm;

    compare_tm.tm_mday = input.day;
    compare_tm.tm_mon  = input.month;
    compare_tm.tm_year = input.year - 1900;
    compare_tm.tm_hour = 0;
    compare_tm.tm_sec  = 0;
    compare_tm.tm_min  = 0;

    target_tm.tm_mday = target.day;
    target_tm.tm_mon  = target.month;
    target_tm.tm_year = target.year - 1900;
    target_tm.tm_hour = 0;
    target_tm.tm_sec  = 0;
    target_tm.tm_min  = 0;

    diff = difftime(mktime(&target_tm), mktime(&compare_tm));
    return diff;
}
