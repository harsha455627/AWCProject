/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: fve_create_update_excel_template.c
    Module  : main

        Used to create and update excel template
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>
===============================================================================
Date               Name                    Description of Change
03-Jan-2013        Brian Lobo              Initial version
===============================================================================*/
#include <time.h>
#include "fve_create_update_excel_template.h"

/* Global Attributes */
char *          login_group                     = NULL;
char *          login_user                      = NULL;
char *          login_password                  = NULL;
FILE *logfileptr = NULL;

/*******************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *   This utility will read the input file ,create excel template if not present . If present will update them
 *
 * Usage:
 *   FVE_remove_dataset -u=user -p=password -g=group -f=inputfile
 *
 * ARGUMENTS
 *   u              In     User name
 *   p              In     Password
 *   g              In     Group
 *   i              In     Input definition name
 *   f              In     path of the directory holding the template files
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description
 * ----------     -------------------    -----------------------------
 *  Jan 2013      Brian lobo             Created
 *
 ******************************************************************************/

extern int ITK_user_main( int argc, char **  argv )
{
    int             ifail                           = ITK_ok;
    int             i                               = 0;
    int             rule_count                      = 0;
	int             line_count                      = 0;
    char *          def_file                        = NULL;
    char *          template_home                   = NULL;
    char *          template_name                   = NULL;
    char *          template_file                   = NULL;
    char **         template_rule                   = NULL;
    char            fileline[257]                   = "";
	char            fileline_tmp[257]               = "";
    FILE *          inputfileptr                    = NULL;
	char            logfilename[255 + 1]            = "";
	char *          time_stamp                      = NULL;
    char *          ptr						    = NULL;
	logical         is_template_name_null			=	FALSE;

    /*Append the log file name with the date and time stamp 
    along with Process ID */
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"UPD_EXCEL_TEMPLATE_%s.log",time_stamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }

    printf("\nLog information will be written into %s\n\n",logfilename);
        
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
        fprintf(logfileptr,"argc: %d\n", argc);
        FVE_FREE(time_stamp)
    }
    

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

    login_user     = ITK_ask_cli_argument("-u=");
    login_password = ITK_ask_cli_argument("-p=");
    login_group    = ITK_ask_cli_argument("-g=");
    def_file       = ITK_ask_cli_argument("-i=");
    template_home  = ITK_ask_cli_argument("-f=");

    ITK_initialize_text_services (0);
    CLEANUP(ITK_init_module (login_user, login_password, login_group))
    if(ifail != ITK_ok)
    {
        printf("Login with userid: %s, group:%s is unsuccessful\n", login_user, login_group);
        fprintf(logfileptr,"ERROR: Login with uid: %s, group:%s is unsuccessful\n", login_user, login_group);    
        fclose( logfileptr );		
        print_usage();
        exit(0);
    }
    else{
        printf("Login with userid: %s, group:%s is successful\n", login_user, login_group);
	    fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n", login_user, login_group);
	}

  fprintf(logfileptr,"-------------------------------------------------------------------\n\n");

    /*Read input file */
    inputfileptr = fopen( def_file, "r");
    if (!inputfileptr)
    {
       printf("Unable to read definition file , utility terminating.\n\n");
	   fprintf(logfileptr,"Unable to read definition file , utility terminating.\n\n");
       goto CLEANUP;
    }

    /* Process input file */
    while (fgets(fileline, 256, inputfileptr) != NULL) 
    {
      char * token    = NULL;
      template_name   = NULL;
      template_file   = NULL;
      template_rule   = NULL;
      rule_count      = 0;
	  line_count++ ;

	  fprintf(logfileptr,"Processing for Line Number =%d\n", line_count);
	  fflush(logfileptr);

      template_rule   = (char**) MEM_alloc(sizeof(char*)*50);

	  if(fileline && tc_strlen(fileline)> 0){

		tc_strcpy( fileline_tmp, fileline);

		ptr = tc_strtok(fileline_tmp, ",");

		FVE_get_value(ptr, &template_name, &is_template_name_null);

		if(is_template_name_null == FALSE){
		fprintf(logfileptr,"Template Name = %s\n",template_name);
		fflush(logfileptr);

		}else{
		fprintf(logfileptr,"Template Name is NULL\n");
		fflush(logfileptr);

		}
	  }

      if (template_name)
      {
		template_file = (char *) tc_strtok(NULL,",");

         if (template_file)
         {
           
           do
           {
              token = (char *) tc_strtok(NULL,",");
              if (token)
              {
                  template_rule[rule_count]   = (char*) MEM_alloc(sizeof(char)*50);
                  tc_strcpy(template_rule[rule_count++],token);
              }
           }
           while(token);

         }

      }

	  fprintf(logfileptr,"Template File = %s\n",template_file);
	  fflush(logfileptr);

      /* Create / update Excel Template */      
      ifail = fve_update_excel_template(template_name,template_file,template_home,template_rule,rule_count);
      if (template_rule) MEM_free(template_rule);

	  fprintf(logfileptr,"After calling fve_update_excel_template for Line Number =%d\n", line_count);
	  fprintf(logfileptr,"=======================================================================\n\n");
	  fflush(logfileptr);

    }//End of while loop
    fclose(inputfileptr);
    ITK_exit_module( true );
    printf("Utility completed successfully.\n\n");
    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
    FVE_FREE(time_stamp); 

	if (logfileptr ) fclose( logfileptr);

    CLEANUP:

    return ifail;
}

/*******************************************************************************
 * NAME: print_usage
 *
 * DESCRIPTION
 *  prints command usage
 *
 * ARGUMENTS
 *   
 *
 * RETURNS
 *   
 *
 * NOTES
 ******************************************************************************/
static void print_usage(void)
{
        printf("\n********************************************************\n");
        printf("Usage: fve_create_update_excel_template <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<login user id>\n");
        printf(" -p=<login password>\n");
        printf(" -g=<login group>\n");
        printf(" -i=definition filename\n");
        printf(" -f=directory holding templates\n");
        printf("\n");
        printf("***********************************************************\n\n");        
}

/* This function checks the tokenised value is null or not */
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}

/*******************************************************************************
 * NAME: fve_update_excel_template
 *
 * DESCRIPTION
 *  Function to create/update excel templates
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *   template_name          In         Name of the template
 *   template_home          In         Full path of the template files
 *   template_rule          In         List of template rules to be applied
 *   rule_count             In         Count of Excel template rules
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/

int fve_update_excel_template(char * template_name,char * template_file,char * template_home,char **template_rule,int rule_count)
{
    int    ifail                     = ITK_ok;
    int    num_found                 = 0;
    int    inx                       = 0;
    tag_t *objTags                   = NULLTAG;
    tag_t  typeTag                   = NULLTAG;
    tag_t  itemCreateInputTag        = NULLTAG;
    tag_t  itemOfExcelTmplt          = NULLTAG;
   char **att_name                  = NULL;
    char **attr_values               = NULL;
    char  *fullpathname              = NULL;
    char  *commandline               = NULL;

    /*char*       att_name[1] = {"object_name"};
    char*       attr_values[1] = {'\0'};
	*/

	  fprintf(logfileptr,"Inside fve_update_excel_template\n");
	  fflush(logfileptr);

    attr_values    = (char **) MEM_alloc(sizeof(char*)*2);
    attr_values[0] = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(attr_values[0],template_name);


    att_name       = (char **) MEM_alloc(sizeof(char*)*2);
    att_name[0]    = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(att_name[0],"object_name");

    fullpathname = (char*) MEM_alloc(sizeof(char)*512);
    commandline  = (char*) MEM_alloc(sizeof(char)*1024);


    sprintf(fullpathname,"%s//%s",template_home,template_file);

    fprintf(logfileptr,"Full Path Name =%s\n",fullpathname);
    fflush(logfileptr);	

    sprintf(commandline,"add_req_templates -u=%s -p=%s -g=%s -t=ExcelTemplate -i=%s",login_user,login_password,login_group,fullpathname);

	 attr_values[0] = template_name;

    /* search for template_name */
    FV_search_objects_by_attrs(EXCELTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);

    /* If not found create template */
    if (num_found < 1)
    {        
        
	  fprintf(logfileptr,"No Template found,So Importing Template\n");
	  fflush(logfileptr);		
		/* Call add_req_templates to create template */
        system(commandline);
        
        /* update Excel Template Rule */
        if (template_rule)
        {
           
		  fprintf(logfileptr,"Applying template rules\n");
		  fflush(logfileptr);	
	  
		   FV_search_objects_by_attrs(EXCELTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);
           if (num_found)
           {
              CLEANUP(ITEM_ask_item_of_rev  (objTags[0],&itemOfExcelTmplt))
              ifail = AOM_refresh(itemOfExcelTmplt,true);
              for(inx=0;inx<rule_count;inx++)
              {
                 /* To overwrite the end of line character */
                 if (inx==(rule_count-1))
                 {
                     int last_element =0;
                     last_element = tc_strlen(template_rule[inx]);
                     template_rule[inx][--last_element]='\0';
                 }
                 CLEANUP(AOM_set_value_string_at(itemOfExcelTmplt,EXCELTMPLTRULE_PROP,inx,template_rule[inx]))
              }
              CLEANUP(AOM_save(itemOfExcelTmplt))
           }
        }
    }
    else
    /* Update template */
    {
       tag_t             relationTypeTag     = NULLTAG;
       tag_t             attachmentTypeTag   = NULLTAG;
       tag_t             msexcelTag          = NULLTAG;
       tag_t             msexcelxTag         = NULLTAG;
       tag_t             file_tag            = NULLTAG;
       tag_t             relation            = NULLTAG;
       tag_t             tagDataSet          = NULLTAG;
       tag_t*            referencers         = NULL;
       GRM_relation_t   *secondary_list      = NULL;
       char**            relations           = NULL; 
       char**            values              = NULL;
       int               count               = 0;
       int               j                   = 0;
       int               n_referencers       = 0;
       int               inx                 = 0;
       int               i                   = 0; 
       int               num                 = 0;
       int*              levels              = NULL; 
	   

	  fprintf(logfileptr,"Existing Template found,So Updating Template\n");
	  fflush(logfileptr);

       
       CLEANUP(TCTYPE_find_type  ("MSExcelX","",&msexcelxTag))
       /* Remove existing dataset */
       CLEANUP(GRM_find_relation_type("IMAN_specification",&relationTypeTag))
       CLEANUP(GRM_list_secondary_objects(objTags[0],NULLTAG,&count,&secondary_list)) 
       
       for(inx =0 ;inx<count;inx++)
       {
           CLEANUP(TCTYPE_ask_object_type(secondary_list[inx].secondary, &attachmentTypeTag ))
           if ((attachmentTypeTag == msexcelxTag))
           {
               CLEANUP(GRM_delete_relation(secondary_list[inx].the_relation))
               CLEANUP(AOM_lock_for_delete(secondary_list[inx].secondary))
               CLEANUP(AE_delete_all_dataset_revs(secondary_list[inx].secondary))
           }
           
       }

	  fprintf(logfileptr,"After deleting existing dataset\n");
	  fflush(logfileptr);

       /* Attaching New dataset */
       /* To overwrite the end of line character */
       if (rule_count==0)
       {
           int last_element =0;
           last_element = tc_strlen(fullpathname);
           fullpathname[--last_element]='\0';
       }
       CLEANUP(fve_create_dataset (template_name,"","MSExcelX",&tagDataSet))

       //Added for updating IP_Classfication
		CLEANUP( WSOM_set_ip_classification( tagDataSet, IP_PUBLIC ) )
		CLEANUP( AOM_refresh(tagDataSet, false ) )
        //Addition Ends

       CLEANUP(fve_import_file(fullpathname,&file_tag))
       CLEANUP(fve_attach_file (tagDataSet,file_tag,"excel"))
       CLEANUP(GRM_create_relation  (objTags[0],tagDataSet,relationTypeTag,NULLTAG,&relation))  
       CLEANUP(GRM_save_relation(relation))

       /* Wipe out past template rules */
       CLEANUP(ITEM_ask_item_of_rev  (objTags[0],&itemOfExcelTmplt))
       CLEANUP(AOM_refresh(itemOfExcelTmplt,true))
       CLEANUP(AOM_ask_value_strings  (itemOfExcelTmplt,EXCELTMPLTRULE_PROP,&num,&values))
       if (values) MEM_free(values);
			 			for (i = 0 ; i < num ; i++)
			    { 
			        CLEANUP(AOM_set_value_string_at(itemOfExcelTmplt,EXCELTMPLTRULE_PROP,i,""));
       }
       AOM_save(itemOfExcelTmplt);

	  fprintf(logfileptr,"After creating the dataset again\n");
	  fflush(logfileptr);
        
       /* update Excel Template Rule */
        if (rule_count)
        {
              for(inx=0;inx<rule_count;inx++)
              {
                 /* To overwrite the end of line character */
                 if (inx==(rule_count-1))
                 {
                     int last_element =0;
                     last_element = tc_strlen(template_rule[inx]);
                     template_rule[inx][--last_element]='\0';
                 }
                 CLEANUP(AOM_set_value_string_at(itemOfExcelTmplt,EXCELTMPLTRULE_PROP,inx,template_rule[inx]))
              }
              CLEANUP(AOM_save(itemOfExcelTmplt))

		  fprintf(logfileptr,"After applying template rules\n");
		  fflush(logfileptr);
           
        }
        CLEANUP(AOM_refresh(itemOfExcelTmplt,false))
       
    }

CLEANUP:
    
    if (objTags)      MEM_free(objTags);
    if (attr_values)  MEM_free(attr_values);
    if (att_name)     MEM_free(att_name);
    if (fullpathname) MEM_free(fullpathname);
    if (commandline)  MEM_free(commandline);
    
    return ifail;

}

/*====================================================================================================================================================
Function     :  fve_create_dataset

Description  :  Function to create dataset

input        :  
pchDatasetName - Name of Dataset
pchDatasetDesc - Description of the dataset
pchDatasetType - Dataset type

Output       :   tagDataSet     - Tag of dataset


Return value :  ITK_ok if successfully completed
non zero value on error 

=====================================================================================================================================================*/
int fve_create_dataset (char  *pchDatasetName,char  *pchDatasetDesc,char  *pchDatasetType,tag_t *tagDataSet)
{
    int   ifail          = ITK_ok;
    tag_t tagDatasetType = NULLTAG;
    tag_t tagToolTag     = NULLTAG;

    if ((ifail = AE_find_datasettype (pchDatasetType, &tagDatasetType)) != ITK_ok)
    {
        TC_write_syslog( " Failed to find dataset type \n");
        return ifail;
    }

    if (tagDatasetType == NULLTAG)
    {
        TC_write_syslog( "  dataset type tag is NULL\n");
        return !ITK_ok;
    }

    ifail = AE_ask_datasettype_def_tool (tagDatasetType,&tagToolTag);

    if (tagToolTag == NULLTAG)
    {
        TC_write_syslog( " dataset Tool is NULL \n");
        return !ITK_ok;
    }


    if ((ifail = AE_create_dataset_with_id (tagDatasetType, pchDatasetName, \
        pchDatasetDesc, 0, 0, tagDataSet)) != ITK_ok)
    {
        return ifail;
    }

    if ((ifail = AE_set_dataset_tool (*tagDataSet, tagToolTag)) != ITK_ok)
    {
        return ifail;
    }

    if ((ifail = AOM_save (*tagDataSet)) != ITK_ok)
    {
        return ifail;
    }

    return ifail;
}

/******************************************************************************
Function     :  fve_import_file

Description  :  Function to import file to TC

input        :  file  - filename that needs to be imported

Output       :  file_tag - file tag


Return value :  if successfull ITK_ok else non-zero number


*******************************************************************************/
int fve_import_file(char  *file,tag_t *file_tag)
{
    int ifail = ITK_ok;
    IMF_file_t file_desc;
    *file_tag = NULLTAG;

    if ((ifail = IMF_import_file (file, NULL, SS_BINARY, file_tag,&file_desc)) != ITK_ok)
    {
        TC_write_syslog(" import_file failed after IMF_import_file \n");
        return ifail;
    }

    if (*file_tag == NULLTAG)
    {
        TC_write_syslog(" import_file file_tag is NULL \n");
        return !ITK_ok;
    }

    if ((ifail = IMF_close_file (file_desc)) != ITK_ok)
    {
        return ifail;
    }

    if ((ifail = AOM_save (*file_tag)) != ITK_ok)
    {
        return ifail;
    }
    
    return ifail;
}

/******************************************************************************
Function     :  fve_attach_file

Description  :  Function to TC file to dataset

input        :  
dataset       - Tag of dataset
file_tag,				 - TC file tag
dst_type			   - dataset type

Output       :  


Return value :  If successful ITK_ok else non-zero number 

*******************************************************************************/
int fve_attach_file (tag_t	dataset,tag_t	file_tag,char	*dst_type )
{
    int ifail                                 = ITK_ok;
    int ref_count                             = 0;
    int lock_type                             = 0;
    logical verdict                           = FALSE;
    char	strNamedRef[AE_reference_size_c + 1] = "\0";
    char *named_ref                           = NULL;

    AE_reference_type_t ref_type  = AE_PART_OF;

    tc_strcpy(strNamedRef, dst_type);

    if ((ifail = POM_is_loaded (dataset, &verdict)) != ITK_ok)
    {
        return ifail;
    }

    if (verdict == FALSE)
    {
        if ((ifail = AOM_load (dataset)) != ITK_ok)
        {
            return ifail;
        }
    }

    if ((ifail = POM_ask_instance_lock (dataset, &lock_type)) != ITK_ok)
    {
        return ifail;
    }

    if (lock_type != POM_modify_lock)
    {
        if ((ifail = AOM_lock (dataset)) != ITK_ok)
        {
            return ifail;
        }
    }

    if ((ifail = AE_ask_dataset_ref_count (dataset, &ref_count)) != ITK_ok)
    {
        return ifail;
    }

    if (ref_count > 0)
    {
        if ((ifail = AE_remove_dataset_named_ref (dataset,strNamedRef)) != ITK_ok)
        {
            return ifail;
        }
    }

    if ((ifail = AE_add_dataset_named_ref (dataset, strNamedRef, \
        ref_type, file_tag)) != ITK_ok)
    {
        return ifail;
    }

    if ((ifail = AOM_save (dataset)) != ITK_ok)
    {
        return ifail;
    }

    if ((ifail = AOM_unlock (dataset)) != ITK_ok)
    {
        return ifail;
    }

    return ifail;
}
