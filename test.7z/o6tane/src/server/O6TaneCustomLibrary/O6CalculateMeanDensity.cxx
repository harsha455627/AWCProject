//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6CalculateMeanDensity
 *
 */
#include <O6TaneCustomLibrary/O6CalculateMeanDensity.hxx>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>

#define DENSITY_MAX "o6_densite_max"
#define DENSITY_MIN "o6_densite_min"
#define MEAN_DENSITY "o6_densite"

/**
 * Function    :  O6CalculateMeanDensity
 * Description :  Used to calculate mean density value.
 * Input       :
 *      msg 		 - Input msg for extension
 *      args         - Input args for extension
 * Output	   :
 * 		none
 */
int O6CalculateMeanDensity( METHOD_message_t * /*msg*/, va_list args )
{
	double dMinDensity = 0.0;
	double dMaxDensity = 0.0;

	int retcode = ITK_ok;

	tag_t  tRMRevTag = NULLTAG;

	va_list largs;
	va_copy ( largs, args );
	tRMRevTag  = va_arg(largs, tag_t);
	va_end( largs );

	ITK ( AOM_ask_value_double ( tRMRevTag, DENSITY_MAX, &dMaxDensity ) );
	ITK ( AOM_ask_value_double ( tRMRevTag, DENSITY_MIN, &dMinDensity ) );

	/* Both the max and min density values should be non zero to proceed */
	if ( ( dMaxDensity == 0.0 && dMinDensity != 0.0 ) || ( dMaxDensity != 0.0 && dMinDensity == 0.0 ) || ( dMaxDensity != 0.0 && dMinDensity != 0.0 ) )
	{
		double dAvgDensity = 0.0;

		dAvgDensity = ( dMaxDensity + dMinDensity )/2;

		ITK ( AOM_refresh ( tRMRevTag, true ) );
		ITK ( AOM_set_value_double ( tRMRevTag, MEAN_DENSITY, dAvgDensity ) );
		ITK ( AOM_save ( tRMRevTag ) );
		ITK ( AOM_refresh ( tRMRevTag, false ) );
	}

	return retcode;
}
