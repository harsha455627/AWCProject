
#include <O6TaneCustomLibrary/O6ActionHandlers.hxx>
#include <O6TaneCustomLibrary/O6ParseObjMapXML.hpp>
#include <cstdio>
#include <iostream>
#include <ctime>
#include <stdio.h>
#include <tccore/grm.h>
#include <stdio.h>
#include <pom/pom/pom.h>
#include <tccore/item.h>
#include <ps/ps.h>
#include <bom/bom.h>
#include <ae/tool.h>
#include <fstream>

#define SEEDS_SHARE_PATH_NOT_FOUND (SEEDS_CUSTOM_ERROR_BASE + 71)
#define FLEREV "O6_FleRevision"
#define GENRMREV "O6_GenRMRevision"
#define SUPLREV "O6_SupRMRevision"

#define GEN_TO_SUP "O6_GenToSupplRM"

#define OBJECT_TYPE "object_type"
#define OBJECT_NAME "object_name"
#define DATASET "Dataset"
#define DOC_CODE "o6_doc_code"
#define DOC_TYPE "o6_doc_type"
#define OBJ_NAME "object_name"
#define OBJ_TYPE "object_type"
#define CPD_STATUS "o6_cpd_status"
#define CPD_MARQUE "o6_cpd_marque"
#define CREATION_DATE "creation_date"
#define MOD_DATE "last_mod_date"
#define ITEM_ID "item_id"
#define OBJECT_DESC "object_desc"
#define STRUCTURE_REVISIONS "structure_revisions"
#define QUALI_QUANTI_REL "O6_QQRel"
#define REGULATED_REL "O6_RegulatedRel"
#define REL_STATUS_LIST "release_status_list"
#define O6_SIMULATION "o6_simulation"
#define INGLIST_REV_TYPE "O6_IngListRevision"
#define O6_ALLERGENE "o6_allergene"
#define O6_IMPURETE "o6_impurete"
#define O6_APPLICATION_TYPE "o6_application_typ"
#define FRENCH_RINCE_VALUE "Rinc�"
#define ENGLISH_RINSE_VALUE "Rinsed"
#define TRUE_VALUE "True"
#define FALSE_VALUE "False"


#define bomAttr_bl_occ_o6_percent_theoric "bl_occ_o6_percent_theoric"
#define bomAttr_bl_occ_o6_vol_percent_theoric "bl_occ_o6_vol_percent_theoric"

/**
 * Function    :  get_date
 * Description :  Return current date.
 * Input       :
 * 		 curren_date	<O>	 - Current Date
 *
 */
int get_date(char** curren_date) {
	int retcode = ITK_ok;

	time_t now = time(0);

	tm *ltm = localtime(&now);

	char local_buff[80];
	sprintf_s(local_buff, "%d%d%d", (1900 + ltm->tm_year),(1 + ltm->tm_mon), (ltm->tm_mday));

	*curren_date = (char*) MEM_alloc(sizeof(char) * (tc_strlen(local_buff) + 1));
	tc_strcpy(*curren_date, local_buff);

	return retcode;
}

/**
 * Function    :  getTargetType
 * Description :  Return target type.
 * Input       :
 * 		 objTag	<I>	 - Object Tag
 * 		 targettype<O> - Target type
 *
 */
int getTargetType(tag_t objTag, char** targettype){
	int retcode = ITK_ok;

	ITK(AOM_ask_value_string(objTag, OBJ_TYPE, targettype));

	return retcode;
}

/**
 * Function    :  getStatus
 * Description :  Return release status.
 * Input       :
 * 		 objTag	<I>	 - Object Tag
 * 		 relstatus <O> - Release status
 *
 */
int getStatus(tag_t objTag, char** relstatus){
	int retcode = ITK_ok;

	ITK(AOM_ask_value_string(objTag, CPD_STATUS, relstatus));

	return retcode;
}

/**
 * Function    :  getModifiedDate
 * Description :  Return modified date.
 * Input       :
 * 		 objTag	<I>	 - Object Tag
 * 		 modifieddate <O> - Last modified date
 *
 */
int getModifiedDate(tag_t objTag, char** modifieddate){
	int retcode = ITK_ok;
	date_t mod_date = POM_null_date();

	char buff[50] = {'\0'};

	ITK(AOM_ask_value_date(objTag, MOD_DATE, &mod_date));
	if(retcode == ITK_ok){
		sprintf_s(buff, "%d/%d/%d", mod_date.day, ((mod_date.month ) + 1), mod_date.year);

		*modifieddate = (char*) MEM_alloc(sizeof(char) * (tc_strlen(buff) + 1));

		tc_strcpy(*modifieddate, buff);
	}

	return retcode;
}

/**
 * Function    :  getCreationDate
 * Description :  Return creation date.
 * Input       :
 * 		 objTag	<I>	 - Object Tag
 * 		 creationdate <O> - Creation date.
 *
 */
int getCreationDate(tag_t objTag, char** creationdate){
	int retcode = ITK_ok;
	date_t cre_date = POM_null_date();

	char buff[50] = {'\0'};

	ITK(AOM_ask_value_date(objTag, CREATION_DATE, &cre_date));
	if(retcode == ITK_ok){
		sprintf_s(buff, "%d/%d/%d", cre_date.day, ((cre_date.month ) + 1), cre_date.year);

		*creationdate = (char*) MEM_alloc(sizeof(char) * (tc_strlen(buff) + 1));

		tc_strcpy(*creationdate, buff);
	}

	return retcode;
}

/**
 * Function    :  isValidDataset
 * Description :  Return creation date.
 * Input       :
 * 		 doccode	<I>	 - Doc code.
 * 		 start <I> - Document type list
 * 		 att_cnt <I> - Attachment count
 * 		 attachments <I> - Attachments
 * 		 obj <I> - Object Tag
 *
 */
int isValidDataset(char* doccode, doc_types_t* start, int att_cnt,
		tag_t* attachments, tag_t obj) {

	int retcode = ITK_ok;
	int value = 0;

	doc_types_t* tmpnode = NULL;

	if (tc_strlen(doccode) > 0) {
		tmpnode = start;
		while (tmpnode != NULL) {
			if (tc_strcmp(tmpnode->type_name, doccode) == 0) {
				value = 1;
				break;
			} else {
				tmpnode = tmpnode->next;
			}
		}
	}

	if (value == 0) {
		tag_t objtag = NULLTAG;
		for (int indx = 0; indx < att_cnt; indx++) {
			objtag = attachments[indx];
			tag_t objtype = NULLTAG;
			ITK(TCTYPE_ask_object_type(objtag,&objtype));
			if (retcode == ITK_ok && objtype != NULLTAG ) {
				char* classname = NULL;
				ITK(TCTYPE_ask_class_name2(objtype, &classname));
				if (retcode == ITK_ok && classname != NULL) {
					if (tc_strcmp(classname, DATASET) == 0 && objtag == obj) {

						value = 1;
					}
					MEM_free(classname);
					classname = NULL;
					if (value) {
						break;
					}
				}
			}
		}
	}

	return value;
}

/**
 * Function    :  getMarque
 * Description :  Return value of a Marque attribute
 * Input       :
 * 		 objTag	<I>	 - Object Tag
 * 		 marqueStr <I>	 - Return attribute value
 */
int getMarque(tag_t objTag, char** marqueStr){
	int retcode = ITK_ok;

	ITK(AOM_ask_value_string(objTag, CPD_MARQUE, marqueStr));

	return retcode;
}

/**
 * Function    :  getLatestRevisionTag
 * Description :  Find latest revision.
 * Input       :
 * 		 itemTag	<I>	 - Item Tag
 * 		 itemRevTag <O>	 - Latest revision tag
 */
int getLatestRevisionTag(tag_t itemTag, tag_t *itemRevTag) {
	int retcode = ITK_ok;

	ITK(ITEM_ask_latest_rev(itemTag,itemRevTag));

	return retcode;
}

/**
 * Function    :  getSupplier
 * Description :  Return supplier name
 * Input       :
 * 		 objTag	<I>	 - Object tag
 * 		 targettype <I>	 - Target type
 * 		 suplname <O> - Supplier Name
 */
int getSupplier(tag_t objTag, char* targettype, char** suplname){
	int retcode = ITK_ok;
	int cnt = 0;
	tag_t relType = NULLTAG;
	tag_t* secondaryObjs = NULL;
	tag_t local_item_tag = NULLTAG;

	if (tc_strcmp(targettype, GENRMREV)==0) {

		ITK(GRM_find_relation_type(GEN_TO_SUP, &relType));
		if (retcode == ITK_ok && relType != NULLTAG ) {
			ITK(GRM_list_secondary_objects_only(objTag,relType,&cnt, &secondaryObjs));
			if (retcode == ITK_ok && cnt > 0 && secondaryObjs != NULL) {

				/**
				 * Only one supplier is attached to the the generic revision but
				 * for some exception if multiple supplier found then use first
				 * supplier.
				 */
				local_item_tag = secondaryObjs[0];

				tag_t suprev = NULLTAG;
				ITK(getLatestRevisionTag(local_item_tag, &suprev));
				if (retcode == ITK_ok && suprev != NULLTAG ) {
					ITK(AOM_ask_value_string(suprev, OBJ_NAME, suplname));
				}

				MEM_free(secondaryObjs);
				secondaryObjs = NULL;
			}
		}
	}
	else
	{
		ITK(AOM_ask_value_string(objTag, OBJ_NAME, suplname));
	}


	return retcode;
}

/**
 * Function    :  create_xml_and_download_files
 * Description :  Create XML file and download named references.
 * Input       :
 * 		 objTag	<I>	 - Object tag
 * 		 buff_xml_file <I>	 - xml file name
 * 		 buff_log_file <I> - log file name
 * 		 args <I> - Handler Argument list
 * 		 start <I> - document type list
 * 		 output_path <I> - Output directory path
 * 		 root_task <I> - Root task
 *
 */
int create_xml_and_download_files(tag_t objTag, char* buff_xml_file,
		char* buff_log_file, arguments_t args, doc_types_t* start,
		char* output_path, tag_t root_task) {

	int retcode = ITK_ok;
	FILE* pFile = NULL;
	char tmpfilename[600] = { '\0' };
	char tmpfilefullname[1000] = { '\0' };

	/* create xml file in */
	pFile = fopen(buff_xml_file, "w");
	if (pFile != NULL) {

		/* Write initial xml block */
		fprintf(pFile, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		fprintf(pFile, "<root>");

		char* targettype = NULL;
		ITK(getTargetType(objTag, &targettype));
		if (retcode == ITK_ok && targettype != NULL) {

			char* itemidstr = NULL;
			ITK(AOM_ask_value_string(objTag,ITEM_ID, &itemidstr));
			if (retcode == ITK_ok && itemidstr != NULL) {
				char* objname = NULL;
				ITK(AOM_ask_value_string(objTag,OBJ_NAME, &objname));
				if (retcode == ITK_ok && objname != NULL) {
					if (tc_strlen(objname) > 0) {

						/* Get release status name */
						char* release_status_nm = NULL;
						ITK(getStatus(objTag, &release_status_nm));

						/* Get creation date */
						char* creationdate = NULL;
						ITK(getCreationDate(objTag, &creationdate));

						char* marqueStr = NULL;
						if(tc_strcmp(targettype,FLEREV) == 0){

							ITK(getMarque(objTag, &marqueStr));
						}

						/**
						 * Get reference attachment
						 */
						int attach_count = 0;
						tag_t* attachments_tag = NULL;
						int ref_attachment_type = EPM_reference_attachment;
						ITK(EPM_ask_attachments(root_task, ref_attachment_type, &attach_count, &attachments_tag));

						rel_t *reltypes = NULL;
						reltypes = args.rellist;
						while (retcode == ITK_ok && reltypes != NULL) {

							tag_t reltype_tag = NULLTAG;
							ITK(GRM_find_relation_type(reltypes->rel_name, &reltype_tag));
							if (retcode == ITK_ok && reltype_tag != NULLTAG ) {

								int nobjs = 0;
								tag_t *objs = NULL;

								ITK(GRM_list_secondary_objects_only(objTag,reltype_tag, &nobjs, &objs));
								if (retcode == ITK_ok && nobjs > 0) {

									fprintf(pFile, "<Files>");

									for (int indx = 0; indx < nobjs && retcode == ITK_ok; indx++) {

										tag_t obj = objs[indx];
										tag_t objtype = NULLTAG;

										ITK(TCTYPE_ask_object_type(obj,&objtype));
										if (retcode == ITK_ok && objtype != NULLTAG ) {

											char* classname = NULL;
											ITK(TCTYPE_ask_class_name2(objtype, &classname));
											if (tc_strcmp(classname, DATASET) == 0) {

												char* lastmodifieddate = NULL;
												ITK(getModifiedDate(obj, &lastmodifieddate));

												char* doccode = NULL;
												ITK(AOM_ask_value_string(obj, DOC_CODE, &doccode));
												if (retcode == ITK_ok && doccode != NULL) {

													if (tc_strlen(itemidstr) > 0
															&& isValidDataset(doccode,
																	start,
																	attach_count,
																	attachments_tag,
																	obj)) {

														tc_strcpy(tmpfilename,"");

														char* cur_date = NULL;
														ITK(get_date(&cur_date));
														if (cur_date != NULL) {

															if (tc_strlen(doccode) > 0) {
																sprintf_s(tmpfilename,
																		"%s_%s_%s_%s",
																		doccode,
																		itemidstr,
																		objname,
																		cur_date);
															} else {
																sprintf_s(tmpfilename,
																		"%s_%s_%s",
																		itemidstr,
																		objname,
																		cur_date);
															}

															tag_t *referenced_object = NULLTAG;
															int n_refobjs = 0;
															ITK(AE_ask_dataset_named_refs(obj, &n_refobjs, &referenced_object));
															if (retcode == ITK_ok && n_refobjs > 0) {
																if (n_refobjs == 1) {

																	char *fileName = NULL;
																	ITK(IMF_ask_original_file_name2(referenced_object[0], &fileName));
																	if (retcode == ITK_ok && fileName != NULL) {

																		char *oldfilename = NULL;
																		oldfilename = (char*) MEM_alloc(sizeof(char) * (tc_strlen(fileName)
																										+ tc_strlen(output_path)
																										+ 5));

																		tc_strcpy(oldfilename,output_path);
																		tc_strcat(oldfilename,"\\");
																		tc_strcat(oldfilename,fileName);

																		ITK(IMF_fmsfile_export(referenced_object[0],oldfilename));
																		if (retcode == 14100) {
																			/* file alrady exist in the directory */
																			retcode = ITK_ok;
																		} else if (retcode == ITK_ok) {

																			char* tokenstr = std::strtok(fileName,".");
																			if (tokenstr != NULL) {
																				tokenstr = strtok(NULL,".");
																			}

																			if (tokenstr != NULL) {
																				tc_strcat(tmpfilename,".");
																				tc_strcat(tmpfilename,tokenstr);

																				tc_strcpy(tmpfilefullname,"");
																				sprintf_s(tmpfilefullname,"%s\\%s",output_path,tmpfilename);

																				int result =0;
																				result = rename(oldfilename,tmpfilefullname);
																				if (result != 0 ) {
																					TC_write_syslog(
																							"\nSEEDS Error: while renaming file..");
																				}

																				fprintf(pFile,"<File ActionType=\"%s\" FileName=\"%s\">", args.action, tmpfilename);
																				fprintf(pFile,"<Metadatas>");
																				if (tc_strlen(doccode) > 0) {
																					fprintf(pFile,"<CodeType>%s</CodeType>",doccode);
																				}
																				else{
																					fprintf(pFile,"<CodeType></CodeType>");
																				}
																				fprintf(pFile,"<CodeArticle>%s</CodeArticle>",itemidstr);
																				fprintf(pFile,"<CodeQualite>1</CodeQualite>");
																				fprintf(pFile,"<LibelleQualite>%s</LibelleQualite>",objname);

																				if(tc_strcmp(targettype,GENRMREV) ==0 || tc_strcmp(targettype,SUPLREV) ==0){

																					char* suplname = NULL;
																					ITK(getSupplier(objTag,targettype, &suplname));
																					if(retcode == ITK_ok && suplname != NULL){

																						fprintf(pFile,"<FournisseurMP>%s</FournisseurMP>",suplname);
																						MEM_free(suplname);
																						suplname = NULL;
																					}
																				}
																				else{
																					fprintf(pFile, "<FournisseurMP></FournisseurMP>");
																				}
																				/* This need to change */

																				fprintf(pFile,"<Fabricant/>");
																				fprintf(pFile,"<CodeLOccitane/>");
																				fprintf(pFile,"<CodeMelvita/>");
																				fprintf(pFile,"<CodeNouvelleMarque/>");
																				fprintf(pFile,"<CodeNouvelleMarque2/>");
																				if(marqueStr != NULL){
																					fprintf(pFile,"<Marque>%s</Marque>",marqueStr);
																				}
																				else
																				{
																					fprintf(pFile,"<Marque></Marque>");
																				}

																				fprintf(pFile,"<GammeFiche/>");
																				fprintf(pFile,"<NomCVL/>");
																				fprintf(pFile,"<CodesPF/>");

																				if(tc_strcmp(targettype,FLEREV) ==0){
																					fprintf(pFile,"<CodeVrac>%s</CodeVrac>",itemidstr);
																				}
																				else
																				{
																					fprintf(pFile,"<CodeVrac> </CodeVrac>");
																				}

																				if(release_status_nm != NULL && tc_strlen(release_status_nm) > 0){
																					fprintf(pFile,"<Statut>%s</Statut>",release_status_nm);
																				}
																				else{
																					fprintf(pFile,"<Statut></Statut>");
																				}

																				if(tc_strcmp(targettype,FLEREV) ==0 && creationdate != NULL){
																					fprintf(pFile,"<DateCreationFormule>%s</DateCreationFormule>",creationdate);
																				}
																				else
																				{
																					fprintf(pFile,"<DateCreationFormule/>");
																				}

																				fprintf(pFile,"<LastUpdate/>");

																				if(lastmodifieddate != NULL){
																					fprintf(pFile,"<DateAjoutPJ>%s</DateAjoutPJ>",lastmodifieddate);
																				}
																				else{
																					fprintf(pFile,"<DateAjoutPJ/>");
																				}

																				fprintf(pFile,"<NomFichierLog>%s</NomFichierLog>",buff_log_file);
																				fprintf(pFile,"</Metadatas>");
																				fprintf(pFile,"</File>");
																			}
																		}
																		MEM_free(oldfilename);
																		oldfilename = NULL;

																		MEM_free(fileName);
																		fileName = NULL;
																	}
																} else {
																	TC_write_syslog(
																			"\nSEED ERROR : Mode than one named references found....");
																}
																MEM_free(referenced_object);
																referenced_object = NULL;
															}

															MEM_free(cur_date);
															cur_date = NULL;
														}
													}

													MEM_free(doccode);
													doccode = NULL;
												}

												if (lastmodifieddate != NULL) {
													MEM_free(lastmodifieddate);
													lastmodifieddate = NULL;
												}
											}
											MEM_free(classname);
											classname = NULL;
										}
									}
								}
								fprintf(pFile, "</Files>");
							}
							reltypes = reltypes->next;
						}

						if(marqueStr != NULL){
							MEM_free(marqueStr);
							marqueStr = NULL;
						}

						if (release_status_nm != NULL) {
							MEM_free(release_status_nm);
							release_status_nm = NULL;
						}

						if (creationdate != NULL) {
							MEM_free(creationdate);
							creationdate = NULL;
						}

						if (attachments_tag != NULL) {
							MEM_free(attachments_tag);
							attachments_tag = NULL;
						}

					}
					MEM_free(objname);
					objname = NULL;
				}
				MEM_free(itemidstr);
				itemidstr = NULL;
			}

			MEM_free(targettype);
			targettype = NULL;
		}

		fprintf(pFile, "</root>");
		fclose(pFile);
	}
	return retcode;
}


/**
 * Function    :  getOutPutDirLoc
 * Description :  Reads the preference 'SEEDS_sharepoint_share' and return the value.
 *
 * Input       :
 *
 * Output
 * 		outPath - Preference value.
 */
int getOutPutDirLoc(char **outPath)
{
    int retcode = ITK_ok;
	char *pathLoc = NULL;

	ITK(PREF_ask_char_value(OUT_FILES_PATH,0,&pathLoc));
	if(pathLoc != NULL){
		*outPath = (char*) MEM_alloc(sizeof(char) * ((int)tc_strlen(pathLoc)+1));
		tc_strcpy(*outPath,pathLoc);
		MEM_free(pathLoc);
		pathLoc = NULL;
	}
	else
	{
		retcode = SEEDS_SHARE_PATH_NOT_FOUND;
		TC_write_syslog("\nSEEDS: Preference 'SEEDS_sharepoint_staging_dir' not set.");
	}

	return retcode;
}

/**
 * Function    :  get_time
 * Description :  Gets the system current time and return string in
 * 				  YY-MM-DD-hh-mm-ss format.
 *
 * Input       :
 *
 * Output
 * 		curren_time - Preference value.
 */
int get_time(char** curren_time) {
	int retcode = ITK_ok;

	time_t now = time(0);

	tm *ltm = localtime(&now);

	char local_buff[80];
	sprintf_s(local_buff, "%d-%d-%d-%d-%d-%d", (1900 + ltm->tm_year),
			(1 + ltm->tm_mon), (ltm->tm_mday), (1 + ltm->tm_hour),
			(1 + ltm->tm_min), (1 + ltm->tm_sec));

	*curren_time = (char*) MEM_alloc(sizeof(char) * (tc_strlen(local_buff) + 1));
	tc_strcpy(*curren_time, local_buff);

	return retcode;
}




/**
 * Function    :  get_output_file_details
 * Description :  Wrapper function to create output file name string
 * 				  and return out put path.
 *
 * Input       :
 *		item_id_local - item id
 *		rev_id_local  - revision id
 *
 * Output
 * 		output_file_name - Output file name.
 * 		output_path - Output file path.
 */
int get_output_file_details(char* item_id_local, char* rev_id_local, char** output_file_name, char** output_path){
	int retcode = ITK_ok;

	char buff[1000] = {'\0'};

	sprintf_s(buff, "%s_%s_",item_id_local, rev_id_local);

	ITK(getOutPutDirLoc(output_path));
	if(retcode == ITK_ok){

		char* curr_time = NULL;
		ITK(get_time(&curr_time));
		if(curr_time != NULL){

			tc_strcat(buff, curr_time);

			*output_file_name = (char*) MEM_alloc(sizeof(char) * (tc_strlen(buff) + 1));
			tc_strcpy(*output_file_name, buff);

			MEM_free(curr_time);
			curr_time = NULL;
		}
	}

	return retcode;
}

/**
 * Function    :  process_attachments
 * Description :  Function to process the attachments and
 * 				  export the named references.
 *
 * Input       :
 *		root_task - Root task from handler.
 *		args  - Handler arguments.
 *		start - Start pointer of a object link list.
 *
 * Output
 *
 */
int process_attachments(tag_t root_task, arguments_t args, doc_types_t* start){
	int retcode = ITK_ok;
	int tar_attachment_type = EPM_target_attachment;
//	int ref_attachment_type = EPM_reference_attachment;
	int attach_count =0;
	tag_t objTag = NULLTAG;
	tag_t *attachments_tag = NULL;

//    if(tc_strcmp(args.attachment, TARGET) == 0){
//
//    	attachment_type = EPM_target_attachment;
//    }
//    else if(tc_strcmp(args.attachment, REFERENCE) == 0)
//    {
//    	attachment_type = EPM_reference_attachment;
//    }

	ITK(EPM_ask_attachments(root_task, tar_attachment_type, &attach_count, &attachments_tag));
	if (retcode == ITK_ok && attach_count > 0){
		for(int ix=0 ; ix < attach_count && retcode == ITK_ok; ix++){

			objTag = attachments_tag[ix];
			if (objTag != NULLTAG ) {

						char* itemid = NULL;
						ITK(AOM_ask_value_string(objTag, ITEMID, &itemid));
						if (retcode == ITK_ok && itemid != NULL) {
							char* item_id_local = (char*) MEM_alloc(sizeof(char) * (tc_strlen(itemid) + 1));
							tc_strcpy(item_id_local, itemid);
							MEM_free(itemid);
							itemid = NULL;

							char* revid = NULL;
							ITK(AOM_ask_value_string(objTag, REVID, &revid));
							if (retcode == ITK_ok && revid != NULL) {
								char* rev_id_local = (char*) MEM_alloc(sizeof(char) * (tc_strlen(revid) + 1));
								tc_strcpy(rev_id_local, revid);
								MEM_free(revid);
								revid = NULL;

								char* output_file_name = NULL;
								char* output_path = NULL;
								ITK(get_output_file_details(item_id_local, rev_id_local, &output_file_name, &output_path));
								if(retcode == ITK_ok && output_file_name != NULL && output_path != NULL){

                                    char* outputxmlfile = NULL;
                                    char* logfile = NULL;

                                    // 5 chars more to append .xml
                                    outputxmlfile = (char*) MEM_alloc(sizeof(char) * (tc_strlen(output_file_name) + 5));
									tc_strcpy(outputxmlfile, output_file_name);
									tc_strcat(outputxmlfile, ".xml");

									logfile = (char*) MEM_alloc(sizeof(char) * (tc_strlen(output_file_name) + 30));
									tc_strcpy(logfile,"SHAREPOINT_Echanges-");
									tc_strcat(logfile, output_file_name);
									tc_strcat(logfile, ".log");

									char buff_xml_file[1000] = {'\0'};
									char buff_log_file[1000] = {'\0'};

									sprintf_s(buff_xml_file,"%s\\%s",output_path,outputxmlfile);
									sprintf_s(buff_log_file,"%s\\%s",output_path,logfile);

									ITK(create_xml_and_download_files(objTag, buff_xml_file, buff_log_file,args, start, output_path, root_task));

									MEM_free(outputxmlfile);
									outputxmlfile = NULL;

									MEM_free(logfile);
									logfile = NULL;

									MEM_free(output_file_name);
									output_file_name = NULL;

									MEM_free(output_path);
									output_path = NULL;
								}

								MEM_free(rev_id_local);
								rev_id_local = NULL;
							}

							MEM_free(item_id_local);
							item_id_local = NULL;
						}
			}
		}

		MEM_free(attachments_tag);
		attachments_tag = NULL;
	}

	return retcode;
}


/**
 * Function    :  getXMLFile
 * Description :  Get the mapping filename from dataset and prepare path to download
 * 				  mapping file in transient volume directory.
 * Input       :
 *
 * Output
 * 		tranientFilePath - Full path to download mapping file in transient volume
 * 		directory.
 */
int getXMLFile(char** tranientFilePath){
	int retcode = ITK_ok;
	AE_reference_type_t reference_type;

	tag_t dataset_type = NULLTAG;

	ITK(AE_find_datasettype2(XML_DATASET_TYPE, &dataset_type));
	if (retcode == ITK_ok && dataset_type != NULLTAG ) {

		tag_t dataset = NULL;
		ITK(AE_find_dataset2(SP_OBJ_MAP_DATASET_NAME, &dataset));
		if (retcode == ITK_ok && dataset != NULLTAG ) {
			tag_t ds_type = NULLTAG;
			ITK(AE_ask_dataset_datasettype(dataset,&ds_type));
			if (retcode == ITK_ok && ds_type == dataset_type) {

				tag_t referenced_object = NULLTAG;

				ITK(AE_ask_dataset_named_ref2(dataset,XML_NMD_REF_NAME,&reference_type, &referenced_object));
				if (retcode == ITK_ok && referenced_object != NULLTAG ) {
					char *fileName = NULL;
					ITK(IMF_ask_original_file_name2(referenced_object, &fileName));
					if (retcode == ITK_ok && fileName != NULL) {
						char *transientVolRootDir = NULL;
						ITK(IMF_get_transient_volume_root_dir(4, &transientVolRootDir));
						if (retcode == ITK_ok && transientVolRootDir != NULL) {

							*tranientFilePath = (char*) MEM_alloc(sizeof(char) * (tc_strlen(fileName) + tc_strlen(transientVolRootDir) + 5));

							tc_strcpy(*tranientFilePath, transientVolRootDir);
							tc_strcat(*tranientFilePath, "\\");
							tc_strcat(*tranientFilePath, fileName);

							ITK(IMF_fmsfile_export(referenced_object,*tranientFilePath));
							if(retcode == 14100){
								/* If file already exist in directory then read the existing file. */
								retcode = ITK_ok;
							}

							MEM_free(transientVolRootDir);
							transientVolRootDir = NULL;
						}

						MEM_free(fileName);
						fileName = NULL;
					}
				}
			}
		} else {
			TC_write_syslog("\nSEEDS ERROR: Dataset not found....");
		}
	}

	return retcode;
}


/**
 * Function    :  read_map_xml_and_process
 * Description :  Helper function to read mapping file and process the inputs
 * Input       :
 *
 * Output
 *
 */
int read_inputxml_and_process(tag_t roottask, arguments_t args) {

	int retcode = ITK_ok;
	char* tranientFilePath = NULL;

	doc_types_t *start = NULL;
	doc_types_t *rear = NULL;

	ITK(getXMLFile(&tranientFilePath));
	if (retcode == ITK_ok && tranientFilePath != NULL) {

		ITK(parseXml(tranientFilePath, &start, &rear));
		if (retcode == ITK_ok && start != NULL) {

			/**
			 * Delete xml file from transient directory.
			 */
			if (std::remove(tranientFilePath) != 0) {
				TC_write_syslog("\nSEEDS Error: while deleting transient volume file.");
			}

            //clear memory
			MEM_free(tranientFilePath);
			tranientFilePath = NULL;

			/**
			 * Add logic.
			 */
			ITK(process_attachments(roottask, args, start));

			/**
			 * Clear all allocated memory.
			 */
			doc_types_t *tmpnode = NULL;
			while (start != NULL) {

				tmpnode = start;
				start = start->next;

				MEM_free(tmpnode->type_name);
				tmpnode->type_name = NULL;

				MEM_free(tmpnode);
				tmpnode = NULL;
			}

			/* no need to free memory for rear since it has been freed using start pointer above.*/
			rear = NULL;

		}
	}

	return retcode;
}

/**
 * Function    :  getlist
 * Description :  Helper function to get list of arguments of the handler
 * Input       :
 * tokenStr       - Char pointer
 * Output
 * front          - Structure pointer
 */
int getlist(rel_t **front, char* tokenStr){
	int retcode = ITK_ok;
	rel_t *tmpnode = NULL;
	rel_t *rear = NULL;
	char* tokstring = NULL;

	tokstring = NULL;
	tokstring = strtok(tokenStr, ",");
	while (tokstring != NULL) {

		tmpnode = (rel_t*) MEM_alloc(sizeof(rel_t) * 1);
		tmpnode->next = NULL;
		tmpnode->rel_name = (char*) MEM_alloc(sizeof(char) * (tc_strlen(tokstring) + 1));
		tc_strcpy(tmpnode->rel_name, tokstring);

		if(*front == NULL){
			*front = tmpnode;
			rear = tmpnode;
		}else
		{
			rear->next = tmpnode;
			rear = rear->next;
		}

		tokstring = strtok(NULL, ",");
	}

	return retcode;
}

/**
 * Function    :  read_arguments
 * Description :  read handler arguments.
 * Input       :
 * 		msg - message
 *
 * Output
 * 		args - handler arguments
 */
int read_arguments(EPM_action_message_t msg, arguments_t *args) {

	int retcode = ITK_ok;
	int no_args = 0;

	/**
	 * Read arguments
	 */
	no_args = TC_number_of_arguments(msg.arguments);
	if (no_args > 0) {

		char* value = NULL;
		char* flag = NULL;
		//

		for (int indx = 0; indx < no_args && retcode == ITK_ok; indx++) {
			ITK(
					ITK_ask_argument_named_value( TC_next_argument(msg.arguments), &flag, &value ));
			if (retcode == ITK_ok) {
				if (flag != NULL && tc_strcmp(flag, "") != 0 && value != NULL
						&& tc_strcmp(value, "") != 0) {
					//if (tc_strcmp(flag, INCLUDE_TYPE) == 0) {

					//	(*args).include_type = (char*) MEM_alloc(sizeof(char) * (tc_strlen(value) + 1));
					//tc_strcpy((*args).include_type, value);

					//} else if
//					if (tc_strcmp(flag, ATTACHMENT) == 0) {
//
//						(*args).attachment = (char*) MEM_alloc(sizeof(char) * (tc_strlen(value) + 1));
//						tc_strcpy((*args).attachment, value);
//
//					} else if
					if (tc_strcmp(flag, RELATION) == 0) {

						rel_t *front = NULL;
						char* tmpval = (char*) MEM_alloc(
								sizeof(char) * (tc_strlen(value) + 1));
						tc_strcpy(tmpval, value);
						ITK(getlist(&front, tmpval));
						if (front != NULL) {
							(*args).rellist = front;
						}
						MEM_free(tmpval);
						tmpval = NULL;

					} else if (tc_strcmp(flag, ACTION) == 0) {

						(*args).action = (char*) MEM_alloc(
								sizeof(char) * (tc_strlen(value) + 1));
						tc_strcpy((*args).action, value);

					}/*else if (tc_strcmp(flag, DATASET_TYPE) == 0) {

					 tokstring = NULL;
					 tokstring = strtok(value, ",");
					 while (tokstring != NULL) {
					 (*args).dataset_type.push_back(string(tokstring));
					 tokstring = strtok(NULL, ",");
					 }
					 }*/
				} else {
					TC_write_syslog(
							"\nO6SEED - o6_export_for_sharepoint Error: Argument value is missing..");
				}

				MEM_free(flag);
				flag = NULL;

				MEM_free(value);
				value = NULL;
			}
		}
	} else {
		TC_write_syslog(
				"\nSeeds Error: o6_export_for_sharepoint handler arguments are missing.");
	}

	return retcode;
}


/**
 * Function    :  O6_export_data
 * Description :  Wrapper function to export data.
 *
 * Input       :
 *		msg - Handler message
 *
 * Output
 *
 */
int O6_export_data(EPM_action_message_t msg) {

    int retcode = ITK_ok;
    arguments_t args;

   // args.attachment = NULL;
    //args.include_type = NULL;
    args.rellist = NULL;
    args.action = NULL;

    /* read input arguments */
    ITK(read_arguments(msg, &args ));
    if(retcode == ITK_ok){
    	tag_t root_task = NULLTAG;

    	ITK(EPM_ask_root_task(msg.task, &root_task));
    	if(retcode == ITK_ok && root_task != NULLTAG){
    		ITK(read_inputxml_and_process(root_task, args));
    	}
    }

    /* MEM Cleanup */
    rel_t *rear = NULL;
    rel_t *tmpptr = NULL;

    rear = args.rellist;
    while(rear != NULL){
    	tmpptr = rear;
    	rear = rear->next;
    	MEM_free(tmpptr);
    }

    //MEM_free(args.attachment);
    //args.attachment = NULL;

   // MEM_free(args.include_type);
   // args.include_type = NULL;

    MEM_free(args.action);
    args.action = NULL;

	return retcode;
}

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 */
int initialise (void)
{
	int retcode = ITK_ok;

	ITK ( BOM_line_look_up_attribute ( bomAttr_lineItemRevTag, &item_revtag_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_lineItemTag, &item_tag_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemId, &item_id_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemRevName, &item_rev_name_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_realOccurrence, &bl_occ_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemUom, &item_uom_attribute ) );

	/* Custom Attributes */
	ITK ( BOM_line_look_up_attribute ( bomAttr_bl_occ_o6_percent_theoric, &bl_occ_o6_percent_theoric_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_bl_occ_o6_vol_percent_theoric, &bl_occ_o6_vol_percent_theoric_attribute ) );

	return retcode;
}

/**
 * Function    :  CreateBVandBVR
 * Description :  Function to create BOM View and Bom View Rev for an Item
 * Input       :
 * 		 tInputItemTag		     <I>     - Item tag of Item for which BOMView to be Created
 * 		 tInputItemRevTag        <I>     - Item Rev tag of Item for which BVR to be Created
 */
int CreateBVandBVR ( tag_t tInputItemTag, tag_t tInputItemRevTag )
{
	int retcode    = ITK_ok;

	tag_t tBOMViewTag = NULLTAG;

	ITK ( PS_create_bom_view ( NULLTAG, "", "", tInputItemTag, &tBOMViewTag ) );

	if ( retcode == ITK_ok && tBOMViewTag != NULLTAG )
	{
		tag_t tBVR = NULLTAG;

		ITK ( AOM_save_without_extensions ( tBOMViewTag ) );
		ITK ( AOM_save_without_extensions ( tInputItemTag ) );
		ITK ( AOM_unlock ( tInputItemTag ) );

		ITK ( PS_create_bvr ( tBOMViewTag, "", "", false, tInputItemRevTag, &tBVR ) );

		if ( retcode == ITK_ok && tBVR != NULLTAG )
		{
			ITK ( AOM_save_without_extensions ( tBVR ) );
			ITK ( AOM_save_without_extensions ( tInputItemRevTag ) );
			ITK ( AOM_unlock ( tInputItemRevTag ) );
		}
	}
	return retcode;
}

/**
 * Function    :  PopulateDataToStructure
 * Description :  Function to Populate Skipped INCI's data.
 *
 * Input       :
 *
 *      tIngListChildLine      <I>     - BOMLine Tag
 *      sIsAllergenValue       <I>     - String Value
 *      pcApplType             <I>     - Char Pointer
 *		head_ptr               <OF>    - Pointer pointing to the first node of the linked list.
 *
 * Output
 *
 */
int PopulateDataToStructure ( struct SkippedINCIInfo **head_ptr, tag_t tIngListChildLine, string sIsAllergenValue, char* pcApplType, string sINCImpurete )
{
	int retcode = ITK_ok;

	struct SkippedINCIInfo *temp_node = NULL;
	struct SkippedINCIInfo *last      = *head_ptr;

	if ( retcode == ITK_ok )
	{
		char* pcINCPercent = NULL;

		ITK ( BOM_line_ask_attribute_string ( tIngListChildLine, bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

		if ( retcode == ITK_ok )
		{
			char* pcINCItemID = NULL;
			char* pcINCName   = NULL;

			ITK ( BOM_line_ask_attribute_string ( tIngListChildLine, item_id_attribute, &pcINCItemID ) );
			ITK ( BOM_line_ask_attribute_string ( tIngListChildLine, item_rev_name_attribute, &pcINCName ) );

			if ( retcode == ITK_ok )
			{
				temp_node = ( struct SkippedINCIInfo* ) MEM_alloc ( sizeof ( struct SkippedINCIInfo ) );

				temp_node->pcINCIId  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcINCItemID ) + 1 ) );
				tc_strcpy ( temp_node->pcINCIId, pcINCItemID );

				if ( pcINCItemID != NULL )
				{
					MEM_free ( pcINCItemID );
					pcINCItemID = NULL;
				}

				temp_node->pcINCName  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcINCName ) + 1 ) );
				tc_strcpy ( temp_node->pcINCName, pcINCName );

				if ( pcINCName != NULL )
				{
					MEM_free ( pcINCName );
					pcINCName = NULL;
				}

				temp_node->pcImpurete  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( sINCImpurete.c_str() ) + 1 ) );
				tc_strcpy ( temp_node->pcImpurete, sINCImpurete.c_str() );

				temp_node->pcApplType  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcApplType ) + 1 ) );
				tc_strcpy ( temp_node->pcApplType, pcApplType );

				temp_node->pcAllergenValue  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( sIsAllergenValue.c_str() ) + 1 ) );
				tc_strcpy ( temp_node->pcAllergenValue, sIsAllergenValue.c_str() );

				temp_node->dTotalPercentage = atof( pcINCPercent );

				temp_node->next = NULL;

				if ( *head_ptr == NULL )
				{
					*head_ptr = temp_node;
				}
				else
				{
					while ( last->next != NULL )
					{
						last = last->next;
					}
					last->next = temp_node;
				}
			}
		}
		if ( pcINCPercent != NULL )
		{
			MEM_free ( pcINCPercent );
			pcINCPercent = NULL;
		}
	}
	return retcode;
}

/**
 * Function    :  GetAllergenValue
 * Description :  Function to get Allergen Value for ING Revs.
 *
 * Input       :
 * 		 tINCItemRevTag		<I>  - Item Rev Tag
 * 		 isAllergen         <OF> - boolean pointer
 *
 */
int GetAllergenValue ( tag_t tINCItemRevTag, bool &isAllergen )
{
	int retcode                = ITK_ok;
    int iPrimIngRegCount       = 0;

	tag_t tRegulatedRelTag     = NULLTAG;

	tag_t* tPrimIngListRevTags = NULL;

	ITK ( TCTYPE_find_type ( REGULATED_REL, REGULATED_REL, &tRegulatedRelTag ) );

	ITK ( GRM_list_primary_objects_only ( tINCItemRevTag, tRegulatedRelTag, &iPrimIngRegCount, &tPrimIngListRevTags ) );

	if ( retcode == ITK_ok && iPrimIngRegCount != 0 )
	{
		ITK ( AOM_ask_value_logical ( tPrimIngListRevTags[0], O6_ALLERGENE, &isAllergen ) );

		if ( tPrimIngListRevTags != NULL )
		{
			MEM_free ( tPrimIngListRevTags );
			tPrimIngListRevTags = NULL;
		}
	}
	return retcode;
}

/**
 * Function    :  GetFileName
 * Description :  Function to get FileName to be attached to Dataset's Named Reference.
 *
 * Input       :
 * 		 tSecIngListRevTag		<I>  - Item Rev Tag
 * 		 sFileName              <OF> - String pointer
 *
 */
int GetFileName ( tag_t tSecIngListRevTag, string &sFileName )
{
	char* pcSecIngListRevName = NULL;
	char* pcCurrentTime       = NULL;

	int retcode = ITK_ok;

	ITK ( AOM_ask_value_string ( tSecIngListRevTag, OBJECT_NAME, &pcSecIngListRevName ) );

	ITK ( get_time ( &pcCurrentTime ) );

	if ( retcode == ITK_ok && pcCurrentTime != NULL )
	{
		sFileName = string ( pcSecIngListRevName ) + UNDERSCORE + string ( pcCurrentTime ) + CSV_FILE_EXTENSION;
	}

	if ( pcSecIngListRevName != NULL )
	{
		MEM_free ( pcSecIngListRevName );
		pcSecIngListRevName = NULL;
	}
	if ( pcCurrentTime != NULL )
	{
		MEM_free ( pcCurrentTime );
		pcCurrentTime = NULL;
	}
	return retcode;
}

/**
 * Function    :  CreateAndAttachDataset
 * Description :  Function to create and attach dataset.
 *
 * Input       :
 * 		 tSecIngListRevTag		<I>  - Item Rev Tag
 * 		 sINCIReportPath        <I>  - String
 * 		 sFileName              <I>  - String
 *
 */
int CreateAndAttachDataset ( tag_t tSecIngListRevTag, string sINCIReportPath, string sFileName )
{
	int retcode = ITK_ok;

	tag_t tTextDatasetTypeTag  = NULLTAG;

	ITK ( AE_find_datasettype2 ( TEXT_DATASET_TYPE, &tTextDatasetTypeTag ) );

	string sDatasetName = sFileName;
    string sCSVExt = CSV_FILE_EXTENSION;
	int i = sDatasetName.find ( CSV_FILE_EXTENSION );

	sDatasetName.erase ( i, sCSVExt.length() ); // Removing the extension from Dataset Name

	if ( retcode == ITK_ok && tTextDatasetTypeTag != NULLTAG )
	{
		tag_t tTextDatasetTag = NULLTAG;

		ITK ( AE_create_dataset_with_id	( tTextDatasetTypeTag, sDatasetName.c_str(), "", sDatasetName.c_str(), INITIAL_DATASET_REV, &tTextDatasetTag ) );

		if ( retcode == ITK_ok && tTextDatasetTag != NULLTAG )
		{
			tag_t tRelTypeTag  = NULLTAG;
			tag_t tRelationTag = NULLTAG;
			tag_t tToolTag     = NULLTAG;

			ITK ( AE_find_tool2 ( NOTEPAD, &tToolTag ) );
			ITK ( AE_set_dataset_tool ( tTextDatasetTag, tToolTag ) );
			ITK ( AE_set_dataset_format2 ( tTextDatasetTag, TEXT_REFERENCE ) );
			ITK ( AOM_save ( tTextDatasetTag ) );

			ITK ( GRM_find_relation_type ( TC_ATTACHES, &tRelTypeTag ) );
			ITK ( GRM_create_relation ( tSecIngListRevTag, tTextDatasetTag, tRelTypeTag, NULL, &tRelationTag ) );

			if ( retcode == ITK_ok && tRelationTag != NULLTAG )
			{
				IMF_file_t descriptor;

				tag_t tNamedRefFile = NULLTAG;

				ITK ( GRM_save_relation ( tRelationTag ) );
				ITK ( AOM_unload ( tSecIngListRevTag ) );

				ITK ( IMF_fmsfile_import ( sINCIReportPath.c_str() , sFileName.c_str(), SS_TEXT, &tNamedRefFile, &descriptor ) );

				if ( retcode == ITK_ok && tNamedRefFile != NULLTAG )
				{
					ITK ( AOM_refresh ( tTextDatasetTag, TRUE ) );
					ITK ( AE_add_dataset_named_ref ( tTextDatasetTag, TEXT_DATASET_TYPE, AE_PART_OF, tNamedRefFile ) );

					if ( retcode == ITK_ok )
					{
						ITK ( AOM_save ( tTextDatasetTag ) );
						ITK ( AOM_unload ( tNamedRefFile ) );
						ITK ( AOM_unload ( tTextDatasetTag ) );
					}
				}
			}
		}
	}

	return retcode;
}

/**
 * Function    :  FormulateReport
 * Description :  Function to Formulate Report or Copy BOMLines based on bIsSimReqd.
 *
 * Input       :
 * 		 tIngListChildren		<I>  - Tags of BOMLine
 * 		 iIngListChildCount     <I>  - Number of Children
 * 		 tSecIngListRevTag      <I>  - Item Rev Tag
 *
 */
int FormulateReport ( tag_t* tIngListChildren, int iIngListChildCount, tag_t tSecIngListRevTag )
{
    int retcode = ITK_ok;

    char* pcTransientVolDir = NULL;

	ofstream fINCIReport;

	string sFileName         = "";
	string sINCIReportPath   = "";

	struct SkippedINCIInfo *head_ptr = NULL;

	ITK ( IMF_get_transient_volume_root_dir ( 4, &pcTransientVolDir ) );

	if ( retcode == ITK_ok && pcTransientVolDir != NULL )
	{
		ITK ( GetFileName ( tSecIngListRevTag, sFileName ) );

		if ( retcode == ITK_ok && sFileName.compare ( "" ) != 0 )
		{
			string sValue = "";
			sINCIReportPath = string ( pcTransientVolDir ) + "\\" + sFileName;

			if ( pcTransientVolDir != NULL )
			{
				MEM_free ( pcTransientVolDir );
				pcTransientVolDir = NULL;
			}
			fINCIReport.open( sINCIReportPath );

			ITK ( GetLocaleTextValue ( COPIED_INCI_HEADER, sValue ) );

            if ( retcode == ITK_ok && sValue.compare ( "" ) != 0 )
            {
            	fINCIReport<< sValue;
            	sValue = "";
            	fINCIReport << "\n";
            	ITK ( GetLocaleTextValue ( INCI_BOM_REPORT_HEADER, sValue ) );

            	if ( retcode == ITK_ok && sValue.compare ( "" ) != 0 )
            	{
            		fINCIReport << sValue;
            	}
            }
		}
	}

	for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
	{
		bool bIsImpurete = false;

		tag_t tOccurenceTag = NULLTAG;

		ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

		ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

		if ( retcode == ITK_ok )
		{
			bool isAllergen = false;

			char* pcApplType = NULL;

			tag_t tINCItemRevTag = NULLTAG;

			ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

			if ( retcode == ITK_ok )
			{
				ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

				if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
				{
					/*Getting Allergen value of Ingredient*/
					ITK ( GetAllergenValue ( tINCItemRevTag, isAllergen ) );

					if ( retcode == ITK_ok )
					{
						/*Writing to Report only if Ingredient is Pure*/
						if ( bIsImpurete == false )
						{
							char* pcINCPercent = NULL;

							ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

							/*Check if Ingredient's Allergen value is True*/
							if ( isAllergen == true )
							{
								/*Check if Application Type is Rince*/
								if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
								{
									/*Writing to Report only if Application Type is Rince and content >= 0.01*/
									if ( atof ( pcINCPercent ) >= 0.01 )
									{
										char* pcINCID      = NULL;
										char* pcINCRevName = NULL;

										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_id_attribute, &pcINCID ) );
										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_rev_name_attribute, &pcINCRevName ) );

										fINCIReport<<"\n" + string ( pcINCID ) + COMMA_SYMBOL + string ( pcINCRevName ) + COMMA_SYMBOL + TRUE_VALUE + COMMA_SYMBOL + string ( pcApplType ) + COMMA_SYMBOL + string ( pcINCPercent );

										if ( pcINCID != NULL )
										{
											MEM_free ( pcINCID );
											pcINCID = NULL;
										}
										if ( pcINCRevName != NULL )
										{
											MEM_free ( pcINCRevName );
											pcINCRevName = NULL;
										}
									}
									/*Populating Skipped INCI entries if Application Type is Rince and content < 0.01*/
									else
									{
										ITK ( PopulateDataToStructure ( &head_ptr, tIngListChildren[iInx], TRUE_VALUE, pcApplType, FALSE_VALUE ) );
									}
								}
								else
								{
									/*Writing to Report only if Application Type is Non Rince value and content >= 0.001*/
									if ( atof ( pcINCPercent ) >= 0.001 )
									{
										char* pcINCID      = NULL;
										char* pcINCRevName = NULL;

										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_id_attribute, &pcINCID ) );
										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_rev_name_attribute, &pcINCRevName ) );

										fINCIReport<<"\n" + string ( pcINCID ) + COMMA_SYMBOL + string ( pcINCRevName ) + COMMA_SYMBOL + TRUE_VALUE + COMMA_SYMBOL + string ( pcApplType ) + COMMA_SYMBOL + string ( pcINCPercent );

										if ( pcINCID != NULL )
										{
											MEM_free ( pcINCID );
											pcINCID = NULL;
										}
										if ( pcINCRevName != NULL )
										{
											MEM_free ( pcINCRevName );
											pcINCRevName = NULL;
										}
									}
									/*Populating Skipped INCI entries if Application Type is Non Rince value and content < 0.001*/
									else
									{
										ITK ( PopulateDataToStructure ( &head_ptr, tIngListChildren[iInx], TRUE_VALUE, pcApplType, FALSE_VALUE ) );
									}
								}
								if ( pcINCPercent != NULL )
								{
									MEM_free ( pcINCPercent );
									pcINCPercent = NULL;
								}
							}
							/*Check if Ingredient's Allergen value is False*/
							else
							{
								char* pcINCID      = NULL;
								char* pcINCRevName = NULL;

								ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_id_attribute, &pcINCID ) );
								ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_rev_name_attribute, &pcINCRevName ) );

								fINCIReport<<"\n" + string ( pcINCID ) + COMMA_SYMBOL + string ( pcINCRevName ) + COMMA_SYMBOL + FALSE_VALUE + COMMA_SYMBOL + string ( pcApplType ) + COMMA_SYMBOL + string ( pcINCPercent );

								if ( pcINCID != NULL )
								{
									MEM_free ( pcINCID );
									pcINCID = NULL;
								}
								if ( pcINCRevName != NULL )
								{
									MEM_free ( pcINCRevName );
									pcINCRevName = NULL;
								}
							}
							if ( pcINCPercent != NULL )
							{
								MEM_free ( pcINCPercent );
								pcINCPercent = NULL;
							}
						}
						/*Populating Impure INCI's ID entries*/
						else
						{
							if ( isAllergen == true )
							{
								ITK ( PopulateDataToStructure ( &head_ptr, tIngListChildren[iInx], TRUE_VALUE, pcApplType, TRUE_VALUE ) );
							}
							else
							{
								ITK ( PopulateDataToStructure ( &head_ptr, tIngListChildren[iInx], FALSE_VALUE, pcApplType, TRUE_VALUE ) );
							}
						}
					}
				}
			}
			if ( pcApplType != NULL )
			{
				MEM_free ( pcApplType );
				pcApplType = NULL;
			}
		}
	}

	/*Writing Skipped INCI's to Report*/
	if ( head_ptr != NULL )
	{
		string sSkippedHeader = "";
		string sBOMHeader     = "";
		string sImpureHeader  = "";


		fINCIReport<<"\n\n\n\n";

		ITK ( GetLocaleTextValue ( SKIPPED_INCI_HEADER, sSkippedHeader ) );
		fINCIReport<<sSkippedHeader;

		fINCIReport<<"\n";

		ITK ( GetLocaleTextValue ( INCI_BOM_REPORT_HEADER, sBOMHeader ) );
		fINCIReport<<sBOMHeader;


		SkippedINCIInfo *temp = new SkippedINCIInfo;
		temp = head_ptr;

		while ( temp != NULL)
		{
			if ( ( tc_strcmp ( temp->pcImpurete, FALSE_VALUE ) == 0 ) )
			{
				string sINCName = ( temp->pcINCName == NULL ) ? "" : string ( temp->pcINCName );

				fINCIReport <<  "\n" + string ( temp->pcINCIId ) + COMMA_SYMBOL + sINCName + COMMA_SYMBOL + string ( temp->pcAllergenValue ) + COMMA_SYMBOL + string ( temp->pcApplType ) + COMMA_SYMBOL + to_string ( temp->dTotalPercentage );
			}
			temp=temp->next;
		}

		fINCIReport << "\n\n\n\n";

		temp = head_ptr;
		ITK ( GetLocaleTextValue ( IMPURE_INCI_HEADER, sImpureHeader ) );
		fINCIReport<<sImpureHeader;

		fINCIReport << "\n";

		fINCIReport << sBOMHeader;

		while ( temp != NULL)
		{
			if ( ( tc_strcmp ( temp->pcImpurete, TRUE_VALUE ) == 0 ) )
			{
				string sINCName = ( temp->pcINCName == NULL ) ? "" : string ( temp->pcINCName );

				fINCIReport <<  "\n" + string ( temp->pcINCIId ) + COMMA_SYMBOL + sINCName + COMMA_SYMBOL + string ( temp->pcAllergenValue ) + COMMA_SYMBOL + string ( temp->pcApplType ) + COMMA_SYMBOL + to_string ( temp->dTotalPercentage );
			}
			temp=temp->next;
		}

	}

	fINCIReport.close();

	ITK ( CreateAndAttachDataset ( tSecIngListRevTag, sINCIReportPath, sFileName ) );

	if ( retcode == ITK_ok )
	{
		remove ( sINCIReportPath.c_str() );
	}

	/*Memory Cleanup*/
	if ( head_ptr != NULL )
	{
		struct SkippedINCIInfo *tmp_ptr = NULL;
		do
		{
			tmp_ptr = head_ptr->next;

			if ( head_ptr->pcINCIId != NULL )
			{
				MEM_free ( head_ptr->pcINCIId );
				head_ptr->pcINCIId = NULL;
			}
			if ( head_ptr->pcINCName != NULL )
			{
				MEM_free ( head_ptr->pcINCName );
				head_ptr->pcINCName = NULL;
			}
			if ( head_ptr->pcAllergenValue != NULL )
			{
				MEM_free ( head_ptr->pcAllergenValue );
				head_ptr->pcAllergenValue = NULL;
			}
			if ( head_ptr->pcApplType != NULL )
			{
				MEM_free ( head_ptr->pcApplType );
				head_ptr->pcApplType = NULL;
			}
            if ( head_ptr->pcImpurete != NULL )
            {
            	MEM_free ( head_ptr->pcImpurete );
            	head_ptr->pcImpurete = NULL;
            }

			head_ptr->next = NULL;

			MEM_free ( head_ptr );

			head_ptr = tmp_ptr;

		} while ( head_ptr != NULL );
	}
	return retcode;
}

/**
 * Function    :  CreateSecIngBOM
 * Description :  Function to Formulate Report or Copy BOMLines based on bIsSimReqd.
 *
 * Input       :
 * 		 tIngListChildren		<I>  - Tags of BOMLine
 * 		 iIngListChildCount     <I>  - Number of Children
 * 		 tSecIngListRevTag      <I>  - Item Rev Tag
 * 		 bIsSimReqd             <I>  - Boolean Value
 *
 */
int CreateSecIngBOM ( tag_t* tIngListChildren, int iIngListChildCount, tag_t tSecIngListRevTag, bool bIsSimReqd )
{
	int retcode = ITK_ok;
	int iSecIngBVRCount = 0;

	tag_t* tSecBVRTags  = NULL;

	ITK ( AOM_ask_value_tags ( tSecIngListRevTag, STRUCTURE_REVISIONS, &iSecIngBVRCount ,&tSecBVRTags ) );

	if ( tSecBVRTags != NULL )
	{
		MEM_free ( tSecBVRTags );
		tSecBVRTags = NULL;
	}

	ITK ( initialise () );

	if ( bIsSimReqd == true )
	{
		if ( iSecIngBVRCount == 0 )
		{
			/*Formulating Report if Simulation value is True*/
			ITK ( FormulateReport ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
		}
		else
		{
			int iIngChildCount        = 0;

			tag_t tSecIngBOMWindowTag = NULLTAG;
			tag_t tSecIngBOMTopline   = NULLTAG;

			tag_t* tIngChildLines     = NULL;

			ITK ( BOM_create_window ( &tSecIngBOMWindowTag ) );
			ITK ( BOM_set_window_top_line ( tSecIngBOMWindowTag, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngBOMTopline ) );
			ITK ( BOM_line_ask_all_child_lines ( tSecIngBOMTopline, &iIngChildCount, &tIngChildLines ) );

			if ( retcode == ITK_ok && iIngChildCount == 0 )
			{
				/*Formulating Report if Simulation value is True*/
				ITK ( FormulateReport ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}
			else
			{
				for ( int iInx = 0; iInx < iIngChildCount; iInx++ )
				{
					ITK ( BOM_line_cut ( tIngChildLines[iInx] ) );
					BOM_save_window ( tSecIngBOMWindowTag );
				}
				/*Formulating Report if Simulation value is True*/
				ITK ( FormulateReport ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}

			if ( tIngChildLines != NULL )
			{
				MEM_free ( tIngChildLines );
				tIngChildLines = NULL;
			}
		}
	}
	else
	{
		/*Create BOM, if no BOM present earlier under Quali Quanti Object*/
		if ( iSecIngBVRCount == 0 )
		{
			tag_t tSecIngListItemTag = NULLTAG;

			ITK ( ITEM_ask_item_of_rev ( tSecIngListRevTag, &tSecIngListItemTag ) );

			if ( retcode == ITK_ok && tSecIngListItemTag != NULLTAG )
			{
				ITK ( CreateBVandBVR ( tSecIngListItemTag, tSecIngListRevTag ) );

				if ( retcode == ITK_ok )
				{
					tag_t tSecIngBOMWindow   = NULLTAG;
					tag_t tSecIngListTopLine = NULLTAG;

					ITK ( BOM_create_window ( &tSecIngBOMWindow ) );

					ITK ( BOM_set_window_top_line ( tSecIngBOMWindow, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngListTopLine ) );

					for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
					{
						bool bIsImpurete = false;

						tag_t tOccurenceTag = NULLTAG;

						ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

						ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

						if ( retcode == ITK_ok )
						{
							/*If Ingredient is Pure*/
							if ( bIsImpurete == false )
							{
								tag_t tINCItemRevTag = NULLTAG;
								tag_t tNewLineTag    = NULLTAG;

								ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

								if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
								{
									bool isAllergen = false;

									/*Getting Allergen Value of Ingredient*/
									ITK ( GetAllergenValue ( tINCItemRevTag, isAllergen ) );

									if ( retcode == ITK_ok )
									{
										char* pcApplType = NULL;

										ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

										if ( retcode == ITK_ok )
										{
											/*If Allergen value of Ingredient is True*/
											if ( isAllergen == true )
											{
												char* pcINCPercent = NULL;

												ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

												/*If Application Type Is RINCE*/
												if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
												{
													/* If Application Type is RINCE and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.01 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												/*If Application Type is any value other than Rince*/
												else
												{
													/* If Application Type is Non Rince and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.001 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												if ( pcINCPercent != NULL )
												{
													MEM_free ( pcINCPercent );
													pcINCPercent = NULL;
												}
											}
											/*If Ingredient's Allergen Value is False, Copy the BOMLine */
											else
											{
												ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
											}
										}
										if ( pcApplType != NULL )
										{
											MEM_free ( pcApplType );
											pcApplType = NULL;
										}
									}
								}
							}
						}
					}
					ITK ( BOM_save_window ( tSecIngBOMWindow ) );
					ITK ( BOM_close_window ( tSecIngBOMWindow ) );
				}
			}
			/*Once BOM attached, Formulate report*/
			ITK ( FormulateReport ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
		}
		else
		{
			int iIngChildCount        = 0;

			tag_t tSecIngBOMWindowTag = NULLTAG;
			tag_t tSecIngBOMTopline   = NULLTAG;

			tag_t* tIngChildLines     = NULL;

			ITK ( BOM_create_window ( &tSecIngBOMWindowTag ) );
			ITK ( BOM_set_window_top_line ( tSecIngBOMWindowTag, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngBOMTopline ) );
			ITK ( BOM_line_ask_all_child_lines ( tSecIngBOMTopline, &iIngChildCount, &tIngChildLines ) );

			if ( retcode == ITK_ok && iIngChildCount == 0 )
			{
				tag_t tSecIngListItemTag = NULLTAG;

				ITK ( ITEM_ask_item_of_rev ( tSecIngListRevTag, &tSecIngListItemTag ) );

				if ( retcode == ITK_ok && tSecIngListItemTag != NULLTAG )
				{
					tag_t tSecIngBOMWindow   = NULLTAG;
					tag_t tSecIngListTopLine = NULLTAG;

					ITK ( BOM_create_window ( &tSecIngBOMWindow ) );

					ITK ( BOM_set_window_top_line ( tSecIngBOMWindow, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngListTopLine ) );

					for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
					{
						bool bIsImpurete = false;

						tag_t tOccurenceTag = NULLTAG;

						ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

						ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

						if ( retcode == ITK_ok )
						{
							/*If Ingredient is Pure*/
							if ( bIsImpurete == false )
							{
								tag_t tINCItemRevTag = NULLTAG;
								tag_t tNewLineTag    = NULLTAG;

								ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

								if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
								{
									bool isAllergen = false;

									/*Getting Allergen Value of Ingredient*/
									ITK ( GetAllergenValue ( tINCItemRevTag, isAllergen ) );

									if ( retcode == ITK_ok )
									{
										char* pcApplType = NULL;

										ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

										if ( retcode == ITK_ok )
										{
											/*If Allergen value of Ingredient is True*/
											if ( isAllergen == true )
											{
												char* pcINCPercent = NULL;

												ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

												/*If Application Type Is RINCE*/
												if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
												{
													/* If Application Type is RINCE and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.01 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												/*If Application Type is any value other than Rince*/
												else
												{
													/* If Application Type is Non Rince and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.001 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												if ( pcINCPercent != NULL )
												{
													MEM_free ( pcINCPercent );
													pcINCPercent = NULL;
												}
											}
											/*If Ingredient's Allergen Value is False, Copy the BOMLine */
											else
											{
												ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
											}
										}
										if ( pcApplType != NULL )
										{
											MEM_free ( pcApplType );
											pcApplType = NULL;
										}
									}
								}
							}
						}
					}
					ITK ( BOM_save_window ( tSecIngBOMWindow ) );
					ITK ( BOM_close_window ( tSecIngBOMWindow ) );
				}
				/*Once BOM attached, Formulate report*/
				ITK ( FormulateReport ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}
			else
			{
				tag_t tSecIngListItemTag = NULLTAG;

				for ( int iInx = 0; iInx < iIngChildCount; iInx++ )
				{
					ITK ( BOM_line_cut ( tIngChildLines[iInx] ) );
					BOM_save_window ( tSecIngBOMWindowTag );
				}

				ITK ( ITEM_ask_item_of_rev ( tSecIngListRevTag, &tSecIngListItemTag ) );

				if ( retcode == ITK_ok && tSecIngListItemTag != NULLTAG )
				{
					tag_t tSecIngBOMWindow   = NULLTAG;
					tag_t tSecIngListTopLine = NULLTAG;

					ITK ( BOM_create_window ( &tSecIngBOMWindow ) );

					ITK ( BOM_set_window_top_line ( tSecIngBOMWindow, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngListTopLine ) );

					for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
					{
						bool bIsImpurete = false;

						tag_t tOccurenceTag = NULLTAG;

						ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

						ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

						if ( retcode == ITK_ok )
						{
							/*If Ingredient is Pure*/
							if ( bIsImpurete == false )
							{
								tag_t tINCItemRevTag = NULLTAG;
								tag_t tNewLineTag    = NULLTAG;

								ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

								if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
								{
									bool isAllergen = false;

									/*Getting Allergen Value of Ingredient*/
									ITK ( GetAllergenValue ( tINCItemRevTag, isAllergen ) );

									if ( retcode == ITK_ok )
									{
										char* pcApplType = NULL;

										ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

										if ( retcode == ITK_ok )
										{
											/*If Allergen value of Ingredient is True*/
											if ( isAllergen == true )
											{
												char* pcINCPercent = NULL;

												ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

												/*If Application Type Is RINCE*/
												if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
												{
													/* If Application Type is RINCE and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.01 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												/*If Application Type is any value other than Rince*/
												else
												{
													/* If Application Type is Non Rince and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.001 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												if ( pcINCPercent != NULL )
												{
													MEM_free ( pcINCPercent );
													pcINCPercent = NULL;
												}
											}
											/*If Ingredient's Allergen Value is False, Copy the BOMLine */
											else
											{
												ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
											}
										}
										if ( pcApplType != NULL )
										{
											MEM_free ( pcApplType );
											pcApplType = NULL;
										}
									}
								}
							}
						}
					}
					ITK ( BOM_save_window ( tSecIngBOMWindow ) );
					ITK ( BOM_close_window ( tSecIngBOMWindow ) );
				}
				/*Once BOM attached, Formulate report*/
				ITK ( FormulateReport ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}
			if ( tIngChildLines != NULL )
			{
				MEM_free ( tIngChildLines );
				tIngChildLines = NULL;
			}

		}
	}
	return retcode;
}

/**
 * Function    :  o6_quali_quanti_calc
 * Description :  Wrapper function to do Quali Quanti Calculations data.
 *
 * Input       :
 *		msg - Handler message
 *
 * Output
 *
 */
int o6_quali_quanti_calc ( EPM_action_message_t msg )
{
	int retcode               = ITK_ok;

	tag_t tRootTask           = NULLTAG;

	ITK ( EPM_ask_root_task ( msg.task, &tRootTask ) );

	if ( retcode == ITK_ok && tRootTask != NULLTAG )
	{
		int iTargetCount           = 0;

        tag_t tINGListClassID      = NULLTAG;

		tag_t* tTargetAttachments = NULL;

		ITK ( EPM_ask_attachments ( tRootTask, EPM_target_attachment, &iTargetCount, &tTargetAttachments ) );

		ITK ( POM_class_id_of_class	( INGLIST_REV_TYPE, &tINGListClassID ) );

		if ( retcode == ITK_ok && iTargetCount != 0 )
		{
			tag_t tTargetINGListRevTag = NULLTAG;

			for ( int iInx = 0; iInx < iTargetCount; iInx++ )
			{
				tag_t tTargetClassID = NULLTAG;

				ITK ( POM_class_of_instance	( tTargetAttachments[iInx], &tTargetClassID ) );

				if ( tTargetClassID == tINGListClassID )
				{
					tTargetINGListRevTag = tTargetAttachments[iInx];
					break;
				}
			}

			if ( tTargetAttachments != NULL )
			{
				MEM_free ( tTargetAttachments );
				tTargetAttachments = NULL;
			}

			if ( tTargetINGListRevTag != NULLTAG )
			{
				tag_t tQualiQuantiRelTag = NULLTAG;

				ITK ( TCTYPE_find_type ( QUALI_QUANTI_REL, QUALI_QUANTI_REL, &tQualiQuantiRelTag ) );

				if ( retcode == ITK_ok && tQualiQuantiRelTag != NULLTAG )
				{
					int iPFRegDossRevCount   = 0;

					tag_t* tPFRegDossRevTags = NULL;

					ITK ( GRM_list_secondary_objects_only ( tTargetINGListRevTag, tQualiQuantiRelTag, &iPFRegDossRevCount, &tPFRegDossRevTags ) );

					if ( retcode == ITK_ok && iPFRegDossRevCount != 0 )
					{
						int iPFBVRCount           = 0;

						tag_t tTargetPFItemRevTag = NULLTAG;

						tag_t* tPFBVRTags         = NULL;

						tTargetPFItemRevTag = tPFRegDossRevTags[0];

						if ( tPFRegDossRevTags != NULL )
						{
							MEM_free ( tPFRegDossRevTags );
							tPFRegDossRevTags = NULL;
						}

						ITK ( AOM_ask_value_tags ( tTargetPFItemRevTag, STRUCTURE_REVISIONS, &iPFBVRCount, &tPFBVRTags ) );

						if ( tPFBVRTags != NULL )
						{
							MEM_free ( tPFBVRTags );
							tPFBVRTags = NULL;
						}

						if ( retcode == ITK_ok && iPFBVRCount != 0 )
						{
							int iFPChildCount     = 0;

							tag_t tPFBOMWindowTag = NULLTAG;
							tag_t tFPBOMTopLine   = NULLTAG;

							tag_t* tFPChildren    = NULL;

							ITK ( BOM_create_window ( &tPFBOMWindowTag ) );
							ITK ( BOM_set_window_top_line ( tPFBOMWindowTag, NULLTAG, tTargetPFItemRevTag, NULLTAG, &tFPBOMTopLine ) );
							ITK ( BOM_line_ask_all_child_lines ( tFPBOMTopLine, &iFPChildCount, &tFPChildren ) );

							if ( retcode == ITK_ok && iFPChildCount != 0 )
							{
								int iIngListChildCount = 0;

								tag_t* tIngListChildren = NULL;

								ITK ( BOM_set_window_pack_all ( tPFBOMWindowTag, false ) );
								ITK ( BOM_line_ask_all_child_lines ( tFPChildren[0], &iIngListChildCount, &tIngListChildren ) );

								if ( retcode == ITK_ok && iIngListChildCount != 0 )
								{
									bool bIsSimReqd = false;

									ITK ( AOM_ask_value_logical ( tTargetINGListRevTag, O6_SIMULATION, &bIsSimReqd ) );

									if ( retcode == ITK_ok )
									{
										ITK ( CreateSecIngBOM ( tIngListChildren, iIngListChildCount, tTargetINGListRevTag, bIsSimReqd ) ); // Formulate Report or Copy BOMLines based on bIsSimReqd
									}
								}
								if ( tIngListChildren != NULL )
								{
									MEM_free ( tIngListChildren );
									tIngListChildren = NULL;
								}
							}

							ITK ( BOM_close_window ( tPFBOMWindowTag ) );

							if ( tFPChildren != NULL )
							{
								MEM_free ( tFPChildren );
								tFPChildren = NULL;
							}
						}
					}
				}
			}
		}
	}
	return retcode;
}
