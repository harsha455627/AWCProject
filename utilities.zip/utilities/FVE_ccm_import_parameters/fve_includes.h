/******************************************************************************
 * Filename        :   fve_includes.h
 * Description     :   Defines the macro used in fve_import_parameters.c
 * Module          :   fve_import_parameters.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * 03-Apr-2012    Swapnal Shewale	      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_INCLUDES_H
#define FVE_INCLUDES_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef WIN32 
  #define stricmp strcasecmp 
  #define strnicmp strncasecmp 
#endif

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/

#include <ctype.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <tc/iman.h>
#include <fclasses/iman_stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h> 
	
#include <textsrv/textserver.h>	
#include <tc/emh_const.h>
#include <property/prop_errors.h>
#include <property/propdesc.h>
#include <epm/epm.h>
#include <itk/bmf.h>
#include <tc/tc.h>
#include <cfm/cfm.h>
#include <pom/enq/enq.h>
#include <tc/preferences.h>
#include <itk/mem.h>
#include <tccore/tctype.h>
#include <tccore/grmtype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/iman_msg.h>
#include <tccore/item_msg.h>
#include <tccore/tc_msg.h>	
#include <tccore/method.h>	
#include <tccore/license.h>
#include <errno.h>
#include <sa/tcvolume.h>
#include <ae/ae.h>
#include <ae/vm_errors.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#include <lov/lov.h>
#include <sa/tcfile.h>
#include <ctype.h>
#include <sa/sa.h>
#include <ae/shell_util.h>
#include <sa/user.h>
#include <ps/ps_tokens.h>
#include <tc/folder.h>
#include <rdv/arch.h>
#include <constants/constants.h>
#include <bom/bom.h>
#include <res/res_itk.h>
#include <epm/releasestatus.h>
#include <epm/cr.h>
#include <tccore/workspaceobject.h> 	
#include <tc/tc_macros.h>
#include <form/form.h>
#include <tccore/grm.h>
#include <ps/ps.h>
#include <me/me.h>
#include <fclasses/tc_date.h>
#include <tc/tc_util.h>

#ifdef __cplusplus
}
#endif

#endif
