/*===============================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
=================================================================================
File description:

    Filename: FV_import_baseparts.c
    Module  : main

    Used to import the base part numbers for ECU.
    Requires a login account specified by -u=<user> -p=<pass> -g=<group>.


	Assumptions:
	1. Run Exe with -u=infodba -p=infodba -g=dba -file=filename
	2. Default delimeter "|" will be considered for parsing csv files.Make sure csv file contains this parameter.
	
	Below is the sample format of the input file that is needed
	|PartBase|Class|PartDesc|Status|ECUAcronym|PartSubType
	|14C036|Strategy Part|SFTW IVD CONTR STRGY|ACTIVE|ABS|ANTI-LOCK BRAKE SYSTEM (ABS) CONTROL MODULE
	|14C037|Calibration Part|SFTW IVD CONTR CAL|ACTIVE|ABS|ANTI-LOCK BRAKE SYSTEM (ABS) CONTROL MODULE
	|14C328|Strategy Part|SFTW STRGY RECV DSC PLYR W AMPL|ACTIVE|ACM|AUDIO FRONT CONTROL MODULE
	|000000|ECU Hardware Part|NO NAME|INACTIVE||REAR ENTERTAINMENT CONTROL MODULE
	|10849|PartII Specification|CLUS ASY INSTR|ACTIVE
	3. log file will be created with name "FV_import_baseparts" on time stamp basis where utility is executed.
	
===============================================================================
Date               Name                    Description of Change
2016               Vinay Deshmukh          Initial Version.
===============================================================================*/

#include <fclasses/tc_stat.h>
#include "FV_import_baseparts.h"


/*--------------------------Function Prototypes-------------------------------*/


static void print_usage(void);


FILE *logfileptr = NULL;

FILE *summary_file_ptr = NULL;
/*-------------------------------End------------------------------------------*/

extern int ITK_user_main(int retCount, char **retValue)
{

	FILE *fileptr             = NULL;

	char line_in[2047 + 1]    = "";
	char line_temp[2047 + 1]  = "";
	const char * filename     = NULL;
	const char * mode         = "r";
	char * ptr				  = NULL;
	char logfilename[255 + 1] = "";

	char * group			  = NULL;
	char * user				  = NULL;
	char * password			  = NULL;
	char * time_stamp         = NULL;
	int   ifail               = ITK_ok;
	int   len                 = 0;
	int line_count            = 0;
	int array_cnt             = 0;

	char **PartBase_array     = NULL;
	char **PartClass_array    = NULL;
	char **PartStatus_array   = NULL;
	char **ECUAcronym_array   = NULL;
	char **PartDesc_array     = NULL;
	char **PartSubType_array  = NULL;


    //Get the time stamp.
	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"FV_import_baseparts_errors_%s.log",time_stamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
		FVE_FREE(time_stamp)
        exit(1);
    }

    printf("\n Error information will be written into %s\n\n",logfilename);

	if(logfileptr)
    {
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
		fprintf(logfileptr,"-----------------\n", time_stamp);
		FVE_FREE(time_stamp)
    }
     
	if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

	user = ITK_ask_cli_argument("-u=");
	password = ITK_ask_cli_argument("-p=");
	group = ITK_ask_cli_argument("-g=");
	filename = ITK_ask_cli_argument("-file=");

    ITK_initialize_text_services(0);

	if ( user != NULL && strlen(user)!=0  &&  password != NULL && strlen(password)!=0 &&  group != NULL && strlen(group)!=0)
	{
      ITK(ITK_init_module( user,password,group));
      if(ifail != ITK_ok)
	  {
         fprintf(logfileptr,"Login with uid: %s, group:%s is unsuccessful\n", user, group);  
	  }
	}
	else
	{      
      ITK (ITK_auto_login())
      if(ifail != ITK_ok)
	  {
         fprintf(logfileptr,"Auto Login unsuccessful\n");
	  }
	}  

	/* Check input arguments */
    if (!filename)
    {
        print_usage();
        return !ITK_ok ;
    }

	printf("filename is %s\n", filename);
    fileptr = fopen (filename, mode);
	if ( fileptr != NULL )
    {
		line_count = 0;
        while (fgets(line_in, 2048, fileptr) != 0)
        {
			line_count++;
			len = (int) strlen(line_in);
            if (len > 0 && line_in[len-1] == '\n')
                line_in[len-1] = '\0';
            if ( strlen(  line_in ) == 0 )
                continue;

            if(line_count == 1)
			 continue;
            tc_strcpy( line_temp, line_in);
			array_cnt ++;
			
            ptr = tc_strtok(line_temp, DELIMITER);
			if(tc_strlen(ptr) == 0)
				ptr = tc_strtok(NULL, DELIMITER);
			FV_get_value_and_store(ptr, array_cnt, &PartBase_array);

			ptr = tc_strtok(NULL, DELIMITER);
			FV_get_value_and_store(ptr, array_cnt, &PartClass_array);

			ptr = tc_strtok(NULL, DELIMITER);
			FV_get_value_and_store(ptr, array_cnt, &PartDesc_array);

			ptr = tc_strtok(NULL, DELIMITER);
			FV_get_value_and_store(ptr, array_cnt, &PartStatus_array);

			ptr = tc_strtok(NULL, DELIMITER);
			FV_get_value_and_store(ptr, array_cnt, &ECUAcronym_array);

			ptr = tc_strtok(NULL, DELIMITER);
			FV_get_value_and_store(ptr, array_cnt, &PartSubType_array);
        }

		//Get the time stamp.
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		fprintf(logfileptr,"\nInput file parsing is completed successfully %s \n\n",time_stamp);
		fprintf(logfileptr,"--------------------------------------------------------------- \n",time_stamp);

        //Function for creating the workspace objects.
	    ITK(FV_create_workspace_objects(PartBase_array,PartClass_array,PartDesc_array,PartStatus_array,ECUAcronym_array,array_cnt))
	
		FVE_FREE_ARRAY(PartBase_array, array_cnt)
		FVE_FREE_ARRAY(PartClass_array, array_cnt)
		FVE_FREE_ARRAY(PartDesc_array, array_cnt)
        FVE_FREE_ARRAY(PartStatus_array, array_cnt)
		FVE_FREE_ARRAY(ECUAcronym_array, array_cnt)
		FVE_FREE_ARRAY(PartSubType_array, array_cnt)
	}
	else
	{
		printf("\nCould not open %s file for reading\n", filename);
	}

    ITK_exit_module( true );

	fprintf(logfileptr,"\n\n\n------------------------------------------------------------");
	fprintf(logfileptr,"\n\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	printf("Utility Completed successfully");
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
	FVE_FREE(time_stamp)

    if (logfileptr )
	{
		fclose( logfileptr);
	}

    if (fileptr )
	{
		fclose( fileptr);
	}

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


/*--------------------------------------------------------------------------*/

static void print_usage(void)
{		printf(" This program is intended to import the base part numbers for ECU.\n\n");
        printf("\n******************************************************************************\n");
        printf("Usage: FV_import_baseparts <args>\n\n");
        printf(" Where args include the following:\n\n");
		printf(" -u=<login user id>\n");
		printf(" -p=<login password>\n");
		printf(" -g=<login group>\n");
		printf(" -file=<filename>  input file to import base part numbers\n\n\n");
        printf("Each record in the file contains the following in the order specified:\nPart Base, Part Class, Part Desc, Status, ECU Acronym, Part Sub Type\n");
        printf("\n\n");
        printf(" -h=<any value> for usage help\n");
		printf("\n");
        printf("******************************************************************************\n\n");
}

//Function for read value from file and store it.
void FV_get_value_and_store(char * init_value, int cnt, char *** str_array)
{
	(*str_array) = (char **) MEM_realloc ((*str_array), (int) cnt * sizeof(char *));

	if(tc_strcmp(init_value, "") != 0)
	{
		(*str_array)[cnt -1] = (char *) MEM_alloc ((int) (tc_strlen(init_value) + 1) * sizeof(char));
		tc_strcpy((*str_array)[cnt -1], init_value);
	}
	else
	{ 
		(*str_array)[cnt -1] = NULL;
	}
}

//Function For creating Objects.
int FV_create_workspace_objects(char **PartBase_array,char **PartClass_array,char **PartDesc_array,char **PartStatus_array,char **ECUAcronym_array,int num_column)
{

		int ifail                        = ITK_ok;

		tag_t target_type_tag            = NULLTAG;
		tag_t target_obj_tag             = NULLTAG;
		tag_t createInputTag             = NULLTAG;
		tag_t ecuRev_class_id			 = NULLTAG;
		tag_t object_id_class            = NULLTAG;
		tag_t partnum					 = NULLTAG;
		tag_t partclass		             = NULLTAG;
		tag_t enqid1                     = NULLTAG;
		tag_t enqid2                     = NULLTAG;
		tag_t enqid3                     = NULLTAG;
		tag_t enqid4                     = NULLTAG;
		tag_t enqid5                     = NULLTAG;
		tag_t *tag_revs                  = NULL;
		tag_t *ecu_tag_revs				 = NULL;

		char *time_stamp                 = NULL;
		char summarylogfilename[255 + 1] = "";
		char *ecu_string				 = NULL;

		int no_cnt                       = 0;
		int counter_first                = 0;
		int line_number                  = 0;
		int summary_counter              = 0;
		//int success_line_counter         = 0;
		char *not_valid_class[2]  	     = {"ECU Assembly", "Core Assembly Part"};
		int invalid_class_count			 = 2;
		logical isClassValid			 = FALSE;
		int success_count				 = 0;


		//Error log file.
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		sprintf(summarylogfilename,"FV_import_baseparts_summary_%s.log",time_stamp);

		summary_file_ptr = fopen( summarylogfilename, "w+");
		if (summary_file_ptr == NULL)
		{
			fprintf(stderr, "\nERROR: Can not create log file : %s", summarylogfilename);
			FVE_FREE(time_stamp)
		}
		printf("\nSummary information will be written into %s\n\n",summarylogfilename);

		if(summary_file_ptr)
		{
			fprintf(summary_file_ptr,"Start time: %s\n\n", time_stamp);
			fprintf(summary_file_ptr,"-----------------------------\n", time_stamp);
			FVE_FREE(time_stamp)
		}
	     
		//Find the type tag of the given ECU.
		ITK(TCTYPE_find_type(FV9ECUBasePartNumberTYPE,NULL,&target_type_tag))
		if (ifail != ITK_ok)
		{
			fprintf(logfileptr,"\n\nError: Unable to find the tag of %s type", FV9ECUBasePartNumberTYPE);
		    ifail = ITK_ok;
		}

		for(counter_first=0;counter_first<num_column;counter_first++)
		{
			// There has to be an ECU and it cannot be NULL.
			if(ECUAcronym_array[counter_first] == NULL)
			{
				continue;
			}

			line_number++;

			fprintf(summary_file_ptr,"\n Processing started for line number %d \t",line_number);
			fprintf(summary_file_ptr,"Class being processed is %s",PartClass_array[counter_first]);

			// Base parts for �ECU Assembly� or �Core Assembly� will not be imported
			if(PartClass_array[counter_first] != NULL)  
			{
				int count = 0;
				for (count = 0; count < invalid_class_count; count++)
				{
					if(tc_strcmp(PartClass_array[counter_first],not_valid_class[count])==0) 
					{
						isClassValid = TRUE;
						break;
					}
				}
				if (isClassValid)
				{
					fprintf(logfileptr,"\n\nLine %d - Invalid class %s is not being processed", line_number, PartClass_array[counter_first]);
					isClassValid = FALSE;
					continue;
				}
			}

			//Create the pom enquiry to check whether the object exist in teamcenter or not.
			ITK(POM_class_id_of_class(FVE_ECURevisionTYPE, &ecuRev_class_id))

			//Get the object name
			ITK(POM_attr_id_of_attr("FVE_ECUAcronym",FVE_ECURevisionTYPE, &object_id_class))  
			ITK(POM_create_enquiry_on_string(ecuRev_class_id, object_id_class, POM_is_equal_to, &(ECUAcronym_array[counter_first]), &enqid1))
			ITK(POM_execute_enquiry(enqid1, &no_cnt, &ecu_tag_revs))
	
			// verify if the ECU is already created or not
			if(ecu_tag_revs == NULLTAG)
			{
				 fprintf(logfileptr,"\n\n%s Object does not exists in Teamcenter", ECUAcronym_array[counter_first]);
				 ifail = ITK_ok; 
				 continue;
			}


			// All the below are mandatory for creation of ECU Base part number list, 
			// but Status is not mandatory while checking for existence of the object 
			if( (ECUAcronym_array[counter_first] != NULL) && 
				     (PartBase_array[counter_first] != NULL) && 
							(PartClass_array[counter_first] != NULL) &&
								(PartStatus_array[counter_first] != NULL))
			{
				 //Create the pom enquiry to check whether the object exist in teamcenter or not.
				 ITK(POM_class_id_of_class(FV9ECUBasePartNumberTYPE, &ecuRev_class_id))

				 //Get the object name
				 ITK(POM_attr_id_of_attr("object_name",FV9ECUBasePartNumberTYPE, &object_id_class))  
				 ITK(POM_create_enquiry_on_string(ecuRev_class_id, object_id_class, POM_is_equal_to, &(ECUAcronym_array[counter_first]), &enqid1))

				 // Get the part number
				 ITK(POM_attr_id_of_attr("fv9BasePartNumber",FV9ECUBasePartNumberTYPE, &partnum))
				 ITK(POM_create_enquiry_on_string(ecuRev_class_id, partnum, POM_is_equal_to, &(PartBase_array[counter_first]), &enqid2))

				 // Get the part class
				 ITK(POM_attr_id_of_attr("fv9PartClass",FV9ECUBasePartNumberTYPE, &partclass))
				 ITK(POM_create_enquiry_on_string(ecuRev_class_id, partclass, POM_is_equal_to, &(PartClass_array[counter_first]), &enqid3))

				 // Verify if Obj name, part number and part class combination exists already. combine the enquires
				 ITK(POM_combine_enquiries(enqid1, POM_and, enqid2, &enqid4))
				 ITK(POM_combine_enquiries(enqid4, POM_and, enqid3, &enqid5))

				 ITK(POM_execute_enquiry(enqid5, &no_cnt, &tag_revs))
			}
			else
			{
				fprintf(logfileptr,"\n\nLine %d - One OR All of the Mandatory Data (ECU Acronym, Part base, Part Class) is missing",line_number);
				continue;
			}
			   
			if(tag_revs != NULL)
			{
				 fprintf(logfileptr,"\n\nLine %d - %s-%s-%s-%s already exists in Teamcenter", line_number, ECUAcronym_array[counter_first],
					 PartBase_array[counter_first],PartClass_array[counter_first],PartStatus_array[counter_first]);
				 ifail = ITK_ok; 
				 continue;
			}
			else
			{
				//Get the create input tag for creating the target busniss object.
				ITK(TCTYPE_construct_create_input(target_type_tag,&createInputTag))

				//set name.
				ITK(TCTYPE_set_create_display_value(createInputTag, "object_name", 1, (const char**)&ECUAcronym_array[counter_first]))

				ITK(AOM_tag_to_string(*ecu_tag_revs,&ecu_string))
				ITK(TCTYPE_set_create_display_value(createInputTag, "fv9ECURef", 1, (const char**)&ecu_string))
				
				//set base part number.
			    ITK(TCTYPE_set_create_display_value(createInputTag, "fv9BasePartNumber", 1, (const char**)&(PartBase_array[counter_first])))

				//set base part class.
			    ITK(TCTYPE_set_create_display_value(createInputTag, "fv9PartClass", 1, (const char**)&(PartClass_array[counter_first])))

				//set Status. we already checked for it's existence while querying for the object, thus no need to check for existence of value here
			    ITK(TCTYPE_set_create_display_value(createInputTag, "FV_PicklistStatus", 1, (const char**)&(PartStatus_array[counter_first])))

				//For the creation of objects.
				ITK(TCTYPE_create_object(createInputTag,&target_obj_tag))
				if( ifail != ITK_ok)
				{
					fprintf(logfileptr,"\n\nLine %d - Check correctness of values for %s-%s-%s-%s",line_number, ECUAcronym_array[counter_first], 
						PartBase_array[counter_first],PartClass_array[counter_first], PartStatus_array[counter_first]);
					ifail = ITK_ok;
					summary_counter++;
					continue;
				}
				ITK( AOM_save_with_extensions(target_obj_tag))
				if (ifail == ITK_ok)
				{
					fprintf(summary_file_ptr,"\n\nProcessing %s-%s-%s-%s completed", ECUAcronym_array[counter_first], 
						PartBase_array[counter_first],PartClass_array[counter_first], PartStatus_array[counter_first]);
					success_count++;
				}

				//set part description, if provided in the csv file.
				if ( PartDesc_array[counter_first] != NULL )
				{
					if(FVDT_check_property_exists(target_obj_tag, "FV_PicklistDesc") == 0)
					{
						ITK(AOM_set_value_string(target_obj_tag, "FV_PicklistDesc", PartDesc_array[counter_first]))
						ITK(AOM_save(target_obj_tag))
					}
					else 
					{
						fprintf(logfileptr,"\n\nError:Property %s does not exists on this picklist",PartDesc_array[counter_first]);
					}

					if (ifail != ITK_ok)
				    {
					   fprintf(summary_file_ptr,"\nProcessing for Part Desc = %s  have some error pl check error log file for line number %d", PartDesc_array[counter_first],line_number);
					   fprintf(logfileptr,"\nLine %d - Error encountered",line_number);
					   fprintf(logfileptr,"\nError:Unable to set value %s on property object_desc",PartDesc_array[counter_first]);
					   ifail = ITK_ok;
					   summary_counter++;
				    }
				}
			}

			fprintf(summary_file_ptr,"\n\nProcessing ends for line number %d",line_number);
		}

		//Get the timestamp value.
        get_time_stamp(DATE_FORMAT_STR, &time_stamp);
        
        fprintf(summary_file_ptr,"\n=======================");
        fprintf(summary_file_ptr,"\nSummary");
        fprintf(summary_file_ptr,"\nTotal number of lines processed is %d",line_number);
		fprintf(summary_file_ptr,"\nSuccessful count is %d",success_count);
		fprintf(summary_file_ptr,"\nfailure count is %d",line_number-success_count);
		fprintf(summary_file_ptr,"\n=======================");

		FVE_FREE(tag_revs)
		FVE_FREE(ecu_tag_revs)

		if (summary_file_ptr) 
		{
			fclose(summary_file_ptr);
		}

 return ifail;
 }

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = (byte) newTime->tm_mon;
	currentTime.year = (short) newTime->tm_year + 1900;
	currentTime.day = (byte) newTime->tm_mday;
	currentTime.hour = (byte) newTime->tm_hour;
	currentTime.minute = (byte) newTime->tm_min;
	currentTime.second = (byte) newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}
