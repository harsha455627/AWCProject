/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
 
package com.o6.services.loose.customservicelibrary;

import java.util.List;


import com.teamcenter.soa.client.Connection;
import com.teamcenter.soa.internal.client.Sender;
import com.teamcenter.soa.internal.client.model.PopulateModel;

 /**
  * @unpublished
  */
@SuppressWarnings("unchecked")
public class O6TaneCustomServiceRestBindingStub extends O6TaneCustomServiceService
{
    private Sender              restSender;
    private PopulateModel       modelManager;
    private Connection          localConnection;
    
    /**
     * Constructor
     * @param connection
     * @unpublished
     */
    public O6TaneCustomServiceRestBindingStub( Connection connection )
    {
        this.localConnection = connection;
        this.restSender  = connection.getSender();
        this.modelManager= (PopulateModel)this.localConnection.getModelManager();
        
    }

    static com.teamcenter.schemas.soa._2006_03.base.ObjectFactory base_Factory = new 
           com.teamcenter.schemas.soa._2006_03.base.ObjectFactory();

    // each child interface has its own factory and methods for calling


    static com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.ObjectFactory O6TaneCustomService_201706Factory = new 
           com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.ObjectFactory();
    static final String O6TANECUSTOMSERVICE_201706_PORT_NAME          = "CustomServiceLibrary-2017-06-O6TaneCustomService";
    static final String O6TANECUSTOMSERVICE_201706_CONTEXT_PATH = "com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice:com.o6.schemas.customservicelibrary._2017_11.o6tanecustomservice:com.o6.schemas.customservicelibrary._2017_12.o6tanecustomservice:com.teamcenter.schemas.soa._2006_03.base";

    /**
     * @param local
     * @return wire
     * @unpublished 
     */
    public  static com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.TargetObjecs toWire( com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService.TargetObjecs local ) 
    {
 		com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.TargetObjecs wire = null;
     	wire = O6TaneCustomService_201706Factory.createTargetObjecs();

         List wireInDisplaynames = wire.getDisplaynames();// VECTOR_TO_WIRE 
         for (int i = 0; i < local.displaynames.length; i ++ )
         {
                   wireInDisplaynames.add((new String(local.displaynames[i]))); //OTHER_BASIC_ELEMENT_IN_VECTOR_TO_WIRE 

         }
         List wireInRealnames = wire.getRealnames();// VECTOR_TO_WIRE 
         for (int i = 0; i < local.realnames.length; i ++ )
         {
                   wireInRealnames.add((new String(local.realnames[i]))); //OTHER_BASIC_ELEMENT_IN_VECTOR_TO_WIRE 

         }
         List wireInNrPattern = wire.getNrPattern();// VECTOR_TO_WIRE 
         for (int i = 0; i < local.nrPattern.length; i ++ )
         {
                   wireInNrPattern.add((new String(local.nrPattern[i]))); //OTHER_BASIC_ELEMENT_IN_VECTOR_TO_WIRE 

         }

		return wire;
	}
    /**
     * @param wire
     * @param modelManager
     * @return local
     * @unpublished 
     */
    public  static com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService.TargetObjecs toLocal( com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.TargetObjecs  wire , com.teamcenter.soa.internal.client.model.PopulateModel modelManager ) 
 		
    {
  		com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService.TargetObjecs local = new com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService.TargetObjecs();

      List wireDisplaynames = wire.getDisplaynames();// VECTOR_TO_LOCAL
      local.displaynames = new String[wireDisplaynames.size()];
      for (int i = 0; i < wireDisplaynames.size(); i ++ )
      {
                  local.displaynames[i] = (new String (wireDisplaynames.get(i).toString())).toString(); //OTHER_BASIC_ELEMENT_IN_VECTOR_TO_LOCAL

      }
      List wireRealnames = wire.getRealnames();// VECTOR_TO_LOCAL
      local.realnames = new String[wireRealnames.size()];
      for (int i = 0; i < wireRealnames.size(); i ++ )
      {
                  local.realnames[i] = (new String (wireRealnames.get(i).toString())).toString(); //OTHER_BASIC_ELEMENT_IN_VECTOR_TO_LOCAL

      }
      List wireNrPattern = wire.getNrPattern();// VECTOR_TO_LOCAL
      local.nrPattern = new String[wireNrPattern.size()];
      for (int i = 0; i < wireNrPattern.size(); i ++ )
      {
                  local.nrPattern[i] = (new String (wireNrPattern.get(i).toString())).toString(); //OTHER_BASIC_ELEMENT_IN_VECTOR_TO_LOCAL

      }


		return local;
	}
	
    @Override 
    public com.teamcenter.soa.client.model.ServiceData calculateINCIs( com.teamcenter.soa.client.model.ModelObject obj ) 
    
    {
       try
       {
        restSender.pushRequestId();
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateINCIs");
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateINCIs.localToWire");
		com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.CalculateINCIsInput wireIn = null;
        wireIn = O6TaneCustomService_201706Factory.createCalculateINCIsInput();
        com.teamcenter.schemas.soa._2006_03.base.ModelObject objWireIn = null; //WIRE_CREATE
        objWireIn = base_Factory.createModelObject();
        if(obj == null)  // MODEL_OBJECT_ELEMENT_TO_WIRE
             objWireIn.setUid( com.teamcenter.soa.client.model.ModelObject.NULL_ID );
        else
             objWireIn.setUid(obj.getUid());
        wireIn.setObj( objWireIn );

        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateINCIs.localToWire");

        Object outObj = restSender.invoke2( O6TANECUSTOMSERVICE_201706_PORT_NAME, "calculateINCIs", wireIn, 
                        O6TANECUSTOMSERVICE_201706_CONTEXT_PATH, O6TANECUSTOMSERVICE_201706_CONTEXT_PATH);
		modelManager.lockModel();
		

        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateINCIs.wireToLocal");

        com.teamcenter.schemas.soa._2006_03.base.ServiceData wireOut = 
       (com.teamcenter.schemas.soa._2006_03.base.ServiceData)outObj;
        com.teamcenter.soa.client.model.ServiceData localOut;
        
        localOut =  modelManager.loadServiceData( wireOut ); // SERVICEDATA_RETURN

        if(!localConnection.getOption(Connection.OPT_CACHE_MODEL_OBJECTS).equals( "true" ))
      	{
        	localConnection.getClientDataModel().removeAllObjects(); 
        }
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateINCIs.wireToLocal");
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateINCIs");
         return localOut;
       }
       finally
       {
        restSender.popRequestId();
        modelManager.unlockModel();
       }
    }
	
    @Override 
    public com.teamcenter.soa.client.model.ServiceData copyObjectAndCreateRelation( com.teamcenter.soa.client.model.ModelObject obj, String targetItemtype ) 
    
    {
       try
       {
        restSender.pushRequestId();
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation");
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.localToWire");
		com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.CopyObjectAndCreateRelationInput wireIn = null;
        wireIn = O6TaneCustomService_201706Factory.createCopyObjectAndCreateRelationInput();
        com.teamcenter.schemas.soa._2006_03.base.ModelObject objWireIn = null; //WIRE_CREATE
        objWireIn = base_Factory.createModelObject();
        if(obj == null)  // MODEL_OBJECT_ELEMENT_TO_WIRE
             objWireIn.setUid( com.teamcenter.soa.client.model.ModelObject.NULL_ID );
        else
             objWireIn.setUid(obj.getUid());
        wireIn.setObj( objWireIn );
        wireIn.setTargetItemtype( targetItemtype ); //BASIC_ELEMENT_TO_WIRE

        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.localToWire");

        Object outObj = restSender.invoke2( O6TANECUSTOMSERVICE_201706_PORT_NAME, "copyObjectAndCreateRelation", wireIn, 
                        O6TANECUSTOMSERVICE_201706_CONTEXT_PATH, O6TANECUSTOMSERVICE_201706_CONTEXT_PATH);
		modelManager.lockModel();
		

        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.wireToLocal");

        com.teamcenter.schemas.soa._2006_03.base.ServiceData wireOut = 
       (com.teamcenter.schemas.soa._2006_03.base.ServiceData)outObj;
        com.teamcenter.soa.client.model.ServiceData localOut;
        
        localOut =  modelManager.loadServiceData( wireOut ); // SERVICEDATA_RETURN

        if(!localConnection.getOption(Connection.OPT_CACHE_MODEL_OBJECTS).equals( "true" ))
      	{
        	localConnection.getClientDataModel().removeAllObjects(); 
        }
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.wireToLocal");
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation");
         return localOut;
       }
       finally
       {
        restSender.popRequestId();
        modelManager.unlockModel();
       }
    }
	
    @Override 
    public com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService.TargetObjecs getTargets( com.teamcenter.soa.client.model.ModelObject obj ) 
    
    {
       try
       {
        restSender.pushRequestId();
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.getTargets");
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.getTargets.localToWire");
		com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.GetTargetsInput wireIn = null;
        wireIn = O6TaneCustomService_201706Factory.createGetTargetsInput();
        com.teamcenter.schemas.soa._2006_03.base.ModelObject objWireIn = null; //WIRE_CREATE
        objWireIn = base_Factory.createModelObject();
        if(obj == null)  // MODEL_OBJECT_ELEMENT_TO_WIRE
             objWireIn.setUid( com.teamcenter.soa.client.model.ModelObject.NULL_ID );
        else
             objWireIn.setUid(obj.getUid());
        wireIn.setObj( objWireIn );

        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.getTargets.localToWire");

        Object outObj = restSender.invoke2( O6TANECUSTOMSERVICE_201706_PORT_NAME, "getTargets", wireIn, 
                        O6TANECUSTOMSERVICE_201706_CONTEXT_PATH, O6TANECUSTOMSERVICE_201706_CONTEXT_PATH);
		modelManager.lockModel();
		

        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.getTargets.wireToLocal");

        com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.TargetObjecs wireOut = 
       (com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice.TargetObjecs)outObj;
        com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService.TargetObjecs localOut;
        
        localOut =  toLocal( wireOut,modelManager ); // STRUCT_RETURN

        if(!localConnection.getOption(Connection.OPT_CACHE_MODEL_OBJECTS).equals( "true" ))
      	{
        	localConnection.getClientDataModel().removeAllObjects(); 
        }
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.getTargets.wireToLocal");
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.getTargets");
         return localOut;
       }
       finally
       {
        restSender.popRequestId();
        modelManager.unlockModel();
       }
    }

    static com.o6.schemas.customservicelibrary._2017_11.o6tanecustomservice.ObjectFactory O6TaneCustomService_201711Factory = new 
           com.o6.schemas.customservicelibrary._2017_11.o6tanecustomservice.ObjectFactory();
    static final String O6TANECUSTOMSERVICE_201711_PORT_NAME          = "CustomServiceLibrary-2017-11-O6TaneCustomService";
    static final String O6TANECUSTOMSERVICE_201711_CONTEXT_PATH = "com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice:com.o6.schemas.customservicelibrary._2017_11.o6tanecustomservice:com.o6.schemas.customservicelibrary._2017_12.o6tanecustomservice:com.teamcenter.schemas.soa._2006_03.base";
	
    @Override 
    public com.teamcenter.soa.client.model.ServiceData copyObjectAndCreateRelation( com.teamcenter.soa.client.model.ModelObject obj, String targetItemtype, String targetItemPattern, String targetItemVersion ) 
    
    {
       try
       {
        restSender.pushRequestId();
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation");
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.localToWire");
		com.o6.schemas.customservicelibrary._2017_11.o6tanecustomservice.CopyObjectAndCreateRelationInput wireIn = null;
        wireIn = O6TaneCustomService_201711Factory.createCopyObjectAndCreateRelationInput();
        com.teamcenter.schemas.soa._2006_03.base.ModelObject objWireIn = null; //WIRE_CREATE
        objWireIn = base_Factory.createModelObject();
        if(obj == null)  // MODEL_OBJECT_ELEMENT_TO_WIRE
             objWireIn.setUid( com.teamcenter.soa.client.model.ModelObject.NULL_ID );
        else
             objWireIn.setUid(obj.getUid());
        wireIn.setObj( objWireIn );
        wireIn.setTargetItemtype( targetItemtype ); //BASIC_ELEMENT_TO_WIRE
        wireIn.setTargetItemPattern( targetItemPattern ); //BASIC_ELEMENT_TO_WIRE
        wireIn.setTargetItemVersion( targetItemVersion ); //BASIC_ELEMENT_TO_WIRE

        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.localToWire");

        Object outObj = restSender.invoke2( O6TANECUSTOMSERVICE_201711_PORT_NAME, "copyObjectAndCreateRelation", wireIn, 
                        O6TANECUSTOMSERVICE_201711_CONTEXT_PATH, O6TANECUSTOMSERVICE_201711_CONTEXT_PATH);
		modelManager.lockModel();
		

        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.wireToLocal");

        com.teamcenter.schemas.soa._2006_03.base.ServiceData wireOut = 
       (com.teamcenter.schemas.soa._2006_03.base.ServiceData)outObj;
        com.teamcenter.soa.client.model.ServiceData localOut;
        
        localOut =  modelManager.loadServiceData( wireOut ); // SERVICEDATA_RETURN

        if(!localConnection.getOption(Connection.OPT_CACHE_MODEL_OBJECTS).equals( "true" ))
      	{
        	localConnection.getClientDataModel().removeAllObjects(); 
        }
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation.wireToLocal");
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.copyObjectAndCreateRelation");
         return localOut;
       }
       finally
       {
        restSender.popRequestId();
        modelManager.unlockModel();
       }
    }

    static com.o6.schemas.customservicelibrary._2017_12.o6tanecustomservice.ObjectFactory O6TaneCustomService_201712Factory = new 
           com.o6.schemas.customservicelibrary._2017_12.o6tanecustomservice.ObjectFactory();
    static final String O6TANECUSTOMSERVICE_201712_PORT_NAME          = "CustomServiceLibrary-2017-12-O6TaneCustomService";
    static final String O6TANECUSTOMSERVICE_201712_CONTEXT_PATH = "com.o6.schemas.customservicelibrary._2017_06.o6tanecustomservice:com.o6.schemas.customservicelibrary._2017_11.o6tanecustomservice:com.o6.schemas.customservicelibrary._2017_12.o6tanecustomservice:com.teamcenter.schemas.soa._2006_03.base";
	
    @Override 
    public com.teamcenter.soa.client.model.ServiceData calculateQSP( com.teamcenter.soa.client.model.ModelObject obj ) 
    
    {
       try
       {
        restSender.pushRequestId();
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateQSP");
        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateQSP.localToWire");
		com.o6.schemas.customservicelibrary._2017_12.o6tanecustomservice.CalculateQSPInput wireIn = null;
        wireIn = O6TaneCustomService_201712Factory.createCalculateQSPInput();
        com.teamcenter.schemas.soa._2006_03.base.ModelObject objWireIn = null; //WIRE_CREATE
        objWireIn = base_Factory.createModelObject();
        if(obj == null)  // MODEL_OBJECT_ELEMENT_TO_WIRE
             objWireIn.setUid( com.teamcenter.soa.client.model.ModelObject.NULL_ID );
        else
             objWireIn.setUid(obj.getUid());
        wireIn.setObj( objWireIn );

        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateQSP.localToWire");

        Object outObj = restSender.invoke2( O6TANECUSTOMSERVICE_201712_PORT_NAME, "calculateQSP", wireIn, 
                        O6TANECUSTOMSERVICE_201712_CONTEXT_PATH, O6TANECUSTOMSERVICE_201712_CONTEXT_PATH);
		modelManager.lockModel();
		

        com.teamcenter.soa.internal.common.Monitor.markStart("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateQSP.wireToLocal");

        com.teamcenter.schemas.soa._2006_03.base.ServiceData wireOut = 
       (com.teamcenter.schemas.soa._2006_03.base.ServiceData)outObj;
        com.teamcenter.soa.client.model.ServiceData localOut;
        
        localOut =  modelManager.loadServiceData( wireOut ); // SERVICEDATA_RETURN

        if(!localConnection.getOption(Connection.OPT_CACHE_MODEL_OBJECTS).equals( "true" ))
      	{
        	localConnection.getClientDataModel().removeAllObjects(); 
        }
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateQSP.wireToLocal");
        com.teamcenter.soa.internal.common.Monitor.markEnd  ("com.o6.services.loose.customservicelibrary.O6TaneCustomServiceRestBindingStub.calculateQSP");
         return localOut;
       }
       finally
       {
        restSender.popRequestId();
        modelManager.unlockModel();
       }
    }


}
