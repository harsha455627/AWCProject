//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6CreateRMRegDossBOM
 *
 */
#include <O6TaneCustomLibrary/O6CreateRMRegDossBOM.hxx>

#define LISTE_NAME_PREFIX "INGList-"
#define RM_DRG_PREFIX "DRG-"
#define INGLIST_REVISION "O6_IngListRevision"
#define INGLIST "O6_IngList"
#define OBJECT_NAME "object_name"
#define REVISION "revision"
#define STRUCT_REVISIONS "structure_revisions"

/**
 * Function    :  AttachItemRevToBVR
 * Description :  Function to add Item Rev to BOM
 * Input       :
 * 		 tFPBOMWindowTag		     <I>     - Target BVR BOM Window
 * 		 targetbomline               <I>     - Target BOMLine
 * 		 itemtag                     <I>     - Item Tag of Item to be added to Bomline
 * 		 itemrevtag                  <I>     - Item Rev Tag of the Item
 */
int AttachItemRevToBVR ( tag_t tMPRegBOMWindow, tag_t targetbomline, tag_t itemtag, tag_t itemrevtag )
{
	int retcode    = ITK_ok;

	tag_t new_line = NULLTAG;

	ITK ( BOM_line_add ( targetbomline, itemtag, itemrevtag, NULLTAG, &new_line ) );

	if ( retcode == ITK_ok && new_line != NULLTAG )
	{
	    ITK ( BOM_save_window ( tMPRegBOMWindow ) );
	}
	return retcode;
}

/**
 * Function    :  CreateIngItem
 * Description :  Function to create Liste d Ingredient Item
 * Input       :
 * 		 tItemTag		     <O>     - Item tag of Item Created
 */
int CreateIngItem ( tag_t *tItemTag, string sRMRegDossId )
{
	int retcode               = ITK_ok;

	tag_t tRevTypeTag         = NULLTAG;
	tag_t tRevCreateInputTag  = NULLTAG;

	ITK ( TCTYPE_find_type ( INGLIST_REVISION, NULL, &tRevTypeTag ) );
	ITK ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) );

	if ( retcode == ITK_ok && tRevCreateInputTag != NULLTAG )
	{
		tag_t tItemTypeTag        = NULLTAG;
		tag_t tItemCreateInputTag = NULLTAG;

		ITK ( TCTYPE_find_type ( INGLIST, NULL, &tItemTypeTag ) );
		ITK ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) );

		if ( retcode == ITK_ok && tItemCreateInputTag != NULLTAG )
		{
			string sObjectName = LISTE_NAME_PREFIX + sRMRegDossId;

			ITK ( AOM_set_value_string ( tItemCreateInputTag, OBJECT_NAME, sObjectName.c_str() ) );
			ITK ( AOM_set_value_tag ( tItemCreateInputTag, REVISION, tRevCreateInputTag ) );

			ITK ( TCTYPE_create_object ( tItemCreateInputTag, tItemTag ) );

			if ( retcode == ITK_ok && tItemTag != NULLTAG )
			{
				ITK ( AOM_save_without_extensions ( *tItemTag ) );
				ITK ( AOM_unlock ( *tItemTag ) );
			}
		}
	}
	return retcode;
}

int CheckRMRegDossBVR ( tag_t tRMRegDossRev, int &iRMBOMCount )
{
	int retcode       = ITK_ok;

	tag_t* tRMBOMTags = NULL;

	ITK ( AOM_ask_value_tags ( tRMRegDossRev, STRUCT_REVISIONS, &iRMBOMCount, &tRMBOMTags ) );

	if ( tRMBOMTags != NULL )
	{
		MEM_free ( tRMBOMTags );
		tRMBOMTags = NULL;
	}
	return retcode;
}

int O6CreateRMRegDossBOM( METHOD_message_t * msg, va_list args )
{
	int retcode     = ITK_ok;

	int iRMBOMCount = 0;

	va_list largs;
	va_copy( largs, args );
	va_end( largs );

	tag_t tRMRegDossRev  = NULLTAG;
	tag_t tRMRegDossItem = NULLTAG;

	tRMRegDossRev = msg->object_tag;

	ITK ( ITEM_ask_item_of_rev ( tRMRegDossRev, &tRMRegDossItem ) );
	if ( retcode == ITK_ok && tRMRegDossItem != NULLTAG )
	{
		ITK ( CheckRMRegDossBVR ( tRMRegDossRev, iRMBOMCount ) );

		if ( iRMBOMCount == 0 )
		{
			ITK ( CreateBVandBVR ( tRMRegDossItem, tRMRegDossRev ) );

			if ( retcode == ITK_ok )
			{
				tag_t tMPRegBOMWindow = NULLTAG;
				tag_t tMPBOMTopLine   = NULLTAG;

				ITK ( BOM_create_window ( &tMPRegBOMWindow ) );
				ITK ( BOM_set_window_top_line ( tMPRegBOMWindow, NULLTAG, tRMRegDossRev, NULLTAG, &tMPBOMTopLine ) );

				if ( retcode == ITK_ok && tMPBOMTopLine != NULLTAG )
				{
					char* pcRMRegDossId = NULL;

					ITK ( ITEM_ask_id2 ( tRMRegDossItem, &pcRMRegDossId ) );

					if ( retcode == ITK_ok && pcRMRegDossId != NULL )
					{
						tag_t tIngListItem = NULLTAG;

						string sRMRegDossId = string ( pcRMRegDossId );

						string sPrefix = RM_DRG_PREFIX;

						std::string::size_type i = sRMRegDossId.find ( sPrefix );

						if ( i != std::string::npos )
						{
							sRMRegDossId.erase(i, sPrefix.length());
						}

						ITK ( CreateIngItem ( &tIngListItem, sRMRegDossId ) );

						if ( retcode == ITK_ok && tIngListItem != NULLTAG )
						{
							tag_t tIngListRev = NULLTAG;

							ITK ( ITEM_ask_latest_rev ( tIngListItem, &tIngListRev ) );
							if ( retcode == ITK_ok && tIngListRev != NULLTAG )
							{
								ITK ( AttachItemRevToBVR ( tMPRegBOMWindow, tMPBOMTopLine, tIngListItem, tIngListRev ) );
							}
						}
					}
					if ( pcRMRegDossId != NULL )
					{
						MEM_free ( pcRMRegDossId );
						pcRMRegDossId = NULL;
					}
				}
				ITK ( BOM_close_window ( tMPRegBOMWindow ) );
			}
		}
		else
		{
			tag_t tRMBOMWindowTag = NULLTAG;
			tag_t tTopLine        = NULLTAG;

			ITK ( BOM_create_window ( &tRMBOMWindowTag ) );
			ITK ( BOM_set_window_pack_all ( tRMBOMWindowTag, false ) );
			ITK ( BOM_set_window_top_line ( tRMBOMWindowTag, NULLTAG, tRMRegDossRev, NULLTAG, &tTopLine ) );

			if ( retcode == ITK_ok && tTopLine != NULLTAG )
			{
				int iIngListCount = 0;

				tag_t* tIngListLines = NULL;

				ITK ( BOM_line_ask_all_child_lines ( tTopLine, &iIngListCount, &tIngListLines ) );

				if ( iIngListCount == 0 )
				{
					char* pcRMRegDossId = NULL;

					ITK ( ITEM_ask_id2 ( tRMRegDossItem, &pcRMRegDossId ) );

					if ( retcode == ITK_ok && pcRMRegDossId != NULL )
					{
						tag_t tIngListItem = NULLTAG;

						string sRMRegDossId = string ( pcRMRegDossId );

						string sPrefix = RM_DRG_PREFIX;

						std::string::size_type i = sRMRegDossId.find ( sPrefix );

						if ( i != std::string::npos )
						{
							sRMRegDossId.erase(i, sPrefix.length());
						}

						ITK ( CreateIngItem ( &tIngListItem, sRMRegDossId ) );

						if ( retcode == ITK_ok && tIngListItem != NULLTAG )
						{
							tag_t tIngListRev = NULLTAG;

							ITK ( ITEM_ask_latest_rev ( tIngListItem, &tIngListRev ) );
							if ( retcode == ITK_ok && tIngListRev != NULLTAG )
							{
								ITK ( AttachItemRevToBVR ( tRMBOMWindowTag, tTopLine, tIngListItem, tIngListRev ) );
							}
						}
					}
					if ( pcRMRegDossId != NULL )
					{
						MEM_free ( pcRMRegDossId );
						pcRMRegDossId = NULL;
					}

				ITK ( BOM_close_window ( tRMBOMWindowTag ) );
				}
			}
		}
	}
	return retcode;
}
