/******************************************************************************
 * Filename         :   fve_import_parameter_values.c
 * Utility to import parameters from csv file.
 *
 * To maintain the log file related information like  log file name , path and extension ,some constant values
   Configuration file with name "FVE_ccm_config.txt" should exist where utility is executed.
   if this configuration file does not exist ,
                                    1.log file will be created with executable name on time stamp basis where utility is executed.
									2.Default delimeter "||" will be considered for parsing csv files.Make sure csv file contains this parameter.
   if this configuration file exist ,it should specify log file related information ,delimeter used for csv file parsing & ..


 *
 *Utility Arguments
 *				-u=
                -p=
				-g=
				-topNodeId
				-revId
				-parmvalfile=
				-varExpMapfile=


 *Assumption :
	parameter_values.csv file should contains following columns.
	*NameOfData (Parameter)	Rev ID	Value	Value (name)	VariantCondition

	variant_condition_expression.csv file should contains following columns
	*VariantCondition Expression  VariantCondition Name

	Note :
	Through parameter_values.csv file its not clear ,
		How to get the values for multiple rows and multiple columns ?<csv file should provide delimiter as semicolon in such case>
		e.g. Values are provided in below format
		1.DEFAULT   -->it means  one row and one column
		2.{CONTINUOUS_ONLY, CONTINUOUS_ONLY, CONTINUOUS_ONLY, BOTH_SUPPRESSED}   -->it means 1 row and 4 columns
		3.{-40,0,50,150,200,300}
		4.{{BULB,BULB,BULB,BULB,BULB,BULB,DC,DC,BULB,BULB,BULB,BULB,BULB,BULB,LED,BULB,BULB,BULB,BULB,BULB,BULB},{BULB,BULB,BULB,BULB,BULB,BULB,DC,DC,BULB,BULB,BULB,BULB,BULB,BULB,LED,BULB,BULB,BULB,BULB,BULB,BULB},{BULB,BULB,BULB,BULB,BULB,BULB,DC,DC,BULB,BULB,BULB,BULB,BULB,BULB,LED,BULB,BULB,BULB,BULB,BULB,BULB},{BULB,BULB,BULB,BULB,BULB,BULB,DC,DC,BULB,BULB,BULB,BULB,BULB,BULB,LED,BULB,BULB,BULB,BULB,BULB,BULB}}


 * History
 *------------------------------------------------------------------------------
 * Date					Name				Description of Change
 * 31-Jul-2012			Kalyan               Created.
 * 27-August-2012       Swapnal Shewale      Added Variant Condition on Parameter Value Object.
 * 05-Sept-2012         Swapnal Shewale		 Added code to create HEX value object
 * 12-Oct-2012          Swapnal Shewale		 Merged Variant condition code for Drop 8
 * 01-Apr-2013          Shalini Tawar        Fix for hex type parameter value creation on Solaris env
 * 25-Apr-2013          Shalini Tawar        Fixed Change management issues.
 * 26-Apr-2013          Shalini Tawar        Changes to validate parameter value on update,
 *                                           changes to handle if single parameter value
 *                                           needs to be populated in entire table.

 *29-Apr-2013           Nikhil Patil        Changes related to configuration file -
 *                                          If a config file is not available at the same location where the utility is executed or
 *                                          If the config file path (-configFile command line argument) is provided but
 *                                          the config file does not exist in that location - 
 *                                          throw an error saying 
 *                                          �+++ERROR: Config file is not provided. Please specify the location for the file FVE_ccm_config.txt� 
 *                                          and quit from there
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/

#include <sys/stat.h>
#include "fve_import_parameter_values.h"
#include "fve_macros.h"
#include "fve_constants.h"
#include "fve_includes.h"

FILE		*logfileptr				=	NULL;
FILE		*fileptr1				=	0;
FILE		*fileptr2				=	0;
FILE		*logFilePtrFailure		=	NULL;
int			totalNoOfParameters		=	0;
int			totalNoOfvExprs			=	0;

int			successCntParameter		=	0;
int			failureCntParameter		=	0;
int			successCntProcesses		=	0;
int			failureCntProcesses		=	0;
char		* dicId					=	NULL;
char		* dicRevId				=	NULL;
char		*ecuAcronym				=	NULL;
char		*csvConfigFileDelimeter		=	NULL;
char		*toleranceExistInConfigFile	=	NULL;
tag_t		ecctRevTag				=	NULLTAG;
tag_t		ecctItemTag				=	NULLTAG;


//this is tag for groupBl
tag_t		topBlECCTPrj			=	NULLTAG;
tag_t		windowECCTPrj			=	NULLTAG;
char		*filename1				=	NULL;
char		*filename2				=	NULL;
struct      FVEVariantInfostruct	*strVariantInfo		= NULL;
struct		FVEParmValInfostruct	*strParmValInfo		=	NULL;

struct      stat file_stat;
struct      stat file_statProcessInfo;
struct      stat configFile_stat;

char		*file_pathFailure			=	NULL;
char 		*login_group				=	NULL;
char 		*login_user					=	NULL;
char		currentRoleName[SA_name_size_c+1]	=	"";
char		*exeName					=	NULL;
char        typeName[TCTYPE_name_size_c+1] = "" ;
tag_t       objType            = NULLTAG;

// Pointer to point configuration file path.
char*   configFileInput     =   NULL;

// File pointer to config file.
FILE    *configFilePtr      =   0;

extern int ITK_user_main( int argc, char **  argv)
{

    int         line_count = 0;
    int  		ifail						=	ITK_ok;
	int			cntExt						=	0;
	int			iCounter					=	0;
	int			validCounterExt				=	0;
	int			totalNoOfConfigCons			=	0;
    char 		*login_password				=	NULL;
	char        *upwf                       =   NULL;
	char        line_in[555 + 1]			=	"";
    char        *ptr						=	0;
    char        logfilename[255 + 1]		=	"";
	char        logfilename_failure[255 + 1]		=	"";
	char		** extension				=	NULL;
	char		* time_stamp				=	NULL;
	char		* file_path					=	NULL;
	char		*lgFlName					=	NULL;
	char		*lgFlPath					=	NULL;
	char		*lgFlExt					=	NULL;
	char*		line_temp					=	NULL;
	char*       representsValue				=	NULL;
	logical     isParmGrpDef				=	FALSE;
	char	    *configFlName				=	NULL;
	tag_t		current_role_tag			=	NULLTAG;
	logical		isConfigFilePresent			=	FALSE;

	time_t      clock;
	int			numUsersSE					=	0;
	tag_t		*list_usersSE				=	NULL;
	int			numUsersMS					=	0;
	tag_t		*list_usersMS				=	NULL;
	int			numUsersDBA					=	0;
	tag_t		*list_usersDBA				=	NULL;
	int			numUsersCC					=	0;
	tag_t		*list_usersCC				=	NULL;
	char		*message					=	NULL;
	tag_t		group_tag					=	NULLTAG;
	tag_t		user_tag					=	NULLTAG;
	tag_t		se_role_tag					=	NULLTAG;
	tag_t		ms_role_tag					=	NULLTAG;
	tag_t		dba_role_tag				=	NULLTAG;
	tag_t		cc_role_tag			     	=	NULLTAG;
	//structure variables
	struct		FVEConfigFileInfostruct	*strConfigInfo	=	NULL;
	struct      stat configFile_stat;
	logical		sessionFlag					=	FALSE;
	char		object_type[WSO_name_size_c+1]	=	"";



	struct		tm *time_struct;

	/** @par	High level design steps:
	*  @n 			Below are the high level steps which are followed in uploader2 (fve_import_parameter_values) utility:

	*  \b	1.	Get input arguments and validate the arguments.
	*  @n	(e.g. user, password, group, topNodeId, revId, parmvalfile, varExpMapfile, configFile)

	*  \b	2.	Validate input files i.e. Parameter value file (parmvalfile) and Variant definition file (varExpMapfile)
	*  @n	Function: int FVE_validate_files(char *filename1, char *filename2)

	*  \b	3.	Validate config file and create log file and failure log file.
	*  @n \li \b	3.1	If config file is valid then parse it and store the information in structure array (configInfo). 
	*  @n	Function:  int fve_parse_configFile(FILE *configFlPtr,char *delim,struct FVEConfigFileInfostruct *configInfo)
	*  @n \li \b	3.2	Get log file constants; check if log file name, path and extension exist and create log file name and failure log file name accordingly.
	*  @n \li \b	3.3	Append log file name and failure log file name with time stamp. And create those files.

	*  \b	4.	Verify user is a member of valid group and having valid role. 
	*  @n	Valid roles are Software Engineer, Module Supervisor, Configuration Coordinator and DBA.

	*  \b	5.	Check if given item revision is of type �FVE_ECCTProjectRevision� and if not then log error and exit.

	*  \b	6.	Process the Variant Definition file and store the information in a structure array (variantInfo).
	*  @n	Parse variant expression file to get variant expression conditions and variant expression names.
	*  @n	Function: int FVE_parse_variantFile(FILE *flPtrProcess,char *delim,struct FVEVariantInfostruct *variantInfo)
	*  @n	(Function �FVE_parse_variantFile� populates structure array (variantInfo) and returns total no of variant expressions)

	*  \b	7.	Get the parameter value information.
	*  @n	If delimiter is specified in configuration file then parse parameter value file using specified delimiter else parse parameter value file using default delimiter (�||�) and store the information in structure array (parmValueInfo).
	*  @n	Function: int FVE_parse_parmValFile(FILE *flPtrProcess,char *delim,struct FVEParmValInfostruct *parmValueInfo)
	*  @n	(Function FVE_parse_parmValFile populates structure array (parmValueInfo) and returns total no of parameters)

	*  \b	8.	Process the parameter value information.
	*  @n	Function: int fve_process_parameterValueInfo(struct FVEParmValInfostruct *parmValInfoStr,int totalNoOfParameters)
	*  @n	Brief steps followed in function �fve_process_parameterValueInfo�:
	*  @n \li \b	8.1	For each parameter name from csv file, recursively check if it exists under ECCT repository else throw error.
	*  @n \li \b	8.2 	Check if parameter value object is already exists with given name under parameter usage bomline.
	*  @n \b	8.2.1	If parameter value object already exist then update it.
	*  @n	Function: int FVE_update_operations(tag_t paramValBl,tag_t paramUsageBl,struct FVEParmValInfostruct *valInfoStruct,int Counter)
	*  @n \b	8.2.2	If parameter value object does not exist then create parameter value object, add it under parameter usage and set variant condition on it.
	*  @n		Function: int FVE_traverse_paramUsageBomLine(struct FVEParmValInfostruct *valInfoStr, tag_t bomLineUsageTag,int counter)

	*  \b	9.	Report all the processing details in a log file.
			
	*/

    if( argc < 1)
    {
        display_usage();
        exit(0);
    }

    if (( ITK_ask_cli_argument( "-help" ) ) ||
		( ITK_ask_cli_argument( "-h" ) )    ||
		( ITK_ask_cli_argument( "-H" ) )
	   )
    {
        display_usage();
        exit(0);
    }

	login_user		=	ITK_ask_cli_argument("-u=");
	login_password	=	ITK_ask_cli_argument("-p=");
	upwf            =   ITK_ask_cli_argument("-pf=");/* gets the password file*/
	login_group		=	ITK_ask_cli_argument("-g=");
	dicId			=	ITK_ask_cli_argument("-topNodeId=");
	dicRevId		=	ITK_ask_cli_argument("-revId=");
	filename1		=	ITK_ask_cli_argument("-parmvalfile=");
	filename2		=	ITK_ask_cli_argument("-varExpMapfile=");

    configFileInput =   ITK_ask_cli_argument("-configFile=");
	
	/*-------------------------------------------*/
    /*          Decrypt the password             */
    /*-------------------------------------------*/
    if( upwf != 0 )
    {
       readAndDecryptPasswd( upwf, &login_password) ;
    }

	if(login_user == NULL || tc_strlen(login_user) == 0)
	{
		fprintf(stderr,"\nERROR: -u=%s is Not provided.Please provide userid\n","user Id");
		display_usage();
        exit(0);

	}
	if(login_password == NULL || tc_strlen(login_password) ==0)
	{
		fprintf(stderr,"\nERROR: -p=%s is not provided.Please provide password\n","password");
		display_usage();
        exit(0);
	}
	
	if(login_group == NULL || tc_strlen(login_group) == 0)
	{
		fprintf(stderr,"\nERROR: -g=%s is not provided.Please provide group name\n","group Name");
		display_usage();
        exit(0);
	}
	if(dicId == NULL || tc_strlen(dicId) == 0)
	{
		fprintf(stderr,"\nERROR: -topNodeId=%s is not provided.\nPlease provide Repository Id.\n","Repository Id");
		display_usage();
        exit(0);
	}
	if(dicRevId == NULL || tc_strlen(dicRevId) == 0)
	{
		fprintf(stderr,"\nERROR: -revId=%s is not provided.\nPlease provide Repository Revision Id.\n","revision Id");
		display_usage();
        exit(0);
	}

	ifail=FVE_validate_files(filename1,filename2);

	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	printf("Logging in...\n");
	if (( ifail = ITK_init_module(login_user,login_password,FV_trim_blanks(login_group))) != ITK_ok)
	{
		fprintf(stderr,"\nERROR: %d, Failed to login, See syslog file for details\n", ifail);
		printf("\nFailed to login.Either userId , Password or Group information is invalid.\n");
		EMH_ask_error_text (ifail, &message);
		fprintf(stderr,"\nERROR: %s\n",message);
		exit(1);
	}

	/** @bug \b 1. Configuration file validation
	*  @n		Existing: Configuration file validation partially done in function FVE_validate_files and remaining validation is done after login into Teamcenter.
	*  @n		Comments: Separate function to validate config file which is called before login into Teamcenter.
	*/

        // Nikhil Patil changes starts.
    if ( configFilePtr == 0)
    {
        //log file information
        /*Check if configuration file exist*/
        configFlName=FVE_CCM_CONFIG_FILE_NAME;
        configFilePtr=fopen(configFlName, "r");
    }
    // Nikhil Patil changes ends.

	if(configFilePtr == 0)
    {
        /*
            If a config file is not available at the same location where the utility is executed or
            If the config file path (-configFile command line argument) is provided but
            the config file does not exist in that location - 
            throw an error saying 
            �+++ERROR: Config file is not provided. Please specify the location for the file FVE_ccm_config.txt� 
            and quit from there
        */

            fprintf(stderr, "+++ERROR: Config file is not provided. Please specify the location for the file FVE_ccm_config.txt\n\n");
            exit(1);
    }else
	{

            // Nikhil Patil changes starts.
            if( configFlName == NULL || tc_strlen(configFlName) == 0 )
            {
                ITK(FV_strdup(configFileInput, &configFlName))
                //configFlName = ( (char*) MEM_alloc( sizeof(char) * tc_strlen(configFileInput) ) );
                //tc_strcpy(configFlName, configFileInput);
            }

            // Nikhil Patil changes ends.

			stat( configFlName, &configFile_stat);
			if( configFile_stat.st_size == 0 )
			{
				 printf("Warning: Configuration File [%s] is empty!!.\n", configFlName);
			}else
			{
				strConfigInfo=(struct FVEConfigFileInfostruct*)MEM_alloc((sizeof(struct FVEConfigFileInfostruct))*MAX_STRCT);
				FVE_initialize_ConfigFiletructure(strConfigInfo);
				//parse file to get the log file constants.
				totalNoOfConfigCons=fve_parse_configFile(configFilePtr,TXT_FILE_DELIM,strConfigInfo);

	/** @bug \b 2. Configuration file parsing
	*  @n		Existing: After parsing config file data is captured in structure array and again looped through for loop to find config file constants and decided log file name, failure log file name.
	*  @n		Comments: Instead of looping through structure again  can we decide log file name and failure log file name in one pass only? (i.e. while parsing config file) 
	*/
				if(totalNoOfConfigCons > 0)
				{
					//make sure log file name , path and extension exist
					for(iCounter=0;iCounter<totalNoOfConfigCons;iCounter++)
					{
						if(strConfigInfo[iCounter].constantName != NULL &&
							tc_strlen(strConfigInfo[iCounter].constantName) > 0 )
						{
							if(tc_strcmp(strConfigInfo[iCounter].constantName ,LOG_FILE_NAME) == 0)
							{
								if(strConfigInfo[iCounter].lofFileName != NULL && tc_strlen(strConfigInfo[iCounter].lofFileName)> 0)
								{
									lgFlName=(char*) MEM_alloc((int) (strlen(strConfigInfo[iCounter].lofFileName)+1)* sizeof(char));
									tc_strcpy(lgFlName,strConfigInfo[iCounter].lofFileName);
								}
							}else if(tc_strcmp(strConfigInfo[iCounter].constantName ,LOG_FILE_PATH) == 0)
							{
								if(strConfigInfo[iCounter].logFilePath != NULL && tc_strlen(strConfigInfo[iCounter].logFilePath)> 0)
								{
									lgFlPath=(char*) MEM_alloc((int) (strlen(strConfigInfo[iCounter].logFilePath)+1)* sizeof(char));
									tc_strcpy(lgFlPath,strConfigInfo[iCounter].logFilePath);
								}
							}else if(tc_strcmp(strConfigInfo[iCounter].constantName ,LOG_FILE_EXTENSION) == 0)
							{
								if(strConfigInfo[iCounter].logFileExt != NULL && tc_strlen(strConfigInfo[iCounter].logFileExt)> 0)
								{
									lgFlExt=(char*) MEM_alloc((int) (strlen(strConfigInfo[iCounter].logFileExt)+1)* sizeof(char));
									tc_strcpy(lgFlExt,strConfigInfo[iCounter].logFileExt);
								}
							}
						}//if
					}//for
					if(lgFlName && lgFlPath && lgFlExt )
						isConfigFilePresent = TRUE;

				}// totalNoOfConfigCons> 0
			}//configFile_stat.st_size == 0
	}//configFilePtr

	 /*Append the log file name with the date and time stamp along with Process ID */
	if(isConfigFilePresent == FALSE)
	{
		time( &clock );
		time_struct= localtime(&clock);
		#ifdef UNX
			sprintf(logfilename,"%s_%d_%02d_%02d_%d_%02d:%02d.log",argv[0],getpid(),
                 (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );

			sprintf(logfilename_failure,"%s_%s_%d_%02d_%02d_%d_%02d:%02d.log",argv[0],"failed_list",getpid(),
                 (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );

		#else
			sprintf(logfilename,"%s_%02d_%02d_%d_%02d_%02d.log",argv[0],
                    (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );

			sprintf(logfilename_failure,"%s_%s_%02d_%02d_%d_%02d_%02d.log",argv[0],"failed_list",
                    (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );
		#endif

		logfileptr = fopen( logfilename, "w+");
	}else
	{
		/*Append the log file name with the date and time stamp */
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		sprintf(logfilename,"%s",lgFlName);
		strcat(logfilename,"_");
		strcat(logfilename,time_stamp);

		file_path = (char*)MEM_alloc((int)(strlen(lgFlPath)+strlen(logfilename) +10) * sizeof(char));
		strcpy(file_path, lgFlPath);
		strcat(file_path, FILEPATH_DELIMITER);
		strcat(file_path, logfilename);
		strcat(file_path, ".");
		strcat(file_path, lgFlExt);
		logfileptr = fopen(file_path, "w+");

		//failure file name
		sprintf(logfilename_failure,"%s",lgFlName);
		strcat(logfilename_failure,"_");
		strcat(logfilename_failure,"failed_list");
		strcat(logfilename_failure,"_");
		strcat(logfilename_failure,time_stamp);

		file_pathFailure = (char*)MEM_alloc((int)(strlen(lgFlPath)+strlen(logfilename_failure) +10) * sizeof(char));
		strcpy(file_pathFailure, lgFlPath);
		strcat(file_pathFailure, FILEPATH_DELIMITER);
		strcat(file_pathFailure, logfilename_failure);
		strcat(file_pathFailure, ".");
		strcat(file_pathFailure, lgFlExt);

	}

	//verify if user is a member of a group and having a certain role
	if(login_group && tc_strlen(login_group)> 0 && login_user && tc_strlen(login_user)> 0)
	{
		ITK(SA_find_groupmember_by_rolename(FV_SW_ENGG_ROLE,login_group,login_user,&numUsersSE,&list_usersSE))
		ITK(SA_find_groupmember_by_rolename(FV_Module_SVR_ROLE,login_group,login_user,&numUsersMS,&list_usersMS))
		ITK(SA_find_groupmember_by_rolename(DBA_ROLE,login_group,login_user,&numUsersDBA,&list_usersDBA))
		ITK(SA_find_groupmember_by_rolename(CONF_COORD_ROLE,login_group,login_user,&numUsersCC,&list_usersCC))
		ITK(SA_find_group(login_group,&group_tag))
		ITK(SA_find_user(login_user,&user_tag))
	}

	//get the current login user role
	ITK(SA_ask_current_role(&current_role_tag))
	ITK(SA_ask_role_name(current_role_tag, currentRoleName))
	ITK(SA_find_role(FV_SW_ENGG_ROLE,&se_role_tag))
	ITK(SA_find_role(FV_Module_SVR_ROLE,&ms_role_tag))
	ITK(SA_find_role(DBA_ROLE,&dba_role_tag))
	ITK(SA_find_role(CONF_COORD_ROLE,&cc_role_tag))


	fprintf(logfileptr,"<Current Role name> %s.\n",currentRoleName);
	fprintf(logfileptr,"\n");
	if((currentRoleName) && (tc_strlen(currentRoleName)> 0))
	{
		/*check if the given role is a valid role in order to be able to run the script and
		 also check if the given user id is having the role specified in the config file*/
		if( (tc_strcasecmp(currentRoleName, FV_SW_ENGG_ROLE) == 0) || (tc_strcasecmp(currentRoleName, FV_Module_SVR_ROLE) == 0) || (tc_strcasecmp(currentRoleName, CONF_COORD_ROLE) == 0) || (tc_strcasecmp(currentRoleName,DBA_ROLE) == 0))
		{
			sessionFlag=TRUE;
		}else
		{
			/*
			if current user belongs to all 3 valid roles i.e. SE/MS/DBA
				First Priority will be given for DBA , Then SE and  last MS
				1.utility should get execute with DBA role.

			if current user belongs to any 2 roles valid roles i.e.
				1.SE/MS or SE/DBA  ->utility should get execute with DBA
				2.MS/DBA           -->Utility should get execute with DBA
			*/

	/** @bug \b 3. Validate user, group and role
	*  @n		Existing: Logic used in coding and comments mentioned in source code differs, need to confirm valid user, group and roles.
	*  @n		Comments: Existing coding logic need to be checked again after confirming valid users, groups, roles.
	*/

			if(list_usersSE || numUsersSE > 0 || list_usersCC || numUsersCC > 0 || list_usersMS || list_usersDBA || numUsersMS > 0 || numUsersDBA > 0)
			{

				if(user_tag && group_tag && dba_role_tag)
				{
					if(list_usersDBA && numUsersDBA > 0)
					{
						fprintf(logfileptr,"Setting current user session with role %s\n",DBA_ROLE);
						fprintf(logfileptr,"\n");
						ITK(SA_set_default_role(user_tag,group_tag,dba_role_tag))
						if(ifail== ITK_ok)
						{
							sessionFlag=TRUE;
						}else
						{
							EMH_ask_error_text(ifail, &message);
							fprintf(stderr,"\nERROR: %s\n",message);
						}
					}
				}

				if(sessionFlag == FALSE)
				{
					//set session to se
					if(user_tag && group_tag && se_role_tag)
					{
						if(list_usersSE && numUsersSE > 0)
						{
							fprintf(logfileptr,"Setting current user session with role %s\n",FV_SW_ENGG_ROLE);
							fprintf(logfileptr,"\n");
							ITK(SA_set_default_role(user_tag,group_tag,se_role_tag))
							if(ifail== ITK_ok)
							{
								sessionFlag=TRUE;
							}else
							{
								EMH_ask_error_text(ifail, &message);
								fprintf(stderr,"\nERROR: %s\n",message);
							}
						}
					}
				}
				if(sessionFlag == FALSE)
				{
					//set session to cc
					if(user_tag && group_tag && cc_role_tag)
					{
						if(list_usersSE && numUsersCC > 0)
						{
							fprintf(logfileptr,"Setting current user session with role %s\n",CONF_COORD_ROLE);
							fprintf(logfileptr,"\n");
							ITK(SA_set_default_role(user_tag,group_tag,cc_role_tag))
							if(ifail== ITK_ok)
							{
								sessionFlag=TRUE;
							}else
							{
								EMH_ask_error_text(ifail, &message);
								fprintf(stderr,"\nERROR: %s\n",message);
							}
						}
					}
				}

				if(sessionFlag == FALSE)
				{
					//set session to ms
					if(user_tag && group_tag && ms_role_tag)
					{
						if(list_usersMS && numUsersMS > 0)
						{
							fprintf(logfileptr,"Setting current user session with role %s\n",FV_Module_SVR_ROLE);
							fprintf(logfileptr,"\n");
							ITK(SA_set_default_role(user_tag,group_tag,ms_role_tag))
							if(ifail== ITK_ok)
							{
								sessionFlag=TRUE;
							}else
							{
								EMH_ask_error_text(ifail, &message);
								fprintf(stderr,"\nERROR: %s\n",message);
							}
						}
					}
				}//sessionFlag == FALSE
			}// list_usersSE || numUsersSE > 0 || list_usersMS || list_usersDBA || numUsersMS > 0 || numUsersDBA > 0
		}//else
	}//currentRoleName

	if(sessionFlag == FALSE)
	{
		printf("\n Invalid user role \n");
		fprintf(stderr,"\nERROR: Current User Role is %s .\n",currentRoleName);
		fprintf(stderr,"\nERROR: Invalid Role , Only users having role Software Engineer or Module Supervisor or DBA can perform this action.\n");
		exit(1);

	}else
	{
		printf("\nValid user %s \n",login_user);
	}

	FVE_FREE(list_usersSE)
	numUsersSE=0;
	FVE_FREE(list_usersMS)
	numUsersMS=0;
	FVE_FREE(list_usersDBA)
	numUsersDBA=0;
    FVE_FREE(list_usersCC)
	numUsersCC=0;

	ITK(FVE_find_rev(dicId, dicRevId, &ecctRevTag))

	/** @bug \b 4. Check ECCT project Revision
	*  @n		Existing: If given item revision is not found in Teamcenter then also program flow is continuing. 
	*  @n		Comments: Error handling should be done correctly.
	*/

	if(ecctRevTag == NULLTAG)
	{
		fprintf(stderr,"\nERROR: Repository with %s%s%s does not exist\n",dicId,"/",dicRevId);
	}
	else
	{
		// Check if it is of type ECCT Project.
		// Check the object type
		ITK(WSOM_ask_object_type(ecctRevTag, object_type))
		
		if(strcmp(object_type, FVE_ECCTProjectRevisionTYPE) == 0)
		{
			//ITK(FV_object_is_typeof(ecctRevTag, ParmGrpDefRevisionTYPE, &isParmGrpDef))
			//if(isParmGrpDef)
			//{
            ITK(ITEM_ask_item_of_rev(ecctRevTag, &ecctItemTag))
            //ITK(AOM_get_value_string(ecctItemTag, representsPROP, &representsValue))
            //if(representsValue && (tc_strcmp(ECCTProjectVALUE, representsValue) == 0))
		    //{
			//get the ecu acronym from dictionary
			ITK(AOM_ask_value_string(ecctRevTag,FVE_ECUAcronymPROP,&ecuAcronym))
		  
		}else
		{
			  fprintf(stderr,"\nERROR: Given item id %s%s%s does not represent a Repository.\n",dicId,"/",dicRevId);
			  exit(1);
		}
	}

	/** @bug \b 5. Log file creation
	*  @n		Existing: if (logfileptr == NULL) is checked at later stage in code. 
	*  @n		Comments: logfileptr needs to be checked earlier in code where it is tried to open log file for writing.
	*/

    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog details will be written into %s\n\n",file_path);
	if( logfileptr )
    {

        fprintf(logfileptr,"Utility name: %s\n\n",argv[0]);
		exeName= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(argv[0]))+1)* sizeof(char));
		strcpy(exeName,FV_trim_blanks(argv[0]));
		time( &clock );
        fprintf(logfileptr,"Start time: %s\n", ctime(&clock));
    }

	fprintf(logfileptr,"Logged in successfully.\n");

	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"ECU Name: %s\n", ecuAcronym);
	fprintf(logfileptr,"\n");
	fprintf(logfileptr,"Repository Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
	fprintf(logfileptr,"\n");


	/** @bug \b 6. Memory allocations and memory free
	*  @n		Existing: 6.1 Structure array of 20000 structures is created each for configInfo, strVariantInfo, strParmValInfo.
	*  @n \li		strConfigInfo=(struct FVEConfigFileInfostruct*)MEM_alloc((sizeof(struct FVEConfigFileInfostruct))*MAX_STRCT);
	*  @n \li		strVariantInfo=(struct FVEVariantInfostruct*)MEM_alloc((sizeof(struct FVEVariantInfostruct))*MAX_STRCT);
	*  @n \li		strParmValInfo=(struct FVEParmValInfostruct*)MEM_alloc((sizeof(struct FVEParmValInfostruct))*MAX_STRCT);
	*  @n			6.2 Many of the allocated memories are not freed correctly. In error scenarios without freeing allocated memories exit is called. 
	*  @n		Comments: Proper Memory allocation and memory free needs to be done.
	*/

	/** @bug \b 7. Variant condition update during update parameter value.
	*  @n		Existing:  In FVE_update_operations existing variant condition is removed and new varinat condition is created and added on bom line.
	*  @n		Comments: Check if earlier variant condition is different than new variant condition and if different then only update the variant condition.
	*  @n		e.g. If structure having 100 bom lines has variant condtion change for 2 bom lines only then with new approach only 2 bom lines will be get processed.  
	*/

	/* Process the Variant Definition file and store the info in a structure */
	strVariantInfo=(struct FVEVariantInfostruct*)MEM_alloc((sizeof(struct FVEVariantInfostruct))*MAX_STRCT);
	FVE_initialize_VariantStructure(strVariantInfo);

	printf("\nStart Processing Variant Definition File...\n");
	if(csvConfigFileDelimeter && tc_strlen(csvConfigFileDelimeter)> 0)
	{
		totalNoOfvExprs=FVE_parse_variantFile(fileptr2,csvConfigFileDelimeter,strVariantInfo);
	}else
	{
		totalNoOfvExprs=FVE_parse_variantFile(fileptr2,CSV_DEFAULT_FILE_DELIM,strVariantInfo);
	}
	printf("\nTotal No Of Variant Expressions =%d\n",totalNoOfvExprs);



	/* Process the parameter value info now */
	strParmValInfo=(struct FVEParmValInfostruct*)MEM_alloc((sizeof(struct FVEParmValInfostruct))*MAX_STRCT);
	FVE_initialize_ParmValStructure(strParmValInfo);

	//parse parameter definition file
	if(csvConfigFileDelimeter && tc_strlen(csvConfigFileDelimeter)> 0)
	{
		printf("\nDelimiter %s is specified in the configuration file.\n",csvConfigFileDelimeter);
		printf("\nStart Processing Parameter Value Definition File...\n");
		totalNoOfParameters=FVE_parse_parmValFile(fileptr1,csvConfigFileDelimeter,strParmValInfo );
	}else
	{
		printf("\nDelimiter is not specified in the configuration file\n");
		printf("\nDefault delimiter %s will be considered.Please make sure csv file contains this delimeter.\n",CSV_DEFAULT_FILE_DELIM);
		totalNoOfParameters=FVE_parse_parmValFile(fileptr1,CSV_DEFAULT_FILE_DELIM, strParmValInfo);
	}
	printf("\nTotal Parameters=%d\n",totalNoOfParameters);

	if(totalNoOfParameters > 0)
	{
		ifail=fve_process_parameterValueInfo(strParmValInfo,totalNoOfParameters);
	}


    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    time( &clock );
    fprintf(logfileptr,"\nEnd time: %s", ctime( &clock ) );

	if(logFilePtrFailure)
	{
		fprintf(logFilePtrFailure,"\nEnd time: %s", ctime( &clock ) );
	}

	if (logfileptr ) fclose( logfileptr);
	if(fileptr1) fclose(fileptr1);
	if(fileptr2) fclose(fileptr2);
	if(logFilePtrFailure) fclose(logFilePtrFailure);

	ITK(BOM_close_window(windowECCTPrj))

	if(user_tag && group_tag && current_role_tag)
		ITK(SA_set_default_role(user_tag,group_tag,current_role_tag))

        // Nikhil Patil - changes starts
    /*
    *  Close config file.
    */

    // Close config file.
    if( configFilePtr )
    {
        fclose(configFilePtr);
    }

    configFileInput =   NULL;


    // Nikhil Patil - changes ends


	FVE_MemFreeStructParameterVal(strParmValInfo);
    FVE_MemFreeStructVariant(strVariantInfo);
	FVE_MemFreeStructConfigFile(strConfigInfo);
	FVE_FREE(toleranceExistInConfigFile);
	FVE_FREE(exeName);

	ITK_exit_module( true );

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}

/* */
int fve_process_parameterValueInfo(struct FVEParmValInfostruct *parmValInfoStr,int totalNoOfParameters)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"fve_process_parameterValueInfo";
	int			iCounter			=	0;
	tag_t		tagParmUsageBl		=	NULLTAG;
	tag_t		tagParmValueBl		=	NULLTAG;
	TC_write_syslog("\n Enter function %s",function_name);
	if(totalNoOfParameters > 0)
	{
		//get the topBomline and window for ECCT project Revision
		ifail=FV_get_set_window_fromRev(ecctRevTag,&windowECCTPrj,&topBlECCTPrj);
		if(windowECCTPrj && topBlECCTPrj)
		{
			//for each parameter name from csv file , recursively check if it exist under ecct repository
			for(iCounter=0;iCounter<totalNoOfParameters;iCounter++)
			{
				tagParmUsageBl = NULLTAG;
                tagParmValueBl = NULLTAG;
				ifail=FV_check_bomLineExist_inStruct(topBlECCTPrj,parmValInfoStr[iCounter].parmName,&tagParmUsageBl);
				if(tagParmUsageBl)
				{
					//update log file
					ifail=FVE_update_log_file(logfileptr,parmValInfoStr,iCounter);
					/*check if parameter value object alreday exist with gien name under parameter usage bomline
					  if alreday exist , update it.
					  else create and add it.
					*/
					ifail=FV_check_bomLineExist_inStruct_ofTypeParmVal(tagParmUsageBl,parmValInfoStr[iCounter].parmValueName,&tagParmValueBl);
					if(tagParmValueBl)
					{
						//update parameter value object
						ifail=FVE_update_operations(tagParmValueBl,tagParmUsageBl,parmValInfoStr,iCounter);
					}else
					{
						//create Parameter Value Object based on the bom line type with the given name and set the values on it.
						//ifail=FVE_traverse_paramUsageBomLine(parmValInfoStr,tagParmUsageBl,iCounter,parmValInfoStr[iCounter].parmValueName,parmValInfoStr[iCounter].parmValue,parmValInfoStr[iCounter].vExprName);
						ifail=FVE_traverse_paramUsageBomLine(parmValInfoStr,tagParmUsageBl,iCounter);
					}
				}else
				{
					failureCntParameter++;
					ifail=FVE_update_log_file(logfileptr,parmValInfoStr,iCounter);
					//parameter usage bomline didnt exist under ECCT Repository structure
					fprintf(logfileptr,"ERROR: Parameter %s not found in repository structure.\n",parmValInfoStr[iCounter].parmName);
					fprintf(logfileptr,"Status: Failed.\n");
					fprintf(logfileptr,"\n");

					if(logFilePtrFailure == NULL)
					{
						logFilePtrFailure = fopen(file_pathFailure, "w+");
						fprintf(logFilePtrFailure,"Failed parameter List\n");
						fprintf(logFilePtrFailure,"\n");
						fprintf(logFilePtrFailure,"\n");

						if(logfileptr)
						{
							fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
						}
						fprintf(logFilePtrFailure,"Logged in successfully.\n");
						fprintf(logFilePtrFailure,"\n");
						fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
						fprintf(logFilePtrFailure,"\n");
						fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
						fprintf(logFilePtrFailure,"\n");
						fprintf(logfileptr,"Repository Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
						fprintf(logFilePtrFailure,"\n");
					}
					ifail=FVE_update_log_file(logFilePtrFailure,parmValInfoStr,iCounter);
					fprintf(logFilePtrFailure,"ERROR: Parameter %s not found in repository structure.\n",parmValInfoStr[iCounter].parmName);
					fprintf(logFilePtrFailure,"Status: Failed.\n");
					fprintf(logFilePtrFailure,"\n");
				}
			}//for
			fprintf(logfileptr,"\n");
			fprintf(logfileptr,"Completed Processing Parameter Values\n");
			fprintf(logfileptr,"\n");

			fprintf(logfileptr,"Total Count Of Parameters: %d\n",totalNoOfParameters);
			fprintf(logfileptr,"Successfully Processed Parameters: %d\n",successCntParameter);
			fprintf(logfileptr,"Failure Count Parameters: %d\n",failureCntParameter);
			fprintf(logfileptr,"\n");
			fprintf(logfileptr,"\n");
		}//windowECCTPrj
	}//totalNoOfParameters
	TC_write_syslog("\n leave function %s",function_name);
	return ifail;
}

/*
function to update log file contents
If all required attributes are present , generate the log file with  required attributes.
*/
int FVE_update_log_file(FILE *filePtr,struct FVEParmValInfostruct *parmInfoStruct,int counter)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_update_log_file";
	char*       name				=	NULL;
	int			cntDomainEl			=	0;
	char		**valDomainEl		=	NULL;
	int			cntDomainElVal		=	0;
	char		**valDomainElVal	=	NULL;
	logical		lgDomainElName		=	false;
	logical		lgDomainElValue		=	false;

	TC_write_syslog("\n Enter function %s",function_name);
	if(filePtr)
	{

		name=parmInfoStruct[counter].parmName;
		fprintf(filePtr,"Parameter Name: %s\n",parmInfoStruct[counter].parmName);
		fprintf(filePtr,"Parameter RevId: %s\n",parmInfoStruct[counter].parmRevId);
		fprintf(filePtr,"Parameter Value: %s\n",parmInfoStruct[counter].parmValue);
		if(parmInfoStruct[counter].parmValueName && tc_strlen(parmInfoStruct[counter].parmValueName)> 0)
		{
			fprintf(filePtr,"Parameter Value Name: %s\n",parmInfoStruct[counter].parmValueName);
		}else
		{
			//just add a message saying parameter value name will be auto_generated to <parameter_name>_�value�.
			fprintf(filePtr,"Parameter Value Name: %s\n","");
			fprintf(filePtr,"Parameter value name will be auto generated to %s%s%s%s%s\n","<",name,"_","value",">");
		}
	}
	return ifail;
}

int FVE_initialise_failure_log_file(FILE **filePtr)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_initialise_failure_log_file";

	TC_write_syslog("\n Enter function %s",function_name);

     if(*filePtr == NULL)
    {
	    *filePtr = fopen(file_pathFailure, "w+");
	    fprintf(*filePtr,"Failed parameter List\n");
	    fprintf(*filePtr,"\n");
	    fprintf(*filePtr,"\n");

	    if(logfileptr)
	    {
		    fprintf(*filePtr,"Utility name: %s\n\n",exeName);
	    }
	    fprintf(*filePtr,"Logged in successfully.\n");
	    fprintf(*filePtr,"\n");
	    fprintf(*filePtr,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
	    fprintf(*filePtr,"\n");
	    fprintf(*filePtr,"ECU Name: %s\n", ecuAcronym);
	    fprintf(*filePtr,"\n");
	    fprintf(*filePtr,"Repository Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
	    fprintf(*filePtr,"\n");
    }
	
	TC_write_syslog("\n Exit function %s",function_name);
    return ifail;
}


/*update operation for parameter value object
paramValBl - parameter value bomline tag
paramUsageBl - immidiate parent of paramValBl
valInfoStruct - structure where current information of value object is stored
counter - position in structure


*/
/**
**************************************************************************
*
*  Function Name:   FVE_update_operations
*
*  @desc			Update operation for parameter value object.
*  @see				In Progress
*
*  @param[in]:      paramValBl - parameter value bomline tag
*  @param[in]:      paramUsageBl - immediate parent of paramValBl
*  @param[in]:      valInfoStruct - structure array where current information of value objects is stored
*  @param[in]:      counter - position in structure array
*
*  @return          ITK success/failure ifail.
*
****************************************************************************/
int FVE_update_operations(tag_t paramValBl,tag_t paramUsageBl,struct FVEParmValInfostruct *valInfoStruct,int Counter)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_update_operations";
	tag_t		parmValItemRevTag			=	NULLTAG;
	tag_t		parmValItemTag				=	NULLTAG;
	char*		parmValItemType			=	NULL;
	char*		parmValItemName			=	NULL;
	tag_t		parmUsageItemRevTag			=	NULLTAG;
	tag_t		parmUsageItemTag				=	NULLTAG;
	char*		parmUsageItemType			=	NULL;
	char*		parmValType				=	NULL;
	logical		flag				=	FALSE;
	char	*commaDelimExist		=	NULL;
	char	*semiColonDelimExist	=	NULL;
	int     newValueCnt				=	0;
	int     oldValueCnt				=	0;
	char	**oldValueArray			=	NULL;
	char	**newValueArray			=	NULL;
	tag_t	oldParmDefRevTagOnUsgObject	=	NULLTAG;
	int		newRowCnt				=	0;
	int		newColCnt				=	0;
	int		oldRowCnt				=	0;
	int		oldColCnt				=	0;

	tag_t	oldTableDefTag			=	NULLTAG;
	tag_t	newTableDefTag			=	NULLTAG;
	logical	isRowCntModify			=	FALSE;
	logical	isColCntModify			=	FALSE;
	logical	isInitValModify			=	FALSE;
	int		rowIndex				=	0;
	char	*newVal					=	NULL;
	char	*newVal1				=	NULL;

	int     newParmDefRows         = 0;
    int     newParmDefCols         = 0;
	logical modify				=	FALSE;
	char	*message			=	NULL;
    char**   dummyValArray = NULL;
    int      dummyValArrayCnt = 0;
    int      iCounter = 0;
    char*   varExpression = NULL;
	char*   varExpCondition = NULL;
    char*   sedVal = NULL;
    char**  parmDefDomainElValues = NULL;
	char**  parmDefDomainElNames = NULL;
    char*   status = NULL;
    tag_t   clauseList = NULLTAG;
	tag_t   condVe = NULLTAG;
    tag_t   loadifVe = NULLTAG;
    tag_t   veb = NULLTAG;
    tag_t   oldVe = NULLTAG;
	int     parmDefDomainElCnt = 0;
	logical   isMatchingVarCond = FALSE;

	TC_write_syslog("\n Enter function %s",function_name);

	/** \par 	Steps Followed:
     */
	/** \par   	1. Get parameter value details
	* @brief \b 		1.1 Get parameter value item rev tag (parmValItemRevTag) from paramValBl.
	* @n \b				1.2 If parameter value item rev has release status then print error in log file and exit.
	* @n \b	        	1.3 Get the item, itemRevTag and item type for paramValBl.
     */

	//get the  item , itemRevTag and its type for paramValBl
	if(paramValBl)
	{
		ITK(AOM_ask_value_tag(paramValBl,bomAttr_lineItemRevTag,&parmValItemRevTag))
        ITK(FV_ask_release_status(parmValItemRevTag, &status))
        if(status != NULL)
        {
            FVE_initialise_failure_log_file(&logFilePtrFailure);
			FVE_update_log_file(logFilePtrFailure,valInfoStruct,Counter);
            fprintf(logFilePtrFailure,"No updates in the attribute values during reimport as Parameter Value is released\n");
            fprintf(logFilePtrFailure,"Status: Failed.\n");
		    fprintf(logFilePtrFailure,"\n");
            fprintf(logfileptr,"Status: Failed.\n");
		    fprintf(logfileptr,"Comment: No updates in the attribute values during reimport as Parameter Value is released\n");
		    fprintf(logfileptr,"\n");
            goto CLEANUP;


        }
		ITK(AOM_ask_value_tag(paramValBl,bomAttr_lineItemTag,&parmValItemTag))
		ITK(AOM_ask_value_string(paramValBl, bomAttr_itemType, &parmValItemType))
		ITK(AOM_ask_value_string(paramValBl,bomAttr_itemName,&parmValItemName))
	}

	/** \par 	2. Get the type of parent (parameter usage object) to make sure we have correct type of value object to modify.
	*  @brief \b        2.1 Get the tag of parameter definition stored on old usage revision.
	*  @n \b            2.2 Get the parameter usage item type and decide parameter value type accordingly.
	*  \li                Parameter usage Item type -> Parameter value type.
	*  @n                FV9ParmDfIntUsg           -> FV9ParmValInt
	*  @n                FV9ParmDfDblUsg           -> FV9ParmValDbl
	*  @n                FV9ParmDfStrUsg           -> FV9ParmValStr
	*  @n                FV9ParmDfSEDUsg           -> FV9ParmValSED
	*  @n                FV9ParmDfHexUsg           -> FV9ParmValHex
	*  
	*  @brief \b	    2.3 If parameter value type decided in step 2.2 is matching with parameter value type found in step 1.1 then only proceed further.
     */
	//now get the type of parent to make sure we have correct type of value object to modify
	if(paramUsageBl)
	{
		ITK(AOM_ask_value_tag(paramUsageBl,bomAttr_lineItemRevTag,&parmUsageItemRevTag))
		if(parmUsageItemRevTag)
		{
			//get the tag of parameter definition stored on this old usage revision
			ITK(AOM_ask_value_tag(parmUsageItemRevTag,fv9RefParmDefRevPROP,&oldParmDefRevTagOnUsgObject))
		}
		ITK(AOM_ask_value_tag(paramUsageBl,bomAttr_lineItemTag,&parmUsageItemTag))
		ITK(AOM_ask_value_string(paramUsageBl, bomAttr_itemType, &parmUsageItemType))
	}
	if(parmUsageItemType && tc_strlen(parmUsageItemType)> 0)
	{
		if(tc_strcmp(parmUsageItemType,FV9ParmDfIntUsgTYPE)== 0)
			parmValType=FV9ParmValIntTYPE;
		if(tc_strcmp(parmUsageItemType,FV9ParmDfDblUsgTYPE)== 0)
			parmValType=FV9ParmValDblTYPE;
		if(tc_strcmp(parmUsageItemType,FV9ParmDfStrUsgTYPE)== 0)
			parmValType=FV9ParmValStrTYPE;
		if(tc_strcmp(parmUsageItemType,FV9ParmDfSEDUsgTYPE)== 0)
			parmValType=FV9ParmValSEDTYPE;
		if(tc_strcmp(parmUsageItemType,FV9ParmDfHexUsgTYPE)== 0)
			parmValType=FV9ParmValHexTYPE;
	}
	if(parmValType && parmValItemType && tc_strcmp(parmValType,parmValItemType)==0)
		flag=TRUE;

	if(flag)
	{
	/** \par 	3. Get the new count for rows, columns and newValueArray using the populated structure valInfoStruct.
	*  @brief \b            3.1 If parmValue in structure valInfoStruct is DEFAULT then
	*  \li                   newParmDefRows = 'rows' property value stored on tableDefinition of parameter definition revision.
	*  \li                   newParmDefCols = 'cols' property value stored on tableDefinition of parameter definition revision.
	*  \li                   newValueCnt = (newParmDefRows * newParmDefCols)
	*
	*  @brief \b            3.2 Else    
	*  \li                   newParmDefRows = 'rows' property value stored on tableDefinition of parameter definition revision.
	*  \li                   newParmDefCols = 'cols' property value stored on tableDefinition of parameter definition revision.
	*  @n @n
	*  \li \b                   3.2.1 If parmValue in structure valInfoStruct contains ";"
	*  @n                            then split the string parmValue using ";" and for each delimited string check
	*  @n \b	                      	3.2.1.1 If it contains ","
	*  @n                                       then split the string using "," and get newValueArray, newValueCnt
	*  @n \b	                       	3.2.1.2 Else
	*  @n                                       split the string using "' '" and get newValueArray, newValueCnt
    *  @n @n
	*  \li \b                   3.2.2 Else
	*  @n \b	                       	3.2.2.1 If parmValue in structure valInfoStruct contains ","
	*  @n                                       then split the string using "," and get newValueArray, newValueCnt
    *  @n \b	                          3.2.2.2 Else
	*  @n \b	                                  3.2.2.2.1 If parameter usage item type == FV9ParmDfSEDUsg
	*  @n                                                    then get the domain element values from domain element name and copy to newValueArray and get the newValueCnt as well.
	*  @n \b	                                  3.2.2.2.2 Else
	*  @n                                                    copy parmValue to newValueArray and get the newValueCnt.
     */
		//get the new coulnt for rows , columns and newValueArray
		if(valInfoStruct[Counter].parmValue && tc_strlen(valInfoStruct[Counter].parmValue)> 0)
		{
			if(tc_strcmp(FV_trim_blanks(valInfoStruct[Counter].parmValue),DEFAULTValue)== 0)
			{
				if(oldParmDefRevTagOnUsgObject)
				{
					ITK(AOM_ask_value_tag(oldParmDefRevTagOnUsgObject,"tableDefinition",&newTableDefTag))
					ITK(FVE_get_value_arrays(oldParmDefRevTagOnUsgObject,initialValuesPROP,&newValueArray))
					//get the count for rows and column
					if(newTableDefTag)
					{
						ITK(AOM_ask_value_int(newTableDefTag, colsPROP, &newColCnt));
						ITK(AOM_ask_value_int(newTableDefTag, rowsPROP, &newRowCnt));
						//validate table size
						newParmDefCols = newColCnt;
                        newParmDefRows = newRowCnt;
						newValueCnt = newRowCnt*newColCnt;
					}
				}
			}else
			{	
				//validate table size
				if(oldParmDefRevTagOnUsgObject)
				{
                    ITK(AOM_ask_value_tag(oldParmDefRevTagOnUsgObject,"tableDefinition",&newTableDefTag))
                    if(newTableDefTag)
                    {
                        ITK(AOM_ask_value_int(newTableDefTag, colsPROP, &newParmDefCols));
					    ITK(AOM_ask_value_int(newTableDefTag, rowsPROP, &newParmDefRows));
                    }
                }
				semiColonDelimExist=strstr(FV_trim_blanks(valInfoStruct[Counter].parmValue),SEMICOLON_DELIM);
                if(semiColonDelimExist)
				{
					split_the_string(FV_trim_blanks(valInfoStruct[Counter].parmValue),SEMICOLON_DELIM, &dummyValArrayCnt, &dummyValArray);
					//semiColonDelimExist=NULL;
					if(dummyValArrayCnt > 0 && dummyValArray)
					{
						newRowCnt = dummyValArrayCnt;
						for(iCounter = 0; iCounter < dummyValArrayCnt; iCounter++)
						{
								commaDelimExist = strstr(FV_trim_blanks(dummyValArray[iCounter]),COMMA_DELIM);
								if(commaDelimExist)
								{
									split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),COMMA_DELIM,&newValueCnt,&newValueArray);
									if(iCounter==0)
									{
										newColCnt=newValueCnt;
									}
									commaDelimExist=NULL;
								}else
								{
									split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),"' '",&newValueCnt,&newValueArray);
								}
						}//for
					}
				}
                else
                {
				    commaDelimExist=strstr(FV_trim_blanks(valInfoStruct[Counter].parmValue),COMMA_DELIM);
				    if(commaDelimExist)
				    {
					    split_the_string(FV_trim_invalidChars(valInfoStruct[Counter].parmValue),COMMA_DELIM,&newValueCnt,&newValueArray);
					    newRowCnt=1;
					    newColCnt=newValueCnt;
				    }else
				    {
					    //newValueCnt=1;
					    newRowCnt=1;
					    newColCnt=1;
					    //newValueArray = (char **)MEM_alloc( 1 * sizeof(char *));
					    //newValueArray[0] = (char *)MEM_alloc( (strlen(valInfoStruct[Counter].parmValue) + 1) * sizeof(char ));
                        if(tc_strcmp(parmUsageItemType,FV9ParmDfSEDUsgTYPE)==0)
						{
							//get the domain element value from domain element name
							if(oldParmDefRevTagOnUsgObject)
							{
								//get the domain element values
								ITK(FVE_get_value_arrays(oldParmDefRevTagOnUsgObject, validValuesPROP,&parmDefDomainElValues));
								//get the domain element name
								ITK(FVE_get_desc_array(oldParmDefRevTagOnUsgObject, validValuesPROP,"desc",&parmDefDomainElNames,&parmDefDomainElCnt));
								for(iCounter =0; iCounter<parmDefDomainElCnt ; iCounter++)
								{
									if(valInfoStruct[Counter].parmValue && parmDefDomainElNames[iCounter] && tc_strlen(parmDefDomainElNames[iCounter])> 0 
                                        && tc_strlen(valInfoStruct[Counter].parmValue)> 0)
									{
										if( tc_strcmp(FV_trim_blanks(valInfoStruct[Counter].parmValue),FV_trim_blanks(parmDefDomainElNames[iCounter])) == 0)
										{
											ITK(FV_copy_string_to_array(&newValueCnt, &newValueArray, parmDefDomainElValues[iCounter]))
                                            //tc_strcpy((newValueArray)[0],parmDefDomainElValues[iCounter]);
											break;
										}
									}
								}//for
							}//parmDefRev
						}else
						{
							ITK(FV_copy_string_to_array(&newValueCnt, &newValueArray, valInfoStruct[Counter].parmValue))
                            //tc_strcpy((newValueArray)[0],FV_trim_blanks(valInfoStruct[Counter].parmValue));
						}
				    }
                }
			}//else
		}

	/** \par 	4. Set parameter values.
	*  @n \b          4.1 If parameter usage item type == FV9ParmDfSEDUsg
	*  @n 						then First string from newValueArray is set as 'fv9Values' property on the parameter value item revision.
	*  @n \b          4.2 Else   
	*  \li \b                 4.2.1 If newValueArray == NULL then print error in log file and exit.
	*  \li \b                 4.2.2 Get the old count for rows , columns and oldValueArray from parameter value item revision.
	*  @n @n
	*  \li \b                 4.2.3 Compare the old values with new values and process accordingly.
	*  @n \b                       4.2.3.1 If((newRowCnt > 1 || newColCnt > 1) && (newRowCnt != newParmDefRows || newColCnt != newParmDefCols ))
	*  @n                                   then print error in log file and exit.
	*  @n \b                       4.2.3.2 If(newRowCnt != oldRowCnt && (newRowCnt != 1 || newColCnt != 1))
	*  @n                   	     	   then isRowCntModify = TRUE
	*  @n \b                       4.2.3.3 If(oldColCnt != newColCnt &&( newRowCnt != 1 || newColCnt != 1))
	*  @n                   	     	   then isColCntModify = TRUE
	*  @n \b                       4.2.3.4 If ((oldRowCnt == newRowCnt && oldColCnt == newColCnt) || (newRowCnt == 1 && newColCnt == 1))
	*  @n                   	     	   then check the old initial values with new values and decide if isInitValModify=TRUE/FALSE
	*  @n @n
	*  \li \b                 4.2.4 If(isRowCntModify || isColCntModify || isInitValModify)
	*  @n                            then validate the parameter values using function FV_validate_reimport_parm_values(parmValItemRevTag, newValueArray, newValueCnt) 
	*  @n                            If validations fails then print error in logfile and exit.
	*  @n @n
	*  \li \b                 4.2.5 If(isRowCntModify || isColCntModify)
	*  @n                            then set the modified row, column value on revision and accordingly create/delete required cells.
	*  @n                            Create the cells based on the item type and depending on newValueCnt set the array of values or single value(Min/Max/Initial)
	*  @n @n
	*  \li \b                 4.2.6 Else
	*  @n							If(isInitValModify == TRUE) then
	*  @n                            depending on newValueCnt set multiple values or single value on cells of Min/Max/Initial tables on revision.
	*/
	
        if(parmValItemRevTag && tc_strcmp(parmUsageItemType,FV9ParmDfSEDUsgTYPE)==0)
        {
            if(newValueArray == NULL)
            {
                failureCntParameter++;           
			    ifail = FV_CCDM_ERROR_INVALID_VALUE;
                TC_write_syslog("\nNo of rows & columns of Parameter value does not match with Parameter Definition.\n");
                FVE_initialise_failure_log_file(&logFilePtrFailure);
			    FVE_update_log_file(logFilePtrFailure,valInfoStruct,Counter);
			    fprintf(logFilePtrFailure,"ERROR: %s\n","Invalid Parameter Value");
                fprintf(logfileptr,"ERROR: %s\n","Invalid Parameter Value");
                fprintf(logFilePtrFailure,"Status: Failed.\n");
			    fprintf(logFilePtrFailure,"\n");
                fprintf(logfileptr,"Status: Failed.\n");
			    fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport");
			    fprintf(logfileptr,"\n");
                goto CLEANUP;
            }
            ITK(AOM_ask_value_string(parmValItemRevTag,fv9ValuesPROP,&sedVal))
            if(sedVal != NULL && tc_strlen(sedVal) > 0 && newValueCnt > 0 &&
                newValueArray[0] != NULL && tc_strcmp(sedVal, newValueArray[0]) != 0)
            {
                modify = TRUE;
                ITK(AOM_refresh(parmValItemRevTag,TRUE))
                ifail=AOM_set_value_string(parmValItemRevTag,fv9ValuesPROP,newValueArray[0]);
                ITK(AOM_save(parmValItemRevTag))
                ITK(AOM_refresh(parmValItemRevTag,FALSE))
		        if(ifail != ITK_ok)
		            ifail=ITK_ok;
            }
        }
        else
        {
		    //get the old count for rows , columns and oldValueArray
		    if(parmValItemRevTag)
		    {
			    ITK(AOM_ask_value_tag(parmValItemRevTag,"fv9TableDefinition",&oldTableDefTag))
			    if(oldTableDefTag)
			    {
				    ITK(AOM_ask_value_int(oldTableDefTag, colsPROP, &oldColCnt));
				    ITK(AOM_ask_value_int(oldTableDefTag, rowsPROP, &oldRowCnt));
				    oldValueCnt=oldColCnt*oldRowCnt;
			    }
			    //get the old values stored on parmValItemRevTag
			    ITK(FVE_get_value_arrays(parmValItemRevTag,fv9ValuesPROP,&oldValueArray))
		    }

		    /*
			    newRowCnt ->Parameter value Row Cnt
			    newColCnt -->Parameter Value Column Cnt
			    newParmDefRows -->Parameter Definition Row Cnt
			    newParmDefCols -->Parameter Definition Column Cnt
		    */
		    if((newRowCnt > 1 || newColCnt > 1) && (newRowCnt != newParmDefRows || newColCnt != newParmDefCols ))
            {
			    failureCntParameter++;           
			    ifail = FV_CCDM_ERROR_INVALID_LENGTH;
                TC_write_syslog("\nNo of rows & columns of Parameter value does not match with Parameter Definition.\n");
                FVE_initialise_failure_log_file(&logFilePtrFailure);
			    FVE_update_log_file(logFilePtrFailure,valInfoStruct,Counter);
			    fprintf(logFilePtrFailure,"ERROR: %s\n","No of rows & columns of Parameter value does not match with Parameter Definition.");
                fprintf(logfileptr,"ERROR: %s\n","No of rows & columns of Parameter value does not match with Parameter Definition.");
                fprintf(logFilePtrFailure,"Status: Failed.\n");
			    fprintf(logFilePtrFailure,"\n");
                fprintf(logfileptr,"Status: Failed.\n");
			    fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport");
			    fprintf(logfileptr,"\n");
                goto CLEANUP;
            }


		    //compare the properties
		    if(newRowCnt != oldRowCnt && (newRowCnt != 1 || newColCnt != 1))
		    {
			    isRowCntModify = TRUE;
			    TC_write_syslog("\n In %s: Row Count modified:", function_name);
			    TC_write_syslog("\n Old RowCount = %d \n New RowCount = %d \n",
                      oldRowCnt,newRowCnt);
		    }
		    if(oldColCnt != newColCnt &&( newRowCnt != 1 || newColCnt != 1))
		    {
			    isColCntModify = TRUE;
			    TC_write_syslog("\n In %s: Column Count modified:", function_name);
			    TC_write_syslog("\n Old ColumnCount = %d \n New ColumnCount = %d \n",
                     oldColCnt, newColCnt);
		    }

		    if((oldRowCnt == newRowCnt && oldColCnt == newColCnt) || (newRowCnt == 1 && newColCnt == 1))
		    {
			    //check the old initial values with new values
			    for(rowIndex=0;rowIndex<oldRowCnt*oldColCnt;rowIndex++)
			    {
				    if(newValueArray && newValueCnt == oldRowCnt*oldColCnt)
				    {
					    if(newValueArray[rowIndex])
					    {
						    newVal1=NULL;
						    FVE_truncate_double_values(atof(FV_trim_blanks(newValueArray[rowIndex])),&newVal1);
						    newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
						    strcpy(newVal,newVal1);
					    }
				    }
				    if(newValueArray && newValueCnt == 1)
				    {
					    if(newValueArray[0])
					    {
						    newVal1=NULL;
						    FVE_truncate_double_values(atof(FV_trim_blanks(newValueArray[0])),&newVal1);
						    newVal= (char*) MEM_alloc((int) (strlen(newVal1)+1)* sizeof(char));
						    strcpy(newVal,newVal1);
					    }
				    }
				    if( (oldValueArray[rowIndex] && newVal) &&(tc_strcmp(oldValueArray[rowIndex],FV_trim_blanks(newVal)) == 0))
				    {
						    isInitValModify = FALSE;
				    }else
				    {
						    isInitValModify = TRUE;
				    }
				    FVE_FREE(newVal)
				    if(isInitValModify == TRUE)
					    break;

			    }//for
		    }else
		    {
			     isInitValModify = TRUE;
		    }

		    if(isRowCntModify || isColCntModify || isInitValModify)
		    {
			    ifail = FV_validate_reimport_parm_values(parmValItemRevTag, newValueArray, newValueCnt);
                if(ifail != ITK_ok)
                {
                    EMH_ask_error_text (ifail, &message);
                    FVE_initialise_failure_log_file(&logFilePtrFailure);
			        FVE_update_log_file(logFilePtrFailure,strParmValInfo,Counter);
				    /*
				    #define FV_CCDM_ERROR_INVALID_ISSIGNED    				(FV_error_base + 79)
				    #define FV_CCDM_ERROR_NOT_IN_RANGE       				(FV_error_base + 80)
				    #define FV_CCDM_ERROR_INVALID_VALUE       				(FV_error_base + 81)
				    #define FV_CCDM_ERROR_VALUE_NOT_ACTUAL_INCREMENT_OF_RES (FV_error_base + 82)
				    #define FV_CCDM_ERROR_INSUFFICIENT_INCREMENT            (FV_error_base + 83)
				    */
                    if(ifail== 920103)
			        {
				        fprintf(logFilePtrFailure,"ERROR: %s\n","Invalid isSigned Value");
                        fprintf(logfileptr,"ERROR: %s\n","Invalid isSigned Value");
			        }else if(ifail== 920104)
			        {
				        fprintf(logFilePtrFailure,"ERROR: %s\n","Parameter Value is not in range");
                        fprintf(logfileptr,"ERROR: %s\n","Parameter Value is not in range");
			        }else if(ifail== 920105)
			        {
				        fprintf(logFilePtrFailure,"ERROR: %s\n","Invalid Parameter Value");
                        fprintf(logfileptr,"ERROR: %s\n","Invalid Parameter Value");
			        }else if(ifail== 920106)
			        {
				        fprintf(logFilePtrFailure,"ERROR: %s\n","Parameter Value is not in actual increment of resolution");
                        fprintf(logfileptr,"ERROR: %s\n","Parameter Value is not in actual increment of resolution");
			        }
                    else if(ifail== 920122)
			        {
				        fprintf(logFilePtrFailure,"ERROR: %s\n","No of rows & columns of Parameter value does not match with Parameter Definition.");
                        fprintf(logfileptr,"ERROR: %s\n","No of rows & columns of Parameter value does not match with Parameter Definition.");
			        }
			        else
			        {
				        fprintf(logFilePtrFailure,"ERROR: %s\n",message);
                        fprintf(logfileptr,"ERROR: %s\n",message);
			        }
                    fprintf(logFilePtrFailure,"Status: Failed.\n");
			        fprintf(logFilePtrFailure,"\n");
                    fprintf(logfileptr,"Status: Failed.\n");
			        fprintf(logfileptr,"\n");
                    goto CLEANUP;
                }
                modify	=	TRUE;

		    }

		    //compare the values
		    if(isRowCntModify || isColCntModify)
		    {
			    ifail=FVE_set_rowColumns(parmValItemRevTag,newRowCnt,newColCnt,false,false,NULL,NULL);
			    //set the initial values
			    if(newValueArray && newValueCnt ==   newRowCnt*newColCnt)
			    {
				    ifail=FVE_create_cells(parmValItemRevTag,newRowCnt,oldRowCnt,newColCnt,oldColCnt,fv9ValuesPROP,newValueArray,NULL,NULL);
			    }else if(newValueArray && newValueCnt == 1)
			    {
				    ifail=FVE_create_cells_MinMaxInit(parmValItemRevTag,newRowCnt,oldRowCnt,newColCnt,oldColCnt,fv9ValuesPROP,newValueArray[0]);
			    }

		    }else
		    {
			    if(isInitValModify == TRUE)
			    {
				    if(newValueArray && newValueCnt ==  oldRowCnt*oldColCnt)
				    {
					    ifail=FVE_set_values(parmValItemRevTag,fv9ValuesPROP,newValueArray,newValueCnt);
				    }
				    else if(newValueArray && newValueCnt ==  1)
				    {
					    ifail=FVE_set_value(parmValItemRevTag,fv9ValuesPROP,newValueArray[0]);
				    }
				    if(ifail != ITK_ok)
				    ifail=ITK_ok;
			    }//isInitValModify

		    }
        }

	/** \par 	5. Update variant expression
	*  \b				5.1 Get variant expression name from valInfoStruct
	*  @n \b 	        5.2 Check if variant expression name exist in structure strVariantInfo (structure initialized after processing the Variant Definition file) and if exists then get variant expression string.
	*  @n \b  	        5.3 If got variant expression string
	*  \li                          then delete variant condition if already exist on parameter value object
	*  \li                          From variant expression string create variant condition and attach on parameter value bom line.

     */
	 
        // update Variant Expression
        varExpCondition = valInfoStruct[Counter].vExprName;
        if(paramValBl && varExpCondition && tc_strlen(varExpCondition) > 0)
        {
            if(totalNoOfvExprs > 0)
            {
                ifail=FV_check_variantCondition_exist(strVariantInfo,varExpCondition,&varExpression);
                if(varExpression && tc_strlen(varExpression)> 0)
                {
                    clauseList			= NULLTAG;
                    TC_write_syslog("variant expression is %s",varExpression);
                    fprintf(logfileptr,"VariantCondition Expression: %s\n",varExpression);

					//Avoid creating variant expressions if there is no change in it 
					isMatchingVarCond = FALSE;
					ITK(FV_check_bomLine_has_matching_variantCondText(paramValBl, varExpression, &isMatchingVarCond))

					//TC_write_syslog("\n VARIANT CONDITION MATCH STATUS => %d", isMatchingVarCond);
					if(isMatchingVarCond == FALSE)
					{			

                    //delete variant condition if alreday exist on parameter value object
                    ITK(FVDT_delete_variant_condition(windowECCTPrj,paramValBl))

                    ITK(BOM_variant_new_clause_list( windowECCTPrj, &clauseList ))
                    ITK(FV_create_clauseList_from_textWithBrackets(windowECCTPrj, clauseList, varExpression))
                    /*
	                    Calling here function to create variant clause list from clause text
	                    This function exist in libfve
                    */
                    //Create a condition from the clauseList expression
                    ITK(BOM_variant_join_clause_list ( clauseList, &condVe ))
                    ITK(BOM_variant_expr_load_if ( condVe, &loadifVe ))

                    ITK(BOM_new_variant_e_block ( &veb ))

                    ITK(BOM_set_variant_e_block ( veb, 1, &loadifVe ))

                    // Set the Variant Expression Block on BOMLine.
                    ITK(BOM_line_set_variant_e_block(paramValBl, veb))
                    

                    // Save Variant Expression.
                    ITK(AOM_save(condVe))

                    // Save load if Variant Expression.
                    ITK(AOM_save(loadifVe))

                    // Save Variant Expression Block.
                    ITK(AOM_save(veb))

                    //Save the BOM window
                    ITK(BOM_save_window(windowECCTPrj))

                    // Delete the clause list
                    ITK(BOM_variant_delete_clause_list ( clauseList ))

                    if(ifail != ITK_ok)
					{
						failureCntParameter++;
						EMH_ask_error_text (ifail, &message);
						fprintf(logfileptr,"ERROR: %s\n",message);
                        fprintf(logfileptr,"Failed to set Variant Condition \n");
						fprintf(logfileptr,"\n");
                        FVE_initialise_failure_log_file(&logFilePtrFailure);
						ifail=FVE_update_log_file(logFilePtrFailure,strParmValInfo,Counter);
						fprintf(logFilePtrFailure,"VariantCondition Expression: %s\n",varExpression);
						fprintf(logFilePtrFailure,"ERROR: %s\n",message);
                        fprintf(logFilePtrFailure,"Failed to set Variant Condition \n");
						fprintf(logFilePtrFailure,"Status: Failed.\n");
						fprintf(logFilePtrFailure,"\n");
                        goto CLEANUP;
					}
                    else
                    {
                        fprintf(logfileptr,"Successfully updated Variant Condition \n");
                    }
					}
                }
            }
        }

        if(modify == TRUE)
		{
			fprintf(logfileptr,"Comment: %s\n","Attributes Updated");
			fprintf(logfileptr,"\n");
			successCntParameter++;
		}else
		{
			fprintf(logfileptr,"Comment: %s\n","No updates in the attribute values during reimport");
			fprintf(logfileptr,"\n");
			successCntParameter++;
		}


	}//flag
CLEANUP:
	FVE_FREE(parmValItemType)
	FVE_FREE(parmValItemName)
	FVE_FREE(parmUsageItemType)
	FVE_FREE_ARRAY(newValueArray,newValueCnt)
	newValueCnt=0;
    FVE_FREE_ARRAY(dummyValArray,dummyValArrayCnt)
    FVE_FREE(varExpression)
    FV_FREE_STRINGS(parmDefDomainElValues)
	FV_FREE_STRINGS(parmDefDomainElNames)
    FVE_FREE(sedVal)
    FVE_FREE(status)
	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;
}

/**
**************************************************************************
*
*  Function Name:   FVE_traverse_paramUsageBomLine
*
*  @desc			Create Parameter Value Object using information from valInfoStr and add it under paramUsageBomLine.
*  @see				In Progress
*
*  @param[in]:      valInfoStruct - structure array where current information of value object is stored
*  @param[in]:      bomLineUsageTag - parameter usage bom line tag
*  @param[in]:      counter - position in structure array
*
*  @return         ITK success/failure ifail.
*
****************************************************************************/
/*Based on the bomLineTag , create Parameter Value Object*/
//int FVE_traverse_paramUsageBomLine(struct FVEParmValInfostruct *valInfoStr, tag_t bomLineUsageTag,int counter,char *name, char *values,char *varExpCondition)
int FVE_traverse_paramUsageBomLine(struct FVEParmValInfostruct *valInfoStr, tag_t bomLineUsageTag,int counter)

{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_traverse_paramUsageBomLine";
	tag_t		itemRevTag			=	NULLTAG;
	tag_t		itemTag				=	NULLTAG;
	char*		itemType			=	NULL;
	char*		itemName			=	NULL;
	tag_t		parmValItem			=	NULLTAG;
	tag_t		parmValRev			=	NULLTAG;
	tag_t		parmValfBl			=	NULLTAG;
	char		*message			=	NULL;
	char		*varExpression		=	NULL;
	tag_t       clauseList			= NULLTAG;
	tag_t       condVe             = NULLTAG;
    tag_t       loadifVe           = NULLTAG;
    tag_t       veb                = NULLTAG;
	char *name	=NULL;
	char *values=NULL;
	char *varExpCondition=NULL;
	char		*time_stamp		=	NULL;
	TC_write_syslog("\n Enter function %s",function_name);

	/** \par 		Steps Followed:
	*/
    /** @par 		1. Get parameter usage details from bom line
	*  @brief			Get the itemTag, itemRevTag, itemType and itemName for parameter usage bom line (i.e.bomLineUsageTag).
    */

	if(bomLineUsageTag)
	{
		//get the  item , itemRevTag and its type
		ITK(AOM_ask_value_tag(bomLineUsageTag,bomAttr_lineItemRevTag,&itemRevTag))
		ITK(AOM_ask_value_tag(bomLineUsageTag,bomAttr_lineItemTag,&itemTag))
		ITK(AOM_ask_value_string(bomLineUsageTag, bomAttr_itemType, &itemType))
		ITK(AOM_ask_value_string(bomLineUsageTag,bomAttr_itemName,&itemName))

	/** @par 		2. Get parameter value and variant expression details from valInfoStr.
	*  @brief			Get the parameter value details (parmValueName, parmValue, vExprName) from structure valInfoStr.
	*             
    */

		name=valInfoStr[counter].parmValueName;
		values=valInfoStr[counter].parmValue;
		varExpCondition=valInfoStr[counter].vExprName;
		//update log file
		if(itemType && tc_strlen(itemType)> 0 )
		{
        //Time Statistics
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		//fprintf(logfileptr,"Start Time To Create Parameter Value :%s\n",time_stamp);

	/** @par 		3. Create parameter value object and add under parent parameter usage object.
	*  @b			3.1 Create parameter value object using function 
	*  @link            FVE_create_parmValObject
	*  @endlink
	*  @n \b		3.2 If parameter value object is created successfully then add this parameter value object under parent.
	*  @n \b		3.3 If failed to create parameter value object then initialize and update failure log file.
    */

		ifail=FVE_create_parmValObject(bomLineUsageTag,name,values,&parmValItem,&parmValRev);
		
		//Time Statistics
		get_time_stamp(DATE_FORMAT_STR, &time_stamp);
		//fprintf(logfileptr,"End Time To Create Parameter Value :%s\n",time_stamp);

		}

		//add this parameter value object below parent.
		if(parmValItem && parmValRev)
		{
			
			if(name && tc_strlen(name)> 0)
			{
				TC_write_syslog("object %s created successfully \n",name);
			}else
			{
				TC_write_syslog("object %s created successfully \n",itemName);
			}
			if(windowECCTPrj && topBlECCTPrj)
			{
				//check bomview exist for this revision or not.
				
				get_time_stamp(DATE_FORMAT_STR, &time_stamp);
				//fprintf(logfileptr,"Start Time To add Parameter Value to usage :%s\n",time_stamp);
	
				ifail=FV_check_bom_views_exist(itemRevTag);
				AM__set_application_bypass(TRUE);
				ITK(BOM_line_add(bomLineUsageTag, NULLTAG, parmValRev, NULLTAG, &parmValfBl))
				ITK(BOM_save_window(windowECCTPrj))
				AM__set_application_bypass(FALSE);
				
				get_time_stamp(DATE_FORMAT_STR, &time_stamp);
				//fprintf(logfileptr,"End Time To add Parameter Value to usage :%s\n",time_stamp);

	/** @par 		4. Set variant condition on newly added parameter value bom line
	*  @brief			 After adding parameter value object under parent set the variant condition on newly added parameter value bom line (i.e.parmValfBl).
	*  @n \b		4.1 Check if variant expression name (varExpCondition) exist in structure strVariantInfo (structure initialized after processing the Variant Definition file) and if exists then get variant expression string.
	*  @n \b		4.2 When no any variant expression found  because of wrong csv file format, update the log file with failure details.
	*  @n \b		4.3 When variant expression found then create variant condition and set it on parameter value bom line.
	*  @n				If failed to set variant condition then update the log file with failure details.
    */

				//Now set the variant condition for parmValfBl
				if(parmValfBl && varExpCondition && tc_strlen(varExpCondition) > 0)
				{
				
				get_time_stamp(DATE_FORMAT_STR, &time_stamp);
				//fprintf(logfileptr,"Start Time To Create Variant Condition :%s\n",time_stamp);

					//get the expression from condition i.e. from varExpCondition
					if(totalNoOfvExprs > 0)
					{
						ifail=FV_check_variantCondition_exist(strVariantInfo,varExpCondition,&varExpression);						
						if(varExpression && tc_strlen(varExpression)> 0)
						{
						    TC_write_syslog("variant expression is %s",varExpression);
							fprintf(logfileptr,"VariantCondition Expression: %s\n",varExpression);
							//delete variant condition if alreday exist on parameter value object
							//ITK(FVDT_delete_variant_condition(windowECCTPrj,parmValfBl))
							clauseList			= NULLTAG;
							ITK(BOM_variant_new_clause_list( windowECCTPrj, &clauseList ))
							/*
								Calling here function to create variant clause list from clause text
								This function exist in libfve
							*/
							ITK(FV_create_clauseList_from_textWithBrackets(windowECCTPrj, clauseList, varExpression))
							//Create a condition from the clauseList expression
							ITK(BOM_variant_join_clause_list ( clauseList, &condVe ))
							ITK(BOM_variant_expr_load_if ( condVe, &loadifVe ))

							ITK(BOM_new_variant_e_block ( &veb ))

							ITK(BOM_set_variant_e_block ( veb, 1, &loadifVe ))
							// Set the Variant Expression Block on BOMLine.
							ITK(BOM_line_set_variant_e_block(parmValfBl, veb))

							// Save Variant Expression.
							ITK(AOM_save(condVe))

							// Save load if Variant Expression.
							ITK(AOM_save(loadifVe))

							// Save Variant Expression Block.
							ITK(AOM_save(veb))

							//Save the BOM window
							ITK(BOM_save_window(windowECCTPrj))

							//Refresh the BOM window
							//ITK(BOM_refresh_window(windowECCTPrj))


							// Delete the clause list
							ITK(BOM_variant_delete_clause_list ( clauseList ))

							if(ifail==ITK_ok)
							{
								successCntParameter++;
								fprintf(logfileptr,"Status: Successful.\n");
								fprintf(logfileptr,"\n");
							}
							if(ifail != ITK_ok)
							{
								failureCntParameter++;
								EMH_ask_error_text (ifail, &message);
								fprintf(logfileptr,"ERROR: %s\n",message);
								if(name && tc_strlen(name)> 0)
								{
									fprintf(logfileptr,"Failed to set Variant Condition for object %s.\n",name);
								}else
								{
									fprintf(logfileptr,"Failed to set Variant Condition for object %s%s.\n",itemName,"_value");
								}
								fprintf(logfileptr,"Status: Failed.\n");
								fprintf(logfileptr,"\n");

								//generate failure log file
								if(logFilePtrFailure == NULL)
								{
									logFilePtrFailure = fopen(file_pathFailure, "w+");
									fprintf(logFilePtrFailure,"Failed parameter List\n");
									fprintf(logFilePtrFailure,"\n");
									fprintf(logFilePtrFailure,"\n");

									if(logfileptr)
									{
										fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
									}
									fprintf(logFilePtrFailure,"Logged in successfully.\n");
									fprintf(logFilePtrFailure,"\n");
									fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
									fprintf(logFilePtrFailure,"\n");
									fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
									fprintf(logFilePtrFailure,"\n");
									fprintf(logFilePtrFailure,"Repository Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
									fprintf(logFilePtrFailure,"\n");
								}
								ifail=FVE_update_log_file(logFilePtrFailure,strParmValInfo,counter);
								fprintf(logFilePtrFailure,"VariantCondition Expression: %s\n",varExpression);
								fprintf(logFilePtrFailure,"ERROR: %s\n",message);
								if(name && tc_strlen(name)> 0)
								{
									fprintf(logFilePtrFailure,"Failed to set Variant Condition for object %s.\n",name);
								}else
								{
									fprintf(logFilePtrFailure,"Failed to set Variant Condition for object %s%s.\n",itemName,"_value");
								}
								fprintf(logFilePtrFailure,"Status: Failed.\n");
								fprintf(logFilePtrFailure,"\n");
							}//ifail != ITK_ok

							
						get_time_stamp(DATE_FORMAT_STR, &time_stamp);
						//fprintf(logfileptr,"End Time To Create Variant Condition :%s\n",time_stamp);
		
						}//varExpression && tc_strlen(varExpression)> 0
						else
						{
							if(ifail==ITK_ok)
							{
								successCntParameter++;
								fprintf(logfileptr,"Status: Successful.\n");
								fprintf(logfileptr,"\n");
							}
						}
					}//totalNoOfvExprs > 0
					else
					{
						/*
						  When no any variant expression found  because of wrong csv file format , update the log file.
						*/
						failureCntParameter++;
						fprintf(logfileptr,"Error: Failed to get Variant Condition/Expression from CSV file.\n");
						fprintf(logfileptr,"Status: Failed.\n");
						fprintf(logfileptr,"\n");
						TC_write_syslog("\n In %s: Added ParmDefBomLine in the Structure ", function_name);

						//generate failure log file
						if(logFilePtrFailure == NULL)
						{
							logFilePtrFailure = fopen(file_pathFailure, "w+");
							fprintf(logFilePtrFailure,"Failed parameter List\n");
							fprintf(logFilePtrFailure,"\n");
							fprintf(logFilePtrFailure,"\n");

							if(logfileptr)
							{
								fprintf(logFilePtrFailure,"Utility name: %s\n\n",exeName);
							}
							fprintf(logFilePtrFailure,"Logged in successfully.\n");
							fprintf(logFilePtrFailure,"\n");
							fprintf(logFilePtrFailure,"Importing User Id/Role: %s%s%s \n",login_user,"/",currentRoleName);
							fprintf(logFilePtrFailure,"\n");
							fprintf(logFilePtrFailure,"ECU Name: %s\n", ecuAcronym);
							fprintf(logFilePtrFailure,"\n");
							fprintf(logFilePtrFailure,"Repository Id/Revision: %s%s%s\n",dicId,"/",dicRevId);
							fprintf(logFilePtrFailure,"\n");
						}
						ifail=FVE_update_log_file(logFilePtrFailure,valInfoStr,counter);
						fprintf(logFilePtrFailure,"Error: Failed to get Variant Condition/Expression from CSV file.\n");
						fprintf(logFilePtrFailure,"Status: Failed.\n");
						fprintf(logFilePtrFailure,"\n");

					}
					
				}//parmValfBl && varExpCondition && tc_strlen(varExpCondition) > 0
				else if(parmValfBl && varExpCondition == NULL)
				{
					successCntParameter++;
					fprintf(logfileptr,"Status: Successful.\n");
					fprintf(logfileptr,"\n");

				}
				
			}//windowECCTPrj && topBlECCTPrj
			//fprintf(logfileptr,"Status: Successful.\n");
			//fprintf(logfileptr,"\n");
		}else
		{
				failureCntParameter++;
				if(name && tc_strlen(name)> 0)
				{
					TC_write_syslog("object %s failed to create \n",name);
				}else
				{
					TC_write_syslog("object %s created successfully \n",itemName);
				}

				EMH_ask_error_text (ifail, &message);
                FVE_initialise_failure_log_file(&logFilePtrFailure);
			    FVE_update_log_file(logFilePtrFailure,valInfoStr,counter);
				/*
				#define FV_CCDM_ERROR_INVALID_ISSIGNED    				(FV_error_base + 79)
				#define FV_CCDM_ERROR_NOT_IN_RANGE       				(FV_error_base + 80)
				#define FV_CCDM_ERROR_INVALID_VALUE       				(FV_error_base + 81)
				#define FV_CCDM_ERROR_VALUE_NOT_ACTUAL_INCREMENT_OF_RES (FV_error_base + 82)
				#define FV_CCDM_ERROR_INSUFFICIENT_INCREMENT            (FV_error_base + 83)
				*/
                if(ifail== 920103)
			    {
				    fprintf(logFilePtrFailure,"ERROR: %s\n","Invalid isSigned Value");
                    fprintf(logfileptr,"ERROR: %s\n","Invalid isSigned Value");
			    }else if(ifail== 920104)
			    {
				    fprintf(logFilePtrFailure,"ERROR: %s\n","Parameter Value is not in range");
                    fprintf(logfileptr,"ERROR: %s\n","Parameter Value is not in range");
			    }else if(ifail== 920105)
			    {
				    fprintf(logFilePtrFailure,"ERROR: %s\n","Invalid Parameter Value");
                    fprintf(logfileptr,"ERROR: %s\n","Invalid Parameter Value");
			    }else if(ifail== 920106)
			    {
				    fprintf(logFilePtrFailure,"ERROR: %s\n","Parameter Value is not in actual increment of resolution");
                    fprintf(logfileptr,"ERROR: %s\n","Parameter Value is not in actual increment of resolution");
			    }
                else if(ifail== 920122)
			    {
				    fprintf(logFilePtrFailure,"ERROR: %s\n","No of rows & columns of Parameter value does not match with Parameter Definition.");
                    fprintf(logfileptr,"ERROR: %s\n","No of rows & columns of Parameter value does not match with Parameter Definition.");
			    }
			    else
			    {
				    fprintf(logFilePtrFailure,"ERROR: %s\n",message);
                    fprintf(logfileptr,"ERROR: %s\n",message);
			    }
                fprintf(logFilePtrFailure,"Status: Failed.\n");
			    fprintf(logFilePtrFailure,"\n");
                fprintf(logfileptr,"Status: Failed.\n");
			    fprintf(logfileptr,"\n");
		}



	}//bomLineUsageTag

	FVE_FREE(itemType)
	FVE_FREE(itemName)
	FVE_FREE(varExpression)
	TC_write_syslog("\n leave function %s",function_name);
	return ifail;
}

/**
**************************************************************************
*
*  Function Name:   FVE_create_parmValObject
*
*  @desc			Create parameter value object based on the bomLineType.
*  @see				In Progress
*
*  @param[in]:      bomLine - bom line tag
*  @param[in]:      name - parameter value name
*  @param[in]:      values - values to be populated on parameter value object
*  @param[out]:		parmValItem - newly created parameter value Item tag.
*  @param[out]:		parmValRevision - newly created parameter value Item Rev tag.
*
*  @return         ITK success/failure ifail.
*
****************************************************************************/

/*Create parameter value Object based on the bomLineType

1.If name is null  autogenerate name as <parametername>_value
2.Whenever "DEFAULT" value is provided ,get the Initial Values from the Initial Values table on the parameter definition (which is the parent for the value object that will be created)
and populate the value object with those values.
3.For SED type parameter_value.csv file gives domain element name as a  value.On Parameter definition object , internally  domain element value get set.So
Before creating parameter value object , get the domain element value from domain element name.


*/
int FVE_create_parmValObject(tag_t bomLine,char *name,char *values,tag_t *parmValItem,tag_t *parmValRevision)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_create_parmValObject";
	tag_t		itemRevTag			=	NULLTAG;
	tag_t		itemTag				=	NULLTAG;
	char*		itemType			=	NULL;
	char*		itemName			=	NULL;
	char*		cellType			=	NULL;
	tag_t		parmDefRev			=	NULLTAG;
	tag_t		strTag				=	NULLTAG;
	tag_t		revisionTag			=	NULLTAG;
    tag_t		strTypeTag			=	NULLTAG;
    tag_t		strRevTypeTag		=	NULLTAG;
	tag_t		createInputTag		=	NULLTAG;
    tag_t		createRevInputTag	=	NULLTAG;
	char		*revTypeName		=	NULL;
	tag_t	tableTypeTag		=	NULLTAG;
	tag_t	tableDefTypeTag		=	NULLTAG;
    tag_t	tableDefInputTag	=	NULLTAG;
	char	* rowCountTable		=	NULL;
	char	* colCountTable		=	NULL;
	char       *rowNumber       =   NULL;
	char       *colNumber       =   NULL;

	int			rows				=	0;
	int			columns				=	0;

    int         parmDefRows         = 0;
    int         parmDefCols         = 0;


	tag_t	tableInputTagValue	=	NULLTAG;
	tag_t	tableCellTypeTag	=	NULLTAG;
	tag_t	tableCellInputTagValue	=	NULLTAG;


	char       intRowBuf[FV_INTEGER_LEN+1] = {'\0'};
	char       intColBuf[FV_INTEGER_LEN+1] = {'\0'};

	tag_t*      cellInputTags = NULL;
	int         cellCnt = 0;

	char	*objName[]				=	{""};
	char	*commaDelimExist		=	NULL;
	char	*semiColonDelimExist	=	NULL;
	int     valueCnt				=	0;
	char	**valueArray			=	NULL;
	int     dummyValArrayCnt	=	0;
	char	**dummyValArray	=	NULL;
	char	*initialValue			=	NULL;
	int			incrCounter =0;
	int iCounter	=0;
	int jCounter	=	0;

	tag_t	tableDefTag			=	NULLTAG;
	logical	 doNotCheckForComma	=FALSE;
	char	**parmDefDomainElValues				=	NULL;
	char	**parmDefDomainElNames				=	NULL;
	int		parmDefDomainElCnt					=	0;
	char	*valueSubstring			=	NULL;
	int		index					=0;
	 char*       indexOfX      = NULL;

	/** \par 		Steps Followed:
	*/
    /** @par 		1. Get parameter usage details from bom line
	*  @brief \b			1.1 Get parameter usage revision (itemRevTag) from parameter usage bom line (i.e. bomLine).
	*  @n \b				1.2 Get the tag of parameter definition revision (parmDefRev) stored on parameter usage revision (itemRevTag).
	*  @n \b				1.3 Get the itemTag, itemType, itemName from parameter usage bom line (i.e. bomLine).
	*/
	
	TC_write_syslog("\n Enter function %s",function_name);
	if(bomLine)
	{
		ITK(AOM_ask_value_tag(bomLine,bomAttr_lineItemRevTag,&itemRevTag))
		if(itemRevTag)
		{
			//get the tag of parameter definition stored on this usage revision
			ITK(AOM_ask_value_tag(itemRevTag,fv9RefParmDefRevPROP,&parmDefRev))
		}
		ITK(AOM_ask_value_tag(bomLine,bomAttr_lineItemTag,&itemTag))
		ITK(AOM_ask_value_string(bomLine, bomAttr_itemType, &itemType))
		ITK(AOM_ask_value_string(bomLine,bomAttr_itemName,&itemName))
		
	/** @par 		2. Decide parameter value object name
	*  @brief			If name is valid then use the given name else autogenerate name as <parametername>_value.
    */

		if(name && tc_strlen(name)> 0)
		{
			
			(*objName) = (char*) MEM_alloc((int) (tc_strlen(name)+1)* sizeof(char));
			 tc_strcpy((*objName),name);
		}else
		{
			(*objName) = (char *)MEM_alloc((int) sizeof(char)*(tc_strlen(itemName)+tc_strlen("_")+tc_strlen("value")+1));
			tc_strcpy((*objName),itemName);
			tc_strcat((*objName),"_");
			tc_strcat((*objName),"value");
		}
		
	/** @par 		3. Get the rows and columns based on the values
	*  @brief \b			3.1 If values == DEFAULT then
	*/
	/** @par
	*  @li \b					3.1.1 If itemType == FV9ParmDfSEDUsg then 
	*  @n 								initialValue = 'initialValue' property stored on parameter definition rev (parmDefRev)
	*  @li \b					3.1.2 Else 
	*  @n								parmDefCols = 'cols' property value stored on tableDefinition of parameter definition revision.
    *  @n   	                        parmDefRows = 'rows' property value stored on tableDefinition of parameter definition revision.
	*  @n								valueCnt = 	parmDefRows * parmDefCols
	*/
	/**
	*  @brief \b			3.2 Else
	*  @n 						parmDefCols = 'cols' property value stored on tableDefinition of parameter definition revision.
    *  @n 	                    parmDefRows = 'rows' property value stored on tableDefinition of parameter definition revision.
	*  @li \b					3.2.1 If semicolon(;) exists in 'values'
	*  @n							  then doNotCheckForComma=TRUE and split the string 'values' using ";" 
	*  @n \b                          3.2.1.1 rows= count of splited strings
	*  @n \b						  3.2.1.2 For each delimited string check 
	*  @n \b									3.2.1.2.1 If delimitted string contains comma(,)
	*  @n													then split the string using "," and get the valueCnt and valueArray.
	*  @n													columns=valueCnt
	*  @n \b									3.2.1.2.2 Else
	*  @n													split the string using "' '" and get the valueCnt and valueArray.
	*  @li \b					3.2.2 If(doNotCheckForComma == FALSE)
	*  @n \b							3.2.2.1 If comma(,) exists in 'values'
	*  @n										then then split the string using "," and get the valueCnt and valueArray.
	*  @n										rows=1
	*  @n										columns=valueCnt
	*  @n \b							3.2.2.2 Else
	*  @n										rows=1
	*  @n										columns=1
	*  @n										valueCnt=rows*columns
	*  @n \b									3.2.2.2.1 If itemType == FV9ParmDfSEDUsg then
	*  @n													get the domain element values from parameter definition revision
	*  @n													Find matching domain element name with values and copy domain element value to valueArray[0]
	*  @n \b									3.2.2.2.2 Else copy 'values' to valueArray[0]                 
    */

		//get the rows and columns based on the values
		/*
			if values contains comma it means one row and any number of columns
			if values didnt contains comma , it means one row and one column
			if values contains semicolon , it means multiple rows and multiple columns
		*/
		if(values && tc_strlen(values)> 0)
		{

			if( values && tc_strlen(values)> 0 && tc_strcmp(FV_trim_blanks(values),DEFAULTValue)==0)
			{
				//get the row,column , initial values from  parmDefRev
				if(parmDefRev)
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
					if(itemType && tc_strlen(itemType)> 0)
					{
						if(tc_strcmp(itemType,FV9ParmDfSEDUsgTYPE)==0)
						{
							//get the in itial value for SED type
							//ITK(FVE_get_value_arrays(parmDefRev, validValuesPROP,&valueArray));
							ITK(AOM_ask_value_string(parmDefRev, initialValuePROP, &initialValue))

						}else
						{
							ITK(FVE_get_value_arrays(parmDefRev,initialValuesPROP,&valueArray))
							//get the count for rows and column
							if(tableDefTag)
							{
								ITK(AOM_ask_value_int(tableDefTag, colsPROP, &columns));
								ITK(AOM_ask_value_int(tableDefTag, rowsPROP, &rows));
                                parmDefCols = columns;
                                parmDefRows = rows;
								valueCnt = rows*columns;
							}
						}
					}
				}
			}else
			{
				if(parmDefRev)
                {
                    ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
                    if(tableDefTag)
                    {
                        ITK(AOM_ask_value_int(tableDefTag, colsPROP, &parmDefCols));
					    ITK(AOM_ask_value_int(tableDefTag, rowsPROP, &parmDefRows));
                    }
                }
                semiColonDelimExist=strstr(FV_trim_blanks(values),SEMICOLON_DELIM);
				if(semiColonDelimExist)
				{
					doNotCheckForComma=TRUE;
					split_the_string(FV_trim_blanks(values),SEMICOLON_DELIM,&dummyValArrayCnt,&dummyValArray);
					//semiColonDelimExist=NULL;
					if(dummyValArrayCnt > 0 && dummyValArray)
					{
						rows=dummyValArrayCnt;
						for(iCounter=0;iCounter<dummyValArrayCnt;iCounter++)
						{
								commaDelimExist=strstr(FV_trim_blanks(dummyValArray[iCounter]),COMMA_DELIM);
								if(commaDelimExist)
								{
									split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),COMMA_DELIM,&valueCnt,&valueArray);
									if(iCounter==0)
									{
										columns=valueCnt;
									}
									commaDelimExist=NULL;
								}else
								{
									split_the_string(FV_trim_invalidChars(dummyValArray[iCounter]),"' '",&valueCnt,&valueArray);
								}
						}//for
					}
				}
				if(doNotCheckForComma == FALSE)
				{
					commaDelimExist=strstr(FV_trim_blanks(values),COMMA_DELIM);
					if(commaDelimExist)
					{
						split_the_string(FV_trim_invalidChars(values),COMMA_DELIM,&valueCnt,&valueArray);
						rows=1;
						columns=valueCnt;
					}else
					{
						rows=1;
						columns=1;
						valueCnt=rows*columns;
						valueArray = (char **)MEM_alloc( 1 * sizeof(char *));
						valueArray[0] = (char *)MEM_alloc( (strlen(values) + 1) * sizeof(char ));
						if(tc_strcmp(itemType,FV9ParmDfSEDUsgTYPE)==0)
						{
							//get the domain element value from domain element name
							if(parmDefRev)
							{
								//get the domain element values
								ITK(FVE_get_value_arrays(parmDefRev, validValuesPROP,&parmDefDomainElValues));
								//get the domain element name
								ITK(FVE_get_desc_array(parmDefRev, validValuesPROP,"desc",&parmDefDomainElNames,&parmDefDomainElCnt));
								for(iCounter =0; iCounter<parmDefDomainElCnt ; iCounter++)
								{
									if(values && parmDefDomainElNames[iCounter] && tc_strlen(parmDefDomainElNames[iCounter])> 0 && tc_strlen(values)> 0)
									{
										if( tc_strcmp(FV_trim_blanks(values),FV_trim_blanks(parmDefDomainElNames[iCounter])) == 0)
										{
											tc_strcpy((valueArray)[0],parmDefDomainElValues[iCounter]);
											break;
										}
									}
								}//for
							}//parmDefRev
						}else
						{
							tc_strcpy((valueArray)[0],FV_trim_blanks(values));
						}
					}
				}
			}//else
		}//values

	/** @par 		4. Check rows and columns
	*  @brief			If number of rows & columns of Parameter value does not match with Parameter Definition then log error and exit.
	*/

        if((rows > 1 || columns > 1) && (rows != parmDefRows || columns != parmDefCols ))
        {
            ifail = FV_CCDM_ERROR_INVALID_LENGTH;
            TC_write_syslog("\nNo of rows & columns of Parameter value does not match with Parameter Definition.\n");
            goto CLEANUP;
        }

	/** @par 		5. Create parameter value object and set properties
	*  @brief \b		5.1 Depending on parameter usage item type (itemType) decide parameter value type, parameter value rev type and cellType to be created.
	*  @n \b			5.2 Construct CreateInput object to hold input data for creation of parameter value object.
	*  @n \b			5.3 Construct table definition type create input object and set properties 'rows' and 'cols' using parmDefRows and parmDefCols respectively.
	*  @n \b			5.4 Construct table type create input object, create cells and set cell values.
	*  @n \b			5.5 Set item revision attributes fv9Values, fv9TableDefinition and fv9RefParmDefRev.
	*  @n \b			5.6 Create and save parameter value object.
	*/

		// create item
		if(itemType && tc_strlen(itemType)> 0)
		{
			if(tc_strcmp(itemType,FV9ParmDfStrUsgTYPE)==0)
			{
				ITK(TCTYPE_ask_type(FV9ParmValStrTYPE, &strTypeTag))
				ITK(FV_strdup_plus(FV9ParmValStrTYPE, 9, &revTypeName))
				tc_strcat(revTypeName, "Revision");
				ITK(TCTYPE_ask_type(revTypeName, &strRevTypeTag))
				cellType=TableCellStringCLASS;
			}
			if(tc_strcmp(itemType,FV9ParmDfHexUsgTYPE)==0)
			{
				ITK(TCTYPE_ask_type(FV9ParmValHexTYPE, &strTypeTag))
				ITK(FV_strdup_plus(FV9ParmValHexTYPE, 9, &revTypeName))
				tc_strcat(revTypeName, "Revision");
				ITK(TCTYPE_ask_type(revTypeName, &strRevTypeTag))
				cellType=TableCellHexCLASS;
			}
			if(tc_strcmp(itemType,FV9ParmDfSEDUsgTYPE)==0)
			{
				ITK(TCTYPE_ask_type(FV9ParmValSEDTYPE, &strTypeTag))
				ITK(FV_strdup_plus(FV9ParmValSEDTYPE, 9, &revTypeName))
				tc_strcat(revTypeName, "Revision");
				ITK(TCTYPE_ask_type(revTypeName, &strRevTypeTag))
				cellType=TableCellSEDCLASS;
			}
			if(tc_strcmp(itemType,FV9ParmDfIntUsgTYPE)==0)
			{
				ITK(TCTYPE_ask_type(FV9ParmValIntTYPE, &strTypeTag))
				ITK(FV_strdup_plus(FV9ParmValIntTYPE, 9, &revTypeName))
				tc_strcat(revTypeName, "Revision");
				ITK(TCTYPE_ask_type(revTypeName, &strRevTypeTag))
				cellType=TableCellIntCLASS;
			}
			if(tc_strcmp(itemType,FV9ParmDfDblUsgTYPE)==0)
			{
				ITK(TCTYPE_ask_type(FV9ParmValDblTYPE, &strTypeTag))
				ITK(FV_strdup_plus(FV9ParmValDblTYPE, 9, &revTypeName))
				tc_strcat(revTypeName, "Revision");
				ITK(TCTYPE_ask_type(revTypeName, &strRevTypeTag))
				cellType=TableCellDoubleCLASS;
			}
		}
		//create Item and revision
		if(strTypeTag && strRevTypeTag)
		{
			ITK(TCTYPE_construct_create_input(strTypeTag, &createInputTag))
			ITK(TCTYPE_construct_create_input(strRevTypeTag, &createRevInputTag))
			// set revision
			if(createInputTag && createRevInputTag)
				ITK(TCTYPE_set_compound_objects(createInputTag, "revision", 1, &createRevInputTag))
		}

		// set item attribute
		if(createInputTag)
		{
			ITK(TCTYPE_set_create_display_value(createInputTag, object_namePROP, 1, (const char**)objName))
		}

		//TC_write_syslog("Creating table def\n");
		// create table definition
		ITK(TCTYPE_ask_type("TableDefinition", &tableDefTypeTag))
		ITK(TCTYPE_construct_create_input(tableDefTypeTag, &tableDefInputTag))
		rowCountTable = (char*)MEM_alloc((int)(rows + 1) * sizeof(char));
		colCountTable = (char*)MEM_alloc((int)(columns + 1) * sizeof(char));
		sprintf(rowCountTable, "%d", parmDefRows);
		sprintf(colCountTable, "%d", parmDefCols );
		ITK(TCTYPE_set_create_display_value(tableDefInputTag, "rows", 1, (const char**)&rowCountTable))
		ITK(TCTYPE_set_create_display_value(tableDefInputTag, "cols", 1, (const char**)&colCountTable))
		//free memory
		FVE_FREE(rowCountTable)
		FVE_FREE(colCountTable)

		ITK(TCTYPE_ask_type("Table", &tableTypeTag))
		//set the values values for table
		ITK(TCTYPE_construct_create_input(tableTypeTag, &tableInputTagValue))
		for(iCounter=0;iCounter<parmDefRows;iCounter++)
		{
			sprintf(intRowBuf, "%d",iCounter);
   			rowNumber = intRowBuf;
			//TC_write_syslog ("rowNumber = %s\n",rowNumber);
			for(jCounter=0;jCounter<parmDefCols;jCounter++)
			{
				sprintf(intColBuf, "%d",jCounter);
   				colNumber = intColBuf;
				//TC_write_syslog ("colNumber = %s\n",colNumber);
				// create table cell
				ITK(TCTYPE_ask_type(cellType, &tableCellTypeTag))
				ITK(TCTYPE_construct_create_input(tableCellTypeTag, &tableCellInputTagValue))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagValue, "row", 1,(const char **)&rowNumber))
				ITK(TCTYPE_set_create_display_value(tableCellInputTagValue, "col", 1, (const char **)&colNumber))
				if(tc_strcmp(itemType,FV9ParmDfHexUsgTYPE)==0)
				{
					// ValueCnt can be 1 , when same parameter value is set in all cells
                    if(valueArray && (valueCnt == parmDefRows*parmDefCols || valueCnt == 1))
					{
						//check if value starting with prefix "0x"
						indexOfX=NULL;
						indexOfX=strchr(valueArray[incrCounter],'x');
						if(indexOfX != NULL)
						{
							index = (int)(indexOfX - valueArray[incrCounter]);
							valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(valueArray[incrCounter])+1));
							sprintf(valueSubstring,"%s",&(valueArray[incrCounter])[index+1]);
							if(valueSubstring && strlen(valueSubstring)> 0)
							{
								ITK(TCTYPE_set_create_display_value(tableCellInputTagValue, "value",1,(const char **)&valueSubstring))
							}
							FVE_FREE(valueSubstring)
							index=0;
                            // same parameter value is set in all cells
                            if(valueCnt != 1)
							    incrCounter++;	
						}//indexOfX
					}
				}else
				{
					// ValueCnt can be 1 , when same parameter value is set in all cells
                    if(valueArray && (valueCnt == parmDefRows*parmDefCols || valueCnt == 1))
					{
						ITK(TCTYPE_set_create_display_value(tableCellInputTagValue, "value",1,(const char **)&valueArray[incrCounter]))
                        if(valueCnt != 1)
						    incrCounter++;
					}
				}
				// Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTagValue))
			}
		}
		ITK(TCTYPE_set_compound_objects(tableInputTagValue, "definition", 1, &tableDefInputTag))
		// Set array of Table Cell input tags on Table object.
		ITK(TCTYPE_set_compound_objects(tableInputTagValue, "cells", cellCnt, cellInputTags))
		FVE_FREE(cellInputTags)
		cellCnt=0;
		incrCounter=0;

		TC_write_syslog("Setting item revision compound objects\n");
		//set revision attribute
		if(itemType && tc_strlen(itemType)> 0)
		{
			if(tc_strcmp(itemType,FV9ParmDfSEDUsgTYPE)==0)
			{
				if(initialValue && tc_strlen(initialValue)>0)
				{
					ITK(TCTYPE_set_create_display_value(createRevInputTag, fv9ValuesPROP, 1,(const char **)&initialValue))
				}
				else if((valueArray)[0] && tc_strlen((valueArray)[0])> 0)
				{
					ITK(TCTYPE_set_create_display_value(createRevInputTag, fv9ValuesPROP, 1,(const char **)&valueArray[0]))
				}
			}else
			{
				ITK(TCTYPE_set_compound_objects(createRevInputTag, fv9ValuesPROP, 1, &tableInputTagValue))
				ITK(TCTYPE_set_compound_objects(createRevInputTag, fv9TableDefinitionPROP, 1, &tableDefInputTag))
			}
		}//else
		//{
			//ITK(TCTYPE_set_compound_objects(createRevInputTag, fv9ValuesPROP, 1, &tableInputTagValue))
			//ITK(TCTYPE_set_compound_objects(createRevInputTag, fv9TableDefinitionPROP, 1, &tableDefInputTag))
		//}
		ITK(TCTYPE_set_compound_objects(createRevInputTag, fv9RefParmDefRevPROP, 1,&parmDefRev))

		 ITK(TCTYPE_create_object(createInputTag, &strTag))
		if(strTag)
		{
			ITK(AOM_save_with_extensions(strTag))
			ITK(AOM_refresh(strTag, false) )
			*parmValItem=strTag;

			// Get the new item revision tag.
			ITK(ITEM_ask_latest_rev(strTag, &revisionTag))
			if(revisionTag != NULLTAG)
			{
				*parmValRevision=revisionTag;
			}
		}

	}//bomLine

CLEANUP:
    FVE_FREE(itemType)
	FVE_FREE(itemName)
	FVE_FREE(initialValue)
	FVE_FREE_ARRAY(valueArray,valueCnt)
	valueCnt=0;
	FVE_FREE_ARRAY(dummyValArray,dummyValArrayCnt)
	dummyValArrayCnt=0;
	FVE_FREE(*objName);
	FVE_FREE(parmDefDomainElValues)
	FVE_FREE(parmDefDomainElNames)
	parmDefDomainElCnt=0;
	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;
}
void FVE_MemFreeStructVariant(struct FVEVariantInfostruct *variantStruct)
{
	TC_write_syslog("Start of FVE_MemFreeStructVariant \n");
	FVE_FREE(variantStruct->vCondExpr);
	FVE_FREE(variantStruct->vCondName);
	FVE_FREE(variantStruct);

	TC_write_syslog("End of FVE_MemFreeStructVariant \n");
}

void FVE_initialize_VariantStructure(struct FVEVariantInfostruct * variantStruct)
{
	TC_write_syslog("Start of FVE_initialize_VariantStructure \n");
	variantStruct->vCondExpr=NULL;
	variantStruct->vCondName=NULL;

	TC_write_syslog("End of FVE_initialize_VariantStructure \n");
}

void FVE_initialize_ParmValStructure(struct FVEParmValInfostruct * parmValReportStruct)
{
	TC_write_syslog("Start of FVE_initialize_ParmValStructure \n");

	parmValReportStruct->parmName=NULL;
	parmValReportStruct->parmRevId=NULL;
	parmValReportStruct->parmValue=NULL;
	parmValReportStruct->parmValueName=NULL;
	parmValReportStruct->vExprName=NULL;
	TC_write_syslog("End of FVE_initialize_ParmValStructure \n");
}
void FVE_MemFreeStructParameterVal(struct FVEParmValInfostruct *parmReportStruct)
{

	TC_write_syslog("Start of FVE_MemFreeStructParameterVal \n");
	FVE_FREE(parmReportStruct->parmName);
	FVE_FREE(parmReportStruct->parmRevId);
	FVE_FREE(parmReportStruct->parmValue);
 	FVE_FREE(parmReportStruct->parmValueName);
	FVE_FREE(parmReportStruct->vExprName);
	FVE_FREE(parmReportStruct);
	TC_write_syslog("End of FVE_MemFreeStructParameterVal \n");

}

void FVE_MemFreeStructConfigFile(struct FVEConfigFileInfostruct *configInfoStruct)
{

	TC_write_syslog("Start of FVE_MemFreeStructConfigFile \n");
	FVE_FREE(configInfoStruct->constantName);
	FVE_FREE(configInfoStruct->csvFileDelim);
	FVE_FREE(configInfoStruct->lofFileName);
	FVE_FREE(configInfoStruct->logFileExt);
	FVE_FREE(configInfoStruct->logFilePath);
	FVE_FREE(configInfoStruct->tolerance);
	FVE_FREE(configInfoStruct);

	TC_write_syslog("End of FVE_MemFreeStructConfigFile \n");
}

void FVE_initialize_ConfigFiletructure(struct FVEConfigFileInfostruct * configInfoStruct)
{
	TC_write_syslog("Start of FVE_initialize_ConfigFiletructure \n");
	configInfoStruct->constantName=NULL;
	configInfoStruct->csvFileDelim=NULL;
	configInfoStruct->lofFileName=NULL;
	configInfoStruct->logFileExt=NULL;
	configInfoStruct->logFilePath=NULL;
	configInfoStruct->tolerance=NULL;
	TC_write_syslog("End of FVE_initialize_ConfigFiletructure \n");
}

/*
Function to parse the configuration file
*/
int fve_parse_configFile(FILE *configFlPtr,char *delim,struct FVEConfigFileInfostruct *configInfo)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"FVE_parse_configFile";
	int			totalCnt			=	0;
	char        *ptr				=	0;
	char*		line_temp			=	NULL;
	char		*copyStr			=	NULL;
	char        line_in[MAX_STRCT]	=	"";
	int			line_count			=	0;

	char *constName =NULL;
	char *constValue =NULL;


	TC_write_syslog("\n Enter function %s",function_name);
	if ( configFlPtr != 0)
	{

		line_count = 0;
		while (fgets(line_in, MAX_STRCT, configFlPtr) != 0)
		{

			int     len							=	0;
			logical lgIncrCount					=	FALSE;
			logical is_constName_null			=	FALSE;
			logical is_constValue_null			=	FALSE;
			logical is_lgFlName_null			=	FALSE;
			logical is_lgFlPath_null			=	FALSE;
			logical is_lgFlExt_null				=	FALSE;

			if(line_in && tc_strlen(line_in)> 0)
			{
				copyStr=FV_trim_blanks(line_in);
				len = tc_strlen(copyStr);
				if(len > 0)
				{
					ITK(fv_strdup(copyStr, &line_temp))
				}
			}

			if ( len == 0 )
					continue;
			line_count++;

			if (len > 0 && copyStr[len-1] == '\n')
					copyStr[len-1] = '\0';


			if(delim != NULL && tc_strlen(delim)> 0)
			{
				//get constant name i.e. Log File Name
				ptr = tc_strtok(copyStr,delim);
				fve_get_value(ptr, &constName, &is_constName_null);
				if(is_constName_null == FALSE)
				{
					configInfo[totalCnt].constantName= (char*) MEM_alloc((int) (strlen(constName)+1)* sizeof(char));
					strcpy(configInfo[totalCnt].constantName,FV_trim_blanks(constName));
				}
				//get the constant value
				ptr = tc_strtok(NULL,delim);
				fve_get_value(ptr, &constValue, &is_constValue_null);
				if(is_constValue_null == FALSE)
				{
					if( (configInfo[totalCnt].constantName != NULL) && (tc_strlen(configInfo[totalCnt].constantName)> 0))
					{
						if( tc_strcmp(configInfo[totalCnt].constantName,LOG_FILE_NAME)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].lofFileName= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].lofFileName,FV_trim_blanks(constValue));
						}
						else if( tc_strcmp(configInfo[totalCnt].constantName,LOG_FILE_PATH)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].logFilePath= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].logFilePath,FV_trim_blanks(constValue));

						}else if( tc_strcmp(configInfo[totalCnt].constantName,LOG_FILE_EXTENSION)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].logFileExt= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].logFileExt,FV_trim_blanks(constValue));
						}else if( tc_strcmp(configInfo[totalCnt].constantName,CCM_CSV_FILE_DELIMITER)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].csvFileDelim= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							csvConfigFileDelimeter=(char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].csvFileDelim,FV_trim_blanks(constValue));
							strcpy(csvConfigFileDelimeter,FV_trim_blanks(constValue));
						}else if( tc_strcmp(configInfo[totalCnt].constantName,CCM_TOLERANCE_VALUE)== 0)
						{
							lgIncrCount=TRUE;
							configInfo[totalCnt].tolerance= (char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							toleranceExistInConfigFile=(char*) MEM_alloc((int) (strlen(FV_trim_blanks(constValue))+1)* sizeof(char));
							strcpy(configInfo[totalCnt].tolerance,FV_trim_blanks(constValue));
							strcpy(toleranceExistInConfigFile,FV_trim_blanks(constValue));
						}
					}
				}
				FVE_FREE(line_temp)
				copyStr=NULL;
				if(lgIncrCount == TRUE)
						totalCnt++;
			}// delim != null
			//free memory
			FVE_FREE(constName)
			FVE_FREE(constValue)
		}//while
	}//if


	TC_write_syslog("\n Leave function %s",function_name);
	return totalCnt;
}

/*Parse parameter value file*/
int FVE_parse_parmValFile(FILE *flPtrProcess,char *delim,struct FVEParmValInfostruct *parmValueInfo)
{
		int         ifail					=	ITK_ok;
		char*       function_name			=	"FVE_parse_parmValFile";
		char        *ptr					=	0;
		char*		line_temp				=	NULL;
		char        line_in[MAX_STRCT]		=	"";
		int			line_count				=	0;
		char		*copyStr				=	NULL;
		char		*prName					=	NULL;
		char		*prRevId				=	NULL;
		char		*parValue				=	NULL;
		char		*parValueName				=	NULL;
		char		*varCond				=	NULL;
		char		*prRevIdLoc				=	NULL;
		char		*parValueLoc			=	NULL;
		char		*parValueNameLoc		=	NULL;
		char		*varCondLoc				=	NULL;
		char		*remPartAfterPrName		=	NULL;
		char		*remPartAfterPrRevId	=	NULL;
		char		*remPartAfterParValue	=	NULL;
		char		*remPartAfterParValueName	=	NULL;
		char		*remPartAfterVarCond	=	NULL;
		int			totalCnt			=	0;

		TC_write_syslog("\n Enter function %s",function_name);

		if (flPtrProcess != 0)
		{
			fprintf(logfileptr,"Start Processing Parameter value File...\n");
			fprintf(logfileptr,"\n");
			line_count = 0;
			while (fgets(line_in, MAX_STRCT, flPtrProcess) != 0)
			{
				int     len						=	0;
				logical lgIncrCount				=	FALSE;

				if(line_in && tc_strlen(line_in) > 0)
				{
					copyStr=FV_trim_blanks(line_in);
					len = tc_strlen(copyStr);
					if(len > 0)
					{
						ITK(fv_strdup(copyStr, &line_temp))
					}
				}
				if (len == 0)
					continue;

				line_count++;

				if (len > 0 && line_temp[len-1] == '\n')
				{
					line_temp[len-1] = '\0';
				}


				if(delim != NULL && tc_strlen(delim)> 0)
				{
					// Parameter Name
					char *prNameLoc =strstr(copyStr, delim);
					if(prNameLoc != NULL)
					{
						ifail=fve_get_val_line(delim,copyStr,prNameLoc,&prName,&remPartAfterPrName);
						if(prName && tc_strlen(prName) > 0)
						{
							lgIncrCount=TRUE;
							parmValueInfo[totalCnt].parmName= (char*) MEM_alloc((int) (strlen(prName)+1)* sizeof(char));
							strcpy(parmValueInfo[totalCnt].parmName,FV_trim_invalidChars(FV_trim_blanks(prName)));
						}
					}

					//Rev ID
					if(remPartAfterPrName && tc_strlen(remPartAfterPrName)> 0)
					{
						prRevIdLoc=strstr(FV_trim_blanks(remPartAfterPrName),delim);
						if(prRevIdLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterPrName),FV_trim_blanks(prRevIdLoc),&prRevId,&remPartAfterPrRevId);
							if(prRevId && tc_strlen(prRevId)> 0)
							{
								parmValueInfo[totalCnt].parmRevId= (char*) MEM_alloc((int) (strlen(prRevId)+1)* sizeof(char));
								strcpy(parmValueInfo[totalCnt].parmRevId,FV_trim_blanks(prRevId));
							}
						}
					}

					//parameter values
					if(remPartAfterPrRevId && tc_strlen(remPartAfterPrRevId)> 0)
					{
						parValueLoc=strstr(FV_trim_blanks(remPartAfterPrRevId),delim);
						if(parValueLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterPrRevId),FV_trim_blanks(parValueLoc),&parValue,&remPartAfterParValue);
							if(parValue && tc_strlen(parValue)> 0)
							{
								parmValueInfo[totalCnt].parmValue= (char*) MEM_alloc((int) (strlen(parValue)+1)* sizeof(char));
								strcpy(parmValueInfo[totalCnt].parmValue,FV_trim_blanks(parValue));
							}
						}
					}

					//Value Name
					if(remPartAfterParValue && tc_strlen(remPartAfterParValue)> 0)
					{
						parValueNameLoc=strstr(FV_trim_blanks(remPartAfterParValue),delim);
						if(parValueNameLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParValue),FV_trim_blanks(parValueNameLoc),&parValueName,&remPartAfterParValueName);
							if(parValueName && tc_strlen(parValueName)> 0)
							{
								parmValueInfo[totalCnt].parmValueName= (char*) MEM_alloc((int) (strlen(parValueName)+1)* sizeof(char));
								strcpy(parmValueInfo[totalCnt].parmValueName,FV_trim_blanks(parValueName));
							}
                            // If name is not specified in value csv file, then form name = <parameter name>_value
                            else if(parmValueInfo[totalCnt].parmName && tc_strlen(parmValueInfo[totalCnt].parmName) > 0)
                            {
                                parmValueInfo[totalCnt].parmValueName= (char*) MEM_alloc( ((int)(tc_strlen(parmValueInfo[totalCnt].parmName) 
                                    + tc_strlen("_")+tc_strlen("value"))+1)* sizeof(char));
                                tc_strcpy(parmValueInfo[totalCnt].parmValueName,FV_trim_blanks(parmValueInfo[totalCnt].parmName));
                                tc_strcat(parmValueInfo[totalCnt].parmValueName,"_");
                                tc_strcat(parmValueInfo[totalCnt].parmValueName,"value");
                            }
						}
					}

					//Variant Expression
					if(remPartAfterParValueName && tc_strlen(remPartAfterParValueName)> 0)
					{
						varCondLoc=strstr(FV_trim_blanks(remPartAfterParValueName),delim);
						if(varCondLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterParValueName),FV_trim_blanks(varCondLoc),&varCond,&remPartAfterVarCond);
							if(varCond && tc_strlen(varCond)> 0)
							{
								parmValueInfo[totalCnt].vExprName= (char*) MEM_alloc((int) (strlen(varCond)+1)* sizeof(char));
								strcpy(parmValueInfo[totalCnt].vExprName,FV_trim_blanks(varCond));
							}
						}else
						{
							parmValueInfo[totalCnt].vExprName= (char*) MEM_alloc((int)(strlen(remPartAfterParValueName)+1)* sizeof(char));
							strcpy(parmValueInfo[totalCnt].vExprName,FV_trim_blanks(remPartAfterParValueName));
						}
					}else
					{
						parmValueInfo[totalCnt].vExprName=NULL;
					}


					if(lgIncrCount == TRUE)
						totalCnt++;
					FVE_FREE(line_temp)
					copyStr=NULL;
				}//if delim != null
				//free memory
				FVE_FREE(prName)
				FVE_FREE(prRevId)
				FVE_FREE(parValue)
				FVE_FREE(parValueName)
				FVE_FREE(varCond)

				FVE_FREE(remPartAfterPrName);
				FVE_FREE(remPartAfterPrRevId);
				FVE_FREE(remPartAfterParValue);
				FVE_FREE(remPartAfterParValueName);
				FVE_FREE(remPartAfterVarCond);
			}//while
		}//flPtrProcess != 0
		TC_write_syslog("\n Leave function %s",function_name);
	    return totalCnt;
}


/*Parse variant expression file to get variant expression condition and variant expression name*/
int FVE_parse_variantFile(FILE *flPtrProcess,char *delim,struct FVEVariantInfostruct *variantInfo)
{

		int         ifail					=	ITK_ok;
		char*       function_name			=	"FVE_parse_variantFile";
		char        *ptr					=	0;
		char*		line_temp				=	NULL;
		char        line_in[MAX_STRCT]		=	"";
		int			line_count				=	0;
		char		*copyStr				=	NULL;
		char		*varCondExpr			=	NULL;
		char		*varCondName			=	NULL;

		char		*remPartAfterVarCondExpr		=	NULL;
		char		*remPartAfterVarCondName		=	NULL;
		char		*varCondExprLoc			=	NULL;
		char		*varCondNameLoc				=	NULL;

		int			totalCnt			=	0;

		TC_write_syslog("\n Enter function %s",function_name);

		if (flPtrProcess != 0)
		{
			fprintf(logfileptr,"Start Processing Variant Definition File...\n");
			fprintf(logfileptr,"\n");
			line_count = 0;
			while (fgets(line_in, MAX_STRCT, flPtrProcess) != 0)
			{
				int     len						=	0;
				logical lgIncrCount				=	FALSE;

				if(line_in && tc_strlen(line_in) > 0)
				{
					copyStr=FV_trim_blanks(line_in);
					len = tc_strlen(copyStr);
					if(len > 0)
					{
						ITK(fv_strdup(copyStr, &line_temp))
					}
				}
				if (len == 0)
					continue;

				line_count++;

				if (len > 0 && line_temp[len-1] == '\n')
				{
					line_temp[len-1] = '\0';
				}


				if(delim != NULL && tc_strlen(delim)> 0)
				{
					// Get the Variant Expression string
					char *varCondExprLoc =strstr(copyStr, delim);
					if(varCondExprLoc)
					{
						ifail=fve_get_val_line(delim,copyStr,varCondExprLoc,&varCondExpr,&remPartAfterVarCondExpr);
						if(varCondExpr && tc_strlen(varCondExpr) > 0)
						{
							lgIncrCount=TRUE;
							variantInfo[totalCnt].vCondExpr= (char*) MEM_alloc((int) (strlen(varCondExpr)+1)* sizeof(char));
							strcpy(variantInfo[totalCnt].vCondExpr,FV_trim_blanks(varCondExpr));
						}
					}


					//Get the Variant Expression Name
					if(remPartAfterVarCondExpr && tc_strlen(remPartAfterVarCondExpr)> 0)
					{
						varCondNameLoc=strstr(FV_trim_blanks(remPartAfterVarCondExpr),delim);
						if(varCondNameLoc)
						{
							ifail=fve_get_val_line(delim,FV_trim_blanks(remPartAfterVarCondExpr),FV_trim_blanks(varCondNameLoc),&varCondName,&remPartAfterVarCondName);
							if(varCondName && tc_strlen(varCondName)> 0)
							{
								variantInfo[totalCnt].vCondName= (char*) MEM_alloc((int) (strlen(varCondName)+1)* sizeof(char));
								strcpy(variantInfo[totalCnt].vCondName,FV_trim_blanks(varCondName));
							}
						}else
						{
							variantInfo[totalCnt].vCondName= (char*) MEM_alloc((int)(strlen(remPartAfterVarCondExpr)+1)* sizeof(char));
							strcpy(variantInfo[totalCnt].vCondName,FV_trim_blanks(remPartAfterVarCondExpr));
						}
					}
					if(lgIncrCount == TRUE)
						totalCnt++;
					FVE_FREE(line_temp)
					copyStr=NULL;
				}//if delim != null
				//free memory
				FVE_FREE(varCondExpr)
				FVE_FREE(varCondName)

				FVE_FREE(remPartAfterVarCondExpr);
				FVE_FREE(remPartAfterVarCondName);
			}//while
			fprintf(logfileptr,"Finish Processing Variant Definition File...\n");
			fprintf(logfileptr,"\n");
		}//flPtrProcess != 0

		TC_write_syslog("\n Leave function %s",function_name);
	    return totalCnt;
}


static void display_usage(void)
{
        printf("\n*******************************************************************************\n");
        printf("Usage: fve_import_parameter_values <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<User id with a Software Engr or Module Supervisor role>\n");
        printf(" {-p=password | -pf=passwordFile}\n");
		printf(" -g=<Teamcenter group for userid>\n");
		printf(" -topNodeId=Repository Item ID\n");
		printf(" -revId=Repository Rev ID\n");
        printf(" -parmvalfile=<dir\\parmvalfile> \n");
        printf(" The parmvalfile name should contain parameter definition information seperated by || \n");
		printf(" -varExpMapfile=<dir\\varExpMapfile> \n");
        printf(" The varExpMapfile name should contain variant information seperated by || \n");
        printf(" -configFile=<dir\\processdeffile> \n");
        printf(" This input is optional. The configuration file is used to process parameter definition files.  \n");
		printf("******************************************************************************\n\n");

}


int FVE_validate_files(char *filename1, char *filename2)
{

	int		ifail			=	ITK_ok;
	char	*function_name	=	"FVE_validate_files";
	int		iCounter		=	0;
	int		validCounterExt	=	0;
	int		cntExt			=	0;
	char	**extension		=	NULL;
	TC_write_syslog("\n Entering %s\n", function_name);

    
    // Nikhil Patil changes starts.
    /*
    *  Take input for configuration file.
    */
        if (configFileInput != 0)
        {
            configFilePtr = fopen(configFileInput, "r");
            if (configFilePtr == 0)
            {
                fprintf(stderr, "\nERROR: file %s does not exist.\n", filename1);
                exit(1);
            }
        }

    // Nikhil Patil changes ends.

	if(filename1 == NULL || tc_strlen(filename1) == 0)
	{
		fprintf(stderr,"\nERROR: -parmvalfile is not provided. \nPlease provide a file name with .csv extension, containing the Parameter Definition Information.\n");
		display_usage();
		exit(0);
	}
	else
	{
		//check if file extension is csv
		split_the_string(filename1,".",&cntExt,&extension);
		for(iCounter = 0;iCounter< cntExt; iCounter++)
		{
			if( (tc_strcmp(extension[iCounter] ,"csv") == 0) ||
			(tc_strcmp(extension[iCounter] ,"CSV") == 0))
			{
				validCounterExt++;
			}
		}
		if(validCounterExt == 0)
		{
			fprintf(stderr,"\nERROR: -parmvalfile is provided with wrong extension.\nPlease provide the file name with extension csv.\n");
			exit(1);
		}else
		{
			validCounterExt=0;
		}
		FVE_FREE_ARRAY(extension,cntExt)
		cntExt=0;
	}//filename1

	//Make sure if file : Parameter Value information exist
	if (filename1 != 0)
	{
		fileptr1 = fopen(filename1, "r");
		if (fileptr1 == 0)
		{
			fprintf(stderr, "\nERROR: file %s does not exist.\n", filename1);
			exit(1);
		}
		//If file size is Zero, Exit
		stat( filename1, &file_stat);
		if( file_stat.st_size == 0 )
		{
			printf("\nERROR: Input File [%s] is empty!!.\n", filename1);
			exit(1);
		}
	}


	if(filename2 == NULL || tc_strlen(filename2) == 0)
	{
		fprintf(stderr,"\nERROR: -varExpMapfile is not provided.\n Please provide a file name with .csv extension, containing the Process Definition Information.\n");
		display_usage();
		exit(0);
	}
	else
	{
		//check if file extension is csv
		//check if file extension is csv
		split_the_string(filename2,".",&cntExt,&extension);
		for(iCounter = 0;iCounter< cntExt; iCounter++)
		{
			if( (tc_strcmp(extension[iCounter] ,"csv") == 0) ||
			(tc_strcmp(extension[iCounter] ,"CSV") == 0))
			{
				validCounterExt++;
			}
		}
		if(validCounterExt == 0)
		{
			fprintf(stderr,"\nERROR: -varExpMapfile is provided with wrong extension.\nPlease provide the file name with extension csv.\n");
			exit(1);
		}else
		{
			validCounterExt=0;
		}
		FVE_FREE_ARRAY(extension,cntExt)
		cntExt=0;

	}//filename2

	//Make sure if file : information on Variant Expressions exist
	if ( filename2 != 0 )
	{
		fileptr2 = fopen(filename2, "r");
		if (fileptr2 == 0)
		{
			fprintf(stderr, "\nERROR: file %s does not exist.\n", filename2);
			exit(1);
		}
		//If varExpMapfile size is Zero, Exit
		stat( filename2, &file_statProcessInfo);
		if( file_statProcessInfo.st_size == 0 )
		{
			printf("\nERROR: Input File [%s] is empty!!.\n", filename2);
			exit(1);
		}
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}


extern char* FV_trim_blanks(char* inputStr)
{
  char* end = NULL;

  if (inputStr == NULL)
     return inputStr;

  end=strrchr(inputStr, '\0'); // Find null terminator

  while (inputStr<end && isspace(*inputStr)) // Scan forward
    ++inputStr;

  while (end>inputStr && isspace(*(end-1))) // scan back from end
    --end;

  *end='\0'; // terminate modified string

  return inputStr;
}

int FVE_find_rev(char* item_id,	char* rev_id, tag_t* rev)
{
	int ifail = ITK_ok;
	int num = 0;
	tag_t* revs = NULL;
	char** attrs = (char**)MEM_alloc(1*sizeof(char*));
	char** vals = (char**)MEM_alloc(1*sizeof(char*));

	attrs[0] = "item_id";
	vals[0] = item_id;
	ITK(ITEM_find_item_revs_by_key_attributes(1, (const char**)attrs, (const char**)vals, rev_id, &num, &revs))
	if(num == 0 || revs == NULL)
	{
		*rev = NULLTAG;
		TC_write_syslog("+++VSEM ERROR+++ Item Revision with id=%s and rev=%s cannot be located.\n", item_id, rev_id);
	}
	else
	{
		*rev = revs[0];
		FVE_FREE(revs)
	}

	FVE_FREE(attrs)
	FVE_FREE(vals)

	return ifail;
}

/*
Recursive function to check if bomline with the given name of type parameter value object exist in structure or not.
*/
/*
int FV_check_bomLineExist_inStruct_ofTypeParmVal(tag_t topBl,char *objName,tag_t *tagMatchingBl)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FV_check_bomLineExist_inStruct_ofTypeParmVal";
	int		cntChildLine	=	0;
	tag_t*	tagsChildLines	=	NULL;
	int		iCnt			=	0;
	char*	itemName		=	NULL;
	char*	itemType		=	NULL;
	logical flag			=	FALSE;


	TC_write_syslog("\n Entering %s\n", function_name);

	ITK(AOM_ask_value_string(topBl, bomAttr_itemName, &itemName))
	
	if((itemName != NULL) && (objName != NULL) && (tc_strcmp(itemName,objName) == 0) )
	{
		//cross check here , bomline is of type parameter usage 
		ITK(AOM_ask_value_string(topBl, bomAttr_itemType, &itemType))
			if( (itemType != NULL) &&  ( (tc_strcmp(itemType,FV9ParmValIntTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValDblTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValSEDTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValHexTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValStrTYPE)== 0) ))
		{
			*tagMatchingBl=topBl;
			flag	=	TRUE;
			return ifail;
		}
	}
	FVE_FREE(itemName)
	FVE_FREE(itemType)

	ITK(BOM_line_ask_child_lines(topBl, &cntChildLine, &tagsChildLines))
	for(iCnt = 0; iCnt < cntChildLine; iCnt++)
	{
		ITK(FV_check_bomLineExist_inStruct_ofTypeParmVal(tagsChildLines[iCnt],objName,tagMatchingBl))
		if(ifail == ITK_ok && flag	==	TRUE)
			return ifail;
	}

	FVE_FREE(tagsChildLines)
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}
*/

/*
Recursive function to check if bomline with the given name of type parameter value object exist in structure or not.
*/
int FV_check_bomLineExist_inStruct_ofTypeParmVal(tag_t topBl,char *objName,tag_t *tagMatchingBl)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FV_check_bomLineExist_inStruct_ofTypeParmVal";
	int		cntChildLine	=	0;
	tag_t*	tagsChildLines	=	NULL;
	int		iCnt			=	0;
	char*	itemName		=	NULL;
	char*	itemType		=	NULL;
	logical flag			=	FALSE;


	TC_write_syslog("\n Entering %s\n", function_name);

	ITK(BOM_line_ask_child_lines(topBl, &cntChildLine, &tagsChildLines))
	if(cntChildLine == 0 &&  tagsChildLines == NULL)
	{
		*tagMatchingBl=NULLTAG;
	}else
	{
		for(iCnt = 0; iCnt < cntChildLine; iCnt++)
		{
			ITK(AOM_ask_value_string(tagsChildLines[iCnt], bomAttr_itemName, &itemName))
			if((itemName != NULL) && (objName != NULL) && (tc_strcmp(itemName,objName) == 0) )
			{
				ITK(AOM_ask_value_string(tagsChildLines[iCnt], bomAttr_itemType, &itemType))
				if( (itemType != NULL) &&  ( (tc_strcmp(itemType,FV9ParmValIntTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValDblTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValSEDTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValHexTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmValStrTYPE)== 0) ))
				{
					*tagMatchingBl=tagsChildLines[iCnt];
				}
				FVE_FREE(itemType)
			}
			FVE_FREE(itemName)
		}//for
	}

	FVE_FREE(tagsChildLines)
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}



/*
Recursive function to check if bomline with the given name for parameter usage exist in structure or not.
*/
int FV_check_bomLineExist_inStruct(tag_t topBl,char *objName,tag_t *tagMatchingBl)
{
	int ifail	=	ITK_ok;
	char	*function_name	=		"FV_check_bomLineExist_inStruct";
	int		cntChildLine	=		0;
	tag_t*	tagsChildLines	=		NULL;
	int		iCnt			=		0;
	char*	itemName		=		NULL;
	char*	itemType		=		NULL;
	logical flag			=		FALSE;


	TC_write_syslog("\n Entering %s\n", function_name);

	ITK(AOM_ask_value_string(topBl, bomAttr_itemName, &itemName))
	if((itemName != NULL) && (objName != NULL) && (stricmp(itemName,objName) == 0) )
	{
		/*cross check here , bomline is of type parameter usage */
		ITK(AOM_ask_value_string(topBl, bomAttr_itemType, &itemType))
			if( (itemType != NULL) &&  ( (tc_strcmp(itemType,FV9ParmDfIntUsgTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfStrUsgTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfDblUsgTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfHexUsgTYPE)== 0) ||
										 (tc_strcmp(itemType,FV9ParmDfSEDUsgTYPE)== 0) ))
		{
			*tagMatchingBl=topBl;
			flag	=	TRUE;
			return ifail;
		}
	}
	FVE_FREE(itemName)
	FVE_FREE(itemType)

	ITK(BOM_line_ask_child_lines(topBl, &cntChildLine, &tagsChildLines))
	for(iCnt = 0; iCnt < cntChildLine; iCnt++)
	{
		ITK(FV_check_bomLineExist_inStruct(tagsChildLines[iCnt],objName,tagMatchingBl))
		if(ifail == ITK_ok && flag	==	TRUE)
			return ifail;
	}

	FVE_FREE(tagsChildLines)
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}


/*
  Set window for revision.
  I/P : revision tag
  o/p : window
		topBomLine
*/
int FV_get_set_window_fromRev(tag_t revision, tag_t *windowTag,tag_t *bomLineTag)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FV_get_set_window_fromRev";
	tag_t	newWindow			=	NULLTAG;
	tag_t	topbomLine		=	NULLTAG;
	tag_t	absocc_edit_mode_attr	=		NULLTAG;
    tag_t	absocc_ctxt_line_attr	=		NULLTAG;

	TC_write_syslog("\n Entering %s\n", function_name);
	if(revision != NULLTAG)
	{
		ITK(BOM_create_window(&newWindow))
		ITK(BOM_set_window_top_line(newWindow, NULLTAG, revision, NULLTAG, &topbomLine))
		//Turned Off InContext Mode
		/*
		ITK(PROP_ask_property_by_name(newWindow,(char *)"absocc_specific_edit_mode",&absocc_edit_mode_attr))
		ITK(PROP_ask_property_by_name(newWindow,(char *)"absocc_ctxtline",&absocc_ctxt_line_attr))
		ITK(PROP_set_value_logical(absocc_edit_mode_attr,TRUE))
		ITK(PROP_set_value_tag(absocc_ctxt_line_attr,topbomLine)) 
		*/
		ITK(BOM_save_window(newWindow))
		ITK(BOM_refresh_window(newWindow))
		ITK(BOM_line_set_precise(topbomLine, TRUE))
		ITK(BOM_save_window(newWindow))

		ITK(BOM_set_window_pack_all(newWindow,FALSE))
		ITK(BOM_window_show_substitutes(newWindow))
		ITK(BOM_window_show_unconfigured(newWindow))
		ITK(BOM_window_show_variants(newWindow))

		if(topbomLine)
		{
			*windowTag=newWindow;
			*bomLineTag=topbomLine;
		}
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

int split_the_string(char *consolidated_str,char *delim, int * str_cnt, char *** splitted_strings)
{
	char	*temp_str	=	NULL;
	char	* ptr			=	NULL;
	int		ifail			=	ITK_ok;
	char	*function_name	=	"split_the_string";

	TC_write_syslog("\n Entering %s\n", function_name);
	if(consolidated_str != NULL)
	{
		ITK(FV_strdup(consolidated_str, &temp_str))
		ptr = strtok(temp_str,delim);
		while(ptr != NULL)
		{
			(*splitted_strings) = (char **) MEM_realloc((*splitted_strings), (*str_cnt + 1) * sizeof(char *));
			(*splitted_strings)[*str_cnt] = (char *) MEM_alloc ((int)((strlen(FV_trim_blanks(ptr)) + 1)) * sizeof(char));
			strcpy((*splitted_strings)[*str_cnt], FV_trim_blanks(ptr));
			(*str_cnt)++;
			ptr = strtok(NULL,delim);
		}
	}

	TC_write_syslog("\n Exiting %s\n", function_name);
    FVE_FREE(temp_str)
	return ifail;
}

/*
  This function will trim only first and last invalid character from string.
  Only exception is with - minus sign , if string starts with it.
  If string starts with - sign , it will not be removed.
  If string ends with any invalid character , it will be removed.

 e.g  Matrix 4X2
  String = -40 15 25 40 20 30 40 50-
  string[0] = -40 15  ->Here - sign will not be removed.
  string[1]=   40 50-  ->Here  - sign will be removed.


*/
extern char* FV_trim_invalidChars(char* inputStr)
{
  char		*end			=	NULL;
  int		asciiValueStart		=	0;
  int		asciiValueEnd		=	0;
  logical	flagStart		=	FALSE;
  logical	flagEnd			=	FALSE;

  if (inputStr == NULL)
     return inputStr;

  asciiValueStart = *inputStr;
  end=strrchr(inputStr, '\0'); // Find null terminator
  asciiValueEnd= *(end-1);

  if( (asciiValueStart >= 32 && asciiValueStart <= 44) || (asciiValueStart >= 46 && asciiValueStart <= 47) || (asciiValueStart >= 58 && asciiValueStart <= 64) || (asciiValueStart >= 91 && asciiValueStart <= 96) || (asciiValueStart >= 123 && asciiValueStart <= 127))
	   flagStart = TRUE;

  if( (asciiValueEnd >= 32 && asciiValueEnd <= 47) || (asciiValueEnd >= 58 && asciiValueEnd <= 64) || (asciiValueEnd >= 91 && asciiValueEnd <= 96) || (asciiValueEnd >= 123 && asciiValueEnd <= 127))
	   flagEnd = TRUE;

  if(inputStr<end && flagStart) // Scan forward
    ++inputStr;

  if(end>inputStr && flagEnd) // scan back from end
    --end;

  *end='\0'; // terminate modified string

  return inputStr;
}

/* This function checks the tokenised value is null or not */
void fve_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}

int fv_strdup(const char* inputString, char** outputString)
{
   int   ifail = ITK_ok;
   char* function_name = "fv_strdup";
   char  intCharBuf[FV_INTEGER_LEN+1] = {'\0'};

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   *outputString = MEM_alloc((int)(sizeof(char)*(tc_strlen(inputString)+1)));

   if (*outputString != NULL)
   {
      tc_strcpy(*outputString, inputString);
   }
   else
   {
      sprintf(intCharBuf, "%d",  sizeof(char)*(tc_strlen(inputString)+1));
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, intCharBuf, function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}

/*
function to parse the line with given delimeper
I/p - delimeter
      line
	  locName = line pointer where the first occurance of delimeter exist.
	  e.g.
	  delimeter=||
	  line_temp=AirflowCalc||Calculated airflow output.Added Desc||Numeric||HW Output||
	  locName=||Calculated airflow output.Added Desc||Numeric||HW Output

0/p -Return first part before delimeter
     Return second Part after delimeter
*/
int fve_get_val_line(char *delim,char *line_temp,char *locName,char **firstStr,char **secondStr)
{
	int         ifail				=	ITK_ok;
	char*       function_name		=	"fve_get_val_line";
	int			delimLength			=	0;
	int			reqLength1			=	0;
	int			reqLength2			=	0;
	char		*firstPart			=	NULL;
	char		*secondPart			=	NULL;
	int			lenStrPointer		=	0;

	TC_write_syslog("\n Enter function %s",function_name);

	if(locName != NULL)
	{
		delimLength = strlen(delim);
		reqLength1=(tc_strlen(line_temp))-(tc_strlen(locName));
		reqLength2=strlen(locName)+delimLength;

		//get the length for locName
		lenStrPointer=tc_strlen(locName);
		firstPart = (char*)MEM_alloc((int) (reqLength1+1)* sizeof(char));

		strncpy(firstPart, FV_trim_blanks(line_temp),reqLength1);
		firstPart[reqLength1]='\0';
		secondPart = (char*)MEM_alloc((int) (reqLength2+1)* sizeof(char));
		sprintf(secondPart,"%.*s",strlen(locName)-delimLength,&locName[delimLength]);

		if(firstPart && tc_strlen(firstPart)> 0)
		{
			*firstStr=firstPart;
			firstPart=NULL;
		}

		if(secondPart && tc_strlen(secondPart)> 0)
		{
			*secondStr=secondPart;
			secondPart=NULL;

		}
	}
	TC_write_syslog("\n Leave function %s",function_name);
	return ifail;

}

/*
check Bom View & BVR exist for given revision.If not exist create it.
*/
int FV_check_bom_views_exist(tag_t revision)
{
	int		ifail			=	ITK_ok;
	char	*function_name	=	"FV_check_bom_views_exist";
	tag_t	viewTypeTag		=	NULLTAG;
	int		countBV			=	0;
	tag_t	*bvList			=	NULL;
	tag_t	bvTag			=	NULLTAG;
	tag_t	bvrTag			=	NULLTAG;
	tag_t	itemTag			=	NULLTAG;
	tag_t*  attached_bvrs   =	 NULL;
	int     bvr_count       =	0;
	char	*objName		=	NULL;
	char	item_id[ITEM_id_size_c + 1] = "";

	TC_write_syslog("\n Entering %s\n", function_name);

	//get the item for vehicle program document
	if(revision != NULLTAG)
	{
		ITK(ITEM_ask_item_of_rev(revision,&itemTag))
		ITK(ITEM_ask_id(itemTag, item_id))
		ITK(PS_find_view_type(viewVIEW, &viewTypeTag))
		if((ifail != ITK_ok) || (viewTypeTag == NULLTAG))
		{
			TC_write_syslog(" In %s: BOM View type - view not found ", function_name);
			return ifail;
		}
		ITK(ITEM_list_bom_views(itemTag,&countBV,&bvList))
		if(ifail==ITK_ok && countBV ==	0)
		{
				AM__set_application_bypass(TRUE);
				ITK(PS_create_bom_view(viewTypeTag,NULL,NULL,itemTag,&bvTag))
				if(bvTag != NULLTAG)
				{
					 ITK(AOM_lock(bvTag))
					 ITK(AOM_save(bvTag))
					 ITK(AOM_unlock(bvTag))
					 ITK(AOM_save(itemTag))
					 ITK(PS_create_bvr(bvTag,NULL,NULL,TRUE,revision,&bvrTag))
					 ITK(AOM_lock(bvrTag))
					 ITK(AOM_save(bvrTag))
					 ITK(AOM_unlock(bvrTag))
					 ITK(AOM_save(revision))
				}
				AM__set_application_bypass(FALSE);
		}
		else if(ifail==ITK_ok && countBV >	0)
		{
			AM__set_application_bypass(TRUE);
			ITK(ITEM_rev_list_all_bom_view_revs (revision,&bvr_count,&attached_bvrs))
			if(bvr_count == 0)
			{
				ITK(AOM_ask_value_string(revision,object_stringPROP,&objName))
				TC_write_syslog("\n Item Revision %s  with ID %s contains BV but dont have BVR \n",objName,item_id);
				TC_write_syslog("\n Error : Vehicle Program Structure not created now..... \n");
				ITK(EMH_store_error_s2(EMH_severity_error, FV_ITEMREV_WITHOUT_BVR,objName,item_id))
				return FV_ITEMREV_WITHOUT_BVR;
			}
			AM__set_application_bypass(FALSE);

		}

		FVE_FREE(bvList);
		FVE_FREE(attached_bvrs);
		FVE_FREE(objName);
	}
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}


/*
	Get the Attribute Values for Max , Min and Initial.
*/
int FVE_get_value_arrays(tag_t rev, char *attr,char *** value_array)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_get_value_arrays";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	int		cell_value_int		=	0;
	char	item_type[ITEM_type_size_c+1];
	char	cell_val_int[32]	 = "";
	char	*cell_value			=	NULL;
	char	cell_val_dbl[128]	=	"";

	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	double	cell_value_dbl		=	0.0;
	tag_t	item				=	NULLTAG;
	char	*cell_value_double	=	NULL;


	TC_write_syslog("\n Enter %s\n", function_name);
	ITK(ITEM_ask_item_of_rev(rev, &item))
	ITK(ITEM_ask_type(item, item_type))

	ITK(AOM_ask_value_tag(rev, attr, &attr_value))
	ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
	ITK(AOM_ask_value_int(table_def, colsPROP, &num_cols))
	ITK(AOM_ask_value_int(table_def, rowsPROP, &num_rows))

	ITK(AOM_ask_value_tags(attr_value, cellsPROP, &num_cells, &cells))

	(*value_array) = (char**) MEM_alloc((num_cells) * sizeof(char *));
	for(k = 0; k < num_cells; k++)
	{

		if( (tc_strcmp(item_type, FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) )
		{
			ITK(AOM_ask_value_string(cells[k], valuePROP, &cell_value))
			(*value_array)[k] = cell_value;
		}
		else if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
		{
			ITK(AOM_ask_value_double(cells[k], valuePROP, &cell_value_dbl))
			FVE_truncate_double_values(cell_value_dbl,&cell_value_double);
			sprintf(cell_val_dbl, "%s", cell_value_double);
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_val_dbl) + 1) * sizeof(char));
			strcpy((*value_array)[k], cell_val_dbl);
		}else if((tc_strcmp(item_type, FVE_ParmDefIntTYPE) == 0) ||(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
		{
			ITK(AOM_ask_value_int(cells[k], valuePROP, &cell_value_int))
			sprintf(cell_val_int, "%d", cell_value_int);
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_val_int) + 1) * sizeof(char));
			strcpy((*value_array)[k], cell_val_int);

		}else if( (tc_strcmp(item_type, FVE_ParmDefBCDTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValBCDTYPE) == 0) ||
				  (tc_strcmp(item_type, FVE_ParmDefSEDTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
		{
			ITK(AOM_ask_value_string(cells[k], valuePROP, &cell_value))
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_value)+ 1) * sizeof(char));
			strcpy((*value_array)[k], cell_value);
		}else if( (tc_strcmp(item_type, FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValHexTYPE) == 0))
		{
			ITK(AOM_ask_value_string(cells[k], valuePROP, &cell_value))
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_value) + strlen(HEX) + 1) * sizeof(char));
			strcpy((*value_array)[k], HEX);
			strcat((*value_array)[k], cell_value);
		}
	}

	FVE_FREE(cells)
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;
}

void FVE_truncate_double_values(double num, char ** truncated_vale)
{
	char temp_num[32] = "";
	char temp_str[2] = "";
	char * ptr = NULL;
	int len = 0;
	int i = 0;
	int unwanted_zero_cnt = 0;

	sprintf(temp_num, "%f", num);
	ptr = strtok(temp_num, ".");
	if(ptr != NULL)
	{
		(*truncated_vale) = (char *) MEM_alloc((int) (strlen(ptr) + 1) * sizeof(char));
		strcpy((*truncated_vale), ptr);
	}
	ptr = strtok(NULL, ".");
	if(ptr != NULL)
	{
		len = (int) strlen(ptr);
		for(i = len-1; i >= 0; i--)
		{
			if(ptr[i] != '0')
				break;
			else
				unwanted_zero_cnt++;
		}
		if(unwanted_zero_cnt < len)
		{
			(*truncated_vale) = (char *) MEM_realloc((*truncated_vale), (int) (strlen(*truncated_vale) + (len - unwanted_zero_cnt) + 2) * sizeof(char));
			strcat((*truncated_vale), ".");
			for(i = 0; i < (len - unwanted_zero_cnt); i++)
			{
				sprintf(temp_str, "%c", ptr[i]);
				strcat((*truncated_vale), temp_str);
			}
		}
	}
}


/*
Function to create the cells based on the item type and set the array of values(Min/Max/Initial).
For SED type its columns are fixed (domain Name , value) , it will never modify as of TC8.1.
From TC 9  -columns for SED are name , value and description.
*/
int FVE_create_cells(tag_t parmDefRev,int newNumRows,int oldNumRows,int newNumCols,int oldNumCols,char *propName,char **valDomainElName,char **valDomainElVal,char **valDomainElDescr)
{
	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_create_cells";

	int			iCounter						=	0;
	int			jCounter						=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		intColBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		* rowNumber						=   NULL;
	char		* colNumber						=   NULL;
	tag_t		tableCellTypeTag				=	NULLTAG;
	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		tableCellInputTag				= NULLTAG;

	tag_t		item							=	NULLTAG;
	char	item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       pomClassIdTable					=	NULLTAG;
	tag_t		tableInputTag					=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		attrIdValueTag					=	NULLTAG;
	tag_t		attrIdDescTag					=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;
	tag_t      tableTag = NULLTAG;

	tag_t	*cells				=	NULL;
	int		num_cells			=	0;
	tag_t	descTag				=	NULLTAG;
	tag_t	valueTag			=	NULLTAG;
	tag_t	validValuesId		=	NULLTAG;
	tag_t	validValues			=	NULLTAG;

	//tag_t   valueTag = NULLTAG;
	logical isItNullValTag=FALSE;
	logical isItEmptyValTag=FALSE;
	logical isItNullDescTag=FALSE;
	logical isItEmptyDescTag=FALSE;

	tag_t label_prop_tag = NULLTAG;
	tag_t* tag_lables = NULL;
	int num_labels = 0;

	tag_t	attr_value			=	NULLTAG;
	tag_t	table_def=NULLTAG;


	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))


	if(parmDefRev && propName && tc_strlen(propName)> 0)
	{
		//get the item type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}

		ITK(AOM_ask_value_tag(parmDefRev,propName, &attr_value))
		ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
		ITK(AOM_ask_value_tags(attr_value, cellsPROP, &num_cells, &cells))

		//first delete cells and then recreate cells for property based on itemType.
		ITK(AOM_refresh(parmDefRev,TRUE))
		ITK(AOM_refresh(table_def,TRUE))

		//set references to NULL and then delete the cells
		ITK(AOM_refresh(attr_value,TRUE))
		ifail=AOM_set_value_tags(attr_value,"cells",0,NULL);
		ITK(AOM_save(attr_value))
		ITK(AOM_refresh(attr_value,FALSE))
		ifail=FV_delete_pom_objects(oldNumRows*oldNumCols,cells);

		ITK(AOM_save(table_def))
		ITK(AOM_refresh(table_def,FALSE))

		ITK(AOM_save(parmDefRev))
		ITK(AOM_refresh(parmDefRev,FALSE))

		//now recreate the cells for a property and set the values based on itemType
		/*For SED , 2 value arrays required i.e. domain name and decription.
		  For Other types only value array is required.*/
		if(item_type && tc_strlen(item_type)> 0)
		{
			if((tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0) ||  (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
			{
				if(valDomainElName && valDomainElVal)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,valDomainElVal,valDomainElDescr);
				}
			}else if((tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||  (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
			{
				if(valDomainElName)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,NULL,NULL);
				}
			}else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
			{
				if(valDomainElName)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,NULL,NULL);
				}
			}else if((tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
			{
				if(valDomainElName)
				{
					ifail=FVE_reCreate_cells_multipleValues(parmDefRev,newNumRows,newNumCols,propName,valDomainElName,NULL,NULL);
				}
			}
		}//item_type

	}//parmDefRev

	FVE_FREE(cellInputTags)
	cellCnt=0;


	TC_write_syslog("\n Entering %s\n", function_name);
	return ifail;
}

/*
   Function to reCreate cells with multiple values during update of Parameter Definition ...
   Additional argument "domainElVal" is required for SED type.
*/
int FVE_reCreate_cells_multipleValues(tag_t parmDefRev,int newNumRows,int newNumCols,char *propName,char **values,char **domainElVal,char **domainElDescr)
{
	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_reCreate_cells_multipleValues";

	int			iCounter						=	0;
	int			jCounter						=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		intColBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		* rowNumber						=   NULL;
	char		* colNumber						=   NULL;
	tag_t		tableCellTypeTag				=	NULLTAG;
	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		tableCellInputTag				= NULLTAG;

	tag_t		item							=	NULLTAG;
	char	item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       pomClassIdTable					=	NULLTAG;
	tag_t		tableInputTag					=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		attrIdValueTag					=	NULLTAG;
	tag_t		attrIdDescTag					=	NULLTAG;
	tag_t		attrIdDomainDescTag				=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;
	tag_t      tableTag = NULLTAG;

	tag_t	*cells				=	NULL;
	int		num_cells			=	0;
	int    incrCounter			=	0;

	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))

	if(parmDefRev && propName && values)
	{
		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellSEDCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellSEDCLASS,&attrIdDescTag))
				ITK(POM_attr_id_of_attr("fnd0DomainElementDesc",TableCellSEDCLASS,&attrIdDomainDescTag))
			}
			else if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||  (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellIntCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellIntCLASS,&attrIdDescTag))
			}else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellDoubleCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellDoubleCLASS,&attrIdDescTag))
			}else if((tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellStringCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellStringCLASS,&attrIdDescTag))
			}

			// Get *any* TypedReference Table object for the Parameter Definition Revision.
			ITK(AOM_ask_value_tag(parmDefRev,propName,&tableTag));

			ITK(POM_refresh_instances_any_class(1,&tableTag,POM_no_lock))
			ITK(POM_load_instances_any_class(1,&tableTag,POM_no_lock))

			ITK(AOM_refresh(parmDefRev,TRUE))
			ITK(AOM_refresh(tableTag,TRUE))

			for(iCounter=0;iCounter<newNumRows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;

				for(jCounter=0;jCounter<newNumCols;jCounter++)
				{
					sprintf(intColBuf, "%d",jCounter);
   					colNumber = intColBuf;
					if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellIntCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
						{
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdValueTag,atoi(values[incrCounter])));
							incrCounter++;
						}
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}else if( (tc_strcmp(item_type,FVE_ParmDefStrTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellStringCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));
						//set value
						if(attrIdValueTag && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,values[incrCounter]));
							incrCounter++;
						}
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}
					else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellDoubleCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
						{
							ITK(POM_set_attr_double(1,&tableCellInputTag,attrIdValueTag,atof(values[incrCounter])));
							incrCounter++;
						}
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}else if( (tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellSEDCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))

						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set desc
						if(attrIdDescTag && values[incrCounter] && tc_strlen(values[incrCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdDescTag,values[incrCounter]));
						}

						//set value
						if(attrIdValueTag && domainElVal[incrCounter] && tc_strlen(domainElVal[incrCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,domainElVal[incrCounter]));
							incrCounter++;
						}
						//set domain descrption
						if(attrIdDomainDescTag && domainElDescr[incrCounter] && tc_strlen(domainElDescr[incrCounter])> 0)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdDomainDescTag,domainElDescr[incrCounter]));
							incrCounter++;
						}

						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))
					}//objSED

						// Add array cell input tag to array of tags.
					ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTag))
				}//jCounter
			}//iCounter
			if(tableTag && prop_tagCell && cellInputTags)
				ITK(POM_set_attr_tags(1,&tableTag,prop_tagCell,0,cellCnt,cellInputTags))

			ITK(AOM_save(tableTag))
			ITK(AOM_refresh(tableTag,FALSE))

			ITK(AOM_save(parmDefRev))
			ITK(AOM_refresh(parmDefRev,FALSE))

		}//itemType

	}//parmDefRev

	return ifail;
}

// Given an array of POM_objects, unload and delete them.
// WARNING! This deletes objects from the database.
// NOTE: this function will fail if any input objects are referenced.
extern int FV_delete_pom_objects(int pomObjCnt, tag_t* pomObjTags)
{
    int         ifail = ITK_ok;
    char*       function_name = "FV_delete_pom_objects";
    tag_t*      unloadTags = NULL;
    int         unloadCnt=0;
    int         tagIdx = 0;
    logical     isLoaded = FALSE;

    TC_write_syslog("Entering %s, deleting %d objects\n", function_name, pomObjCnt);

    if (pomObjTags == NULL)
       ITK(FV_handle_missing_arg_error(function_name, "pomObjTags"))

    for (tagIdx=0; tagIdx<pomObjCnt; tagIdx++)
    {
        ITK(POM_is_loaded(pomObjTags[tagIdx], &isLoaded))
        if (isLoaded)
           ITK(FV_add_unique_tag_to_array(&unloadCnt, &unloadTags, pomObjTags[tagIdx]))
    }

    if (unloadCnt > 0)
    {
       TC_write_syslog("In %s, unloading %d objects\n", function_name, unloadCnt);
       ITK(POM_unload_instances(unloadCnt, unloadTags))
    }

    TC_write_syslog("In %s, deleting %d objects\n", function_name, pomObjCnt);
    ITK(POM_delete_instances(pomObjCnt, pomObjTags))

    TC_write_syslog("Exiting %s\n", function_name);
    FVE_FREE(unloadTags)

    return ifail;
}


/*
function to set single value for number of cells of Min/Max/Initial table on revision
*/
int FVE_set_value(tag_t rev,char *attr,char *val)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_set_value";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	char	item_type[ITEM_type_size_c+1];

	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	tag_t	item				=	NULLTAG;
	double	val_dbl				=	0.0;
	char	*valueSubstring		=	NULL;
	int		index				=	0;
	char*  indexOfX				=	NULL;


	TC_write_syslog("\n Enter %s\n", function_name);
	ITK(ITEM_ask_item_of_rev(rev, &item))
	ITK(ITEM_ask_type(item, item_type))

	ITK(AOM_ask_value_tag(rev, attr, &attr_value))
	ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
	ITK(AOM_ask_value_int(table_def,colsPROP, &num_cols))
	ITK(AOM_ask_value_int(table_def,rowsPROP, &num_rows))

	ITK(AOM_ask_value_tags(attr_value,cellsPROP, &num_cells, &cells))

	ITK(AOM_refresh(rev,TRUE))
	ITK(AOM_refresh(table_def,TRUE))
	for(k = 0; k < num_cells; k++)
	{
		if(cells[k] && val && tc_strlen(val)> 0)
		{
			ITK(AOM_refresh(cells[k],TRUE))
			if( (tc_strcmp(item_type, FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
			{
				ITK(AOM_set_value_string(cells[k], valuePROP,val))
			}
			else if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValDblTYPE) == 0) )
			{
				val_dbl=atof(val);
				ITK(AOM_set_value_double(cells[k],valuePROP,val_dbl))
			}
			else if( (tc_strcmp(item_type, FVE_ParmDefIntTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValIntTYPE) == 0))
			{
				ITK(AOM_set_value_int(cells[k],valuePROP,atoi(val)))
			}
			else if( (tc_strcmp(item_type, FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValHexTYPE) == 0))
			{
				//check if value is with prefix "0x"
				indexOfX=NULL;
				indexOfX=strchr(val,'x');
				if(indexOfX != NULL)
				{
					index = (int)(indexOfX - val);
					valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(val)+1));
					//sprintf(valueSubstring,"%d%s",strlen(initValArray[incrCounter])-(index+1),&(initValArray[incrCounter])[index+1]);
					sprintf(valueSubstring,"%s",&(val)[index+1]);
					if(valueSubstring)
					{
						ITK(AOM_set_value_string(cells[k], valuePROP,valueSubstring))
					}
					FVE_FREE(valueSubstring)
					index=0;
				}else
				{
					ITK(AOM_set_value_string(cells[k], valuePROP,val))
				}
			}
			ITK(AOM_save(cells[k]))
			ITK(AOM_refresh(cells[k],FALSE))
		}
	}
	ITK(AOM_save(table_def))
	ITK(AOM_refresh(table_def,FALSE))
	ITK(AOM_save(rev))
	ITK(AOM_refresh(rev,FALSE))

	FVE_FREE(cells)
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;
}

/*
Function to set multiple values on cells of Min/Max/Initial tables on revision.
*/
int FVE_set_values(tag_t rev,char *propName,char **valArray,int valCnt)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_set_values";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	char	item_type[ITEM_type_size_c+1];

	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	tag_t	item				=	NULLTAG;
	double	val_dbl				=	0.0;
	char	*valueSubstring		=	NULL;
	int		index				=	0;
	char*  indexOfX				=	NULL;

	TC_write_syslog("\n Enter %s\n", function_name);
	if(rev && propName && valArray && valCnt > 0)
	{
		ITK(ITEM_ask_item_of_rev(rev, &item))
		ITK(ITEM_ask_type(item, item_type))

		ITK(AOM_ask_value_tag(rev, propName, &attr_value))
		ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
		ITK(AOM_ask_value_int(table_def,colsPROP, &num_cols))
		ITK(AOM_ask_value_int(table_def,rowsPROP, &num_rows))

		ITK(AOM_ask_value_tags(attr_value,cellsPROP, &num_cells, &cells))

		if(num_cells == valCnt)
		{
			ITK(AOM_refresh(rev,TRUE))
			ITK(AOM_refresh(table_def,TRUE))
			for(k = 0; k < num_cells; k++)
			{
				if(cells[k] && valArray[k])
				{
					ITK(AOM_refresh(cells[k],TRUE))
					if( (tc_strcmp(item_type, FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
					{
						ITK(AOM_set_value_string(cells[k], valuePROP,valArray[k]))
					}
					else if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValDblTYPE) == 0) )
					{
						val_dbl=atof(valArray[k]);
						ITK(AOM_set_value_double(cells[k],valuePROP,val_dbl))
					}
					else if( (tc_strcmp(item_type, FVE_ParmDefIntTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValIntTYPE) == 0))
					{
						ITK(AOM_set_value_int(cells[k],valuePROP,atoi(valArray[k])))
					}
					else if( (tc_strcmp(item_type, FVE_ParmDefHexTYPE) == 0) || (tc_strcmp(item_type, FV9ParmValHexTYPE) == 0))
					{
						//check if value is with prefix "0x"
						indexOfX=NULL;
						indexOfX=strchr(valArray[k],'x');
						if(indexOfX != NULL)
						{
							index = (int)(indexOfX - valArray[k]);
							valueSubstring = MEM_alloc(sizeof(char)*(tc_strlen(valArray[k])+1));
							sprintf(valueSubstring,"%s",&(valArray[k])[index+1]);
							if(valueSubstring)
							{
								ITK(AOM_set_value_string(cells[k], valuePROP,valueSubstring))
							}
							FVE_FREE(valueSubstring)
							index=0;
						}else
						{
							ITK(AOM_set_value_string(cells[k], valuePROP,valArray[k]))
						}
					}
					ITK(AOM_save(cells[k]))
					ITK(AOM_refresh(cells[k],FALSE))
				}
			}//k = 0
			ITK(AOM_save(table_def))
			ITK(AOM_refresh(table_def,FALSE))
			ITK(AOM_save(rev))
			ITK(AOM_refresh(rev,FALSE))
		}//num_cells == valCnt
		FVE_FREE(cells)
	}
	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

/*
Function to create the cells based on the item type and set the single value(Min/Max/Initial) for rows*columns.
For SED type its columns are fixed (domain Name and Description) , it will never modify as of TC8.1.
*/
int FVE_create_cells_MinMaxInit(tag_t parmDefRev,int newNumRows,int oldNumRows,int newNumCols,int oldNumCols,char *propName,char *value)
{
	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_create_cells_MinMaxInit";

	int			iCounter						=	0;
	int			jCounter						=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		intColBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		* rowNumber						=   NULL;
	char		* colNumber						=   NULL;
	tag_t		tableCellTypeTag				=	NULLTAG;
	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		tableCellInputTag				= NULLTAG;

	tag_t		item							=	NULLTAG;
	char		item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       pomClassIdTable					=	NULLTAG;
	tag_t		tableInputTag					=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		attrIdValueTag					=	NULLTAG;
	tag_t		attrIdDescTag					=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;
	tag_t      tableTag = NULLTAG;

	tag_t	*cells				=	NULL;
	int		num_cells			=	0;
	tag_t	descTag				=	NULLTAG;
	tag_t	valueTag			=	NULLTAG;
	tag_t	validValuesId		=	NULLTAG;
	tag_t	validValues			=	NULLTAG;

	tag_t	attr_value			=	NULLTAG;
	tag_t	table_def=NULLTAG;
	tag_t   cellValueTag = NULLTAG;

	tag_t	tabletag	=	NULLTAG;

	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))

	if(parmDefRev && propName && value && tc_strlen(value)> 0)
	{
		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}

		ITK(AOM_get_value_tag(parmDefRev,propName, &attr_value))
		ITK(AOM_get_value_tag(attr_value, definitionPROP, &table_def))
		ITK(AOM_get_value_tags(attr_value, cellsPROP, &num_cells, &cells))

		/*Delete existing cells during update and then reCreate the cells based on the itemtype */
		ITK(AOM_refresh(parmDefRev,TRUE))
		ITK(AOM_refresh(table_def,TRUE))

		//set references to NULL and then delete existing cells
		ITK(AOM_refresh(attr_value,TRUE))
		ifail=AOM_set_value_tags(attr_value,"cells",0,NULL);
		ITK(AOM_save(attr_value))
		ITK(AOM_refresh(attr_value,FALSE))
		ifail=FV_delete_pom_objects(oldNumRows*oldNumCols,cells);

		ITK(AOM_save(table_def))
		ITK(AOM_refresh(table_def,FALSE))

		ITK(AOM_save(parmDefRev))
		ITK(AOM_refresh(parmDefRev,FALSE))

		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || (tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) )
			{
				//reCreate the cells for a property and set the values
				ifail=FVE_reCreate_cells_singleValue(parmDefRev,newNumRows,newNumCols,propName,value);
			}
		}
	}//parmDefRev

	TC_write_syslog("\n Entering %s\n", function_name);
	FVE_FREE(cellInputTags);
	cellCnt=0;
	return ifail;
}

/*
function to set the modified row , column value on revision and accordingly create/delete required cells.

Arguments : revision
            modified row value
			modified column value
			logical value true/false to set rowlabelName
			logical value true/false to set columnLabel
			array rowLabelNames
			array colLabelNames
*/
int FVE_set_rowColumns(tag_t parmDefRev,int Rows,int Columns,logical flagRowLabel,logical flagColLabel,char **rowlabelArr,char **colLabelArr)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_set_rowColumns";
	int			cnt_row							=	0;
	int			old_num_cols					=	0;
	int			old_num_rows					=	0;
	tag_t		tableDefTag						=	NULLTAG;
	char        rev_type[ITEM_type_size_c + 1]  =	"";
	tag_t		item							=	NULLTAG;
	char		item_type[ITEM_type_size_c+1];


	TC_write_syslog("\n Entering %s\n", function_name);

	if(parmDefRev)
	{
		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		ITK(ITEM_ask_rev_type(parmDefRev, rev_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}
	}

	if(tableDefTag)
	{
		ITK(AOM_ask_value_int(tableDefTag, colsPROP, &old_num_cols))
		ITK(AOM_ask_value_int(tableDefTag, rowsPROP, &old_num_rows))

		ITK(AOM_refresh(parmDefRev,TRUE))
		ITK(AOM_refresh(tableDefTag,TRUE))

		ITK(AOM_set_value_int(tableDefTag,colsPROP,Columns))
		ITK(AOM_set_value_int(tableDefTag,rowsPROP,Rows))
		ITK(AOM_save(tableDefTag))
		ITK(AOM_refresh(tableDefTag,FALSE))

		ITK(AOM_save(parmDefRev))
		ITK(AOM_refresh(parmDefRev,FALSE))

		if ( (tc_strcmp(rev_type, FVE_ParmDefIntRevisionTYPE)==0) || (tc_strcmp(rev_type, FVE_ParmDefDblRevisionTYPE)==0) || (tc_strcmp(rev_type, FVE_ParmDefStrRevisionTYPE)==0) ||
			 (tc_strcmp(rev_type, FV9ParmValIntRevisionTYPE)==0) ||  (tc_strcmp(rev_type, FV9ParmValDblRevisionTYPE)==0) ||  (tc_strcmp(rev_type, FV9ParmValStrRevisionTYPE)==0))
		{
			//create /delete row cells
			if( (flagRowLabel && rowlabelArr) || (flagColLabel && colLabelArr) )
			{
				ifail=FV_create_cells_labels(parmDefRev,Rows,old_num_rows,rowLabelsPROP,rowlabelArr,Columns,old_num_cols,colLabelsPROP,colLabelArr);
			}
		}
	}//tableDefTag != NULLTAG


	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;

}

/* Function to reCreate cells with single value during update of Parameter Definition ...
*/
int FVE_reCreate_cells_singleValue(tag_t parmDefRev,int newNumRows,int newNumCols,char *propName,char *value)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_reCreate_cells_singleValue";

	int			iCounter						=	0;
	int			jCounter						=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		intColBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	char		* rowNumber						=   NULL;
	char		* colNumber						=   NULL;
	tag_t		tableCellTypeTag				=	NULLTAG;
	tag_t		*cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		tableCellInputTag				= NULLTAG;

	tag_t		item							=	NULLTAG;
	char	item_type[ITEM_type_size_c+1];
	tag_t		tableDefTag						=	NULLTAG;
	tag_t       pomClassIdTable					=	NULLTAG;
	tag_t		tableInputTag					=	NULLTAG;
	tag_t       attrIdRowTag					=	NULLTAG;
	tag_t		attrIdColTag					=	NULLTAG;
	tag_t		attrIdValueTag					=	NULLTAG;
	tag_t		attrIdDescTag					=	NULLTAG;
	tag_t		prop_tagCell					=	NULLTAG;
	tag_t		prop_tagDef						=	NULLTAG;
	tag_t      tableTag = NULLTAG;

	tag_t	*cells				=	NULL;
	int		num_cells			=	0;

	TC_write_syslog("\n Entering %s\n", function_name);

	//Get Attribute Id
	ITK(POM_attr_id_of_attr("row","TableCell",&attrIdRowTag))
	ITK(POM_attr_id_of_attr("col","TableCell",&attrIdColTag))
	ITK(POM_attr_id_of_attr("cells","Table", &prop_tagCell))
	ITK(POM_attr_id_of_attr("definition","Table", &prop_tagDef))

	if(parmDefRev && propName && value && tc_strlen(value)> 0)
	{
		//get the type
		ITK(ITEM_ask_item_of_rev(parmDefRev, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(parmDefRev,"tableDefinition",&tableDefTag))
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(parmDefRev,"fv9TableDefinition",&tableDefTag))
				}
		}
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefSEDTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellSEDCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellSEDCLASS,&attrIdDescTag))
			}
			else if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellIntCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellIntCLASS,&attrIdDescTag))
			}else if((tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellDoubleCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellDoubleCLASS,&attrIdDescTag))
			}else if((tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
			{
				ITK(POM_attr_id_of_attr("value",TableCellStringCLASS,&attrIdValueTag))
				ITK(POM_attr_id_of_attr("desc",TableCellStringCLASS,&attrIdDescTag))
			}

			// Get *any* TypedReference Table object for the Parameter Definition Revision.
			ITK(AOM_ask_value_tag(parmDefRev,propName,&tableTag));

			ITK(POM_refresh_instances_any_class(1,&tableTag,POM_no_lock))
			ITK(POM_load_instances_any_class(1,&tableTag,POM_no_lock))

			ITK(AOM_refresh(parmDefRev,TRUE))
			ITK(AOM_refresh(tableTag,TRUE))

			for(iCounter=0;iCounter<newNumRows;iCounter++)
			{
				sprintf(intRowBuf, "%d",iCounter);
   				rowNumber = intRowBuf;

				for(jCounter=0;jCounter<newNumCols;jCounter++)
				{
					sprintf(intColBuf, "%d",jCounter);
   					colNumber = intColBuf;
					if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellIntCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdValueTag,atoi(value)));
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}else if( (tc_strcmp(item_type,FVE_ParmDefDblTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValDblTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellDoubleCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));

						//set value
						if(attrIdValueTag)
							ITK(POM_set_attr_double(1,&tableCellInputTag,attrIdValueTag,atof(value)));
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}else if( (tc_strcmp(item_type,FVE_ParmDefStrTYPE) ==0) || (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0))
					{
						ITK(POM_class_id_of_class(TableCellStringCLASS, &tableCellTypeTag))
						ITK(POM_create_instance(tableCellTypeTag, &tableCellInputTag))
						//set row value
						if(attrIdRowTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdRowTag,iCounter))
						//set column value
						if(attrIdColTag)
							ITK(POM_set_attr_int(1,&tableCellInputTag,attrIdColTag,jCounter));
						//set value
						if(attrIdValueTag)
						{
							ITK(POM_set_attr_string(1,&tableCellInputTag,attrIdValueTag,value));
						}
						ITK(POM_save_instances(1, &tableCellInputTag, TRUE))

					}
					// Add array cell input tag to array of tags.
					ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableCellInputTag))
				}//jCounter
			}//iCounter
			if(tableTag && prop_tagCell && cellInputTags)
				ITK(POM_set_attr_tags(1,&tableTag,prop_tagCell,0,cellCnt,cellInputTags))

			ITK(AOM_save(tableTag))
			ITK(AOM_refresh(tableTag,FALSE))

			ITK(AOM_save(parmDefRev))
			ITK(AOM_refresh(parmDefRev,FALSE))

		}//itemType

	}//parmDefRev

	FVE_FREE(cellInputTags);
	cellCnt=0;
	return ifail;
}

/*
Function to create/delete row/column labels during update of parameter definition revision.
I/P : revision
      new_Rcount
	  old_Rcount
	  rowPropName
	  rowPropValues
	  new_Colcount
	  old_Colcount
	  colPropName
	  colPropValues

*/
int FV_create_cells_labels(tag_t revision,int new_Rcount,int old_Rcount , char *rowPropName ,char **rowPropValues,int new_Colcount,int old_Colcount , char *colPropName ,char **colPropValues)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FV_create_cells_labels";
	tag_t		tableDefTag						=	NULLTAG;
	int			cnt_row							=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	int			locationCounter					=	0;
	char		*rowCountStr					=	NULL;
	tag_t       pomClassIdLabel					=	NULLTAG;
	tag_t       attrIdLabelTag					=	NULLTAG;
	tag_t		attrIdLocationTag				=	NULLTAG;
	tag_t		tableRowLabelInputTag			=	NULLTAG;
	tag_t*      cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		prop_tag						=	NULLTAG;
	int			rowLabelNumber					=	0;
	tag_t		*rowLabelValues					=	NULL;
	int			colLabelNumber					=	0;
	tag_t		*colLabelValues					=	NULL;
	char	item_type[ITEM_type_size_c+1];
	tag_t	item								=	NULLTAG;

	tag_t label_prop_tag = NULLTAG;
	tag_t* tag_lables = NULL;
	int num_labels = 0;
	tag_t label_prop_tag1 = NULLTAG;
	tag_t* tag_lables1 = NULL;
	int num_labels1 = 0;
	logical		isParmDefObject					=	FALSE;
	logical		isFv9ValObject					=	FALSE;


	TC_write_syslog("\n Enter %s\n", function_name);

	/* When row/column count get modified , first delete existing  labels and reCreate new Labels.*/
	if(revision)
	{
		ITK(ITEM_ask_item_of_rev(revision, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(revision,"tableDefinition",&tableDefTag))
					isParmDefObject=TRUE;
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(revision,"fv9TableDefinition",&tableDefTag))
					isFv9ValObject=TRUE;
				}
		}

		ITK(POM_class_id_of_class("TableLabel", &pomClassIdLabel))

		if(tableDefTag)
		{
			ITK(AOM_ask_value_tags(tableDefTag, rowPropName, &rowLabelNumber,&rowLabelValues))
			ITK(AOM_ask_value_tags(tableDefTag, colPropName, &colLabelNumber,&colLabelValues))

			if( (tc_strcmp(item_type, FVE_ParmDefDblTYPE) == 0) ||  (strcmp(item_type, FVE_ParmDefIntTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type ,FVE_ParmDefBoolTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefDateTYPE) == 0) || (tc_strcmp(item_type ,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type ,FVE_ParmDefStrTYPE) == 0)	||
				(tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) || (tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
				(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
			{
				ITK(AOM_refresh(tableDefTag,TRUE))
				ifail=AOM_set_value_tags(tableDefTag,rowPropName,0,NULL);
				ifail=AOM_set_value_tags(tableDefTag,colPropName,0,NULL);
				ITK(AOM_save(tableDefTag))
				ITK(AOM_refresh(tableDefTag,FALSE))

				AM__set_application_bypass(TRUE);
				ITK(AOM_lock(revision))
				if(isParmDefObject == TRUE)
				{
					ifail=AOM_set_value_tag(revision,"tableDefinition",NULLTAG);
				}
				if(isFv9ValObject == TRUE)
				{
					ifail=AOM_set_value_tag(revision,"fv9TableDefinition",NULLTAG);
				}
				ITK(AOM_save(revision))
				ITK(AOM_unlock(revision))
				ITK(AOM_refresh(revision,FALSE))
				AM__set_application_bypass(FALSE);

				if(rowLabelValues)
					ifail=FV_delete_pom_objects(rowLabelNumber,rowLabelValues);

				if(colLabelValues)
					ifail=FV_delete_pom_objects(colLabelNumber,colLabelValues);

				//recrete cell_labels again
				if(rowPropValues && rowPropName && tc_strlen(rowPropName)> 0)
				{
					ifail=FVE_reCreate_cellsLabels(revision,new_Rcount,rowPropName,rowPropValues);
				}

				if(colPropValues && colPropName && tc_strlen(colPropName)> 0)
				{
					ifail=FVE_reCreate_cellsLabels(revision,new_Colcount,colPropName,colPropValues);
				}
			}
		}//tableDefTag
	} //revision

	TC_write_syslog("\n Exiting %s\n", function_name);
	return ifail;
}

/*
Function to reCreate cells during update
*/
int FVE_reCreate_cellsLabels(tag_t revision,int new_count,char *propName,char **propValues)
{

	int			ifail							=	ITK_ok;
	char		*function_name					=	"FVE_reCreate_cellsLabels";
	tag_t		tableDefTag						=	NULLTAG;
	int			cnt_row							=	0;
	char		intRowBuf[FV_INTEGER_LEN+1]		=	{'\0'};
	int			locationCounter					=	0;
	char		*rowCountStr					=	NULL;
	tag_t       pomClassIdLabel					=	NULLTAG;
	tag_t       attrIdLabelTag					=	NULLTAG;
	tag_t		attrIdLocationTag				=	NULLTAG;
	tag_t		tableRowLabelInputTag			=	NULLTAG;
	tag_t*      cellInputTags					=	NULL;
	int         cellCnt							=	0;
	tag_t		prop_tag						=	NULLTAG;
	int			number							=	0;
	tag_t		*values							=	NULL;
	char	item_type[ITEM_type_size_c+1];
	tag_t	item								=	NULLTAG;

	tag_t label_prop_tag = NULLTAG;
	tag_t* tag_lables = NULL;
	int num_labels = 0;
	logical		isParmDefObject					=	FALSE;
	logical		isFv9ValObject					=	FALSE;



	TC_write_syslog("\n Enter %s\n", function_name);

	if(revision)
	{
		ITK(ITEM_ask_item_of_rev(revision, &item))
		ITK(ITEM_ask_type(item, item_type))
		if(item_type && tc_strlen(item_type)> 0)
		{
			if( (tc_strcmp(item_type,FVE_ParmDefIntTYPE) ==0) ||
				(tc_strcmp(item_type,FVE_ParmDefDblTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefStrTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefHexTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBoolTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefBCDTYPE) == 0) ||
				(tc_strcmp(item_type,FVE_ParmDefDateTYPE) == 0) )
				{
					ITK(AOM_ask_value_tag(revision,"tableDefinition",&tableDefTag))
					isParmDefObject=TRUE;
				}
				if( (tc_strcmp(item_type,FV9ParmValStrTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValIntTYPE) == 0)  ||
					(tc_strcmp(item_type,FV9ParmValDblTYPE) == 0) ||
					(tc_strcmp(item_type,FV9ParmValSEDTYPE) == 0))
				{
					ITK(AOM_ask_value_tag(revision,"fv9TableDefinition",&tableDefTag))
					isFv9ValObject=TRUE;
				}
		}
		ITK(POM_class_id_of_class("TableLabel", &pomClassIdLabel))
		if(tableDefTag && propValues)
		{
			//create required label cells for rows or columns
			ITK(POM_refresh_instances_any_class(1,&tableDefTag,POM_no_lock))
			ITK(POM_load_instances_any_class(1,&tableDefTag,POM_no_lock))

			ITK(AOM_refresh(revision,TRUE))
			ITK(AOM_refresh(tableDefTag,TRUE))
			for(cnt_row = 0; cnt_row < new_count; cnt_row++)
			{
				sprintf(intRowBuf, "%d",cnt_row);
   				rowCountStr = intRowBuf;
				locationCounter=locationCounter+1;

				// Create POM object
				ITK(POM_create_instance(pomClassIdLabel, &tableRowLabelInputTag))
				/* Get Attribute Id */
				ITK(POM_attr_id_of_attr("label","TableLabel",&attrIdLabelTag))
				if(propValues[cnt_row] && tc_strlen(propValues[cnt_row]) > 0)
				{
					ITK(POM_set_attr_string(1,&tableRowLabelInputTag,attrIdLabelTag,propValues[cnt_row]))
				}
				ITK(POM_attr_id_of_attr("location","TableLabel",&attrIdLocationTag))
				ITK(POM_set_attr_int(1,&tableRowLabelInputTag,attrIdLocationTag,cnt_row));
				ITK(POM_save_instances(1, &tableRowLabelInputTag, TRUE))

				//Add array cell input tag to array of tags.
				ITK(FV_add_tag_to_array(&cellCnt, &cellInputTags, tableRowLabelInputTag))
			}

			//set rowLabels or columnLabels on tableDefinition
			ITK(POM_attr_id_of_attr(propName,"TableDefinition", &prop_tag))
			ITK(POM_set_attr_tags(1,&tableDefTag,prop_tag,0,cellCnt,cellInputTags))

			ITK(AOM_save(tableDefTag))
			ITK(AOM_refresh(tableDefTag,FALSE))

			ITK(AOM_save(revision))
			ITK(AOM_refresh(revision,FALSE))

		}//tableDefTag

	}//revision
	return ifail;
}

// This allocates/reallocates the array and adds the tag to the end of the array.
// I/O argument tagCnt is incremented on exit.
// Handles out-of-memory error.
extern int FV_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_add_tag_to_array";

   *tagArray = MEM_realloc(*tagArray, sizeof(tag_t) * (*tagCnt+1));

   if (*tagArray != NULL)
   {
      (*tagArray)[*tagCnt] = addTag;
      (*tagCnt)++;
   }
   else
   {
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, "1", function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
      goto CLEANUP;
   }

CLEANUP:
   return (ifail);
}

// This allocates/reallocates the array and adds the tag to the end of the array.
// Adds tag only if not already in the array.
// I/O argument tagCnt is incremented on exit if tag was added.
// Handles out-of-memory error.
extern int FV_add_unique_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag)
{
    int   ifail = ITK_ok;

    // Ignore a duplicate tag.
    if (FV_find_tag_in_array(*tagCnt, *tagArray, addTag) > -1)
       goto CLEANUP;

    CLEANUP(FV_add_tag_to_array(tagCnt, tagArray, addTag))

CLEANUP:
   return (ifail);
}

// Returns index in array of first tag found. If not found, returns -1.
extern int FV_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag)
{
    int   i = 0;
    int foundIdx = -1;

    if (!tagArray || (tagCnt < 1))
       goto CLEANUP;

    for (i=0; i<tagCnt; i++)
    {
        if (tagArray[i] == tag)
        {
           foundIdx = i;
	   goto CLEANUP;
        }
    }

CLEANUP:
    return foundIdx;
}

// Handle missing required argument value for custom functions. This throws an error!
int FV_handle_missing_arg_error(const char* functionName, char* argumentName)
{
	int ifail=-1;
	TC_write_syslog("ERROR: In %s, required argument %s is NULL\n", functionName, argumentName);
    return ifail;
}
extern int FV_strdup_plus(const char* inputString, int extraCnt, char** outputString)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_strdup_plus";
   char  intCharBuf[FV_INTEGER_LEN+1] = {'\0'};

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   *outputString = MEM_alloc(sizeof(char)*(tc_strlen(inputString)+1+extraCnt));

   if (*outputString != NULL)
   {
      tc_strcpy(*outputString, inputString);
   }
   else
   {
      sprintf(intCharBuf, "%d",  sizeof(char)*(tc_strlen(inputString)+1));
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, intCharBuf, function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}

// Given an object tag and a typename, if input object is
// is a type/subtype of the typename then return TRUE.
int FV_object_is_typeof(tag_t obj_tag, char* typename, logical* answer)
{
    int      ifail = ITK_ok;
    char*    function_name = "FV_object_is_typeof";
    tag_t    type_tag = NULLTAG;

    *answer = FALSE;

    if (typename == NULL)
       CLEANUP(FV_handle_missing_arg_error(function_name, "typename"))

    CLEANUP(TCTYPE_find_type(typename, NULL, &type_tag))

    CLEANUP(AOM_is_type_of(obj_tag, type_tag, answer))

CLEANUP:
    return ifail;
}

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
			EMH_ask_error_text (stat, &errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], texts[n_ifails-1] );
			//fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, ifails[n_ifails-1], lineNumber, errstring );
			fprintf(logfileptr, "%s: Error: %d at Line %d  -- %s\n", prog_name, ifails[n_ifails-1], lineNumber, texts[n_ifails-1] );
			fflush(logfileptr);
			MEM_free( errstring );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
			//TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], texts[n_ifails-1] );
			//fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, ifails[n_ifails-1], lineNumber, errstring );
			fprintf(logfileptr, "%s: Error: %d at Line %d -- %s\n", prog_name, ifails[n_ifails-1], lineNumber, texts[n_ifails-1] );
			fflush(logfileptr);

            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
		TC_write_syslog( "%s: Error: %d %s\n", prog_name, stat, errstring );
		fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, stat, lineNumber, errstring );
			fflush(logfileptr);
        MEM_free( errstring );
    }
    //TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	/*fprintf(logfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );*/
	fflush(logfileptr);
}

int FV_check_variantCondition_exist(struct FVEVariantInfostruct *strVarInfo,char *variantCondition,char **variantExpression)
{
	int			ifail			=	ITK_ok;
	char*		function_name	=	"FV_check_variantCondition_exist";
	int			iCounter		=	0;
	logical		isMatchFound	=	FALSE;

	TC_write_syslog("\n Enter %s\n", function_name);
	if(totalNoOfvExprs > 0)
	{
    		for(iCounter=0;iCounter<totalNoOfvExprs;iCounter++)
		{
			if( (strVarInfo[iCounter].vCondName) && (tc_strlen(strVarInfo[iCounter].vCondName)>0) && (variantCondition) && (tc_strlen(variantCondition)> 0))
			{
				if(stricmp(strVarInfo[iCounter].vCondName,variantCondition) == 0)
				{
					if(strVarInfo[iCounter].vCondExpr && tc_strlen(strVarInfo[iCounter].vCondExpr) > 0)
					{
						isMatchFound=TRUE;
						*variantExpression = (char *) MEM_alloc ((int)((strlen(strVarInfo[iCounter].vCondExpr) + 1)) * sizeof(char));
						tc_strcpy((*variantExpression), strVarInfo[iCounter].vCondExpr);
					}
				}
			}
			if(isMatchFound == TRUE)
				break;
		}
	}
	TC_write_syslog("\n Leaving %s\n", function_name);
	return ifail;
}

/****************************************************************************
 *
 * Function Name:   FVDT_delete_variant_condition
 *
 * Description:     This method deletes the variant condition set on
                    the BOMline. It gets the variant expression block.
                    Gets the expression from block.
                    Gets the clause list from the expression.
                    Deletes the clause list.
                    Removes the expression.
                    Deletes the expression.
                    The variant expression block is set to NULL.
                    bl_condition_tag attribute on bomline is set to NULL
                    BOM Window is saved and refresh
 *
 * Input Args:      1. window
 *                  2. bomline
 *--------------------------------------------------------------------------*
 * History
 *--------------------------------------------------------------------------*
 * Date         	    Name              Description of Change
 * Mar 28,2011	     Piyush Modak	      Method written
 *
 ****************************************************************************/


int FVDT_delete_variant_condition(tag_t window , tag_t bomLine)
{
    int ifail = ITK_ok;
    tag_t varExpBlockTag = NULLTAG;
    const char* theFunction         = "FVDT_delete_variant_condition";

    //Both the tags should not be nll
    if(window==NULLTAG || bomLine==NULLTAG)
    {
        return ifail;
    }
    //Do the function entry in Syslog file
    TC_write_syslog("\n\tINFO:Entering %s\n", theFunction);
    //First check whether the BOMLine already has the expression block associated to it
    ITK(BOM_line_ask_variant_e_block(bomLine , &varExpBlockTag))
    //Check if the variant expression block is not NULL
    if(varExpBlockTag)
    {
        int exp              = 0;
        int expressionCount  = 0;
        tag_t expressionLoop = NULLTAG;
        tag_t clauseListTag  = NULLTAG;
        tag_t *expressions   = NULL;

        //Delete the variant expression block to set multiple variant expression
        ITK(BOM_ask_variant_e_block(varExpBlockTag , &expressionCount , &expressions))
        //Remove all the expressions
        for(exp = 0 ; exp < expressionCount ; exp++)
        {
            //Lock the expression block against any modification
            ITK(AOM_refresh(varExpBlockTag , true))
            //Remove the expression from the block
            ITK(BOM_variant_e_block_remove( varExpBlockTag, expressions[exp]))
            //Save the expression block
            ITK(AOM_save(varExpBlockTag))
            //Remove the clause list from the BOMLine
            ITK(BOM_variant_condition_to_clause_list(window, expressionLoop, &clauseListTag ))
            //Release the lock from the expression block
            ITK(AOM_refresh(varExpBlockTag , false))
            //Lock the expressions against any modification
            ITK(AOM_refresh(expressions[exp] , true))
            //Delete the expressions
            ITK(AOM_delete(expressions[exp]))
            //Delete the clause list
            ITK(BOM_variant_delete_clause_list(clauseListTag))
        }

        //Remove the variant expression block from the BOMLine
        ITK(BOM_line_set_variant_e_block( bomLine, NULLTAG))
        //Set the tag to false this will remove the condition tag from BOMLine
        ITK(AOM_set_value_tag(bomLine , bomAttr_lineConditionTag, NULLTAG))
        //Deallocate the memory
        FVE_FREE(expressions);
        //Save the BOM window
        ITK(BOM_save_window(window))
        //Refresh the BOM window
        ITK(BOM_refresh_window(window))
    }
    //Do the function Exit in Syslog file
    TC_write_syslog("\n\tINFO:Exiting %s\n", theFunction);
    return ifail;
}


int FV_strdup(const char* inputString, char** outputString)
{
   int   ifail = ITK_ok;
   char* function_name = "FV_strdup";

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   *outputString = MEM_alloc(sizeof(char)*(tc_strlen(inputString)+1));

   if (*outputString != NULL)
   {
      tc_strcpy(*outputString, inputString);
   }
   else
   {
      EMH_store_error_s2(EMH_severity_error, FV_ALLOCATE_MEMORY_FAILURE, FV_int_to_static_string(tc_strlen(inputString)+1), function_name);
      ifail = FV_ALLOCATE_MEMORY_FAILURE;
   }

   return (ifail);
}

char* FV_int_to_static_string(int intValue)
{
   static char* intString = NULL;

   // Allocate the static string only once to max integer length.
   if (intString == NULL)
      intString = MEM_alloc(FV_INTEGER_LEN+1);

   sprintf(intString, "%d", intValue);

   return intString;
}

/*
get the description Name for Valid Values of SED type
*/
int FVE_get_desc_array(tag_t rev, char *attr,char *cellsProp,char *** value_array,int * retCnt)
{
	int		ifail				=	ITK_ok;
	char	*function_name		=	"FVE_get_desc_array";
	int		num_cells			=	0;
	int		k					=	0;
	int		num_cols			=	0;
	int		num_rows			=	0;
	int		cell_value_int		=	0;
	char	item_type[ITEM_type_size_c+1];
	char	cell_val_int[32]	 = "";
	char	*cell_value			=	NULL;
	tag_t	attr_value			=	NULLTAG;
	tag_t	*cells				=	NULL;
	tag_t	table_def			=	NULLTAG;

	tag_t	item				=	NULLTAG;


	TC_write_syslog("\n Enter %s\n", function_name);
	ITK(ITEM_ask_item_of_rev(rev, &item))
	ITK(ITEM_ask_type(item, item_type))

	ITK(AOM_ask_value_tag(rev, attr, &attr_value))
	ITK(AOM_ask_value_tag(attr_value, definitionPROP, &table_def))
	ITK(AOM_ask_value_int(table_def, colsPROP, &num_cols))
	ITK(AOM_ask_value_int(table_def, rowsPROP, &num_rows))

	ITK(AOM_ask_value_tags(attr_value, cellsPROP, &num_cells, &cells))

	(*value_array) = (char**) MEM_alloc((num_cells) * sizeof(char *));
	for(k = 0; k < num_cells; k++)
	{
		 if(strcmp(item_type, FVE_ParmDefSEDTYPE) == 0)
		{
			ITK(AOM_ask_value_string(cells[k], "desc", &cell_value))
			(*value_array)[k] = (char *) MEM_alloc((int) (strlen(cell_value)+ 1) * sizeof(char));
			strcpy((*value_array)[k], cell_value);
		}
	}
	*retCnt=num_cells;
	FVE_FREE(cells)
	TC_write_syslog("\n Exiting %s\n", function_name);

	return ifail;

}

/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                  */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  02/25/2013     		Kalyan	              Initial Creation              */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;


    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );        
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        printf( "ERROR: Invalid format for password file '%s'\n", passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);

    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");        
        return !ITK_ok ;
    }

    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;

    return ifail;
}


/**
**************************************************************************
*
*  Function Name:   FV_check_bomLine_has_matching_variantCondText
*
*  @desc			Checks if variant condition text on bom line matches with input string.
*  @see				
*
*  @param[in]:      bomLine - bom line tag
*  @param[in]:      str - text string to compare with
*  @param[out]:		isMatching - TRUE if varinat condition text matches with input string else FALSE.
*
*  @return         ITK success/failure ifail.
*
*--------------------------------------------------------------------------
* History
*--------------------------------------------------------------------------
* Date         	    Name               Description of Change
* 22-07-2013	    Ravindra Chaugule  Method written
****************************************************************************/
int FV_check_bomLine_has_matching_variantCondText(tag_t bomLineTag, char* str, logical* isMatching)
{
	int     ifail = ITK_ok;
	char*   function_name	=	"FV_check_bomLine_has_matching_variantCondText";

	tag_t   existVarExBlockTag = NULLTAG;
	int     cntExprs = 0;
	int     cntr = 0;
	tag_t*  exprsArr = NULL;
	char*   exprText = NULL;
	tag_t   condVeTag = NULLTAG;
	tag_t   bomWinTag = NULLTAG;
	tag_t   clauseListTag = NULLTAG;
	int     cntClauses = 0;
	char**  clausesStrArray = NULL;
	char*   varExprText = NULL;
	char*   strCopy = NULL;
	
	//int attribute=0;
	
	
	//FV_DEBUG_TXT(("\nEntering %s", function_name));

	*isMatching=FALSE;
	if(bomLineTag == NULLTAG || !str || tc_strlen(str)==0)
	{
		return ifail;
	}

	//If bom line has variant condition then get variant condition text 
	CLEANUP(BOM_line_ask_variant_e_block(bomLineTag, &existVarExBlockTag))
	if(existVarExBlockTag)
	{
		CLEANUP(BOM_ask_variant_e_block(existVarExBlockTag, &cntExprs, &exprsArr))
		for(cntr = 0; cntr<cntExprs; cntr++)
		{
			cntClauses=0;
			condVeTag=NULLTAG;
			clauseListTag=NULLTAG;

			CLEANUP(BOM_variant_expr_split_load_if(exprsArr[cntr], &condVeTag))
			if(condVeTag != NULLTAG)
			{
				CLEANUP(BOM_line_ask_window(bomLineTag, &bomWinTag))
				if(bomWinTag != NULLTAG)
					CLEANUP(BOM_variant_condition_to_clause_list(bomWinTag, condVeTag, &clauseListTag))
			}
			if(clauseListTag != NULLTAG)
			{
				CLEANUP(BOM_variant_clause_list_text(clauseListTag, &cntClauses, &clausesStrArray))
				if(cntClauses>0)
				{
					CLEANUP(FV_build_delimited_string(cntClauses, clausesStrArray, " ", &varExprText))
					TC_write_syslog("\n Actual variant condition text on Bom line is => %s \n", varExprText);

					//Remove spaces in varinat condition text from bom line so that it will be easy for comparison
					CLEANUP(FV_remove_all_chars(varExprText, ' '))
					TC_write_syslog("\n Modified variant condition text on Bom line is => %s \n", varExprText);
					if(varExprText && tc_strlen(varExprText)>0)
					{
						//Remove spaces from string to be compared
						CLEANUP(FV_strdup(str, &strCopy))
						CLEANUP(FV_remove_all_chars(strCopy, ' '))

						//Compare modified variant condition text with modified input string
						if(tc_strcmp(varExprText, strCopy)==0)
						{
							TC_write_syslog("\n Variant condition expression text matches.");
							*isMatching=TRUE;
							break;
						}
						FVE_FREE(strCopy)
						FVE_FREE(varExprText)
					}
					/*Commenting out call to FV_FREE_STRINGS because it gives error 908 in syslog
					For more details see comments in CLEANUP*/
					//FV_FREE_STRINGS(clausesStrArray)
					FVE_FREE(clausesStrArray)				
				}
			}
		
		}//End of for loop
		
	}

CLEANUP:
	
	FVE_FREE(exprsArr)
	//FVE_FREE(exprText)
	FVE_FREE(strCopy)
	FVE_FREE(varExprText)
	/*Commenting out call to FV_FREE_STRINGS because it gives error 908 in syslog 
	while freeing string array (which is output from ITK API BOM_variant_clause_list_text)
	NOTE: MEM_free on individual elements of string array also fails. Observed only with string array returned from ITK API BOM_variant_clause_list_text
	*/
	//FV_FREE_STRINGS(clausesStrArray)
	FVE_FREE(clausesStrArray)
	//FV_DEBUG_TXT(("\nExiting %s", function_name));
	return ifail;
}
