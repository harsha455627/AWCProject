//
//  @file
//  This file contains the common header components
//

#include <tc/tc.h>
#include <base_utils/Mem.h>
#include <fclasses/tc_string.h>
#include <tc/emh.h>
#include <common/emh_const.h>

#include <string>

using namespace std;



/**
 * SEEDS custom error base.
 */
#define SEEDS_CUSTOM_ERROR_BASE (EMH_USER_error_base + 600)

#define ITK( argument )						                                \
{									                                        \
	if (retcode == ITK_ok)													\
	{																		\
		retcode = argument;                                                 \
		if ( retcode != ITK_ok )											\
		{																	\
			char* s;                                                        \
			TC_write_syslog( " "#argument "\n" );                           \
			TC_write_syslog( "  returns [%d]\n", retcode );                 \
			EMH_ask_error_text (retcode, &s);                               \
			EMH_store_error(EMH_severity_error,retcode);                    \
			TC_write_syslog( "  Teamcenter Error: [%s]\n", s);              \
			TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
			if (s != 0) MEM_free (s);                                       \
		}                                                                   \
	}																		\
}

#define UOM_NAME "symbol"
#define EACH "each"
#define LITER "l"
#define KG "kg"
#define GM "g"

int GetLocaleTextValue ( char* , string &);
