/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/


package com.o6.services.loose.customservicelibrary._2017_11;

/**
 *
 */
 @SuppressWarnings("unchecked")
public interface O6TaneCustomService
{


    

    /**
     * .
     *
     * @param obj
     *        None
     *
     * @param targetItemtype
     *        None
     *
     * @param targetItemPattern
     *        None
     *
     * @param targetItemVersion
     *        None
     *
     * @return
     *
     */
    public com.teamcenter.soa.client.model.ServiceData copyObjectAndCreateRelation ( com.teamcenter.soa.client.model.ModelObject obj, String targetItemtype, String targetItemPattern, String targetItemVersion );



}
