#ifndef O6Stock_HANDLER_H_INCLUDED
#define O6Stock_HANDLER_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <tc/emh_errors.h>
#include <tc/preferences.h>
#include <textsrv/textserver.h>
#include <pom/pom/pom.h>
#include <pom/enq/enq.h>
#include <tccore/custom.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/item_msg.h>
#include <tccore/item_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/workspaceobject.h>
#include <tccore/method.h>
#include <tccore/grm_msg.h>
#include <tccore/tc_msg.h>
#include <user_exits/user_exit_msg.h>
#include <ps/ps.h>
#include <qry/qry.h>
#include <qry/crf.h>
#include <bom/bom_msg.h>
#include <epm/epm.h>
#include <me/me_msg.h>
#include <ae/dataset.h>
#include <ict/ict_userservice.h>
#include <dispatcher/dispatcher_itk.h>
#include <commun.h>
extern int O6Stock_manage_request( EPM_action_message_t msg );
extern int O6Stock_manage_goods( EPM_action_message_t msg );
extern int O6Stock_set_goods_request_as_rejected( EPM_action_message_t msg ) ;
extern int O6Stock_set_goods_request_as_approved( EPM_action_message_t msg ) ;
extern int O6Stock_set_goods_request_as_cancelled( EPM_action_message_t msg ) ;
#endif /* O6Stock_HANDLER_H_INCLUDED */
// End-Of-File
