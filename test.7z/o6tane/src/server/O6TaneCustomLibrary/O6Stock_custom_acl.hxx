//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension O6Stock_custom_acl
 *
 */
 
#ifndef O6STOCK_CUSTOM_ACL_HXX
#define O6STOCK_CUSTOM_ACL_HXX
#include <tccore/method.h>
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern O6TANECUSTOMLIBRARY_API int O6Stock_custom_acl(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
                
#endif  // O6STOCK_CUSTOM_ACL_HXX
