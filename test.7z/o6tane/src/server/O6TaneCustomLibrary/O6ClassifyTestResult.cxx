//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6ClassifyTestResult
 *
 */
#include <O6TaneCustomLibrary/O6ClassifyTestResult.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <metaframework/CreateInput.hxx>
#include <tccore/method.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tccore/tctype.h>
#include <ics/ics.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>

#define TEST_REVISION "O6_TestRevision"
#define RESULT_REVISION "O6_TestResultRevision"
#define ICS_ClS "ics_classified"
#define DELM "DEF"
#define RSL "RSL"

/**
 * Function    :  classifyObject
 * Description :  Classifies the object
 * Input       :
 * 		ObjRev  - Object tag
 * 		classid - Class Id of classification tree
 *
 */
int classifyObject(tag_t ObjRev, char* classid){
	int retcode = ITK_ok;

	    tag_t classtag = NULLTAG;
	    tag_t classificationObject = NULLTAG;

		ITK(ICS_find_class(classid, &classtag));
		ITK(ICS_create_classification_object(ObjRev, NULL, classtag,&classificationObject));
		ITK(ICS_classify_wsobject(ObjRev, classificationObject));

	return retcode;
}

/**
 * Function    :  O6ClassifyTestResult
 * Description :  Extension Method
 * Input       :
 * 		msg  - Message
 * 		args - Method arguments
 *
 */
int O6ClassifyTestResult(METHOD_message_t * /*msg*/, va_list args) {
	int retcode = ITK_ok;
	bool isNull = true;
	tag_t primaryObj = NULLTAG;
	tag_t secondayObj = NULLTAG;

	va_list largs;
	va_copy( largs, args);
	Teamcenter::CreateInput *creInput = va_arg(largs, Teamcenter::CreateInput*);
	va_end( largs );

	ITK(creInput->getTag("primary_object", primaryObj, isNull));
	if ((isNull == FALSE) && (retcode == ITK_ok) && primaryObj != NULL) {

		ITK(creInput->getTag("secondary_object", secondayObj, isNull));
		if ((isNull == FALSE) && (retcode == ITK_ok) && secondayObj != NULL) {

			tag_t primaryObjType = NULLTAG;

			ITK(TCTYPE_ask_object_type(primaryObj, &primaryObjType));
			if (primaryObjType != NULLTAG ) {

				char* primobjtypename = NULL;
				ITK(TCTYPE_ask_name2(primaryObjType, &primobjtypename));
				//TC_write_syslog("    new_rev: %s \n", primobjtypename);
				if (primobjtypename != NULL && tc_strcmp(primobjtypename, TEST_REVISION) == 0) {

					tag_t secondayObjType = NULLTAG;
					ITK(TCTYPE_ask_object_type(secondayObj, &secondayObjType));
					if (secondayObjType != NULLTAG ) {

						char* secondobjtypename = NULL;
						ITK(TCTYPE_ask_name2(secondayObjType, &secondobjtypename));
						//TC_write_syslog("    new_rev: %s \n",secondobjtypename);
						if (secondobjtypename != NULL && tc_strcmp(secondobjtypename, RESULT_REVISION) == 0) {

							logical isClassified = FALSE;
							ITK(ICS_is_wsobject_classified(primaryObj, &isClassified ));

							logical isSecClassified = FALSE;
							ITK(ICS_is_wsobject_classified(secondayObj, &isSecClassified ));

							if (isClassified) {
								if (!isSecClassified) {
									tag_t classificationObject = NULLTAG;
									ITK(ICS_ask_classification_object(primaryObj, &classificationObject ));
									if (classificationObject != NULLTAG ) {
										tag_t classTag = NULLTAG;
										ITK(ICS_ask_class_of_classification_obj(classificationObject, &classTag));
										if (classTag != NULLTAG ) {
											char* classID = NULL;
											ITK(AOM_ask_value_string(classTag, "cid", &classID));
											if (classID != NULL) {
												char* dupstr = (char*) MEM_alloc(sizeof(char) * (tc_strlen(classID) + 1));
												tc_strcpy(dupstr, classID);

												//TC_write_syslog("\nClass IS : %s", dupstr);
												char* substr = tc_strstr(dupstr, DELM);
												if (substr != NULL) {

													char* tmpstr = (char*) MEM_alloc(sizeof(char) * (tc_strlen(classID) + 1));
													memset(tmpstr, '\0', sizeof(tmpstr));

													tc_strncpy(tmpstr, dupstr, 3);

													tc_strcat(tmpstr, RSL);
													tc_strcat(tmpstr, (substr + 3));

													//TC_write_syslog("\ntmpstr : %s",tmpstr);

													ITK(classifyObject(secondayObj,tmpstr));

													MEM_free(tmpstr);
													tmpstr = NULL;

												}

												MEM_free(dupstr);
												dupstr = NULL;
												MEM_free(classID);
												classID = NULL;
											}
										}
									}
								}
							} else {
								char* objname = NULL;
								ITK(AOM_ask_value_string(primaryObj, "object_string", &objname));
								if (objname != NULL) {
									TC_write_syslog("\nObject : %s is not classified",objname);
									MEM_free(objname);
									objname = NULL;
								}
							}

							MEM_free(secondobjtypename);
							secondobjtypename = NULL;
						}
					}
					MEM_free(primobjtypename);
					primobjtypename = NULL;
				}
			}
		}

	}

 return retcode;

}
