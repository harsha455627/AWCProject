/*===============================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
=================================================================================
File description:
  A production utility that dumps info about BVRs and their occurrence threads.

===============================================================================
Date               Name                    Description of Change
Sep 2014           ME Dawson               Created.
===============================================================================*/

#include "FV_includes.h"
#include <property/nr.h>

extern FILE* logfileptr;	

#define FV_UTILITY_TRACE(TXT)       \
	{                           \
	   (printf TXT );           \
           (TC_write_syslog TXT );  \
        }

int validateRevisions(int revisionCnt, tag_t* revisionTags);

int getLevel2Items(tag_t topItemTag, const char* viewTypeName, const char* revisionRule,
	       	   tag_t** level2ItemTags, int* level2ItemCnt);

int utilityLogin(const char* login_user, const char* login_password, const char* login_group);

int startLogging(const char* logFilename, const char* function_name, char* structIdxString, int argc, char** argv);

void stopLogging(const char* function_name, char* structIdxString, int input_ifail);

int findItemByItemID(const char* itemID, tag_t* itemTag);

FILE* logfileptr;

static void print_usage(void)
{	printf("\n\nStructureValUtility validates the BOMViewRevision (BVR) for each revision of an Item.\n");
 	printf("It will optionally perform the same validation for each immediate child of the input Item.\n");
        printf("\n");
        printf("**********************************************************************************\n");
        printf("Usage: StructureValUtility<args>\n");
        printf(" Args include the following:\n");
        printf(" -u=<login user id>\n");
        printf(" -p=<login password>\n");
        printf(" -g=<login group>\n");
        printf(" -itemID=<Item ID of Item to validate> (REQUIRED)\n");
        printf(" -validateChildren=<true/false - default is false> (also validate BVRs of immediate children of the latest revision of input Item)\n");
	printf(" -log= <log filename> (REQUIRED)\n");
        printf("\n");
        printf(" -h=<help>\n");
        printf("\n");
        printf("Examples:\n");
        printf("StructureValUtility -u=infodba -p=infodba -g=dba -itemID=F000002 -log=item_val.log\n");
        printf("StructureValUtility -u=infodba -p=infodba -g=dba -itemID=F000002 -validateChildren=true -log=child_val.log\n");
        printf("**********************************************************************************\n\n");
}

extern int ITK_user_main(int retCount, char **retValue)
{
    int ifail = ITK_ok;
    char* function_name = "StructureValUtility (main)";
    char* login_group = NULL;
    char* login_user = NULL;
    char* login_password = NULL;
    char* itemID =  NULL;
    char* valChildrenStr =  NULL;
    char* logFilename = NULL;

    char*   itemObjStr = NULL;
    char*   itemUID = NULL;
    char*   lev2ItemObjStr = NULL;
    char*   lev2ItemUID = NULL;
    tag_t*  revisionTags = NULL;
    tag_t*  lev2ItemTags = NULL;
    tag_t   itemTag = NULLTAG;
    tag_t   lev2ItemTag = NULLTAG;
    int     revisionCnt = 0;
    int     lev2ItemCnt = 0, lev2Idx = 0;
    logical valChildren = false;
    logical isItem = false;

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

    /*
     * Process the input arguments.
     */
    login_user = ITK_ask_cli_argument("-u=");
    login_password = ITK_ask_cli_argument("-p=");
    login_group = ITK_ask_cli_argument("-g=");
    itemID = ITK_ask_cli_argument("-itemID=");
    logFilename = ITK_ask_cli_argument("-log=");
    valChildrenStr = ITK_ask_cli_argument("-validateChildren=");
    if (valChildrenStr != NULL)
    {
       valChildren = (tc_strcasecmp(valChildrenStr, FV_TRUE_VALUE) == 0);
    }

    if ((itemID == NULL) || (logFilename == NULL))
    {
       FV_UTILITY_TRACE(("\n\n!!!!!!!!!!! ERROR: A required argument is missing\n\n"))
       print_usage();
       exit(0);
    }

    /*
     * Initialize logging/tracing and login to Teamcenter. 
     */
    CLEANUP(startLogging(logFilename, function_name, NULL, retCount, retValue))
    CLEANUP(utilityLogin(login_user, login_password, login_group))

    /*
     * Get the input Item.
     */
    CLEANUP(findItemByItemID(itemID, &itemTag))

    if (itemTag == NULLTAG)
    {
       FV_UTILITY_TRACE(("\n!!!!!!!!!!!! ERROR: cannot find Item ID: %s\n", itemID))
       fprintf(logfileptr,"\n!!!!!!!!!!!! ERROR: cannot find Item ID: %s\n", itemID);   
       goto CLEANUP;
    }

    CLEANUP(FV_object_is_typeof(itemTag, ItemTYPE, &isItem))

    if (!isItem)
    {
       FV_UTILITY_TRACE(("\n!!!!!!!!!!!! ERROR: Item ID %s is NOT a type of Item\n", itemID))
       fprintf(logfileptr,"\n!!!!!!!!!!!! ERROR: Item ID %s is NOT a type of Item\n", itemID);   
       goto CLEANUP;
    }

    CLEANUP(AOM_ask_value_string(itemTag, object_stringPROP, &itemObjStr))
    CLEANUP(AOM_tag_to_string(itemTag, &itemUID))

    FV_UTILITY_TRACE((">>>Validating: %s, %s (%s)\n",  FV_ask_object_type_display_name_static(itemTag), itemObjStr, itemUID))
    fprintf(logfileptr, "Validating: %s, %s (%s)\n",  FV_ask_object_type_display_name_static(itemTag), itemObjStr, itemUID);

   CLEANUP(AOM_ask_value_tags(itemTag, revision_listPROP, &revisionCnt, &revisionTags))
   FV_UTILITY_TRACE((">>>%s has %d revisions\n", itemObjStr, revisionCnt))
   fprintf(logfileptr, "%s has %d revisions\n", itemObjStr, revisionCnt);

   // Validate BVRs for each revision of the input Item.
   CLEANUP(validateRevisions(revisionCnt, revisionTags))
   FVE_FREE(revisionTags)
   revisionCnt = 0;

   // Optionally, validate BVRs for direct children of latest revision of input item.
   if (valChildren)	   
   {
      CLEANUP(getLevel2Items(itemTag, viewVIEW, NULL, &lev2ItemTags, &lev2ItemCnt))

      FV_UTILITY_TRACE(("\n\n>>>####################################################################################\n"))
      fprintf(logfileptr, "\n\n####################################################################################\n");

      FV_UTILITY_TRACE((">>>Validating %d immediate children of: %s\n",  lev2ItemCnt, itemObjStr))
      fprintf(logfileptr, "Validating %d immediate children of: %s\n",  lev2ItemCnt, itemObjStr);

      FV_UTILITY_TRACE((">>>####################################################################################\n"))
      fprintf(logfileptr, "####################################################################################\n");

      for (lev2Idx=0; lev2Idx<lev2ItemCnt; lev2Idx++)
      {
          lev2ItemTag = lev2ItemTags[lev2Idx];
          CLEANUP(AOM_ask_value_string(lev2ItemTag, object_stringPROP, &lev2ItemObjStr))
          CLEANUP(AOM_tag_to_string(itemTag, &lev2ItemUID))

           FV_UTILITY_TRACE(("\n\n>>>Validating child: %s, %s (%s)\n",  FV_ask_object_type_display_name_static(lev2ItemTag), lev2ItemObjStr, lev2ItemUID))
           fprintf(logfileptr, "\n\nValidating child: %s, %s (%s)\n",  FV_ask_object_type_display_name_static(lev2ItemTag), lev2ItemObjStr, lev2ItemUID);

          CLEANUP(AOM_ask_value_tags(lev2ItemTag, revision_listPROP, &revisionCnt, &revisionTags))
          FV_UTILITY_TRACE((">>>%s has %d revisions\n", lev2ItemObjStr, revisionCnt))
          fprintf(logfileptr, "%s has %d revisions\n", lev2ItemObjStr, revisionCnt);

          // Validate BVRs for each revision of this child Item.
          CLEANUP(validateRevisions(revisionCnt, revisionTags))

          FVE_FREE(lev2ItemObjStr)
          FVE_FREE(lev2ItemUID)
          FVE_FREE(revisionTags)
	  revisionCnt = 0;
      }
   }

CLEANUP:
    stopLogging(function_name, NULL, ifail);

    // Don't free the input args!
    FVE_FREE(itemObjStr)
    FVE_FREE(itemUID)
    FVE_FREE(revisionTags)
    FVE_FREE(lev2ItemTags)

    ITK_exit_module( true );

    return ifail;
}

int validateRevisions(int revisionCnt, tag_t* revisionTags)
{
    int ifail = ITK_ok;
    char*   itemRevObjStr = NULL;
    char*   itemRevUID = NULL;
    char*   bvrObjStr = NULL;
    char*   bvrUID = NULL;
    char*   occThreadUID = NULL;
    char*   childObjStr = NULL;
    char*   childUID = NULL;
    char*   childRevObjStr = NULL;
    char*   staticTypeName = NULL;
    tag_t*  bvrTags = NULL;
    tag_t*  occThreadTags = NULL;
    tag_t   itemRevTag = NULLTAG;
    tag_t   bvrTag = NULLTAG;
    tag_t   childTag = NULLTAG;
    tag_t   childBOMViewTag = NULLTAG;
    tag_t   childRevTag = NULLTAG;
    int     revIdx = 0;
    int     bvrCnt = 0, bvrIdx = 0;
    int     occCnt = 0, occIdx = 0;
    int     tempFail = ITK_ok;
    logical isPreciseBVR = false;

   for (revIdx=0; revIdx<revisionCnt; revIdx++)
   {
      itemRevTag = revisionTags[revIdx];
      CLEANUP(AOM_ask_value_string(itemRevTag, object_stringPROP, &itemRevObjStr))
      CLEANUP(AOM_tag_to_string(itemRevTag, &itemRevUID))

      CLEANUP(ITEM_rev_list_all_bom_view_revs(itemRevTag, &bvrCnt, &bvrTags))

      FV_UTILITY_TRACE(("\n   >>>Revision: %s (%s) has %d BVRs\n", itemRevObjStr, itemRevUID, bvrCnt))
      fprintf(logfileptr, "\n   Revision: %s (%s) has %d BVRs\n", itemRevObjStr, itemRevUID, bvrCnt);

      if (bvrCnt > 0)
      {
         for (bvrIdx=0; bvrIdx<bvrCnt; bvrIdx++)
	 {
             bvrTag = bvrTags[bvrIdx];
             CLEANUP(AOM_ask_value_string(bvrTag, object_stringPROP, &bvrObjStr))
             CLEANUP(AOM_tag_to_string(bvrTag, &bvrUID))
	     CLEANUP(PS_ask_is_bvr_precise(bvrTag, &isPreciseBVR))
	     CLEANUP(PS_list_occurrences_of_bvr(bvrTag, &occCnt, &occThreadTags))

	     if (isPreciseBVR)
	     {
                FV_UTILITY_TRACE(("      >>>Precise BVR[%d]: %s (%s) has %d occurrences\n", bvrIdx, (bvrObjStr?bvrObjStr:"NAME UNKNOWN"), bvrUID, occCnt))
                fprintf(logfileptr, "      Precise BVR[%d]: %s (%s) has %d occurrences\n", bvrIdx, (bvrObjStr?bvrObjStr:"NAME UNKNOWN"), bvrUID, occCnt);
	     }
	     else
	     {
                FV_UTILITY_TRACE(("      >>>Imprecise BVR[%d]: %s (%s) has %d occurrences\n", bvrIdx, (bvrObjStr?bvrObjStr:"NAME UNKNOWN"), bvrUID, occCnt))
                fprintf(logfileptr, "      Imprecise BVR[%d]: %s (%s) has %d occurrences\n", bvrIdx, (bvrObjStr?bvrObjStr:"NAME UNKNOWN"), bvrUID, occCnt);
	     }

	     for (occIdx=0; occIdx<occCnt; occIdx++)
	     {
                CLEANUP(AOM_tag_to_string(occThreadTags[occIdx], &occThreadUID))
		staticTypeName = FV_ask_object_type_display_name_static(occThreadTags[occIdx]);

                FV_UTILITY_TRACE(("\n         >>>Occurrence Thread[%d]: %s (%s)\n", occIdx, (staticTypeName?staticTypeName:"TYPE UNKNOWN"), occThreadUID))
                fprintf(logfileptr, "\n         Occurrence Thread[%d]: %s (%s)\n", occIdx, (staticTypeName?staticTypeName:"TYPE UNKNOWN"), occThreadUID);
                fflush(logfileptr);
                fflush(stdout);

		tempFail = PS_ask_occurrence_child(bvrTag, occThreadTags[occIdx], &childTag, &childBOMViewTag);
		if ((tempFail != ITK_ok) || (childTag == NULLTAG))
		{
                   FV_UTILITY_TRACE(("\n         >>>Occurrence Thread[%d] (%s): FAILED to get child\n", occIdx, occThreadUID))
                   fprintf(logfileptr, "\n         Occurrence Thread[%d] (%s): FAILED to get child\n", occIdx, occThreadUID);
                   goto OCC_LOOP_CLEANUP;
		}

                CLEANUP(AOM_ask_value_string(childTag, object_stringPROP, &childObjStr))
                CLEANUP(AOM_tag_to_string(childTag, &childUID))
		staticTypeName = FV_ask_object_type_display_name_static(childTag);

                FV_UTILITY_TRACE(("         >>>Occurrence Child: %s, %s (%s)\n", (staticTypeName?staticTypeName:"TYPE UNKNOWN"), (childObjStr?childObjStr:"NAME UNKNOWN"), childUID))
                fprintf(logfileptr, "         Occurrence Child: %s, %s (%s)\n", (staticTypeName?staticTypeName:"TYPE UNKNOWN"), (childObjStr?childObjStr:"NAME UNKNOWN"), childUID);

		if (!isPreciseBVR)
		{
                   FV_UTILITY_TRACE(("         >>>Attempting to get latest revision of this occurrence Item...\n"))
                   fprintf(logfileptr, "         Attempting to get latest revision of this occurrence Item...\n");
                   fflush(logfileptr);
                   fflush(stdout);

		   tempFail = ITEM_ask_latest_rev(childTag, &childRevTag);
		   if (tempFail == ITK_ok)
		   {
                      CLEANUP(AOM_ask_value_string(childRevTag, object_stringPROP, &childRevObjStr))
                      FV_UTILITY_TRACE(("         >>>Latest revision: %s\n", (childRevObjStr?childRevObjStr:"NAME UNKNOWN")))
                      fprintf(logfileptr, "         Latest revision: %s\n", (childRevObjStr?childRevObjStr:"NAME UNKNOWN"));
		   }
		   else
		   {
                      FV_UTILITY_TRACE(("         >>>FAILED in ITEM_ask_latest_rev(), error = %d\n", tempFail))
                      fprintf(logfileptr, "         FAILED in ITEM_ask_latest_rev(), error = %d\n", tempFail);
		   }
		}

OCC_LOOP_CLEANUP:
                fflush(logfileptr);
                fflush(stdout);
		FVE_FREE(occThreadUID)
		FVE_FREE(childUID)
		FVE_FREE(childObjStr)
		FVE_FREE(childRevObjStr)
             }

             fflush(logfileptr);
             fflush(stdout);
	     FVE_FREE(bvrObjStr)
	     FVE_FREE(bvrUID)
	     FVE_FREE(occThreadTags)
	 }
      }


//REVISION_LOOP_CLEANUP://modified by harsha
      fflush(logfileptr);
      fflush(stdout);
      FVE_FREE(itemRevObjStr)
      FVE_FREE(itemRevUID)
      FVE_FREE(bvrTags)
   }

CLEANUP:

    return ifail;
}

int getLevel2Items(tag_t topItemTag, const char* viewTypeName, const char* revisionRule,
	       	   tag_t** level2ItemTags, int* level2ItemCnt)
{
    int         ifail = ITK_ok;
    char*       function_name = "getLevel2Items";
    char*       localRevisionRule = NULL;
    char*       localViewType = NULL;
    tag_t*      level2BomlineTags = NULL;
    tag_t       revisionRuleTag = NULLTAG;
    tag_t       topLineTag = NULLTAG;
    tag_t       bomViewTag = NULLTAG;
    tag_t       bomWindowTag = NULLTAG;
    tag_t       itemTag = NULLTAG;
    int         level2BomlineCnt = 0;
    int         lev2Idx = 0;
    logical     isBomlineReadable = FALSE;

    *level2ItemTags = NULL;
    *level2ItemCnt = 0;

    if (topItemTag == NULLTAG)
       CLEANUP(FV_handle_missing_arg_error(function_name, "topItemTag"))

    // If view type not supplied by caller, use "view" view. 
    localViewType = (char*) (viewTypeName ? viewTypeName:viewVIEW);
    CLEANUP(FV_item_ask_bom_view_by_viewname(topItemTag, localViewType, &bomViewTag))

    // If revision rule not supplied by caller, use "Latest Working".
    localRevisionRule = (char*) (revisionRule ? revisionRule:Latest_WorkingREVISIONRULE);
    CLEANUP(CFM_find(localRevisionRule, &revisionRuleTag))

    CLEANUP(BOM_create_window(&bomWindowTag))
    CLEANUP(BOM_set_window_config_rule(bomWindowTag, revisionRuleTag))
    CLEANUP(BOM_set_window_pack_all(bomWindowTag, true))
    CLEANUP(BOM_set_window_top_line(bomWindowTag, topItemTag, NULLTAG, bomViewTag, &topLineTag))

    CLEANUP(BOM_line_ask_child_lines(topLineTag, &level2BomlineCnt, &level2BomlineTags))

    // Fastest to preallocate array.
    CLEANUP(FV_alloc_tag_array(level2BomlineCnt, level2ItemTags))

    for (lev2Idx=0; lev2Idx<level2BomlineCnt; lev2Idx++)
    {
       CLEANUP(FV_is_bomline_readable(level2BomlineTags[lev2Idx], &isBomlineReadable))
       if (isBomlineReadable)
       {	    
          CLEANUP(AOM_ask_value_tag(level2BomlineTags[lev2Idx], bomAttr_lineItemTag, &itemTag))
          (*level2ItemTags)[*level2ItemCnt] = itemTag;
          (*level2ItemCnt)++;
       }
    }

CLEANUP:
   FV_UTILITY_TRACE(("\n>>>Found %d second level items\n", *level2ItemCnt))
   fprintf(logfileptr, "\nFound %d second level items\n", *level2ItemCnt);

   if (bomWindowTag != NULLTAG)
   {
      ITK(BOM_close_window(bomWindowTag))
   }

   FVE_FREE(level2BomlineTags)

   return ifail;
}

int startLogging(const char* logFilename, const char* function_name, char* structIdxString, int argc, char** argv)
{
    int ifail = ITK_ok;
    char*  startTime = NULL;
    int    argIdx = 0;

    logfileptr = fopen(logFilename, "w");
    if (logfileptr == NULL)
    {
      FV_UTILITY_TRACE(("!!!!!!!!!!! ERROR: failed creating log file: %s\n", logFilename))
      ifail = 99999;
      goto CLEANUP;
    }

    // If structIdx is NOT NULL then we are in a subprocess and need to suppress some logging.
    if (structIdxString == NULL)
    {
       FV_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &startTime);
       FV_UTILITY_TRACE((">>>Entering %s at %s\nArguments:\n", function_name, startTime))
       fprintf(logfileptr, "Entering %s at %s\nArguments:\n", function_name, startTime);

       // Dump the arguments
       for (argIdx=0; argIdx<argc; argIdx++)
       {
          // Do NOT expose the password value.
          if ( argv[argIdx] && (tc_strlen(argv[argIdx]) > 3) &&
	       (FV_strstr_ignore_case(argv[argIdx], "-p=") || FV_strstr_ignore_case(argv[argIdx], "-p ")) ) 
	  {
             FV_UTILITY_TRACE(("%s\n", "-p=######################"))
             fprintf(logfileptr, "%s\n", "-p=######################");
	  }
	  else
	  {
             FV_UTILITY_TRACE(("%s\n", argv[argIdx] ? argv[argIdx]:"NAME UNKNOWN"))
             fprintf(logfileptr, "%s\n", argv[argIdx] ? argv[argIdx]:"NAME UNKNOWN");
	  }
       }
       FV_UTILITY_TRACE(("\n\n"))
       fprintf(logfileptr, "\n\n");
    }

CLEANUP:
    FVE_FREE(startTime)
    fflush(logfileptr);
    fflush(stdout);

    return ifail;
}

int utilityLogin(const char* login_user, const char* login_password, const char* login_group)
{
    int ifail = ITK_ok;

    ITK_initialize_text_services (0);
    ITK(ITK_init_module (login_user, login_password, login_group))
    ITK(ITK_set_bypass( true))

    if (ifail != ITK_ok)
    {
       FV_UTILITY_TRACE(("!!!!!!!!!!! ERROR: Login with user id: %s, group:%s is unsuccessful\n", login_user, login_group))
       fprintf(logfileptr, "!!!!!!!!!!! ERROR: Login with user id: %s, group:%s is unsuccessful\n", login_user, login_group);
    }		

    return ifail;
 }		

void stopLogging(const char* function_name, char* structIdxString, int input_ifail)
{
    char*  endTime = NULL;

    // If structIdx is NOT NULL then we are in a subprocess and need to suppress some logging.
    if (structIdxString == NULL)
    {
       FV_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &endTime);
       FV_UTILITY_TRACE(("\n>>>Exiting %s, %s, ifail = %d\n", function_name, endTime, input_ifail))
       fprintf(logfileptr,"\nExiting %s, %s, ifail = %d\n", function_name, endTime, input_ifail);   
    }

    fflush(logfileptr);
    fclose(logfileptr);

    fflush(stdout);

    FVE_FREE(endTime)

    return;
}

int findItemByItemID(const char* itemID, tag_t* itemTag)
{
    int    ifail = ITK_ok;
    char*  function_name = "findItemByItemID";
    char*  attrs[1] =  { item_idPROP };
    char*  values[1] = {""};
    tag_t* itemTags = NULL;
    int    itemCnt = 0;

   *itemTag = NULLTAG;

   if (itemID == NULLTAG)
      CLEANUP(FV_handle_missing_arg_error(function_name, "itemID"))

   values[0] = (char*) itemID;

   CLEANUP(ITEM_find_items_by_key_attributes(1, attrs, values, &itemCnt, &itemTags)) 

   if (itemCnt > 0)
   {
      *itemTag = itemTags[0];  
   }

CLEANUP:
   FVE_FREE(itemTags)
   return ifail;
}

