//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6_custom_register_properties
 *
 */
#include <O6TaneCustomLibrary/O6_custom_register_properties.hxx>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <fclasses/tc_string.h>
#include <tccore/aom_prop.h>
#include<string>
#include <sstream>
#include <vector>
#include <tc/preferences.h>
#include <tccore/grm.h>
#include <tccore/workspaceobject.h>

#define PRIMARYOBJECT "Primary"
#define SECONDARYOBJECT "Secondary"
#define PREF_TO_GET_VALUES "SEEDS_path_to_RMRegDoss"
#define STORAGE_CLASS_OBJ "O6_GenRMRevision"
#define STORAGE_CLASS_PROP "o6_inter_drg_ref"
using namespace std;
int Properties_ask_is_required_value (METHOD_message_t *  m, va_list  args);
/**
 * Function    :  getDelimitedValuesForPrefValue
 * Description :  Used to seperate values based on delimiter.
 * Input       :
 *      sPrefValue 	      - String preference value
 *      pcDelimiter       - Char pointer containing delimited values
 * Output	   :
 * 		&vDelimitedValues - Address of Vector containing values
 */
void getDelimitedValuesForPrefValue ( string sPrefValue, vector<string>&vDelimitedValues, char pcDelimiter )
{
	std::istringstream ss( sPrefValue );

	string value;

	while ( std::getline ( ss, value, pcDelimiter ) )
	{
		vDelimitedValues.push_back ( value );
	}
}
int O6_custom_register_properties( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
	METHOD_id_t method;

	METHOD_register_prop_method(STORAGE_CLASS_OBJ, STORAGE_CLASS_PROP,PROP_ask_value_tags_msg, Properties_ask_is_required_value,0, &method );

	return 0;

}

int Properties_ask_is_required_value (METHOD_message_t *  m, va_list  args){

			int retcode 					= ITK_ok;
		   char **pcTraversalAttrName    	=  NULL;
		   tag_t  inputTag 					= NULLTAG;
		   int numCount 					= 0;
		   tag_t  propTag 					= NULLTAG;
		   int*       num 					= NULL;
		   tag_t**    values 				= NULL;
		   va_list    copyArgs;
		   tag_t RelationTag 				= NULLTAG;
		   int count						= 0;
			char* TypeOfObject 				= NULL;
		   char* RMRegDossType 				= NULL;
		   tag_t* RMRegDossTags 			= NULL;
		   char* valueOfTheProp 			= NULL;
		   va_copy(copyArgs, args);
		   propTag = va_arg(copyArgs, tag_t);
		   num = (int*) va_arg(copyArgs, int*);
		   values = (tag_t**)va_arg(copyArgs, tag_t**  );
		   va_end(copyArgs);
		   vector<string> delimitedValues;
		   vector<tag_t> validObjTags;

			TC_write_syslog("Entered into function Properties_ask_is_required_value\n");
			METHOD_PROP_MESSAGE_OBJECT(m, inputTag)



			ITK(WSOM_ask_object_type2(inputTag,&TypeOfObject));

		   ITK(PREF_ask_char_values(PREF_TO_GET_VALUES, &numCount, &pcTraversalAttrName))
			 for(int ij=0;ij<numCount;ij++)
			 {
			getDelimitedValuesForPrefValue(pcTraversalAttrName[ij],delimitedValues,':');

			if(delimitedValues.size() > 0)
			{
			 if(tc_strcmp(delimitedValues[0].c_str(),TypeOfObject)==0)
			  {
						if(delimitedValues[2].c_str()!=NULL)
						ITK(GRM_find_relation_type(delimitedValues[2].c_str(),&RelationTag))
						if(RelationTag!=NULLTAG)
						{
						if(tc_strcmp(delimitedValues[3].c_str(),PRIMARYOBJECT)==0)
								{
								ITK(GRM_list_primary_objects_only(inputTag,RelationTag,&count,&RMRegDossTags))
										if(count >0)
										{
											for(int jj=0;jj<count;jj++)
											{
												ITK(WSOM_ask_object_type2(RMRegDossTags[jj],&RMRegDossType))
													if(tc_strcmp(RMRegDossType,delimitedValues[4].c_str())==0)
													{
													  ITK(AOM_ask_value_string(RMRegDossTags[jj],delimitedValues[5].c_str(),&valueOfTheProp))
															  if(tc_strcmp(valueOfTheProp,delimitedValues[6].c_str())==0)
															  {
																  validObjTags.push_back(RMRegDossTags[jj]);
															  }
													}
											}

										}
								}
									else if(tc_strcmp(delimitedValues[3].c_str(),SECONDARYOBJECT)==0)
								{
									ITK(GRM_list_secondary_objects_only(inputTag,RelationTag,&count,&RMRegDossTags))
										if(count >0)
										{
											for(int jj=0;jj<count;jj++)
											{
												ITK(WSOM_ask_object_type2(RMRegDossTags[jj],&RMRegDossType))
													if(tc_strcmp(RMRegDossType,delimitedValues[4].c_str())==0)
													{
													  ITK(AOM_ask_value_string(RMRegDossTags[jj],delimitedValues[5].c_str(),&valueOfTheProp))
															  if(tc_strcmp(valueOfTheProp,delimitedValues[6].c_str())==0)

															  {
																  validObjTags.push_back(RMRegDossTags[jj]);
															  }
													}
											}

										}
								}
							}


						}
			 else
				 delimitedValues.clear();

						}
}
						if(validObjTags.size() > 0)
						{
							  *values = (tag_t*)MEM_realloc(*values, sizeof(tag_t) * (validObjTags.size()+1));
							  for(int ii=0;ii<validObjTags.size();ii++)
							  {
					            (*values)[ii] = validObjTags[ii];
							  }
							  *num =validObjTags.size();

						}

						TC_write_syslog("Exit out of function Properties_ask_is_required_value\n");

	  if (pcTraversalAttrName != NULL)
	  {
		MEM_free(pcTraversalAttrName);
		pcTraversalAttrName = NULL;
		}
	    MEM_free(TypeOfObject);
	    MEM_free(RMRegDossType);
	    MEM_free(valueOfTheProp);
		return retcode;


	}
