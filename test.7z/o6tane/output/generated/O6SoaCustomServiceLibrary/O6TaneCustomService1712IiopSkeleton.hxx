/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

//#ifndef TEAMCENTER_SERVICES_CustomServiceLibrary__2017_12_O6TaneCustomService_HXX 
//#define TEAMCENTER_SERVICES_CustomServiceLibrary__2017_12_O6TaneCustomService_HXX

#include <unidefs.h>
#if defined(SUN)
#    include <unistd.h>
#endif

#include <string>
#include <iostream>
#include <sstream>



#include <teamcenter/soa/server/ServiceData.hxx>
#include <teamcenter/soa/server/ServiceException.hxx>
#include <teamcenter/soa/server/PartialErrors.hxx>
#include <teamcenter/soa/server/Preferences.hxx>
#include <teamcenter/soa/server/ServicePolicy.hxx> 
#include <teamcenter/soa/internal/server/IiopSkeleton.hxx>
#include <teamcenter/soa/internal/server/ServiceManager.hxx>
#include <teamcenter/soa/internal/gateway/TcServiceManager.hxx>
#include <teamcenter/soa/common/xml/SaxToNodeParser.hxx>
#include <teamcenter/soa/common/xml/XmlUtils.hxx>
#include <teamcenter/soa/common/exceptions/ExceptionMapper.hxx>
#include <teamcenter/soa/common/exceptions/DomException.hxx>
#include <teamcenter/schemas/soa/_2006_03/exceptions/ServiceException.hxx>

#include <o6tanecustomservice1712impl.hxx>


#include <CustomServiceLibrary_exports.h>  
namespace O6
{
    namespace Services
    {
    
        namespace CustomServiceLibrary
        {
             namespace _2017_12
             {


class SOACUSTOMSERVICELIBRARY_API O6TaneCustomServiceIiopSkeleton : public Teamcenter::Soa::Internal::Server::IiopSkeleton
{

public:

     O6TaneCustomServiceIiopSkeleton();
    ~O6TaneCustomServiceIiopSkeleton();
    
    virtual void initialize();
   


private:

    static O6::Soa::CustomServiceLibrary::_2017_12::O6TaneCustomServiceImpl* _service;
	static Teamcenter::Soa::Server::ServicePolicy*  	 _servicePolicy;


    static void calculateQSP( const std::string& xmlIn,  Teamcenter::Soa::Internal::Gateway::GatewayResponse& gatewayResponse );
    


};    // End Class



}}}}    // End Namespace
#include <CustomServiceLibrary_undef.h>
//#endif   

