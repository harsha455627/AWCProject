//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension O6_custom_register_properties
 *
 */
 
#ifndef O6_CUSTOM_REGISTER_PROPERTIES_HXX
#define O6_CUSTOM_REGISTER_PROPERTIES_HXX
#include <tccore/method.h>
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern O6TANECUSTOMLIBRARY_API int O6_custom_register_properties(METHOD_message_t* msg, va_list args);
#define ITK( argument )						                                \
{									                                        \
	if (retcode == ITK_ok)													\
	{																		\
		retcode = argument;                                                 \
		if ( retcode != ITK_ok )											\
		{																	\
			char* s;                                                        \
			TC_write_syslog( " "#argument "\n" );                           \
			TC_write_syslog( "  returns [%d]\n", retcode );                 \
			EMH_ask_error_text (retcode, &s);                               \
			EMH_store_error(EMH_severity_error,retcode);                    \
			TC_write_syslog( "  Teamcenter Error: [%s]\n", s);              \
			TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
			if (s != 0) MEM_free (s);                                       \
		}                                                                   \
	}																		\
}
#ifdef __cplusplus
                   }
#endif
                
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
                
#endif  // O6_CUSTOM_REGISTER_PROPERTIES_HXX
