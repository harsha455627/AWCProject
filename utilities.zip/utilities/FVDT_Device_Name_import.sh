#!/usr/bin/ksh

# ---------------------------------------------------------------------------------------------
#NOTE - This utility should be used to create standard device names initially and ongoing basis

# Inputs:
# 1. InputFile - Full path contains the standard names
# 2. emailID - The person who would be notified with email attachment


# Set the TC environment

export TC_ROOT=/apps/tc_vsem/11.2/sun
export TC_DATA=/data/fna1lv1/cfg1

. $TC_DATA/tc_profilevars

export LOG_FILE_DIR=/data/fna1lv1/cfg1/../log

export FVDT_UTIL_IMP_LOG_DIR=$LOG_FILE_DIR/DEVICE_IMPORT_`date +%b_%d_%Y_%H_%M`

mkdir $FVDT_UTIL_IMP_LOG_DIR 2> /dev/null

if [ ! -f "$1" ]
then
      echo "ERROR: Input file $1 does not exist.\n" | \
      mailx -s "FVDT_Device_Name_Import.sh failure" $2
      exit 1
fi


$TC_ROOT/fve_kit/server/utilities/FVDT_import_std_data -class=FVDTStdCompName -file=$1

if [ ! -z $2 ]
then
   cd $FVDT_UTIL_IMP_LOG_DIR

   command=""
   for i in `ls *.txt *.log`
   do
     command=$command"uuencode $i $i;"
   done

   (echo "Standard Device Name Import logs" ; eval $command)  | mailx -s 'Standard Device Name Import Reports' $2
fi

