/******************************************************************************
 * Filename        :   fve_delete_report_definition.h
 * Description     :   Defines the macro used in fve_delete_report_definition.c
 * Module          :   FVE_DELETE_REPORT_DEFINITION.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * December, 2011    Ram Sisodia      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_DELETE_REPORT_DEFINITION_H
#define FVE_DELETE_REPORT_DEFINITION_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <pie/pie.h>
#include<qry/crf.h>
#include<tccore/grm.h>
#include<ae/dataset.h>

/*************************************************
* Macros Definition
**************************************************/

#define SIGNAL_UNIT_TCTYPE		"FVE_SignalUnit"
#define OBJ_NAME_ATTR			"object_name"
#define UNIT_DESC				"FVE_UnitDesc"
#define UNIT_ABBR				"FVE_Abbreviation"
#define SPACE_BAR				" "

#define DATE_FORMAT_STR			"%m%d%Y_%H%M%S"


/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\

#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}
 

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

#define DATE_FORMAT      "%d-%b-%Y"

#define ITK(x) \
{\
   if ( ifail == ITK_ok )\
   {\
      if((ifail = (x)) != ITK_ok)\
      {\
         dump_itk_errors ( ifail, #x, __LINE__, __FILE__ );\
      }\
   }\
}\

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, 
					 const char * fileName );

void get_time_stamp(char* format, char** timestamp);
void FVE_get_value_and_store(char * init_value, int cnt, char *** str_array, logical * is_value_null);
#endif /*FVE_DELETE_REPORT_DEFINITION*/
