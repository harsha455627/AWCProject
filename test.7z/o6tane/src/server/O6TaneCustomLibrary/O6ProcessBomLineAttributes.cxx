//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6ProcessBomLineAttributes
 *
 */
#include <string>
#include <iostream>
#include <vector>
#include <cstdlib>

#include <O6TaneCustomLibrary/O6ProcessBomLineAttributes.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/method.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <tccore/workspaceobject.h>
#include<algorithm>


#define STRING_ATTR_VALUE_SET_ERROR ( SEEDS_CUSTOM_ERROR_BASE + 2 )

/**
 * Bom line custom attributes.
 */
#define bomAttr_bl_occ_o6_percent_theoric "bl_occ_o6_percent_theoric"
#define bomAttr_bl_occ_o6_vol_percent_theoric "bl_occ_o6_vol_percent_theoric"
#define bomAttr_bl_occ_o6_qte_pesee "bl_occ_o6_qte_pesee"
#define bomAttr_bl_occ_o6_percent_reel "bl_occ_o6_percent_reel"
//#define bomAttr_bl_occ_o6_valeur "bl_occ_o6_valeur"
//#define bom_attr_bl_occ_o6_valeur_percent "bl_occ_o6_valeur_percent"

#define O6_IMPURETE "o6_impurete"


#define TOP_LINE_ATTR "top_line"
#define MANUF_QTY "o6_fabrique_qtt"
#define BOM_WINDOW_TYPE "BOMWindow"
#define FLE_REV_TYPE "O6_FleRootRevision"
#define OBJ_TYPE_ATTR "object_type"
#define FLE_BATCH_REV "O6_FleBatchRevision"
#define FLE_REV "O6_FleRevision"
#define FP_REG_DOSS_REV "O6_FPRegDossRevision"
#define ING_LIST_REV "O6_IngListRevision"
#define TOT_QTY_PER "o6_total_percent"
#define TOT_COST "o6_total_cost"
#define MEAN_DENSITY "o6_densite"
#define OBJECT_TYPE "object_type"
#define MP_GEN_REV "O6_GenRMRevision"
#define SUPL_REV "O6_SupRMRevision"
//#define SAP_PRICE_ATTR "o6_prix_sap"
#define GEN_TO_SUP "O6_GenToSupplRM"
#define FLE_BATCH_REV_TYPE "O6_FleBatchRevision"

typedef struct bomline{
	double pertherqty =0;
	double qty = 0;
   // double value = 0;
    double realQty =0;
    double dCalcPercent = 0;
} bline;

/**
 * Bomline attributes declaration.
 */
static int item_revtag_attribute;
static int bl_occ_o6_percent_theoric_attribute;
static int bl_occ_o6_vol_percent_theoric_attribute;
static int bl_occ_o6_qte_pesee_attribute;
static int quantiy_attribute;
static int name_attribute;
static int uom_attribute;
static int bl_occ_o6_percent_reel_attribute;
static int item_uom_attribute;
static int bl_occ_attribute;
static int iBOMLineSeqNo;
//static int bl_occ_o6_valeur_attribute;
//static int bl_occ_o6_valeur_percent_attribute;


/**
 * Function    :  initialise_attribute
 * Description :  Initialize BOM attributes.
 * Input       :
 */
static int initialise_attribute (char *name,  int *attribute)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (name, attribute));

    return retcode;
  }

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 * Input       :
 */
static int initialise (void)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (bomAttr_lineItemRevTag, &item_revtag_attribute));
    ITK ( BOM_line_look_up_attribute ( bomAttr_occSeqNo, &iBOMLineSeqNo ) );

    ITK(initialise_attribute (bomAttr_lineName, &name_attribute));
    ITK(initialise_attribute (bomAttr_occQty, &quantiy_attribute));
    ITK(initialise_attribute (bomAttr_occUoM, &uom_attribute));

    ITK(initialise_attribute(bomAttr_itemUom, &item_uom_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_percent_theoric, &bl_occ_o6_percent_theoric_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_vol_percent_theoric, &bl_occ_o6_vol_percent_theoric_attribute))
    ITK(initialise_attribute (bomAttr_bl_occ_o6_qte_pesee, &bl_occ_o6_qte_pesee_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_percent_reel, &bl_occ_o6_percent_reel_attribute));
    ITK(initialise_attribute ( bomAttr_realOccurrence, &bl_occ_attribute));
    //ITK(initialise_attribute (bomAttr_bl_occ_o6_valeur, &bl_occ_o6_valeur_attribute));
    //ITK(initialise_attribute (bom_attr_bl_occ_o6_valeur_percent, &bl_occ_o6_valeur_percent_attribute));

    return retcode;
  }

/**
 * Function		: getConvertedQuanity
 * Description	: Get final quantity based on unit of measure selected
 * Input		:
 * 		bomline 		 - tag of Bomline used for evaluation
 * 		unitTopLinestr   - char pointer denoting Topline UOM value
 * 		blQty            - double sap price value
 * Output		:
 * 		finalQty         - double final cost address based on UOM
 */
int getConvertedQuanity(tag_t bomline, char* unitTopLinestr, double blQty, double* finalQty){
	int retcode = ITK_ok;

	tag_t uomtag = NULLTAG;
	ITK(BOM_line_ask_attribute_tag(bomline, uom_attribute, &uomtag));
	if(retcode == ITK_ok && uomtag != NULLTAG){

		char* unitBomLineStr = NULL;
		ITK(AOM_ask_value_string(uomtag,UOM_NAME, &unitBomLineStr));
		if (retcode == ITK_ok && unitBomLineStr != NULL){
			if(tc_strlen(unitBomLineStr) > 0) {
				if(tc_strcmp(unitTopLinestr,unitBomLineStr)==0){
					*finalQty = blQty;
				}
				else if(tc_strcmp(unitTopLinestr, KG) ==0 && tc_strcmp(unitBomLineStr, GM) ==0){
                      *finalQty =  blQty * 1000;
				}
				else if(tc_strcmp(unitTopLinestr, GM) ==0 && tc_strcmp(unitBomLineStr, KG) ==0){
				                      *finalQty =  blQty / 1000;
				}
			}

			MEM_free(unitBomLineStr);
			unitBomLineStr = NULL;
		}
	}

	return retcode;
}

/**
 * Function		: CalculateTotalDensity
 * Description	: Traverses the BOM and calculates the total density of the formula or formula Batch
 * Input		:
 * 		children 		 - BOMLines
 * 		iChildCount      - BOMLine Count
 * 		bIsMassPercent   - Boolean value
 * 		dTotalPercentage - total percent value
 *
 *  Output      :
 *  	dTotalDensity   - <OF> - total density
 */

int CalculateTotalDensity ( tag_t* children, int iChildCount, bool bIsMassPercent, double dTotalPercentage ,double &dTotalDensity )
{
	int retcode = ITK_ok;

	if ( bIsMassPercent == true )
	{
		char* pcPercent = NULL;

		double dTotalVolume = 0.0;

		for ( int iInx = 0; iInx < iChildCount; iInx++ )
		{
			tag_t tItemRevTag = NULLTAG;

			double perqty     = 0.0;
			double dDensity   = 0.0;

			ITK ( BOM_line_ask_attribute_string ( children[iInx], bl_occ_o6_percent_theoric_attribute, &pcPercent ) );

			perqty = atof ( pcPercent );

			if ( pcPercent != NULL )
			{
				MEM_free ( pcPercent );
				pcPercent = NULL;
			}

			ITK ( BOM_line_ask_attribute_tag ( children[iInx], item_revtag_attribute, &tItemRevTag ) );
			ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensity ) );

			dTotalVolume = dTotalVolume + ( perqty/dDensity );
		}
		dTotalDensity = dTotalPercentage / dTotalVolume;
	}
	else
	{
		char* pcPercent = NULL;

		double dTotalMass = 0.0;

		for ( int iInx = 0; iInx < iChildCount; iInx++ )
		{
			tag_t tItemRevTag = NULLTAG;

			double dDensity   = 0.0;

			ITK ( BOM_line_ask_attribute_string ( children[iInx], bl_occ_o6_vol_percent_theoric_attribute, &pcPercent ) );

			double perqty = atof ( pcPercent );

			ITK ( BOM_line_ask_attribute_tag ( children[iInx], item_revtag_attribute, &tItemRevTag ) );
			ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensity ) );

			dTotalMass = dTotalMass + ( perqty * dDensity );

			if ( pcPercent != NULL )
			{
				MEM_free ( pcPercent );
				pcPercent = NULL;
			}
		}
		dTotalDensity = dTotalMass / dTotalPercentage;
	}
	return retcode;
}

/**
 * Function		: CalculateTotalPercent
 * Description	: Traverses the BOM and calculates the total percent of the formula or formula Batch
 * Input		:
 * 		children 		 - BOMLines
 * 		iChildCount      - BOMLine Count
 * 		bIsMassPercent   - Boolean value
 *
 *  Output      :
 *  	dTotalPercentage - <OF> - total percentage
 */

int CalculateTotalPercent ( tag_t* children, int iChildCount, bool bIsMassPercent, double &dTotalPercentage )
{
	int retcode = ITK_ok;

	if ( bIsMassPercent == true )
	{
		for ( int iInx = 0; iInx < iChildCount; iInx++ )
		{
			char* pcPercent = NULL;

			ITK ( BOM_line_ask_attribute_string ( children[iInx], bl_occ_o6_percent_theoric_attribute, &pcPercent ) );

			double perqty = atof ( pcPercent );

			dTotalPercentage = dTotalPercentage + perqty;

			if ( pcPercent != NULL )
			{
				MEM_free ( pcPercent );
				pcPercent = NULL;
			}
		}
	}
	else
	{
		for ( int iInx = 0; iInx < iChildCount; iInx++ )
		{
			char* pcPercent = NULL;

			ITK ( BOM_line_ask_attribute_string ( children[iInx], bl_occ_o6_vol_percent_theoric_attribute, &pcPercent ) );

			double perqty = atof ( pcPercent );

			dTotalPercentage = dTotalPercentage + perqty;

			if ( pcPercent != NULL )
			{
				MEM_free ( pcPercent );
				pcPercent = NULL;
			}
		}
	}

	return retcode;
}

/**
 * Function		: traverse_BOM
 * Description	: Traverse single level bom and set attributes on bom line.
 * Input		:
 * 		top_line 		 - Top BOMLine
 * 		root_itemrev_tag - Item revision of top bomline.
 * Output		:
 * 		none
 */
int traverse_BOM(tag_t top_line, tag_t root_itemrev_tag)
{
	int retcode = ITK_ok;
	int chld_cnt = 0;

	std::vector<bline> bl_vector;
	double totalQuantityPercent = 0;
	double totalQuantityReal = 0;
	double dTotalPercentage = 0.0;
	double dTotalDensity = 0.0;

	logical quantityCalcRequired = false;

	tag_t* children = NULL;
	tag_t tOccurenceTag = NULLTAG;

	char* itemrev_type = NULL;
	char* objtypestr = NULL;
	char* tempValStr = NULL;
	char* unitTopLinestr = NULL;

	double manuf_qty_dbl = 0;

	logical lIsImpurete = false;

	vector<pair<double,tag_t>> vPercentageChild,vPercentageChildImpure;
	ITK(AOM_ask_value_string(root_itemrev_tag, OBJ_TYPE_ATTR, &objtypestr));
	if (retcode == ITK_ok && objtypestr != NULL) {

		itemrev_type = (char*) MEM_alloc(sizeof(char) * (tc_strlen(objtypestr) + 1));
		tc_strcpy(itemrev_type, objtypestr);

		MEM_free(objtypestr);
		objtypestr = NULL;

		if ( tc_strcmp ( itemrev_type, FP_REG_DOSS_REV ) == 0 || tc_strcmp ( itemrev_type, ING_LIST_REV ) == 0 )
		{
			if ( tc_strcmp ( itemrev_type, FP_REG_DOSS_REV ) == 0 )
			{

				int iIngListChild       = 0;

				tag_t* tIngListChildren = 0;
				ITK ( BOM_line_ask_all_child_lines ( top_line, &chld_cnt, &children ) );

				if ( retcode == ITK_ok && chld_cnt > 0 )
				{
					ITK ( BOM_line_ask_all_child_lines ( children[0], &iIngListChild, &tIngListChildren ) );
					if ( retcode == ITK_ok && iIngListChild > 0 )
					{
						for ( int indx = 0; indx < iIngListChild && retcode == ITK_ok; indx++ )
						{
							ITK ( BOM_line_ask_attribute_string ( tIngListChildren[indx], bl_occ_o6_percent_theoric_attribute, &tempValStr ) );
							ITK(BOM_line_ask_attribute_tag(tIngListChildren[indx],bl_occ_attribute,&tOccurenceTag));
							ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &lIsImpurete ) );

									if(lIsImpurete == false)
										{
										vPercentageChild.push_back ( make_pair ( atof ( tempValStr ), tIngListChildren[indx] ) );
										}
										else
										vPercentageChildImpure.push_back ( make_pair ( atof ( tempValStr ), tIngListChildren[indx] ) );


							if ( retcode == ITK_ok && tempValStr != NULL && lIsImpurete == false)
							{
								if ( tc_strlen ( tempValStr ) > 0 )
								{
									double perqty = atof ( tempValStr );

									if ( tempValStr != NULL )
									{
										MEM_free ( tempValStr );
										tempValStr = NULL;
									}
									if ( perqty > 0 )
									{
										totalQuantityPercent = totalQuantityPercent	+ perqty;
									}
								}
							}
						}
						sort ( vPercentageChild.begin(), vPercentageChild.end() );
						sort ( vPercentageChildImpure.begin(), vPercentageChildImpure.end() );

						int iSeqNumber = 10;
								//for ( int iInx = 0; iInx < vPercentageChild.size(); iInx++ )
							for ( int iInx = vPercentageChild.size()-1; iInx >= 0; iInx-- )
							{
							tag_t tBOMLine = vPercentageChild[iInx].second;

							string sSeqNumber = to_string ( iSeqNumber );

							ITK ( BOM_line_set_attribute_string ( tBOMLine, iBOMLineSeqNo, sSeqNumber.c_str () ) );

								iSeqNumber = iSeqNumber + 10;
							}
							for ( int iInx = vPercentageChildImpure.size()-1; iInx >= 0; iInx-- )
							{
							tag_t tBOMLine = vPercentageChildImpure[iInx].second;

							string sSeqNumber = to_string ( iSeqNumber );

							ITK ( BOM_line_set_attribute_string ( tBOMLine, iBOMLineSeqNo, sSeqNumber.c_str () ) );

							iSeqNumber = iSeqNumber + 10;
							}
							vPercentageChild.clear();
							vPercentageChildImpure.clear();
						if ( totalQuantityPercent > 0 )
						{
							tag_t tIngListRevTag = NULLTAG;

							ITK ( BOM_line_ask_attribute_tag ( children[0], item_revtag_attribute, &tIngListRevTag ) );
							if ( retcode == ITK_ok && tIngListRevTag != NULLTAG )
							{
								ITK ( AOM_refresh ( tIngListRevTag,TRUE ) );
								ITK ( AOM_set_value_double ( tIngListRevTag, TOT_QTY_PER, totalQuantityPercent ) );
								ITK ( AOM_save_without_extensions ( tIngListRevTag ) );
								ITK ( AOM_unlock ( tIngListRevTag ) );
							}
						}
					}
				}
				if ( tIngListChildren != NULL )
				{
					MEM_free ( tIngListChildren );
					tIngListChildren = NULL;
				}
			}
			else
			{
				ITK ( BOM_line_ask_all_child_lines ( top_line, &chld_cnt, &children ) );
				if ( retcode == ITK_ok && chld_cnt > 0 )
				{
					for ( int indx = 0; indx < chld_cnt && retcode == ITK_ok; indx++ )
					{
						ITK ( BOM_line_ask_attribute_string ( children[indx], bl_occ_o6_percent_theoric_attribute, &tempValStr ) );
						ITK(BOM_line_ask_attribute_tag(children[indx],bl_occ_attribute,&tOccurenceTag));
						ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &lIsImpurete ) );
						if(lIsImpurete == false)
							{
							vPercentageChild.push_back ( make_pair ( atof ( tempValStr ), children[indx] ) );
							}
							else
							vPercentageChildImpure.push_back ( make_pair ( atof ( tempValStr ), children[indx] ) );
						if ( retcode == ITK_ok && tempValStr != NULL && lIsImpurete == false)
						{
							if ( tc_strlen ( tempValStr ) > 0 )
							{
								double perqty = atof ( tempValStr );

								if ( tempValStr != NULL )
								{
									MEM_free ( tempValStr );
									tempValStr = NULL;
								}
								if ( perqty > 0 )
								{
									totalQuantityPercent = totalQuantityPercent	+ perqty;
								}
							}
						}
					}

					sort ( vPercentageChild.begin(), vPercentageChild.end() );
					sort ( vPercentageChildImpure.begin(), vPercentageChildImpure.end() );

					int iSeqNumber = 10;
							//for ( int iInx = 0; iInx < vPercentageChild.size(); iInx++ )
						for ( int iInx = vPercentageChild.size()-1; iInx >= 0; iInx-- )
						{
						tag_t tBOMLine = vPercentageChild[iInx].second;

						string sSeqNumber = to_string ( iSeqNumber );

						ITK ( BOM_line_set_attribute_string ( tBOMLine, iBOMLineSeqNo, sSeqNumber.c_str () ) );

							iSeqNumber = iSeqNumber + 10;
						}
						for ( int iInx = vPercentageChildImpure.size()-1; iInx >= 0; iInx-- )
						{
						tag_t tBOMLine = vPercentageChildImpure[iInx].second;

						string sSeqNumber = to_string ( iSeqNumber );

						ITK ( BOM_line_set_attribute_string ( tBOMLine, iBOMLineSeqNo, sSeqNumber.c_str () ) );

						iSeqNumber = iSeqNumber + 10;
						}
						vPercentageChild.clear();
						vPercentageChildImpure.clear();


					if ( totalQuantityPercent > 0 )
					{
						ITK ( AOM_refresh ( root_itemrev_tag,TRUE ) );
						ITK ( AOM_set_value_double ( root_itemrev_tag, TOT_QTY_PER, totalQuantityPercent ) );
						ITK ( AOM_save_without_extensions ( root_itemrev_tag ) );
						ITK ( AOM_unlock ( root_itemrev_tag ) );
					}
				}
			}
		}
		else
		{
			char* unitTopLinestrL = NULL;

			ITK ( BOM_line_ask_attribute_string ( top_line, item_uom_attribute, &unitTopLinestrL ) );

			unitTopLinestr = ( char* ) MEM_alloc( sizeof ( char ) * ( tc_strlen ( unitTopLinestrL ) + 1 ) );
			tc_strcpy ( unitTopLinestr, unitTopLinestrL );
			MEM_free ( unitTopLinestrL );
			unitTopLinestrL = NULL;

			if ( tc_strcmp ( itemrev_type, FLE_BATCH_REV ) == 0 )
			{
				ITK ( AOM_ask_value_double ( root_itemrev_tag, MANUF_QTY, &manuf_qty_dbl ) );
				if (retcode == ITK_ok && manuf_qty_dbl != NULL
						&& manuf_qty_dbl > 0)
				{
					quantityCalcRequired = true;
				}
			}

			ITK ( BOM_line_ask_child_lines ( top_line, &chld_cnt, &children ) );

			/*If topline's UOM is Litre, logic to calculate Mass percentage of components*/
			if ( tc_strcmp ( unitTopLinestr, LITER ) == 0 )
			{
				ITK ( CalculateTotalPercent ( children, chld_cnt, false, dTotalPercentage ) );

				if ( retcode == ITK_ok )
				{
					ITK ( CalculateTotalDensity ( children, chld_cnt, false, dTotalPercentage, dTotalDensity ) );
				}
			}
			/*If topline's UOM is Litre, logic to calculate volume percentage of components*/
			else if ( tc_strcmp ( unitTopLinestr, KG ) == 0 || tc_strcmp ( unitTopLinestr, GM ) == 0 )
			{
				ITK ( CalculateTotalPercent ( children, chld_cnt,true, dTotalPercentage ) );

				if ( retcode == ITK_ok )
				{
					ITK ( CalculateTotalDensity ( children, chld_cnt, true, dTotalPercentage, dTotalDensity ) );
				}
			}

			if ( retcode == ITK_ok && chld_cnt > 0 )
			{
				for ( int indx = 0; indx < chld_cnt && retcode == ITK_ok; indx++ )
				{
					tag_t fleBatchRevtag = NULLTAG;
					ITK ( BOM_line_ask_attribute_tag ( children[indx], item_revtag_attribute, &fleBatchRevtag ) );
					if ( retcode == ITK_ok && fleBatchRevtag != NULLTAG )
					{
						tag_t fleBatchRevTypeTag = NULLTAG;
						ITK ( TCTYPE_ask_object_type ( fleBatchRevtag, &fleBatchRevTypeTag ) );
						if ( retcode== ITK_ok && fleBatchRevTypeTag != NULLTAG )
						{
							logical answerFlg = FALSE;
							ITK ( TCTYPE_is_type_of_as_str ( fleBatchRevTypeTag,FLE_BATCH_REV_TYPE,&answerFlg ) );
							if ( retcode == ITK_ok && answerFlg == TRUE )
							{
								/* Replace FleBatch with its children and cut the fle batch */
								ITK ( BOM_line_cut ( children[indx] ) );
							}
							else
							{
								bline bl;

								/*Calculation for Mass or Volume percentage based on topline's UOM values and storing in structure*/
								if ( tc_strcmp ( unitTopLinestr, LITER ) == 0 )
								{
									tag_t tItemRevTag 	= NULLTAG;

									double dDensity 	= 0.0;
									double dMassPercent = 0.0;

									ITK ( BOM_line_ask_attribute_string ( children[indx], bl_occ_o6_vol_percent_theoric_attribute, &tempValStr ) );

									ITK ( BOM_line_ask_attribute_tag ( children[indx], item_revtag_attribute, &tItemRevTag ) );
									ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensity ) );

									dMassPercent = atof ( tempValStr ) * ( dDensity / dTotalDensity );
									bl.dCalcPercent = dMassPercent;
								}
								else if ( tc_strcmp ( unitTopLinestr, KG ) == 0 || tc_strcmp ( unitTopLinestr, GM ) == 0 )
								{
									double dVolumePercent = 0.0;
									double dDensity       = 0.0;

									tag_t tItemRevTag 	  = NULLTAG;

									ITK ( BOM_line_ask_attribute_string ( children[indx], bl_occ_o6_percent_theoric_attribute, &tempValStr ) );

									ITK ( BOM_line_ask_attribute_tag ( children[indx], item_revtag_attribute, &tItemRevTag ) );
									ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensity ) );

									dVolumePercent = atof ( tempValStr ) * ( dTotalDensity / dDensity );
									bl.dCalcPercent = dVolumePercent;
								}

								if ( retcode == ITK_ok && tempValStr != NULL )
								{
									if ( tc_strlen ( tempValStr ) > 0 )
									{
										double perqty = atof ( tempValStr );
										if ( perqty > 0 )
										{
											bl.pertherqty = perqty;

											totalQuantityPercent = totalQuantityPercent
													+ perqty;

											if ( quantityCalcRequired == true )
											{
												double totQty = ( perqty / 100 ) * manuf_qty_dbl;

												if ( tc_strcmp ( itemrev_type, FLE_BATCH_REV ) == 0 && unitTopLinestr != NULL )
												{
													double finalQty = 0;
													ITK ( getConvertedQuanity ( children[indx], unitTopLinestr, totQty, &finalQty ) );
													if ( retcode == ITK_ok && finalQty > 0 )
													{
														bl.qty = finalQty;
													}
												}
											}
										}
									}

									MEM_free ( tempValStr );
									tempValStr = NULL;
								}

								if ( retcode == ITK_ok && tc_strcmp ( itemrev_type, FLE_REV ) != 0 )
								{
									ITK ( BOM_line_ask_attribute_string ( children[indx], bl_occ_o6_qte_pesee_attribute, &tempValStr ) );
									if ( retcode == ITK_ok && tempValStr != NULL )
									{
										if ( tc_strlen ( tempValStr ) > 0 )
										{

											double realQty = atof ( tempValStr );
											if ( realQty > 0 )
											{
												bl.realQty = realQty;
												totalQuantityReal = totalQuantityReal + realQty;
											}
										}
										MEM_free ( tempValStr );
										tempValStr = NULL;
									}
								}

								bl_vector.push_back(bl);
							}
						}
					}
				}

				/**
				 * Second loop to set the bom line attributes based on the values
				 * calculated in first iteration.
				 */
				for (int indj = 0;
						indj < chld_cnt && bl_vector.size() == chld_cnt
								&& retcode == ITK_ok; indj++) {

					bline b1;
					b1 = bl_vector[indj];

					if (quantityCalcRequired == true && b1.qty > 0)
					{
						std::string tmpstr = std::to_string ( b1.qty );
						ITK ( BOM_line_set_attribute_string ( children[indj], quantiy_attribute, tmpstr.c_str() ) );
						if ( retcode == 46010 )
						{
							retcode = ITK_ok;
							char* bomlinename = NULL;
							ITK ( BOM_line_ask_attribute_string ( children[indj], name_attribute, &bomlinename ) );

							char* errorStr = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( bomlinename ) + 1 ) );
							tc_strcpy ( errorStr, bomlinename );

							TC_write_syslog(
									"SEEDs Error: Error while setting quantity on bom line [ %s ]. Please check if UOM is set correclty?. Note: UOM value 'each' is not acceptable for fractional quantity",
									errorStr);
							EMH_store_error_s1(EMH_severity_error, STRING_ATTR_VALUE_SET_ERROR, errorStr);
							MEM_free(errorStr);
							errorStr = NULL;
							MEM_free(bomlinename);
							bomlinename = NULL;
							retcode = STRING_ATTR_VALUE_SET_ERROR;
						}
					}

					if ( retcode == ITK_ok && totalQuantityReal > 0 )
					{
						double realQty = b1.realQty;
						if ( realQty > 0 )
						{
							double perRealQty = (realQty / totalQuantityReal) * 100;

							if ( perRealQty > 0 )
							{
								std::string tmpstr = std::to_string ( perRealQty );

								ITK ( BOM_line_set_attribute_string ( children[indj], bl_occ_o6_percent_reel_attribute, tmpstr.c_str() ) );
							}
						}
					}
					/*Setting Mass or Volume percentage values based on values stored in structure*/
					if ( tc_strcmp ( unitTopLinestr, LITER ) == 0 )
					{
						double dCalculatedMassValue = b1.dCalcPercent;

						if ( dCalculatedMassValue > 0 )
						{
							std::string tmpstr = std::to_string ( dCalculatedMassValue );
							ITK ( BOM_line_set_attribute_string ( children[indj], bl_occ_o6_percent_theoric_attribute, tmpstr.c_str() ) );
						}
					}
					else if ( tc_strcmp ( unitTopLinestr, KG ) == 0 || tc_strcmp ( unitTopLinestr, GM ) == 0 )
					{
						double dCalculatedVolValue = b1.dCalcPercent;

						if ( dCalculatedVolValue > 0 )
						{
							std::string tmpstr = std::to_string ( dCalculatedVolValue );
							ITK ( BOM_line_set_attribute_string ( children[indj], bl_occ_o6_vol_percent_theoric_attribute, tmpstr.c_str() ) );
						}
					}
				}

				if ( retcode == ITK_ok && ( totalQuantityPercent > 0 || dTotalDensity > 0))
				{
					ITK ( AOM_refresh ( root_itemrev_tag, TRUE ) );

					if ( totalQuantityPercent > 0 )
					{
						ITK ( AOM_set_value_double ( root_itemrev_tag,TOT_QTY_PER,totalQuantityPercent ) );
					}
					if ( dTotalDensity > 0 )
					{
						ITK ( AOM_set_value_double ( root_itemrev_tag, MEAN_DENSITY, dTotalDensity ) );
					}
					ITK ( AOM_save_without_extensions (root_itemrev_tag ) );
					ITK ( AOM_unlock ( root_itemrev_tag ) );
				}
				bl_vector.clear();
			}

			if(unitTopLinestr != NULL){
				MEM_free(unitTopLinestr);
				unitTopLinestr = NULL;
			}
		}
	}
	if ( itemrev_type != NULL )
	{
		MEM_free(itemrev_type);
		itemrev_type = NULL;
	}
	if ( children != NULL )
	{
		MEM_free(children);
		children = NULL;
	}

	return retcode;
}


/**
 * Function		: O6ProcessBomLineAttributes
 * Description	: Extension method calls at BOM Window save.
 * Input		:
 * 		msg 	- not used
 * 		args 	- Bom window
 * Output		:
 * 		none
 */
int O6ProcessBomLineAttributes( METHOD_message_t * /*msg*/, va_list args )
{
	int retcode = ITK_ok;

	va_list largs;
	va_copy( largs, args);
	tag_t windowTag = va_arg(largs, tag_t);
	va_end( largs );

	tag_t ObjTypeTag = NULLTAG;
	TC_write_syslog("Entere into function O6ProcessBomLineAttributes...........\n");
	ITK(TCTYPE_ask_object_type(windowTag, &ObjTypeTag));
	if (retcode== ITK_ok && ObjTypeTag != NULLTAG) {

		char* objtypename = NULL;
		ITK(TCTYPE_ask_name2(ObjTypeTag, &objtypename));
		if(retcode == ITK_ok && objtypename != NULL && tc_strcmp(objtypename, BOM_WINDOW_TYPE)==0){

			tag_t rootLine = NULLTAG;
			ITK(AOM_ask_value_tag(windowTag,TOP_LINE_ATTR,&rootLine));
			if (retcode == ITK_ok && rootLine != NULLTAG) {
				tag_t itemrevtag = NULLTAG;

				/**
				 * Initialize bom attributes
				 */
				ITK(initialise());

				ITK(BOM_line_ask_attribute_tag (rootLine, item_revtag_attribute, &itemrevtag));
				if (retcode == ITK_ok && itemrevtag != NULLTAG ) {
					tag_t itemrevTypeTag = NULLTAG;
					ITK(TCTYPE_ask_object_type(itemrevtag, &itemrevTypeTag));
					if (retcode== ITK_ok && itemrevTypeTag != NULLTAG )
					{
						char* pcItemRevType = NULL;

						logical answerFlg   = FALSE;

						ITK ( AOM_ask_value_string ( itemrevtag, OBJ_TYPE_ATTR, &pcItemRevType ) );

						ITK(TCTYPE_is_type_of_as_str(itemrevTypeTag,FLE_REV_TYPE,&answerFlg));

						if ( retcode == ITK_ok && ( answerFlg == TRUE || tc_strcmp ( pcItemRevType, FP_REG_DOSS_REV ) == 0 || tc_strcmp ( pcItemRevType, ING_LIST_REV ) == 0 ) )
						{
							ITK ( traverse_BOM ( rootLine, itemrevtag ) );
						}

						if ( pcItemRevType != NULL )
						{
							MEM_free ( pcItemRevType );
							pcItemRevType = NULL;
						}
					}
				}
				ITK ( AOM_refresh ( itemrevtag, TRUE ) );
				ITK ( AOM_save_without_extensions (itemrevtag ) );
				ITK ( AOM_unlock ( itemrevtag ) );
			}

			MEM_free(objtypename);
			objtypename = NULL;
		}
	}

	TC_write_syslog("Exit out of function O6ProcessBomLineAttributes...........\n");
 return retcode;
}
