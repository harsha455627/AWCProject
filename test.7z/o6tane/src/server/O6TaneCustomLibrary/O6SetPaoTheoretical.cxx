//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6SetPaoTheoretical
 *
 */
#include <O6TaneCustomLibrary/O6SetPaoTheoretical.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <algorithm>

#define O6_CPD_PAO_CT1 "o6_cpd_pao_ct1"
#define O6_CPD_PAO_CT2 "o6_cpd_pao_ct2"
#define O6_CPD_PAO_CT4 "o6_cpd_pao_ct4"
#define O6_CPD_PAO_CT5 "o6_cpd_pao_ct5"
#define O6_PAO_THEORI "o6_pao_theori"
#define O6_CONTENANCE_PAO "o6_contenance_pao"
#define O6_CPD_DENSITE_THEO "o6_cpd_densite_theo"
#define O6_CPD_DOSEXFREQUENCE "o6_cpd_dosexfrequence"

/**
 * Function		: checkInvalidStringCount
 * Description	: Checks if the given string is valid integer value or not
 * Input		:
 * 		sValue 		     - String to be evaluated
 * Output		:
 * 		bIsStringInvalid - Count of characters found in the string
 */
bool checkInvalidStringCount ( string sValue )
{
	bool bIsStringInvalid = false;

	if ( sValue.find_first_not_of ( "123456789" ) != std::string::npos )
	{
		bIsStringInvalid = true;
	}
	return bIsStringInvalid;
}

/**
 * Function		: countOfChar
 * Description	: Finding count of characters in a string
 * Input		:
 * 		sDensite 		 - String in which character to be found
 * 		pcDecimalSymbol  - Character to be found in the string
 * Output		:
 * 		count            - Count of characters found in the string
 */
int countOfChar ( string sDensite, char pcDecimalSymbol )
{
	int i       = 0;
	int count   = 0;
	int contain = 0;

	while ( ( contain = sDensite.find ( pcDecimalSymbol, i ) ) != string::npos )
	{
	    count++;
	    i = contain + 1;
	}

	return count;
}

/**
 * Function		: getDoubleValue
 * Description	: To get double value based on the given string
 * Input		:
 * 		sValue 		     - String to be converted to double
 * Output		:
 * 		dValue           - Converted double value
 */
double getDoubleValue ( string sValue )
{
	double dValue = 0.0;

	if ( ! ( sValue.find_first_not_of ( "01234567890,." ) != std::string::npos ) )
	{
		int iCommaCount = 0;
		int iPointCount = 0;

		iCommaCount = countOfChar ( sValue, ',' );
		iPointCount = countOfChar ( sValue, '.' );

		if ( ! ( iCommaCount > 0 && iPointCount > 0 ) )
		{
			if ( iCommaCount == 0 ) /* condition to check for '.' in absence of ',' */
			{
				if ( iPointCount == 0 || iPointCount == 1 ) /*if it contains a decimal point or whole number*/
				{
					dValue = stod ( sValue );
				}
			}
			else if ( iCommaCount == 1 ) /* if it contains single ',' */
			{
				std::replace ( sValue.begin(), sValue.end(), ',', '.' );
				dValue = stod ( sValue );
			}
		}
	}
	return dValue;
}

/**
 * Function		: setPaoTheoricValue
 * Description	: To set double value on the form
 * Input		:
 * 		tFormTag    - Form on which the double value is to be set
 * 		dValue      - Double value to be set on the form
 * Output		:
 * 		none
 */
int setPaoTheoricValue ( tag_t tFormTag, double dValue )
{
	int retcode = ITK_ok;

	ITK ( AOM_refresh ( tFormTag, true ) );
	ITK ( AOM_set_value_double ( tFormTag, O6_PAO_THEORI, dValue ) );
	ITK ( AOM_save_without_extensions ( tFormTag ) );
	ITK ( AOM_refresh ( tFormTag, false ) );

	return retcode;
}

/**
 * Function		: getDCT3Value
 * Description	: To calculate and get property value of property DCT3 of form O6_PAOPF
 * Input		:
 * 		tFormTag    - Form for which Property value to be calculated
 * Output		:
 * 		dCT3        - Address of the double value calculated
 */
int getDCT3Value ( tag_t tFormTag, double &dCT3 )
{
	int retcode = ITK_ok;

	char* pcContenance = NULL;

	ITK ( AOM_ask_value_string ( tFormTag, O6_CONTENANCE_PAO, &pcContenance ) );

	if ( retcode == ITK_ok && pcContenance != NULL && strlen ( pcContenance ) > 0 )
	{
		double dContenance = 0.0;

		dContenance = getDoubleValue ( string ( pcContenance ) );

		if ( dContenance > 0 )
		{
			char* pcDensiteTheo = NULL;
			ITK ( AOM_ask_value_string ( tFormTag, O6_CPD_DENSITE_THEO, &pcDensiteTheo ) );

			if ( retcode == ITK_ok && pcDensiteTheo != NULL && strlen ( pcDensiteTheo ) > 0 )
			{
				double dDensiteTheo = 0.0;

				dDensiteTheo = getDoubleValue ( string ( pcDensiteTheo ) ); // Converting string to double value

				if ( dDensiteTheo > 0 )
				{
					double dDosexFrequence = 0.0;

					ITK ( AOM_ask_value_double ( tFormTag, O6_CPD_DOSEXFREQUENCE, &dDosexFrequence ) );

					if ( retcode == ITK_ok && dDosexFrequence > 0 )
					{
						double dProd = 0.0;

						dProd = ( dContenance * dDensiteTheo ) / dDosexFrequence;
						if ( dProd > 0 && dProd <= 31 )
						{
							dCT3 = 1;
						}
						if ( dProd > 31 && dProd <= 93 )
						{
							dCT3 = 2;
						}
						if ( dProd > 93 )
						{
							dCT3 = 3;
						}
					}
				}
			}
			if ( pcDensiteTheo != NULL )
			{
				MEM_free ( pcDensiteTheo );
				pcDensiteTheo = NULL;
			}
		}
	}
	if ( pcContenance != NULL )
	{
		pcContenance = NULL;
		MEM_free ( pcContenance );
	}

	return retcode;
}

/**
 * Function    :  O6SetPaoTheoretical
 * Description :  Used to set property value for property o6_pao_theori on O6_PAOPF form.
 * Input       :
 *      msg 		 - Input msg for extension
 *      args         - Input args for extension
 * Output	   :
 * 		none
 */

int O6SetPaoTheoretical( METHOD_message_t * /*msg*/, va_list args )
{
	int retcode = ITK_ok;

    va_list largs;
    va_copy( largs, args );
    tag_t tFormTag = va_arg ( largs, tag_t );
    va_end( largs );

    if ( tFormTag != NULLTAG )
    {
    	double dCT2 = 0.0;

    	ITK ( AOM_ask_value_double ( tFormTag, O6_CPD_PAO_CT2, &dCT2 ) );

    	if ( retcode == ITK_ok )
    	{
    		if ( dCT2 == 0 ) //First check if the double value out of CT1-CT5 is 0 or empty (which will again be 0 as per code)
    		{
    			ITK ( setPaoTheoricValue ( tFormTag, -1 ) );
    		}
    		else
    		{
    			bool bIsStringInvalid = false;

    			char* pcCT1 = NULL;

    			ITK ( AOM_ask_value_string ( tFormTag, O6_CPD_PAO_CT1, &pcCT1 ) );
    			bIsStringInvalid = checkInvalidStringCount ( string ( pcCT1 ) ); // This will check both invalid and 0 for strings

    			if ( retcode == ITK_ok && pcCT1 != NULL && strlen ( pcCT1 ) > 0 && bIsStringInvalid == false )
    			{
    				double dCT3 = 0.0;

					ITK ( getDCT3Value ( tFormTag, dCT3 ) );

					if ( retcode == ITK_ok && dCT3 > 0 )
					{
						char* pcCT4 = NULL;

						bIsStringInvalid = false;

						ITK ( AOM_ask_value_string ( tFormTag, O6_CPD_PAO_CT4, &pcCT4 ) );
						bIsStringInvalid = checkInvalidStringCount ( string ( pcCT4 ) );

						if ( retcode == ITK_ok && pcCT4 != NULL && strlen ( pcCT4 ) > 0 && bIsStringInvalid == false )
						{
							char* pcCT5 = NULL;

							bIsStringInvalid = false;

							ITK ( AOM_ask_value_string ( tFormTag, O6_CPD_PAO_CT5, &pcCT5 ) );
							bIsStringInvalid = checkInvalidStringCount ( string ( pcCT5 ) );

							if ( retcode == ITK_ok && pcCT5 != NULL && strlen ( pcCT5 ) > 0 && bIsStringInvalid == false ) //Calculation done only if CT1-CT5 values are valid and non zero. Else default value set to -1
							{
								double dRTValue = 0.0;

								dRTValue = stoi ( pcCT1 ) * dCT2 * dCT3 * stoi ( pcCT4 ) * stoi ( pcCT5 );

								if ( dRTValue >= 1 && dRTValue <= 8  )
								{
									ITK ( setPaoTheoricValue ( tFormTag, 18 ) );
								}
								else if ( dRTValue > 8 && dRTValue <= 24 )
								{
									ITK ( setPaoTheoricValue ( tFormTag, 12 ) );
								}
								else if ( dRTValue > 24 && dRTValue <= 48 )
								{
									ITK ( setPaoTheoricValue ( tFormTag, 6 ) );
								}
								else
								{
									ITK ( setPaoTheoricValue ( tFormTag, -1 ) );
								}
							}
							if ( retcode == ITK_ok && ( pcCT5 == NULL || strlen ( pcCT5 ) == 0 || bIsStringInvalid == true ) )
							{
								ITK ( setPaoTheoricValue ( tFormTag, -1 ) );
							}
							if ( pcCT5 != NULL )
							{
								MEM_free ( pcCT5 );
								pcCT5 = NULL;
							}
						}
						if ( retcode == ITK_ok && ( pcCT4 == NULL || strlen ( pcCT4 ) == 0 || bIsStringInvalid == true ) )
						{
							ITK ( setPaoTheoricValue ( tFormTag, -1 ) );
						}
						if ( pcCT4 != NULL )
						{
							MEM_free ( pcCT4 );
							pcCT4 = NULL;
						}
					}
					if ( retcode == ITK_ok && dCT3 == 0 )
					{
						ITK ( setPaoTheoricValue ( tFormTag, -1 ) );
					}
    			}
    			if ( retcode == ITK_ok && ( pcCT1 == NULL || strlen ( pcCT1 ) == 0 || bIsStringInvalid == true ) )
    			{
    				ITK ( setPaoTheoricValue ( tFormTag, -1 ) );
    			}

    			if ( pcCT1 != NULL )
    			{
    				MEM_free ( pcCT1 );
    				pcCT1 = NULL;
    			}
    		}
    	}
    }
	return retcode;
}
