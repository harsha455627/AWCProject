/*==================================================================================================

Copyright (c) 2015 SIEMENS PLM SOFTWARE INC.
Unpublished - All rights reserved
====================================================================================================
File description:

Filename: FVE_create_folder_structure.c
Module  : main

Used to create Folder structure in VSEM
Requires a login account specified by -u=<user> -p=<pass> -g=<group> if not specified, then auto-login is used.
===============================================================================
Date               Name                    Description of Change
18-March-2015      Siddalingu Rangappa      Initial version
07-Dec-2017			Shreya Suman			Modified to fix import issue.
===============================================================================*/

#include <time.h>
#include "FVE_create_folder_structure.h"
#include "FVE_constants.h"

/* Global Attributes */
char *          login_group                     = NULL;
char *          login_user                      = NULL;
char *          login_password                  = NULL;

FILE *          logfileptr                      = NULL;
FILE *          movefileptr                     = NULL; 

struct stack
{
	tag_t folderTag[MAXSIZE];
    int folderLevel[MAXSIZE];
	int top;	
};

typedef struct stack STACK;
STACK s;


/*  Function to add an element to the stack */
void initStack()
{
		s.top = -1;
}

int isStackEmpty()
{
	int b= 0;

	if (s.top == - 1)
	{
		b = 1;
	}

	return b;
}

void push (tag_t folderTag, int level)
{
	s.top = s.top + 1;	
	s.folderTag[s.top] = folderTag;
    s.folderLevel[s.top] = level;

	return;
}
/*  Function to delete an element from the stack */
void pop()
{
	if (s.top == - 1)
	{
		printf ("Stack is Empty\n");
		return;
	}
	else
	{
		s.folderTag[s.top] = NULLTAG;
		s.top = s.top - 1;
	}
	return;
}

/*  Function to retunns top element */
void peek(tag_t *folder_tag, int *level)
{
	*folder_tag = s.folderTag[s.top];
	*level = s.folderLevel[s.top];
	return ;
}

/*******************************************************************************
* NAME: ITK_user_main
*
* DESCRIPTION
*   This utility will read the input file ,create Folder Structure . 
*   If present will update the sort order of folders
*
* ARGUMENTS
*   u              		In     User name
*   p              		In     Password
*   g              		In     Group
*   file         		In     Input definition name
*
* RETURNS
*   0                    - Success
*   1                    - Failure
*
* NOTES
*
*  Date          Author                 Change Description
* ----------     -------------------    -----------------------------
*  March 2014     Siddalingu R           Created
******************************************************************************/
extern int ITK_user_main( int argc, char **  argv )
{
	int             ifail                           = ITK_ok;
	int             line_count                      = 0;
	int				current_level                   = -1;
	int             folder_line_cnt                 = 0;
	int             sort_order                      = 0;
	int             folder_level                    = 0;	
    char            fileline[1024]                   = "";	
	char            logfilename[255 + 1]            = "";
	char*           input_file                      = NULL;	
	char*           time_stamp                      = NULL;
	char*           folder_name                     = NULL;
	char*           folder_type                     = NULL;
	char**          folder_line_values              = NULL;	
	
	FILE *          inputfileptr                    = NULL;
	
	tag_t           folderTag                       = NULLTAG;
	tag_t			current_folder					= NULLTAG;


	if (ITK_ask_cli_argument("-h"))
	{
		print_usage();
		exit(0);
	}

	/*Append the log file name with the date and time stamp*/
	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	sprintf(logfilename,"FVE_CREATE_FOLDER_STRUCTURE_%s.log",time_stamp);	

	logfileptr = fopen( logfilename, "w+");
	if (logfileptr == NULL)
	{
		fprintf(stderr, "ERROR: Failed to create log file:%s\n", logfilename);
		exit(1);
	}

	printf("\n\nLog information will be written into %s\n\n",logfilename);

	if(logfileptr)
	{        
		fprintf(logfileptr,"\n********************************************************************\n\n");
		fprintf(logfileptr,"Utility: FVE_create_folder_structure\n");
		fprintf(logfileptr,"Start time: %s\n", time_stamp);
		fprintf(logfileptr,"argc: %d\n", argc);
		fprintf(logfileptr,"\n********************************************************************\n\n");
	}

	FVE_FREE(time_stamp);

	ITK_initialize_text_services (0);

	//if ( argc > 2 )
	//{
		login_user		= ITK_ask_cli_argument("-u=");
		login_password	= ITK_ask_cli_argument("-p=");
		login_group		= ITK_ask_cli_argument("-g=");
		input_file		= ITK_ask_cli_argument("-file=");		
		
		/* Logging into Teamcenter */
		if ( login_user != NULL && (tc_strlen(login_user) > 0)  
			&&  login_password != NULL && (tc_strlen(login_password) > 0) 
			&&  login_group != NULL && (tc_strlen(login_group) > 0))
		{
   			ITK(ITK_init_module (login_user, login_password, login_group))
			if(ifail != ITK_ok)
			{
				printf ("ERROR: Unable to login\n");
				printf ( "Ifail = %d\n", ifail);
				fprintf (logfileptr, "ERROR: Unable to login\n");
				fflush(logfileptr);
				fflush(stdout);
				fclose( logfileptr);
				exit (1);
			}
			else
			{
				printf ("Login successful.\n");
				fprintf(logfileptr,"Login successful.\n");
				fflush(logfileptr);
			}
		}
		else
		{
			/*printf ("ERROR: Unable to login\n");
			fprintf (logfileptr, "ERROR: Missing login information.\n");
			fflush(logfileptr);
			fclose( logfileptr);
			fflush(stdout);
			exit (1);*/

			ifail =  ITK_auto_login ();
			
			if(ifail != ITK_ok)
			{
				printf ("ERROR: Unable to auto login\n");
				printf ( "Ifail = %d\n", ifail);
				fprintf(logfileptr,"Auto Login unsuccessful\n");
				fflush(logfileptr);
				fclose( logfileptr);
				fflush(stdout);
				exit (1);
			}
			else
			{
				printf ("Auto Login successful.\n");
				fprintf(logfileptr,"Auto Login successful.\n");
				fflush(logfileptr);
			}
		}
	//}
	//else
	//{
	//	ifail =  ITK_auto_login ();
	//	printf ( "Ifail = %d\n", ifail);
	//	if(ifail != ITK_ok)
	//	{
	//		printf ("ERROR: Unable to login\n");
	//		fprintf(logfileptr,"Auto Login unsuccessful\n");
	//		fflush(logfileptr);
	//		fclose( logfileptr);
	//		fflush(stdout);
	//		exit (1);
	//	}
	//}

	fprintf(logfileptr,"-------------------------------------------------------------------\n\n");

	if (!input_file)
	{
		printf("Unable to read input file , utility terminating.\n\n");
		fprintf(logfileptr,"Unable to read input file , utility terminating.\n\n");
		fflush(logfileptr);
	}
	else
	{
		/*Read input file */
		inputfileptr = fopen( input_file, "r");

		if (!inputfileptr)
		{
			printf("Unable to read definition file , utility terminating.\n\n");
			fprintf(logfileptr,"Unable to read definition file , utility terminating.\n\n");
			fflush(logfileptr);
		}
		else
		{
			fprintf(logfileptr,"Processing File : %s\n\n",input_file);
			fflush(logfileptr);

			//initialize Stack
			initStack();

			/* Process input file */
			while (fgets(fileline, 1024, inputfileptr) != NULL) 
			{
				line_count++ ;

				ITK(FV_parse_delimited_string(fileline, FV_TRIPLE_BAR, FV_TRIM_BLANKS, &folder_line_cnt, &folder_line_values))

				if ( folder_line_cnt != 4 )
				{
					fprintf(logfileptr,"Wrong Input format in Line Number = %d\n", line_count);
					fflush(logfileptr);
					continue;
				}

				folder_level = atoi(folder_line_values[0]);
				folder_name=folder_line_values[1];
				folder_type=folder_line_values[2];
				sort_order = atoi(folder_line_values[3]);
		
				if ( isStackEmpty())
				{
					current_folder = NULLTAG;
					current_level=-1;
				}
				else
				{
					peek(&current_folder, &current_level);
				}

				while ( current_level >= folder_level)
				{
					pop();
					if ( isStackEmpty())
					{
							current_folder = NULLTAG;
							current_level=-1;
					}
					else
					{
						peek(&current_folder, &current_level);
					}
				}
		
				ITK(fve_create_vsem_gmrdb_folder_under_parent(current_folder, folder_name,folder_type, &folderTag));
				ITK(FV_set_folder_sort(folderTag, sort_order));	
				push(folderTag,folder_level);

			}//End of while loop
			fclose(inputfileptr);
		}
	}

	if (logfileptr )
	{
		fprintf(logfileptr,"\nUtility completed...\n\n");
		get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
		fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
		fclose( logfileptr);
	}


	FVE_FREE(time_stamp);
	ITK_exit_module( true );	

	printf("\nUtility completed...\n\n");

	return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}

/* This function checks the tokenised value is null or not */
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}


static void print_usage(void)
{
	printf("\n********************************************************\n");
	printf("Usage: fve_create_folder_structure <args>\n\n");
	printf(" Where args include the following:\n\n");
	printf(" -u=<login user id>\n");
	printf(" -p=<login password>\n");
	printf(" -g=<login group>\n");
	printf(" -file=<input file path>\n");
	printf("\n");
	printf("***********************************************************\n\n");        
}

/*  create Folder */
extern int fve_create_vsem_gmrdb_folder_under_parent(tag_t parent_folder,char * folder_name,char * folder_type,tag_t *folder_tag)
{
	int		ifail						= ITK_ok;
	
	tag_t	folderType					= NULLTAG;
	tag_t   newFolderTag                = NULLTAG;
	
	char **	attr_values					= NULL;
	char*   attrNames[1]                = {object_namePROP};

	*folder_tag = NULLTAG;
	
	TC_write_syslog("Entering function : fve_create_vsem_gmrdb_folder_under_parent\n");

	attr_values    = (char **) MEM_alloc(sizeof(char*)*2);
	attr_values[0] = (char *) MEM_alloc((sizeof(char)*strlen(folder_name))+1);
	tc_strcpy(attr_values[0], folder_name);
	attr_values[0] = folder_name;

	fprintf(logfileptr,"\nProcessing Folder : %s.\n",folder_name);
	fflush(logfileptr);

	if ( parent_folder == NULLTAG)
	{
		int num_rows = 0;
		
		tag_t *results_tag = NULL;
		
		ITK(FV_search_objects_by_attrs(folder_type, 1, attrNames, attr_values, &num_rows, &results_tag ));
		
		if ( num_rows > 0)
		{
			newFolderTag = results_tag[0];
		}
		
		FVE_FREE(results_tag);

	}
	else
	{
		ITK(FV_find_folder_under_parent(parent_folder, folder_name, folder_type, &newFolderTag));
	}

	if ( newFolderTag == NULLTAG)
	{ 
		fprintf(logfileptr,"Folder Not Found, Creating...\n");
		fflush(logfileptr);

		ITK(TCTYPE_ask_type(folder_type, &folderType))	   
		ITK(FV_create_simple_workspace_object(folderType, 1,attrNames, attr_values, &newFolderTag))	
		//Create a relation between parent_folder and the new folder
		if ( parent_folder != NULLTAG )
		{
			ITK( FL_insert(parent_folder,newFolderTag,999))
			ITK( AOM_save(parent_folder));
		}
	}
	else
	{
		fprintf(logfileptr,"Folder Already Exists.\n");
		fflush(logfileptr);
	}

	*folder_tag = newFolderTag;

	TC_write_syslog("Exiting function : fve_create_vsem_gmrdb_folder_under_parent\n");

	if(attr_values) FVE_FREE(attr_values);

	return ifail;
}

extern int FV_find_folder_under_parent(tag_t  parent_folder,char * folder_name,char * folder_type,tag_t *folder_tag)
{

	int         ifail = ITK_ok;
	int			contentIndx = 0;
	int			num_contents = 0;
	
	char*		content_name = NULL;
	
	tag_t*      content_tags = NULL;

	*folder_tag = NULLTAG;
	
	TC_write_syslog("Entering function : FV_find_folder_under_parent\n");
		
	ITK(AOM_ask_value_tags(parent_folder, "contents", &num_contents, &content_tags))
	
	for( contentIndx = 0; contentIndx < num_contents; contentIndx++)
	{
		char *typeName = NULL;
		
		tag_t typeTag = NULLTAG;
		
		ITK(AOM_ask_name(content_tags[contentIndx], &content_name));
		
		ITK(FV_ask_object_type_and_typename(content_tags[contentIndx], &typeTag, &typeName));
		
		if((tc_strcmp(content_name, folder_name) == 0) && ( tc_strcmp(typeName, folder_type) == 0 ))
		{
			*folder_tag = content_tags[contentIndx];
			FVE_FREE(typeName);
			break;
		}
		
		FVE_FREE(typeName);
	}

	TC_write_syslog("Exiting function : FV_find_folder_under_parent\n");
	
	FVE_FREE(content_tags);

	return ifail;
}

/*  Function to dump ITK errors */
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
	int             n_ifails                    = 0;
	const int       *severities                 = NULL;
	const int       *ifails                     = NULL;
	const char      **texts                     = NULL;
	char            *errstring                  = NULL; 

	EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
	if ( n_ifails && texts != NULL )
	{
		if ( ifails[n_ifails-1] == stat )
		{
			TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
		}
		else
		{
			EMH_ask_error_text (stat, &errstring );
			TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
			FVE_FREE( errstring );
			printf("mbfd");
		}
	}
	else
	{
		EMH_ask_error_text (stat, &errstring );
		TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
		FVE_FREE( errstring );
	}
	TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fprintf(logfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fflush(logfileptr);
}

//extern int FV_move_items_from_parent_to_children( tag_t parent_folder, tag_t child_folder)
//{
//	int ifail = ITK_ok;
//	int item_count = 0;
//	
//	char* child_folder_name = NULL;
//	char* parent_folder_name = NULL;
//	
//	tag_t* item_tags = NULL;
//	
//	logical has_items = false;
//	
//	if ( parent_folder == NULLTAG || child_folder == NULLTAG )
//	{
//		//fprintf(movefileptr,"Parent_Folder|Object_count|Child_Folder|Object_String|Move_Status\n");
//		fprintf(logfileptr,"\nEither Parent folder is null or child folder is null. so not moving any items\n");
//		return ifail;
//	}
//	
//	ITK(AOM_ask_name(child_folder, &child_folder_name));
//	ITK(AOM_ask_name(parent_folder, &parent_folder_name));
//	
//	ITK(FV_get_items_to_move(parent_folder, child_folder, &item_count, &item_tags, &has_items));
//	
//	fprintf(movefileptr,"%s|%d|%s||\r\n", parent_folder_name, item_count, child_folder_name);
//	
//	if( has_items )
//	{
//		int inx = 0;
//		
//		fprintf(logfileptr,"Items found in parent folder <%s> : <%d>\n", parent_folder_name, item_count);
//		fprintf(logfileptr,"moving items from parent: <%s> to child : <%s> folder\n", parent_folder_name, child_folder_name);
//		
//		for ( inx = 0; inx < item_count; inx++ )
//		{
//			char *item_string = NULL;
//			
//			logical is_added = false;
//			
//			ITK(AOM_ask_value_string(item_tags[inx], "object_string", &item_string));
//			
//			ITK(FV_add_object_to_folder(item_tags[inx], child_folder, &is_added));
//			
//			if( is_added )
//			{
//				TC_write_syslog("\nremoving item from parent: <%s>\n", parent_folder_name);
//				ITK(FV_remove_object_from_folder(item_tags[inx], parent_folder));
//				fprintf(logfileptr,"\t%s|Success\n", item_string);
//				fprintf(movefileptr,"|||%s|SUCCESS\r\n", item_string);
//			}
//			else
//			{
//				FV_DEBUG_TXT(("Unable to add <%s> to folder <%s>......\n", item_string, child_folder_name))
//				fprintf(logfileptr,"\t%s|Error\n", item_string);
//				fprintf(movefileptr,"|||%s|ERROR\r\n", item_string);
//			}
//			FVE_FREE(item_string);
//		}
//	}
//	else
//	{
//		fprintf(logfileptr,"There are no items under the parent <%s> to be moved to child folder <%s>\n", parent_folder_name, child_folder_name);
//	}
//	
//	FVE_FREE(parent_folder_name);
//	FVE_FREE(child_folder_name);
//	FVE_FREE(item_tags);
//	
//	return ifail;
//}

//extern int FV_get_items_to_move(tag_t parent_folder, tag_t child_folder, tag_t *items_count, tag_t **item_tags, logical *has_items)
//{
//	int ifail = ITK_ok;
//	int n_contents = 0;
//	int range_count = 0;
//	int inx = 0;
//	
//	tag_t* content_tags = NULL;
//	
//	char* child_folder_name = NULL;
//	char** range_values = NULL;
//	
//	*items_count = 0;
//	*item_tags = NULL;
//	
//	*has_items = false;
//	
//	ITK(AOM_ask_name(child_folder, &child_folder_name));
//	
//	ITK(FV_parse_delimited_string(child_folder_name, FV_DASH, FV_TRIM_BLANKS, &range_count, &range_values ));
//	
//	if ( range_count != 2)
//	{
//		return ifail;
//	}
//	
//	
//	ITK(AOM_ask_value_tags(parent_folder, CONTENTS_ATTR_NAME, &n_contents, &content_tags));
//	
//	TC_write_syslog("No of contents under parent : %d\n", n_contents);
//	
//	
//	for( inx = 0; inx < n_contents; inx++ )
//	{
//		char *content_type = NULL;
//		
//		ITK(AOM_ask_value_string(content_tags[inx], "object_type", &content_type));
//		
//		if ( tc_strcmp(content_type, FV9GMRDBFolderTYPE) != 0 )
//		{
//			char *identifier_number = NULL;
//			
//			ITK(AOM_ask_value_string(content_tags[inx], fv9GMRIdentifierNumberCmpdPROP, &identifier_number));
//			
//			if ( identifier_number != NULL && tc_strlen(identifier_number) > 0 ) 
//			{
//				if ( ( strcmp( identifier_number, range_values[0]) >= 0 ) && ( strcmp( identifier_number, range_values[1]) <= 0 ))
//				{
//					*item_tags = (tag_t *) MEM_realloc(*item_tags, (*items_count+1)*sizeof(tag_t));
//					(*item_tags)[*items_count] = content_tags[inx];
//					*items_count = *items_count + 1;
//				}
//			}
//			
//			FVE_FREE(identifier_number);
//		}
//		
//		FVE_FREE(content_type);
//	}
//	
//	if ( *items_count > 0 )
//	{
//		*has_items = true;
//		TC_write_syslog("Parent has %d items\n", *items_count);
//	}
//	
//	FVE_FREE(child_folder_name);
//	FVE_FREE(range_values);
//	FVE_FREE(content_tags);
//	
//	return ifail;
//}

extern int FV_add_object_to_folder(tag_t object, tag_t folder, logical *is_added)
{
	int ifail = ITK_ok;
	int numReqContents = 0;
	int contentIndx = 0;
	
	tag_t *req_content_tags = NULL;
	
	logical isObjAlreadyPresent = false;
	
	*is_added = false;
	
	ITK(AOM_ask_value_tags(folder, CONTENTS_ATTR_NAME, &numReqContents, &req_content_tags));
	
	for( contentIndx = 0; contentIndx < numReqContents; contentIndx++)
	{
		if(req_content_tags[contentIndx] == object)
		{
			FV_DEBUG_TXT(("Object already present in folder. SKIPPING......\n"))
			isObjAlreadyPresent = true;
			*is_added = true;
			break;
		}
	}
	
	if(isObjAlreadyPresent == false)
	{
		int folder_index = 0;
		
		ITK(AOM_refresh(folder, true));		
		ITK(FL_ask_size(folder, &folder_index));
		ITK(FL_insert(folder, object, folder_index));
		ITK(AOM_save(folder));
		ITK(AOM_refresh(folder,false));
		
		*is_added = true;
	}
	
	FVE_FREE(req_content_tags);
	
	return ifail;
}

extern int FV_remove_object_from_folder(tag_t object, tag_t folder)
{
	int ifail = ITK_ok;

	ITK(AOM_refresh(folder, true));
	ITK(FL_remove(folder, object));
	ITK(AOM_save(folder));
	ITK(AOM_refresh(folder, false));
	
	return ifail;
}
