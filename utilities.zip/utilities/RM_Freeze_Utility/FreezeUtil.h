/**********************************************************************************
 * Filename        :   FreezeUtil.h
 * Description     :   Defines the macro used in FreezeUtil.c
 * Module          :   Freeze.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *---------------------------------------------------------------------------------
 * Date              Name              Description of Change
 * Nov 2013          Prasmit Pansare        Initial Code
 * --------------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FV9_UPD_DT_DEVICE_NAME_H
#define FV9_UPD_DT_DEVICE_NAME_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>
#include <FV_includes.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>

#include <tccore/aom_prop.h>
#include <tccore/aom.h>

#include <tccore/item.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <sys/stat.h>



/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\



void get_time_stamp(char* format, char** timestamp);

#endif 