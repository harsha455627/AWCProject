//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6_stock_request_custom_save
 *
 */
#include <O6TaneCustomLibrary/O6_stock_request_custom_save.hxx>
#include <O6TaneCustomLibrary/method.hxx>
#include<string>
#include<vector>

/**
 * Function    :  O6_stock_request_custom_save
 * Description :  Update "o6_stock_item_uom_ar" of Goods reuest form based on values of "o6_stock_item_id_ar".
 * Input       :
 */
int O6_stock_request_custom_save( METHOD_message_t * /*msg*/, va_list args )
{
	 int 		irc				    = ITK_ok;
	 int 		iStockId 				= 0;
	 tag_t 		tObjectToSave 			= NULLTAG;
	 int 		iIdCount				= 0;
	 tag_t 		tUOMValue 				= NULLTAG;
	 int 		iObjectsCount			= 0;
	 logical 	lDoSave 				= FALSE;
	 char* 		pcAttrUOMValue 			= (char*)NULL;
	 const char* functionName			= "O6_stock_request_custom_save";
	 char** 	pcIdValues  			= NULL;
	            tObjectToSave 			= (tag_t)va_arg(args, tag_t);
	 char**      headerNames 			= NULL;
	 int         headerNamesCnt 		= 0;
	 std::vector<std::string> myVector;

	 TC_write_syslog("Entered into Function %s \n",functionName);
	 if(tObjectToSave != NULLTAG)
	 {
	  irc = ITK_CALL(AOM_ask_value_strings(tObjectToSave,"o6_stock_item_id_ar",&iIdCount,&pcIdValues));
	  if(iIdCount > 0)
	  {
		  //Loop through all the id's and get the referenced uom_tag and from the tag get the value from "symbol" attribute.
	  for(iStockId = 0;iStockId < iIdCount ;iStockId++)
	  {
		   if ( strlen ( pcIdValues[iStockId] ) != 0)
		  {
			  tag_t tClassTag=NULLTAG,tAttributeTag=NULLTAG,tEnqId=NULLTAG;
			  tag_t *ptObjects;
			  irc = ITK_CALL(POM_class_id_of_class ( Q_CLS, &tClassTag ) );
			  irc = ITK_CALL(POM_attr_id_of_attr ( Q_CLS_ATT, Q_CLS, &tAttributeTag ) );
			  irc = ITK_CALL(POM_create_enquiry_on_string ( tClassTag, tAttributeTag, POM_is_equal_to, &pcIdValues[iStockId], &tEnqId ) );
			  irc = ITK_CALL(POM_execute_enquiry ( tEnqId, &iObjectsCount, &ptObjects ) );
			  irc = ITK_CALL(POM_delete_enquiries ( 1, &tEnqId ) );
			  if ( iObjectsCount == 1 )
			  {
				  irc = ITK_CALL(AOM_ask_value_tag ( ptObjects[0], "uom_tag", &tUOMValue ));
				  if ( tUOMValue != NULLTAG)
				  {
				  irc = ITK_CALL(AOM_ask_value_string ( tUOMValue, "symbol", &pcAttrUOMValue ));
				  }
				  else
				  {
					  tc_strcpy(pcAttrUOMValue,NULL);
				  }
				  if(pcAttrUOMValue!=NULL &&(std::string(pcAttrUOMValue).length()>0))
				  {
					  myVector.push_back(pcAttrUOMValue);
				  }
				  else
				  {
					  myVector.push_back(EMPTY_VALUE);
				  }
			  }
		  }

	  }
	  lDoSave = TRUE;
	  }
	  //If no id's are present then clear the uom array attribute
	  else
	  {
		irc = ITK_CALL ( AOM_refresh ( tObjectToSave, TRUE ) );
		irc = ITK_CALL(AOM_set_value_strings(tObjectToSave, TRG_SLAVE_ATT_UOM_AR,0,NULL));
		irc = ITK_CALL(AOM_save_without_extensions(tObjectToSave));
		ITK_CALL(AOM_refresh(tObjectToSave, FALSE));
	  }
	  //If lDoSave attribute is true then set the values into UOM array attribute.
	    if(lDoSave)
	 	  {
	    	headerNames = (char**) MEM_alloc( myVector.size() * sizeof(char*));

	    	for(int headc =0;headc< myVector.size();headc++)
	    	{
	    		headerNames[headc]	= (char*) MEM_alloc((myVector[headc].length()+1) * sizeof(char));
	    		tc_strcpy(headerNames[headc],myVector[headc].c_str());
	    	}

	 	 	irc = ITK_CALL ( AOM_refresh ( tObjectToSave, TRUE ) );
	 	 	irc = ITK_CALL(AOM_set_value_strings(tObjectToSave, TRG_SLAVE_ATT_UOM_AR,myVector.size(),headerNames));
	 	 	irc = ITK_CALL(AOM_save_without_extensions(tObjectToSave));
	 	 	ITK_CALL(AOM_refresh(tObjectToSave, FALSE));
	 	 	lDoSave =FALSE;
	 	 }

	 }

	 TC_write_syslog("Exit out of the Function %s \n",functionName);


	for (int ij = 0; ij < headerNamesCnt; ij++)
    {
       MEM_free(headerNames[ij]);
    }
	for (int ii = 0; ii < iIdCount; ii++)
	 {
     MEM_free(pcIdValues[ii]);
	 }
   MEM_free(pcIdValues);
   MEM_free(headerNames);
   if(pcAttrUOMValue)MEM_free( pcAttrUOMValue);


	return irc;
}

