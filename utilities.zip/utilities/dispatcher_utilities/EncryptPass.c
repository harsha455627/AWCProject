/**************************************************************************
 **************   COPYRIGHT, 2000, FORD MOTOR COMPANY   *******************
 **************************************************************************
 *
 * CONFIDENTIAL - FORD MOTOR COMPANY
 *
 * This is an unpublished work, which is a trade secret, created in 2000.
 * Ford Motor Company owns all rights to this work and intends to maintain
 * it in confidence to preserve its trade secret status. Ford Motor Company
 * reserves the right to protect this work as an unpublished copyrighted
 * work in the event of an inadvertent or deliberate unauthorized
 * publication. Ford Motor Company also reserves its rights under the
 * copyright laws to protect this work as a published work. Those having
 * access to this work may not copy it, use it, or disclose the information
 * contained in it without the written authorization of Ford Motor Company.
 *
 **************************************************************************
 * File:
 *
 *    EncryptPass.c
 *
 * Purpose:
 *
 *    To encrypt a password.
 *
 * Functions defined here:
 *
 *     NAME: ShowUsage()
 *     NAME: CopyString()
 *
 * Notes:
 *
 * Restrictions:
 *
 * Change history:
 *
 * Author               Date            Change
 * Romit(TATA)          02/01/2000      Created.
 *********************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include"PasswdFunction.h"
#include<string.h>
#define MAX_PASSWD_LEN 20
#define NUM_OF_ARGS 3

char *programName                      = NULL;
char *keyValue                         = NULL;
char *filename                         = NULL;
char *decryptPasswd                    = NULL;
char *valOfEncryptedPasswd             = NULL;

char encryptPasswd[MAX_PASSWD_LEN + 1] = {'\0'};
char actualPasswd[MAX_PASSWD_LEN + 1]  = {'\0'};

/**************************************************************************
 * Name:
 *     ShowUsage()
 * 
 *
 * Purpose:
 * This function shows the usage of various command line options.
 *
 * ARGUMENTS
 * Argument                      In/Out    Description
 *
 * RETURNS
 *
 * Notes:
 *
 * Restrictions:
 *
 * Change history:
 *
 * Author               Date            Change
 * Romit ( TATA )       04/02/2000      Created
 *
 *********************************************************************/

void ShowUsage()
{
    fprintf (stderr, "\nUsage for encryption: \n\
                     %s -k <key> -f <filename>\n",programName);

    exit(0);
}


/**************************************************************************
 * Name:
 *     CopyString()
 * 
 *
 * Purpose:
 * This function copies one string into another.
 *
 * ARGUMENTS
 * Argument                      In/Out    Description
 *
 * char*    inputString          In       Source string to be copied from. 
 * char*    *outputString        Out      Destination string to be copied to.  
 *
 * RETURNS
 *
 *
 * Notes:
 *
 * Restrictions:
 *
 * Change history:
 *
 * Author               Date            Change
 * Romit ( TATA )       04/02/2000      Created
 *
 *********************************************************************/

char *CopyString(char **outputString, char *inputString)
{
    *outputString = (char*) malloc((strlen(inputString) + 1) * sizeof(char));
     strcpy(*outputString, inputString);
     return *outputString;
}


/**************************************************************************
 * Name:
 *     main()
 * 
 *
 * Purpose:
 * This function calls EncryptPasswd().
 *
 * ARGUMENTS
 * Argument                      In/Out    Description
 *
 * int      argc                 In       Argument counter. 
 * char**   argv                 Out      Argument vector.  
 *
 * RETURNS
 *
 *
 * Notes:
 *
 * Restrictions:
 *
 * Change history:
 *
 * Author               Date            Change
 * Romit ( TATA )       04/02/2000      Created
 *
 *********************************************************************/

int main(int argc, char **argv)

{
    register char *argString = NULL;

    FILE *filePtr            = NULL;


    programName = argv[0];

    if (argc <  NUM_OF_ARGS )
    {
        ShowUsage();
    }

    while (--argc > 0 && (*++argv)[0] == '-')
    {
        for (argString = argv[0] + 1; *argString != '\0'; argString++)
        {
            switch (*argString)
            {
                case 'k':

                    if (--argc <= 0)
                    {
                        fprintf(stderr, "option: -k requires a key\n");
                        ShowUsage();
                    }

                    CopyString(&keyValue ,*++argv);
                    break;

                case 'f':

                    if (--argc <= 0)
                    {
                        fprintf(stderr, "option: -f requires a filename\n");
                        ShowUsage();
                    }

                    CopyString(&filename ,*++argv);
                    break;

                default:
                   
                    fprintf(stderr, "Invalid Option %c\n", *argString);
                    ShowUsage();
                    break;
        
            }/****************************************************************
              *end of switch(...)
              ****************************************************************/

        }/*********************************************************************
          *End of for(...)
          ********************************************************************/

    }/************************************************************************
      *End of while(...)
      ************************************************************************/


    if ((keyValue == NULL) || (strlen(keyValue) == 0))
    {
        fprintf(stderr, "Value of key is not supplied for encryption\n");
        ShowUsage();
    }

    /* Get the password from the user */
    system("stty -echo");

    fprintf(stdout, "Enter the password to be encrypted\n");

    scanf("%s", actualPasswd);

    system("stty echo");

    if ((actualPasswd == NULL) || (strlen(actualPasswd) == 0))
    {
      fprintf(stderr, "Password is not supplied for encryption\n");
      ShowUsage();
    }

    /**********************************************************************
     *Calling the function EncryptPasswd().
     *********************************************************************/

    EncryptPasswd(actualPasswd, keyValue, &valOfEncryptedPasswd);

    if ((valOfEncryptedPasswd == NULL) ||
           (strlen(valOfEncryptedPasswd) == 0))
    {
        fprintf(stderr, "Password encryption logic failed to encrypt the password\n");
        exit(0);
    }

    /**********************************************************************
     *Writing the encrypted password into the file .Password.PWF in the 
     *current directory.
     **********************************************************************/ 

    if((filename == NULL) || (strlen(filename) == 0))
    {
      if ((filePtr = fopen("./.Password.PWF","w")) == NULL)
      {
        fprintf(stderr, "Unable to create a file .Password.PWF in the current directory\n");
        exit(0);
      }
    }
    else
    {
      if ((filePtr = fopen(filename,"w")) == NULL)
      {
        fprintf(stderr, "Unable to create a file %s in the current directory\n", filename);
        exit(0);
      }
    }

    fprintf(filePtr,"%s",valOfEncryptedPasswd);

    fclose(filePtr); 

    if((filename == NULL) || (strlen(filename) == 0))
      fprintf(stdout, "Encrypted password written to ./.Password.PWF \n");
    else
      fprintf(stdout, "Encrypted password written to ./%s\n", filename);
    
    free(keyValue);
    free(filename);
    
}/****************************************************************************
  *End of main()
  **************************************************************************/
