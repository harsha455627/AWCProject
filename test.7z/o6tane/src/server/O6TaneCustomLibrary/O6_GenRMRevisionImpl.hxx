//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object O6_GenRMRevisionImpl
//

#ifndef O6TANE__O6_GENRMREVISIONIMPL_HXX
#define O6TANE__O6_GENRMREVISIONIMPL_HXX

#include <O6TaneCustomLibrary/O6_GenRMRevisionGenImpl.hxx>

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>


namespace o6tane
{
    class O6_GenRMRevisionImpl; 
    class O6_GenRMRevisionDelegate;
}

class  O6TANECUSTOMLIBRARY_API o6tane::O6_GenRMRevisionImpl
    : public o6tane::O6_GenRMRevisionGenImpl
{
public:


protected:
    ///
    /// Constructor for a O6_GenRMRevision
    explicit O6_GenRMRevisionImpl( O6_GenRMRevision& busObj );

    ///
    /// Destructor
    virtual ~O6_GenRMRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    O6_GenRMRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    O6_GenRMRevisionImpl( const O6_GenRMRevisionImpl& );

    ///
    /// Copy constructor
    O6_GenRMRevisionImpl& operator=( const O6_GenRMRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class o6tane::O6_GenRMRevisionDelegate;

};

#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
#endif // O6TANE__O6_GENRMREVISIONIMPL_HXX
