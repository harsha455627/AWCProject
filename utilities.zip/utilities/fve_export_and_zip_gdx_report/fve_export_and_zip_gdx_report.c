/*=======================================================================================
Copyright (c) 2015 SIEMENS PLM SOFTWARE INC.
Unpublished - All rights reserved            
=========================================================================================
File description:

    Filename: fve_export_and_zip_gdx_report.c
    Module  : main
      
    Requires a login account specified by -u=<user> -p=<pass> -g=<group>
    This utility will run as a cron job on scheduled time and does the following.
    1. Generate XML GDX Report on the path specified(Read the path from preference value)
    2. Export xsd data set to the GDX report folder.
    3. The GDX report, will be zipped along with the XSD file. The naming convention 
       will gdx_timestamp.zip
    4. The Zip file will be attached to the �Export� folder of GMRDB Perspective in 
       descending order of their creation date.
=========================================================================================
Date           Name                Description of Change
Aug-2015       Siddalingu R        Initial version
Oct-2015	   Debanjan C		   VSEM3.1 - Modified and Added part for DTC 04
=========================================================================================*/

#include "fve_export_and_zip_gdx_report.h"

/*Global Attributes*/
static char*   xml_report_string   =   NULL;
FILE*          log_file_ptr        =   NULL;
FILE*          gdx_xmlFile         =   NULL;

/***************************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *   This utility will generate GDX XML report and attach as a zip dataset in Export folder
 *   of GMRDB perspective along with xsd file.
 *
 *
 * ARGUMENTS
 *   u              In     User name
 *   p              In     Password
 *   g              In     Group
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date         Author                 Change Description
 * ------------  -------------------    -------------------
 *  August 2015  Siddalingu Rangappa    Created
 *  Oct	2015	 Debanjan Chatterjee	Modified
 *  Oct 2015	 Debanjan Chatterjee	Modified for Auto-Login
 *
 /***************************************************************************************/
extern int ITK_user_main( int argc, char **  argv )
{   

	int       ifail                  = ITK_ok;       
	char      logfilename[255 + 1]   = {""};    
	char*     output_dir             = NULL;
	char*     time_stamp             = NULL;          
	char*     zipDirPath             = NULL;
	char*     zipDirName             = NULL;
	char*     gdxReportName          = NULL;
	char*     dirPath                = NULL;
	tag_t     repDatasetTag          = NULLTAG; 
	tag_t     zipDatasetTag          = NULLTAG; 
	tag_t     expZipFolderTag        = NULLTAG;
	tag_t     xsdDatasetTag          = NULLTAG; 
	logical   isFlag                 = FALSE;
	logical   isExported             = FALSE;

	/*Append the log file name with the date and time stamp */
	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	sprintf(logfilename,"fve_export_and_zip_gdx_report%s.log",time_stamp);

	log_file_ptr = fopen( logfilename, "w+");
	if (log_file_ptr == NULL)
	{
		fprintf(stderr, "ERROR: Cannot create log file:%s\n", logfilename);
		exit(1);
	}
	printf("\nLog information will be written into %s\n\n",logfilename);

	if(log_file_ptr)
	{        
		fprintf(log_file_ptr,"Start time: %s\n", time_stamp);
		FVE_FREE(time_stamp)
	}

	if (ITK_ask_cli_argument("-h"))
	{
		print_usage();
		exit(0);
	}    
	output_dir     = ITK_ask_cli_argument("-outDir=");
	ITK_initialize_text_services (0);

	// Logging to Teamcenter
	ifail = ITK_auto_login ();
	if(ifail != ITK_ok)
	{
		printf ("ERROR: Unable to login\n");
		fprintf(log_file_ptr,"Auto Login unsuccessful\n");
		fclose( log_file_ptr );
		exit(0);
	}
	else 
	{
		printf ("Auto Login successful\n");
		fprintf(log_file_ptr,"Auto Login successful\n");
	}

	if(ifail==ITK_ok)
	{  
		//Generate Zip directory name and path
		CLEANUP(FV_generate_zip_dir_and_path(output_dir,&zipDirName,&gdxReportName,&zipDirPath))
		if(zipDirPath != NULL)
		{
			isFlag = TRUE;
			//Create directory
			fprintf(log_file_ptr,"Generating GDX directory with name:%s in path:%s.\n", zipDirName,zipDirPath);
			CLEANUP(FV_create_zip_directory(zipDirPath))

				/* Since GDX report is generated through utility ,So setting the flag to True
				If the GDX reprort is generated from Client(File->GMRDB->GDX Report) the 
				flag value should be False. */              
				CLEANUP(FV_generate_gdx_xml_reportAndZip(gdxReportName,"",zipDirPath,&isFlag,&repDatasetTag))

				if(repDatasetTag == NULLTAG)
				{                   
					fprintf(log_file_ptr,"Successfully generated GDX xml file :%s.xml in path:%s.\n", zipDirName,zipDirPath);
					fprintf(log_file_ptr,"Started exporting xsd file in the path:%s.\n",zipDirPath);

					//Find xsd dataset
					CLEANUP(AE_find_dataset(XSD_DATASET_NAME,&xsdDatasetTag))

						if(xsdDatasetTag != NULLTAG)
						{                           
							isExported =  FALSE;

							//Export xsd dataset to Zip dir folder
							CLEANUP(FV_export_named_ref(xsdDatasetTag,DATASET_TYPE,zipDirPath,&isExported))

								if(isExported)
								{
									fprintf(log_file_ptr,"Successfully exported xsd file: %s.\n", XSD_DATASET_NAME);
								}
								else
								{
									fprintf(log_file_ptr,"Failed to export xsd file: %s.\n", XSD_DATASET_NAME);
								}
						}               

						//Creat ZIP file and attach it to Export folder
						CLEANUP(FV_gdx_zip_directory(zipDirName,output_dir, &zipDatasetTag))

							//Add Zip file to Export folder
							if (zipDatasetTag != NULLTAG)
							{                           
								fprintf(log_file_ptr,"Successfully Zipped the directory\n");

								FV_strdup(output_dir,&dirPath);
								FV_strcat(&dirPath, FV_FILEPATH_DELIMITER);
								FV_strcat(&dirPath,zipDirName);
								fprintf(log_file_ptr,"Deleting the directory :%s...Only Keeping Zipped file\n",zipDirName);
								FV_delete_directory(dirPath);

								// Get Export folder tag from GMRDB folder
								CLEANUP(FV_get_export_folder_tag(&expZipFolderTag))

									if(expZipFolderTag != NULLTAG)
									{
										// Auto login Utility, BYPASS needed for Non Admins.
										AM__set_application_bypass(true);
										// Add Zip dataset to Zip Folder.
										CLEANUP(FV_update_folder (expZipFolderTag,zipDatasetTag))
											fprintf(log_file_ptr,"Completed pasting Zip file in GMRDB Export folder\n");
									}
							}
				}

				ITK_exit_module( true );
				printf("Utility completed successfully.\n\n");
				fprintf(log_file_ptr,"Exiting the utility.\n\n");
				fprintf(log_file_ptr,"-----------------------------------------------------------------------------------------------------------\n\n");
				get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
				fprintf(log_file_ptr,"\nEnd time: %s\n", time_stamp); 
				FVE_FREE(time_stamp)    
		}
	}
	else
	{
		ITK_exit_module( true );
		printf("There was an error while execution...Check the logs .\n\n");
		get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
		fprintf(log_file_ptr,"\nEnd time: %s\n", time_stamp); 
		FVE_FREE(time_stamp)
	}
	if (log_file_ptr ) fclose( log_file_ptr);

CLEANUP: 
	AM__set_application_bypass(false);
	return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


static void print_usage(void)
{   
	printf("\n***************************************************************************************\n");
	printf(" This utility is to generate and zip the GDX Report and xsd file and paste inside GMRDB Export folder.\n\n");
	printf("\n***************************************************************************************\n");
	printf(" Usage: fve_export_and_zip_gdx_report <args>\n\n");
	printf(" Where args include the following:\n\n");
	printf(" -outDir=<Specify the output directory\n");
	printf(" -h=<any value> for usage help\n\n");
	printf(" NOTE:- This Utility uses Auto-login.\n");
	printf("****************************************************************************************\n\n");
}

int FV_generate_gdx_xml_reportAndZip(char* gdx_rep_name, char* gdx_rep_type, char* zipDirPath, logical *flagValue,tag_t* rep_dataset)
{   
	int     ifail                            = ITK_ok;
	char*   pref_val                         = NULL;
	char*   function_name                    = "FV_generate_gdx_xml_reportAndZip"; 
	char*   gdx_file_abs_path                = NULL;
//	char*   time_stamp                       = NULL; 

	FV_DEBUG_TXT(("Entering: %s\n", function_name)) 
	//get_time_stamp(DATE_FORMAT_STR, &time_stamp);

	if(tc_strcmp(zipDirPath,"") == 0)
	{
		CLEANUP(PREF_ask_char_value (FVE_TMP_DIR_PREF, 0, &pref_val))
		if(pref_val == NULL)
		{
			//FVE_FREE(time_stamp)
			FV_DEBUG_TXT(("\n FVE_TMP_DIR preference is not set. report cannot be generated!!\n"));
			CLEANUP(EMH_store_error(EMH_severity_error, FVE_TMP_NOT_PRESENT));
			return FVE_TMP_NOT_PRESENT;
		}
		FV_strcat(&gdx_file_abs_path, pref_val);
		FV_strcat(&gdx_file_abs_path, FV_FILEPATH_DELIMITER);
		FV_strcat(&gdx_file_abs_path, gdx_rep_name);
		FV_strcat(&gdx_file_abs_path, GDX_EXTENSION);           
	}
	else
	{
		FV_strcat(&gdx_file_abs_path, zipDirPath);
		FV_strcat(&gdx_file_abs_path, FV_FILEPATH_DELIMITER);
		FV_strcat(&gdx_file_abs_path, gdx_rep_name);
		FV_strcat(&gdx_file_abs_path, GDX_EXTENSION); 
	}   

	CLEANUP(FV_generate_gdx_xml_report(gdx_rep_name,false,gdx_file_abs_path,gdx_xmlFile))
	

CLEANUP:
		FV_DEBUG_TXT(("Exiting: %s\n", function_name))
		return ifail;
}

int FV_create_zip_directory(char *dirFullPath)
{
	int     ifail                       = ITK_ok;
	char*   function_name               = "FV_create_zip_directory";
	char*   pszSysCommandAndDirFullPath = NULL;

	FV_DEBUG_TXT(("Entering: %s\n", function_name))

		if(!dirFullPath || (tc_strlen(dirFullPath) < 1)) 

			CLEANUP(FV_handle_missing_arg_error(function_name, "dirFullPath"))
			FV_DEBUG_TXT(("In %s, attempting to create directory %s\n", function_name, dirFullPath))

#if defined(WNT)    

			CLEANUP(FV_strdup("mkdir ", &pszSysCommandAndDirFullPath))
			CLEANUP(FV_strcat(&pszSysCommandAndDirFullPath, dirFullPath))
			ifail = system(pszSysCommandAndDirFullPath);

#else
			ifail = mkdir(dirFullPath, S_IRWXU | S_IRWXG | S_IRWXO);
#endif

	FV_DEBUG_TXT(("Exiting: %s\n", function_name))

CLEANUP:
	return ifail;
}

int FV_generate_zip_dir_and_path(char* prefValue, char** sanitizedObjDirName,char** fileName, char** directoryPath)
{
	int   ifail            = ITK_ok;
	char* function_name    = "FV_generate_zip_dir_and_path";
	char* gdxPrefix        = "GMRDB_";    
	char* timeStamp        = NULL;  
	char* zipFileName      = NULL;
	char* gdxFileName      = NULL;
	char* zipFilePath      = NULL;

	*sanitizedObjDirName   = NULL;
	*fileName              = NULL;
	*directoryPath         = NULL;

	FV_DEBUG_TXT(("Entering: %s\n", function_name))

		if (prefValue == NULL)
			CLEANUP(FV_handle_missing_arg_error(function_name, "prefValue")) 

		//Construct GDX report name. Format GMRDB_YYYYMMDD_HHMMSS_gdx.
		get_time_stamp(DATE_FORMAT_STR, &timeStamp);
		CLEANUP(FV_strdup(gdxPrefix, &zipFileName))
		CLEANUP(FV_strcat(&zipFileName, timeStamp))
		CLEANUP(FV_strcat(&zipFileName, "_gdx"))
		CLEANUP(FV_sanitize_filename(zipFileName,sanitizedObjDirName))

		//Construct GDX report name. Format GMRDB_YYYYMMDD_HHMMSS.  
		CLEANUP(FV_strdup(gdxPrefix, &gdxFileName))
		CLEANUP(FV_strcat(&gdxFileName, timeStamp))  
		CLEANUP(FV_sanitize_filename(gdxFileName,fileName))  

		//Generate full directory path.
		CLEANUP(FV_strdup(prefValue, &zipFilePath))
		CLEANUP(FV_strcat(&zipFilePath, FV_FILEPATH_DELIMITER))
		CLEANUP(FV_strcat(&zipFilePath, *sanitizedObjDirName))    

		//Return file path
		*directoryPath = zipFilePath;

	FV_DEBUG_TXT(("Exiting: %s\n", function_name))

CLEANUP:
	FVE_FREE(timeStamp) 
		return ifail;
}

int FV_gdx_zip_directory(char* dirName, char* parentDirPath, tag_t* zipDatasetTag)
{
	int         ifail                = ITK_ok;
	int         processReturnCode    = 0;
	char*       function_name        = "FV_gdx_zip_directory";
	char*       dirPath              = NULL;
	char*       zipFilePath          = NULL;
	char*       zipDatasetName       = NULL;
	char*       commandFilePath      = NULL;
	char*       zipExecutablePref    = NULL;
	char*       zipCommandArgsPref   = NULL;
	char*       currentDirectory     = NULL;
	char*       args[2];    
	tag_t       zipFileTag           = NULLTAG;
	IMF_file_t  zipFileDescriptor;
	FILE        *filePtr;

	if(dirName == NULL)
		CLEANUP(FV_handle_missing_arg_error(function_name, "dirName")) 

		if (parentDirPath == NULL)
			CLEANUP(FV_handle_missing_arg_error(function_name, "parentDirPath")) 

			FV_DEBUG_TXT(("Entering: %s, dirName = %s, parentDirPath = %s\n", function_name, dirName, parentDirPath))

			dirPath = (char*) MEM_alloc(sizeof(char)*(tc_strlen(parentDirPath)+tc_strlen(dirName)+5)); 
	sprintf(dirPath, "%s%s%s", parentDirPath, FV_FILEPATH_DELIMITER, dirName);

	// Return NULLTAG if not a valid directory.
	if (!FV_path_is_directory(dirPath))
		goto CLEANUP;

	/*First check for valid directory and for contents.
	If no contents, then don't zip file.
	Get full path of the Zip executable from preference.
	It must exist on server machine with execute permission.*/
	CLEANUP(FV_ask_preference_value(FV_ZipExecutablePathPREF, TC_preference_site, FV_REQUIRED, &zipExecutablePref))

		/*Zip the directory. Use the InfoZip executable bundled with TCUA in TCROOT/bin (zip.exe).
		InfoZip requires that process be attached to parent directory of the directory to be zipped.
		I have found no way to make tcserver process do a change director (cd).
		So create a command file and run as separate process.*/
		commandFilePath = (char*) MEM_alloc(sizeof(char)*(tc_strlen(parentDirPath)+tc_strlen(FV_SHELL_FILE_EXTENSION)+21)); 
	sprintf(commandFilePath, "%s%szipCommand.%s", parentDirPath, FV_FILEPATH_DELIMITER, FV_SHELL_FILE_EXTENSION);

	filePtr = fopen(commandFilePath, "w");
	if (filePtr == NULL)
	{
		TC_write_syslog("ERROR in %s: failed to open command file %s for WRITE.\n", function_name, commandFilePath);
		EMH_store_error_s2(EMH_severity_error, FV_FILE_OPEN_FAILURE, commandFilePath, FV_WRITE_ACCESS);
		ifail = FV_FILE_OPEN_FAILURE;
		goto CLEANUP;
	}

	fprintf(filePtr, "cd %s\n", parentDirPath);
	fprintf(filePtr, "%s \"%s\" %s %s %s\n", FV_CALL_COMMAND, zipExecutablePref, "-r", dirName, dirName); 
	fclose(filePtr);

	// Build array of arguments
	args[0] = commandFilePath;
	args[1] = NULL;

	ifail = FV_execute_batch_file(args[0], 2, args, TRUE, &processReturnCode);
	if ((ifail != ITK_ok) || (processReturnCode != 0)) goto CLEANUP;

	// Import the zip file.
	zipFilePath = MEM_alloc(sizeof(char)*(tc_strlen(parentDirPath)+tc_strlen(dirName)+11)); 
	sprintf(zipFilePath, "%s%s%s.zip", parentDirPath, FV_FILEPATH_DELIMITER, dirName);

	CLEANUP(IMF_import_file(zipFilePath, "", SS_BINARY, &zipFileTag, &zipFileDescriptor))

	FV_DEBUG_TXT(("In %s, Imported zip file %s\n", function_name, zipFilePath))

	CLEANUP(AOM_save(zipFileTag))
	CLEANUP(AOM_unlock(zipFileTag))

	// Create a Zip dataset.
	CLEANUP(FV_strdup(dirName, &zipDatasetName))

	if (tc_strlen(zipDatasetName) > FV_DATASET_NAME_LEN) zipDatasetName[FV_DATASET_NAME_LEN] = '\0';

	CLEANUP(FV_create_and_save_dataset(ZipTYPE, zipDatasetName, "Zipped GDX Report",zipDatasetName, ZIPFILEREF, UnZipTOOL, zipDatasetTag)) 

	FV_DEBUG_TXT(("In %s, Created dataset %s\n", function_name, zipDatasetName))

	// Lock the dataset so we can modify it.
	CLEANUP(AOM_refresh(*zipDatasetTag, TRUE))

	// Add zip file to dataset as a named reference.
	CLEANUP(AE_add_dataset_named_ref(*zipDatasetTag, ZIPFILEREF, AE_PART_OF, zipFileTag))

	FV_DEBUG_TXT(("In %s, Added zip file %s.zip to dataset %s\n", function_name, dirName, zipDatasetName))

	CLEANUP(AOM_save(*zipDatasetTag))
	CLEANUP(AOM_unlock(*zipDatasetTag))

	/* FV_ZipSkipCleanup preference is used for debugging only.
	When set to TRUE, the zip directory will NOT be deleted.
	In production, this preference should not be defined.*/
	if (!FV_ask_preference_is_true(FV_ZipSkipCleanupPREF, TC_preference_site))
	{
		if ((commandFilePath != NULL) && (tc_strlen(commandFilePath) > 0))
			FV_delete_file(commandFilePath);
	}
	FV_DEBUG_TXT(("Exiting: %s\n", function_name))

CLEANUP: 
	FVE_FREE(dirPath)
	FVE_FREE(zipDatasetName)
	FVE_FREE(zipFilePath)
	FVE_FREE(commandFilePath)
	FVE_FREE(zipExecutablePref)
	FVE_FREE(zipCommandArgsPref)
	FVE_FREE(currentDirectory)
	return ifail;
}


int FV_execute_batch_file(const char *processFullPath, int argCnt, char *args[],
	logical setExecPriv, int *processReturnCode)
{
	int     ifail           = ITK_ok;
	char*   function_name   = "FV_execute_batch_file";

	///////////////////////////////
	// WINDOWS CODE
	///////////////////////////////
#if defined(WNT)

	int    timeOut     = 0;
	int    totArgSize  = 0;
	int    i           = 0;
	char*  timeOutPref = NULL;
	char*  commandLine = NULL;
	char*  pszSysCommandAndDirFullPath   = NULL;
	DWORD                 dwExitCode = 0;
	STARTUPINFO           startupInfo; 
	PROCESS_INFORMATION   processInfo;

	*processReturnCode = 0;

	if (processFullPath == NULL)
		CLEANUP(FV_handle_missing_arg_error(function_name, "processFullPath")) 

		totArgSize = tc_strlen(processFullPath);

	// args[0] is executable name and args[argCnt-1] is NULL.
	for (i=1; i<(argCnt-1); i++)
		totArgSize += tc_strlen(args[i]);

	FV_DEBUG_TXT(("In %s, totArgSize = %d\n", function_name, totArgSize))

		CLEANUP(FV_strdup_plus(processFullPath, totArgSize+argCnt+10, &commandLine))

		for (i=1; i<(argCnt-1); i++)
		{
			tc_strcat(commandLine, " ");
			tc_strcat(commandLine, args[i]);
		}

		FV_DEBUG_TXT(("In %s, commandLine = %s\n", function_name, commandLine))

			// Get optional ProcessTimeOut preference in seconds.
			CLEANUP(FV_ask_preference_value(FV_ProcessTimeOutPREF, TC_preference_site, FV_NOT_REQUIRED, &timeOutPref))

			if ((timeOutPref != NULL) && (tc_strlen(timeOutPref) > 0))
				timeOut = atoi(timeOutPref) * 1000;

		FV_DEBUG_TXT(("In %s, timeOut = %d\n", function_name, timeOut))

			ZeroMemory(&startupInfo, sizeof(startupInfo));  
		startupInfo.cb = sizeof(startupInfo);           

		ZeroMemory(&processInfo, sizeof(processInfo));

		CLEANUP(FV_strdup("cmd.exe ", &pszSysCommandAndDirFullPath))
		CLEANUP(FV_strcat(&pszSysCommandAndDirFullPath, "call "))
		CLEANUP(FV_strcat(&pszSysCommandAndDirFullPath, "/c "))
		CLEANUP(FV_strcat(&pszSysCommandAndDirFullPath, commandLine))
		system(pszSysCommandAndDirFullPath);

		// Wait until child process exits.
		if (timeOut > 0)
			WaitForSingleObject(processInfo.hProcess, timeOut);
		else
			WaitForSingleObject(processInfo.hProcess, INFINITE);

		// Check exit code
		GetExitCodeProcess(processInfo.hProcess, &dwExitCode);

		// If process not finished, then force it to terminate.
		if (dwExitCode == STILL_ACTIVE)
		{
			TerminateProcess(processInfo.hProcess, 0);
			ifail = FV_FORCED_PROCESS_TERMINATION;
		}

		// Close process and thread handles. 
		CloseHandle(processInfo.hProcess);
		CloseHandle(processInfo.hThread);

CLEANUP:
		//FVE_FREE(commandLine)
		FVE_FREE(pszSysCommandAndDirFullPath)

			if ((ifail != ITK_ok) || (*processReturnCode != 0))
				TC_write_syslog("In %s, %s failed, ifail = %d, processReturnCode = %d\n",
				function_name, processFullPath, ifail, *processReturnCode);

		return ifail;    

		///////////////////////////////
		// UNIX CODE
		///////////////////////////////
#else
	pid_t pid;
	int   pathLen = 0;
	int   retcode = 0;

	*processReturnCode = 0;

	if (processFullPath == NULL)
		goto UNIX_CLEANUP;

	// If caller requests, set executable permission
	// before running the process. This is mainly to
	// support our ad hoc command files.
	if (setExecPriv)
		retcode = chmod(processFullPath, S_IRWXU | S_IRWXG | S_IRWXO);

	pathLen = tc_strlen(processFullPath);

	// If executable is a shell command file, then just use the 
	// system command to run it.
	if (tc_strcmp(".sh", processFullPath+(pathLen-3)) == 0)
	{
		system(processFullPath);
		goto UNIX_CLEANUP;
	}

	// Spawn a child to run the program.
	pid = fork();

	if (pid == -1)
	{
		ifail = FV_FORK_FAILED;
		goto UNIX_CLEANUP;
	}

	// If in child process...
	if (pid == 0)
	{ 
		execv(processFullPath, args);

		// Code reached only if process fails.
		ifail = FV_PROCESS_FAILED;
		goto UNIX_CLEANUP;
	}
	// If in parent process...
	else
	{
		// Wait for child to exit.
		waitpid(pid,0,0);
	}

UNIX_CLEANUP:
	if ((ifail != ITK_ok) || (*processReturnCode != 0))
		TC_write_syslog("In %s, %s failed, ifail = %d, processReturnCode = %d\n",
		function_name, processFullPath, ifail, *processReturnCode);

	return ifail;
#endif
}

int FV_get_export_folder_tag(tag_t* expFolderTag)
{
	int      ifail                       = ITK_ok;
	int      stringCnt                   = 0;
	int      objFound                    = 0;
	int      num_contents                = 0;
	int      contentIndx                 = 0;
	tag_t*   content_tags                = NULL;
	tag_t*   gmrdbFolderObjs             = NULL;
	char*    function_name               = "FV_get_export_folder_tag";
	char*    gmrdbFolderSearchAttrs[1]   = {object_namePROP};
	char*    folder                      = NULL;
	char**   gmrdbFolderSearchValues     = NULL;    
	char*    user_name_string            = NULL;
	tag_t    owning_user                 = NULLTAG;
	logical  verdict_Read_folder         = false;

	*expFolderTag = NULLTAG;    

	FV_DEBUG_TXT(("Entering: %s\n", function_name))

		CLEANUP(POM_get_user(&user_name_string, &owning_user))

		// search for parent GMRDB Home Folder
		CLEANUP(FV_copy_string_to_array(&stringCnt, &gmrdbFolderSearchValues, FV_GMRDB_HOME_FOLDER))
		CLEANUP(FV_search_objects_by_attrs(FV9GMRDBFolderTYPE,1,gmrdbFolderSearchAttrs,gmrdbFolderSearchValues,&objFound,&gmrdbFolderObjs))
		if(objFound == 1 )
		{   
			if(gmrdbFolderObjs[0] != NULLTAG)
			{
				CLEANUP(AOM_ask_value_tags(gmrdbFolderObjs[0], CONTENTS_ATTR_NAME, &num_contents, &content_tags))
					// Find Export GMRDB Folder to paste object
					for( contentIndx = 0; contentIndx < num_contents; contentIndx++)
					{
						CLEANUP( AM_check_users_privilege (owning_user, content_tags[contentIndx], "READ", &verdict_Read_folder))

							if (verdict_Read_folder == false ) continue; //skip if dont have access to Administrator field.

						CLEANUP(AOM_ask_name(content_tags[contentIndx], &folder))
							if(tc_strcmp(folder, "Export") == 0)
							{
								*expFolderTag = content_tags[contentIndx];
							}
							FVE_FREE(folder)
					}
			}
		}
		FV_DEBUG_TXT(("Exiting: %s\n", function_name))

CLEANUP:
		FVE_FREE(gmrdbFolderSearchValues)
			FVE_FREE(gmrdbFolderObjs)    
			return ifail;
}

int FV_export_named_ref(tag_t tdataset, char *sNamedRefName,char *sExportDir, logical *expFile)
{
	int   ifail                                    = ITK_ok;
	char* function_name                            = "FV_export_named_ref"; 
	char  sOrigFilename[IMF_filename_size_c + 1]   = {'\0'};
	tag_t refObjTag                                = NULLTAG ;

	AE_reference_type_t refType ;

	FV_DEBUG_TXT(("Entering: %s\n", function_name))

		// To get reference object
		CLEANUP(AE_ask_dataset_named_ref(tdataset,sNamedRefName,&refType,&refObjTag))       

		if(refObjTag == NULLTAG) return EXIT_FAILURE;

	// To get reference object original name
	CLEANUP(IMF_ask_original_file_name(refObjTag, sOrigFilename))

		if(tc_strcmp(sOrigFilename,"") !=0)
		{
			FV_strcat(&sExportDir,FILEPATH_DELIMITER);
			FV_strcat(&sExportDir,sOrigFilename);

			ifail = IMF_export_file( refObjTag,sExportDir);

			if(ifail != ITK_ok)
			{
				*expFile = FALSE;       
			}
			else
			{
				*expFile = TRUE;
			}
		}
		else
		{
			FV_DEBUG_TXT(("Invalid file name %s\n", function_name))
				goto CLEANUP;
		}
		FV_DEBUG_TXT(("Exiting: %s\n", function_name));

CLEANUP:    
		return ifail;
}
