//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6Stock_custom_save
 *
 */
#include <O6TaneCustomLibrary/O6Stock_custom_save.hxx>
#include <O6TaneCustomLibrary/method.hxx>

int O6Stock_custom_save( METHOD_message_t * /*msg*/, va_list args )
{
	int  irc = ITK_ok, m=0, m1=0/*, customization_exit=ITK_serious_error*/;
	char prop_name[133], msg_name[133], action_opt[33];
	char *objectformsg = (char*)NULL;

	tag_t saved_object;

	*prop_name = *msg_name = *action_opt = '\0';
	saved_object = NULL_TAG;

	char	*sAttrValue = (char*)NULL;

	saved_object = ( tag_t ) va_arg ( args, tag_t );

	irc = ITK_CALL ( AOM_ask_value_string ( saved_object, CURR_OBJ_STR, &sAttrValue ) );

	MEM_free ( sAttrValue );

	if ( saved_object != NULL_TAG )
	{
		logical to_purge = FALSE;

		irc = ITK_CALL ( AOM_ask_value_string ( saved_object, CURR_OBJ_STR, &objectformsg ) );
		irc = ITK_CALL ( AOM_ask_value_logical ( saved_object, PURGE, &to_purge ) );

		if ( ! to_purge )
		{
			logical do_save = FALSE, special_case = FALSE;
			{
			  char	*sAttrValue = ( char* )NULL, *sAttrUOMValue = ( char* )NULL,*sAttrValue_ori = ( char* )NULL;

			  tag_t tg_UOMValue = NULLTAG;

			  irc = ITK_CALL ( AOM_ask_value_string ( saved_object, TRG_SLAVE_ATT, &sAttrValue_ori ) );
			  irc = ITK_CALL ( AOM_ask_value_string ( saved_object, TRG_MASTER_ATT, &sAttrValue ) );
			  if ( strlen ( sAttrValue ) != 0)
			  {
				  tag_t tg_class=NULLTAG,tg_attribut=NULLTAG,enqid=NULLTAG;

				  int objects_count=0;

				  tag_t *p_tg_objects;

				  irc = ITK_CALL(POM_class_id_of_class ( Q_CLS, &tg_class ) );
				  irc = ITK_CALL(POM_attr_id_of_attr ( Q_CLS_ATT, Q_CLS, &tg_attribut ) );
				  irc = ITK_CALL(POM_create_enquiry_on_string ( tg_class, tg_attribut, POM_is_equal_to, &sAttrValue, &enqid ) );
				  irc = ITK_CALL(POM_execute_enquiry ( enqid, &objects_count, &p_tg_objects ) );
				  irc = ITK_CALL(POM_delete_enquiries ( 1, &enqid ) );

				  MEM_free (sAttrValue);

				  if ( objects_count == 1 )
				  {
					  irc = ITK_CALL ( AOM_ask_value_string ( p_tg_objects[0], RSLT_SLAVE_ATT, &sAttrValue ) );
					  irc = ITK_CALL ( AOM_ask_value_tag ( p_tg_objects[0], "uom_tag", &tg_UOMValue ) );

					  if ( tg_UOMValue != NULLTAG)
					  {
						irc = ITK_CALL ( AOM_ask_value_string ( tg_UOMValue, "symbol", &sAttrUOMValue ) );
					  }
					  else
					  {
					  }
					  if ( strcmp ( sAttrValue, sAttrValue_ori ) != 0 )
					  {
						  m1=919105;
						  do_save=TRUE;
					  }
					  else
					  {
						  MEM_free(sAttrValue);

						  if ( tg_UOMValue != NULLTAG )
						  {
							  MEM_free(sAttrUOMValue);
						  }
					  }
					  MEM_free(sAttrValue_ori);
				  }
				  else
				  {
					  if ( strcmp ( EMPTY_VALUE, sAttrValue_ori ) != 0 )
					  {
						  m1=919106;
						  do_save=TRUE;
						  special_case=TRUE;
					  }
				  }
			  }
			  else
			  {
				  if ( strcmp ( EMPTY_VALUE, sAttrValue_ori ) != 0 )
				  {
					do_save=TRUE;
					special_case=TRUE;
				  }
			  }
			  if ( do_save )
			  {
				  irc = ITK_CALL ( AOM_refresh ( saved_object, TRUE ) );

				  if ( special_case )
				  {
					  irc = ITK_CALL(AOM_set_value_string(saved_object, TRG_SLAVE_ATT, EMPTY_VALUE));
					  irc = ITK_CALL(AOM_set_value_string(saved_object, TRG_SLAVE_ATT_UOM, EMPTY_VALUE));
				  }
				  else
				  {
					  irc = ITK_CALL(AOM_set_value_string(saved_object, TRG_SLAVE_ATT, sAttrValue));

					  if ( tg_UOMValue != NULLTAG )
					  {
						  irc = ITK_CALL(AOM_set_value_string(saved_object, TRG_SLAVE_ATT_UOM, sAttrUOMValue));
					  }
					  else
					  {
						  irc = ITK_CALL(AOM_set_value_string(saved_object, TRG_SLAVE_ATT_UOM, EMPTY_VALUE));
					  }

					  MEM_free ( sAttrValue );

					  if ( tg_UOMValue != NULLTAG )
					  {
						  MEM_free ( sAttrUOMValue );
					  }
				  }
				  irc = ITK_CALL(AOM_save_without_extensions(saved_object));
				  ITK_CALL(AOM_refresh(saved_object, FALSE));
		      }
		  }

		  do_save=FALSE;

		  double dbl_mvt=0.0,dbl_actual=0.0,mvt_result=0.0;

		  irc = ITK_CALL ( AOM_ask_value_double ( saved_object, MVT_ATT, &dbl_mvt ) );
		  irc = ITK_CALL ( AOM_ask_value_double ( saved_object, QTY_ATT, &dbl_actual ) );

		  if ( dbl_actual != ( dbl_actual + dbl_mvt ) )
		  {
			  char* TRG_MASTER_ATTValue = ( char* ) NULL;

			  irc = ITK_CALL ( AOM_ask_value_string ( saved_object, TRG_MASTER_ATT, &TRG_MASTER_ATTValue ) );

			  if ( strlen( TRG_MASTER_ATTValue ) != 0 )
			  {
				  MEM_free ( TRG_MASTER_ATTValue );
			  }
			  else
			  {
				  int errorCode = 0;
				  errorCode = 919102;
				  MEM_free ( TRG_MASTER_ATTValue );
				  irc = ITK_CALL ( EMH_store_error_s1 ( EMH_severity_error, 919102, objectformsg ) );
				  MEM_free ( objectformsg );
				  return errorCode;
			  }

			  mvt_result = dbl_actual + dbl_mvt;

			  if ( mvt_result > 0.0)
			  {
				  m = 919103;
				  do_save=TRUE;
			  }
			  else if ( mvt_result < 0.0 )
			  {
				  int errorCode = 0;
				  errorCode = 919101;

				  irc = ITK_CALL ( EMH_store_error_s1 ( EMH_severity_error, 919101, objectformsg ) );
				  MEM_free ( objectformsg );
				  return errorCode;
			  }
			  else
			  {
				  m = 919104;
				  do_save = TRUE;
			  }
		  }
		  if ( do_save )
		  {
			  irc = ITK_CALL ( AOM_refresh ( saved_object, TRUE ) );
			  irc = ITK_CALL ( AOM_set_value_double ( saved_object, QTY_ATT, mvt_result ) );
			  irc = ITK_CALL ( AOM_set_value_double ( saved_object, MVT_ATT, 0.0 ) );
			  irc = ITK_CALL ( AOM_set_value_int ( saved_object, CMP_CDE,100 ) );
			  irc = ITK_CALL ( AOM_save_without_extensions( saved_object ) );
			  ITK_CALL ( AOM_refresh ( saved_object, FALSE ) );
			  {
				  int cnt=0;
				  tag_t *wrhs,rel2wrhs=NULLTAG;

				  irc = ITK_CALL ( GRM_find_relation_type ( GOODSINWAREHOUSE, &rel2wrhs ) );
				  irc = ITK_CALL ( GRM_list_primary_objects_only ( saved_object, rel2wrhs, &cnt, &wrhs ) );

				  if ( cnt != 0 )
				  {
					  irc = summarize_stock_level ( wrhs[0] );
				  }
				  if ( cnt > 0 )
				  MEM_free ( wrhs );
			  }
			  if (m1 != 0)
			  {
				  irc = ITK_CALL ( EMH_store_error_s1 ( EMH_severity_information, m1, objectformsg ) );
			  }
			  irc = ITK_CALL ( EMH_store_error_s1 ( EMH_severity_information, m, objectformsg ) );
			  MEM_free ( objectformsg );
			  return m;
	      }
      }
	  else
	  {
		  int count_rels2p=0;
		  GRM_relation_t 	*rels2p;
		  tag_t rel=NULLTAG,rel_p=NULLTAG;

		  irc = ITK_CALL(GRM_find_relation_type (GOODSINWAREHOUSE, &rel));
		  irc = ITK_CALL(GRM_list_primary_objects (saved_object, rel, &count_rels2p, &rels2p));

		  if (count_rels2p==1)
		  {
			  tag_t dummy_rel_tag=NULLTAG;

			  irc = ITK_CALL(GRM_find_relation_type (GOODSPURGEDINWAREHOUSE, &rel_p));
			  irc = ITK_CALL(GRM_create_relation(rels2p[0].primary,saved_object,rel_p,NULLTAG,&dummy_rel_tag));

			  if (irc==ITK_ok)
			  {
				  irc = ITK_CALL(AOM_refresh(dummy_rel_tag, TRUE));
				  irc = ITK_CALL(GRM_save_relation (dummy_rel_tag));
				  irc = ITK_CALL(AOM_refresh(dummy_rel_tag, FALSE));

			  }
			  irc = ITK_CALL(GRM_delete_relation (rels2p[0].the_relation));
			  {
				  irc=summarize_stock_level(rels2p[0].primary);
			  }
			  if (count_rels2p >0 )
			  MEM_free(rels2p);

			  irc = ITK_CALL(EMH_store_error_s1 ( EMH_severity_information, 919108, objectformsg));
			  MEM_free(objectformsg);
			  return 919108;
		  }
		  else
		  {
		      if (count_rels2p >0 )
		      MEM_free(rels2p);

		      int errorCode = 0;

		      errorCode = 919107;

		      irc = ITK_CALL(EMH_store_error_s1 ( EMH_severity_error, 919107, objectformsg));
			  MEM_free(objectformsg);
			  return errorCode;
		  }
	  }
	}
	if (m1 != 0)
	{
		int errorCode = 0;

		errorCode = m1;

		irc = ITK_CALL(EMH_store_error_s1 ( EMH_severity_information, m1, objectformsg));
		MEM_free(objectformsg);

		return errorCode;
	}
	else
	{
		MEM_free(objectformsg);
		return ITK_ok;
	}
}
