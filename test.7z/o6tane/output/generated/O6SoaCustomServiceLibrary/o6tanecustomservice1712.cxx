/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#include <string>
#include <map>

#include <o6tanecustomservice1712.hxx>


#include <teamcenter/soa/internal/server/SdmParser.hxx>
#include <teamcenter/soa/internal/server/SdmStream.hxx>

using namespace O6::Soa::CustomServiceLibrary::_2017_12;

const std::string O6TaneCustomService::XSD_NAMESPACE ="http://o6.com/Schemas/CustomServiceLibrary/2017-12/O6TaneCustomService";







O6TaneCustomService::O6TaneCustomService()
{
}

O6TaneCustomService::~O6TaneCustomService()
{
}

