/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: IM_Auto_CheckIn_as_Infodba.c
    Module  : main

       
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>
===============================================================================
Date               Name                    Description of Change
Aug 2013          Soumalya Sinha             Initial version
===============================================================================*/
#include <time.h>
#include "IM_Auto_CheckIn_as_Infodba.h"
#include <sa/sa.h>
#include <tccore/aom_prop.h>

/*--------------------------Function Prototypes-------------------------------*/


static void print_usage(void);
FILE *logfileptr = NULL;
/*-------------------------------End------------------------------------------*/

extern int ITK_user_main( int argc, char **  argv )
{   
	
    int     ifail                               = ITK_ok;
	int     ItemsRevCnt                         = 0;
	int     loggedin_users_num                  = 0;
	int     foundIdx                            = 0;
	int     ItemsRevIndx                        = 0;
		     
	char    logfilename[255 + 1]                = {""};
	char    checked_out_user[SA_user_size_c+1]  = {""};
	char    curr_role_name[SA_user_size_c+1]    = {""};


	char   *login_group                         = NULL;
    char   *login_user                          = NULL;
    char   *login_password                      = NULL;
    char   *time_stamp                          = NULL;


	
    
	char   *Qry_Name                            = "IM Checked-Out Revisions...";
	
	char   **entryNames                         = NULL;
	char   **entryValues                        = NULL;
	char   **loggedin_users                     = NULL;

	tag_t   query_tag                           = NULLTAG;
	tag_t   reservation_tag                     = NULLTAG;
	tag_t   checked_out_user_tag                = NULLTAG;
	tag_t  *ItemRevTags                         = NULL;
	tag_t   curr_role_tag                       = NULLTAG;

	logical isDBA                               = false;


    //Append the log file name with the date and time stamp 
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"IM_Auto_CheckIn_as_Infodba_%s.log",time_stamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);
        
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
        fprintf(logfileptr,"argc: %d\n", argc);
        FVE_FREE(time_stamp)
    }

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }    
    
    login_user     = ITK_ask_cli_argument("-u=");
    login_password = ITK_ask_cli_argument("-p=");
    login_group    = ITK_ask_cli_argument("-g=");
        
    ITK_initialize_text_services (0);
   // CLEANUP(ITK_init_module (login_user, login_password, login_group))

	/* Logging into Teamcenter */
	if ( login_user != NULL && strlen(login_user)!=0  &&  login_password != NULL && strlen(login_password)!=0 &&  login_group != NULL && strlen(login_group)!=0)
	{
		ifail = ITK_init_module (login_user, login_password, login_group);

		if(ifail != ITK_ok)
		{
			printf ("ERROR: Unable to login\n");
			fprintf(logfileptr,"Login with uid: %s, group:%s is unsuccessful\n\n", login_user, login_group);    
			fclose( logfileptr );
			print_usage();
			exit(0);
		}
		else
		{
			fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n\n", login_user, login_group);   
		}

	}
	else
	{
		ifail = ITK_auto_login ();
		if(ifail != ITK_ok)
		{
			printf ("ERROR: Unable to login\n");
			fprintf(logfileptr,"Auto Login unsuccessful\n");
			fclose( logfileptr );
			exit(0);
		}
		else 
		{
			printf ("Auto Login successful\n");
			fprintf(logfileptr,"Auto Login successful\n");

		}


	}
	if(ifail==ITK_ok)
	{
		CLEANUP(SA_ask_current_role(&curr_role_tag));
		CLEANUP(SA_ask_role_name  (curr_role_tag,curr_role_name));
		printf ("current role name %s \n",curr_role_name);

		if(tc_strcmp(curr_role_name,"DBA")==0)
		{
			printf ("current role name %s \n",curr_role_name);
			isDBA=true;
		}

	}


	if(isDBA) {
		/* Find query tag */   
		CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
			//FVE_FREE(Qry_Name)

	  CLEANUP(QRY_execute ( query_tag, 0, entryNames, entryValues, &ItemsRevCnt, &ItemRevTags))
      fprintf(logfileptr,"Number of issues in checked out state are : %d \n",ItemsRevCnt);
	  if(ItemsRevCnt>0)
	  {

         ifail = system("clearlocks -verbose");

         CLEANUP(FV_IM_find_all_loggedin_users(&loggedin_users_num,&loggedin_users))
		
	     for(ItemsRevIndx = 0;ItemsRevIndx<ItemsRevCnt;ItemsRevIndx++)
		 {	 
	         CLEANUP ( RES_ask_reservation_object (ItemRevTags[ItemsRevIndx], &reservation_tag))
             //double check if object is checked out?
	         if(reservation_tag != NULLTAG)
             {
                //Load the object
                // CLEANUP(AOM_load(reservation_tag))
                //Get the checked out user
                //CLEANUP(RES_ask_user ( reservation_tag, &checked_out_user_tag ) )
				
				CLEANUP(AOM_ask_value_tag(ItemRevTags[ItemsRevIndx],checked_out_userPROP,&checked_out_user_tag))
				CLEANUP(SA_ask_user_identifier(checked_out_user_tag,checked_out_user))
               
                 fprintf(logfileptr,"checked out user :%s \n",checked_out_user);
				//Unload the reservation tag
                //CLEANUP(AOM_unload(reservation_tag))

				foundIdx = FV_find_string_in_array(loggedin_users_num, loggedin_users, checked_out_user);
                if(foundIdx < 0)
				{
					 char   *object_string                       = NULL;
					 fprintf(logfileptr,"checked out user is : %s not logged in so checking in issue \n",checked_out_user);
					 //CLEANUP(RES_cancel_checkout(ItemRevTags[ItemsRevIndx],false))
                     CLEANUP(AOM_ask_value_string(ItemRevTags[ItemsRevIndx],"object_string",&object_string))
					 ifail = RES_checkin(ItemRevTags[ItemsRevIndx]);
					 if(ifail!=ITK_ok && object_string != NULL)
					 {
                         fprintf(logfileptr,"checkin for issue object string : %s FAILED  for user :%s \n",object_string,checked_out_user);
						 continue;
					 }
								else if(object_string != NULL)
								{
									fprintf(logfileptr,"checkin for issue object string : %s SUCCESS  for user :%s \n",object_string,checked_out_user);
									continue;
								}
								FVE_FREE( object_string)
             }
		 }
     }


	  }
	
	// ifail = FV_Checkin_all_checkedout_objects();

    ITK_exit_module( true );
    printf("Utility completed successfully.\n\n");
    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
    FVE_FREE(time_stamp)    
	}
	else
	{
		ITK_exit_module( true );
		printf("Role should be DBA to run the utility .\n\n");
		fprintf(logfileptr,"role:%s , should be DBA to run the utility \n\n",curr_role_name);    
		get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
		fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
		FVE_FREE(time_stamp)    

	}
    if (logfileptr ) fclose( logfileptr);
    
CLEANUP:
   
    

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


int FV_IM_find_all_loggedin_users(int* loggedin_users_num,char*** loggedin_users)
{
    int     ifail                           = ITK_ok;
	int     loadedindex                     = 0;
    
	int  n_loaded                           = 0 ;
    char *user_name                         = NULL;

    tag_t pom_session_c                     = NULLTAG;
    tag_t user_name_a                       = NULLTAG;

    tag_t *  loaded                         = NULL;
	logical in                              = false;
    logical ie                              = false;
	logical exists                         = false;

   CLEANUP(POM_class_id_of_class ( "POM_session",  &pom_session_c))
   
   CLEANUP(POM_load_class_extent( "POM_session", &n_loaded, &loaded, POM_no_lock ))
     
   for (loadedindex = 0; loadedindex < n_loaded; ++loadedindex)
   {
		 
      CLEANUP( POM_instance_exists( loaded[loadedindex], &exists ))
      if ( exists )
      {
         CLEANUP(POM_attr_id_of_attr("user_name",  "pom_session", &user_name_a))
         CLEANUP(POM_ask_attr_string (loaded[loadedindex], user_name_a, &user_name, &in, &ie))
		  
		 CLEANUP(FV_add_unique_string_pointer_to_array(loggedin_users_num,loggedin_users,user_name))
		 //FVE_FREE(user_name);
		            
      }
  
   }


     CLEANUP(POM_unload_instances( n_loaded, loaded ))
    CLEANUP:

	 return ifail;

}




/*--------------------------------------------------------------------------*/

static void print_usage(void)
{
        printf("\n**********************************************************************************************\n");
        printf("Usage: IM_Auto_CheckIn_as_Infodba(checkin all the checked out object present in DB by the logged out users as Infodba)<args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<login user id>/Infodba Expected\Optional other User \n");
        printf(" -p=<login password>/Infodba Expected\Optional other user's Password \n");
        printf(" -g=<login group>/dba Expected\Optional other user's Group\n");
        printf("\n");
        printf("***********************************************************************************************\n\n");        
}

