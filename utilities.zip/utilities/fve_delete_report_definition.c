
/*===============================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
=================================================================================
File description:

    Filename: FVE_delete_xsl.c
    Module  : main

        
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>.

===============================================================================
Date               Name                    Description of Change
december,2011      Ram Sisodia        Utility to delete the existing report definition.
===============================================================================*/

#include <sys/stat.h>
#include "fve_delete_report_definition.h"

/*--------------------------Function Prototypes-------------------------------*/


static void print_usage(void);
FILE *logfileptr = NULL;

/*-------------------------------End------------------------------------------*/

extern int ITK_user_main(int retCount, char **retValue)
{

    FILE *fileptr                   =      NULL;

    int line_count                  =      0;
	int ifail                       =      ITK_ok;
	int len                         =      0;
	int rep_cnt                     =      0;
	int dataset_cnt                 =      0;
	int array_cnt					=	   0;
	int  count					    =      0; 
	int  nFound						=      0;
	int  iRelations                 =      0;
	int num							=	   0;
	int rel_cnt						=	   0;

	logical is_null                 =      FALSE;
	


    char line_in[555 + 1]           =      "";
	const char * filename           =      NULL;
	const char * mode               =      "r+";
    char * ptr						=      0;
    char logfilename[255 + 1]       =      "";
    char line_temp[555 + 1]         =      "";
	char *  login_group             =      NULL;
    char *  login_user              =      NULL;
    char * login_password           =      NULL;
	char * login_help				=	   NULL;
	char * time_stamp               =      NULL;
	char ** report_name_array		=      NULL;
	char ** report_id_array			=      NULL;
	char *  datasetname			    =      NULL; 
	


	tag_t *  transfer_mode_tags		=      NULL;
	tag_t *  report_definition_tags =      NULL;
	tag_t * dataset_tags		    =	   NULL;
	tag_t * data_set_tags		    =	   NULL;
	GRM_relation_t * primary_list   =      NULL;
	tag_t * dataset_name			=      NULL; 


	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"FVE_delete_xslt%s.log",time_stamp);


    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
		FVE_FREE(time_stamp)
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);



	if(logfileptr)
    {
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
		FVE_FREE(time_stamp)
    }

    //Get the required argument.
	login_help = ITK_ask_cli_argument("-h");
	login_user = ITK_ask_cli_argument("-u=");
	login_password = ITK_ask_cli_argument("-p=");
	login_group = ITK_ask_cli_argument("-g=");
    ITK_initialize_text_services (0);

	// Logging into Teamcenter
   	ITK(ITK_init_module (login_user, login_password, login_group))

	
	if(login_help)
	{
	    print_usage();
        exit(0);
	}
	if(ifail != ITK_ok)
	{
		fprintf(logfileptr,"Login with user id: %s, group:%s is unsuccessful\n", login_user, login_group);
		fclose( logfileptr );
        print_usage();
        exit(0);
    }
	else
		fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n\n\n\n", login_user, login_group);

		//Read file.
	    filename = ITK_ask_cli_argument("-file=");
		if(filename == NULL)
		{
			 print_usage();
             exit(0);
		}
	    printf("filename is %s\n", filename);
		//Open file.
        fileptr = fopen (filename, mode);

		if ( fileptr != NULL )
		{
			line_count = 0;
			while ( fgets ( line_in, 512, fileptr ) != NULL ) /* read a line */
			{
				line_count++;		
				len = (int) tc_strlen(line_in);
				if (len > 0 && line_in[len-1] == '\n')
					line_in[len-1] = '\0'; 
				if ( tc_strlen(  line_in ) == 0 )
					continue;

				tc_strcpy( line_temp, line_in);
			    array_cnt ++;
				ptr = tc_strtok(line_temp, "|");
				FVE_get_value_and_store(ptr, array_cnt, &report_name_array, &is_null);

			    ptr = tc_strtok(NULL, "|");
			    FVE_get_value_and_store(ptr, array_cnt, &report_id_array, &is_null);
			}
		}
				
	for(rep_cnt=0;rep_cnt<array_cnt; rep_cnt++)
	{
		//Get the report definition.
		ITK(CRF_get_report_definitions (report_id_array[rep_cnt],  
									  report_name_array[rep_cnt],  
									  NULL,  
									  "Teamcenter",  
									  0,  
									  0,  
									  NULL,  
									  &count,  
									  &report_definition_tags))
		
	    fprintf(logfileptr,"\n\n**********Processing for report: %s starts.**********\n", report_name_array[rep_cnt]);

		if(report_definition_tags == NULL)
		{ 
			fprintf(logfileptr,"Error:Definition of  %s doesn't exist. \n", report_name_array[rep_cnt]);
			fprintf(logfileptr,"**********Processing for report: %s ends.**********\n\n\n\n\n", report_name_array[rep_cnt]);
			ifail = ITK_ok;
			continue;
		}

		ITK(AOM_ask_value_tags(report_definition_tags[0],"rd_style_sheets",&num,&dataset_tags)) 
		if(dataset_tags == NULL)
		{ 
			fprintf(logfileptr,"Error:There is no dataset attached with this %s. \n",report_name_array[rep_cnt]);
			fprintf(logfileptr,"**********Processing for report: %s ends.**********\n\n\n\n\n", report_name_array[rep_cnt]);
			ifail = ITK_ok;
			continue;
		}
		ITK(AOM_ask_value_string(dataset_tags[0],"object_name",&datasetname))
		//Get all the data set tags.
		ITK(AE_find_all_datasets(datasetname, &nFound, &data_set_tags))
		//Delete the report definition
		ITK(POM_delete_instances(1,report_definition_tags))
		if(ifail != ITK_ok)
		{
			fprintf(logfileptr,"Error:unable to delete the definition of %s \n",report_name_array[rep_cnt]);
			ifail = ITK_ok;
		}
		else
		fprintf(logfileptr,"%s definition deleted successfully.\n", report_name_array[rep_cnt]);
		for(dataset_cnt=0;dataset_cnt<nFound;dataset_cnt++)
		{
			ITK(GRM_list_primary_objects(data_set_tags[dataset_cnt], NULLTAG, &iRelations, &primary_list))
			for(rel_cnt=0;rel_cnt<iRelations;rel_cnt++)
			{
				ITK(AOM_refresh(primary_list[dataset_cnt].the_relation, TRUE))
				if(ifail != ITK_ok)
				{
					printf("Error:Unable to refresh relation\n");
						   ifail = ITK_ok;
						   continue;
				}
				ITK(GRM_delete_relation(primary_list[dataset_cnt].the_relation)) 
				if(ifail != ITK_ok)
				{
					fprintf(logfileptr,"Error:unable to delete the relation %s \n",report_name_array[rep_cnt]);
					ifail = ITK_ok;
				}
			}
			FVE_FREE(primary_list)
		}

		
		if(nFound)
		{
			ITK(AOM_lock_for_delete(data_set_tags[0]))
			//Delete the all dataset tag revision.
			ITK(AE_delete_all_dataset_revs(data_set_tags[0]))
			if(ifail != ITK_ok)
			{
				fprintf(logfileptr,"Error:unable to delete dataset %s \n",datasetname);
				fprintf(logfileptr,"Error:ifail value is %d \n",ifail);
				fprintf(logfileptr,"**********Processing for report: %s ends.**********\n\n\n\n\n", report_name_array[rep_cnt]);
				ifail = ITK_ok;
				continue;
			}
			else
			fprintf(logfileptr,"%s dataset deleted successfully.\n", report_name_array[rep_cnt]);

		}

		 FVE_FREE(datasetname)
		 FVE_FREE(data_set_tags)
	     FVE_FREE(dataset_tags)
		 fprintf(logfileptr,"**********Processing for report: %s ends.**********\n\n\n\n\n", report_name_array[rep_cnt]);
	}   

	    FVE_FREE(report_name_array)
		FVE_FREE(report_id_array)

    ITK_exit_module( true );
	fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
	FVE_FREE(time_stamp)

    if (logfileptr ) fclose( logfileptr);
    if (fileptr ) fclose( fileptr);

    return ifail;
}

static void print_usage(void)
{	
	    printf(" This program is intended to delete the existing report definition and dataset\n\n");
        printf("\n**********************************************************************************\n");
        printf("Usage: fve_delete_report_definition <args>\n\n");
        printf(" Where args include the following:\n\n");
		printf(" -u=<login user id>\n");
		printf(" -p=<login password>\n");
		printf(" -g=<login group>\n");
        printf(" -file=<filename>  input file to delete the existing report definition\n\n");
        printf("Each record in the file contains the following in the order specified:\n");
        printf("Report name|Report id\n\n");
        printf("\n");
        printf("**********************************************************************************\n\n");
}

void FVE_get_value_and_store(char * init_value, int cnt, char *** str_array, logical * is_value_null)
{
	(*str_array) = (char **) MEM_realloc ((*str_array), (int) cnt * sizeof(char *));

	if(init_value != NULL)
	{
		(*str_array)[cnt -1] = (char *) MEM_alloc ((int) (tc_strlen(init_value) + 1) * sizeof(char));
		tc_strcpy((*str_array)[cnt -1], init_value);
	}
	else
	{
		(*str_array)[cnt -1] = (char *) MEM_alloc ((int) (tc_strlen(" ") + 1) * sizeof(char));
		tc_strcpy((*str_array)[cnt -1], " ");
		(* is_value_null) = TRUE;
	}
}

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fprintf(logfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fflush(logfileptr);
}

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = (byte) newTime->tm_mon;
	currentTime.year = (short) newTime->tm_year + 1900;
	currentTime.day = (byte) newTime->tm_mday;
	currentTime.hour = (byte) newTime->tm_hour;
	currentTime.minute = (byte) newTime->tm_min;
	currentTime.second = (byte) newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}
