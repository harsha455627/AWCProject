/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <o6tanecustomservice1712impl.hxx>
/* TC header files */
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <fclasses/tc_string.h>
#include <tc/preferences.h>
#include <base_utils/Mem.h>
#include <tccore/tctype.h>
#include <property/nr.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <tccore/grm.h>
#include <pom/pom/pom.h>
#include <cfm/cfm.h>
#include <sa/tcfile.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#include <ae/tool.h>
#include <fstream>
#include <ctime>

/* Bom Attributes */
#define bomAttr_bl_occ_o6_percent_theoric "bl_occ_o6_percent_theoric"
#define bomAttr_bl_occ_o6_impurete "bl_occ_o6_impurete"
#define bomAttr_bl_occ_o6_for_QSP "bl_occ_o6_qsp"
#define bomAttr_bl_Item_Id "bl_rev_item_id"

#define PERCENT_TOTAL "o6_total_percent"
#define O6_IMPURETE "o6_impurete"
#define O6_QSP "o6_qsp"
#define O6_PERCENT_THEORIC "o6_percent_theoric"
#define AW0ARCHETYPE "awb0Archetype"
#define TRUE_STRING  "true"
#define FALSE_STRING "false"


static int item_revtag_attribute;
static int bl_occ_o6_for_QSP_attribute;
static int bl_occ_o6_impurete;
static int bl_occ_o6_percent_theoric_attribute;
static int bl_occ_attribute;
static int bl_Item_ID_attribute;


#define SUP_RM_REV "O6_SupRMRevision"
#define GEN_RM_REV "O6_GenRMRevision"
#define RM_BATCH_REV "O6_RMBatchRevision"
#define FLE_BATCH_REV "O6_FleBatchRevision"
#define FLE_REVISION "O6_FleRevision"
#define ING_LIST_REVISION "O6_IngListRevision"

#define MORE_THAN_ONE_TRUE_VALUE_AS_STRING_ERROR ( SEEDS_CUSTOM_ERROR_BASE + 3 )
#define THEORIQUE_VALUE_AS_STRING_ERROR          ( SEEDS_CUSTOM_ERROR_BASE + 4 )
#define IMPURETE_AS_STRING_ERROR                 ( SEEDS_CUSTOM_ERROR_BASE + 5 )

using namespace O6::Soa::CustomServiceLibrary::_2017_12;
using namespace Teamcenter::Soa::Server;
using namespace std;

/**
 * Function    :  initialise_attribute
 * Description :  Initialize BOM attributes.
 * Input       :
 */
static int initialise_attribute (char *name,  int *attribute)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (name, attribute));

    return retcode;
  }

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 * Input       :
 */
static int initialise (void)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (bomAttr_lineItemRevTag, &item_revtag_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_percent_theoric, &bl_occ_o6_percent_theoric_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_for_QSP, &bl_occ_o6_for_QSP_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_impurete, &bl_occ_o6_impurete));
    ITK(initialise_attribute ( bomAttr_realOccurrence, &bl_occ_attribute));
    ITK(initialise_attribute (bomAttr_bl_Item_Id, &bl_Item_ID_attribute));

    return retcode;
  }

/**
 * Function    :  O6_get_number_of_true_BOMLines_and_TheoricValue
 * Description :  Count No of QSP BOMLines which are true and also count No of BOMLines which are false
 * Input       :
 */
int O6_get_number_of_true_BOMLines_and_TheoricValue(int iCnt,tag_t *tpChildren,int OccAttr,int ItemIDAttribute,double *TheoricValue,int *iCounter,logical *lImpurete,char **cpError)
{
	int retcode = ITK_ok;
	int TrueCount = 0;

	char *cpQSPVal = NULL;
	char *cpItemId = NULL;

	tag_t tOccurenceTag = NULLTAG;

	 double dpTheoric = 0.0;
	 double TempValue = 0.0;

	 logical lIsImpurete = false;

	if(iCnt > 0)
	{
		for(int j=0;j<iCnt;j++)
		{
			ITK(BOM_line_ask_attribute_tag(tpChildren[j],OccAttr,&tOccurenceTag));
			ITK ( AOM_ask_value_string ( tOccurenceTag, O6_QSP, &cpQSPVal ) );
			ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &lIsImpurete ) );


			 if (retcode == ITK_ok && cpQSPVal != NULL)
			 {
				if (tc_strcmp(cpQSPVal,TRUE_STRING)==0 && tc_strlen(cpQSPVal) > 0 && lIsImpurete == false)
				 {
					TrueCount++;
					if(TrueCount > 1)
					{
					  BOM_line_ask_attribute_string(tpChildren[j],ItemIDAttribute,&cpItemId);
					  *cpError = (char*)MEM_alloc((tc_strlen(cpItemId)+2)* sizeof(char));
					  tc_strcpy(*cpError,cpItemId);
					  *iCounter = TrueCount;
					  break;
					}
				 }
				 else if(tc_strcmp(cpQSPVal,FALSE_STRING)==0 && tc_strlen(cpQSPVal) > 0 && lIsImpurete == false)
				 {
					ITK(AOM_ask_value_double(tOccurenceTag,O6_PERCENT_THEORIC,&dpTheoric));
					if(dpTheoric > 0)
					{
					  TempValue = TempValue + dpTheoric;
					}
				 }
				 else if(tc_strcmp(cpQSPVal,TRUE_STRING)==0 && tc_strlen(cpQSPVal) > 0 && lIsImpurete == true)
				 {
					 BOM_line_ask_attribute_string(tpChildren[j],ItemIDAttribute,&cpItemId);
					 *cpError = (char*)MEM_alloc((tc_strlen(cpItemId)+2)* sizeof(char));
					 tc_strcpy(*cpError,cpItemId);
					 *lImpurete = lIsImpurete;
					 break;
				 }
			  }
			}
		}
		*TheoricValue = TempValue;

	MEM_free(cpQSPVal);
	MEM_free(cpItemId);

	return retcode;
}

/**
 * Function    :  O6_perform_QSP_calculation
 * Description :  Performs QSP calculation and sets required BOMLine based on value of QSP
 * Input       :
 */
int O6_perform_QSP_calculation(int count,tag_t *tpChildren,int OccAttr,int TheoricAttribute,double *TheoricValue)
{
	int retcode = ITK_ok;
	tag_t tOccurenceTag = NULLTAG;

	char *cpQSPVal = NULL;
	char *Temp = NULL;

	double finalCost = 100.0;

	logical lIsImpurete = false;

	if(count > 0)
	{
	  for(int j=0;j<count;j++)
	  {
		ITK(BOM_line_ask_attribute_tag(tpChildren[j],OccAttr,&tOccurenceTag));
		ITK ( AOM_ask_value_string ( tOccurenceTag, O6_QSP, &cpQSPVal ) );
		ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &lIsImpurete ) );
		if (retcode == ITK_ok && cpQSPVal != NULL && lIsImpurete == false)
		{
			if (tc_strcmp(cpQSPVal,TRUE_STRING)==0 && tc_strlen(cpQSPVal) > 0)
			{
				 finalCost = finalCost - *TheoricValue;
				 char buffer[200];
				 sprintf(buffer,"%lf", finalCost);
				 Temp = (char*)MEM_alloc((tc_strlen(buffer)+1)*sizeof(char));
				 tc_strcpy (Temp,buffer);
				 ITK(BOM_line_set_attribute_string(tpChildren[j],TheoricAttribute,Temp));
			}
		}

	  }
	}
	MEM_free(Temp);
	MEM_free(cpQSPVal);

	return retcode;
}

/**
 * Function    :  O6TaneCustomServiceImpl::calculateQSP
 * Description :  Performs QSP calculation for object type "O6_FleRevision", "O6_FleBatchRevision" and "O6_IngListRevision"
 * Input       :
 */
Teamcenter::Soa::Server::ServiceData O6TaneCustomServiceImpl::calculateQSP ( const BusinessObjectRef<Teamcenter::BOMLine>& obj )
{
  int retcode = ITK_ok;

  ServiceData service_data;

  tag_t tObjecttag = NULLTAG;
  tag_t tWindow = NULLTAG;
  tag_t tTopBOMLine = NULLTAG;
  tag_t *tChildren = NULLTAG;
  tag_t tObj = NULLTAG;

  char *cpObjectTypeName = NULL;
  char *cpErrorStack = NULL;

  int iChildCount = 0;
  int iCounter = 0;

  logical lImpurete = false;

  double TheoricValue = 0.0 ;

  if ( obj.tag() != NULLTAG )
   {

	 ITK(AOM_ask_value_tag(obj.tag(),AW0ARCHETYPE,&tObj));

	 ITK(TCTYPE_ask_object_type(tObj,&tObjecttag));
	 if(retcode == ITK_ok && tObjecttag != NULLTAG)
	 {
	   ITK(TCTYPE_ask_name2(tObjecttag,&cpObjectTypeName));

	   if(retcode == ITK_ok && ((tc_strcmp(cpObjectTypeName,FLE_REVISION) == 0) ||(tc_strcmp(cpObjectTypeName,FLE_BATCH_REV) == 0)||(tc_strcmp(cpObjectTypeName,ING_LIST_REVISION) == 0)))
	   {
		   ITK(initialise());
		   ITK(BOM_create_window(&tWindow));
		   ITK(BOM_set_window_top_line(tWindow,NULLTAG,tObj,NULLTAG,&tTopBOMLine));

		   ITK ( BOM_line_ask_all_child_lines (tTopBOMLine,&iChildCount,&tChildren));
		   if(retcode == ITK_ok && iChildCount > 0)
		   {
			 O6_get_number_of_true_BOMLines_and_TheoricValue(iChildCount,tChildren,bl_occ_attribute,bl_Item_ID_attribute,
					                                           &TheoricValue,&iCounter,&lImpurete,&cpErrorStack);

			 if(lImpurete == true)
			 {
			    char *error = (char*) MEM_alloc(sizeof(char) * (tc_strlen(cpErrorStack) + 1));
			    tc_strcpy(error,cpErrorStack);
				EMH_store_error_s1(EMH_severity_error,IMPURETE_AS_STRING_ERROR,error);
				service_data.addErrorStack();
			    MEM_free(error); error = NULL;
			 }
			 else
			 {
			   if(iCounter > 1)
			  	{
			     // char errorStr1[1000];
			     // sprintf(errorStr1,"%d", iCounter);
			     char *errorStr1 = (char*) MEM_alloc(sizeof(char) * (tc_strlen(cpErrorStack) + 1));
			  	 tc_strcpy(errorStr1,cpErrorStack);
			  	 EMH_store_error_s1(EMH_severity_error,MORE_THAN_ONE_TRUE_VALUE_AS_STRING_ERROR,errorStr1);
			  	 service_data.addErrorStack();
			  	 MEM_free(errorStr1); errorStr1 = NULL;
			  	}
			   else
			   {
				 if(TheoricValue >= 100)
				 {
				   char errorStr2[100];
				   sprintf(errorStr2,"%lf", TheoricValue);
				   EMH_store_error_s1(EMH_severity_error,THEORIQUE_VALUE_AS_STRING_ERROR,errorStr2);
				   service_data.addErrorStack();
				 }
				 else
				 {
                   O6_perform_QSP_calculation(iChildCount,tChildren,bl_occ_attribute,bl_occ_o6_percent_theoric_attribute,&TheoricValue);
				 }
			   }
			 }
		   }
		   ITK(BOM_save_window(tWindow));
		   ITK(BOM_close_window(tWindow));
	   }
	   MEM_free(cpErrorStack);
	   MEM_free(tChildren);
	 }
	 MEM_free(cpObjectTypeName);
   }

		if ( retcode != ITK_ok )
	     {
		   service_data.addErrorStack();
		 }

				return service_data;
}



