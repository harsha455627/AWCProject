/*======================================================================================================================
                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
========================================================================================================================
File description:

    Filename: fv_item_dataset_import_utility.c
    Module  : main

    Used to import/create any type of an item and  associate a dataset with one or more named references.
    Requires a login account specified by -u=<user> -p=<pass> -g=<group>.
	Assumptions:
	1. Run Exe with -u=infodba -p=infodba -g=dba -file=filename
	2. Default delimiter "|" will be considered for parsing csv files.Make sure csv file contains this parameter.
	3. log file will be created with name "fv_item_dataset_import_utility" on time stamp basis where utility is executed.
	
========================================================================================================================
Date               Name                    Description of Change
2016          Pournima Hawaldar            Initial Version.
========================================================================================================================*/
#include <sys/stat.h>
#include "fv_item_dataset_import_utility.h"

/* Property Constant
****************************************************/
#define ItemTYPE					("Item")
#define ItemRevisionTYPE			("ItemRevision")
#define item_idPROP					("item_id")
#define item_revision_idPROP		("item_revision_id")
#define FVRDocumentTYPE				("FVRDocument")
#define FVRDocumentRevisionTYPE     ("FVRDocumentRevision")
#define FVR_DocMaturityPROP			("FVR_DocMaturity")
#define FVR_PercentCompletePROP		("FVR_PercentComplete")
#define FV_DocumentTypePROP			("FV_DocumentType")
#define ip_classificationPROP		("ip_classification")
#define COLUMN_TYPE					("TYPE")
#define COLUMN_Revision_TYPE		("RevisionTYPE")
#define COLUMN_Dataset_TYPE			("DatasetTYPE")
#define COLUMN_Relation_TYPE		("RelationTYPE")
#define COLUMN_Obj_Name				("object_name")
#define COLUMN_Item_ID				("item_id")
#define MAX_LINE_LEN 500
/****************************************************/
void print_usage(void);

FILE *slogfileptr = NULL;
FILE *elogfileptr = NULL;
FILE *summary_file_ptr = NULL;

int typeInx=0;
int revTypeInx=0;
int datasetTypeInx=0;
int relationTypeInx=0;
int objNameInx = 0;
int itemIDInx = 0;

/******************************************************************************
Function     :  ask_populated_datasets
Description  :  Function to find dataset attached to ItemRev 			
input        :  Tag of ItemRevision,relationTypename
Output       :  Datasets count and Tags of datasets
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int ask_populated_datasets(tag_t objectTag,char* relationTypename,int* datasetCnt, tag_t** datasetTags)
{
	int			ifail						=	ITK_ok;
	int         relatedCnt					=	0;
    int         refCnt						=	0;
    int         relIdx						=	0;
    
	char*       function_name				=	"ask_populated_datasets";
    char*       datasetType					=	DatasetTYPE;
	//char*   expandRelTypenames[2] = {IMAN_specificationTYPE, TC_AttachesTYPE};
    tag_t*      secondaryList				=	NULL;

	*datasetCnt = 0;
    *datasetTags = NULL;

	if(relationTypename == NULL)
    {
        goto CLEANUP;
    }

    if (objectTag == NULLTAG)
       CLEANUP(FV_handle_missing_arg_error(function_name, "objectTag"))

    FV_DEBUG_TXT(("Entering %s\n", function_name))
	
    // Get attached datasets
    CLEANUP(FV_expand_one_step(&objectTag, 1, FV_SECONDARY,&relationTypename, 1,
			       &datasetType, 1, &secondaryList, &relatedCnt))
	printf("\n relatedCnt:%d",relatedCnt);
    for (relIdx=0; relIdx<relatedCnt; relIdx++)
    {
       CLEANUP(AE_ask_dataset_ref_count(secondaryList[relIdx], &refCnt))
	   //if dataset has no references but has dataset
	   //if (refCnt > 0)
       {
          // Inflate custom Dataset runtime properties and add to returned array. 
          CLEANUP(FV_inflate_dataset(secondaryList[relIdx], objectTag))
          CLEANUP(FV_add_tag_to_array(datasetCnt, datasetTags, secondaryList[relIdx]))
       }
    }
CLEANUP:
    FV_DEBUG_TXT(("Exiting %s, returning %d datasets\n", function_name, *datasetCnt))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);
    FVE_FREE(secondaryList)	
    return ifail;
}

/******************************************************************************
Function     :  find_column_indexes
Description  :  Function to find column indexes for placeholder like TYPE,RevisionTYPE,DatasetTYPE,RelationTYPE 			
input        :  column_array_cnt for number of columns ,column values
Output       :  index of specific placeholder
Return value :  index of placeholder
*******************************************************************************/
void find_column_indexes(int column_array_cnt ,char ** column_array)
{
	int inx=0;
	for(inx = 0; inx < column_array_cnt; inx++)
	{

		if(tc_strcmp(column_array[inx],COLUMN_TYPE) == 0)
		{
			typeInx=inx;
		}
		else if (tc_strcmp(column_array[inx],COLUMN_Item_ID) == 0)
		{
			itemIDInx=inx;
		}else if (tc_strcmp(column_array[inx],COLUMN_Obj_Name) == 0)
		{
			objNameInx=inx;
		}
		else if(tc_strcmp(column_array[inx],COLUMN_Revision_TYPE) == 0)
		{
			revTypeInx=inx;
		}	
		else if(tc_strcmp(column_array[inx],COLUMN_Dataset_TYPE) == 0)
		{
			datasetTypeInx=inx;
		}	
	}
	printf("\n typeInx:[%d]\n itemIDInx:[%d]\n objNameInx:[%d]\n revTypeInx:[%d]\n datasetTypeInx:[%d]\n",typeInx,itemIDInx,objNameInx,revTypeInx,datasetTypeInx);
    fprintf(slogfileptr,"\n typeInx:[%d]\n itemIDInx:[%d]\n objNameInx:[%d]\n revTypeInx:[%d]\n datasetTypeInx:[%d]\n",typeInx,itemIDInx,objNameInx,revTypeInx,datasetTypeInx);	
}

/******************************************************************************
Function     :  fve_autologin
Description  :  Function for auto login to Teamcenter. 			
input        :  
Output       :  
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int fve_autologin()
{
	int ifail = ITK_ok;

	ifail =  ITK_auto_login();
	printf ( "Ifail = %d\n", ifail);
	if(ifail != ITK_ok)
	{
		fprintf(stderr,"Auto Login unsuccessful\n");
		fflush(stderr);
		return ifail;
	}
	else
	{	
		char*		userName = NULL;
		tag_t		userTag		= NULLTAG;
		printf("Login Successful\n");
		POM_get_user(&userName, &userTag);
		fprintf(stderr,"Login with User: %s successful\n", userName);
		fflush(slogfileptr);
	}

	return ifail;
}
int FV_set_application_bypass(logical trueFalseAction, char* callingFunctionName)
{
    // NOTE: ITK_set_bypass() sets the value for DBA bypass (user must be system administrator). 
    //       ITK_ask_bypass() gets the value of DBA bypass. 
    //
    //       AM_set_application_bypass() sets the value for application bypass (works for any user).	
    //       AM_ask_application_bypass() gets the value of application bypass.	
	
    // Set or reset the application bypass
    AM__set_application_bypass(trueFalseAction);

    FV_DEBUG_TXT(("%s() set APPLICATION BYPASS to %s\n", 
	         (callingFunctionName?callingFunctionName:FV_NULL_VALUE),
		 (trueFalseAction?FV_TRUE_VALUE:FV_FALSE_VALUE)))

    return ITK_ok;
}
/******************************************************************************
Function     :  createDataset
Description  :  Function to create dataset with specific Type. 			
input        :  Dataset name and DatasetType name 
Output       :  Tag of dataset
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int createDataset(char *datasetName, char *DTstTypeName ,tag_t *dataset)
{
		int			ifail						=	ITK_ok;
		char		*function_name				=	"createDataset";
		char		format_name[AE_io_format_size_c+1] ; 
		tag_t		datasettype					=	NULLTAG;
		tag_t		tool						=	NULLTAG;
		tag_t		new_dataset					=	NULLTAG;		

		FV_DEBUG_TXT(("\n Entering %s\n", function_name))
        FV_set_application_bypass(TRUE, function_name);
		CLEANUP(AE_init_module())
		/* create dataset */
		fprintf(slogfileptr,"\n [%s] \n",DTstTypeName);		
		CLEANUP(AE_find_datasettype(DTstTypeName, &datasettype))	
		CLEANUP(AE_ask_datasettype_def_tool(datasettype,&tool))			
		CLEANUP(AE_create_dataset_with_id(datasettype,datasetName,NULL,0,0,&new_dataset))		
		
		if(new_dataset != NULLTAG)
		{
			*dataset=new_dataset;
			CLEANUP(AE_set_dataset_tool(new_dataset, tool))
			CLEANUP(AE_ask_dataset_format(new_dataset,format_name))
			fprintf(slogfileptr,"\n [%s] \n",format_name);
			printf("\n [%s] \n",format_name);

			CLEANUP(AE_set_dataset_format(new_dataset, format_name))			
			CLEANUP(AOM_save(new_dataset))
			CLEANUP(AOM_refresh(new_dataset, TRUE))	
		}

		CLEANUP(AE_exit_module())
        FV_set_application_bypass(FALSE, function_name);
CLEANUP:
		FV_DEBUG_TXT(("\n Exiting from %s \n", function_name))
		fprintf(slogfileptr,"\n Exiting from %s\n",function_name);	
		return ifail;
}

/******************************************************************************
Function     :  print_usage
Description  :  Function to print argument information. 			
input        :  
Output       :  
Return value :  
*******************************************************************************/
void print_usage(void)
{		printf(" This program is intended to import Item,Dataset and their named references.\n\n");
        printf("\n******************************************************************************\n");
        printf("Usage: fv_item_dataset_import_utility <args>\n\n");
        printf(" Where args include the following:\n\n");
		printf(" -u=<login user id>\n");
		printf(" -p=<login password>\n");
		printf(" -g=<login group>\n");
		printf(" -file=<filename>  input file to import items,dataset ,references\n");
        printf("Each record in the file contains the following in the order specified:|TYPE|item_id|object_name|object_desc|ip_classification|RevisionTYPE|FV_DocumentType|FVR_DocMaturity|FVR_PercentComplete|DatasetTYPE|RelationTYPE|filename_1|filename_2|filename_3|filename_4|filename_5\n");
        printf("\n\n");
        printf(" -h=<any value> for usage help\n");
		printf("\n");
        printf(" NOTE:- \n");
        printf("******************************************************************************\n\n");
}

/******************************************************************************
Function     :  dump_itk_errors
Description  :  Function to dump error information. 			
input        :  status,program name,lineNumber and fileName
Output       :  
Return value :  
*******************************************************************************/
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int				n_ifails					=   0;
	int				ifail						=	ITK_ok;
    const int*		severities					=	NULL;
    const int*		ifails						=	NULL;
    const char**	texts						=	NULL;
    char*			errstring					=	NULL;
	
    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
		   fprintf( elogfileptr, "%s: Error %d: %s\n", prog_name, ifail, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
			fprintf( elogfileptr, "%s: Error %d: %s\n", prog_name, stat, errstring);
            FVE_FREE( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
		fprintf( elogfileptr, "%s: Error %d: %s\n", prog_name, stat, errstring);
        FVE_FREE( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fprintf(elogfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	fflush(elogfileptr);
}
/******************************************************************************
Function     :  get_time_stamp
Description  :  Function to get current timestamp information. 			
input        :  time-date format
Output       :  current timestamp
Return value :  
*******************************************************************************/
void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month  = (byte) newTime->tm_mon;
	currentTime.year   = (short) newTime->tm_year + 1900;
	currentTime.day    = (byte) newTime->tm_mday;
	currentTime.hour   = (byte) newTime->tm_hour;
	currentTime.minute = (byte) newTime->tm_min;
	currentTime.second = (byte) newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}
/******************************************************************************
Function     :  ask_property_value_by_name
Description  :  Function to property value of given property. 			
input        :  tag of Object and property name	
Output       :  property value
Return value :  
*******************************************************************************/
void ask_property_value_by_name(tag_t object, char *prop_name,char **prop_value)
{
    //tag_t	      prop_tag					=	NULLTAG;
	int			  ifail						=	ITK_ok;
	char*		  function_name				=	"ask_property_value_by_name";

   // CLEANUP(PROP_UIF_ask_property_by_name(object, prop_name, &prop_tag))
   // CLEANUP(PROP_UIF_ask_value(prop_tag, prop_value))
   CLEANUP(AOM_ask_value_string(object,prop_name,prop_value))

CLEANUP:
	//FVE_FREE(prop_value)
    FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);    
}
/******************************************************************************
Function     :  ask_dataset_imanfile_named_references
Description  :  Function to find dataset named references count. 			
input        :  tag of dataset
Output       :  reference count and  tags of reference objects
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int ask_dataset_imanfile_named_references(tag_t dataset,int* referenceNameCount, char ***reference_names, int* referenceObjCount, tag_t **reference_objects)
{
    int
        ii = 0,
        reference_count = 0;
	int						  ifail						=	ITK_ok;
    tag_t					  reference_object			=	NULLTAG;
    char
        reference_name[AE_reference_size_c + 1],
        *type;
    AE_reference_type_t       reference_type;
	char*					  function_name				=	"ask_dataset_imanfile_named_references";

    CLEANUP(AOM_refresh(dataset, TRUE))
    CLEANUP(AE_ask_dataset_ref_count(dataset, &reference_count))
    if (reference_count > 0)
    {
        for (ii = 0; ii < reference_count; ii++)
        {
            CLEANUP(AE_find_dataset_named_ref(dataset, ii,
                reference_name, &reference_type, &reference_object))
            ask_property_value_by_name(reference_object, "Type", &type);
            if (!strcmp(type, "ImanFile"))
            {
				FV_copy_string_to_array(referenceNameCount, reference_names, reference_name);
				FV_add_tag_to_array(referenceObjCount, reference_objects, reference_object);
            }
            if (type != NULL) FVE_FREE(type);
        }
    }

    CLEANUP(AOM_unlock(dataset))

  CLEANUP:
    FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);
    return ifail;
}
/******************************************************************************
Function     :  report_imanfile_references
Description  :  Function to print named references information. 			
input        :  referenceObjCount,reference names and tags of references objects
Output       :  
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int report_imanfile_references(int n, char **reference_names,tag_t *reference_objects)
{
    int					ii;
	int					ifail						=	ITK_ok;
    
	char				name[IMF_filename_size_c + 1];
	char*               function_name = "report_imanfile_references";

    for (ii = 0; ii < n; ii++)
    {
        CLEANUP(IMF_ask_original_file_name(reference_objects[ii], name));
        fprintf(slogfileptr,"%d.  %s - %s\n", ii+1, reference_names[ii], name);
    }

CLEANUP:	
    FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);
    return ifail;
}
/******************************************************************************
Function     :  ask_imanfile_path
Description  :  Function to find file path from given fileTag. 			
input        :  Tag of file
Output       :  filepath of given file tag
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int ask_imanfile_path(tag_t fileTag, char *path)
{
    int         machine_type				=	0;
	int			ifail						=	ITK_ok;
    tag_t		volume						=	NULLTAG;	
	char*       function_name				=	"ask_imanfile_path";

    CLEANUP(IMF_ask_volume(fileTag, &volume))
    CLEANUP(VM_ask_machine_type(volume, &machine_type))
    CLEANUP(IMF_ask_file_pathname(fileTag, machine_type, path))

CLEANUP:
    FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);
    return ifail;
}

/******************************************************************************
Function     :  delete_dataset_named_reference
Description  :  Function to delete attached named references. 			
input        :  Tag of dataset,reference name and Tag of reference_object
Output       :  
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int delete_dataset_named_reference(tag_t dataset, char *reference_name,tag_t reference_object)
{
    char        pathname[SS_MAXPATHLEN];
	char*       function_name				=	"delete_dataset_named_reference";
	int			ifail						=	ITK_ok;

    CLEANUP(AOM_refresh(dataset, TRUE))
    CLEANUP(AE_remove_dataset_named_ref_by_tag(dataset, reference_name,reference_object))
    CLEANUP(AE_save_myself(dataset))
    CLEANUP(AOM_unlock(dataset))

    CLEANUP(AOM_lock_for_delete(reference_object))
    CLEANUP(ask_imanfile_path(reference_object, pathname))
	fprintf(slogfileptr,"\n Deleted:%s \n",pathname);	
    printf("Deleted: %s\n", pathname);
    CLEANUP(AOM_refresh(reference_object,FALSE))
	CLEANUP(AOM_lock_for_delete(reference_object))  
    CLEANUP(AOM_delete(reference_object))
	
CLEANUP:
    FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);
    return ifail;
}
/******************************************************************************
Function     :  ask_file_format
Description  :  Function to find file format information. 			
input        :  path of file
Output       :  
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int ask_file_format(char *path)
{
    IMF_file_status        stats ;
	int					   ifail						=	ITK_ok;
	char*				   function_name							=	"ask_file_format";

    CLEANUP(IMF_stat(path, &stats))

CLEANUP:
	FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);
    return stats.fmt;
}

/******************************************************************************
Function     :  import_os_file
Description  :  Function to import file from pathname. 			
input        :  references names
Output       :  
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
tag_t import_os_file(char *os_path_name, char *new_os_name)
{
    int        file_type					=   0;
	int		   ifail						=	ITK_ok;
    
	tag_t      file_tag						=   NULLTAG;
    
	char       pathname[SS_MAXPATHLEN];
  	char*      function_name				=	"import_os_file";
    
	IMF_file_t file_descriptor;

    file_type = ask_file_format(os_path_name);
	printf("\n file_type:%d\n", file_type);

    CLEANUP(IMF_import_file(os_path_name, new_os_name, file_type,&file_tag, &file_descriptor))
    ask_imanfile_path(file_tag, pathname);
    printf("\n imported %s to %s\n", os_path_name, pathname);
	fprintf(slogfileptr,"\n imported %s to %s\n", os_path_name, pathname);
    if (strcmp(new_os_name, ""))
        CLEANUP(IMF_set_original_file_name(file_tag, new_os_name))

    CLEANUP(AOM_save(file_tag))
    CLEANUP(AOM_unlock(file_tag))
   
CLEANUP:
    FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);    
    return file_tag;
}
/******************************************************************************
Function     :  add_dataset_named_reference
Description  :  Function to add named references to dataset. 			
input        :  Tag of dataset,reference name and file Tag
Output       :  
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int add_dataset_named_reference(tag_t dataset, char *reference_name,tag_t imported_file)
{
	int			ifail						=	ITK_ok;
	char*       function_name = "add_dataset_named_reference";

    CLEANUP(AOM_refresh(dataset, TRUE))
    CLEANUP(AE_add_dataset_named_ref(dataset, reference_name, AE_PART_OF,imported_file))
    CLEANUP(AE_save_myself(dataset))
    CLEANUP(AOM_unlock(dataset))

CLEANUP:
    FV_DEBUG_TXT(("Exiting %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);
    return ifail;
}
/******************************************************************************
Function     :  add_or_delete_dataset_named_reference
Description  :  Function to add or remove dataset named references 			
input        :  Tag of revision,datasetTypename,relationtypename,referencecount,named references names
Output       :  
Return value :  If successful ITK_ok else non-zero number
*******************************************************************************/
int add_or_delete_dataset_named_reference(tag_t newRevTag,char *DTstTypeName,char** itemDSRelNames,int namedRefNameCnt,char** namedRefValues)
{
	int			ifail										=	ITK_ok;
	int			refIdx										=	0;
	int			foundRefIdx									=	0;
	int			n_ref										=	0;
	int         referenceNameCount							=	0;
	int         referenceObjCount							=	0;
	int			uniqueDSTypeNamesCount						=   0;		
	int			dsTypeIdx									=   0;	
	int			dsTagIndex									=   0;
	int			secondaryDatasetsCnt						=   0;
	int         uniqueRelationNamesCnt						=   0;

	tag_t       datasetTag									=	NULLTAG;
	tag_t*		reference_objects							=	NULLTAG;
	tag_t		imported_file								=	NULLTAG;
	tag_t       relationTag									=	NULLTAG;
	tag_t 		resolvedDatasetTypeTag						=	NULLTAG;      
	tag_t*      uniqueDatasetTags							=	NULLTAG;
	tag_t*		secondaryDatasets							= NULL;
	tag_t		tempDatasetTypetag							= 0;

	char**		reference_names								=	NULL;		
	char*		newDSID										=	NULL;	
	char*		namedRef 									=	NULL;		
	char*		itemDSRelTypeNm								=	NULL;	
	char*       function_name								=	"add_or_delete_dataset_named_reference"; 
	char        datasetTypeNm[AE_datasettype_name_size_c+1] =	{'\0'};
	char**		uniqueDSTypeNames							= NULL;		
	char*		tempDatasetTypeName							= NULL;
	char**		uniqueRelationNames							= NULL;

	logical		datasetFound								= FALSE;

	printf("\n namedRefNameCnt:%d \n", namedRefNameCnt);
	printf("\n DTstTypeName:%s \n", DTstTypeName);
	
	for(refIdx = 0; refIdx < namedRefNameCnt; refIdx++)	
	{
		FV_copy_unique_string_to_array(&uniqueRelationNamesCnt, &uniqueRelationNames, itemDSRelNames[refIdx]);
	}

	//First Delete All references of existing Dataset
	for(refIdx = 0; refIdx < uniqueRelationNamesCnt; refIdx++)	
	{
			uniqueDSTypeNamesCount = 0;		
			secondaryDatasetsCnt = 0;
		
			CLEANUP(FV_strdup(uniqueRelationNames[refIdx], &itemDSRelTypeNm))				

			printf("\n DELETE:[%d]:[%s] \n",refIdx,itemDSRelTypeNm);
			fprintf(slogfileptr,"\n DELETE:[%d]:[%s] \n",refIdx,itemDSRelTypeNm);
			// Get all types for these dataset tags and make unique array out of them
			CLEANUP(get_all_unique_dataset_type_names_for_relation(newRevTag, itemDSRelTypeNm, &uniqueDSTypeNamesCount, &uniqueDSTypeNames, &secondaryDatasetsCnt, &secondaryDatasets))			
			
			// If no datasets present with relation then continue the loop as there will not be any named ref to delete.
			if(secondaryDatasetsCnt == 0)
			{
				continue;
			}			
			for(dsTagIndex = 0; dsTagIndex < secondaryDatasetsCnt; dsTagIndex++)
			{
							//Check that object you are sending to this function is dataset
							CLEANUP(FV_ask_dataset_type_and_typename(secondaryDatasets[dsTagIndex], &tempDatasetTypetag, &tempDatasetTypeName))									
							
							if(tc_strcmp(uniqueDSTypeNames[dsTypeIdx],tempDatasetTypeName) == 0)
							{
								//Dataset Type already exist
								referenceNameCount=0;
								referenceObjCount=0;		
								datasetTag = secondaryDatasets[dsTagIndex];	
								//printf("\n datasetTypeNm:%s\n",datasetTypeNm);
								if(datasetTag != NULLTAG)
								{
									n_ref = ask_dataset_imanfile_named_references(datasetTag,&referenceNameCount,&reference_names, &referenceObjCount,&reference_objects);		
									printf("\n References Found::%d\n",referenceObjCount);
									fprintf(slogfileptr,"\n References Found:%d \n",referenceObjCount);	
									if(referenceObjCount!=0)
									{
											CLEANUP(report_imanfile_references(referenceObjCount, reference_names,reference_objects))
											printf("\n Delete refs:%d \n", referenceObjCount);	
											//Delete existing references									
											for (foundRefIdx=0; foundRefIdx<referenceObjCount; foundRefIdx++)
											{
												fprintf(slogfileptr,"\n [%d]:[%s]\n ", foundRefIdx,reference_names[foundRefIdx]);
												CLEANUP(delete_dataset_named_reference(datasetTag, reference_names[foundRefIdx],reference_objects[foundRefIdx]))
											}		
									}
									FVE_FREE(reference_objects)
									FVE_FREE(tempDatasetTypeName)	
									FVE_FREE_ARRAY(reference_names,referenceNameCount)	
								}
							}

			}	
			FVE_FREE(secondaryDatasets)
			FVE_FREE(itemDSRelTypeNm)
			FVE_FREE(uniqueDatasetTags)
			FV_FREE_STRINGS(uniqueDSTypeNames)
	}		
	//Add References
	
	//itemDSRelNamesCount = namedRefNameCnt;


	for(refIdx = 0; refIdx < namedRefNameCnt; refIdx++)
	{
		datasetFound = FALSE;	
	
		
		printf("\n ****%s\n",DTstTypeName);
				
		// find relation name from same index

		CLEANUP(FV_strdup(itemDSRelNames[refIdx], &itemDSRelTypeNm))				
		printf("\n [%d]:itemDSRelTypeNm:%s \n",refIdx,itemDSRelTypeNm);

		
		// check if some dataset of that type name is attached with revision with that relation

		CLEANUP(ask_populated_datasets(newRevTag,itemDSRelTypeNm,&secondaryDatasetsCnt, &secondaryDatasets))
	
		CLEANUP(FV_resolve_datasettype_tag_for_filename(namedRefValues[refIdx],&resolvedDatasetTypeTag,&namedRef))
		CLEANUP(AE_ask_datasettype_name(resolvedDatasetTypeTag, datasetTypeNm))
		printf("\n ****%s:%s\n",datasetTypeNm,namedRef);

		for(dsTagIndex = 0; dsTagIndex < secondaryDatasetsCnt; dsTagIndex++)
		{
			//Check that object you are sending to this function is dataset
			CLEANUP(FV_ask_dataset_type_and_typename(secondaryDatasets[dsTagIndex], &tempDatasetTypetag, &tempDatasetTypeName))
			
			if(tc_strcmp(datasetTypeNm, tempDatasetTypeName) == 0)
			{
				//Add Named reference to first dataset found
				
				datasetTag = secondaryDatasets[dsTagIndex];
				imported_file = import_os_file(namedRefValues[refIdx], "");									
				
				printf("\n **********namedRef:[%s]\n",namedRef);
				
				if(imported_file!=NULLTAG)
				{
					CLEANUP(add_dataset_named_reference(datasetTag,  namedRef, imported_file))	
				}
				
				datasetFound = TRUE;

				break;
			}

			FVE_FREE(tempDatasetTypeName)
		}

		if(datasetFound == FALSE)
		{
		// create new dataset for this file type and add it to the revision

			CLEANUP(AOM_ask_value_string (newRevTag, item_idPROP, &newDSID))
			printf("\n newDSID:%s ", newDSID);
			printf("\n DTstTypeName:%s ", DTstTypeName);
			printf("\n datasetTypeNm:%s ", datasetTypeNm);

			CLEANUP(createDataset(newDSID,DTstTypeName,&datasetTag))
			//CLEANUP(createDataset(newDSID,datasetTypeNm,&datasetTag))
			printf("\n Dataset %s is created ...\n",newDSID);

			printf("\n itemDSRelTypeNm:%s\n",itemDSRelTypeNm);

			CLEANUP(FV_create_and_save_relation(newRevTag,datasetTag,itemDSRelTypeNm,NULLTAG,&relationTag))
			printf("\n Relation created ...\n");

			FVE_FREE(newDSID)
			//Add new references
			imported_file = import_os_file(namedRefValues[refIdx], "");		
			
			printf("\n **********namedRef:[%s]\n",namedRef);
			
			if(imported_file!=NULLTAG)
			{
				printf("\n ***********HERE**********");
				CLEANUP(add_dataset_named_reference(datasetTag,  namedRef, imported_file))	
			}

		}
		// if yes, attach the file to that dataset only. (if multiple datasets found of that type, then use first one)
		// If no, create new dataset of that dataset type name, add named reference and attach it to the revision with found relation.
		//FV_FREE_STRINGS(pathStrArray)
		FVE_FREE(namedRef)
		FVE_FREE(itemDSRelTypeNm)			
	}

CLEANUP:
	FV_FREE_STRINGS(uniqueRelationNames)
    FV_DEBUG_TXT(("\n Exiting from %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);	
    return ifail;
}

int get_all_unique_dataset_type_names_from_input_file_for_relation(char* itemDSRelTypeNm, char** itemDSRelNames, int namedRefNameCnt,char** namedRefValues, int* uniqueDSTypeNamesFromInputCount, char*** uniqueDSTypeNamesFromInput)
{
	int			ifail										=	ITK_ok;
	char*       function_name								=	"get_all_unique_dataset_type_names_from_input_file_for_relation";
	int			inx											= 0;
	tag_t		datasetTypetag								= NULLTAG;
	char*		datasetTypeName								= NULL;
	char*		namedRef									= NULL;
	char		type_name_buffer[AE_datasettype_name_size_c+1] = {'\0'};

	for(inx = 0; inx < namedRefNameCnt; inx++)
	{
		if(tc_strcmp(itemDSRelTypeNm, itemDSRelNames[inx]) == 0)
		{	
			// Add call to get only file name out of whole file full path. Its recommended for below function call.
			CLEANUP(FV_resolve_datasettype_tag_for_filename(namedRefValues[inx], &datasetTypetag, &namedRef))
			CLEANUP(AE_ask_datasettype_name(datasetTypetag, type_name_buffer))
			CLEANUP(FV_strdup(type_name_buffer, &datasetTypeName))
			
			FV_copy_unique_string_to_array(uniqueDSTypeNamesFromInputCount, uniqueDSTypeNamesFromInput, datasetTypeName); 

			FVE_FREE(datasetTypeName)
			FVE_FREE(namedRef)
		}
	}


CLEANUP:
    FV_DEBUG_TXT(("\n Exiting from %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);	
    return ifail;
}

int get_all_unique_dataset_type_names_for_relation(tag_t revTag, char* itemDSRelTypeNm, int* uniqueDSTypeNamesCount, char*** uniqueDSTypeNames, int* secondaryDatasetsCnt, tag_t** secondaryDatasets)
{
	int			ifail										= ITK_ok;
	char*       function_name								= "get_all_unique_dataset_type_names_for_relation";
	int			datasetCnt									= 0;
	tag_t*		datasetTags									= NULL;
	tag_t		datasetTypetag								= NULLTAG;
	char*		datasetTypeName								= NULL;
	int			inx											= 0;

	CLEANUP(ask_populated_datasets(revTag,itemDSRelTypeNm,&datasetCnt, &datasetTags))
	CLEANUP(FV_add_tags_to_array(secondaryDatasetsCnt, secondaryDatasets, datasetCnt, datasetTags))

	for(inx = 0; inx < datasetCnt; inx++)
	{
		CLEANUP(FV_ask_dataset_type_and_typename(datasetTags[inx], &datasetTypetag, &datasetTypeName))		
		CLEANUP(FV_copy_unique_string_to_array(uniqueDSTypeNamesCount, uniqueDSTypeNames, datasetTypeName))
		FVE_FREE(datasetTypeName)
	}
	
	FVE_FREE(datasetTags)
CLEANUP:
    FV_DEBUG_TXT(("\n Exiting from %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);	
    return ifail;

}

int FV_find_type_valid_attrs(char* createTypeNames,char* column,char* columnAttrValue,int* itemAttrNameCnt,char*** itemAttrNames,int* itemAttrValuesCnt,char*** itemAttrValues)
{
	int			ifail						=	ITK_ok;
	int			propertyCnt					=	0;
	int         propIdx						=   0;
	int         propAttrCnt					=   0;
	char*       function_name				=	"FV_find_type_valid_attrs"; 
	char*		typeName					=   NULL;
	char*       propertyType				=   NULL;
    char*       propertyName				=   NULL;
	char**      propAttrValues				=   NULL;

	tag_t       typeTag						=   NULLTAG;
	tag_t*      propertyDescriptorTags		=	NULL;

	if (createTypeNames == NULL)
       CLEANUP(FV_handle_missing_arg_error(function_name, "createTypeNames"))
    if (column == NULL)
       CLEANUP(FV_handle_missing_arg_error(function_name, "column"))
    if (columnAttrValue == NULL)
       CLEANUP(FV_handle_missing_arg_error(function_name, "columnAttrValue"))
   
    CLEANUP(FV_strdup(createTypeNames, &typeName))
	printf("\n typeName:%s\n",typeName);	
	CLEANUP(TCTYPE_find_type(typeName, NULL, &typeTag))
    if (typeTag == NULLTAG)
    {
       fprintf(slogfileptr,"In %s, failed to find type %s\n", function_name, (typeName?typeName:FV_NULL_VALUE));
       goto CLEANUP;
    }
	CLEANUP(TCTYPE_list_displayable_properties( typeTag, &propertyCnt, &propertyDescriptorTags))
	printf("\n propertyCnt:%d\n",propertyCnt);	
	
    for (propIdx=0; propIdx<propertyCnt; propIdx++)
    {
        PROP_type_t propTypeTag = NULLTAG;
	    CLEANUP(PROPDESC_ask_property_type(propertyDescriptorTags[propIdx], &propTypeTag, &propertyType))
        if (propTypeTag == PROP_attribute)
        {
            CLEANUP(PROPDESC_ask_name(propertyDescriptorTags[propIdx], &propertyName))   
			CLEANUP(FV_copy_string_to_array(&propAttrCnt, &propAttrValues,FV_trim_blanks(propertyName)))
			//printf("\n propertyName:%s\n",propertyName);	              
            FVE_FREE(propertyName)           
        }
        FVE_FREE(propertyType)
    }
	if (FV_find_string_in_array_ignore_case(propAttrCnt, propAttrValues, column) > 0)
	{
		CLEANUP(FV_copy_string_to_array(itemAttrNameCnt, itemAttrNames,FV_trim_blanks(column)))
		CLEANUP(FV_copy_string_to_array(itemAttrValuesCnt, itemAttrValues,FV_trim_blanks(columnAttrValue)))	
	}
	else
	{
			printf("\n Property invalid....\n");
			printf("\n [%s]:[%s] \n",column,columnAttrValue);		
	}

CLEANUP:
	FVE_FREE(typeName)
	FVE_FREE(propertyDescriptorTags)
	FV_FREE_STRINGS(propAttrValues)
    FV_DEBUG_TXT(("\n Exiting from %s \n", function_name))
	fprintf(slogfileptr,"\n Exiting from %s\n",function_name);	
    return ifail;
}
extern int ITK_user_main(int retCount, char **retValue)
{
	FILE			*fileptr                                                =           NULL;
	char			line_in[2047 + 1]                                       =           "";
	char			line_temp[2047 + 1]                                     =           "";
	const char*		filename												=           NULL;
	const char*		mode													=           "r+";
	char*			ptr														=           NULL;
	char			successLogfilename[255 + 1]                             =           "";
	char			errorLogfilename[255 + 1]							    =           "";
	char*			time_stamp												=           NULL;
	char **         column_array											=           NULL;	
	char**			itemAttrNames											=			NULL;	
	char**			revAttrNames											=			NULL;
	char**			itemDSRelNames											=			NULL;	
	char**			namedRefValues											=			NULL;		
	char**			itemAttrValues											=			NULL;
	char**			revAttrValues											=			NULL;
	char**			columnAttrValues										=			NULL;
	char**			createTypeNames 										=			NULL;
	char**			createDatasetTypeNames 									=			NULL;
	char*			datasetName												=			NULL;
	char*			relationTypename										=			NULL;
	char*			itemID													=			NULL;
	char*			objName													=			NULL;	
	char**			attrNames												=			NULL;
	char**			attrValues												=			NULL;		
	char*			revTypestr												=			NULL;
	char*			itemDSRelName											=			NULL;
	char*			namedRefVal												=			NULL;
	char*			DTstTypeName											=			NULL;

	int				ifail													=           ITK_ok;
	int				len														=           0;
	int				line_count                                              =           0;
	int				column_array_cnt                                        =           0;	
	int				inx														=			0;
	int				itemAttrValuesCnt										=			0;
	int				namedRefValuesCnt										=			0;
	int				revAttrValuesCnt										=			0;
	int				itemAttrNameCnt											=			0;
	int				revAttrNameCnt											=			0;
	int				itemDSRelNameCnt										=			0;
	int				columnAttrValuesCnt										=			0;
	int				typeNamesCnt											=			0;
	int				datasetTypeNamesCnt										=			0;			
	int				resultCnt												=			0; 	
	int             attrNamesCnt											=			0;
	int             attrValuesCnt											=			0;

	logical			isAlreadyExists											=			FALSE;	

	
	tag_t			newRevTag												=			NULLTAG;
	tag_t*			resultTags												=			NULLTAG;

	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(successLogfilename,"fv_item_dataset_import_utility_success_%s.log",time_stamp);
	sprintf(errorLogfilename,"fv_item_dataset_import_utility_error_%s.log",time_stamp);

    slogfileptr = fopen( successLogfilename, "w+");
    if (slogfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", successLogfilename);
		FVE_FREE(time_stamp)
        exit(1);
    }
	else
		fprintf(slogfileptr,"File %s created successfully\n", successLogfilename);
    
	elogfileptr = fopen( errorLogfilename, "w+");
	if (elogfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", errorLogfilename);
		FVE_FREE(time_stamp)
        exit(1);
    }
	else
		fprintf(elogfileptr,"Error File %s created successfully\n", errorLogfilename);

	if(slogfileptr)
    {
        fprintf(slogfileptr,"Start time: %s\n", time_stamp);		
    }
	if(elogfileptr)
    {
        fprintf(elogfileptr,"Start time: %s\n", time_stamp);		
    }
     
	if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

	filename = ITK_ask_cli_argument("-file=");

    if (!filename)
    {
            print_usage();
            return !ITK_ok ;
    }

    ITK_initialize_text_services (0);

	ifail = fve_autologin();
	if (ifail != ITK_ok)
	{
		 fprintf(elogfileptr,"Login Failed....\n");
		 exit(0);
	}
	else
		 fprintf(slogfileptr,"Login Successful....\n");

	get_time_stamp(DATE_FORMAT_STR, &time_stamp);

	fprintf(slogfileptr,"\n Inputfile %s parsing is completed successfully  \n\n",filename);	

    fileptr = fopen (filename, mode);

	if ( fileptr != NULL )
    {
				line_count = 0;
				while (fgets(line_in, MAX_LINE_LEN, fileptr) != 0)
				{
					line_count++;
					len = (int) strlen(line_in);
					if (len > 0 && line_in[len-1] == '\n')
						line_in[len-1] = '\0';
					if ( strlen(  line_in ) == 0 )
						continue;
		
					if(line_count == 1)
					{
							tc_strcpy( line_temp, line_in);							
							ptr = tc_strtok(line_temp, "|");
							ptr = FV_trim_blanks(ptr);
							ITK(FV_copy_string_to_array(&column_array_cnt, &column_array, FV_trim_blanks(ptr)))
							while(ptr != NULL)			
							{
								ptr = tc_strtok(NULL, "|");								
								if(FV_trim_blanks(ptr)!=NULL)
								{									
									ITK(FV_copy_string_to_array(&column_array_cnt, &column_array, FV_trim_blanks(ptr)))
								}
							}
							find_column_indexes(column_array_cnt,column_array);							
							continue;
					}	
					else
					{
							ptr=NULL;							
							columnAttrValuesCnt=0;												
							typeNamesCnt=0;							
							datasetTypeNamesCnt=0;							
							itemAttrNameCnt=0;
							itemAttrValuesCnt=0;
							revAttrNameCnt=0;
							revAttrValuesCnt=0;
							itemDSRelNameCnt=0;
							namedRefValuesCnt=0;							
							relationTypename=NULL;
							isAlreadyExists=FALSE;
							resultCnt=0;
							itemID=NULL;
							objName=NULL;
							attrNamesCnt=0;
							attrValuesCnt=0;		
							revTypestr=NULL;
							DTstTypeName=NULL;

							tc_strcpy( line_temp, line_in);									
							ptr = tc_strtok(line_temp, "|");
							ptr = FV_trim_blanks(ptr);
							ITK(FV_copy_string_to_array(&columnAttrValuesCnt, &columnAttrValues, FV_trim_blanks(ptr)))
							while(ptr != NULL)			
							{
								ptr = tc_strtok(NULL, "|");
								if(FV_trim_blanks(ptr)!=NULL)
								ITK(FV_copy_string_to_array(&columnAttrValuesCnt, &columnAttrValues, FV_trim_blanks(ptr)))
							}							
							fprintf(slogfileptr,"\n columnAttrValues[typeInx]:[%s]\n",columnAttrValues[typeInx]);
							printf("\n columnAttrValues[typeInx]:[%s]\n",columnAttrValues[typeInx]);
							if ((columnAttrValues[typeInx] == NULL) || tc_strlen(FV_trim_blanks(columnAttrValues[typeInx])) < 1)
							{
									printf("ERROR:ItemType cannot be Blank,Bypass:Item and Dataset Creation...");
									fprintf(elogfileptr,"\n ERROR:ItemType cannot be Blank,Bypass:Item and Dataset Creation...\n");															
									ifail = ITK_ok;									
									goto CLEANUP;
							}	
							else
							{
									ITK(FV_copy_string_to_array(&typeNamesCnt, &createTypeNames,FV_trim_blanks(columnAttrValues[typeInx])))			
							}
							printf("\n columnAttrValues[revTypeInx]:[%s]\n",columnAttrValues[revTypeInx]);
							fprintf(slogfileptr,"\n columnAttrValues[revTypeInx]:[%s]\n",columnAttrValues[revTypeInx]);

							if ((columnAttrValues[revTypeInx] == NULL) || tc_strlen(FV_trim_blanks(columnAttrValues[revTypeInx])) < 1)
							{
									if(columnAttrValues[typeInx] != NULL)
									{
										CLEANUP(FV_strdup(columnAttrValues[typeInx], &revTypestr))
									    CLEANUP(FV_strcat(&revTypestr,"Revision"))
										printf("\n revTypestr:[%s]\n",revTypestr);
										fprintf(slogfileptr,"\n revTypestr:[%s]\n",revTypestr);
										ITK(FV_copy_string_to_array(&typeNamesCnt, &createTypeNames,FV_trim_blanks(revTypestr)))
									}
							}
							else
							{
								ITK(FV_copy_string_to_array(&typeNamesCnt, &createTypeNames,FV_trim_blanks(columnAttrValues[revTypeInx])))
							}		
							fprintf(slogfileptr,"\n columnAttrValues[datasetTypeInx]:[%s]\n",columnAttrValues[datasetTypeInx]);
							printf("\n columnAttrValues[datasetTypeInx]:[%s]\n",columnAttrValues[datasetTypeInx]);
							if ((columnAttrValues[datasetTypeInx] == NULL) || tc_strlen(FV_trim_blanks(columnAttrValues[datasetTypeInx])) < 1)
							{
									printf("ERROR:DatasetTYPE cannot be Blank,Bypass:Item and Dataset Creation...");
									fprintf(elogfileptr,"\n ERROR:DatasetTYPE cannot be Blank,Bypass:Item and Dataset Creation...\n");															
									ifail = ITK_ok;									
									goto CLEANUP;
							}	
							else
							{
									ITK(FV_copy_string_to_array(&datasetTypeNamesCnt, &createDatasetTypeNames,FV_trim_blanks(columnAttrValues[datasetTypeInx])))			
							}
							printf("\n columnAttrValues[datasetTypeInx]:[%s]\n",columnAttrValues[datasetTypeInx]);
							fprintf(slogfileptr,"\n columnAttrValues[datasetTypeInx]:[%s]\n",columnAttrValues[datasetTypeInx]);
							fprintf(slogfileptr,"\n Line %d \n",line_count);
							fprintf(slogfileptr,"\n Printing Types of object of row  %d \n",typeNamesCnt);	
							for(inx = 0; inx < typeNamesCnt; inx++)
							{
								fprintf(slogfileptr," [%s]\n",createTypeNames[inx]);								
							}										

							for(inx = 0; inx < columnAttrValuesCnt; inx++)
							{								
								if(inx==typeInx || inx==revTypeInx || inx==datasetTypeInx)
									continue;
								if(inx < revTypeInx )
								{	
									if (!FV_is_string_value_empty(columnAttrValues[inx], FV_TRIM_BLANKS))
									{										
										ITK(FV_copy_string_to_array(&itemAttrNameCnt, &itemAttrNames,FV_trim_blanks(column_array[inx])))
										ITK(FV_copy_string_to_array(&itemAttrValuesCnt, &itemAttrValues,FV_trim_blanks(columnAttrValues[inx])))
										//ITK(FV_find_type_valid_attrs(createTypeNames[0],column_array[inx],columnAttrValues[inx],&itemAttrNameCnt, &itemAttrNames,&itemAttrValuesCnt, &itemAttrValues))																		
									}									
								}else if(inx < datasetTypeInx )
								{
									if (!FV_is_string_value_empty(columnAttrValues[inx], FV_TRIM_BLANKS))
									{
										ITK(FV_copy_string_to_array(&revAttrNameCnt, &revAttrNames,FV_trim_blanks(column_array[inx])))
										ITK(FV_copy_string_to_array(&revAttrValuesCnt, &revAttrValues,FV_trim_blanks(columnAttrValues[inx])))
										//ITK(FV_find_type_valid_attrs(createTypeNames[1],column_array[inx],columnAttrValues[inx],&revAttrNameCnt, &revAttrNames,&revAttrValuesCnt, &revAttrValues))							
									}									
								}else if(inx > datasetTypeInx )
								{
									if (!FV_is_string_value_empty(columnAttrValues[inx], FV_TRIM_BLANKS))
									{
										 itemDSRelName = strtok(columnAttrValues[inx], "-" );
										 namedRefVal = strtok(NULL, "-" );
										 ITK(FV_copy_string_to_array(&itemDSRelNameCnt, &itemDSRelNames,FV_trim_blanks(itemDSRelName)))
										 ITK(FV_copy_string_to_array(&namedRefValuesCnt, &namedRefValues,FV_trim_blanks(namedRefVal)))									
									}
								}
							}
							// Adding object name to rev array
							if (!FV_is_string_value_empty(column_array[objNameInx], FV_TRIM_BLANKS))
							{
										ITK(FV_copy_string_to_array(&revAttrNameCnt, &revAttrNames,FV_trim_blanks(column_array[objNameInx])))
										ITK(FV_copy_string_to_array(&revAttrValuesCnt, &revAttrValues,FV_trim_blanks(columnAttrValues[objNameInx])))
							}
							
							fprintf(slogfileptr,"\n Printing Item Attribute of row  %d \n",itemAttrNameCnt);	
							for(inx = 0; inx < itemAttrNameCnt;inx++)
							{
								fprintf(slogfileptr," %d: [%s] = [%s]\n",inx + 1, itemAttrNames[inx], itemAttrValues[inx]);								
							}
							fprintf(slogfileptr,"\n Printing Rev Attribute of row  %d \n",revAttrNameCnt);
							for(inx = 0; inx < revAttrNameCnt; inx++)
							{
								fprintf(slogfileptr," %d: [%s] = [%s]\n",inx + 1, revAttrNames[inx], revAttrValues[inx]);							
							}
							fprintf(slogfileptr,"\n Printing dataset named references of row  %d \n",itemDSRelNameCnt);
							for(inx = 0; inx < itemDSRelNameCnt; inx++)
							{
								fprintf(slogfileptr," %d: [%s] = [%s]\n",inx + 1, itemDSRelNames[inx], namedRefValues[inx]);										
							}								
							
							itemID=columnAttrValues[itemIDInx];
							fprintf(slogfileptr,"******************************");
							fprintf(slogfileptr,"\n itemID:[%s]\n",itemID);

							objName=columnAttrValues[objNameInx];							
							fprintf(slogfileptr,"\n objName:[%s]\n",objName);

							ITK(FV_strdup(createDatasetTypeNames[0],&DTstTypeName))
							fprintf(slogfileptr,"\n DTstTypeName:[%s]\n",DTstTypeName);								

							fprintf(slogfileptr,"******************************");

							if(tc_strlen(FV_trim_blanks(itemID)) > 1)
							{
								printf("\n Searching by ID...\n");
								ITK(FV_copy_unique_string_to_array(&attrNamesCnt, &attrNames, Item_IDENTRY))
								ITK(FV_copy_unique_string_to_array(&attrNamesCnt, &attrNames, FV_OBJECT_TYPE))	

								ITK(FV_copy_unique_string_to_array(&attrValuesCnt, &attrValues, itemID))
								ITK(FV_copy_unique_string_to_array(&attrValuesCnt, &attrValues, createTypeNames[1]))	
								ITK(FV_execute_saved_query(Item_RevisionQUERY,attrValuesCnt, attrNames, attrValues, &resultCnt, &resultTags))

								printf("\n resultCnt:%d\n",resultCnt);															
																
								if(resultCnt>0)
								{
									fprintf(slogfileptr,"\n \n ItemID:%s is already Exist... \n",itemID);	
									newRevTag=resultTags[0];										
									ITK(add_or_delete_dataset_named_reference(newRevTag,DTstTypeName,itemDSRelNames,namedRefValuesCnt,namedRefValues))	
									//ITK(add_or_delete_dataset_named_reference(newRevTag,itemDSRelNames,DTstTypeName,namedRefValuesCnt,namedRefValues))										
									isAlreadyExists=TRUE;
									continue;	
								}//	resultCnt															
								FVE_FREE(resultTags)
								FV_FREE_STRINGS(attrNames)
								FV_FREE_STRINGS(attrValues)
							}
							else if(tc_strlen(FV_trim_blanks(objName)) >1)
							{
								printf("\n Searching by name...\n");
							
								ITK(FV_copy_unique_string_to_array(&attrNamesCnt, &attrNames, NameENTRY))
								ITK(FV_copy_unique_string_to_array(&attrNamesCnt, &attrNames, FV_OBJECT_TYPE))	

								ITK(FV_copy_unique_string_to_array(&attrValuesCnt, &attrValues, objName))
								ITK(FV_copy_unique_string_to_array(&attrValuesCnt, &attrValues, createTypeNames[1]))	
								ITK(FV_execute_saved_query(Item_RevisionQUERY, attrValuesCnt, attrNames, attrValues, &resultCnt, &resultTags))
								printf("\n resultCnt:%d\n",resultCnt);																				
								
								if(resultCnt>0)
								{
									fprintf(slogfileptr,"\n \n ItemID:%s is already Exist... \n",itemID);	
									newRevTag=resultTags[0];										
									ITK(add_or_delete_dataset_named_reference(newRevTag,DTstTypeName,itemDSRelNames,namedRefValuesCnt,namedRefValues))	
									//ITK(add_or_delete_dataset_named_reference(newRevTag,itemDSRelNames,DTstTypeName,namedRefValuesCnt,namedRefValues))										
									isAlreadyExists=TRUE;
									continue;	
								}//	resultCnt															
								FVE_FREE(resultTags)
								FV_FREE_STRINGS(attrNames)
								FV_FREE_STRINGS(attrValues)
							}			
							
							if(!isAlreadyExists)
							{
								//create item
								ITK(FV_create_item(2, createTypeNames, 0,
									itemAttrNameCnt, itemAttrNames, itemAttrValues,
									revAttrNameCnt, revAttrNames, revAttrValues, &newRevTag))								
							}							 
							if(newRevTag != NULLTAG)
							{
								fprintf(slogfileptr,"\n \n Item Created Successfully... \n");
								ITK(add_or_delete_dataset_named_reference(newRevTag,DTstTypeName,itemDSRelNames,namedRefValuesCnt,namedRefValues))																			
								//ITK(add_or_delete_dataset_named_reference(newRevTag,itemDSRelNames,DTstTypeName,namedRefValuesCnt,namedRefValues))	
							}//newRevTag		
							else
							{
								fprintf(slogfileptr,"\n \n Item Creation Failed... \n");
							}
							
							FVE_FREE(ptr)												
							FVE_FREE(columnAttrValues)
							FVE_FREE(createTypeNames)							
							FVE_FREE(itemAttrNames)
							FVE_FREE(itemAttrValues)
							FVE_FREE(revAttrNames)
							FVE_FREE(revAttrValues)
							FVE_FREE(itemDSRelNames)
							FVE_FREE(namedRefValues)
							FVE_FREE(createDatasetTypeNames)
					}//else
				}//while
	}//file close

    ITK_exit_module( true );
	fprintf(slogfileptr,"\n Utility completed successfully...\n\n");
	fprintf(elogfileptr,"\n Utility completed successfully...\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	printf("\n Utility Completed successfully...");
    fprintf(slogfileptr,"\n End time: %s\n", time_stamp);
	fprintf(elogfileptr,"\n End time: %s\n", time_stamp);
	FVE_FREE(time_stamp)
	FVE_FREE(datasetName)
    if (slogfileptr ) fclose( slogfileptr);
    if (fileptr ) fclose( fileptr);
	
								
	CLEANUP:
		return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}