//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#ifndef TEAMCENTER_CLIENTX_APPXREQUESTLISTENER_HXX
#define TEAMCENTER_CLIENTX_APPXREQUESTLISTENER_HXX





#include <string>
#include <vector>




#include <teamcenter/soa/client/RequestListener.hxx>





namespace Teamcenter
{
    namespace ClientX
    {




/**
 * This implemenation of the RequestListener, logs each service request
 * to the console.
 *
 */
class  AppXRequestListener: public Teamcenter::Soa::Client::RequestListener
{
public:

    /**
     * This method is called before every service request.
     *
     * @param info  Information describing the service operation
     */
    virtual void serviceRequest ( const Teamcenter::Soa::Client::ServiceInfo& info );

    /**
     * The method is called after the service response is recived.
     *
     * @param info Information describing the service operation
     */
    virtual void serviceResponse( const Teamcenter::Soa::Client::ServiceInfo& info );

};


}} //end namespace
#endif



