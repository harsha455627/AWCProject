

#include "FVDT_connector_lib_import.h"
#include "PasswdFunction.h"
#pragma warning( disable : 4996 )

int skipFileCheck = 0;

/*******************************************************************************/
/* Function Name    : FVDT_checksum                                            */
/*                                                                             */
/* Description      : Return the checksum size                                */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/


unsigned FVDT_checksum(void *buffer, size_t len, unsigned int seed)
{
      unsigned char *buf = (unsigned char *)buffer;
      size_t i;

      for (i = 0; i < len; ++i)
            seed += (unsigned int)(*buf++);
      return seed;
}

/*******************************************************************************/
/* Function Name    : FVDT_Get_CheckSum                                        */
/*                                                                             */
/* Description      : Return the check sum size of the input file              */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

unsigned FVDT_Get_CheckSum (char *file, unsigned int* seed)
   {
      FILE *fp;
      size_t len;
      char buf[4096];
      if (NULL == (fp = fopen(file, "rb")))
      {
            TC_write_syslog("Unable to open %s for reading\n", file);
            return -1;
      }
      len = fread(buf, sizeof(char), sizeof(buf), fp);
      if (g_debug) TC_write_syslog("%d bytes read\n", len);
      *seed = FVDT_checksum(buf, len, 0);
      if (g_debug) TC_write_syslog("The checksum of %s is %#x\n", file, FVDT_checksum(buf, len, 0));
	  fclose (fp);
      return 0;
}


/*******************************************************************************
 * NAME: dump_itk_errors
 *
 * DESCRIPTION
 *  Function to dump the ITK errors. This function has been inheritted from
 *  Teamcenter sample code.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/
static void dump_itk_errors( int ifail, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int   *severities=NULL;
    const int   *ifails=NULL;
    const char **texts=NULL;
    char        *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == ifail )
        {
           fprintf( stderr, "%s: Error %d: %s\n", prog_name, ifail, texts[n_ifails-1] );
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, ifail, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (ifail, &errstring );
            fprintf( stderr, "%s: Error %d: %s\n", prog_name, ifail, errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, ifail, errstring );
            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (ifail, &errstring );
        fprintf( stderr, "%s: Error %d: %s\n", prog_name, ifail, errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, ifail, errstring );
        MEM_free( errstring );
    }
    fprintf( stderr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
}

void dousage()
{
	printf("\nUSAGE: %s -u=user {-p=password | -pf=passwordFile} -g=group -f=inputfile -dir=Directory\n",my_name);
   printf("\nNOTE: File to be used :- connector_gdt2db_load.txt \n");
   return;
}


/*******************************************************************************/
/* Function Name    : FVDT_String_to_StringArray                               */
/*                                                                             */
/* Description      : Convert string to string array on the basis of given     */
/*                    delimitor                                                */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

void FVDT_String_to_StringArray  (char* line, char ***Attributes, char * delim, int *count )
{
   char     *str = NULL;   
   char**  AttributesDup = NULL;
   int      i              = 0;

   //*Attributes  = NULL;   
   str = tc_strtok (line, delim);   
   while (str != NULL)
   {
       //TC_write_syslog ("str %s.....\n",str);
       
       AttributesDup = (char**)MEM_realloc(AttributesDup, sizeof(char*)*(i+1));
       AttributesDup[i] = (char*)MEM_alloc( sizeof(char)*((int)strlen (str)+1));
       strcpy( AttributesDup [i], str);
       str = tc_strtok (NULL,delim);
       i++;
       //TC_write_syslog ("line %s.....\n",line);

   }
   *Attributes = AttributesDup;
   *count = i;
}

/*******************************************************************************/
/* Function Name    : FVDT_find_item                                           */
/*                                                                             */
/* Description      : Return all items for given item id                       */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

int FVDT_find_item(char* item_id,	 tag_t** rev, int *count)
{
   int          ifail             = ITK_ok;
	int          num = 0;
   char         *item_id_Attr = NULL;
   //tag_t			 *revs        = NULL; 
	char** attrs = NULL;
	char** vals = NULL;

   
   item_id_Attr = (char*)MEM_alloc((int) (strlen(item_idPROP)+1)*sizeof(char));
      
   strcpy(item_id_Attr, item_idPROP);

   attrs = (char**)MEM_alloc(1*sizeof(char*));
	vals = (char**)MEM_alloc(1*sizeof(char*));


   attrs[0]= (char*)MEM_alloc(sizeof(char)*((int) strlen (item_id_Attr)+1));
   vals[0]= (char*)MEM_alloc(sizeof(char)*((int)strlen (item_id)+1));

	strcpy(attrs[0], item_id_Attr);
	strcpy(vals[0], item_id);
   ITK (ITEM_find_items_by_key_attributes (1, (const char**)attrs, (const char**)vals, &num, rev));

   *count = num;
   FVDT_FREE(item_id_Attr)

	FVDT_FREE_ARRAY(attrs,1);
	FVDT_FREE_ARRAY(vals,1);

	return ifail;
}

/*******************************************************************************/
/* Function Name    : save_object                                           */
/*                                                                             */
/* Description      : Save the given object                      */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

int save_object (tag_t     object_tag)
{
    int ifail;

    /*  Save the object.  */
    ifail = AOM_save (object_tag);
    if (ifail != ITK_ok)
    {
        TC_write_syslog ("ERROR %d save object.\n", ifail);
        return (ifail);
    }

    /* Unlock the object. */
    ifail = AOM_unlock (object_tag);
    if (ifail != ITK_ok)
    {
        TC_write_syslog ("ERROR %d unlock object.\n", ifail);
    }

    return (ifail);
}

/*******************************************************************************/
/* Function Name    : FVDT_import_file                                         */
/*                                                                             */
/*  Description     : Import the datafile . If file-name has an extension,     */
/*                    strip it off from  file name. Use the input file-name to */
/*                    name the dataset and for the associated file, use        */
/*                    USER_new_file_name function to generate a unique name for*/
/*                    it                                                       */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/


int FVDT_import_file (
                 char      *datasetname,
                 char      *filename,
                 tag_t     *file_tag)
{
    int         file_type;
    char       *generatedFileName;
    char        extension [WSO_name_size_c + 1];
    IMF_file_t  fileDescriptor;
    int         ifail;
    int         j, idx, length;
    int         isFileExist      = 0;
    char        ref_name[AE_reference_size_c + 1];
	char        *mod_name = "FVDT_import_file";

	if (g_debug) TC_write_syslog ("Entering :: %s\n", mod_name);

    /* Get the original file extension. */
    length = tc_strlen(filename);

    /*Check if file exist*/
    isFileExist = FVDT_file_exists(filename);
    //printf( " isFileExist %d  %s ", isFileExist, filename );fflush(stdout);


    if ( isFileExist!=1)
    {

      return (1);
    }

    idx = 0;

    for (j=length -1; j >=0; j--)
    {
         if (filename[j] == '.')
         {
             idx = j;
             break;
         }
    }

    if (idx > 0)
    { /*  Case when filename has "." and extension. */
        if ((length - idx) > 1)
        {
              strcpy (extension, &filename[idx+1]);
        }
        else
        { /* Case when input filename has "." but has no extension. */
              strcpy (extension, "png");
        }
    }
    else
    {  /* Case when filename has no "." and no extension. */
        strcpy (extension, "png");
    }


    file_type= SS_BINARY;

    strcpy(ref_name, "Image");

    generatedFileName = USER_new_file_name (datasetname,
                                            ref_name,
                                            extension, 1);

    if (g_debug) TC_write_syslog(" generatedFileName %s", generatedFileName);



    ifail = IMF_import_file (filename, generatedFileName,
                                  file_type, file_tag, &fileDescriptor);


    if (ifail == ITK_ok)
    {
        ifail = IMF_close_file (fileDescriptor);
    }

    if (ifail != ITK_ok)
    {
        TC_write_syslog ("ERROR %d importing a file.\n", ifail);
        return (ifail);
    }

    ifail = save_object (*file_tag);

    return (ifail);
}

/*******************************************************************************/
/* Function Name    : FVDT_create_dataset                                      */
/*                                                                             */
/*  Description     : Creates the dataset and sets the default tool, output    */
/*                    format and dataset format for that dataset.              */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

int FVDT_create_dataset (char        *dataset_name,
                    tag_t        datasettype_tag,
                    char        *dataset_format,
                    char        *description,
                    tag_t        default_tool_tag,
                    tag_t       *dataset_tag)
{
    int ifail       = ITK_ok;


    /*
     * Create a dataset for the imported file.
     */

    if (!description)
    {
       ITK(AE_create_dataset_with_id (datasettype_tag, dataset_name,
                                        DESCRIPTION, 0, 0, dataset_tag));
    }
    else
    {
       ITK( AE_create_dataset_with_id (datasettype_tag, dataset_name,
                                        description, 0, 0, dataset_tag));
    }

    if (ifail != ITK_ok)
    {
        TC_write_syslog ("ERROR %d creating a dataset.\n", ifail);
        return (ifail);
    }

    /* Set the default tool for the new dataset */
    ITK(AE_set_dataset_tool (*dataset_tag, default_tool_tag));

    if (ifail != ITK_ok)
    {
        TC_write_syslog ("ERROR %d setting tool for dataset.\n", ifail);
        return (ifail);
    }

    /*
     * If tool output formats exist, use the tool output format to set for the
     * dataset format
     */

    /* Set the dataset format */
    ITK(AE_set_dataset_format (*dataset_tag, dataset_format));

    if (ifail != ITK_ok)
    {
        TC_write_syslog ("ERROR %d setting format for dataset.\n",
                      ifail);
        return (ifail);
    }


   //Set IP Classification to PUBLIC
   ITK( WSOM_set_ip_classification((*dataset_tag), IP_PUBLIC))


    return (ifail);
}

/*******************************************************************************/
/* Function Name    : FVDT_compare_and_update_attribute                        */
/*                                                                             */
/*  Description     : Compair the item attribute with attribute value in input */
/*                    file, Update the item attribute if there is any difference */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/


int FVDT_compare_and_update_attribute(char *item_id, tag_t item_rev, char ** Attributes, int *isUpdated)
{
   int          ifail             = ITK_ok;


   char        *value            = NULL;
   int         CavityNum         = 0;
   double      MatForce          = 0;
   double      MatForceTmp       = 0;
   char        *mod_name         ="FVDT_compare_and_update_attribute";

	if (g_debug) TC_write_syslog ("Entering :: %s\n", mod_name);

   ITK(AOM_refresh(item_rev, TRUE));

   ITK(AOM_get_value_string (item_rev, FVDTCHSSymNamePROP, &value));
   if ( Attributes[1]!=NULL && strlen(Attributes[1])!=0 && strcmp(value, Attributes[1])!=0)
   {
     ITK(AOM_set_value_string (item_rev, FVDTCHSSymNamePROP, Attributes[1]));
     *isUpdated =1;
   }

   FVDT_FREE(value);
   ITK(AOM_get_value_int  (item_rev, FVDTCHSCavityNumPROP, &CavityNum));
   if ( Attributes[2]!=NULL && strlen(Attributes[2])!=0 && atoi(Attributes[2])!=CavityNum)
   {
     ITK(AOM_set_value_int (item_rev, FVDTCHSCavityNumPROP, atoi(Attributes[2])));
     *isUpdated =1;
   }

   ITK(AOM_get_value_string (item_rev, object_namePROP, &value));
   if ( Attributes[3]!=NULL && strlen(Attributes[3])!=0 && strcmp(value, Attributes[3])!=0)
   {
     ITK(AOM_set_value_string (item_rev, object_namePROP, Attributes[3]));
     *isUpdated =1;
   }

   ITK(AOM_get_value_string (item_rev, FVDTCHSSubmergiblePROP, &value));
   if ( Attributes[4]!=NULL && strlen(Attributes[4])!=0 && strcmp(value, Attributes[4])!=0)
   {
     ITK(AOM_set_value_string (item_rev, FVDTCHSSubmergiblePROP, Attributes[4]));
     *isUpdated =1;
   }

   FVDT_FREE(value);
   ITK(AOM_get_value_string (item_rev, FVDTCHSRestrictedPROP, &value));
   if ( Attributes[5]!=NULL && strlen(Attributes[5])!=0 && strcmp(value, Attributes[5])!=0)
   {
     ITK(AOM_set_value_string (item_rev, FVDTCHSRestrictedPROP, Attributes[5]));
     *isUpdated =1;
   }

   FVDT_FREE(value);
   ITK(AOM_get_value_string (item_rev, FVDTCHSEvalRatingPROP, &value));
   if ( Attributes[6]!=NULL && strlen(Attributes[6])!=0 && strcmp(value, Attributes[6])!=0)
   {
     ITK(AOM_set_value_string (item_rev, FVDTCHSEvalRatingPROP, Attributes[6]));
     *isUpdated =1;
   }

   FVDT_FREE(value);
   ITK(AOM_get_value_double (item_rev, FVDTCHSMatForcePROP, &MatForce));
   MatForceTmp = atof(Attributes[7]);
   if ( Attributes[7]!=NULL && strlen(Attributes[7])!=0 && (float)MatForceTmp!=(float)MatForce)
   {

     
     ITK(AOM_set_value_double (item_rev, FVDTCHSMatForcePROP, MatForceTmp));
     *isUpdated =1;
   }

   ITK(AOM_get_value_string (item_rev, FVDTCHSReplacesPROP, &value));
   if ( Attributes[8]!=NULL && strlen(Attributes[8])!=0 && strcmp(value, Attributes[8])!=0  &&strcmp(Attributes[0],Attributes[8]) != 0 )
   {
     ITK(AOM_set_value_string (item_rev, FVDTCHSReplacesPROP, Attributes[8]));
     *isUpdated =1;
   }

   FVDT_FREE(value);
   ITK(AOM_get_value_string (item_rev, FVDTCHSServKitPartNumPROP, &value));
   if ( Attributes[9]!=NULL && strlen(Attributes[9])!=0 && strcmp(value, Attributes[9])!=0)
   {
     ITK(AOM_set_value_string (item_rev, FVDTCHSServKitPartNumPROP, Attributes[9]));
     *isUpdated =1;
   }

   FVDT_FREE(value);
   ITK(AOM_get_value_string (item_rev, FVDTCHSSpecPROP, &value));
   if ( Attributes[10]!=NULL && strlen(Attributes[10])!=0 && strcmp(value, Attributes[10])!=0)
   {
     ITK(AOM_set_value_string (item_rev, FVDTCHSSpecPROP, Attributes[10]));
     *isUpdated =1;
   }

   if ( *isUpdated!=0)
   {
	  fprintf (g_general_log,"Metadata is changed\n");
      if (save_object (item_rev) != ITK_ok)
      {
         TC_write_syslog("ERROR in save_object item\n");
          return (!ITK_ok);
      }
	  else
	  {
		  fprintf (g_general_log,"Metadata is updated\n");
	  }
   }
   else
   {
	  fprintf (g_general_log,"Metadata is NOT changed\n");
   }
   return (ifail);


}

/*******************************************************************************/
/* Function Name    : FVDT_update_Item_attributes                              */
/*                                                                             */
/*  Description     : Get the value from input file and update item            */
/*                                                                             */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*  Feb-2012      Saroj                   Changed atoi to normal string value  */
/*******************************************************************************/


int FVDT_update_Item_attributes(tag_t item, char ** Attributes)
{
      int          ifail             = ITK_ok;


      ITK(AOM_refresh(item,TRUE));

     if (Attributes[1]!=NULL && strlen(Attributes[1])!=0)
      ITK(AOM_set_value_string (item, FVDTCHSSymNamePROP, Attributes[1]));

      if (Attributes[2]!=NULL && strlen(Attributes[2])!=0)
      ITK(AOM_set_value_int  (item, FVDTCHSCavityNumPROP, atoi(Attributes[2])));

      /* Changed atoi to normal string value , 
        Attributes[3] is holding alphanumeric value
      */
      if (Attributes[3]!=NULL && strlen(Attributes[3])!=0)
      ITK(AOM_set_value_string  (item, object_namePROP, Attributes[3]));
      
      /*
      ** ITK(AOM_set_value_string  (item, object_namePROP, atoi(Attributes[3])));
      */

      if ( (Attributes[4]!=NULL && strlen(Attributes[4])!=0))
      ITK(AOM_set_value_string (item, FVDTCHSSubmergiblePROP, Attributes[4]));

      if ( (Attributes[5]!=NULL && strlen(Attributes[5])!=0))
      ITK(AOM_set_value_string (item, FVDTCHSRestrictedPROP, Attributes[5]));

      if ( (Attributes[6]!=NULL && strlen(Attributes[6])!=0))
      ITK(AOM_set_value_string (item, FVDTCHSEvalRatingPROP, Attributes[6]));

      if ( (Attributes[7]!=NULL && strlen(Attributes[7])!=0))
      ITK(AOM_set_value_double  (item, FVDTCHSMatForcePROP,atof( Attributes[7])));

      if (Attributes[8]!=NULL && strlen(Attributes[8])!=0 &&strcmp(Attributes[0],Attributes[8]) != 0)
      ITK(AOM_set_value_string (item, FVDTCHSReplacesPROP, Attributes[8]));

      if ((Attributes[9]!=NULL && strlen(Attributes[9])!=0))
      ITK(AOM_set_value_string (item, FVDTCHSServKitPartNumPROP, Attributes[9]));

      if ((Attributes[10]!=NULL && strlen(Attributes[10])!=0))
      ITK(AOM_set_value_string (item, FVDTCHSSpecPROP, Attributes[10]));


      if (save_object (item) != ITK_ok)
      {
         TC_write_syslog("ERROR in save_object item\n");

          return (!ITK_ok);
      }

      return (ifail);

}

/*******************************************************************************/
/* Function Name    : FVDT_add_reference_name                                  */
/*                                                                             */
/*  Description     :  Add the name reference to the dataset                   */
/*                                                                             */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

int FVDT_add_reference_name ( tag_t     file_tag,
                                       tag_t     dataset_tag)
{
    AE_reference_type_t reference_type;
    int                 ifail;
    char                refname[AE_reference_size_c + 1];
   char        *mod_name         ="FVDT_add_reference_name";

	if (g_debug) TC_write_syslog ("Entering :: %s\n", mod_name);

    /*
     * Add the referenced names to the dataset.
     */
    reference_type = AE_PART_OF;
    strcpy(refname, "Image");

    ifail = AE_add_dataset_named_ref (dataset_tag, refname,
                                           reference_type, file_tag);
    if (ifail != ITK_ok)
    {
        if (ifail == AE_reference_already_exists)
        {
            ifail = ITK_ok;
        }
        else
        {
            //TC_write_syslog ("ERROR %d add dataset named references.\n",
            //              ifail);
        }
    }


    return (ifail);
}

/*******************************************************************************/
/* Function Name    : FVDT_file_exists                                         */
/*                                                                             */
/*  Description     :  Checks if file with given filename exists or not        */
/*                                                                             */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

int FVDT_file_exists(char * filename)
{
   FILE * file ;
   file = fopen(filename, "r");
    if (file != NULL)
    {
        fclose(file);
        return (1);
    }
    return (0);
}
/*******************************************************************************/
/* Function Name    : FVDT_getFileName                                         */
/*                                                                             */
/*  Description     :  Get the valid filename. Next in order                   */
/*                                                                             */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

int FVDT_getFileName(  char ** filename)
{
   int          ifail             = ITK_ok;
   char			 *Path            = NULL;
	char			 *PathTmp         = NULL;
 	char			 *tmpFilename     = NULL;
   char           buf[3];
   char           to_string[4];
   int           i               = 0;

   //Path = getenv ( "TMP" );
   ITK(PREF_ask_char_value ("FVE_TMP_DIR", 0,  &Path));

   PathTmp = (char*)MEM_alloc((int) (strlen(Path) +1)*sizeof(char));
   strcpy(PathTmp, Path);

   if (g_debug) TC_write_syslog(" FVDT_getFileName %s", Path);


   do
   {
      i++;
      FVDT_FREE(tmpFilename);
      #ifdef UNX
     
         tmpFilename = (char*)MEM_alloc((int) (strlen(PathTmp)+(strlen("/Tc_tmpFilename000.png"))+6)*sizeof(char));
         strcpy (tmpFilename, PathTmp);
         tmpFilename=strcat(tmpFilename, "/Tc_tmpFilename");
         sprintf(to_string, "%d", i);
         tmpFilename=strcat(tmpFilename, to_string);

      #else
      
         tmpFilename = (char*)MEM_alloc((int) (strlen(PathTmp)+(strlen("\\Tc_tmpFilename000.png"))+6)*sizeof(char));
         strcpy (tmpFilename, PathTmp);
         tmpFilename=strcat(tmpFilename, "\\Tc_tmpFilename");
         tmpFilename=strcat(tmpFilename, itoa(i,buf,10));


      #endif

      tmpFilename=strcat(tmpFilename, ".png");
      if (g_debug) TC_write_syslog(" to_string %s", to_string);


   } while (FVDT_file_exists(tmpFilename));
   *filename= tmpFilename;
    FVDT_FREE(PathTmp);
    FVDT_FREE(Path);

    return (ITK_ok);


}



/*******************************************************************************/
/* Function Name    : FVDT_Reminder_Mail                                        */
/*                                                                             */
/*  Description     : Send TC mail to the owner of the object                  */
/*                                                                             */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*  Jan 2015      Binod                   Modified:Combine the email           */
/*                                        notification for DR and CA eng for   */
/*                                        for all the VP(s) together           */
/*******************************************************************************/


int FVDT_Reminder_Mail( tag_t connectorRev, char* connId, char* replaceBy,char *itemId, tag_t object)
{
	int				ifail						= ITK_ok;
	int				participantCount			= 0;
	int				vehProgramCount				= 0;
	int				vehprogCounter				= 0;
	int				participantTypeCount		= 0;
	tag_t			owningUser					= NULLTAG;
	tag_t*			vehPrograms					= NULL;	
	tag_t*			participants				= NULL;
	char			customSubject[ 1024]		={'\0'};
	char			customComment[ 1024]		={'\0'};
	char**			participantTypes			= NULL;

	int         iUniqueParticipants                     = 0;
	tag_t*      taUniqueParticipants                    = NULL;

	MAIL_to_or_cc_t to_or_cc;
	to_or_cc = MAIL_send_to;


	sprintf (customSubject, "The mating connector called out on your DT %s has been auto replaced by the connector library import utility", itemId);

	sprintf ( customComment , "Connector %s has been replaced by %s. A new revision of your DT %s has been released with the new mating connector.If you do not agree,contact the connector application engineer on your program.", connId, replaceBy, itemId);

	ITK(AOM_ask_owner(object, &owningUser))

	
	// Add participant types to the variable
	ITK (FV_copy_string_to_array (&participantTypeCount, &participantTypes, GDTConnectorEngineerTYPE))
	
	//Commented below
	//ITK (FV_copy_string_to_array (&participantTypeCount, &participantTypes, GDTSystemReviewerTYPE))
		
	// Get the vehicle programs in which DT is used
	ITK (FVDT_find_parent_veh_progs (object, &vehPrograms, &vehProgramCount))

	if(vehProgramCount == 0)
		goto CLEANUP;

	
	for (vehprogCounter = 0; vehprogCounter < vehProgramCount; vehprogCounter++)
	{
        tag_t subSysTag = NULLTAG;
		// Call the function to send notification
		participantCount = 0;

		ITK (FV_get_all_participants (vehPrograms[vehprogCounter], participantTypes, participantTypeCount, &participants, &participantCount))

		//Add only the unique tag to return array
		if(participants != NULLTAG)
			ITK( FV_add_unique_tags_to_array(&iUniqueParticipants, &taUniqueParticipants, participantCount, participants))

        //Also send notification to Sub-System Engineer
        ITK(FVDT_find_parent_subsystem_in_VP(vehPrograms[vehprogCounter], object, &subSysTag))
        if(subSysTag != NULLTAG)
        {
            tag_t   subSysOwner = NULLTAG;
            ITK(AOM_ask_owner(subSysTag, &subSysOwner))
            if(subSysOwner != NULLTAG)
            {
                ITK(FV_add_unique_tag_to_array(&iUniqueParticipants, &taUniqueParticipants, subSysOwner))
            }
        }

		// Deallocate memory
		FVDT_FREE (participants)
	}


		// Add the DT owner to the recipient list
		ITK (FV_add_unique_tag_to_array (&iUniqueParticipants, &taUniqueParticipants, owningUser))

	  if (g_debug) TC_write_syslog ("For Connector=%s, Parent DT=%s, Total Mail Recepient Count=%d\n", connId,itemId,iUniqueParticipants);

		// Send mail to recipients
		ITK (FV_send_notification_to_users (taUniqueParticipants, iUniqueParticipants, customSubject, customComment))

CLEANUP:
	// Deallocate memory
	FVDT_FREE (vehPrograms)
	FVDT_FREE_ARRAY (participantTypes, participantTypeCount)
	FVDT_FREE (taUniqueParticipants)

	return	ifail;
}

//New Mail send method for connector replacement
//This is to accomodate more data in the mail body as the Tc envelope
//has restriction on the mail comment
int FVDT_Reminder_Mail2(tag_t connectorRev, char* connId, char* replaceBy,char *itemId, tag_t object)
{
    int         ifail                           = ITK_ok;
    int         Process_id                      = 0;
    char*       custom_name                     = NULL;
    char*       custom_desc                     = NULL;
    char*       pref_val_htmlfile               = NULL;
    char*       file_path                       = NULL;
    char    	Processid_val[FV_INTEGER_LEN+1] = {'\0'};
    char*       dt_url                          = NULL;
    struct      stat stat_struct;
    FILE*       log_file_ptr                    = NULL;

    int				participantCount			= 0;
    int				vehProgramCount				= 0;
    int				vehprogCounter				= 0;
    int				participantTypeCount		= 0;
    tag_t			owningUser					= NULLTAG;
    tag_t*			vehPrograms					= NULL;	
    tag_t*			participants				= NULL;
    char**			participantTypes			= NULL;

    int         iUniqueParticipants                     = 0;
    tag_t*      taUniqueParticipants                    = NULL;

    CLEANUP(TC_tag_to_url(object, PORTAL, &dt_url))

    //Get the path for creating file from preference.
    CLEANUP(PREF_ask_char_value(FVE_TMP_DIR_PREF, 0, &pref_val_htmlfile))
    if(tc_strcmp(pref_val_htmlfile, "") == 0)
    {
        TC_write_syslog("+++ERROR: Preference %s doesn't exist\n", FVE_TMP_DIR_PREF);
        goto CLEANUP;
    }
    else if(stat(pref_val_htmlfile,&stat_struct) != 0)
    {
        TC_write_syslog("+++ERROR: The value set for FVE_TMP_DIR preference is invalid. 'Value' does not exist in your system. Please create the directory in the path specified or contact your System Administrator\n",FVE_TMP_IS_INVALID);
        goto CLEANUP;
    }

    Process_id =(int) getpid();
    sprintf(Processid_val, "%d", Process_id);

    FV_strdup("\"",&custom_name);
    FV_strcat(&custom_name , "The mating connector called out on your DT ");
    FV_strcat(&custom_name , itemId);
    FV_strcat(&custom_name , " has been auto replaced by the connector library import utility");
    FV_strcat(&custom_name , "\"");
    FV_strcat(&custom_name , "\0");

    FV_strdup("\n",&custom_desc);
    FV_strcat(&custom_desc , MAIL_HTML_SINGLE_LINE_BR);
    FV_strcat(&custom_desc , "Task Name: Connector ");
    FV_strcat(&custom_desc , connId);
    FV_strcat(&custom_desc , " has been replaced by ");
    FV_strcat(&custom_desc , replaceBy);
    FV_strcat(&custom_desc , MAIL_HTML_DOUBLE_LINE_BR);
    FV_strcat(&custom_desc , "A new revision of your DT ");
    FV_strcat(&custom_desc , itemId);
    FV_strcat(&custom_desc , " has been released with the new mating connector.");
    FV_strcat(&custom_desc , MAIL_HTML_DOUBLE_LINE_BR);
    FV_strcat(&custom_desc , "If you do not agree, contact the connector application engineer on your program.");
    FV_strcat(&custom_desc , "To identify your connector application engineer by selecting the vehicle program item revision -> Tools (in top menu bar) -> Assign Participants.");
    FV_strcat(&custom_desc , MAIL_HTML_DOUBLE_LINE_BR);
    FV_strcat(&custom_desc , "To View the DT, please see:");
    FV_strcat(&custom_desc , MAIL_HTML_SINGLE_LINE_BR);
    FV_strcat(&custom_desc , dt_url);

    //Make the file with unique name.
    FV_strdup(pref_val_htmlfile,&file_path);
    FV_strcat(&file_path,FV_FILEPATH_DELIMITER);
    FV_strcat(&file_path,Processid_val);
    FV_strcat(&file_path, "Email_conn_replace_notify.htm");
    FV_strcat(&file_path , '\0');

    ITK(AOM_ask_owner(object, &owningUser))
    
    // Add participant types to the variable
    ITK (FV_copy_string_to_array (&participantTypeCount, &participantTypes, GDTConnectorEngineerTYPE))
    
    // Get the vehicle programs in which DT is used
    ITK (FVDT_find_parent_veh_progs (object, &vehPrograms, &vehProgramCount))

    if(vehProgramCount == 0)
        goto CLEANUP;

    
    for (vehprogCounter = 0; vehprogCounter < vehProgramCount; vehprogCounter++)
    {
        tag_t subSysTag = NULLTAG;
        // Call the function to send notification
        participantCount = 0;

        ITK (FV_get_all_participants (vehPrograms[vehprogCounter], participantTypes, participantTypeCount, &participants, &participantCount))

        //Add only the unique tag to return array
        if(participants != NULLTAG)
            ITK( FV_add_unique_tags_to_array(&iUniqueParticipants, &taUniqueParticipants, participantCount, participants))

        //Also send notification to Sub-System Engineer
        ITK(FVDT_find_parent_subsystem_in_VP(vehPrograms[vehprogCounter], object, &subSysTag))
        if(subSysTag != NULLTAG)
        {
            tag_t   subSysOwner = NULLTAG;
            ITK(AOM_ask_owner(subSysTag, &subSysOwner))
            if(subSysOwner != NULLTAG)
            {
                ITK(FV_add_unique_tag_to_array(&iUniqueParticipants, &taUniqueParticipants, subSysOwner))
            }
        }

        // Deallocate memory
        FVDT_FREE (participants)
    }

        // Add the DT owner to the recipient list
        ITK (FV_add_unique_tag_to_array (&iUniqueParticipants, &taUniqueParticipants, owningUser))

      if (g_debug) TC_write_syslog ("For Connector=%s, Parent DT=%s, Total Mail Recepient Count=%d\n", connId,itemId,iUniqueParticipants);

    log_file_ptr =fopen(file_path, "w+");
    if(log_file_ptr == NULL) goto CLEANUP;
    fprintf(log_file_ptr,"%s\n","<html><BODY style=\"font-size:11pt;font-family:Calibri\">");
    fprintf(log_file_ptr," %s", custom_desc);
    fprintf(log_file_ptr," %s", "</BODY></HTML>");
    fclose(log_file_ptr);
    CLEANUP( FV_send_mail(&file_path, custom_name, taUniqueParticipants, iUniqueParticipants, NULL, 0))

CLEANUP:
    FVE_FREE(pref_val_htmlfile)
    FVE_FREE(custom_name)
    FVE_FREE(custom_desc)
    FVE_FREE(file_path)
    return ifail;
}


/*******************************************************************************/
/* Function Name    : FVDT_Import_File_Create_n_Relate_Dataset                 */
/*                                                                             */
/*  Description     : Import png file. Create dataset and relate file to       */
/*                    dataset                                                  */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/


int FVDT_Import_File_Create_n_Relate_Dataset( char *str, char *pngFileName, tag_t   *dataset_tag)
{

 	int	         ifail = ITK_ok;
   int           isFileExist = 0;
   int            tool_format_count;

   char          datasettype[AE_datasettype_name_size_c + 1];
   char         *dataset_format       = NULL;
   char         **tool_output_formats = NULL;
 	char			 *description       = NULL;
   
  	char			 *filenameExt        = NULL;
   tag_t        file_tag            = NULLTAG;
   tag_t        datasettype_tag     = NULLTAG;
   tag_t        default_tool_tag    = NULLTAG;

		TC_write_syslog("File path: %s ", pngFileName);


      if (pngFileName == NULL)
		  goto CLEANUP;

      filenameExt = (char*)MEM_alloc((int) (strlen(pngFileName)+6)*sizeof(char));                     
      strcpy (filenameExt, pngFileName);
      filenameExt=strcat(filenameExt, ".png");
		TC_write_syslog("filenameExt %s ", filenameExt);
	  isFileExist = FVDT_file_exists(filenameExt);

     //printf( " isFileExist %d  %s ", isFileExist, filenameExt );fflush(stdout);
      if (isFileExist == 0)
	  {
         fprintf (g_general_log,"No file found with name %s\n",filenameExt);
		   goto CLEANUP;
	  }

      /* Import the file and return a tag to the IMAN file */
      ITK(FVDT_import_file (str, filenameExt, &file_tag));
      if (ifail != ITK_ok )
      {
         fprintf(g_general_log, "ERROR file %s not found \n", filenameExt);
         goto CLEANUP;
      }
      else
          fprintf(g_general_log, "File %s Import successful \n", filenameExt);

      
      strcpy (datasettype, "Image");

      ITK(AE_find_datasettype (datasettype,   &datasettype_tag));
      if (ifail != ITK_ok)
      {
         fprintf(g_general_log, "ERROR %d finding datasettype \n", ifail);
         goto CLEANUP;
      }


      ITK(AE_ask_datasettype_def_tool (datasettype_tag, &default_tool_tag));
      if (ifail != ITK_ok )
      {
          fprintf(g_general_log, "ERROR %d getting dataset default tool \n", ifail);
          goto CLEANUP;
      }


      ITK(AE_ask_tool_output_formats(default_tool_tag, &tool_format_count, &tool_output_formats));
      if (ifail != ITK_ok)
      {
          fprintf(g_general_log, "ERROR %d getting dataset tool output formats \n", ifail);
          goto CLEANUP;
      }

      if (!tool_format_count )
      {
          fprintf(g_general_log, "ERROR %d %s has no tool output format \n", ifail, datasettype);
          goto CLEANUP;
      }

      if ( tool_output_formats!=NULL)
      {
         dataset_format = (char *)MEM_alloc( (strlen(tool_output_formats[0]) + 1) * sizeof(char));
         strcpy (dataset_format, tool_output_formats[0]);
      }

      ITK(FVDT_create_dataset (str, datasettype_tag, dataset_format, description, default_tool_tag, dataset_tag));
      if ( ifail!= ITK_ok)
      {
          fprintf(g_general_log, "ERROR %d %s while creating dataset for Item  \n", ifail, str);
          goto CLEANUP;
      }
      else
          fprintf(g_general_log, "Dataset created for Item %s\n", str);


      ITK(FVDT_add_reference_name ( file_tag, *dataset_tag));
      if ( ifail != ITK_ok )
      {
         fprintf(g_general_log, "ERROR %d %s while adding file reference to dataset %s \n", ifail, str);
         goto CLEANUP;
      }
      else
         fprintf(g_general_log, "File reference added to dataset for item\n", ifail, str);

      ITK(save_object (*dataset_tag));
      if ( ifail != ITK_ok)
      {
         fprintf(g_general_log, "Error %d while save_object dataset_tag of itme %s\n", ifail, str);
         goto CLEANUP;
      }

CLEANUP:

   if (filenameExt!=NULL)
   {
       FVDT_FREE(filenameExt);
   }

   if (dataset_format!=NULL)
      FVDT_FREE(dataset_format);
   if (tool_output_formats!=NULL)
      FVDT_FREE (tool_output_formats);

return	ifail;

}

/*******************************************************************************/
/* Function Name    : FVDT_Relate_Item_Datset                                  */
/*                                                                             */
/*  Description     : Create realtion between Item and dataset                 */
/*                                                                             */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*******************************************************************************/

int FVDT_Relate_Item_Datset(char *str, tag_t  dataset_tag, tag_t  rev )
{

 	int	       ifail = ITK_ok;
   tag_t        grm_type_tag        = NULLTAG;
   tag_t        rel_tag             = NULLTAG;


   ITK(GRM_find_relation_type (TC_specification_rtype,&grm_type_tag));
   if (ifail != ITK_ok)
   {
       fprintf(g_general_log, "ERROR %d finding relation type for item .\n", ifail, str);
       goto CLEANUP;
   }

   ITK(AOM_refresh(dataset_tag,TRUE));
   if (ifail != ITK_ok)
   {
       fprintf(g_general_log, "ERROR %d Dataset AOM_refresh. for item .\n", ifail, str);
       goto CLEANUP;
   }

   ITK(AOM_refresh(rev,TRUE));
   if (ifail != ITK_ok )
   {
       fprintf(g_general_log, "ERROR %d Item Revision AOM_refresh for item .\n", ifail, str);
       goto CLEANUP;
   }

   ITK(GRM_create_relation (rev,dataset_tag,grm_type_tag,NULLTAG,&rel_tag));
   if (ifail != ITK_ok)
   {
       fprintf(g_general_log, "ERROR %d create relation for item 5s and dataset .\n", ifail, str);
       goto CLEANUP;
   }
   else
       fprintf(g_general_log, "Dataset - Item %s relation created.\n", str);

   ITK(AOM_save(rel_tag));
   if (ifail != ITK_ok )
   {
       fprintf(g_general_log, "ERROR %d saving relation between dataset and item %s\n", ifail, str);
       goto CLEANUP;
   }

   ITK(GRM_save_relation(rel_tag));
   if (ifail != ITK_ok)
   {
       fprintf(g_general_log, "ERROR %d saving relation between dataset and item %s\n", ifail, str);
       goto CLEANUP;
   }  

CLEANUP:

return	ifail;


}
static int FV_ITEM_create_item1(const char* itemId, const char* itemName, const char* itemType,const char* revId,tag_t* itemTag, tag_t* revTag)
{
	tag_t	itemTypeTag				= NULLTAG,
			itemCreateInputTag		= NULLTAG;
	int     ifail					= ITK_ok;
	 TC_write_syslog("FV_ITEM_create_item1 Entry Point\n");
	/*	To find the type of item 	*/
	ITK(TCTYPE_find_type(itemType,  "Item", &itemTypeTag))
	if(itemTypeTag==NULLTAG)
	{
		TC_write_syslog("FV_ITEM_create_item1 : ItemType Not Found\n"); 
	}
	/*	To get the tag to hold the data for input object creation	*/
	ITK(TCTYPE_construct_create_input (itemTypeTag, &itemCreateInputTag))
	if(itemCreateInputTag==NULLTAG)
	{
		TC_write_syslog("FV_ITEM_create_item1 : itemCreateInputTag Not Found\n"); 
	}
	/*	To set the item name display value	*/
	ITK(TCTYPE_set_create_display_value(itemCreateInputTag, "object_name", 1, &itemName))
	if(tc_strlen(itemId)>0)
	{
		ITK(TCTYPE_set_create_display_value(itemCreateInputTag, "item_id" , 1, &itemId));
	}
	if(itemName==NULL)
	{
		TC_write_syslog("FV_ITEM_create_item1 : itemName Not Found\n"); 
	}
	/*	To create item object 	*/
	ITK(TCTYPE_create_object(itemCreateInputTag, itemTag ))
	if(*itemTag==NULLTAG)
	{
		TC_write_syslog("FV_ITEM_create_item1 : itemName Not Found\n"); 
	}
	/*	To save the object tag	*/
	ITK(AOM_save(*itemTag))
	/*	To ask the latest revision attached to the object tag	*/
	ITK(ITEM_ask_latest_rev(*itemTag, revTag))
	
	TC_write_syslog("FV_ITEM_create_item1 Exit Point\n");
	return ITK_ok;
}
/*******************************************************************************/
/* Function Name    : FVDT_create_connector_and_dataset                        */
/*                                                                             */
/*  Description     : Create connector and dataset                             */
/*                                                                             */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/* NOTES                                                                       */
/*                                                                             */
/*  Date          Author                 Change Description                    */
/* ----------     -------------------    -----------------------------         */
/*  Mar 2010      Vishal                  Created                              */
/*  3-Oct-2016       Karthik              VSEM4.0: Modified the code to replace deprecated API's 
/*******************************************************************************/

int FVDT_create_connector_and_dataset(char *str, char *item_name, char *item_type, char **Attributes, char *pngFileName )
{

  	int	       ifail = ITK_ok;
 	char			 *rev_id             = NULL;

	tag_t			 item                = NULLTAG;
	tag_t			 rev                 = NULLTAG;
   tag_t        dataset_tag         = NULLTAG;
   char         *mod_name           ="FVDT_create_connector_and_dataset"; 

	if (g_debug) TC_write_syslog ("Entering :: %s\n", mod_name);
	
	TC_write_syslog ("png file pat name  %s\n", pngFileName);
      
      
   //ITK(ITEM_create_item (str, item_name,item_type, rev_id, &item, &rev));//Deprecated
   ITK(FV_ITEM_create_item1 (str, item_name,item_type, rev_id, &item, &rev));//Deprecated
   if (ifail != ITK_ok)
   {
      fprintf(g_general_log, "ERROR while creating Item with partnumber  %s \n", str);
      goto CLEANUP;
   }
   else
      fprintf(g_general_log, "Item Created with Partnumber  %s \n", str);

   ITK(AOM_refresh(item,TRUE));

   ITK(AOM_set_value_string (item, object_descPROP, "+++ Imported from CHS Connector Library +++"));


   if (save_object (item) != ITK_ok)
   {
      TC_write_syslog("ERROR in save_object item\n");
      fprintf(g_general_log, "ERROR while updating the Item %s  with description \n", str);

       return (!ITK_ok);
   }


   if (rev!=NULLTAG)
   {
      /*Update item with other attributes from file*/
      ITK( FVDT_update_Item_attributes(rev, Attributes));
      if (ifail != ITK_ok)
      {      
           fprintf(g_general_log, "ERROR %d on update of item %s \n", ifail, str);
           goto CLEANUP;
      }
      else
           fprintf(g_general_log, "Item %s attributes value got updated \n", str);


      ITK(AOM_refresh(item,TRUE));
      if (ifail != ITK_ok )
      {
          fprintf(g_general_log, "ERROR %d on Item %s refresh.\n", ifail, str);
          goto CLEANUP;
      }
	  TC_write_syslog ("Before create dtaset\n");
      ITK(FVDT_Import_File_Create_n_Relate_Dataset( str, pngFileName, &dataset_tag));
	  TC_write_syslog ("After Create dataset\n");

      if (dataset_tag!=NULLTAG)
      {
	  TC_write_syslog ("Bfore datset Relation\n");
        ITK(FVDT_Relate_Item_Datset(str, dataset_tag, rev ));
		TC_write_syslog ("After Dataset relation\n");
      }
   }


CLEANUP:

   return	ifail;
}

/*******************************************************************************/
/* Function Name    : FVDT_import_relate_file_to_dataset                        */
/*                                                                              */
/* Description      : Import the file and create relation with given dataset    */
/*                                                                              */
/* Return Value     : (int)  ITK_ok  successful completion.                     */
/*                           !ITK_ok unsuccessful completion.                   */
/* NOTES                                                                        */
/*                                                                              */
/*  Date          Author                 Change Description                     */
/* ----------     -------------------    -----------------------------          */
/*  Mar 2010      Vishal                  Created                               */
/*******************************************************************************/

int FVDT_import_relate_file_to_dataset( char *str,  char *filenameExt, tag_t dataset_tag)
{

   int	         ifail              = ITK_ok;
   tag_t          file_tag          = NULLTAG;

  /* Import the file and return a tag to the IMAN file */
   ITK(FVDT_import_file (str, filenameExt, &file_tag));
   if (ifail != ITK_ok )
   {
      fprintf(g_general_log, "ERROR file %s not found \n", filenameExt);
      goto CLEANUP;
   }
   else
       fprintf(g_general_log, "File %s Import successful \n", filenameExt);

   if ( file_tag!= NULLTAG)
   {
      ITK(AOM_refresh(dataset_tag, TRUE));

      ITK(FVDT_add_reference_name ( file_tag, dataset_tag));
      if ( ifail != ITK_ok )
      {
         fprintf(g_general_log, "ERROR %d %s while adding file reference to dataset %s \n", ifail, str);
         goto CLEANUP;
      }
      else
         fprintf(g_general_log, "File reference added to dataset for item\n", ifail, str);

      ITK(save_object (dataset_tag));
      if ( ifail != ITK_ok)
      {
         fprintf(g_general_log, "Error %d while save_object dataset_tag of itme %s\n", ifail, str);
         goto CLEANUP;
      }
   }

CLEANUP:


return	ifail;

}


/*******************************************************************************/
/* Function Name    : FVDT_update_connector_and_dataset                         */
/*                                                                              */
/*  Description     : Update connector with  attribute value from input file.   */
/*                    Compair the checksum of given file and file attached with */
/*                    dataset. Update the dataset with new file if there is     */
/*                    is difference in checksum                                 */
/*                                                                              */
/*                                                                              */
/* Return Value     : (int)  ITK_ok  successful completion.                     */
/*                           !ITK_ok unsuccessful completion.                   */
/* NOTES                                                                        */
/*                                                                              */
/*  Date          Author                 Change Description                     */
/* ----------     -------------------    -----------------------------          */
/*  Mar 2010      Vishal                  Created                               */
/*******************************************************************************/


int FVDT_update_connector_and_dataset(char *str,tag_t rev,char **Attributes, char *pngFileName )
{

   int	         ifail              = ITK_ok;
   int            inx               = 0;
   int            count1            = 0;
   int            nFound            = 0;

   tag_t			   *relatedObjs      = NULL;
   tag_t			   *refObjs          = NULL;

   tag_t          relation_tag      = NULLTAG;
   tag_t          objTypeTag        = NULLTAG;
   tag_t          file_tag          = NULLTAG;
   tag_t          dataset_tag       = NULLTAG;
   tag_t          refObj            = NULLTAG;

   char           className[TCTYPE_name_size_c+1];
 	char			   *tmpFilename       = NULL;
 	char			   *filenameExt       = NULL;
   char           refname[AE_reference_size_c + 1];
   AE_reference_type_t reference_type;
   int            metadataUpdated = 0;
   int            fileUpdated = 0;
   int            isFileExist = 0, isImageDSetExist = 0;

   unsigned int checkSumDataSet  ;
   unsigned int checkSumLocal  ;
   char         *mod_name           ="FVDT_update_connector_and_dataset"; 

	if (g_debug) TC_write_syslog ("Entering :: %s\n", mod_name);

   ifail = FVDT_compare_and_update_attribute(str, rev, Attributes, &metadataUpdated);

   if (ifail != ITK_ok)
   {
       goto CLEANUP;
   }

   filenameExt = (char*)MEM_alloc((int) (strlen(pngFileName)+6)*sizeof(char));                     
   strcpy (filenameExt, pngFileName);
   filenameExt=strcat(filenameExt, ".png");

   if (skipFileCheck == 1)
	   goto CLEANUP;

   isFileExist = FVDT_file_exists(filenameExt);
   if (isFileExist == 0)
   {
	   fprintf (g_general_log,"WARNING: No file found with name %s\n", filenameExt);
	   goto CLEANUP;
   }

   ifail = GRM_find_relation_type(TC_specification_rtype, &relation_tag);
   if (ifail != ITK_ok)
   {
       fprintf(g_general_log, "ERROR %d while finding relation type for item %s\n", ifail, str);
       goto CLEANUP;
   }

   ITK( GRM_list_secondary_objects_only(rev, relation_tag, &count1, &relatedObjs));
   if (ifail != ITK_ok)
   {
       fprintf(g_general_log, "ERROR %d while getting secondary objects for item %s\n", ifail, str);
       goto CLEANUP;
   }
  
   for (inx = 0; inx < count1; inx++)
   {
      if( relatedObjs[inx] != NULLTAG)
      {
         ITK(TCTYPE_ask_object_type(relatedObjs[inx],&objTypeTag));
         if (ifail != ITK_ok)
         {
             fprintf(g_general_log, "ERROR %d while getting secondary objects type. Primary object is %s\n", ifail, str);
             goto INNER_CLEANUP;
         }       

         if(objTypeTag != NULLTAG)
         {
            TCTYPE_ask_name(objTypeTag,className);
         }
         if ( tc_strcmp(className,"Image") == 0 )
         {
            isImageDSetExist = 1;
            FVDT_getFileName(&tmpFilename);



            ITK(AE_ask_dataset(relatedObjs[inx], &dataset_tag));

            ITK(AOM_refresh(dataset_tag, TRUE));
            reference_type = AE_PART_OF;
            ITK(AE_ask_dataset_named_refs (dataset_tag, &nFound, &refObjs));
            if (ifail != ITK_ok)
            {
                fprintf(g_general_log, "ERROR %d while getting the dataset name ref for item %s.\n", ifail, str);
                goto INNER_CLEANUP;
            }           
                        
            if ( nFound > 0)
            {
               refObj = refObjs [0];            
               ITK(AE_export_named_ref (relatedObjs[inx], "Image", tmpFilename ));
               if (ifail != ITK_ok)
               {
                   fprintf(g_general_log, "ERROR %d while exporting name ref. Primary object is %s\n", ifail, str);
                   goto INNER_CLEANUP;
               }       

               FVDT_Get_CheckSum (tmpFilename, &checkSumDataSet);
               FVDT_Get_CheckSum (filenameExt, &checkSumLocal);

               if ( checkSumDataSet != checkSumLocal)
               {
                  /*ITK(AM_check_privilege (dataset_tag, "WRITE", &matchFound));

                  if (matchFound == false)
                  {
                     fprintf(g_general_log, "ERROR %d User does not have write access on dataset for item %s \n", ifail, str);
                     goto INNER_CLEANUP;
                  }*/

                  fprintf(g_general_log, "File %s is modified \n", filenameExt);
                  fileUpdated = 1;
                  strcpy(refname, "Image");
                  
                  if (ifail != ITK_ok)
                  {
                      fprintf(g_general_log, "ERROR %d while getting the dataset for item %s.\n", ifail, str);
                      goto INNER_CLEANUP;
                  }


                  if (g_debug) TC_write_syslog(" checkSumDataSet != checkSumLocal");
                  ITK(FVDT_import_file ( str, filenameExt, &file_tag));
                  if (ifail != ITK_ok)
                  {
                      fprintf(g_general_log, "ERROR %d while importing the file %s.\n", ifail, filenameExt);
                      goto INNER_CLEANUP;
                  }
                  else
                      fprintf(g_general_log, "File %s imported\n", filenameExt);

                  ITK(AOM_refresh(dataset_tag, TRUE));

                  ITK(AE_replace_dataset_named_ref (dataset_tag, refObj, refname, reference_type, file_tag));

                  if (ifail != ITK_ok)
                  {
                      fprintf(g_general_log, "ERROR %d while replacing the old file with new file %s.\n", ifail, filenameExt);
                      goto INNER_CLEANUP;
                  }
                  else
                      fprintf(g_general_log, "Old file is replaced by new file %s in dataset  \n",  filenameExt);

                  ITK(AOM_save(dataset_tag));
                  ITK(AOM_refresh(dataset_tag, FALSE));

               }
               else
               {
                  if (g_debug) TC_write_syslog(" checkSumDataSet == checkSumLocal");
                  fprintf(g_general_log, "File %s is not changed \n", filenameExt);
               }
               /*Delete the temporary png file*/
               if ( remove (tmpFilename) )
               {
                  if (g_debug) TC_write_syslog(" Error: Deleteing the temporary file");
               }
            }
            else /* If there is no file attached to dataset then attach the latest image file*/
            {
               printf("import file is attached to dataset");fflush(stdout);
               ITK(FVDT_import_relate_file_to_dataset( str,  filenameExt,  dataset_tag));

            }
         }
      }
      /*Memory cleanup within for loop*/
      INNER_CLEANUP:

		 ifail = ITK_ok;
         if (g_debug) TC_write_syslog(" tmpFilename\n");
         if (tmpFilename!=NULL)
            FVDT_FREE(tmpFilename);

         if (g_debug) TC_write_syslog(" filenameExt\n");

   

         if (g_debug) TC_write_syslog(" refObjs\n");

         if (refObjs!=NULL)
            free(refObjs);

         if (g_debug) TC_write_syslog(" after refObjs\n");
   }

   if (isImageDSetExist == 0)
   {
      ITK(FVDT_Import_File_Create_n_Relate_Dataset( str, pngFileName, &dataset_tag));
      if (dataset_tag != NULLTAG)
      {
         ITK(FVDT_Relate_Item_Datset(str, dataset_tag, rev ));
      }
   }

CLEANUP:

   if(relatedObjs)
      free(relatedObjs);
   
      FVDT_FREE(tmpFilename);
   
      FVDT_FREE(filenameExt);

      FVDT_FREE(refObjs);

	  if (filenameExt!=NULL)
        FVDT_FREE(filenameExt);


	  if (ifail == 0)
	  {
		  if (metadataUpdated || fileUpdated)
		  {
			  fprintf (g_success_log,"%s\n",str);
			  g_no_of_successes++;
		  }
		  else
		  {
			  fprintf (g_unchanged_log,"%s\n",str);
			  g_no_of_unchanged++;
		  }
	  }
               
return	ifail;

}


char * FVDT_replace(char *st, char *orig, char *repl) {
  static char buffer[4096];
  char *ch;
  if ((ch = strstr(st, orig)) == NULL)
     return st;
    strncpy(buffer, st, ch-st);  
    buffer[ch-st] = 0;
    sprintf(buffer+(ch-st), "%s%s", repl, ch+strlen(orig));
    return buffer;
}





/* ------------------------------------------------------- */
/* Function: not_blank_line                                */
/* ------------------------------------------------------- */
/* Determines if the input command line is blank.          */
/*                                                         */
/* Return Value: TRUE  if the line is not blank.           */
/*               FALSE if the line is non alphanumeric.    */
/* ------------------------------------------------------- */
int not_blank_line (char *command_line)
{
    int length, i;

    length = strlen (command_line);
    for (i=0; i < length; i++)
    {
        if (isalnum (command_line[i]))
        {
            return TRUE;
        }
    }
    return FALSE;
}

/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                    */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */                                                                          
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  10/21/2004      Ramesh Ramaiah            Initial Creation              */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;
    
    
    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        if( g_general_log )
            fprintf( g_general_log,"ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        if( g_general_log )
        fprintf( g_general_log, "ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);
    
    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        if( g_general_log )
            fprintf( g_general_log,"ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }
    
    //DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;
    
    return ifail;
        
}
/*******************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *
 * Usage:

 *
 * ARGUMENTS
 *   user               In     User name
 *   passward           In     Password
 *   group              In     Group
 *   filename           Out    Input file name
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 *  Mar 2010      Vishal                  Created             
 *
 ******************************************************************************/

int ITK_user_main (int argc, char *argv[])
{
   int          ifail             = ITK_ok;

   int          num              = 0;
	char         line[MAXINPUTLINELEN + 1]        ;//= NULL;
   char         *usr             = NULL;
   char         *upw             = NULL;
   char         *upwf             = NULL;
   char         *ugp             = NULL;
	char			 *inputfile       = NULL;
	char			 *inputDir        = NULL;
	char			 **Attributes     = NULL;
	char			 *str             = NULL;
	char			 *oldConnectorPartNumStr = NULL;
	char			 *item_name       = NULL;
	char			 *item_type       = NULL;
	char			 item_type_tmp    [33];
	char			 *pngFileName     = NULL;
	char			 *pngFullFileName = NULL;
	char			 *filenameExt     = NULL;
   int          count = 0, inx =0;
   int          n_parents      = 0;
   int          *levels         ;
   int          fileidx = 0; 

   tag_t			 *item_tags       = NULL;
   tag_t			 *parents         = NULL;

	tag_t			 rev              = NULLTAG;
	FILE         *fp              = NULL;

	/* Get the input arguments */
   usr = ITK_ask_cli_argument("-u=");/* gets user */
   upw = ITK_ask_cli_argument("-p=");/* gets the password */
   upwf = ITK_ask_cli_argument("-pf=");/* gets the password file*/
   ugp = ITK_ask_cli_argument("-g=");/* gets the password */
   inputfile = ITK_ask_cli_argument("-f=");/* get the input file name */
   inputDir = ITK_ask_cli_argument("-dir=");/* get the input file name */

    if( ITK_ask_cli_argument( "-skipfile" ) )
    {
        skipFileCheck = 1;
    }

   /* Check input arguments */
   if ((!inputfile) || (!inputDir))
   {
      dousage();
      return !ITK_ok ;
   }

   /* Check password arguments arguments */
   /*if ((!upw) && (!upwf) )
   {
      dousage();
      return !ITK_ok ;
   }*/
    /*-----------------------------------------------*/
    /* -debug flag indicates DEBUG to be turned ON   */
    /*-----------------------------------------------*/
    if( ITK_ask_cli_argument( "-debug" ) )
    {
        g_debug = 1;
    }
	/*-------------------------------------------*/
    /*          Create log files                 */
    /*-------------------------------------------*/
    if( ( ifail = FVDT_create_log_files() ) != ITK_ok )
    {
        TC_write_syslog("ERROR: FVDT_create_log_files failed to create log files\n");
        goto EXIT;
    }

	/*-------------------------------------------*/
    /*          Decrypt the password             */
    /*-------------------------------------------*/
   if( upwf != 0 )
   {                                        
      readAndDecryptPasswd( upwf, &upw) ;  
   }
    
    if( g_debug ) fprintf( g_general_log, "Debug: ON\n\n");
    else fprintf( g_general_log, "Debug: OFF \n\n");

   /*  Initialize text services  */
   ITK(ITK_initialize_text_services (ITK_BATCH_TEXT_MODE) );
   ITK(ITK_init_module( usr,upw,ugp));
   
   if ( usr != NULL && strlen(usr)!=0  &&  upw != NULL && strlen(upw)!=0 &&  ugp != NULL && strlen(ugp)!=0)
   {
      ITK(ITK_init_module( usr,upw,ugp));
      if(ifail != ITK_ok)
         fprintf(g_general_log,"Login with uid: %s, group:%s is unsuccessful\n", usr, ugp);
      
   }
   else
   {      
      ITK (ITK_auto_login ())
      if(ifail != ITK_ok)
         fprintf(g_general_log,"Auto Login unsuccessful\n");
   }  


    if (!FVDT_file_exists(inputfile))
   {
  		TC_write_syslog("Cannot find input file %s.\n",inputfile);
      fprintf(g_general_log, "Cannot find input file %s.\n" ,inputfile);
		return !ITK_ok;

   }
	
   /* Open the input dataset file */
	if ((fp = fopen(inputfile,"r"))== NULL)
	{
		TC_write_syslog("Can not able to open the input file %s.\n",inputfile);
      fprintf(g_general_log, "Can not able to open the input file %s\n",inputfile);
		return !ITK_ok;
	}

   item_type = (char*)MEM_alloc((int) (strlen("FVDTMatConn")+1)*sizeof(char));      
   strcpy(item_type, "FVDTMatConn");

	/* Read the input file and get the dataset names */

    for ( fileidx = 1; !feof (fp) && ifail == ITK_ok; fileidx++ )
    {
        /* If there is an input line */
        if ( fgets (line, MAXINPUTLINELEN, fp) != NULL )
        {
            if (not_blank_line ( line ))
            {
                count = 0;
                FVDT_String_to_StringArray(line, &Attributes, "|", &count);

               if (count != 11)
               {
                  TC_write_syslog ("ERROR: Invalid File -> Expecting 12 properties but there are %d\n", count);
				  fprintf(g_general_log, "ERROR: Invalid File -> Expecting 12 properties but there are %d\n", count);
                  FVDT_FREE_ARRAY( Attributes, count);
                  ifail = !ITK_ok; /* No need to process further */
                  continue;
               }
               if (Attributes[0]!=NULL && strlen(Attributes[0])<1)
               {
                  TC_write_syslog ("ERROR: Item Id is missing \n");
				  fprintf(g_general_log, "ERROR: Item Id is missing \n");
                  FVDT_FREE_ARRAY( Attributes, count);
                  //ifail = !ITK_ok; /* No need to process further */
                  continue;
               }

               if ((strcmp(Attributes[0], "PARTNUMBER")== 0) && (strcmp(Attributes[1], "SYMBOLNAME")) ==0 )
               {
                  /* It is a header line that need not to be processed */
                  TC_write_syslog ("File format :: %s\n", line);
                  FVDT_FREE_ARRAY( Attributes, count);
                  continue;
               }

                /*Replace XXX from Part number */
                if (strstr(Attributes[0], "__XXX_")!=NULL)
                {
                    ITK(STRNG_replace_str ( Attributes[0], "__XXX_", "", &str ));
                }
                else if (strstr(Attributes[0], "_XXX_")!=NULL)
                {
                   ITK(STRNG_replace_str ( Attributes[0], "_XXX_", "", &str ));
                }
                else
                {
                   str = (char*)MEM_alloc(sizeof(char)*( (int) strlen (Attributes[0])+1));
                   strcpy(str, Attributes[0]); 
                }

                /*Replace XXX from File name */
				/* No need to check xxx 
                if ((tmpStr = strstr(Attributes[1], "__xxx_"))!=NULL)
                {
                   ITK(STRNG_replace_str ( Attributes[1], "__xxx_" , "", &pngFileName ));
                }
                else if ( (tmpStr = strstr(Attributes[1], "_xxx_"))!=NULL)
                {
                   ITK(STRNG_replace_str ( Attributes[1], "_xxx_" , "", &pngFileName ));
                }
                else
                {
				*/
                   pngFileName = (char*)MEM_alloc(sizeof(char)*( (int) strlen (Attributes[1])+1));
                   strcpy(pngFileName, Attributes[1]);
					TC_write_syslog("Item Not Found\n");
			   /*
                }
				*/

                pngFullFileName = (char*)MEM_alloc((int) (strlen(inputDir) + strlen(pngFileName)+3)*sizeof(char));      
                strcpy(pngFullFileName, inputDir);
                #ifdef UNX
                strcat(pngFullFileName, "/");
                #else
                strcat(pngFullFileName, "\\");
                #endif

                strcat(pngFullFileName, pngFileName);

                fprintf(g_general_log, "Processing for Partnumber %s starts\n", str);         
                item_name = (char*)MEM_alloc((int) (strlen(Attributes[3])+1)*sizeof(char));      
                strcpy(item_name, Attributes[3]);

		        g_total_processed++;

                ITK(FVDT_find_item(str,  &item_tags, &num));

                /*If item does not exist*/
                if(num == 0 || item_tags == NULL)
                {
                      if (g_debug) TC_write_syslog("Item Not Found\n");
                      fprintf(g_general_log, "Item ID match NOT found\n");
                      if (g_debug) fprintf(g_general_log, "Creating Connector and Dataset\n");
                      ITK( FVDT_create_connector_and_dataset(str, item_name, item_type, Attributes, pngFullFileName ));
                      if (ifail!= ITK_ok)
                      {
                         fprintf(g_failure_log, "%s\n", str);
				             g_no_of_failures++;
                         ifail= ITK_ok;
                      }
                      else
                      {
                          filenameExt = (char*)MEM_alloc((int) (strlen(pngFullFileName)+6)*sizeof(char));                     
                          strcpy (filenameExt, pngFullFileName);
                          filenameExt=strcat(filenameExt, ".png");

                         if (FVDT_file_exists(filenameExt))
                          fprintf(g_success_log, "%s\n", str);
                         else
                          fprintf(g_success_log, "%s||No symbol file found for import \n", str);                         
                         g_no_of_successes++;

                       	 if (filenameExt!=NULL)
                           FVDT_FREE(filenameExt);

                      }
                      if (g_debug) TC_write_syslog("After FVDT_create_connector_and_dataset \n");        
               }
               else // Item exist
               {
                      if (g_debug) TC_write_syslog("Item Found %d.\n",num);
                      fprintf(g_general_log, "Item ID match found\n");
                      ITK(ITEM_ask_type (item_tags[0], item_type_tmp));
                      if ( strcmp(item_type_tmp, item_type)!=0 )
                      {
                          fprintf(g_general_log, "ERROR %d Item Type of item %s found is not FVDTMatConn \n", ifail, str);
                          continue;
                      }                     

			             ITK(ITEM_ask_latest_rev (item_tags[0], &rev)); 
                      if ( ifail!= ITK_ok)
                      {
                          fprintf(g_general_log, "ERROR %d while getting latest revision of Item %s\n", ifail, str);
                      }

/*
                      ITK(AM_check_privilege (rev, "WRITE", &matchFound));
            			 if (matchFound == false)
                      {
                         fprintf(g_general_log, "ERROR %d User does not have write access on latest revision of Item %s \n", ifail, str);
                         continue;
                      }
*/

                      if (g_debug)  fprintf(g_general_log, "Updating Connector and Dataset\n");
 		      		  AM__set_application_bypass(true) ;
                      ITK(FVDT_update_connector_and_dataset(str, rev, Attributes, pngFullFileName ));
		      		  AM__set_application_bypass(false) ;

                      if (ifail!= ITK_ok)
                      {
                          fprintf(g_failure_log, "%s\n", str);
				              g_no_of_failures++;
                          ifail= ITK_ok;
                      }
                      FVDT_FREE(item_tags);
                }

				/* Process the "Replaces" field to delete/update/send notification
				    DELETE - If old connector is not used in any DT
					UPDATE - Update REPLACED_BY field of old connector if used in any DT and
					         Send the notification to program team.
			     */
				if ((Attributes[8]!=NULL)&& (strlen(Attributes[8])!=0) &&(strcmp(Attributes[0],Attributes[8] )!=0)) // if replaces is not null
                {
					 /*Replace XXX from Part number */
                     if (strstr(Attributes[8], "__XXX_")!=NULL)
                     {
                          ITK(STRNG_replace_str ( Attributes[8], "__XXX_", "", &oldConnectorPartNumStr ));
                     }
                     else if (strstr(Attributes[8], "_XXX_")!=NULL)
                     {
                          ITK(STRNG_replace_str ( Attributes[8], "_XXX_", "", &oldConnectorPartNumStr ));
                     }
                     else
                     {
                          oldConnectorPartNumStr = (char*)MEM_alloc(sizeof(char)*( (int) strlen (Attributes[8])+1));
                          strcpy(oldConnectorPartNumStr, Attributes[8]); 
                     }

				   //Added in VSEM 2.2.2 - CR#12799762
				   //Ignore processing If Mating Connector Item ID (after removing XXX) matches with Replaces Item ID (after removing XXX)
					if(strcmp(str,oldConnectorPartNumStr) == 0)
					{
						  fprintf(g_general_log, "WARNING:No Processing for Partnumber %s , because its partnumber matches with Replaces partnumber.\n\n", str);
                          continue;
					}

                   ITK(FVDT_find_item(oldConnectorPartNumStr,  &item_tags, &num));
                   if(num != 0 )
                   {
                      
					  //Added to verify Replaces Item Type
                      if (g_debug) TC_write_syslog("Replaces Item Found  = %d.\n",num);
                      fprintf(g_general_log, "Replaces Item ID match found\n");
                      ITK(ITEM_ask_type (item_tags[0], item_type_tmp));

                      if ( strcmp(item_type_tmp, item_type)!=0 )
                      {
                          fprintf(g_general_log, "ERROR %d Item Type of Replaces Item %s found is not FVDTMatConn\n", ifail, oldConnectorPartNumStr);
                          continue;
                      }

                      //Addition Ends
					  
					  ITK(ITEM_ask_latest_rev (item_tags[0], &rev));
                      ITK(PS_where_used_all (rev, 1, &n_parents, &levels, &parents));

					  if (n_parents == 0)
					  {
						  /* First attempt to delete an old connector */
						  ITK (ITEM_delete_item (item_tags[0]));
						  
						  /* If there is a failure in deleting old connector then set the REPLACED BY field and STATUS Field */
						  if (ifail != ITK_ok)
						  {
							  fprintf(g_general_log, "ERROR %d deleting the old connector %s \n", ifail, oldConnectorPartNumStr);
							  ifail = ITK_ok;
							  AM__set_application_bypass(true) ;
							  ITK (AOM_refresh (rev, TRUE));
							  ITK (AOM_set_value_string (rev, FVDTCHSStatusPROP, "OBSOLETE"));
							  ITK (AOM_set_value_string (rev, FVDTCHSReplacedByPROP, str));
							  ITK (AOM_save (rev));
							  ITK (AOM_refresh (rev, FALSE));
							  AM__set_application_bypass(false) ;
						  }
						  else
						  {
							  fprintf(g_general_log, "Successfully deleted the old connector %s \n", oldConnectorPartNumStr);
						  }

					  }
					  else
					  {
						    /* Update the old connector attributes */
							AM__set_application_bypass(true) ;
							ITK (AOM_refresh (rev, TRUE));
							ITK (AOM_set_value_string (rev, FVDTCHSStatusPROP, OBSOLETE_CONNECTOR));
							ITK (AOM_set_value_string (rev, FVDTCHSReplacedByPROP, str));
							ITK (AOM_save (rev));
							ITK (AOM_refresh (rev, FALSE));
							AM__set_application_bypass(false) ;
							
							for ( inx =0 ; inx < n_parents;  inx++)
							{
								char *itemId = NULL;
                                tag_t newDTRevision = NULLTAG;
                                ITK(FVDT_replace_connector_on_DT(parents[inx], rev, str, &newDTRevision));

								if (newDTRevision == NULLTAG)
								    continue;
						
								ITK(AOM_ask_value_string(newDTRevision, item_idPROP, &itemId));	

								ITK(FVDT_Reminder_Mail2( rev, oldConnectorPartNumStr,  Attributes[0], itemId, newDTRevision));
                                
						 
								if (  ifail!= ITK_ok)
								{
									fprintf(g_general_log, "ERROR %d sending mail for connector %s in device \n", ifail, oldConnectorPartNumStr, itemId);
								}
								else
								{
									 g_no_of_repl_conn ++;
									fprintf(g_replacement_log, "%s|%s\n", oldConnectorPartNumStr, itemId);
								}

								FVDT_FREE(itemId);
							}
					  }
                      FVDT_FREE(parents);
                   }
                   FVDT_FREE(item_tags);
                }
                fprintf(g_general_log, "Processing for Partnumber %s Ends \n\n", str);
                FVDT_FREE(str);
                FVDT_FREE(oldConnectorPartNumStr);
                FVDT_FREE(pngFileName);
                FVDT_FREE(pngFullFileName);
                FVDT_FREE(item_name);    
                FVDT_FREE_ARRAY( Attributes, count);
                fflush (stdout);
			} /* not_blank_line */
       }  /* fgets */
   }  /* for loop */

   /*Delete temporary files*/

EXIT:
   FVDT_FREE(item_type);
            

    if( fp != NULL ) fclose( fp );

    if( g_general_log )
    {
        fprintf( g_general_log, "Total Number of Items Processed: %d \n", g_total_processed );

        fprintf( g_general_log, "Total Number of Items Unchanged: %d \n", g_no_of_unchanged );

        fprintf( g_general_log, "Total Number of Items Successfully Processed: %d \n", g_no_of_successes );

        fprintf( g_general_log, "Total Number of Items Unsuccessfully Processed: %d \n", g_no_of_failures );

		fprintf( g_general_log, "Total Number of Items with REPLACED_BY Mating Connector Suggested:  %d \n", g_no_of_repl_conn );
        
    }
    
    if( g_general_log != NULL ) fclose( g_general_log );

    if( g_success_log != NULL ) fclose( g_success_log );

    if( g_failure_log != NULL ) fclose( g_failure_log );

    if( g_unchanged_log != NULL ) fclose( g_unchanged_log );

    if( g_replacement_log != NULL ) fclose( g_replacement_log );
 
   fflush(stdout);
   ITK (ITK_exit_module (TRUE) );
   
   fflush(stdout);

 
   return ITK_ok; 
}

void get_time_stamp(char* format, char** timestamp)
{
    date_t currentTime;
    struct tm* newTime = NULL;
    time_t localTime;
    time(&localTime);
    newTime = localtime(&localTime);
    currentTime.month = newTime->tm_mon;
    currentTime.year = newTime->tm_year + 1900;
    currentTime.day = newTime->tm_mday;
    currentTime.hour = newTime->tm_hour;
    currentTime.minute = newTime->tm_min;
    currentTime.second = newTime->tm_sec;

    DATE_date_to_string(currentTime, format, timestamp);
}

/*******************************************************************************/
/* Function Name    : FVDT_create_log_files                                  */
/*                                                                             */
/* Input Parms      : None                                                     */
/*                                                                             */
/* Output Parms     : None                                                     */
/*                                                                             */
/* Functions called : None                                                     */
/*                                                                             */
/* Description      : This method creates the log files (general, success,     */
/*                    unchanged and                                            */
/*                    failure logs) in the directory specified by environment  */
/*                    variable TC_TMP_DIR. If the environment variable is not  */
/*                    set, the log files are created in the current directory  */
/*                    itself.                                                  */
/*                                                                             */
/* Return Value     : (int)  ITK_ok  successful completion.                    */
/*                           !ITK_ok unsuccessful completion.                  */
/*******************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G                  */
/*******************************************************************************/

int FVDT_create_log_files()
{
    int        process_id                       = 0;
    
    char       *tmp_dir_path                    = NULL;    
    char*       timestr                         = NULL;
    char       gen_log_file_name[FVDT_BUF_SIZE];
    char       suc_log_file_name[FVDT_BUF_SIZE];
    char       fai_log_file_name[FVDT_BUF_SIZE];
	 char       unch_log_file_name[FVDT_BUF_SIZE];
	 char       repl_log_file_name[FVDT_BUF_SIZE];


    if( g_debug ) TC_write_syslog("DEBUG: Entering FVDT_create_log_files\n");

    process_id = getpid();

    get_time_stamp(IMPORT_DATE_FORMAT_STR, &timestr);
    
    /*----------------------------------------------------------*/
    /*  Log files are placed in the directory specified by the  */
    /*  environment variable TC_TMP_DIR. If this is not set   */
    /*  the files are created in the current directory where    */
    /*  the executable is being run.                            */
    /*----------------------------------------------------------*/
    tmp_dir_path = getenv( DT_TMP_DIR_VAR );

    if( tmp_dir_path != NULL )
    {
        
        TC_write_syslog("\nLog files will be placed in : %s \n\n", tmp_dir_path);

        sprintf( gen_log_file_name, "%s/%s_%d_%s.log", tmp_dir_path, FVDT_GENERAL_LOG_FILE_NAME, process_id, timestr );

        sprintf( suc_log_file_name, "%s/%s_%d_%s.log", tmp_dir_path, FVDT_SUCCESS_LOG_FILE_NAME, process_id, timestr );

        sprintf( fai_log_file_name, "%s/%s_%d_%s.log", tmp_dir_path, FVDT_FAILURE_LOG_FILE_NAME, process_id, timestr );

        sprintf( unch_log_file_name, "%s/%s_%d_%s.log", tmp_dir_path, FVDT_UNCHANGED_LOG_FILE_NAME, process_id, timestr );

        sprintf( repl_log_file_name, "%s/%s_%d_%s.log", tmp_dir_path, FVDT_REPLACEMENT_LOG_FILE_NAME, process_id, timestr );

	}
    else
    {
        TC_write_syslog("\nEnvironment Variable TC_TMP_DIR has not been set. Hence the log files will be written in the CURRENT directory only.\n\n");

        sprintf( gen_log_file_name, "%s_%d_%s.log", FVDT_GENERAL_LOG_FILE_NAME, process_id, timestr );

        sprintf( suc_log_file_name, "%s_%d_%s.log", FVDT_SUCCESS_LOG_FILE_NAME, process_id, timestr );

        sprintf( fai_log_file_name, "%s_%d_%s.log", FVDT_FAILURE_LOG_FILE_NAME, process_id, timestr );

        sprintf( unch_log_file_name, "%s_%d_%s.log", FVDT_UNCHANGED_LOG_FILE_NAME, process_id, timestr );

        sprintf( repl_log_file_name, "%s_%d_%s.log", FVDT_REPLACEMENT_LOG_FILE_NAME, process_id, timestr );

    }
    
    g_general_log = fopen( gen_log_file_name, "w" );
    if(g_general_log == NULL)
    {
        TC_write_syslog("ERROR: in opening the file %s \n", gen_log_file_name );

        return !ITK_ok;
    } 

    g_success_log = fopen( suc_log_file_name, "w" );
    if(g_success_log == NULL)
    {
        TC_write_syslog("ERROR: in opening the file %s \n", suc_log_file_name );

        return !ITK_ok;
    } 

    g_failure_log = fopen( fai_log_file_name, "w" );
    if(g_failure_log == NULL)
    {
        TC_write_syslog("ERROR: in opening the file %s \n", fai_log_file_name );

        return !ITK_ok;
    } 

    g_unchanged_log = fopen( unch_log_file_name, "w" );
    if(g_unchanged_log == NULL)
    {
        TC_write_syslog("ERROR: in opening the file %s \n", unch_log_file_name );

        return !ITK_ok;
    } 

    g_replacement_log = fopen( repl_log_file_name, "w" );
    if(g_replacement_log == NULL)
    {

        TC_write_syslog("ERROR: in opening the file %s \n", repl_log_file_name );

        return !ITK_ok;
    }

    
    if( g_debug ) TC_write_syslog("DEBUG: Leaving FVDT_create_log_files\n");

    FVDT_FREE(timestr)

    return ITK_ok;
}

int FVDT_find_parent_veh_progs (tag_t subsysRev, tag_t** vehPrograms, int* vehProgramCount)
{
	//All variables declared
	int				ifail										= ITK_ok;  /* Function return code */
	int				n_parents									= 0;
	int				parents_counter								= 0;
	int*			levels										= NULL;	
	char*			objType									    = NULL;
	tag_t*			parents										= NULL;


	//Syslog updated with custom method entry
    //FVDT_DEBUG_TXT(("\nEntering the method: %s",functionName))

	// Do a where used all to find out the component in which the DT is used
	ITK (PS_where_used_all (subsysRev, 1, &n_parents, &levels, &parents))

	// Remove inactive sequences 
	ITK (FV_remove_inactive_seq_tags_from_array(&n_parents, &parents))

	// Loop through for all the parent components
	for (parents_counter = 0; parents_counter < n_parents; parents_counter++)
	{
		// Check if the parent is of type Component
		ITK (AOM_ask_value_string (parents[parents_counter], object_typePROP, &objType))
		
		if (tc_strcmp (objType, FVE_VehProgramRevisionTYPE) == 0)
		{
			// Store the vehicle program tag
			(*vehProgramCount)++;
			(*vehPrograms) = (tag_t*)MEM_realloc((*vehPrograms), ((*vehProgramCount) * sizeof(tag_t)));
			((*vehPrograms)[((*vehProgramCount) - 1)]) =  (parents[parents_counter]);
		}
		else
		{
			// Call the function recursively till vehicle program is found
			ITK (FVDT_find_parent_veh_progs (parents[parents_counter], vehPrograms, vehProgramCount))
		}
		// Deallocate memory
		FVDT_FREE (objType)
	}
	// Deallocate memory
	FVDT_FREE (levels)
	FVDT_FREE (parents)

	// Update syslog with custom method exit
    //FVDT_DEBUG_TXT(("\nExiting the method: %s",functionName))

	FVDT_FREE (levels)
	FVDT_FREE (parents)
	FVDT_FREE (objType)

	return ifail;
}


/****************************************************************************/
/* Function Name :    FVDT_replace_connector_on_DT                          */
/*                                                                          */
/*                                                                          */
/* File Description : CR-14017732  Manage Mating Connector Changes          */
/*      This method revises the input DT if it is released and replaces the */
/*      old assigned connector with new connector                           */
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  25-May-2017      Bhagwan Moondra          Initial Creation              */
/*  15-Nov-2017      Bhagwan Moondra          Handle un-assigned connectors below DT
/****************************************************************************/
int FVDT_replace_connector_on_DT(tag_t dtRevision, tag_t oldConnector, char* newConnectorStr, tag_t* newDTRevision)
{
    int         ifail               = ITK_ok;
    int         num                 = 0;
    int         indx                = 0;
    int         iHeaderCnt          = 0;
    int         iAssignedConnCnt    = 0;
    int         headerToReviseCnt   = 0;
    int         allConnBomLinesCnt  = 0;
    char*       dtPartNo            = NULL;
    char*       oldConnPartNo       = NULL;
    char*       function_name       = "FVDT_replace_connector_on_DT";
    char*       releaseStatusName   = NULL;
    char*       pcTraverseTypename  = NULL;
    char*       pcTargetTypename    = NULL;
    tag_t       dt_item             = NULLTAG;
    tag_t       newDTRevisionTag    = NULLTAG;
    tag_t       bomWindowTag        = NULLTAG;
    tag_t       topLineTag          = NULLTAG;
    tag_t       newConnRevision     = NULLTAG;
    tag_t       latestDTRev         = NULLTAG;
    tag_t       saveCntxtBomlineTag = NULLTAG;
    tag_t       owningUserTag       = NULLTAG;
    tag_t       owningGroupTag      = NULLTAG;
    tag_t*      allConnBomLines     = NULL;
    tag_t*      item_tags           = NULL;
    tag_t*      ptHeaderBomlines    = NULL;
    tag_t*      ptAssignedConnItems = NULL;
    tag_t*      headerToReviseTags  = NULL;
    logical     saveEditMode        = false;

    if (g_debug) TC_write_syslog ("Entering :: %s\n", function_name);

    CLEANUP(AOM_ask_value_string(dtRevision, item_idPROP, &dtPartNo))
    CLEANUP(AOM_ask_value_string(oldConnector, item_idPROP, &oldConnPartNo))

    //Proceed further only for released DTs
    CLEANUP(FV_ask_release_status(dtRevision, &releaseStatusName))

    if(releaseStatusName != NULL && tc_strcmp(releaseStatusName, "Released") == 0)
    {
        //First check if this is the latest revision
        CLEANUP (ITEM_ask_item_of_rev (dtRevision, &dt_item));
        CLEANUP(ITEM_ask_latest_rev(dt_item, &latestDTRev))
        if(latestDTRev != dtRevision) 
        {
            FVDT_FREE(releaseStatusName)
            return ifail;
        }

        if(newConnectorStr != NULL && tc_strlen(newConnectorStr) > 0)
            CLEANUP(FVDT_find_item(newConnectorStr,  &item_tags, &num));

        if(num > 0 || item_tags != NULL)
        {
            logical isMatConnType = false;
            CLEANUP(FV_object_is_typeof(item_tags[0], FVDTMatConnTYPE, &isMatConnType))
            if(isMatConnType)
                CLEANUP(ITEM_ask_latest_rev (item_tags[0], &newConnRevision)); 
        }

        if(newConnRevision == NULLTAG)
        {
            FVDT_FREE(releaseStatusName)
            return ifail;
        }

        ITK(AOM_refresh(dt_item, true));

        //Revise the DT   
        CLEANUP(ITEM_copy_rev(dtRevision, NULL, &newDTRevisionTag))
        CLEANUP(AOM_refresh(dt_item, false))
        *newDTRevision = newDTRevisionTag;

        CLEANUP(AOM_save(newDTRevisionTag))
        CLEANUP(AOM_refresh(newDTRevisionTag, false))

        //Set the ownership
        CLEANUP(POM_ask_owner(dtRevision, &owningUserTag, &owningGroupTag))
        CLEANUP(AOM_refresh(newDTRevisionTag, true))
        CLEANUP(AOM_set_ownership(newDTRevisionTag, owningUserTag, owningGroupTag))
        CLEANUP(AOM_save(newDTRevisionTag))

        CLEANUP(AOM_refresh(newDTRevisionTag, false))

        CLEANUP(FVDT_create_bomwindow(newDTRevisionTag,Latest_WorkingREVISIONRULE,true,&bomWindowTag,&topLineTag))

        CLEANUP(AOM_ask_value_logical( bomWindowTag, absocc_specific_edit_modePROP, &saveEditMode))
        CLEANUP(AOM_ask_value_tag(bomWindowTag, absocc_ctxtlinePROP, &saveCntxtBomlineTag))

        // Get all the DT's Header bomlines (FVDTHeader).
        pcTraverseTypename = FVDTBaseTYPE;
        pcTargetTypename = FVDTHeaderTYPE;
        CLEANUP(FV_gather_child_bomlines(topLineTag, FV_ONE_LEVEL, FV_LEVEL_ZERO,
                                        1, &pcTargetTypename, 1, &pcTraverseTypename,
                                        FV_ALL_VALUES, FV_NO_BOM_REFRESH, &iHeaderCnt, &ptHeaderBomlines))

        //Replace the assigned connector
        //Collect all headers where old connector is used
        for(indx=0; indx<iHeaderCnt; indx++)
        {
            CLEANUP(FVDT_get_assgined_connector_item_revs_for_DT(ptHeaderBomlines[indx], &iAssignedConnCnt, &ptAssignedConnItems))
            if(FV_find_tag_in_array(iAssignedConnCnt, ptAssignedConnItems, oldConnector) > -1)
            {
                CLEANUP(FV_add_tag_to_array(&headerToReviseCnt, &headerToReviseTags, ptHeaderBomlines[indx]))
            }
            iAssignedConnCnt = 0;
            FVDT_FREE(ptAssignedConnItems)
        }

        for(indx=0; indx<headerToReviseCnt; indx++)
        {
            int     count                       = 0;
            int     modifiedHeaderCnt           = 0;
            int     revCount                    = 0;
            tag_t   newHeaderBomLine            = NULLTAG;
            tag_t*  ptModifiedHeaderBomline     = NULL;
            tag_t*  revisedObjs                 = NULL;
            char*   item_id                     = NULL;
            char*   blnk_str                    = NULL;
            char*   restrictedComment           = NULL;
            char**  removedConnBomLines         = NULL;
            char**  pcCommentsArray             = NULL;
            FV_strdup("", &blnk_str);

            CLEANUP(AOM_ask_value_string(dtRevision, FVDTRestConnUsageCommentsPROP, &restrictedComment))
            if(restrictedComment == NULL)
                FV_strdup("", &restrictedComment);

            CLEANUP(AOM_ask_value_string(oldConnector, item_idPROP, &item_id))
            CLEANUP(FV_add_string_pointer_to_array(&count, &removedConnBomLines, item_id))
            count = 0;
            CLEANUP(FV_add_string_pointer_to_array(&count, &pcCommentsArray, blnk_str))
            CLEANUP(FV_revise_bomline_and_limited_parents(headerToReviseTags[indx], topLineTag, bomWindowTag, &revCount, &revisedObjs, &newHeaderBomLine, false))
            CLEANUP(AOM_set_value_logical( bomWindowTag, absocc_specific_edit_modePROP, true ))
            CLEANUP(AOM_set_value_tag(bomWindowTag, absocc_ctxtlinePROP, topLineTag))

            //Add the new (replacing) connector to DT Revision only once
            //(There can be case when old connector was assigned to multiple headers)
            if(indx == 0)
                CLEANUP(FVDT_update_DT_with_connector_changes(topLineTag
                                                        ,1
                                                        ,&newHeaderBomLine
                                                        ,&oldConnector
                                                        ,1
                                                        ,&newHeaderBomLine
                                                        ,&newConnRevision
                                                        ,1
                                                        ,pcCommentsArray
                                                        ,1
                                                        ,&newConnRevision
                                                        ,1
                                                        ,removedConnBomLines
                                                        ,restrictedComment
                                                        ,&modifiedHeaderCnt
                                                        ,&ptModifiedHeaderBomline))

            else
                CLEANUP(FVDT_update_DT_with_connector_changes(topLineTag
                                                        ,1
                                                        ,&newHeaderBomLine
                                                        ,&oldConnector
                                                        ,1
                                                        ,&newHeaderBomLine
                                                        ,&newConnRevision
                                                        ,1
                                                        ,pcCommentsArray
                                                        ,0
                                                        ,NULL
                                                        ,1
                                                        ,removedConnBomLines
                                                        ,restrictedComment
                                                        ,&modifiedHeaderCnt
                                                        ,&ptModifiedHeaderBomline))
            CLEANUP(BOM_save_window(bomWindowTag))
            CLEANUP(BOM_refresh_window(bomWindowTag))
            CLEANUP(AOM_set_value_logical( bomWindowTag, absocc_specific_edit_modePROP, saveEditMode ))
            CLEANUP(AOM_set_value_tag(bomWindowTag, absocc_ctxtlinePROP, saveCntxtBomlineTag))

            FVDT_FREE(item_id)
            FVDT_FREE(blnk_str)
            FVDT_FREE(restrictedComment)
            FVDT_FREE(ptModifiedHeaderBomline)
            FVDT_FREE(revisedObjs)
            FV_FREE_STRINGS(removedConnBomLines)
            FV_FREE_STRINGS(pcCommentsArray)
        }

        //There can be case when old connector is lying un-assigned below DT
        //Cut such connector BOM Lines from DT
        pcTargetTypename = FVDTMatConnTYPE;
        CLEANUP(FV_gather_child_bomlines(topLineTag,FV_ONE_LEVEL,FV_LEVEL_ZERO,1,&pcTargetTypename,1,&pcTraverseTypename,FV_UNIQUE_VALUES,FV_NO_BOM_REFRESH,&allConnBomLinesCnt,&allConnBomLines))
        for(indx=0; indx<allConnBomLinesCnt; indx++)
        {
            tag_t conRev = NULLTAG;
            CLEANUP(AOM_ask_value_tag(allConnBomLines[indx], "bl_revision", &conRev))
            if(oldConnector == conRev)
            {
                //If old connector is duplicate below DT, just cut the same from DT
                //But if no header is assigned to old connector, then also add the
                //new connector to DT
                CLEANUP(BOM_line_cut(allConnBomLines[indx]))
                if(headerToReviseCnt == 0)
                {
                    tag_t newBomlineTag = NULLTAG;
                    CLEANUP(BOM_line_add(topLineTag, NULLTAG, newConnRevision, NULLTAG, &newBomlineTag))
                }

                CLEANUP(BOM_save_window(bomWindowTag))
                CLEANUP(BOM_refresh_window(bomWindowTag))
                allConnBomLines[indx]=NULLTAG;
            }
        }
        CLEANUP(BOM_close_window(bomWindowTag))

        //Also, release this newly created DT Revision
        CLEANUP(FVDT_freeze(newDTRevisionTag))
    }

CLEANUP:
    if (ifail != ITK_ok)
    {
        ifail = ITK_ok;
        EMH_clear_errors();
        if(dt_item != NULLTAG)
            AOM_refresh(dt_item, false);
        fprintf(g_failure_log, "%s|%s\n", oldConnPartNo, dtPartNo);
        g_no_of_failures++;
    }
    FVDT_FREE(item_tags)
    FVDT_FREE(releaseStatusName)
    FVDT_FREE(ptHeaderBomlines)
    FVDT_FREE(headerToReviseTags)
    FVDT_FREE(allConnBomLines)
    FVDT_FREE(dtPartNo)
    FVDT_FREE(oldConnPartNo)
    if (g_debug) TC_write_syslog ("Entering :: %s\n", function_name);
    return ifail;
}

int FVDT_find_parent_subsystem_in_VP (tag_t vehPrg, tag_t dtRevision, tag_t* parentSubsystem)
{
    int         ifail                   = ITK_ok;
    int         indx                 = 0;
    int         parentCnt            = 0;
    tag_t*      parentTags           = NULL;
    tag_t*      vehPrgTags           = NULL;
    char*       parentTypenames[1]   = {FVDTSubSysRevisionTYPE}; 

    CLEANUP(FV_where_used(&dtRevision, 1, parentTypenames, 1, FV_TWO_LEVELS,
                    Latest_WorkingREVISIONRULE, &parentTags, &parentCnt))
    for(indx=0; indx<parentCnt; indx++)
    {
        char   objType[WSO_name_size_c+1]    = "";
        tag_t  VPTag                         = NULLTAG;
        CLEANUP(WSOM_ask_object_type(parentTags[indx], objType ))
        if(0 == tc_strcmp(objType, FVDTSubSysRevisionTYPE))
        {
            CLEANUP(AOM_ask_value_tag(parentTags[indx], FVDTSubSysVehPrgPROP, &VPTag))
            if(VPTag == vehPrg)
            {
                *parentSubsystem =  parentTags[indx];
                break;
            }
        }
    }
CLEANUP:
    FVDT_FREE(parentTags)
    FVDT_FREE(vehPrgTags)
    return ifail;
}
