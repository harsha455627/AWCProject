//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================


#include <teamcenter/clientx/AppXExceptionHandler.hxx>

#include <iostream>

#include <teamcenter/soa/client/RuntimeException.hxx>
#include <teamcenter/schemas/soa/_2006_03/exceptions/ConnectionException.hxx>
#include <teamcenter/schemas/soa/_2006_03/exceptions/ProtocolException.hxx>

using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Soa::Client;
using namespace Teamcenter::Schemas::Soa::_2006_03::Exceptions;


void AppXExceptionHandler::handleException(InternalServerException& ise)
{
    cout << ""      << endl;
    cout << "*****" << endl;
    cout << "Exception caught in Teamcenter::ClientX::AppXExceptionHandler.handleException(InternalServerException)." << endl;

    ConnectionException *ce = dynamic_cast<ConnectionException *>(&ise);
    ProtocolException   *pe = dynamic_cast<ProtocolException   *>(&ise);

    if (ce)
    {
        // ConnectionException are typically due to a network error (server
        // down .etc) and can be recovered from (the last request can be sent again,
        // after the problem is corrected).
        cout << endl << "The server returned an connection error." << endl << ise.getMessage() <<
                endl << "Do you wish to retry the last service request?[y/n]";
    }
    else if (pe)
    {
        // ProtocolException are typically due to programming errors
        // (content of HTTP
        // request is incorrect). These are generally can not be
        // recovered from.
        cout << endl << "The server returned an protocol error." << endl <<  ise.getMessage() <<
                endl << "This is most likely the result of a programming error." <<
                endl << "Do you wish to retry the last service request?[y/n]";
    }
    else
    {
        cout << endl << "The server returned an internal server error." << endl <<  ise.getMessage() <<
                endl << "This is most likely the result of a programming error." <<
                endl << "A RuntimeException will be thrown." << endl;
        throw RuntimeException(RuntimeException::InternalError, ise.getMessage().c_str());
    }

    std::string retry;
    cin >> retry;
    // If yes, return to the calling SOA client framework, where the
    // last service request will be resent.
    if (retry == "y" || retry == "yes")
        return;

    throw RuntimeException(RuntimeException::InternalError, "The user has opted not to retry the last request");
}

void AppXExceptionHandler::handleException(CanceledOperationException& coe)
{
    cout << ""      << endl;
    cout << "*****" << endl;
    cout << "Exception caught in Teamcenter::ClientX::AppXExceptionHandler.handleException(CanceledOperationException)."<< endl;

    // Expecting this from the login tests with bad credentials, and the
    // AnyUserCredentials class not
    // prompting for different credentials
    throw RuntimeException(RuntimeException::InternalError, coe.getMessage().c_str());
}


