//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6_sap_cost_calculation
 *
 */
#include <O6TaneCustomLibrary/O6_sap_cost_calculation.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/preferences.h>
#include <tccore/grm.h>
#include <bom/bom.h>
#include <tccore/tctype.h>

#include <vector>
#include <sstream>
#include <map>

#define FLE_REV "O6_FleRevision"
#define GENRM_REV "O6_GenRMRevision"

/*BO Properties*/
#define O6_CPD_ENTI_GEO "o6_cpd_enti_geo"
#define O6_ENT_GEO "o6_ent_geographique"
#define O6_SAP_SYSTEM "o6_sap_system"
#define O6_PRIX_SAP "o6_prix_sap"
#define O6_SAP_COST "o6_sap_cost"
#define TOP_LINE_ATTR "top_line"

/*Relation properties*/
#define O6_GENRM_SAP_FORM_REL "O6_GenRMSapFormRel"

/*Preference Name*/
#define SEEDS_SAP_COST "SEEDS_SAP_cost"

/*BOMLine Props*/
#define bomAttr_lineO6_SAP_Cost "o6_sap_cost"

static int item_revtag_attribute;
static int bl_o6_sap_cost_attribute;

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 * Input       :
 */
static int initialise (void)
{
	int retcode = ITK_ok;

	ITK ( BOM_line_look_up_attribute ( bomAttr_lineItemRevTag, &item_revtag_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_lineO6_SAP_Cost, &bl_o6_sap_cost_attribute ) );

	return retcode;
}

/**
 * Function    :  getDelimitedValues
 * Description :  Used to seperate values based on delimiter.
 * Input       :
 *      sPrefValue 	      - String preference value
 *      pcDelimiter       - Char pointer containing delimited values
 * Output	   :
 * 		&vDelimitedValues - Address of Vector containing values
 */
void getDelimitedValues ( string sPrefValue, vector<string>&vDelimitedValues, char pcDelimiter )
{
	std::istringstream ss( sPrefValue );

	string value;

	while ( std::getline ( ss, value, pcDelimiter ) )
	{
		vDelimitedValues.push_back ( value );
	}
}

/**
 * Function    :  getMapValues
 * Description :  Used to populate map with preference values seperated by ':'
 * Input       :
 *      pcPrefValues 	   - Array of preference string values
 *      iValuesCount       - Count of Array elements
 * Output	   :
 * 		&mPrefValues      - Address of map containing values
 */
void getMapValues ( char** pcPrefValues, int iValuesCount, map<string,string> &mPrefValues )
{
	for ( int iInx = 0; iInx < iValuesCount; iInx++ )
	{
		vector<string> vDelimitedValues;
		getDelimitedValues ( string ( pcPrefValues[iInx] ), vDelimitedValues, ':' );

		if ( vDelimitedValues.size() > 0 )
		{
			mPrefValues.insert( pair<string, string> ( vDelimitedValues[0], vDelimitedValues[1] ) );
		}

		vDelimitedValues.clear();
	}
}

/**
 * Function    :  getRequiredSAPForm
 * Description :  Used to get tag of the required form.
 * Input       :
 *      tGenRMRevTag 	   - Array of preference string values
 *      sDepartments       - string
 * Output	   :
 * 		&tFormTag          - Address of tag of the required form
 */
int getRequiredSAPForm ( tag_t tGenRMRevTag, string sDepartments, tag_t &tFormTag )
{
	int retcode = ITK_ok;

	tag_t tFormRelTag = NULLTAG;

	ITK ( GRM_find_relation_type ( O6_GENRM_SAP_FORM_REL, &tFormRelTag ) );

	if ( retcode == ITK_ok && tFormRelTag != NULLTAG )
	{
		int iFormsCount = 0;

		tag_t* tFormsTag = NULL;

		ITK ( GRM_list_secondary_objects_only ( tGenRMRevTag, tFormRelTag, &iFormsCount, &tFormsTag ) );

		for ( int iInx = 0; iInx < iFormsCount; iInx++ )
		{
			char* pcSAPSystem = NULL;

			ITK ( AOM_ask_value_string ( tFormsTag[iInx], O6_SAP_SYSTEM, &pcSAPSystem ) );

			if ( retcode == ITK_ok && pcSAPSystem != NULL && strlen ( pcSAPSystem ) > 0 )
			{
				if ( tc_strcmp ( pcSAPSystem, sDepartments.c_str() ) == 0 )
				{
					tFormTag = tFormsTag[iInx];
					break;
				}
			}

			if ( pcSAPSystem != NULL )
			{
				MEM_free ( pcSAPSystem );
				pcSAPSystem = NULL;
			}
		}

		if ( tFormsTag != NULL )
		{
			MEM_free ( tFormsTag );
			tFormsTag = NULL;
		}
	}

	return retcode;
}

/**
 * Function    :  O6_sap_cost_calculation
 * Description :  Used when getting values for custom runtime property o6_sap_cost.
 * Input       :
 *      msg 		 - Input msg for extension
 *      args         - Input args for extension
 * Output	   :
 * 		none
 */
int O6_sap_cost_calculation( METHOD_message_t * msg, va_list args )
{
	int retcode = ITK_ok;

	double* attrvalue = NULL;
	tag_t blTag = NULLTAG;

	va_list largs;
	va_copy( largs, args);
	va_arg( largs, tag_t ); /*Property Object tag_t  not used*/
	attrvalue = va_arg( largs, double* );
	va_end( largs );

	if ( attrvalue != NULL )
	{
	    *attrvalue = 0;

	    blTag = msg->object_tag;
	    if ( blTag != NULLTAG )
	    {
	    	tag_t tWindowTag = NULLTAG;

	    	ITK ( initialise() );

	    	ITK ( BOM_line_ask_window ( blTag, &tWindowTag ) );
	    	if (retcode == ITK_ok && tWindowTag != NULLTAG )
	    	{
	    		tag_t tRootLine = NULLTAG;

	    		ITK ( AOM_ask_value_tag ( tWindowTag, TOP_LINE_ATTR, &tRootLine));
	    		if (retcode == ITK_ok && tRootLine != NULLTAG )
	    		{
	    			tag_t tFleItemRevTag = NULLTAG;

					ITK ( BOM_line_ask_attribute_tag ( tRootLine, item_revtag_attribute, &tFleItemRevTag ) );

					if ( retcode == ITK_ok && tFleItemRevTag != NULLTAG )
					{
						tag_t tFleRevTypeTag = NULLTAG;
						ITK ( TCTYPE_ask_object_type ( tFleItemRevTag, &tFleRevTypeTag ) );
						if ( retcode == ITK_ok && tFleRevTypeTag != NULLTAG )
						{
							logical answerFlg = FALSE;

							ITK ( TCTYPE_is_type_of_as_str ( tFleRevTypeTag, FLE_REV, &answerFlg));
							if ( retcode == ITK_ok && answerFlg == TRUE )
							{
								tag_t tItemRevTag      = NULLTAG;

								ITK ( BOM_line_ask_attribute_tag ( blTag, item_revtag_attribute, &tItemRevTag ) );

								if ( retcode == ITK_ok && tItemRevTag != NULLTAG )
								{
									tag_t tGenRMRevTypeTag = NULLTAG;

									ITK ( TCTYPE_ask_object_type ( tItemRevTag, &tGenRMRevTypeTag ) );

									if ( tGenRMRevTypeTag != NULLTAG )
									{
										logical answerFlg = FALSE;

										ITK ( TCTYPE_is_type_of_as_str ( tGenRMRevTypeTag, GENRM_REV, &answerFlg));
										if ( retcode == ITK_ok && answerFlg == TRUE )
										{
											char* pcEntiGeo = NULL;

											ITK ( AOM_ask_value_string ( tFleItemRevTag, O6_ENT_GEO, &pcEntiGeo ) ); // Getting value of property o6_ent_geographique from Formula to be compared with preference value
											if ( retcode == ITK_ok && pcEntiGeo != NULL && strlen ( pcEntiGeo ) > 0 )
											{
												int iValuesCount = 0;

												map <string, string> mPrefValues;

												char** pcPrefValues = NULL;

												ITK ( PREF_ask_char_values ( SEEDS_SAP_COST, &iValuesCount, &pcPrefValues ) );

												getMapValues ( pcPrefValues, iValuesCount, mPrefValues ); // Seperating the Preference values based on ':' and storing them as key-value in map

												if ( mPrefValues.size() > 0 )
												{
													if ( mPrefValues.find ( string ( pcEntiGeo ) ) != mPrefValues.end() ) // Finding corresponding geography value in map Key list
													{
														vector<string> vDepartments;

														getDelimitedValues ( mPrefValues.find ( string ( pcEntiGeo ) )->second, vDepartments, ',' ); // Separating Key's value based on ','

														if ( vDepartments.size() > 0 )
														{
															tag_t tFormTag = NULLTAG;

															for ( int iInx = 0; iInx < vDepartments.size(); iInx++ )
															{
																ITK ( getRequiredSAPForm ( tItemRevTag, vDepartments[iInx], tFormTag ) ); // Looping through all the departments as mentioned in preference and getting corresponding form with same value as department

																if ( retcode == ITK_ok && tFormTag != NULLTAG )
																{
																	logical lIsNullOrEmpty = NULL;

																	ITK ( AOM_is_null_empty ( tFormTag, O6_PRIX_SAP, 0, &lIsNullOrEmpty ) );

																	if ( lIsNullOrEmpty == FALSE )
																	{
																		double dPrixSapCost = 0.0;
																		ITK ( AOM_ask_value_double ( tFormTag, O6_PRIX_SAP, &dPrixSapCost ) );

																		if ( retcode == ITK_ok )
																		{
																			*attrvalue = dPrixSapCost; // Setting o6_prix_sap value
																		}
																	}
																	break;
																}
															}
														}
														if ( ! vDepartments.empty() )
														{
															vDepartments.clear();
														}
													}
												}
												if ( pcPrefValues != NULL )
												{
													MEM_free ( pcPrefValues );
													pcPrefValues = NULL;
												}
											}
										}
									}
								}
							}
						}
					}
	    		}
	    	}

	    }
	}
	return retcode;
}
