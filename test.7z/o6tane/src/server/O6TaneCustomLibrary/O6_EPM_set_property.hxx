/*
 * @file
 *
 *   This file contains the all the custom action handler headers.
 *   Note: For custom rule handler, create a new source and a header file.
 *
 */
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/tc_arguments.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <tc/preferences.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tc/tc_util.h>
#include <sa/tcfile.h>
#include <epm/epm.h>
#include <string>
#include <iostream>
#include <sstream>

typedef struct args
{
	string sSourceProperty;
	string sTargetProperty;
}handlerArgs;

int O6_EPM_set_property ( EPM_action_message_t msg );
