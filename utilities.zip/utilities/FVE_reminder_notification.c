
#include <tccore/aom.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <form/form.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
# include <tc/tc.h>
#include <time.h>
#include <epm/epm.h>
#include <fclasses/tc_date.h>
#include <tccore/project.h>
#include <tc/preferences.h>
#include <time.h>
#include <epm/signoff.h>
#include <textsrv/iman_textserver.h>

#include "PasswdFunction.h"
#ifdef UNX
#include <grp.h>
#include <pwd.h>
#include <tc/emh.h>
#include <unistd.h>
#endif
#ifdef WIN32
	#define		PATHDELIM		'\\'
#else
	#define		PATHDELIM		'/'
#endif



#define		GRP_FORM_RELNAME		"FVE_GrpFrmWflRelation"
#define		PRJ_FORM_RELNAME		"FVE_PrjFrmWflRelation"
#define		WKFL_FORM_TYPE			"FVE_ParmVlSupWflForm"
#define		FORM_PVAL_RELNAME		"IMAN_external_object_link"
#define		PROJ_BKDWN_RELNAME		"TC_Generic_Architecture"
FILE *logfileptr = NULL;
#define PASSWORDKEY     "PASSWORDKEY"

#define SAFE_MEMFREE( x){		\
	TC_write_syslog("SAFE_MEMFREE");					\
}


#define IMCALL( iFail, func) {											\
	char *err_string = NULL;														\
	if( (iFail = (func)) != ITK_ok)											\
	{																		\
	EMH_ask_error_text(iFail, &err_string);                 \
    fprintf(logfileptr,"ERROR: %d ERROR MSG: %s.", iFail, err_string);\
	fprintf (logfileptr, "FUNCTION: %sFILE: %s LINE: %d",#func, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	return iFail;\
	}																		\
}



#define IDEBUG ((getenv("VSEM_DEBUG")==NULL)?0:atoi(getenv("VSEM_DEBUG")))

#define ITK(x)                                                             \
{                                                                          \
	if ( stat == ITK_ok )                                                  \
	{                                                                      \
	if ( (stat = (x)) != ITK_ok )                                      \
		{                                                                  \
		dump_itk_errors ( stat,  __LINE__, __FILE__ );         \
		}                                                                  \
	}                                                                      \
}



static void dump_itk_errors( int stat,  int lineNumber, const char * fileName )
{
	int          n_ifails=0;
	const int   *severities=NULL;
	const int   *ifails=NULL;
	const char **texts=NULL;
	char        *errstring=NULL;

	EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
	if ( n_ifails && texts != NULL )
	{
		if ( ifails[n_ifails-1] == stat )
		{
			fprintf( stderr, " Error %d: %s\n",  stat, texts[n_ifails-1] );
		}
		else
		{
			EMH_ask_error_text (stat, &errstring );
			fprintf( stderr, " Error %d: %s\n",  stat, errstring );
			MEM_free( errstring );
		}
	}
	else
	{
		EMH_ask_error_text (stat, &errstring );
		fprintf( stderr, " Error %d: %s\n",  stat, errstring );
	}
	fprintf( stderr, "Error: Line %d in %s\n",  lineNumber, fileName );
}

int GetCurrentDateTime(date_t *date)
{
	struct tm *now;
	time_t current_date_time;

	time( &current_date_time);
	now = localtime(&current_date_time);
	date->year   = now->tm_year + 1900;
	date->month  = now->tm_mon;
	date->day    = now->tm_mday;
	date->hour   = now->tm_hour;
	date->minute = now->tm_min;
	date->second = now->tm_sec;

	return ITK_ok;

}
int FVE_Reminder_Mail( char* procName, char* taskname, char* dueDate, int numProcReviewer, tag_t* arrProcReviewer)
{
	int	iFail = ITK_ok;
	tag_t tagEnvelope = NULLTAG;
	int iCounter = 0;
	int iNumUser = 0;
	char customSubject[ 1024]={'\0'};
	char customComment[ 1024]={'\0'};

	sprintf ( customSubject, "Reminder Notification for \"%s\" Workflow Process", procName);
	sprintf ( customComment , "Following task = \"%s\" is due on \"%s\" ", taskname, dueDate);

	for( iNumUser = 0; iNumUser < numProcReviewer; iNumUser++)
	{

		IMCALL( iFail,  MAIL_create_envelope( customSubject, customComment ,  &tagEnvelope));
		IMCALL( iFail,  MAIL_add_envelope_receiver( tagEnvelope, arrProcReviewer[iCounter]) );
		IMCALL( iFail,  MAIL_send_envelope(tagEnvelope));
	}

	return	iFail;
}
#define DATE_TO_INT(DateToTransforme, temps) \
{ {  struct tm tp;  \
	tp.tm_sec  = (int) DateToTransforme.second; \
	tp.tm_min  = (int) DateToTransforme.minute; \
	tp.tm_hour = (int) DateToTransforme.hour; \
	tp.tm_mday = (int) DateToTransforme.day; \
	tp.tm_mon  = (int) DateToTransforme.month; \
	tp.tm_year = ((int) DateToTransforme.year) - 1900; \
	tp.tm_isdst= 1; \
	temps = mktime(&tp); \
} }

#define INT_TO_DATESTRUCT( tp, tce_date) \
{ {  tce_date.second = ( byte) tp->tm_sec; \
	tce_date.minute = (byte) tp->tm_min ; \
	tce_date.hour =  (byte) tp->tm_hour; \
	tce_date.day = (byte)tp->tm_mday; \
	tce_date.month = ( byte)tp->tm_mon; \
	tce_date.year = (short) ( tp->tm_year + 1900); \
} }

int sendMail( tag_t reminderTask, char* dueDate)
{
	int iFail = ITK_ok;
	int signOffCount = 0;
    tag_t * signOffAttachs = NULL;
    tag_t signoff_member = NULLTAG;

	tag_t cr_job = NULLTAG;
	tag_t  responsible_party	  = NULLTAG;
	char  	review_task_name[WSO_name_size_c+1] = "";
	tag_t root_task = NULLTAG;
	char  	root_review_task_name[WSO_name_size_c+1] = "";

	tag_t user_tag = NULLTAG;

	int j;

	SIGNOFF_TYPE_t signoff_member_type;

	IMCALL( iFail , EPM_ask_job( reminderTask, &cr_job));
	IMCALL( iFail , EPM_ask_responsible_party  	(  	reminderTask, &responsible_party));
	IMCALL( iFail , EPM_ask_review_task_name  	(  	reminderTask, review_task_name) );

	IMCALL( iFail , EPM_ask_root_task  	(  	reminderTask, &root_task) );
	IMCALL( iFail , EPM_ask_review_task_name  	(  	root_task, root_review_task_name) );

	IMCALL(iFail , EPM_ask_attachments(reminderTask, EPM_signoff_attachment, &signOffCount, &signOffAttachs));

	if(signOffCount > 0)
	{
		for(j=0;j<signOffCount;j++)
		{
			IMCALL( iFail, EPM_ask_signoff_member( signOffAttachs[j],  &signoff_member, &signoff_member_type));

			if(signoff_member !=NULLTAG)
			{
				IMCALL(iFail , SA_ask_groupmember_user(signoff_member , &user_tag));

				if(user_tag != NULLTAG)
				{
					IMCALL( iFail , FVE_Reminder_Mail( root_review_task_name, review_task_name , dueDate, 1, &user_tag));

				}

			}

		}
	}

	IMCALL( iFail , FVE_Reminder_Mail( root_review_task_name, review_task_name , dueDate, 1, &responsible_party));

	SAFE_MEMFREE( signOffAttachs);

	return iFail;
}
int processNotifications( tag_t epmtask)
{
	int iFail = ITK_ok;
	logical requiresNotification = FALSE;
	char duration[ 256] = "";

	IMCALL( iFail, doesTaskRequireNotification( epmtask, &requiresNotification, duration));

	return iFail;
}
#define DATE_FORMAT_STR	"%Y-%m-%d-%H.%M.%S"
int doesTaskRequireNotification( tag_t epmtask, logical* requiresNotification, char* duration)
{
	int iFail = ITK_ok;
	date_t dueDate = NULLDATE;
	date_t current_date = NULLDATE;
	int   	yrs = 0;
	int   	wks= 0;
	int   	dys= 0;
	int   	hrs= 0;
	int   	mns= 0;
	char *  	date_str = NULL;

	struct tm*  loc_time = 0;
	date_t  loc_time_date = NULLDATE;
	time_t   task_date = 0;
	time_t   cur_date = 0;
	char*	formattedCurrDate = NULL;
	int   	cur_month = 0;
	int   	cur_day = 0;
	int   	cur_year= 0;
	int   	cur_hour= 0;
	int   	cur_minute= 0;
	int   	cur_second= 0;

	char*	formattedDueDate = NULL;
	int   	due_month= 0;
	int   	due_day= 0;
	int   	due_year= 0;
	int   	due_hour= 0;
	int   	due_minute= 0;
	int   	due_second= 0;

	int   	diff_month= 0;
	int   	diff_day= 0;
	int   	diff_year= 0;
	int		diff_days = 0;
	int		pref_val_count = 0;
	int *	pref_values = NULL;
	int		inc = 0;


	char* StrCurrDate = NULL;

	char* dueDateString = NULL;


	double  diff_time_sec = 0;

	char task_type[WSO_name_size_c+1] = "";

	IMCALL( iFail , WSOM_ask_object_type( epmtask, task_type));

	IMCALL( iFail , GetCurrentDateTime( &current_date));

	IMCALL( iFail,  DATE_date_to_string( current_date, DATE_FORMAT_STR, &formattedCurrDate ));

	// TC_write_syslog( "date_str formattedCurrDate =%s \n", formattedCurrDate);

	DATE_TO_INT( current_date, cur_date);

	// TC_write_syslog( "cur_date =%d \n", cur_date);

	IMCALL( iFail,  ITK_date_to_string( current_date, &StrCurrDate ));

	// TC_write_syslog( "StrCurrDate =%s \n", StrCurrDate);



	IMCALL( iFail, EPM_ask_task_duration(epmtask, &yrs, &wks, &dys, &hrs, &mns));

	// TC_write_syslog( "task_duration yrs=%d  wks=%d dys=%d hrs=%d mns=%d\n", yrs, wks, dys, hrs, mns);

	IMCALL( iFail, EPM_ask_task_due_date(epmtask, &dueDate));


	/*IMCALL( iFail,  ITK_date_to_string( dueDate, &dueDateString ));



	if((dueDateString == NULL) || (dueDateString == " ") )
	{

			TC_write_syslog( "\n dueDateString is NULL \n");

	}
	else
	{
		TC_write_syslog( "dueDateString =%s \n", dueDateString);

	} */


	DATE_TO_INT( dueDate, task_date);

	// TC_write_syslog( "task_date 1 = %d \n", task_date);

	loc_time = localtime ( &task_date );
	INT_TO_DATESTRUCT( loc_time, loc_time_date);
	DATE_TO_INT( loc_time_date, task_date);

	// TC_write_syslog( "task_date 2 =%d \n", task_date);


	IMCALL( iFail,  DATE_date_to_string( loc_time_date, DATE_FORMAT_STR, &formattedDueDate ));
	TC_write_syslog( "date_str formattedDueDate =%s \n", formattedDueDate);

	// TC_write_syslog( "task_date =%d \n", task_date);


	IMCALL( iFail, DATE_string_to_date(	formattedCurrDate, DATE_FORMAT_STR, &cur_month , &cur_day , &cur_year , &cur_hour , &cur_minute , &cur_second));
	IMCALL( iFail, DATE_string_to_date(	formattedDueDate, DATE_FORMAT_STR , &due_month , &due_day , &due_year , &due_hour , &due_minute , &due_second));

	// diff_time_sec = difftime( task_date, cur_date);

	diff_time_sec = difftime( cur_date, task_date);

	// TC_write_syslog("INFO : diff_time_sec = %d \n", diff_time_sec);

	diff_day = diff_time_sec/(24*60*60);

	// TC_write_syslog("INFO : diff_day = %d \n", diff_day);

	IMCALL( iFail, PREF_ask_int_values("FVE_REMAINDER_NOTIF_DAYS", &pref_val_count, &pref_values));

	if(pref_val_count == 0)
	{
		TC_write_syslog("ERROR: No values were set in the Preference FVE_REMAINDER_NOTIF_DAYS\n");
		return !ITK_ok;
	}

	for(inc = 0; inc < pref_val_count; inc++)
	{

		if(pref_values[inc] == diff_day)
		{

			sendMail( epmtask, formattedDueDate);
			break;
		}
	}
	SAFE_MEMFREE(pref_values);

	SAFE_MEMFREE(StrCurrDate);

	SAFE_MEMFREE(dueDateString);

	/*	diff_year = due_year - cur_year;
	diff_month = due_month - cur_month;
	diff_day = due_day - cur_day;

	diff_days = 365*diff_year + 30*diff_month + diff_day;

	if( diff_days == 30 || diff_days == 14 || diff_days == 7 || diff_days == 1)
	{
	sendMail( epmtask);

	}
	*/
	return iFail;
}
int FVE_recursive_process_qry( logical* isNotificationSent, tag_t epmtask)
{
	int iFail = ITK_ok;
	EPM_state_t  	state;

	if( *isNotificationSent == TRUE)
	{

		return iFail;
	}

	IMCALL( iFail , EPM_ask_state( epmtask, &state) );

	if( state == EPM_started )
	{
		int   	subtaskcount = 0;
		int		iSubTaskCnt = 0;
		tag_t*  subtasks = NULL;

		char task_type[WSO_name_size_c+1] = "";
		char* id = NULL;
		IMCALL( iFail , WSOM_ask_id_string  (  	epmtask, &id));
		IMCALL( iFail , WSOM_ask_object_type(  epmtask, task_type));
		TC_write_syslog("\nTASKid=%s is of task_type=%s is started \n ", id, task_type);

		IMCALL( iFail , EPM_ask_sub_tasks( epmtask, &subtaskcount, &subtasks));
		for( iSubTaskCnt = 0; iSubTaskCnt < subtaskcount; iSubTaskCnt++)
		{
			IMCALL( iFail , FVE_recursive_process_qry( isNotificationSent, subtasks[ iSubTaskCnt]));
		}
		if( *isNotificationSent == FALSE)
		{
			IMCALL( iFail , processNotifications( epmtask));
			*isNotificationSent = TRUE;
		}
	}
	/*else
	{
		char* nid = NULL;

		IMCALL( iFail , WSOM_ask_id_string  (epmtask, &nid));

		TC_write_syslog("\nstate NOT EPM_started for task = %s\n", nid );
	} */

	return iFail;
}
int FVE_execute_wip_process_for_reminder_notification( )
{
	int iFail = ITK_ok;
	tag_t qry_tag = NULLTAG;
	int  numWipProc= 0;
	int iCntWipProc = 0;
	tag_t* arrWipProcTag = NULL;

	int  numWipProc1= 0;
	int iCntWipProc1 = 0;
	tag_t* arrWipProcTag1 = NULL;
	int  numWipProc2= 0;
	int iCntWipProc2 = 0;
	tag_t* arrWipProcTag2 = NULL;
	int  numWipProc3= 0;
	int iCntWipProc3 = 0;
	tag_t* arrWipProcTag3 = NULL;
	int  numWipProc4= 0;
	int iCntWipProc4 = 0;
	tag_t* arrWipProcTag4 = NULL;
	int  numWipProc5= 0;
	int iCntWipProc5 = 0;
	tag_t* arrWipProcTag5 = NULL;
	int  numWipProc6= 0;
	int iCntWipProc6 = 0;
	tag_t* arrWipProcTag6 = NULL;

	int  numWipProc7= 0;
	int iCntWipProc7 = 0;
	tag_t* arrWipProcTag7 = NULL;

	int  numWipProc8= 0;
	int iCntWipProc8 = 0;
	tag_t* arrWipProcTag8 = NULL;

	int  numWipProc9= 0;
	int iCntWipProc9 = 0;
	tag_t* arrWipProcTag9 = NULL;

	int  numWipProc10= 0;
	int iCntWipProc10 = 0;
	tag_t* arrWipProcTag10 = NULL;

	int  numWipProc11= 0;
	int iCntWipProc11 = 0;
	tag_t* arrWipProcTag11 = NULL;

	int  numWipProc12= 0;
	int iCntWipProc12 = 0;
	tag_t* arrWipProcTag12 = NULL;


	date_t currentDateAndTime;
	char* qry_name1 = NULL;
	char* qry_name2 = NULL;
	char* qry_name3 = NULL;
	char* qry_name4 = NULL;
	char* qry_name5 = NULL;
	char* qry_name6 = NULL;
	char* qry_name7 = NULL;
	char* qry_name8 = NULL;
	char* qry_name9 = NULL;
	char* qry_name10 = NULL;
	char* qry_name11 = NULL;
	char* qry_name12 = NULL;

	int entry_count1 = 0;
	char **entries1 = NULL;
	char **values1 = NULL;
	int entry_count2 = 0;
	char **entries2 = NULL;
	char **values2 = NULL;
	int entry_count3 = 0;
	char **entries3 = NULL;
	char **values3 = NULL;
	int entry_count4 = 0;
	char **entries4 = NULL;
	char **values4 = NULL;
	int entry_count5 = 0;
	char **entries5 = NULL;
	char **values5 = NULL;
	int entry_count6 = 0;
	char **entries6 = NULL;
	char **values6 = NULL;

	int entry_count7 = 0;
	char **entries7 = NULL;
	char **values7 = NULL;

	int entry_count8 = 0;
	char **entries8 = NULL;
	char **values8 = NULL;

	int entry_count9 = 0;
	char **entries9 = NULL;
	char **values9 = NULL;


	int entry_count10 = 0;
	char **entries10 = NULL;
	char **values10 = NULL;


	int entry_count11 = 0;
	char **entries11 = NULL;
	char **values11 = NULL;


	int entry_count12 = 0;
	char **entries12 = NULL;
	char **values12 = NULL;

	logical isTaskPending = FALSE;

	/*
	IMCALL( iFail, SITE_ask_default_ods( &ods_site_id) );
	*/
	GetCurrentDateTime(&currentDateAndTime);

	qry_name1 = IMAN_text("InDictionaryWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name1, &qry_tag));

	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count1, &entries1, &values1));

	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count1, entries1, values1, &numWipProc1, &arrWipProcTag1)) ;

	for( iCntWipProc1 = 0; iCntWipProc1 < numWipProc1; iCntWipProc1++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag1[ iCntWipProc1]));
	}

	qry_name2 = IMAN_text("InParamvalueWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name2, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count2, &entries2, &values2));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count2, entries2, values2, &numWipProc2, &arrWipProcTag2)) ;

	for( iCntWipProc2 = 0; iCntWipProc2 < numWipProc2; iCntWipProc2++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag2[ iCntWipProc2]));
		isTaskPending = FALSE;
	}

	qry_name3 = IMAN_text("InParamauthoringWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name3, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count3, &entries3, &values3));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count3, entries3, values3, &numWipProc3, &arrWipProcTag3)) ;

	for( iCntWipProc3 = 0; iCntWipProc3 < numWipProc3; iCntWipProc3++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag3[ iCntWipProc3]));
		isTaskPending = FALSE;
	}


	qry_name4 = IMAN_text("InDCRWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name4, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count4, &entries4, &values4));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count4, entries4, values4, &numWipProc4, &arrWipProcTag4)) ;

	for( iCntWipProc4 = 0; iCntWipProc4 < numWipProc4; iCntWipProc4++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag4[ iCntWipProc4]));
		isTaskPending = FALSE;
	}

	qry_name5 = IMAN_text("InDTWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name5, &qry_tag));

	if(qry_tag == NULLTAG)
    {
	  printf("\n\"InDTWorkflow_query\" query is not available in tc server\n");
    }


	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count5, &entries5, &values5));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count5, entries5, values5, &numWipProc5, &arrWipProcTag5)) ;

	TC_write_syslog("\nnumWipProc5 = %d \n ", numWipProc5 );

	for( iCntWipProc5 = 0; iCntWipProc5 < numWipProc5; iCntWipProc5++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending,arrWipProcTag5[ iCntWipProc5]));
		isTaskPending = FALSE;
	}

	qry_name6 = IMAN_text("InDTSubWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name6, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count6, &entries6, &values6));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count6, entries6, values6, &numWipProc6, &arrWipProcTag6)) ;

	for( iCntWipProc6 = 0; iCntWipProc6 < numWipProc6; iCntWipProc6++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag6[ iCntWipProc6]));
		isTaskPending = FALSE;
	}


	qry_name7 = IMAN_text("InDTConnApprovalWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name7, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count7, &entries7, &values7));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count7, entries7, values7, &numWipProc7, &arrWipProcTag7)) ;

	for( iCntWipProc7 = 0; iCntWipProc7 < numWipProc7; iCntWipProc7++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag7[ iCntWipProc7]));
		isTaskPending = FALSE;
	}

	qry_name8 = IMAN_text("InDTComplApprovalWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name8, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count8, &entries8, &values8));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count8, entries8, values8, &numWipProc8, &arrWipProcTag8)) ;

	for( iCntWipProc8 = 0; iCntWipProc8 < numWipProc8; iCntWipProc8++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag8[ iCntWipProc8]));
		isTaskPending = FALSE;
	}

	qry_name9 = IMAN_text("InDTRelApprovalWorkflow_query");
	IMCALL( iFail, QRY_find (qry_name9, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count9, &entries9, &values9));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count9, entries9, values9, &numWipProc9, &arrWipProcTag9)) ;

	for( iCntWipProc9 = 0; iCntWipProc9 < numWipProc9; iCntWipProc9++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag9[ iCntWipProc9]));
		isTaskPending = FALSE;
	}

	qry_name10 = IMAN_text("__InGSDB_Change_Request_Workflow_query");
	IMCALL( iFail, QRY_find (qry_name10, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count10, &entries10, &values10));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count10, entries10, values10, &numWipProc10, &arrWipProcTag10)) ;

	for( iCntWipProc10 = 0; iCntWipProc10 < numWipProc10; iCntWipProc10++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag10[ iCntWipProc10]));
		isTaskPending = FALSE;
	}

	qry_name11 = IMAN_text("__InGCMRS_Msg_Request_Workflow_query");
	IMCALL( iFail, QRY_find (qry_name11, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count11, &entries11, &values11));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count11, entries11, values11, &numWipProc11, &arrWipProcTag11)) ;

	for( iCntWipProc11 = 0; iCntWipProc11 < numWipProc11; iCntWipProc11++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag11[ iCntWipProc11]));
		isTaskPending = FALSE;
	}


	qry_name12 = IMAN_text("__InGCMRS_NID_Request_Workflow_query");
	IMCALL( iFail, QRY_find (qry_name12, &qry_tag));
	IMCALL( iFail,  QRY_find_user_entries ( qry_tag, &entry_count12, &entries12, &values12));
	IMCALL( iFail,  QRY_execute ( qry_tag, entry_count12, entries12, values12, &numWipProc12, &arrWipProcTag12)) ;

	for( iCntWipProc12 = 0; iCntWipProc12 < numWipProc12; iCntWipProc12++)
	{
		IMCALL( iFail, FVE_recursive_process_qry(&isTaskPending, arrWipProcTag12[ iCntWipProc12]));
		isTaskPending = FALSE;
	}

	SAFE_MEMFREE( arrWipProcTag);
	SAFE_MEMFREE( arrWipProcTag1);
	SAFE_MEMFREE( arrWipProcTag2);
	SAFE_MEMFREE( arrWipProcTag3);
	SAFE_MEMFREE( arrWipProcTag4);
	SAFE_MEMFREE( arrWipProcTag5);
	SAFE_MEMFREE( arrWipProcTag6);
	SAFE_MEMFREE( arrWipProcTag7);
	SAFE_MEMFREE( arrWipProcTag8);
	SAFE_MEMFREE( arrWipProcTag9);
	SAFE_MEMFREE( arrWipProcTag10);
	SAFE_MEMFREE( arrWipProcTag11);
	SAFE_MEMFREE( arrWipProcTag12);

	return iFail;
}

static void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: FVE_reminder_notification <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<User ID>   Teamcenter userid for sending reminder notification.\n");
        printf(" -p=<pswd> Teamcenter passwd for userid .\n");
        printf(" -g=<grp>  Teamcenter grp for userid .\n");
        printf(" -pf=<path of encrypted passwd file>  complete Password file path where encrypted password is stored.\n");
        printf("**********************************************************************************\n\n");

}
/****************************************************************************/
/* Function Name :    readAndDecryptPasswd                                    */
/*                                                                          */
/* Called From  :    ITK_user_main()                                        */
/*                                                                          */
/* Functions called:                                                        */
/*                                                                          */
/* File Description : Reads the encrypted password from the input password  */
/*                   file, decrypts and returns the decrypted password      */
/****************************************************************************/
/*            M  O  D  I  F  I  C  A  T  I  O  N      L  O  G               */
/****************************************************************************/
/****************************************************************************/
/*    Date            Author                 Description                    */
/*  ----------     -------------------    --------------------------------- */
/*  10/21/2004      Ramesh Ramaiah            Initial Creation              */
/****************************************************************************/

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;


    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        if( logfileptr )
        fprintf( logfileptr, "ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);

    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }

    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;

    return ifail;

}

extern int ITK_user_main( int argc, char **argv )
{
	int iFail = ITK_ok;
    char *user_id=NULL;
    char *user_pass=NULL;
    char *user_grp=NULL;
    char  *pwdFile = NULL;
    char             logfilename[555 + 1] = "";
    time_t           clock;
	 struct tm *time_struct;
     const char *  tempFileDir =  NULL;

	tempFileDir = getenv("TC_TMP_DIR");
	if( NULL == tempFileDir)
	{
        printf( "ERROR: Environment TC_TMP_DIR not set Please set and run the utility again \n\n");
        return !ITK_ok ;
	}


    time( &clock );

	if( argc == 1 )
    {
        print_usage();
        exit(0);
    }
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }
    time_struct= localtime(&clock);


#ifdef UNX

      sprintf(logfilename,"%s%s%s_%d_%02d_%02d_%d_%02d:%02d.log",tempFileDir, "/" ,"FVE_reminder_notification",getpid(),
                 (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );



#else
	 sprintf(logfilename,"%s,%s,%s_%02d_%02d_%d_%02d:%02d.log",tempFileDir, PATHDELIM,argv[0],
                    (time_struct->tm_mon+1), time_struct->tm_mday,
                 (time_struct->tm_year + 1900 ),time_struct->tm_hour,time_struct->tm_min );
#endif

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);
    if( logfileptr )
    {
        fprintf(logfileptr,"Utility name: %s\n\n",argv[0]);
        fprintf(logfileptr,"Start time: %s\n", ctime( &clock ) );
    }

	user_id = ITK_ask_cli_argument("-u=");
	user_pass = ITK_ask_cli_argument("-p=");
	user_grp = ITK_ask_cli_argument("-g=");
    pwdFile = ITK_ask_cli_argument("-pf=");


    if( pwdFile != 0 )
    {
        IMCALL( iFail , readAndDecryptPasswd( pwdFile, &user_pass )) ;
    }

	IMCALL( iFail , ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	IMCALL( iFail , ITK_init_module ( user_id, user_pass, user_grp));

	IMCALL( iFail, FVE_execute_wip_process_for_reminder_notification( ));

    fclose( logfileptr );

	return iFail;
}

