//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================


#ifndef TEAMCENTER_CLIENTX_SOAEXCEPTIONHANDLER_HXX
#define TEAMCENTER_CLIENTX_SOAEXCEPTIONHANDLER_HXX





#include <string>


#include <teamcenter/schemas/soa/_2006_03/exceptions/InternalServerException.hxx>
#include <teamcenter/soa/client/ExceptionHandler.hxx>
#include <teamcenter/soa/client/CanceledOperationException.hxx>





namespace Teamcenter
{
    namespace ClientX
    {
        class AppXExceptionHandler;



/**
 * Implementation of the ExceptionHandler. For ConnectionExceptions (server
 * temporarily down .etc) prompts the user to retry the last request. For other
 * exceptions convert to a RunTime exception.
 */
class  AppXExceptionHandler: public Teamcenter::Soa::Client::ExceptionHandler
{
public:


    virtual void handleException(Teamcenter::Schemas::Soa::_2006_03::Exceptions::InternalServerException& ise);
    virtual void handleException(Teamcenter::Soa::Client::CanceledOperationException& coe);

};


}} //end namespace
#endif

