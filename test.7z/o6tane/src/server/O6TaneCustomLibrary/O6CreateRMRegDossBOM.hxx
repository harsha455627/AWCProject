//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension O6CreateRMRegDossBOM
 *
 */

#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <O6TaneCustomLibrary/O6ActionHandlers.hxx>

#ifndef O6CREATERMREGDOSSBOM_HXX
#define O6CREATERMREGDOSSBOM_HXX
#include <tccore/method.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern O6TANECUSTOMLIBRARY_API int O6CreateRMRegDossBOM(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
                
#endif  // O6CREATERMREGDOSSBOM_HXX
