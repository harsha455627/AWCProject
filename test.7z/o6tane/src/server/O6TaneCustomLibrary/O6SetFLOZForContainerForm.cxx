//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6SetFLOZForContainerForm
 *
 */
#include <O6TaneCustomLibrary/O6SetFLOZForContainerForm.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>

#define UOM_ML "ml"
#define O6_CONTENANCE_UNITE "o6_contenance_unite"
#define O6_CONTENANCE_AFFICHE "o6_contenance_affiche"
#define O6_FL_OZ "o6_fl_oz"

/**
 * Function    :  O6SetFLOZForContainerForm
 * Description :  Used to set property value for property o6_fl_oz on O6_Contenance form.
 * Input       :
 *      msg 		 - Input msg for extension
 *      args         - Input args for extension
 * Output	   :
 * 		none
 */

int O6SetFLOZForContainerForm( METHOD_message_t * /*msg*/, va_list args )
{
	int retcode = ITK_ok;

    va_list largs;
    va_copy( largs, args );
    tag_t tFormTag = va_arg ( largs, tag_t );
    //logical  isNew = va_arg ( largs, logical );
    va_end( largs );

    if ( tFormTag != NULLTAG )
    {
    	char* pcUnit = NULL;

    	ITK ( AOM_ask_value_string ( tFormTag, O6_CONTENANCE_UNITE, &pcUnit ) );

    	if ( retcode == ITK_ok && pcUnit != NULL && strlen ( pcUnit ) > 0 )
    	{
    		if ( tc_strcmp ( pcUnit, UOM_ML ) == 0 )
    		{
    			double dAffiche = 0.0;

    			ITK ( AOM_ask_value_double ( tFormTag, O6_CONTENANCE_AFFICHE, &dAffiche ) );

    			if ( retcode == ITK_ok )
    			{
    				double dFLOz = 0.0;

    				int iCast    = 0;

    				dFLOz = dAffiche / 29.5735;

    				iCast = ( int )( dFLOz * 10 ); // To make double value limited to just one decimal place.
    				dFLOz = ( ( double ) iCast ) / 10;

    				ITK ( AOM_refresh ( tFormTag, true ) );
    				ITK ( AOM_set_value_double ( tFormTag, O6_FL_OZ, dFLOz ) );
    				ITK ( AOM_save_without_extensions ( tFormTag ) );
    				ITK ( AOM_refresh ( tFormTag, false ) );
    			}
    		}
    		else
    		{
    			logical lIsNullOrEmpty = NULL;

				ITK ( AOM_is_null_empty ( tFormTag, O6_FL_OZ, 0, &lIsNullOrEmpty ) );

				if ( lIsNullOrEmpty == FALSE )
				{
					ITK ( AOM_refresh ( tFormTag, true ) );
					ITK ( AOM_set_value_double ( tFormTag, O6_FL_OZ, 0.0 ) );
					ITK ( AOM_save_without_extensions ( tFormTag ) );
					ITK ( AOM_refresh ( tFormTag, false ) );
				}
    		}
    	}
    	else
    	{
    		logical lIsNullOrEmpty = NULL;

			ITK ( AOM_is_null_empty ( tFormTag, O6_FL_OZ, 0, &lIsNullOrEmpty ) );

			if ( lIsNullOrEmpty == FALSE )
			{
				ITK ( AOM_refresh ( tFormTag, true ) );
				ITK ( AOM_set_value_double ( tFormTag, O6_FL_OZ, 0.0 ) );
				ITK ( AOM_save_without_extensions ( tFormTag ) );
				ITK ( AOM_refresh ( tFormTag, false ) );
			}
    	}
    	if ( pcUnit != NULL )
    	{
    		MEM_free ( pcUnit );
    		pcUnit = NULL;
    	}
    }
	return retcode;
}
