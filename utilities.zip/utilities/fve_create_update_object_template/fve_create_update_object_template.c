/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: fve_create_update_Object_template.c
    Module  : main

        Used to create and update Object template
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>
===============================================================================
Date               Name                    Description of Change
23-Oct-2013        Soumalya Sinha              Initial version
===============================================================================*/
#include <time.h>
#include "fve_create_update_object_template.h"

/* Global Attributes */
char *          login_group                     = NULL;
char *          login_user                      = NULL;
char *          login_password                  = NULL;
char *          login_passfile                  = NULL;
FILE *logfileptr = NULL;

/*******************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *   This utility will read the input file ,create Object/spec template if not present . If present will update them
 *
 * Usage:
 *   fve_create_update_Object_template -u=user -p=password -g=group -i=Input definition name -f=path of the directory holding the template files
 *
 * ARGUMENTS
 *   u              In     User name
 *   p              In     Password
 *   pf             In     Password File
 *   g              In     Group
 *   i              In     Input definition name
 *   f              In     path of the directory holding the template files
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description
 * ----------     -------------------    -----------------------------
 *  Oct 2013      Soumalya Sinha             Created
 *
 ******************************************************************************/

extern int ITK_user_main( int argc, char **  argv )
{
    int             ifail                           = ITK_ok;
    int             i                               = 0;
    int             line_count                      = 0;
    char *          def_file                        = NULL;
    char *          template_home                   = NULL;
    char *          template_name                   = NULL;
    char *          template_file                   = NULL;
	char *          template_type                   = NULL;
	char            fileline[257]                   = "";
	char            fileline_tmp[257]               = "";
    FILE *          inputfileptr                    = NULL;
	char            logfilename[255 + 1]            = "";
	char *          time_stamp                      = NULL;
    char *          ptr						        = NULL;
	int				deleteTemplate					= 0;
	logical         is_template_name_null			=	FALSE;

    /*Append the log file name with the date and time stamp 
    along with Process ID */
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"UPD_OBJECT_TEMPLATE_%s.log",time_stamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }

    printf("\nLog information will be written into %s\n\n",logfilename);
        
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
        fprintf(logfileptr,"argc: %d\n", argc);
        FVE_FREE(time_stamp)
    }
    

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

    login_user     = ITK_ask_cli_argument("-u=");
    login_password = ITK_ask_cli_argument("-p=");
    login_passfile = ITK_ask_cli_argument("-pf=");
    login_group    = ITK_ask_cli_argument("-g=");
    def_file       = ITK_ask_cli_argument("-i=");
    template_home  = ITK_ask_cli_argument("-f=");

    if( ITK_ask_cli_argument( "-delete" ) )
    {
        deleteTemplate = 1;
    }

    ITK_initialize_text_services (0);

    if ( login_user != NULL && strlen(login_user)!=0 
        &&  login_password != NULL && strlen(login_password)!=0 
        &&  login_group != NULL && strlen(login_group)!=0)
    {
        ITK(ITK_init_module (login_user, login_password, login_group))
        if(ifail != ITK_ok)
        {
            fprintf(logfileptr,"Login with uid: %s, group:%s is unsuccessful\n", login_user, login_group);
            exit(1);
        }
        else
            fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n", login_user, login_group);
    }
    else
    {
        ITK_initialize_text_services (0);
        ITK (ITK_auto_login ());
        if(ifail != ITK_ok)
        {
            fprintf(logfileptr,"Auto Login unsuccessful\n");
            exit(1);
        }
        else
            fprintf(logfileptr,"Auto Login successful\n");
    }


    fprintf(logfileptr,"-------------------------------------------------------------------\n\n");

    /*Read input file */
    inputfileptr = fopen( def_file, "r");
    if (!inputfileptr)
    {
       printf("Unable to read definition file , utility terminating.\n\n");
	   fprintf(logfileptr,"Unable to read definition file , utility terminating.\n\n");
       goto CLEANUP;
    }

    /* Process input file */
    while (fgets(fileline, 256, inputfileptr) != NULL) 
    {
      char * token    = NULL;
      template_name   = NULL;
      template_file   = NULL;
	  template_type   = NULL;
        
	  line_count++ ;

	  fprintf(logfileptr,"Processing for Line Number =%d\n", line_count);
	  fflush(logfileptr);

     

	  if(fileline && tc_strlen(fileline)> 0){
		  
		/* Remove the trailing new-line added by fgets */
				 
		tc_strcpy( fileline_tmp, strtok( fileline, "\n" ));

		ptr = tc_strtok(fileline_tmp, ",");

		FVE_get_value(ptr, &template_name, &is_template_name_null);

		if(is_template_name_null == FALSE){
		fprintf(logfileptr,"Template Name = %s\n",template_name);
		fflush(logfileptr);

		}else{
		fprintf(logfileptr,"Template Name is NULL\n");
		fflush(logfileptr);
		continue;


		}
	  }

      if (template_name)
      {
		template_file = (char *) tc_strtok(NULL,",");

         if (template_file)
         {
            fprintf(logfileptr,"Template File = %s\n",template_file);
	        fflush(logfileptr);
         }
		 else
		 {
			 fprintf(logfileptr,"Template File is NULL\n");
		     fflush(logfileptr);
			 continue;
		 }

      }


	  if (template_file)
      {
		template_type = (char *) tc_strtok(NULL,",");

         if (template_type)
         {
           
		   if(tc_strcmp (template_type ,"SpecTemplate")==0)
           {
			    fprintf(logfileptr,"Template Type = %s\n",template_type);
	            fflush(logfileptr);
             
		   }
		   else if(tc_strcmp (template_type ,"ObjectTemplate")==0)
		   {
			   fprintf(logfileptr,"Template Type = %s\n",template_type);
	           fflush(logfileptr);

		   }
		   else
		   {

             fprintf(logfileptr,"Template Type = %s is not valid, allowed template types are SpecTemplate and ObjectTemplate ",template_type);
			 fflush(logfileptr);
			 continue;
        
		   }
         }
		 else
		 {
			 fprintf(logfileptr,"Template Type is NULL\n");
		     fflush(logfileptr);
			 continue;

		 }

      }	 
     
		/* If delete argument is supplied then clear the existing data first */
		if (deleteTemplate)
		{
			ifail = fve_delete_office_template(template_name,template_file,template_home,template_type);
		}else{	  
		/* Create/update Office Template */      
			ifail = fve_update_office_template(template_name,template_file,template_home,template_type);
		}
     

	  fprintf(logfileptr,"After calling fve_update_office_template for Line Number =%d\n", line_count);
	  fprintf(logfileptr,"=======================================================================\n\n");
	  fflush(logfileptr);

    }//End of while loop
    fclose(inputfileptr);
    ITK_exit_module( true );
    printf("Utility completed successfully.\n\n");
    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
    FVE_FREE(time_stamp); 

	if (logfileptr ) fclose( logfileptr);

    CLEANUP:

    return ifail;
}

/*******************************************************************************
 * NAME: print_usage
 *
 * DESCRIPTION
 *  prints command usage
 *
 * ARGUMENTS
 *   
 *
 * RETURNS
 *   
 *
 * NOTES
 ******************************************************************************/
static void print_usage(void)
{
        printf("\n********************************************************\n");
        printf("Usage: fve_create_update_Object_template <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<login user id>\n");
        printf(" -p=<login password>\n");
        printf(" -pf=<login password file>\n");
        printf(" -g=<login group>\n");
        printf(" -i=definition filename\n");
        printf(" -f=directory holding templates\n");
        printf(" -delete=run with delete option first before import\n");
        printf("\n");
        printf("***********************************************************\n\n");        
}

/* This function checks the tokenised value is null or not */
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}

/*******************************************************************************
 * NAME: fve_update_office_template
 *
 * DESCRIPTION
 *  Function to create/update excel templates
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *   template_name          In         Name of the template
 *   template_home          In         Full path of the template files
 *   
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/

int fve_update_office_template(char * template_name,char * template_file,char * template_home,char * template_type)
{
    int    ifail                     = ITK_ok;
    int    num_found                 = 0;
	int    loopCounter               = 0;
    char* functionName =  "fve_update_office_template";

	char  *fullpathname              = NULL;
    char  *commandline               = NULL;
	char **att_name                  = NULL;
    char **attr_values               = NULL;

	tag_t  itemOfObjTmplt            = NULLTAG;

    tag_t *objTags                   = NULLTAG;
	tag_t tItemTag = NULLTAG;
	
	
	
   
	fprintf(logfileptr,"Inside fve_update_office_template\n");
	fflush(logfileptr);

    attr_values    = (char **) MEM_alloc(sizeof(char*)*2);
    attr_values[0] = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(attr_values[0],template_name);


    att_name       = (char **) MEM_alloc(sizeof(char*)*2);
    att_name[0]    = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(att_name[0],"object_name");

    fullpathname = (char*) MEM_alloc(sizeof(char)*512);
    commandline  = (char*) MEM_alloc(sizeof(char)*1024);

    
    sprintf(fullpathname,"\"%s//%s\"",template_home,template_file);

    fprintf(logfileptr,"Full Path Name =%s\n",fullpathname);
    fflush(logfileptr);	

    // Update commandline based on if -p or -pf is used for password (file)
    if ( login_password != NULL && strlen(login_password)!=0 )
    {
      sprintf(commandline,"add_req_templates -u=%s -p=%s -g=%s -t=%s -i=%s",login_user,login_password,login_group,template_type,fullpathname);
    }
    else
    {
      sprintf(commandline,"add_req_templates -u=%s -pf=%s -g=%s -t=%s -i=%s",login_user,login_passfile,login_group,template_type,fullpathname);
    }

    attr_values[0] = template_name;



    if(tc_strcmp (template_type , "ObjectTemplate")==0)
    {

    /* search for template_name */
    FV_search_objects_by_attrs(OBJECTTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);

    }

    else if(tc_strcmp (template_type , "SpecTemplate")==0)
    {
              FV_search_objects_by_attrs(SPECTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);

    }

    /* If not found create template */
    if (num_found < 1)
    {        
        
	  fprintf(logfileptr,"No Template found,So Importing Template\n");
      fprintf(logfileptr,"commandline =%s\n",commandline);
	  fflush(logfileptr);		
		/* Call add_req_templates to create template */
      system(commandline);

	 //START
	 //After Import ,Update IP Classification to attached dataset

	 if (objTags)      MEM_free(objTags);

	 if(tc_strcmp (template_type , "ObjectTemplate")==0)
	 {

	  /* search for template_name */
	  FV_search_objects_by_attrs(OBJECTTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);

	 }

	 else if(tc_strcmp (template_type , "SpecTemplate")==0)
	 {
	   FV_search_objects_by_attrs(SPECTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);

	 }

	 fprintf(logfileptr," (%d)-Template found,After Importing the Template\n",num_found);

	 CLEANUP(update_ip_classification_dataset(objTags[0]))
            
    }

	fprintf(logfileptr,"Exiting fve_update_office_template\n");
	fflush(logfileptr);

CLEANUP:
    
    if (objTags)      MEM_free(objTags);
    if (attr_values)  MEM_free(attr_values);
    if (att_name)     MEM_free(att_name);
    if (fullpathname) MEM_free(fullpathname);
    if (commandline)  MEM_free(commandline);
    
    return ifail;

}

/*******************************************************************************
 * NAME: fve_delete_office_template
 *
 * DESCRIPTION
 *  Function to create/update excel templates
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *   template_name          In         Name of the template
 *   template_home          In         Full path of the template files
 *   
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/

int fve_delete_office_template(char * template_name,char * template_file,char * template_home,char * template_type)
{
    int    ifail                     = ITK_ok;
    int    num_found                 = 0;
	int    loopCounter               = 0;
    char* functionName =  "fve_delete_office_template";

	char  *fullpathname              = NULL;
	char **att_name                  = NULL;
    char **attr_values               = NULL;

	tag_t  itemOfObjTmplt            = NULLTAG;

    tag_t *objTags                   = NULLTAG;
	tag_t tItemTag = NULLTAG;
	
	
	
   
	fprintf(logfileptr,"Inside fve_delete_office_template\n");
	fflush(logfileptr);

    attr_values    = (char **) MEM_alloc(sizeof(char*)*2);
    attr_values[0] = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(attr_values[0],template_name);


    att_name       = (char **) MEM_alloc(sizeof(char*)*2);
    att_name[0]    = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(att_name[0],"object_name");

    fullpathname = (char*) MEM_alloc(sizeof(char)*512);

    
    sprintf(fullpathname,"\"%s//%s\"",template_home,template_file);

    fprintf(logfileptr,"Full Path Name =%s\n",fullpathname);
    fflush(logfileptr);	

    //sprintf(commandline,"add_req_templates -u=%s -p=%s -g=%s -t=%s -i=%s",login_user,login_password,login_group,template_type,fullpathname);

	 attr_values[0] = template_name;



	  if(tc_strcmp (template_type , "ObjectTemplate")==0)
	  {

          /* search for template_name */
          FV_search_objects_by_attrs(OBJECTTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);

	  }

	  else if(tc_strcmp (template_type , "SpecTemplate")==0)
	  {
		   FV_search_objects_by_attrs(SPECTEMPLATETYPE,1,att_name,attr_values,&num_found,&objTags);

	  }

    /* If not found create template */
    if (num_found > 0)
    {        
       
    	fprintf(logfileptr," (%d)-Template found,Before deleting the Template\n",num_found);
		
		CLEANUP(delete_item(objTags[0]))

	    fprintf(logfileptr," (After deleting the Template\n");
	}
    

CLEANUP:
    
    if (objTags)      MEM_free(objTags);
    if (attr_values)  MEM_free(attr_values);
    if (att_name)     MEM_free(att_name);
    if (fullpathname) MEM_free(fullpathname);
    
    return ifail;

}

int update_ip_classification_dataset(tag_t item_rev_tag)
{
	// Variables Declaration
	char* rel_type_name = NULL;
	GRM_relation_t*  related_object_list = NULL;
	int relCount = 0;
	int n_rel = 0;
	int	ifail = ITK_ok;
	tag_t item_tag = NULLTAG;	
	tag_t relation_type = NULLTAG;


	// Deleting the attached datasets
	CLEANUP(GRM_list_all_related_objects(item_rev_tag,&relCount,&related_object_list)) 
		for (n_rel=0;n_rel<relCount;n_rel++)
		{	
			CLEANUP(GRM_ask_relation_type (related_object_list[n_rel].the_relation,&relation_type))  
			CLEANUP(AOM_ask_name(relation_type,&rel_type_name))  

			if(strcmp(rel_type_name,"IMAN_specification")== 0) 
			{
				
			   //Added for updating IP_Classfication
				CLEANUP( WSOM_set_ip_classification( related_object_list[n_rel].secondary, IP_PUBLIC ) )
				CLEANUP( AOM_refresh(related_object_list[n_rel].secondary, false ) )
				//Addition Ends				
		    }
            // Deallocate memory
            FVE_FREE(rel_type_name)
		}

		// Freeing memory as these variables won't be used again
		FVE_FREE(related_object_list)


CLEANUP:
		return ifail;

}


int delete_item(tag_t item_rev_tag)
{
	// Variables Declaration
	char* rel_type_name = NULL;
	GRM_relation_t*  related_object_list = NULL;
	int relCount = 0;
	int n_rel = 0;
	int	ifail = ITK_ok;
	tag_t item_tag = NULLTAG;	
	tag_t relation_type = NULLTAG;


	// Deleting the attached datasets
	CLEANUP(GRM_list_all_related_objects(item_rev_tag,&relCount,&related_object_list)) 
		for (n_rel=0;n_rel<relCount;n_rel++)
		{	
			CLEANUP(GRM_ask_relation_type (related_object_list[n_rel].the_relation,&relation_type))  
			CLEANUP(AOM_ask_name(relation_type,&rel_type_name))  

			if(strcmp(rel_type_name,"IMAN_specification")== 0) 
			{
				CLEANUP(delete_references(related_object_list[n_rel].secondary))
				CLEANUP(AOM_refresh(item_rev_tag,TRUE))
				CLEANUP(GRM_delete_relation (related_object_list[n_rel].the_relation))
				CLEANUP(AOM_save (item_rev_tag)) 
				CLEANUP(AOM_refresh(item_rev_tag,FALSE))
				CLEANUP(AOM_lock_for_delete (related_object_list[n_rel].secondary))  
				CLEANUP(AOM_delete (related_object_list[n_rel].secondary))  
		    }
            // Deallocate memory
            FVE_FREE(rel_type_name)
		}

		// Freeing memory as these variables won't be used again
		FVE_FREE(related_object_list)

		// Deleting the references of Item Revision
		CLEANUP(delete_references(item_rev_tag))

		// Deleting the references of Item 
		CLEANUP(ITEM_ask_item_of_rev(item_rev_tag,&item_tag)) 
		CLEANUP(delete_references(item_tag))

		// Deleting item
		CLEANUP(ITEM_delete_item (item_tag)) 

CLEANUP:
		return ifail;

}

int delete_references(tag_t object_tag)
{
	// Variables Declaration
	tag_t*  values_attr = NULL; 	
	tag_t*  values_attr_new = NULL; 
	tag_t*  referencers = NULL;  			
	char* object_type_name = NULL;
	char** relations = NULL; 
	int n_referencersCnt = 0;
	int n_attrCnt = 0;
	int n_referencers = 0;
	int values_attr_newCnt=0;
	int n_attr = 0;  	
	int	ifail = ITK_ok;
	int*  levels = NULL;
    char* function_name = "delete_references";


	// Finding the references of Item
	CLEANUP(WSOM_where_referenced(object_tag,1,&n_referencers,&levels,&referencers,&relations))  

	// Freeing memory as these variables won't be used again
	FVE_FREE(levels)
	FVE_FREE(relations)

	if (n_referencers != 0)
	{ 
		for (n_referencersCnt=0;n_referencersCnt<n_referencers;n_referencersCnt++)
		{
			CLEANUP(AOM_ask_value_string (referencers[n_referencersCnt], fv9object_typePROP,&object_type_name))

			// Dereferencing the Item from parent folder
			if((strcmp(object_type_name,"Folder") == 0) || (strcmp(object_type_name,"Newstuff Folder") == 0)
				|| (strcmp(object_type_name,"Mail Folder") == 0))
			{	
				CLEANUP(AOM_get_value_tags(referencers[n_referencersCnt],FVRM_FOLDER_ATTRIBUTE_NAME,&n_attr,&values_attr))

				// Allocationg memory to the tags array
				values_attr_new = (tag_t *)MEM_alloc((n_attr-1) * sizeof(tag_t));

				for (n_attrCnt=0;n_attrCnt<n_attr;n_attrCnt++)
				{
					if (values_attr[n_attrCnt]==object_tag)
					{
						// Setting the folder's "contents" attribute value to null 
						AM__set_application_bypass(true);
						CLEANUP(AOM_refresh(referencers[n_referencersCnt],TRUE))
						CLEANUP(AOM_set_value_tags  (referencers[n_referencersCnt],FVRM_FOLDER_ATTRIBUTE_NAME,0,NULL)) 
						CLEANUP(AOM_save(referencers[n_referencersCnt]))
						CLEANUP(AOM_refresh(referencers[n_referencersCnt],FALSE))
						AM__set_application_bypass(false);
					}
					else
					{       
						values_attr_new[values_attr_newCnt] = values_attr[n_attrCnt];
						values_attr_newCnt++;
					}
				} 
				/* Restructuring the folder's "contents" attribute which will now not have the item(to be deleted),
				as a value in the contents attribute */  
				AM__set_application_bypass(true);
				CLEANUP(AOM_refresh(referencers[n_referencersCnt],TRUE))
				CLEANUP(AOM_set_value_tags (referencers[n_referencersCnt],FVRM_FOLDER_ATTRIBUTE_NAME,values_attr_newCnt,values_attr_new)) 
				CLEANUP(AOM_save(referencers[n_referencersCnt]))
				CLEANUP(AOM_refresh(referencers[n_referencersCnt],FALSE))
				AM__set_application_bypass(false);

			}
            // Deallocate memory
            FVE_FREE(object_type_name)
            FVE_FREE(values_attr)
		}	
	}
	// Freeing memory
	FVE_FREE(referencers)	  
	FVE_FREE(values_attr_new)

CLEANUP:

	return ifail;
}



