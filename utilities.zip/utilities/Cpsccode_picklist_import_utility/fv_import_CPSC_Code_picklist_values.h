/******************************************************************************
 * Filename        :   fv_import_CPSC_Code_picklist_values.h
 * Description     :   Defines the macro used in fv_import_CPSC_Code_picklist_values
 * Module          :   fv_import_CPSC_Code_picklist_values.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * Sep 2012      Prashant patil       Intial Verison.
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FV_IMPORT_PICKLIST_VALUES_H
#define FV_IMPORT_PICKLIST_VALUES_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>
#include <string.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <FV_prototypes.h>
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <res/res_itk.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <FV_prototypes.h>
#include <FVDT_common.h>

/*************************************************
* Macros Definition
**************************************************/

#define SIGNAL_UNIT_TCTYPE      "FVE_SignalUnit"
#define OBJ_NAME_ATTR           "object_name"
#define UNIT_DESC               "FVE_UnitDesc"
#define UNIT_ABBR               "FVE_Abbreviation"
#define SPACE_BAR                ""
#define Ftype_name              "Feature Dictionary"
#define Stype_name              ("Feature Group")
#define Ttype_name              "Feature"
//#define Ftype_name              "Function"
#define FItype_name             "Function Group"
//#define Stype_name              "Software Component"


/* Property Constant
****************************************************/

#define Picklist_description_cons                             "object_desc"

/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\

#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}
 

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
/*#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\*/

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

int FV_create_workspace_objects(char **Picklist_Type_array,char **Picklist_Value_array,char **ECPSCOwner_array,char **Description_array,int array_cnt);
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );
void get_time_stamp(char* format, char** timestamp);
void FV_get_value_and_store(char * init_value, int cnt, char *** str_array);
#endif /*fv_import_picklist_values*/
