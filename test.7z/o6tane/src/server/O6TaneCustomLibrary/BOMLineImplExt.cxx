//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object BOMLineImpl
//

#include <O6TaneCustomLibrary/BOMLineImplExt.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>

using namespace o6::o6tane;

//----------------------------------------------------------------------------------
// BOMLineImpl::BOMLineImpl(BOMLine& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
BOMLineImpl::BOMLineImpl( BOMLine& busObj )
   : BOMLineGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// BOMLineImpl::~BOMLineImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
BOMLineImpl::~BOMLineImpl()
{
}

//----------------------------------------------------------------------------------
// BOMLineImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int BOMLineImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = BOMLineGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


///
/// Getter for a Double Property
/// @param value - Parameter Value
/// @param isNull - Returns true if the Parameter value is null
/// @return - Status. 0 if successful
///
int  BOMLineImpl::getO6_valueBase( double & /*value*/, bool & /*isNull*/ ) const
{
    int ifail = ITK_ok;

    // Your Implementation

    /***************************************************************************
     * Do not add any code here.                                               *
     * Actual logic has been added on the extension attached to this property. *
     ***************************************************************************/

    return ifail;
}

///
/// Getter for a Double Property
/// @param value - Parameter Value
/// @param isNull - Returns true if the Parameter value is null
/// @return - Status. 0 if successful
///
int  BOMLineImpl::getO6_value_percentBase( double & /*value*/, bool & /*isNull*/ ) const
{
    int ifail = ITK_ok;

    // Your Implementation

    /***************************************************************************
     * Do not add any code here.                                               *
     * Actual logic has been added on the extension attached to this property. *
     ***************************************************************************/

    return ifail;
}

///
/// Getter for a Double Property
/// @param value - Parameter Value
/// @param isNull - Returns true if the Parameter value is null
/// @return - Status. 0 if successful
///
int  BOMLineImpl::getO6_sap_costBase( double & /*value*/, bool & /*isNull*/ ) const
{
    int ifail = ITK_ok;

    // Your Implementation

    /***************************************************************************
     * Do not add any code here.                                               *
     * Actual logic has been added on the extension attached to this property. *
     ***************************************************************************/

    return ifail;
}

