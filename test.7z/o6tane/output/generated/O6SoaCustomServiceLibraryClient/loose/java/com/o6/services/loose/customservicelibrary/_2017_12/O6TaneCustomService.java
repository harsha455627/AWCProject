/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/


package com.o6.services.loose.customservicelibrary._2017_12;

/**
 *
 */
 @SuppressWarnings("unchecked")
public interface O6TaneCustomService
{


    

    /**
     * .
     *
     * @param obj
     *        This is the Teamcenter::BOMLine
     *
     * @return
     *
     */
    public com.teamcenter.soa.client.model.ServiceData calculateQSP ( com.teamcenter.soa.client.model.ModelObject obj );



}
