#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tc/emh_errors.h>
#include <tc/preferences.h>
#include <textsrv/textserver.h>
#include <pom/pom/pom.h>
#include <pom/enq/enq.h>
#include <tccore/custom.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/item_msg.h>
#include <tccore/item_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/workspaceobject.h>
#include <tccore/method.h>
#include <tccore/grm_msg.h>
#include <tccore/tc_msg.h>
#include <user_exits/user_exit_msg.h>
#include <ps/ps.h>
#include <qry/qry.h>
#include <qry/crf.h>
#include <bom/bom_msg.h>
#include <epm/epm.h>
#include <me/me_msg.h>
#include <ae/dataset.h>
#include <ict/ict_userservice.h>
#include <dispatcher/dispatcher_itk.h>
#include <O6TaneCustomLibrary/commun.hxx>
#include <O6TaneCustomLibrary/method.hxx>

int O6Stock_manage_request( EPM_action_message_t msg );
int O6Stock_manage_goods( EPM_action_message_t msg );
int O6Stock_set_goods_request_as_rejected( EPM_action_message_t msg );
int O6Stock_set_goods_request_as_cancelled( EPM_action_message_t msg );
int O6Stock_set_goods_request_as_approved( EPM_action_message_t msg );
int o6_create_form(char *f_name,char *f_desc,char *f_type,char *f_id ,tag_t *form_tag);

int O6Stock_manage_request( EPM_action_message_t msg ) {
	int		irc = ITK_ok,irc_storage = 0,i,num_att,cnt=0,j=0,error_code=0;
  double actual_stock=0.0,new_stock=0.0;
	tag_t root_task,*atts_objects,*wrhs,rel_1=NULLTAG,rel_2=NULLTAG,rel_3=NULLTAG;
  //int mycount=0;
	
	irc = ITK_CALL(EPM_ask_root_task( msg.task, &root_task));
	if (irc != ITK_ok) return irc;
	irc = ITK_CALL(EPM_ask_attachments(root_task, EPM_target_attachment, &num_att, &atts_objects));	
	
  irc = ITK_CALL(GRM_find_relation_type ("O6_GoodsRequestAnswer", &rel_1));
  irc = ITK_CALL(GRM_find_relation_type ("O6_WHGoodsRelReq", &rel_2));
  irc = ITK_CALL(GRM_find_relation_type ("O6_WHGoodsRel", &rel_3));
	for (i=0; i<num_att; i++) {  
    int cnt_1=0,cnt_2;
    tag_t *wrhs_1,*wrhs_2;

    irc = ITK_CALL(GRM_list_primary_objects_only (atts_objects[i], rel_2, &cnt_1, &wrhs_1)); 
    irc = ITK_CALL(GRM_list_secondary_objects_only (atts_objects[i], rel_1, &cnt, &wrhs));
 
    for (j=0; j<cnt; j++){
      double entry=0.0,stock=0.0/*,result=0.0*/;
      irc = ITK_CALL(GRM_list_primary_objects_only (wrhs[j], rel_2, &cnt_2, &wrhs_2)); 
      if (error_code!=1){
        irc = ITK_CALL(AOM_ask_value_double(wrhs[j],"o6_QtyTransmise" , &entry));
        irc = ITK_CALL(AOM_ask_value_double(wrhs[j],"o6_stock_qtt" , &stock));
        if (entry>stock){
          error_code=1;
        }
        else{
          tag_t Frm=NULLTAG, *Frms;
          char *dummy_s, *dummy_s1, f_id_new[12];
          logical dummy_bool=FALSE,EXISTING=FALSE;
          date_t dummy_d;
          double dummy_dbl;
          int i_name, first=1, actual_Frms=0;
          irc = ITK_CALL(AOM_ask_value_string(wrhs[j], "o6_goods_Type", &dummy_s));
          irc = ITK_CALL(AOM_ask_value_string(wrhs[j], "o6_tc_intern_lot_nb", &dummy_s1));
          
          for (i_name=0;i_name<(strlen(dummy_s1));i_name++){
            if (first==1){
              f_id_new[i_name]='9';
              first=0;
            }
            else{
              f_id_new[i_name]=dummy_s1[i_name];
            }
          }
          f_id_new[strlen(dummy_s1)]='\0';
          MEM_free(dummy_s1);
          irc = ITK_CALL(GRM_list_secondary_objects_only(wrhs_1[0],rel_3,&actual_Frms,&Frms));
          for (i_name=0;i_name<actual_Frms;i_name++){
            if (Frm==NULLTAG){
              irc = ITK_CALL(AOM_ask_value_string(Frms[i_name], "o6_tc_intern_lot_nb", &dummy_s1));
              if (strcmp(dummy_s1,f_id_new)==0){
                Frm=Frms[i_name];
                EXISTING = TRUE;
              }
              MEM_free(dummy_s1);
            }
          }
          if (Frm==NULLTAG){
            irc = o6_create_form("Form","Created By NOVELMIND Custom Handler O6Stock_manage_request",dummy_s,f_id_new, &Frm);
            MEM_free(dummy_s);
            irc = ITK_CALL(AOM_refresh(Frm, TRUE));
            irc = ITK_CALL(AOM_set_value_double(Frm, "o6_stock_qtt", entry));
            irc = ITK_CALL(AOM_ask_value_string(wrhs[j], "o6_stock_item_id", &dummy_s));
            irc = ITK_CALL(AOM_set_value_string(Frm, "o6_stock_item_id", dummy_s));
            MEM_free(dummy_s);          
            irc = ITK_CALL(AOM_ask_value_string(wrhs[j], "o6_stock_item_name", &dummy_s));
            irc = ITK_CALL(AOM_set_value_string(Frm, "o6_stock_item_name", dummy_s));
            MEM_free(dummy_s);
            irc = ITK_CALL(AOM_ask_value_string(wrhs[j], "o6_fourn_lot_nb", &dummy_s));
            irc = ITK_CALL(AOM_set_value_string(Frm, "o6_fourn_lot_nb", dummy_s));
            MEM_free(dummy_s);          
            irc = ITK_CALL(AOM_ask_value_string(wrhs[j], "o6_condit_typ", &dummy_s));
            irc = ITK_CALL(AOM_set_value_string(Frm, "o6_condit_typ", dummy_s));
            MEM_free(dummy_s);          
            irc = ITK_CALL(AOM_ask_value_string(wrhs[j], "o6_sap_lot_nb", &dummy_s));
            irc = ITK_CALL(AOM_set_value_string(Frm, "o6_sap_lot_nb", dummy_s));
            MEM_free(dummy_s);
            irc = ITK_CALL(AOM_ask_value_logical(wrhs[j], "o6_usine_issu", &dummy_bool));
            irc = ITK_CALL(AOM_set_value_logical(Frm, "o6_usine_issu", dummy_bool));          
            irc = ITK_CALL(AOM_ask_value_date(wrhs[j], "o6_entre_date", &dummy_d));
            irc = ITK_CALL(AOM_set_value_date(Frm, "o6_entre_date", dummy_d));           
            irc = ITK_CALL(AOM_ask_value_date(wrhs[j], "o6_ouvert_date", &dummy_d));
            irc = ITK_CALL(AOM_set_value_date(Frm, "o6_ouvert_date", dummy_d));           
            irc = ITK_CALL(AOM_ask_value_date(wrhs[j], "o6_fab_date", &dummy_d));
            irc = ITK_CALL(AOM_set_value_date(Frm, "o6_fab_date", dummy_d));  
            irc = ITK_CALL(AOM_ask_value_date(wrhs[j], "o6_dluo", &dummy_d));
            irc = ITK_CALL(AOM_set_value_date(Frm, "o6_dluo", dummy_d)); 
            irc = ITK_CALL(AOM_ask_value_double(wrhs[j], "o6_vie_duree", &dummy_dbl));
            irc = ITK_CALL(AOM_set_value_double(Frm, "o6_vie_duree", dummy_dbl));           
            irc = ITK_CALL(AOM_set_value_int(Frm, "o6_compute_code",100));
            if (cnt_1!=0){
              tag_t dummy_rel_tag=NULLTAG;
              irc = ITK_CALL(GRM_create_relation(wrhs_1[0],Frm,rel_3,NULLTAG,&dummy_rel_tag));
              if (irc==ITK_ok){
                irc = ITK_CALL(AOM_refresh(dummy_rel_tag, TRUE));
                irc = ITK_CALL(GRM_save_relation (dummy_rel_tag));
                irc = ITK_CALL(AOM_refresh(dummy_rel_tag, FALSE));
              }                            
            }
          }
          else{
            MEM_free(dummy_s);
            irc = ITK_CALL(AOM_refresh(Frm, TRUE));
            if  (irc != ITK_ok){
              irc_storage=1;
            }
            else{
              irc = ITK_CALL(AOM_ask_value_double(Frm, "o6_stock_qtt", &actual_stock));
              new_stock=actual_stock+entry;
              irc = ITK_CALL(AOM_set_value_double(Frm, "o6_stock_qtt", new_stock));
            }
          }
          irc = ITK_CALL(AOM_save(Frm));
          ITK_CALL(AOM_refresh(Frm, FALSE));
          if (irc_storage==0){
            irc = ITK_CALL(AOM_refresh(wrhs[j], TRUE));
            if  (irc != ITK_ok){
              irc_storage=2;
              irc = ITK_CALL(AOM_refresh(Frm, TRUE));
              irc = ITK_CALL(AOM_set_value_double(Frm, "o6_stock_qtt", actual_stock));
              irc = ITK_CALL(AOM_save(Frm));
              ITK_CALL(AOM_refresh(Frm, FALSE));
            }
            else{
              dummy_dbl=0.0;
              dummy_dbl=stock-entry;
              if (actual_Frms>0) MEM_free( Frms);
              irc = ITK_CALL(AOM_set_value_double(wrhs[j],"o6_stock_qtt",dummy_dbl));
              irc = ITK_CALL(AOM_save(wrhs[j]));
              irc = ITK_CALL(AOM_set_value_double(wrhs[j],"o6_QtyTransmise",0.0));
              irc = ITK_CALL(AOM_save(wrhs[j]));
              ITK_CALL(AOM_refresh(wrhs[j], FALSE));
            }
          }
          
          if (cnt_1!=0){
            irc=summarize_stock_level(wrhs_1[0]);
          }
          if (cnt_2!=0){
            irc=summarize_stock_level(wrhs_2[0]);
          }
        }
      }
      else{
      }
      if (cnt_2>0)MEM_free(wrhs_2);
    }
    if (cnt_1>0)MEM_free(wrhs_1);
    if (cnt>0)MEM_free(wrhs);
	}
	if (num_att>0) MEM_free(atts_objects);
	return ITK_ok;
}
int O6Stock_manage_goods( EPM_action_message_t msg ) {
	int		irc = ITK_ok,i,num_att,cnt=0/*,j=0,error_code=0*/;
	tag_t root_task,*atts_objects,*wrhs,rel_1=NULLTAG,rel_2=NULLTAG,rel_3=NULLTAG;
  //int mycount=0;
	
	irc = ITK_CALL(EPM_ask_root_task( msg.task, &root_task));
	if (irc != ITK_ok) return irc;
	irc = ITK_CALL(EPM_ask_attachments(root_task, EPM_target_attachment, &num_att, &atts_objects));	
  irc = ITK_CALL(GRM_find_relation_type ("O6_GoodsRequestAnswer", &rel_1));
  irc = ITK_CALL(GRM_find_relation_type ("O6_WHGoodsRelReq", &rel_2));
  irc = ITK_CALL(GRM_find_relation_type ("O6_WHGoodsRel", &rel_3));
	for (i=0; i<num_att; i++) {    
    irc = ITK_CALL(GRM_list_secondary_objects_only (atts_objects[i], rel_1, &cnt, &wrhs));
    if (cnt>0){
      int emp_tpe=EPM_target_attachment;
      irc = ITK_CALL(EPM_add_attachments( root_task, cnt, wrhs, &emp_tpe));
      MEM_free(wrhs);
    }
	}
	if (num_att>0) MEM_free(atts_objects);
	return ITK_ok;
}
int O6Stock_set_goods_request_as_rejected( EPM_action_message_t msg ) {
	int		irc = ITK_ok,i=0,num_att/*,cnt=0*/;
	tag_t root_task,*atts_objects;
  //int mycount=0;
  char *p_string=NULL;
	
	irc = ITK_CALL(EPM_ask_root_task( msg.task, &root_task));
	if (irc != ITK_ok) return irc;
	irc = ITK_CALL(EPM_ask_attachments(root_task, EPM_target_attachment, &num_att, &atts_objects));	
  for (i=0;i<num_att;i++){
    irc= ITK_CALL(AOM_ask_value_string(atts_objects[i],"object_type",&p_string));
    if (strcmp(p_string,"O6_GoodsRequest") ==0){
      irc = ITK_CALL(AOM_refresh(atts_objects[i], TRUE));
      irc= ITK_CALL(AOM_set_value_string(atts_objects[i],"o6_Answer_Type","Rejected"));
      irc = ITK_CALL(AOM_save(atts_objects[i]));
      irc = ITK_CALL(AOM_refresh(atts_objects[i], FALSE));
      
    }
    MEM_free(p_string);
  }
	if (num_att>0) MEM_free(atts_objects);
	return ITK_ok;
}
int O6Stock_set_goods_request_as_cancelled( EPM_action_message_t msg ) {
	int		irc = ITK_ok,i=0,num_att/*,cnt=0*/;
	tag_t root_task,*atts_objects;
  /*int mycount=0;*/
  char *p_string=NULL;
	
	irc = ITK_CALL(EPM_ask_root_task( msg.task, &root_task));
	if (irc != ITK_ok) return irc;
	irc = ITK_CALL(EPM_ask_attachments(root_task, EPM_target_attachment, &num_att, &atts_objects));	
  for (i=0;i<num_att;i++){
    irc= ITK_CALL(AOM_ask_value_string(atts_objects[i],"object_type",&p_string));
    if (strcmp(p_string,"O6_GoodsRequest") ==0){
      irc = ITK_CALL(AOM_refresh(atts_objects[i], TRUE));
      irc= ITK_CALL(AOM_set_value_string(atts_objects[i],"o6_Answer_Type","Cancelled"));
      irc = ITK_CALL(AOM_save(atts_objects[i]));
      irc = ITK_CALL(AOM_refresh(atts_objects[i], FALSE));
      
    }
    MEM_free(p_string);
  }
	if (num_att>0) MEM_free(atts_objects);
	return ITK_ok;
}
int O6Stock_set_goods_request_as_approved( EPM_action_message_t msg ) {
	int		irc = ITK_ok,i=0,num_att/*,cnt=0*/;
	tag_t root_task,*atts_objects;
  //int mycount=0;
  char *p_string=NULL;
	
	irc = ITK_CALL(EPM_ask_root_task( msg.task, &root_task));
	if (irc != ITK_ok) return irc;
	irc = ITK_CALL(EPM_ask_attachments(root_task, EPM_target_attachment, &num_att, &atts_objects));	
  for (i=0;i<num_att;i++){
    irc= ITK_CALL(AOM_ask_value_string(atts_objects[i],"object_type",&p_string));
    if (strcmp(p_string,"O6_GoodsRequest") ==0){
      irc = ITK_CALL(AOM_refresh(atts_objects[i], TRUE));
      irc= ITK_CALL(AOM_set_value_string(atts_objects[i],"o6_Answer_Type","Approved"));
      irc = ITK_CALL(AOM_save(atts_objects[i]));
      irc = ITK_CALL(AOM_refresh(atts_objects[i], FALSE));
      
    }
    MEM_free(p_string);
  }
	if (num_att>0) MEM_free(atts_objects);
	return ITK_ok;
}
int o6_create_form(char *f_name,char *f_desc,char *f_type,char *f_id ,tag_t *form_tag)  
{
  int		irc = ITK_ok;
	tag_t 	f_type_tag = (tag_t)NULL,f_create_input_tag = (tag_t)NULL;

    irc = ITK_CALL(TCTYPE_find_type("O6_Goods", NULL, &f_type_tag));
    irc = ITK_CALL(TCTYPE_construct_create_input(f_type_tag, &f_create_input_tag));
    irc = ITK_CALL(AOM_set_value_string(f_create_input_tag, "o6_tc_intern_lot_nb", f_id));
    irc = ITK_CALL(AOM_set_value_string(f_create_input_tag, "object_name", f_name));
    irc = ITK_CALL(AOM_set_value_string(f_create_input_tag, "object_desc", f_desc));
    irc = ITK_CALL(AOM_set_value_string(f_create_input_tag, "o6_goods_Type", f_type));
    irc = ITK_CALL(TCTYPE_create_object(f_create_input_tag, form_tag));
    irc = ITK_CALL(AOM_save_with_extensions(*form_tag));
	return ITK_ok;
}

  
