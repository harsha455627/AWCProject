/******************************************************************************
 * Filename        :   FVE_change_ownership.h
 * Description     :   Defines the macro used in FVE_change_ownership.c
 * Module          :   FVE_change_ownership.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * July, 25 2011    Mruthyunjayam A      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_CHANGE_ITEM_ID_H
#define FVE_CHANGE_ITEM_ID_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/tctype.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <res/res_itk.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>

/*************************************************
* Macros Definition
**************************************************/

#define SPACE_BAR				" "

#define DATE_FORMAT_STR			"%m%d%Y_%H%M%S"

#define VSEM_UTIL_LOG_DIR_VAR "VSEM_UTIL_LOG_DIR"

/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

#define DATE_FORMAT      "%d-%b-%Y"

#define ITK(x) \
{\
   if ( ifail == ITK_ok )\
   {\
      if((ifail = (x)) != ITK_ok)\
      {\
         dump_itk_errors ( ifail, #x, __LINE__, __FILE__ );\
      }\
   }\
}\


int FVE_change_id(char *, char *);

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, 
					 const char * fileName );

void get_time_stamp(char* format, char** timestamp);

void FVE_get_value(char * init_value, char ** attr, logical * is_value_null);
int fve_set_usr_and_mod_date_back( tag_t object_tag,  date_t obj_last_moddate,tag_t obj_last_modusr_tag);
int fve_get_last_mod_date_and_usr( tag_t object_tag, date_t *obj_last_moddate, tag_t *obj_last_modusr_tag );
#endif /* FVE_CHANGE_ITEM_ID_H */
