/**********************************************************************************
 * Filename        :   IM_Auto_CheckIn_as_Infodba.h
 * Description     :   Defines the macro used in IM_Auto_CheckIn_as_Infodba.c
 * Module          :   IM_Auto_CheckIn_as_Infodba.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *---------------------------------------------------------------------------------
 * Date              Name              Description of Change
 * Aug 2014          Soumalya Sinha        Initial Code
 * --------------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FV9_UPD_DT_DEVICE_NAME_H
#define FV9_UPD_DT_DEVICE_NAME_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>
#include <FV_includes.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>
#include <ps/ps.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <sys/stat.h>
#include <FVE_user_common.h>

/*************************************************
* Macros Definition
**************************************************/


/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
/*#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\;*/ //modified by harsha //included "FVE_user_common.h"



void get_time_stamp(char* format, char** timestamp);
int FV_IM_find_all_loggedin_users(int* loggedin_users_num,char*** loggedin_users);

#endif /* FVE_UPDATE_USER_PREFERENCE_H */