#include <stdio.h>
#include <string.h>
#include <time.h>

#include <tc/tc.h>
#include <tc/emh.h>
#include <sa/am.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>

#include <O6TaneCustomLibrary/commun.hxx>



//
static char	APP_name[133] = NOT_DEFINED_APPL;
static char	APP_version[33] = NOT_DEFINED_VER;

//
void init_log(char *name, char *ver) {

	if (strcmp(APP_name,  NOT_DEFINED_APPL) == 0) {
		strcpy(APP_name, name);
		strcpy(APP_version, ver);

		print_log("Init log CLEMENT LEBRASSEUR %s version %s - compiled %s %s", name, ver, __DATE__,  __TIME__);
	}
}

//
void print_log(char *fmt, ...) {
	va_list args;
	char	messg[512],
			*pt;

	*messg = '\0';
	va_start(args, fmt);
	vsprintf(messg, fmt, args);
	va_end(args);

	for (pt=messg; *pt != '\0'; pt++) if (*pt == '%') *pt=' ';

	TC_write_syslog("[%s] %s\n", APP_name, messg);
}

//
void itk_trace(char *fmt, ...) {
#ifdef TRACE
	va_list args;
	char	messg[512];
			//*pt;

	*messg = '\0';
	va_start(args, fmt);
	vsprintf(messg, fmt, args);
	va_end(args);

	print_log(messg);
#endif
}


//
void itk_start(char *file, int line, char *fct) {
	print_log("START: %s Line %d on File %s", fct, line, file);
}

//
void itk_print_object(char *title, tag_t obj) {
#ifdef TRACE
	logical	verdict;
	char	messg[256],
			uid[133],
			*pt;

	*messg = '\0';
	*uid = '\0';
	pt = (char*)NULL;

	if (obj != NULL_TAG) {
		is_class(obj, "WorkspaceObject", TRUE, &verdict);

		if (verdict == TRUE) {
			ITK_CALL(WSOM_ask_object_id_string(obj, &pt));

			if (pt != (char*)NULL) {
				strcpy(messg, pt);
			   	MEM_free(pt);
				pt = (char*)NULL;
			}
		}
		else {
			tag_t	class_id;

			ITK_CALL(POM_class_of_instance(obj, &class_id));
			ITK_CALL(POM_name_of_class(class_id, &pt));

			if (pt != (char*)NULL) {
				strcpy(messg, pt);
			   	MEM_free(pt);
				pt = (char*)NULL;
			}
		}

		ITK_CALL(POM_tag_to_uid(obj, &pt));
		if (pt != (char*)NULL) {
			strcpy(uid, pt);
		   	MEM_free(pt);
			pt = (char*)NULL;
		}
		 
	}
	else {
		strcpy(messg, "NULL_TAG");
	}

	print_log("%s: %s (%d / %s)", title, messg, obj, uid);

#endif
}
/*================================================================================================*/
int clear_arr_attribute ( const tag_t obj_tag, char *sAttr ) {
		int 	irc=ITK_ok;
		
		itk_trace("clear_arr_attribute  ----- Object must be locked for Write");
		itk_trace("clear_arr_attribute  ----- Try to clear Array Attribute: %s", sAttr);
		irc = ITK_CALL(AOM_set_value_strings (obj_tag, sAttr, 0, (char**)NULL));
		if (irc != ITK_ok) {
			itk_trace("clear_arr_attribute ----- error");
			irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
			return irc;	
		}
		irc = ITK_CALL(AOM_save(obj_tag));
		if (irc != ITK_ok) {
			itk_trace("clear_arr_attribute ----- error");
			irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
			return irc;		
		}
		itk_trace("clear_arr_attribute  ----- Array Attribute is empty");
	return ITK_ok;
}
/*================================================================================================*/
int set_arr_attribute ( const tag_t obj_tag, char *sAttr, char *value ) {
	int 	count= 0,
			irc=ITK_ok;
	char 	**sAttrValue = (char**)NULL;
	
	itk_trace("----- O6Stock ----- set_arr_attribute  ----- Attribute: %s Value: %s", sAttr, value);
	irc = ITK_CALL(AOM_ask_value_strings(obj_tag,sAttr, &count, &sAttrValue));
	MEM_free(sAttrValue);
	irc = ITK_CALL(AOM_set_value_string_at (obj_tag, sAttr, count, value));
	if (irc != ITK_ok) {
		itk_trace("set_arr_attribute ----- error");
		irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
		return irc;	
	}
	irc = ITK_CALL(AOM_save(obj_tag));
	if (irc != ITK_ok) {
		itk_trace("set_arr_attribute ----- error");
		irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
		return irc;		
	}
	itk_trace("set_arr_attribute  ----- Array Attribute as new value");
	irc = ITK_CALL(AOM_save(obj_tag));
	return ITK_ok;
}
/*================================================================================================*/
int set_err_code ( const tag_t obj_tag, char *sAttr, char *value ) {
	//int 	count= 0,
	int	irc=ITK_ok;
	char 	*sAttrValue = (char*)NULL;
	
	itk_trace("----- O6Stock ----- set_err_code  ----- Attribute: %s Value: %s", sAttr, value);
	irc = ITK_CALL(AOM_ask_value_string(obj_tag,sAttr, &sAttrValue));
	
	if (irc != ITK_ok) {
		itk_trace("set_err_code ----- error");
		irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
		MEM_free(sAttrValue);
		return irc;	
	}
	irc = ITK_CALL(AOM_save(obj_tag));
	if (irc != ITK_ok) {
		itk_trace("set_err_code ----- error");
		irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
		MEM_free(sAttrValue);
		return irc;		
	}
	if (strcmp(sAttrValue, "000000") == 0){
		irc = ITK_CALL(AOM_set_value_string(obj_tag,sAttr, value));
		itk_trace("set_err_code  ----- set_err_code as new value");
	}
	else {
		itk_trace("set_err_code  ----- set_err_code as already a value");
	}
	MEM_free(sAttrValue);
	irc = ITK_CALL(AOM_save(obj_tag));
	return ITK_ok;
}

/*================================================================================================*/
int clear_arr_int ( const tag_t obj_tag, char *sAttr ) {
		int 	irc=ITK_ok;
		
		itk_trace("clear_arr_attribute  ----- Object must be locked for Write");
		itk_trace("clear_arr_attribute  ----- Try to clear Array Int: %s", sAttr);
		irc = ITK_CALL(AOM_set_value_ints (obj_tag, sAttr, 0, (int*)NULL));
		if (irc != ITK_ok) {
			itk_trace("clear_arr_attribute ----- error");
			irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
			return irc;	
		}
		irc = ITK_CALL(AOM_save(obj_tag));
		if (irc != ITK_ok) {
			itk_trace("clear_arr_attribute ----- error");
			irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
			return irc;		
		}
		itk_trace("clear_arr_attribute  ----- Array Attribute is empty");
	return ITK_ok;
}
/*================================================================================================*/
int clear_arr_dbl ( const tag_t obj_tag, char *sAttr ) {
		int 	irc=ITK_ok;
		
		itk_trace("clear_arr_attribute  ----- Object must be locked for Write");
		itk_trace("clear_arr_attribute  ----- Try to clear Array Double: %s", sAttr);
		irc = ITK_CALL(AOM_set_value_doubles (obj_tag, sAttr, 0, (double*)NULL));
		if (irc != ITK_ok) {
			itk_trace("clear_arr_attribute ----- error");
			irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
			return irc;	
		}
		irc = ITK_CALL(AOM_save(obj_tag));
		if (irc != ITK_ok) {
			itk_trace("clear_arr_attribute ----- error");
			irc = ITK_CALL(AOM_refresh(obj_tag, FALSE));
			return irc;		
		}
		itk_trace("clear_arr_attribute  ----- Array Attribute is empty");
	return ITK_ok;
}
/*================================================================================================*/
//
int itk_report( char *file, int line, char *call, int irc) {
	if (irc != ITK_ok) {
		int 	i,
				nb_err;

		const int *severities, *ifails;

		const char	**texts;

		print_log( "ITK Error: File %s line %d - %s Return %d", file, line, call, irc);

		nb_err = 0;
		EMH_ask_errors(&nb_err, &severities, &ifails, &texts);
		if (nb_err > 0) {
			for (i=0; i<nb_err; i++) print_log("\tERROR#%d: %s", ifails[i], texts[i]);	// !pas de free a faire 
			EMH_clear_errors();
		}
		else {
			char	*pt;
			EMH_get_error_string (NULLTAG, irc, &pt);
			if (pt != (char*)NULL) {
				print_log("\tERROR#%d: %s", irc, pt);
				MEM_free(pt);
			}
		}

	}

	return irc;
}

//
int is_class ( tag_t obj, char *pcClass, logical or_subclass, logical *verdict) {
	int 	irc = ITK_ok;
	tag_t	class_id,
			obj_class_id;
	char	*pt_class,
			obj_class[256];

	ITK_START("is_ValidClass");

	*verdict = FALSE;

	if (obj == NULL_TAG) return ITK_ok;

	irc = ITK_CALL(POM_class_of_instance( obj, &obj_class_id ));
	if (irc != ITK_ok ) return irc;

	irc = ITK_CALL(POM_name_of_class( obj_class_id, &pt_class));
	if (irc != ITK_ok ) return irc;

	if (pt_class != (char*)NULL) {
		strcpy(obj_class, pt_class);
		MEM_free (pt_class);
	}
	else {
		print_log("Warning: object has null class");
		return irc;
	}

	//print_log("Info: source obj class=%s", obj_class);


	if (_stricmp(obj_class, pcClass) == 0)	*verdict = TRUE;

	if (((*verdict) == FALSE) && (or_subclass == TRUE)) {
		irc = ITK_CALL(POM_class_id_of_class(pcClass, &class_id));
		if (irc != ITK_ok ) return irc;

		if (class_id != NULL_TAG) {
			logical	answer;
			irc = ITK_CALL(POM_is_descendant(class_id, obj_class_id, &answer));
			if (irc != ITK_ok ) return irc;

			if (answer == TRUE) *verdict = TRUE;
		}		
	}
	
	return ITK_ok;
}

//
int has_privilege( tag_t obj, char *privilege, logical *verdict ) {
	int		n_rules,
			irc;
	char	**rules,
			**args;
	tag_t	acl,
			accessor;

	ITK_START("has_privilege");

	//READ,WRITE,DELETE,CHANGE,PROMOTE,DEMOTE,COPY,IMPORT,EXPORT,TRANSFER_IN,TRANSFER_OUT
	irc = ITK_CALL(AM_evaluate_privilege( obj, privilege, verdict, &n_rules, &rules, &args, &acl, &accessor));
	if (irc != ITK_ok )  return irc;

	if (n_rules > 0) {
		MEM_free(rules);
		MEM_free(args);
	}			

	return ITK_ok;
}



//
int has_property( tag_t obj, char *prop, logical *verdict ) {
	int		irc,
			i,
			num;
	char	**props;

	ITK_START("has_property");

	*verdict = FALSE;

	if (obj == NULL_TAG) return ITK_ok;

	irc = ITK_CALL(AOM_ask_prop_names( obj, &num, &props));
	if (irc != ITK_ok )  return irc;

	if (num > 0) {
		for (i=0; i<num; i++) {
			//itk_trace("   Prop: %s", props[i]);

			if (strcmp(props[i], prop) == 0) {
				*verdict = TRUE;
				break;
			}
		}

		MEM_free(props);
	}			

	return ITK_ok;
}


//
int has_status( tag_t obj, char *status, logical *verdict ) {
	int 	irc = ITK_ok,
			num,
			i;

	tag_t	*status_list;


	//
	num = 0;
	*verdict = FALSE;

	//
	irc = ITK_CALL(AOM_ask_value_tags( obj, "release_status_list", &num, &status_list ));
	if (irc != ITK_ok) return irc;

	for (i=0; i<num; i++) {
		char	str[256],
				*pt;

		*str = '\0';

		irc = ITK_CALL(AOM_ask_value_string(status_list[i], "name", &pt));
		if (irc != ITK_ok) continue;

		if (pt != (char*)NULL) {
			strcpy(str, pt);
			MEM_free(pt);
		}

		if (strcmp(str, status) == 0) {
			*verdict = TRUE;
			break;
		}
	}

	if (num > 0) MEM_free(status_list);

	return ITK_ok;
}


//
TC_argument_list_t* build_args(int num, ...) {
	int						i;
	va_list 				args;

	TC_argument_list_t		*arg_list;
	TC_argument_t			*arg;

	char					*str,
							*pt;

	ITK_START("build_args");

	arg_list = (TC_argument_list_t*)MEM_alloc(sizeof(TC_argument_list_t) );

	TC_init_argument_list( arg_list );

	if (num > 0) {
		arg = (TC_argument_t*)MEM_alloc(num * sizeof(TC_argument_t) );

		va_start(args, num);
		for (i=0; i<num; i++) {
			pt = va_arg(args, char*);
			str = (char*)MEM_alloc( (strlen(pt) + 1 )* sizeof(char) );
			strcpy(str, pt);

			arg[i].type = POM_string;
			arg[i].array_size = 1;
			arg[i].val_union.str_value = str;

		}
		va_end(args);
		arg_list->arguments = arg;
	}

	arg_list->number_of_arguments = num;

	return arg_list;
}

//
char *get_wf_argument(char *args, char *key, char *value, int maxi_size) {
	char	*pt = (char*)NULL,
			*ret =  (char*)NULL;
	
	ITK_START("get_wf_argument");

	if ((pt = strstr( args, key)) != (char*)NULL ) 	{
		if (maxi_size > 0) {
			strncpy(value, pt+strlen(key), maxi_size);
			value[maxi_size] = '\0';
		}

		ret = (pt+strlen(key));
	}

	return ret;
}

//
list_t *add_to_list(list_t **list, tag_t obj, logical force_unik) {
	//int					irc;
	list_t				*lst = NULL_list;
	list_t				*l = NULL_list;

	ITK_START("add_to_list");

	if (obj == NULL_TAG) return l;

	if ((*list) == NULL_list) {
		l = (list_t*)MEM_alloc(sizeof(list_t));
		l->next = NULL_list;
		l->obj = obj;
		*list = l;
	}
	else {
		if (force_unik == TRUE) {
			for (lst=*list; lst != NULL_list; lst=lst->next) {
				if (obj == lst->obj)  {
					return lst;
				}
			}
		}

		for (lst=*list; lst->next != NULL_list; lst=lst->next);	
	
		l = (list_t*)MEM_alloc(sizeof(list_t));
		l->next = NULL_list;
		l->obj = obj;
		lst->next = l;
	}

	return l;
}


//
void free_list(list_t *list) {
	ITK_START("free_list");

	if (list != NULL_list) {
		list_t *lst = NULL_list;
		list_t *l = NULL_list;

		for (lst=list; lst != NULL_list; ) {
			l=lst;
			lst = lst->next;
			if (l != NULL_list) MEM_free(l);
			l = NULL_list;
		}
	}
}

//
void list_to_array(list_t *list, int *nb, tag_t **array) {
	int		i=0;
	tag_t	*tab = (tag_t*)NULL;

	ITK_START("list_to_array");

	if (list != NULL_list) {
		int					count = 0;
		list_t	*lst = NULL_list;

		count = list_count(list);
		if (count > 0) {
			tab = (tag_t*)MEM_alloc(count * sizeof(tag_t));
			if (tab != (tag_t*)NULL) {
				for (lst=list, i=0; lst != NULL_list; lst=lst->next) tab[i++] = lst->obj;
			}
		}
	}
	*array = tab;
	*nb = i;
}

//
int list_count(list_t *list) {
	int count = 0;

	ITK_START("list_count");

	if (list != NULL_list) {
		list_t	*l = NULL_list;
		for (l=list; l != NULL_list; l=l->next) count++;
	}

	return count;
}

//
void string_to_fields(char *string, char *delim, int *count, char ***fields) {
	int		i,
			num;

	char	*pt,
			**tab;

	ITK_START("string_to_fields");

	*count = 0;

	if (string == (char*)NULL) return;

	//
	for (pt=string, num=0; pt != (char*)NULL; pt = strstr(pt, delim), num++) pt+=strlen(delim);

	tab = (char**)MEM_alloc(num * sizeof(char*));
	for (i=0; i<num; i++) tab[i] = (char*)NULL;	

	//
	*count = num;
	*fields = tab;

	for (pt=string, i=0; pt != (char*)NULL; i++, pt+=strlen(delim)) {
		char	*deb;
		size_t		nb;

		deb = pt,

		pt = strstr(deb, delim);
		if (pt != (char*)NULL)	nb = pt-deb;
		else					nb = strlen(deb);

		tab[i] = (char*)MEM_alloc((nb+1) * sizeof(char));
		strncpy(tab[i], deb, nb);
		tab[i][nb] = '\0';
		i++;
		
	}

	return;
}

//
char *get_next_field(char *string, char *delim, char *value, int max_lng) {
	size_t		nb;
	char	*pt;

	ITK_START("get_next_field");

	if (string == (char*)NULL) return string;

	pt = strstr(string, delim);
	if (pt != (char*)NULL)	nb = pt-string;
	else					nb = strlen(string);

	if (nb > max_lng) nb = max_lng;

	strncpy(value, string, nb);
	value[nb] = '\0';

	if (pt != (char*)NULL) pt += strlen(delim);

	return pt;
}

//
int parse_string_variables(char *string, tag_t itm, tag_t rev, char *value, int max_lng) {
	int irc = ITK_ok;

	char	str[1024+1],
			*pt,
			*build_value;

	time_t	atime=0;
	struct 	tm *nowtime;

	ITK_START("parse_string_variables");

	//
	_tzset();	
	time(&atime);
	nowtime = localtime( &atime );

	if (string == (char*)NULL)	return ITK_ok;
	if (max_lng <= 0)			return ITK_ok;

	build_value = (char*)MEM_alloc(2*max_lng);

	*str = *build_value = '\0';
	pt = string;

	do {
		int		lg;
		pt = get_next_field(pt, "$", str, 1024);

		if (strcmp(str, "NOW") == 0) {
			char	*dummy, 
					v[33];

			strcpy(str, "");

			sprintf(v, "%2d", nowtime->tm_mday);
			for (dummy=v; *dummy != '\0'; dummy++) {if (*dummy == ' ') *dummy = '0';}
			strcat(str, v);

			sprintf(v, "%2d", nowtime->tm_mon);
			for (dummy=v; *dummy != '\0'; dummy++) {if (*dummy == ' ') *dummy = '0';}
			strcat(str, v);

			sprintf(v, "%4d", nowtime->tm_year + 1900);
			strcat(str, v);

		}
		else if (strcmp(str, "DIS") == 0) {
			char	*dummy;

			ITK_CALL(WSOM_ask_object_id_string(rev, &dummy));
			if (dummy != (char*)NULL) {
				strcpy(str, dummy);
				MEM_free(dummy);
			}
		}
		else if ( (strstr(str, "ITM:") != (char*)NULL) || (strstr(str, "REV:") != (char*)NULL) ){
			tag_t	obj = NULL_TAG;
			logical	verdict;
			char	*dummy, 
					v[1024+1],
					key[133],
					prop[133];

			*v = '\0';
			dummy = strstr(str, ":");
			if (dummy != (char*)NULL) {
				*dummy = '\0';
				dummy++;
				strcpy(prop, dummy);
				strcpy(key, str);

				dummy = (char*)NULL;
				if (strcmp(key, "ITM") == 0)		obj = itm;
				else if (strcmp(key, "REV") == 0)	obj = rev;
				else								print_log("Ignore unknow key: %s:%s", key, prop);

				if (obj != NULL_TAG) {
					has_property(obj, prop, &verdict);

					if (verdict == TRUE) {
						dummy = (char*)NULL;
						irc = ITK_CALL(AOM_UIF_ask_value(obj, prop, &dummy));
						if ((irc == ITK_ok) && (dummy != (char*)NULL)) {
							strncpy(v, dummy, 1024);
							v[1024] = '\0';
							MEM_free(dummy);
						}
					}
					else {
						print_log("Ignore unknow prop: %s:%s", key, prop);
					}
				}
			}

			strcpy(str, v);
		}

		lg = (strlen(build_value) + strlen(str));
		if (lg <= max_lng) {
			strcat(build_value, str);
		}
		else {
			int cut;
			print_log("Too long build value");
			cut = (max_lng - strlen(build_value));

			if (cut > 0)	str[cut] = '\0';
			strcat(build_value, str);

			break;
		}
	}
	while (pt != (char*)NULL);

	strcpy(value, build_value);

	MEM_free(build_value);

	return ITK_ok;
}

// End-Of-File
