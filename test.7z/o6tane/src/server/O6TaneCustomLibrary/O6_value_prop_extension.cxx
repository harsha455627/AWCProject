//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6_value_prop_extension
 *
 */
#include <stdarg.h>
#include <string>
#include <iostream>
#include <cstdlib>

#include <O6TaneCustomLibrary/O6_value_prop_extension.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <tccore/tctype.h>
#include <ug_va_copy.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>


#define OBJECT_TYPE "object_type"
#define MP_GEN_REV "O6_GenRMRevision"
#define SAP_PRICE_ATTR "o6_prix_sap"
#define SAP_PRICE_INI_ATTR "o6_prix_ini"
#define SAP_PRICE_SUP_ATTR "o6_prix_fournis"
#define MEAN_DENSITY "o6_densite"
#define GEN_TO_SUP "O6_GenToSupplRM"
#define SUPL_REV "O6_SupRMRevision"
#define FLE_BATCH_REV "O6_FleBatchRevision"
#define FLE_REV "O6_FleRevision"
#define TOP_LINE_ATTR "top_line"
#define BOM_WINDOW "bl_window"

#define bomAttr_fnd0bl_line_object_type "fnd0bl_line_object_type"
#define bomAttr_bl_occ_o6_percent_theoric "bl_occ_o6_percent_theoric"
#define bomAttr_bl_occ_o6_vol_percent_theoric "bl_occ_o6_vol_percent_theoric"
#define bomAttr_lineO6_SAP_Cost "o6_sap_cost"

static int item_revtag_attribute;
static int bl_object_type_attribute;
static int bl_occ_o6_percent_theoric_attribute;
static int bl_occ_o6_vol_percent_theoric_attribute;
static int quantiy_attribute;
static int item_uom_attribute;
static int uom_attribute;
static int bl_o6_sap_cost_attribute;

#define BOM_LINE "BOMLine"

/**
 * Function    :  initialise_attribute
 * Description :  Initialize BOM attributes.
 * Input       :
 */

static int initialise_attribute (char *name,  int *attribute)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (name, attribute));

    return retcode;
  }

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 * Input       :
 */
static int initialise (void)
  {
    int retcode = ITK_ok;


    ITK(BOM_line_look_up_attribute (bomAttr_lineItemRevTag, &item_revtag_attribute));
    ITK(initialise_attribute (bomAttr_occQty, &quantiy_attribute));
    ITK(initialise_attribute(bomAttr_itemUom, &item_uom_attribute));
    ITK(initialise_attribute (bomAttr_occUoM, &uom_attribute));
    ITK(initialise_attribute (bomAttr_fnd0bl_line_object_type, &bl_object_type_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_percent_theoric, &bl_occ_o6_percent_theoric_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_vol_percent_theoric, &bl_occ_o6_vol_percent_theoric_attribute ));
    ITK(initialise_attribute (bomAttr_lineO6_SAP_Cost, &bl_o6_sap_cost_attribute ));

    return retcode;
  }

/**
 * Function		: getConvertedCostValue
 * Description	: Get cost value based on unit of measure selected
 * Input		:
 * 		bomline 		 - tag of Bomline used for evaluation
 * 		unitTopLinestr   - char pointer denoting Topline UOM value
 * 		sap_price_var    - double sap price value
 * 		finalcost        - double final cost based on UOM
 * Output		:
 * 		none
 */
int getConvertedCostValue(tag_t bomline, char* unitTopLinestr, double sap_price_var, double* finalcost){
	int retcode = ITK_ok;
	char* bl_uom_str = NULL;

	ITK(BOM_line_ask_attribute_string(bomline, item_uom_attribute, &bl_uom_str));
	if (retcode == ITK_ok && bl_uom_str != NULL) {

		if (tc_strlen(bl_uom_str) > 0) {
			if (tc_strcmp(unitTopLinestr, bl_uom_str) == 0) {
				if((tc_strcmp(unitTopLinestr, KG) == 0 && tc_strcmp(bl_uom_str, KG) == 0))
				{
				    *finalcost = sap_price_var;
				}
				else if ( (tc_strcmp(unitTopLinestr, LITER) == 0 && tc_strcmp(bl_uom_str, LITER) == 0) )
				{
				    *finalcost = sap_price_var;
				}
				else
				{
				    *finalcost = sap_price_var * 1000;
				}
			}else if (tc_strcmp(unitTopLinestr, KG) == 0
					&& tc_strcmp(bl_uom_str, GM) == 0) {
				*finalcost = sap_price_var * 1000;
			}else if (tc_strcmp(unitTopLinestr, KG) == 0
					&& tc_strcmp(bl_uom_str, LITER) == 0) {
				*finalcost = sap_price_var;
			}
			else if (tc_strcmp(unitTopLinestr, GM) == 0
					&& tc_strcmp(bl_uom_str, KG) == 0) {
				*finalcost = sap_price_var;
			}else if (tc_strcmp(unitTopLinestr, GM) == 0
					&& tc_strcmp(bl_uom_str, LITER) == 0) {
				*finalcost = sap_price_var;
			}else if (tc_strcmp(unitTopLinestr, LITER) == 0
					&& tc_strcmp(bl_uom_str, KG) == 0) {
				*finalcost = sap_price_var;
			}else if (tc_strcmp(unitTopLinestr, LITER) == 0
					&& tc_strcmp(bl_uom_str, GM) == 0) {
				*finalcost = sap_price_var * 1000;
			}
		}

		MEM_free(bl_uom_str);
		bl_uom_str = NULL;
	}

	return retcode;
}

/**
 * Function    :  O6_value_prop_extension
 * Description :  Used when getting values for custom runtime property o6_value_prop.
 * Input       :
 *      msg 		 - Input msg for extension
 *      args         - Input args for extension
 * Output	   :
 * 		none
 */
int O6_value_prop_extension(METHOD_message_t *msg, va_list args)
{
	int retcode = ITK_ok;
	double* attrvalue = NULL;
	tag_t blTag = NULLTAG;
	char* tempValStr = NULL;

	va_list largs;
	va_copy( largs, args);
	va_arg( largs, tag_t ); /*Property Object tag_t  not used*/
	attrvalue = va_arg( largs, double* );
	va_end( largs );

	if (attrvalue != NULL) {

		blTag = msg->object_tag;
		if (blTag != NULLTAG ) {

			ITK(initialise());

			tag_t windowTag = NULLTAG;
			ITK(AOM_ask_value_tag(blTag,BOM_WINDOW,&windowTag));
			if (retcode == ITK_ok && windowTag != NULLTAG ) {

				tag_t rootLine = NULLTAG;
				ITK(AOM_ask_value_tag(windowTag,TOP_LINE_ATTR,&rootLine));
				if (retcode == ITK_ok && rootLine != NULLTAG ) {

					char* object_type = NULL;
					ITK(BOM_line_ask_attribute_string(rootLine, bl_object_type_attribute, &object_type));
					if (retcode == ITK_ok && object_type != NULL) {

						if (tc_strcmp(object_type, FLE_BATCH_REV) == 0 || tc_strcmp(object_type, FLE_REV) == 0) {

							char* unitTopLinestr = NULL;
							ITK(BOM_line_ask_attribute_string(rootLine, item_uom_attribute, &unitTopLinestr));
							if (retcode == ITK_ok && unitTopLinestr != NULL) {

                              /*if (tc_strlen(unitTopLinestr) > 0
										&& tc_strcmp(unitTopLinestr, EACH) != 0
										&& tc_strcmp(unitTopLinestr, LITER)
												!= 0) {*/
								if (tc_strlen(unitTopLinestr) > 0
										&& tc_strcmp(unitTopLinestr, EACH) != 0) {
									tag_t rootRev = NULLTAG;
									ITK(BOM_line_ask_attribute_tag (rootLine, item_revtag_attribute, &rootRev));
									if (retcode == ITK_ok && rootRev != NULLTAG ) {

										tag_t itemrev = NULLTAG;
										ITK(BOM_line_ask_attribute_tag (blTag, item_revtag_attribute, &itemrev));
										if (retcode == ITK_ok && itemrev != NULLTAG && itemrev != rootRev) {

											char* objtypestr = NULL;
											ITK(AOM_ask_value_string(itemrev,OBJECT_TYPE, &objtypestr));
											if (retcode == ITK_ok && objtypestr != NULL) {

												double sap_price_var = 0;
												if (tc_strcmp(objtypestr, MP_GEN_REV) == 0)
												{
													ITK ( BOM_line_ask_attribute_double ( blTag, bl_o6_sap_cost_attribute, &sap_price_var) );

													if ( retcode == ITK_ok && sap_price_var == 0 )
													{
														ITK(AOM_ask_value_double(itemrev, SAP_PRICE_INI_ATTR, &sap_price_var));
													}
												} else if (tc_strcmp(objtypestr,SUPL_REV) == 0) {

													ITK(AOM_ask_value_double(itemrev, SAP_PRICE_SUP_ATTR, &sap_price_var));

												}

												if (retcode == ITK_ok && sap_price_var > 0) {

													if (tc_strcmp(object_type, FLE_REV) == 0 || tc_strcmp(object_type,FLE_BATCH_REV) == 0) {
														tempValStr = NULL;
														ITK(BOM_line_ask_attribute_string(blTag, bl_occ_o6_percent_theoric_attribute, &tempValStr));
														if (retcode == ITK_ok && tempValStr != NULL) {

															if (tc_strlen(tempValStr) > 0) {

																double blqty = atof(tempValStr);
																if (blqty > 0) {
																	double finalcost = 0;
																	ITK(getConvertedCostValue(blTag, unitTopLinestr, sap_price_var, &finalcost));
																	if (retcode == ITK_ok && finalcost > 0)
																	{
																		char* pcUOMValue = NULL;

																		ITK ( BOM_line_ask_attribute_string ( blTag, item_uom_attribute, &pcUOMValue ) );

																		/*Valeur calculation based on topline UOM and component UOM*/
																		if ( ( tc_strcmp ( unitTopLinestr, KG ) == 0 || tc_strcmp ( unitTopLinestr, GM ) == 0 ) && tc_strcmp ( pcUOMValue, LITER ) == 0 )
																		{
																			double dDensite   = 0.0;

																			tag_t tItemRevTag = NULLTAG;

																			ITK ( BOM_line_ask_attribute_tag ( blTag, item_revtag_attribute, &tItemRevTag ) );
																			ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensite ) );

																			double valueVar = ( blqty * finalcost ) / ( 100 * dDensite ) ;
																			if ( valueVar > 0 )
																			{
																				*attrvalue = valueVar;
																			}
																		}
																		else if ( ( tc_strcmp ( unitTopLinestr, KG ) == 0 || tc_strcmp ( unitTopLinestr, GM ) == 0 ) && ( tc_strcmp ( pcUOMValue, KG ) == 0 || tc_strcmp ( pcUOMValue, GM ) == 0 ) )
																		{
																			double valueVar = ( blqty / 100 ) * finalcost;
																			if ( valueVar > 0 )
																			{
																				*attrvalue = valueVar;
																			}
																		}
																		else if ( tc_strcmp ( unitTopLinestr, LITER ) == 0 && ( tc_strcmp ( pcUOMValue, KG ) == 0 || tc_strcmp ( pcUOMValue, GM ) == 0 ) )
																		{
																			char* pcVolPercent = NULL;
																			ITK(BOM_line_ask_attribute_string(blTag, bl_occ_o6_vol_percent_theoric_attribute, &pcVolPercent));

																			double dDensite   = 0.0;

																			tag_t tItemRevTag = NULLTAG;

																			ITK ( BOM_line_ask_attribute_tag ( blTag, item_revtag_attribute, &tItemRevTag ) );
																			ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensite ) );

																			double valueVar = dDensite * atof ( pcVolPercent ) * finalcost / 100;

																			if ( valueVar > 0 )
																			{
																				*attrvalue = valueVar;
																			}

																			if ( pcVolPercent != NULL )
																			{
																				MEM_free ( pcVolPercent );
																				pcVolPercent = NULL;
																			}
																		}
																		else if ( tc_strcmp ( unitTopLinestr, LITER ) == 0 && tc_strcmp ( pcUOMValue, LITER ) == 0  )
																		{
																			char* pcVolPercent = NULL;

																			ITK(BOM_line_ask_attribute_string(blTag, bl_occ_o6_vol_percent_theoric_attribute, &pcVolPercent));

																			double valueVar = atof ( pcVolPercent ) * finalcost / 100;

																			if ( valueVar > 0 )
																			{
																				*attrvalue = valueVar;
																			}

																			if ( pcVolPercent != NULL )
																			{
																				MEM_free ( pcVolPercent );
																				pcVolPercent = NULL;
																			}
																		}
																		if ( pcUOMValue != NULL )
																		{
																			MEM_free ( pcUOMValue );
																			pcUOMValue = NULL;
																		}
																	}
																}
															}
															MEM_free(tempValStr);
															tempValStr = NULL;
														}
													}
												}

												MEM_free(objtypestr);
												objtypestr = NULL;
											}
										}
									}
								}
								MEM_free(unitTopLinestr);
								unitTopLinestr = NULL;
							}
						}

						MEM_free(object_type);
						object_type = NULL;
					}
				}
			}
		}
	}

	return retcode;

}
