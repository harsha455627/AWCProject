//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#ifndef TEAMCENTER_CLIENTX_SOAMODELEVENTLISTENER_HXX
#define TEAMCENTER_CLIENTX_SOAMODELEVENTLISTENER_HXX




#include <string>
#include <vector>

#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ModelEventListener.hxx>



namespace Teamcenter
{
    namespace ClientX
    {
        class AppXModelEventListener;



/**
 * Implementation of the ChangeListener. Print out all objects that have been updated.
 *
 */
class  AppXModelEventListener: public Teamcenter::Soa::Client::ModelEventListener
{
public:
    AppXModelEventListener();
    ~AppXModelEventListener();

    virtual void localObjectChange( const std::vector<Teamcenter::Soa::Common::AutoPtr<Teamcenter::Soa::Client::ModelObject> >& objects);
    virtual void localObjectDelete( const std::vector< std::string>&  uids);

};


}} //end namespace
#endif

