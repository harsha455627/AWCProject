/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

package com.o6.services.loose.customservicelibrary;

import com.teamcenter.soa.SoaConstants;
import com.teamcenter.soa.client.Connection;

/**
 * Custom Service
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">O6SoaCustomServiceLibraryLoose.jar
 * </li>
 * <li type="disc">O6SoaCustomServiceLibraryTypes.jar (runtime dependency)
 * </li>
 * </ul>
 */

public abstract class O6TaneCustomServiceService
  implements     com.o6.services.loose.customservicelibrary._2017_06.O6TaneCustomService,
    com.o6.services.loose.customservicelibrary._2017_11.O6TaneCustomService,
    com.o6.services.loose.customservicelibrary._2017_12.O6TaneCustomService
{
    /**
     * 
     * @param connection 
     * @return A instance of the service stub for the given Connection
     */
    public static O6TaneCustomServiceService getService( Connection connection )
    {
        if(connection.getBinding().equalsIgnoreCase( SoaConstants.REST ))
        {
            return new O6TaneCustomServiceRestBindingStub( connection );
        }

        throw new IllegalArgumentException("The "+connection.getBinding()+" binding is not supported.");
    }


}
