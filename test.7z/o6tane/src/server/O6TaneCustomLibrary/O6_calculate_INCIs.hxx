//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension O6_calculate_INCIs
 *
 */
 
#ifndef O6_CALCULATE_INCIS_HXX
#define O6_CALCULATE_INCIS_HXX
#include <tccore/method.h>
#include <textsrv/textserver.h>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_exports.h>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <iostream>
#include <cstring>
#define SEEDS_SAVEAS_TARGET_MAPPINGS "SEEDS_SaveAs_target_mappings"
#define SEEDS_SAVEAS_DEEP_COPY_RULES "SEEDS_SaveAs_deep_copy_rules"
#define SEEDS_PERCENT_VALUE_ATTRIBUTE "SEEDS_INCI_percent_attribute_name"
struct SkippedINCIInfo
{
	char* pcINCIId               = NULL;
	char* pcINCName              = NULL;
	char* pcAllergenValue        = NULL;
	char* pcApplType             = NULL;
	char* pcImpurete             = NULL;

	double dTotalPercentage      = 0.0;

	struct SkippedINCIInfo *next = NULL;
};
#define ITK( argument )						                                \
{									                                        \
	if (retcode == ITK_ok)													\
	{																		\
		retcode = argument;                                                 \
		if ( retcode != ITK_ok )											\
		{																	\
			char* s;                                                        \
			TC_write_syslog( " "#argument "\n" );                           \
			TC_write_syslog( "  returns [%d]\n", retcode );                 \
			EMH_ask_error_text (retcode, &s);                               \
			EMH_store_error(EMH_severity_error,retcode);                    \
			TC_write_syslog( "  Teamcenter Error: [%s]\n", s);              \
			TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
			if (s != 0) MEM_free (s);                                       \
		}                                                                   \
	}																		\
}
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern O6TANECUSTOMLIBRARY_API int O6_calculate_INCIs(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <O6TaneCustomLibrary/libo6tanecustomlibrary_undef.h>
                
#endif  // O6_CALCULATE_INCIS_HXX
