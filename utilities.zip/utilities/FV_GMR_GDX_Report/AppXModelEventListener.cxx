//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#include <typeinfo> 
#include <teamcenter/clientx/AppXModelEventListener.hxx>

#include <iostream>

#include <teamcenter/soa/client/NotLoadedException.hxx>
#include <teamcenter/soa/client/model/WorkspaceObject.hxx>

using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Soa::Client;
using namespace Teamcenter::Soa::Client::Model;
using namespace Teamcenter::Soa::Common;


AppXModelEventListener::AppXModelEventListener():
    ModelEventListener()
{
}

AppXModelEventListener::~AppXModelEventListener()
{
}


void AppXModelEventListener::localObjectChange( const vector<AutoPtr<Teamcenter::Soa::Client::ModelObject> >& objects)
{
    if (objects.size() == 0) return;

    cout << "" << endl;
    cout <<"Modified Objects handled in Teamcenter::ClientX::AppXModelEventListener.localObjectChange"<< endl;
    cout <<"The following objects have been updated in the client data model:"<< endl;

    for (size_t i = 0; i < objects.size(); i++)
    {
        AutoPtr<ModelObject> object = objects [i];
        std::string uid = object->getUid();
        std::string type = object->getType()->getName();
        std::string name = "";

        try
        {
            AutoPtr<Teamcenter::Soa::Client::Model::WorkspaceObject> wo = object.dyn_cast<Teamcenter::Soa::Client::Model::WorkspaceObject>();
            if(!wo.isNull())
            {
                try
                {
                    name = wo->get_object_string();
                }
                catch (NotLoadedException& /*e*/) {} // just ignore
            }
        }
        catch (std::bad_cast& ) { }

        cout << "    " << uid << " " << type << " " << name << endl;
    }
}


void AppXModelEventListener::localObjectDelete( const std::vector< std::string >&  uids)
{
    if (uids.size() == 0)
        return;

    cout << "" << endl;
    cout << "Deleted Objects handled in com.teamcenter.clientx.AppXModelEventListener.localObjectDelete"<< endl;
    cout << "The following objects have been deleted from the server and removed from the client data model:"<< endl;

    for (size_t i = 0; i < uids.size(); i++)
    {
        cout << "    " + uids[i] << endl;
    }

}
