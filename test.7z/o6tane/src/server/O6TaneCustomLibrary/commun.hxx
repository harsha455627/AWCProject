//
#ifndef COMMUN_H_INCLUDED
#define COMMUN_H_INCLUDED

#include <io.h>
#include <tc/tc_arguments.h>

// Active le mode trace - a commenter sinon !
#define TRACE

// No de version a sur-d�finir dans le prog principal
#define NOT_DEFINED_APPL			"##NotDefine##"
#define NOT_DEFINED_VER				"0.0"

//
#define O6Stock_IGNORE_CUSTO_ENV		"O6Stock_IGNORE_CUSTO"


//
#ifdef TRACE
#define ITK_START(X) 	(itk_start( __FILE__, __LINE__, (X)))
#else
#define ITK_START(X) 	
#endif

#define ITK_CALL(X) 	(itk_report( __FILE__, __LINE__, #X, (X)))


//
typedef struct list_s {
	tag_t				obj;
	struct 	list_s		*next;
}list_t, *list_p_t;
#define NULL_list (list_p_t)NULL

//
extern list_t *add_to_list(list_t **list, tag_t obj, logical force_unik);
extern void free_list(list_t *list);
extern void list_to_array(list_t *list, int *nb, tag_t **array);
extern int list_count(list_t *list);

//
extern void init_log(char *appname, char *version);
extern void print_log(char *fmt, ...);
extern void itk_trace(char *fmt, ...);

//
extern void itk_start(char *file, int line, char *fct);
extern void itk_start(char *file, int line, char *fct);
extern void itk_print_object(char *title, tag_t obj);
extern int itk_report( char *file, int line, char *call, int irc);

//
extern int is_class( tag_t obj, char *pcClass, logical or_subclass, logical *verdict);
extern int has_privilege( tag_t obj, char *privilege, logical *verdict );
extern int has_property( tag_t obj, char *prop, logical *verdict );
extern int has_status( tag_t obj, char *status, logical *verdict );

//
extern TC_argument_list_t* build_args(int num, ...);
extern char *get_wf_argument(char *args, char *key, char *value, int maxi_size);
extern int parse_string_variables(char *string, tag_t itm, tag_t rev, char *value, int max_lng);

//
extern void string_to_fields(char *string, char *delim, int *count, char ***fields);
extern char* get_next_field(char *string, char *delim, char *value, int max_lng);


#endif /* COMMUN_H_INCLUDED */

// End-Of-File
