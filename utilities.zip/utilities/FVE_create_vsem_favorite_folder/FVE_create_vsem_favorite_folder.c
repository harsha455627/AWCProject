/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: FVE_create_vsem_favorite_folder.c
    Module  : main

        Used to create VSEM Favorites Folder
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>
===============================================================================
Date               Name                    Description of Change
12-Dec-2014        Shreya Suman             Initial version
===============================================================================*/
#include <time.h>
#include "FVE_create_vsem_favorite_folder.h"

/* Global Attributes */
char *          login_group                     = NULL;
char *          login_user                      = NULL;
char *          login_password                  = NULL;
FILE *logfileptr = NULL;

/*******************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *   This utility will read the input file ,create VSEM Favorite Folder if not present . If present will do nothing
 *
 *
 * ARGUMENTS
 *   u              In     User name
 *   p              In     Password
 *   g              In     Group
 *   i              In     Input definition name
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description
 * ----------     -------------------    -----------------------------
 *  Dec 2014       Shreya Suman           Created
 *
 ******************************************************************************/

extern int ITK_user_main( int argc, char **  argv )
{
    int             ifail                           = ITK_ok;
	int             line_count                      = 0;
    char *          def_file                        = NULL;
    char *          folder_desc	                    = NULL;
    char *          folder_name		                = NULL;
    char            fileline[257]                   = "";
	char            fileline_tmp[257]               = "";
    FILE *          inputfileptr                    = NULL;
	char            logfilename[255 + 1]            = "";
	char *          time_stamp                      = NULL;
    char *          ptr								= NULL;
	logical         is_folder_name_null				= FALSE;

    /*Append the log file name with the date and time stamp*/
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"CREATE_VSEM_FAVORITE_FOLDER_%s.log",time_stamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }

    printf("\nLog information will be written into %s\n\n",logfilename);
        
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
        fprintf(logfileptr,"argc: %d\n", argc);
        FVE_FREE(time_stamp)
    }
    

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

    login_user     = ITK_ask_cli_argument("-u=");
    login_password = ITK_ask_cli_argument("-p=");
    login_group    = ITK_ask_cli_argument("-g=");
    def_file       = ITK_ask_cli_argument("-i=");

    ITK_initialize_text_services (0);
    CLEANUP(ITK_init_module (login_user, login_password, login_group))
    if(ifail != ITK_ok)
    {
        printf("Login with userid: %s, group:%s is unsuccessful\n", login_user, login_group);
        fprintf(logfileptr,"ERROR: Login with uid: %s, group:%s is unsuccessful\n", login_user, login_group);    
        fclose( logfileptr );		
        print_usage();
        exit(0);
    }
    else{
        printf("Login with userid: %s, group:%s is successful\n", login_user, login_group);
	    fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n", login_user, login_group);
	}

  fprintf(logfileptr,"-------------------------------------------------------------------\n\n");

    /*Read input file */
    inputfileptr = fopen( def_file, "r");
    if (!inputfileptr)
    {
       printf("Unable to read definition file , utility terminating.\n\n");
	   fprintf(logfileptr,"Unable to read definition file , utility terminating.\n\n");
       goto CLEANUP;
    }

    /* Process input file */
    while (fgets(fileline, 256, inputfileptr) != NULL) 
    {
      folder_name   = NULL;
	  line_count++ ;

	  fprintf(logfileptr,"Processing for Line Number =%d\n", line_count);
	  fflush(logfileptr);

	  
	  if(fileline && tc_strlen(fileline)> 0){

		  tc_strcpy( fileline_tmp, fileline);

		  ptr = tc_strtok(fileline_tmp, ",");

		  FVE_get_value(ptr,&folder_name,&is_folder_name_null);
		  if(is_folder_name_null == FALSE){
			fprintf(logfileptr,"Folder Name = %s\n",folder_name);
			fflush(logfileptr);

		}else
		  {
			fprintf(logfileptr,"Folder Name is NULL\n");
			fflush(logfileptr);
		}

		if(folder_name)
		{
			folder_desc = (char *) tc_strtok(NULL,",");
			fprintf(logfileptr,"Folder Desc = %s\n",folder_desc);
			fflush(logfileptr);
		}
	  }

      if (folder_desc)
	  {
		  /* Create VSEM Folder */        
		ifail = fve_create_vsem_favorite_folder(folder_name,folder_desc);

      }
	  else
	  {
		  goto CLEANUP;
	  }
	  fprintf(logfileptr,"After calling fve_create_vsem_favorite_folder for Line Number =%d\n", line_count);
	  fprintf(logfileptr,"=======================================================================\n\n");
	  fflush(logfileptr);

    }//End of while loop
    fclose(inputfileptr);
    ITK_exit_module( true );
    printf("Utility completed successfully.\n\n");
    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
    FVE_FREE(time_stamp); 

	if (logfileptr ) fclose( logfileptr);

    CLEANUP:

    return ifail;
}

/* This function checks the tokenised value is null or not */
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}

/*******************************************************************************
 * NAME: print_usage
 *
 * DESCRIPTION
 *  prints command usage
 *
 * ARGUMENTS
 *   
 *
 * RETURNS
 *   
 *
 * NOTES
 ******************************************************************************/
static void print_usage(void)
{
        printf("\n********************************************************\n");
        printf("Usage: fve_create_vsem_favorite_folder <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<login user id>\n");
        printf(" -p=<login password>\n");
        printf(" -g=<login group>\n");
        printf(" -i=definition filename\n");
        printf("\n");
        printf("***********************************************************\n\n");        
}


/*******************************************************************************
 * NAME: fve_create_vsem_favorite_folder
 *
 * DESCRIPTION
 *  Function to create VSEM Favorite Folder
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *   template_name          In         Name of the folder
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/

int fve_create_vsem_favorite_folder(char * folder_name,char * folder_desc)
{
	int		ifail						= ITK_ok;
	int		num_found					= 0;
	tag_t	userTag						= NULLTAG;
	tag_t	homeFolderTag				= NULLTAG;
	tag_t	folderType					= NULLTAG;
	tag_t	createInputTag				= NULLTAG;
	tag_t	strTag						= NULLTAG;
	tag_t*	objTags						= NULL;
	char **	att_name					= NULL;
    char **	attr_values					= NULL;
	char*	userName					= NULL;
	const char *class_name				= "FV9VSEMFolder";
	const char *ip_classification		= "Proprietary";


	fprintf(logfileptr,"Inside fve_create_vsem_favorite_folder\n");
	fflush(logfileptr);

	attr_values    = (char **) MEM_alloc(sizeof(char*)*2);
    attr_values[0] = (char *) MEM_alloc((sizeof(char)*strlen(folder_name))+1);
    tc_strcpy(attr_values[0],folder_name);


    att_name       = (char **) MEM_alloc(sizeof(char*)*2);
    att_name[0]    = (char *) MEM_alloc((sizeof(char)*strlen(folder_name))+1);
    tc_strcpy(att_name[0],"object_name");

	attr_values[0] = folder_name;
    /* search for Folder */
    FV_search_objects_by_attrs(class_name,1,att_name,attr_values,&num_found,&objTags);

	printf(" Total Folders found %d\n",num_found);

	if(num_found < 1)
	{
		CLEANUP(FL_init_module ())		 
		CLEANUP(TCTYPE_ask_type(class_name, &folderType))
		// get create input tag
		if(folderType)
		{
			CLEANUP(TCTYPE_construct_create_input(folderType, &createInputTag))
		}
		// set folder attribute
		if(createInputTag)
		{
			CLEANUP(TCTYPE_set_create_display_value(createInputTag, "object_name", 1, (const char**)&folder_name))
			CLEANUP(TCTYPE_set_create_display_value(createInputTag, "object_desc", 1, (const char**)&folder_desc))
			CLEANUP(TCTYPE_set_create_display_value(createInputTag, "ip_classification", 1, (const char**)&ip_classification))
		}
		// Creating Folder Object
		CLEANUP(TCTYPE_create_object(createInputTag, &strTag))

		 if(strTag)
		 {
			CLEANUP( AOM_save(strTag))
			CLEANUP( AOM_refresh(strTag, false) )
			CLEANUP( POM_get_user(&userName, &userTag))
			CLEANUP( SA_ask_user_home_folder(userTag, &homeFolderTag))
			CLEANUP( FL_insert(homeFolderTag,strTag,999))
			CLEANUP( AOM_save(homeFolderTag))
		 }
		fprintf(logfileptr,"Folder %s Creation Complete\n",folder_name);
		fflush(logfileptr);
	}
	else
	{
		printf("\nFolder already Exists, exiting Utility\n");
		fprintf(logfileptr,"Folder %s already Exists. Skipping Creation of Favorite Folder\n",folder_name);
		fflush(logfileptr);
		goto CLEANUP;
	}


CLEANUP:
	CLEANUP(FL_exit_module ())
	FVE_FREE(userName);
	return ifail;
}