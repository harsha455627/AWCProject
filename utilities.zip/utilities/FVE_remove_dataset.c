

#include <tcinit/tcinit.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <tc/emh.h>
//#include <pie/sample_inh.h>
#include <pie/sample_err.h>
#include <tccore/grm.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tc/folder.h>

#define  my_name  "FVE_remove_dataset"

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            dump_itk_errors ( stat, my_name, __LINE__, __FILE__ );         \
        }                                                                  \
    }                                                                      \
}

/*******************************************************************************
 * NAME: dump_itk_errors
 *
 * DESCRIPTION
 *  Function to dump the ITK errors. This function has been inheritted from
 *  Teamcenter sample code.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/
static void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int   *severities=NULL;
    const int   *ifails=NULL;
    const char **texts=NULL;
    char        *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           fprintf( stderr, "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            fprintf( stderr, "%s: Error %d: %s\n", prog_name, stat, errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        fprintf( stderr, "%s: Error %d: %s\n", prog_name, stat, errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    fprintf( stderr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
}

void dousage()
{
   printf("\nUSAGE: %s -u=user -p=password -g=group -f=inputfile \n",my_name);
   return;
}

/*******************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *   This utility will read the input file ,search for all the datasets in the file and delete them.
 *
 * Usage:
 *   FVE_remove_dataset -u=user -p=password -g=group -f=inputfile
 *
 * ARGUMENTS
 *   user               In     User name
 *   passward           In     Password
 *   group              In     Group
 *   filename           Out    Input file name
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description
 * ----------     -------------------    -----------------------------
 *  Mar 2010      Tarun Saha             Created
 *
 ******************************************************************************/

int ITK_user_main (int argc, char *argv[])
{
   int          stat             = ITK_ok;
	int			 nFound           = 0;
   int          i                = 0;
   int          j                = 0;
   int          iRelations       = 0;
	char         line[128];
	char			 *datasetname     = NULL;
   char         *sObjectName     = NULL;
   char         *usr             = NULL;
   char         *upw             = NULL;
   char         *ugp             = NULL;
	char			 *inputfile       = NULL;
	tag_t			 *dataset_tags    = NULL;
	GRM_relation_t			 *primary_list    = NULL;
	FILE         *fp              = NULL;
	char* folderTYPE = "Folder";

	/* Get the input arguments */
   usr = ITK_ask_cli_argument("-u=");/* gets user */
   upw = ITK_ask_cli_argument("-p=");/* gets the password */
   ugp = ITK_ask_cli_argument("-g=");/* gets the password */
   inputfile = ITK_ask_cli_argument("-f=");/* get the input file name */

   /* Check input arguments */
   if (( !usr) || (!upw) || (!ugp) || (!inputfile))
   {
      dousage();
      return !ITK_ok ;
   }

   /*  Initialize text services  */
   ITK(ITK_initialize_text_services (ITK_BATCH_TEXT_MODE) );
   ITK(ITK_init_module( usr,upw,ugp));

   /* Open the input dataset file */
	if ((fp = fopen(inputfile,"r"))== NULL)
	{
		printf("Can not able to open the input file %s.\n",inputfile);
		return !ITK_ok;
	}

	/* Read the input file and get the dataset names */
	while (fgets(line,sizeof(line),fp)!= NULL)
	{
      datasetname = strtok(line,",");
      if (!datasetname)
      {
         printf("Dataset name is null\n");
         continue;
      }

      ITK(AE_find_all_datasets (datasetname, &nFound, &dataset_tags));

      if (nFound)
      {
         printf("Deleting dataset %s\n", datasetname);
      }
	  else
      {
         printf("Dataset %s not found \n", datasetname);
      }

      for (i = 0 ;i < nFound ; i++)
      {
		  int n_referencers = 0;
		  int *levels = NULL;
		  tag_t *referencers = NULL;
		  char **relations = NULL;

          // Get the reference objects of dataset
		  // TC 9.1 returns error if the dataset is referenced by any folder
		  // Hence ONE level where-referenced objects
		  // Check whether its a Folder
		  // Remove the dataset from the folder
		  ITK(WSOM_where_referenced( dataset_tags[i], 1, &n_referencers, &levels, &referencers,  &relations ))
         for (j = 0;j < n_referencers  ; j++ )
         {
			 tag_t folderTypeTag = NULLTAG;

			 //Get the folder type
			 ITK(TCTYPE_find_type(folderTYPE, folderTYPE, &folderTypeTag))
			 if(folderTypeTag != NULLTAG)
			 {
				 logical isFolder = false;
				 ITK(AOM_is_type_of(referencers[j], folderTypeTag, &isFolder))
				 if(isFolder)
				 {
					 AM__set_application_bypass(true);
					 ITK( FL_remove( referencers[j],dataset_tags[i] ) )
					 ITK(AOM_save(referencers[j]))
					 AM__set_application_bypass(false);
				 }
			 }
         }

		 MEM_free(levels);
		 MEM_free(referencers);
		 MEM_free(relations);
      }

      if (nFound)
      {
         /* Deleting all the revisions for the dataset */
         ITK(AOM_lock_for_delete(dataset_tags[0]));
         if (stat = AE_delete_all_dataset_revs(dataset_tags[0]))
         {
            printf("Unable to delete %s\n",datasetname);
            stat = ITK_ok;
         }
      }

      MEM_free(dataset_tags);
      dataset_tags = NULL;
	}

	fclose(fp);
   ITK (ITK_exit_module (FALSE) );

   return ITK_ok;
}

