//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================
/*
* Mar 2017 Shreya Suman   	VSEM4.0: Updated for TC11 Chnages
*/
#include <teamcenter/clientx/AppXSession.hxx>

#include <typeinfo> 
#include <iostream>
#ifdef WIN32
#include <tchar.h>
#endif
#include <teamcenter/services/core/DatamanagementService.hxx>
#include <teamcenter/soa/common/DateTime.hxx>
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/client/RuntimeException.hxx>
#include <teamcenter/schemas/soa/_2006_03/exceptions/ServiceException.hxx>
#include <teamcenter/soa/client/NotLoadedException.hxx>
#include <teamcenter/soa/client/model/WorkspaceObject.hxx>
#include <teamcenter/soa/client/model/User.hxx>

#include <teamcenter/services/core/SessionService.hxx>

using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Services::Core;
using namespace Teamcenter::Soa::Common;
using namespace Teamcenter::Soa::Client;
using namespace Teamcenter::Soa::Client::Model;
using namespace Teamcenter::Schemas::Soa::_2006_03::Exceptions;



Connection*                 AppXSession::connection         = NULL;
AppXCredentialManager*      AppXSession::credentialManager  = NULL;
AppXExceptionHandler*       AppXSession::exceptionHandler   = NULL;
AppXPartialErrorListener*   AppXSession::errorListener      = NULL;
AppXModelEventListener*     AppXSession::modelEventListener = NULL;
AppXRequestListener*        AppXSession::requestListener    = NULL;
AppXMemoryAllocator*        AppXSession::memoryAllocator    = NULL;

/**
    * Create an instance of the AppXSession with a connection to the specified
    * server.
    *
    * Add implementations of the ExceptionHandler, PartialErrorListener,
    * ChangeListener, and DeleteListeners.
    *
    * @param host      Address of the host to connect to, http://serverName:80/tc
    */
AppXSession::AppXSession(const std::string& host,const std::string& certFile)
{
    // Create an instance of the CredentialManager, this is used
    // by the SOA Framework to get the user's credentials when
    // challanged by the server (sesioin timeout on the web tier).
    m_bTrackMemory = false; //Make this true to track memory during debugging issues

    if ( m_bTrackMemory )
    { 
        // According to m$, fopen_s is more secure than fopen, but we need to use this on unix too.
#ifdef WIN32
        if( (fopen_s(&m_pMemLogFile,"./AppXMemAllocatorLog.txt", "w+")) != 0 )
#else
        if( (m_pMemLogFile = fopen("./AppXMemAllocatorLog.txt", "w+")) == 0 )
#endif
        {
             cout<<"The file 'AppXMemAllocatorLog.txt' was not opened for writing\n";
        }
    }
    else
        m_pMemLogFile = NULL;

    memoryAllocator = new AppXMemoryAllocator();
    Teamcenter::Soa::Common::MemoryManager::initializeMemoryManager(memoryAllocator, m_bTrackMemory);

    credentialManager = new AppXCredentialManager();

    exceptionHandler   = new AppXExceptionHandler();
    errorListener      = new AppXPartialErrorListener();
    modelEventListener = new AppXModelEventListener();
    requestListener    = new AppXRequestListener();

    Connection::Protocol proto;
    std::string envNameTccs;
    if( host.find("http") == 0)
    {
         proto = Connection::HTTP;
    }
    else if( host.find("tccs") == 0 )
    {
        proto = Connection::TCCS;
        int envNameStart = host.find('/') + 2; 
        envNameTccs = ( host.substr ( envNameStart, host.size() - envNameStart) );
    }
    else
    {
        proto = Connection::IIOP;
    }

    // Create the Connection object, no contact is made with the server
    // until a service request is made
    connection = new Connection(host, credentialManager, proto, Connection::REST, false);
	if(( host.find("https") == 0) ||  (host.find("HTTPS") == 0))
    {
         connection->setOption(Teamcenter::Soa::Client::Connection::OPT_SSL_CA_FILE,certFile);
    }
    if( proto == Connection::TCCS)
        connection->setOption(Teamcenter::Soa::Client::Connection::TCCS_ENV_NAME,envNameTccs);
    

    // Add an ExceptionHandler to the Connection, this will handle any
    // InternalServerException, communication errors, xml marshalling errors
    // .etc
    connection->setExceptionHandler(exceptionHandler);

    // While the above ExceptionHandler is required, all of the following
    // Listeners are optional. Client application can add as many or as few Listeners
    // of each type that they want.

    // Add a Partial Error Listener, this will be notified when ever a
    // a service returns partial errors.
    connection->getModelManager()->addPartialErrorListener( errorListener );


    // Add a Change and Delete Listener, this will be notified when ever a
    // a service returns model objects that have been updated or deleted.
    connection->getModelManager()->addModelEventListener( modelEventListener );

    // Add a Request Listener, this will be notified before and after each
    // service request is sent to the server.
    Connection::addRequestListener( requestListener );

}

/**
  * writes memory info
  *
  * @return  void
  */
void AppXSession::dumpMemoryInfo( const char* pSectionTitle)
{
    if( m_pMemLogFile )
    {
        MemoryInfo memInfo;
        Teamcenter::Soa::Common::MemoryManager::getMemoryManager()->getSoaMemoryInfo(memInfo);

        fprintf(m_pMemLogFile, "\n\n=============================================");
        fprintf(m_pMemLogFile, "\n%s", pSectionTitle);
        fprintf(m_pMemLogFile, "\n=============================================");
        fprintf(m_pMemLogFile, "\nCurrent SOA CDM memory size : %f KB", memInfo.currentAllocSize );
        fprintf(m_pMemLogFile, "\nPeak CDM memory size : %f KB", memInfo.PeakMemSize );
        fprintf(m_pMemLogFile, "\nLargest Memory request : %u bytes", memInfo.LargestMemSizeRequested );
    }
}

/**
    * Get the single Connection object for the application
    *
    * @return  connection
    */
Connection* AppXSession::getConnection()
{
    return connection;
}

/**
    * Login to the Teamcenter Server
    *
    */
Teamcenter::Soa::Common::AutoPtr<User> AppXSession::login(const std::string& uName,const std::string& uPwd)
{
    // Get the service stub
    SessionService* sessionService = SessionService::getService(connection);

    try
    {
        // Prompt for credentials until they are right, or until user
        // cancels
       // CredentialManager::Credentials credentials = credentialManager->promptForCredentials();

        while (true)
        {
            try
            {

                // *****************************
                // Execute the service operation
                // *****************************
                dumpMemoryInfo("MEMORY SIZE BEFORE LOGIN");
                Teamcenter::Services::Core::_2006_03::Session::LoginResponse out = sessionService->login(
                        uName, uPwd,
                        NULL, NULL, NULL, "SoaAppX");
                dumpMemoryInfo("MEMORY SIZE AFTER LOGIN");
                return out.user;
            }
            catch (InvalidCredentialsException& e)
            {
               // credentials = credentialManager->getCredentials(e);
				return NULL;
            }
        }
    }
    // User canceled the operation, don't need to tell him again
    catch (CanceledOperationException& /*e*/) {}

    // Exit the application
    return NULL;
}

AppXSession::~AppXSession()
{
    if( m_pMemLogFile )
    {
        fclose(m_pMemLogFile);
    }
}

/**
    * Terminate the session with the Teamcenter Server
    *
    */
void AppXSession::logout()
{
    // Get the service stub
    SessionService* sessionService = SessionService::getService(connection);
    try
    {
        // *****************************
        // Execute the service operation
        // *****************************
        dumpMemoryInfo("MEMORY SIZE BEFORE LOGOUT");
        sessionService->logout();
        dumpMemoryInfo("MEMORY SIZE AFTER LOGOUT & BEFORE DELETING CONNECTION");
        delete connection;
        delete credentialManager;
        delete exceptionHandler;
        delete errorListener;
        delete modelEventListener;

        if( requestListener )
        {
            Connection::removeRequestListener( requestListener );
            delete requestListener;
        }

        connection       = NULL;
        credentialManager= NULL;
        exceptionHandler = NULL;
        errorListener    = NULL;
        modelEventListener=NULL;
        requestListener  = NULL;
        dumpMemoryInfo("MEMORY SIZE AFTER DELETING CONNECTION");
        Teamcenter::Soa::Common::MemoryManager::getMemoryManager()->dumptofile("./HelloTeamcenterMemDump.txt");
    }
    catch (ServiceException& /*e*/){}
}



/**
    * Print some basic information for a list of objects
    *
    * @param objects
    */
void AppXSession::printObjects(const std::vector<AutoPtr<ModelObject> >& objects)
{

    // Ensure that the referenced User objects that we will use below are loaded
    getUsers( objects );

    std::string name;
    std::string modified;
    std::string ownerName;


    cout << "Name\t\tOwner\t\tLast Modified" << endl;
    cout << "====\t\t=====\t\t=============" << endl;
    for (size_t i = 0; i < objects.size(); i++)
    {
    AutoPtr<WorkspaceObject> wo;
    AutoPtr<ModelObject> obj = objects[i];
    try
    {
            wo = obj.dyn_cast<WorkspaceObject>().getPtr();
    }

    catch (std::bad_cast&)
    {
        continue;
    }

    AutoPtr<User> owner;
    try
        {
        owner = wo->get_owning_user().dyn_cast<User>();

        DateTime lastModified =wo->get_last_mod_date();
        name      = wo->get_object_string();
        ownerName = owner->get_user_name();
            modified  = lastModified.toString();

            cout << name << "\t" << ownerName  << "\t"  << modified << endl;
        }
        catch (NotLoadedException& e)
        {
            // Print out a message, and skip to the next item in the folder
            // Could do a DatamanagementService.getProperties call at this point
            cout << e.getMessage() << endl;
            cout << "The Object Property Policy ($TC_DATA/soa/policies/Default.xml) is not configured with this property." << endl;
        }
    }

}


void AppXSession::getUsers( const std::vector<AutoPtr<ModelObject> >& objects )
{
    DatamanagementService* dmService = DatamanagementService::getService(AppXSession::getConnection());

    std::vector<AutoPtr<ModelObject> > unKnownUsers;
    for (size_t i = 0; i < objects.size(); i++)
    {
    AutoPtr<WorkspaceObject>wo;
    try
    {
        wo = objects[i].dyn_cast<WorkspaceObject>();
    }
    catch (std::bad_cast&)
    {
        continue;
    }

       AutoPtr<User> owner = NULL;
        try
        {
        owner= wo->get_owning_user().cast<User>();
            owner->get_user_name();
        }
        catch (NotLoadedException& /*e*/)
        {
        if(!owner.isNull())
            unKnownUsers.push_back(owner.cast<User>());
        }
    }
    std::vector< std::string> attributes;
    attributes.push_back( "user_name" );


    // *****************************
    // Execute the service operation
    // *****************************
    dmService->getProperties(unKnownUsers, attributes);


}

