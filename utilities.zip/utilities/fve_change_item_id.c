/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: FVE_change_item_id.c
    Module  : main

        Requires a login account specified by -u=<user> -p=<pass> -g=<group>.

===============================================================================
Date               Name                    Description of Change
27-02-2012		Piyush Modak				Initial version
===============================================================================*/

#include <sys/stat.h>
#include <errno.h>
#include <sys/types.h>
#include <FV_prototypes.h>

#include "fve_change_item_id.h"

/*--------------------------Function Prototypes-------------------------------*/

static void print_usage(void);

static logical verbose_flag = false;
FILE *logfileptr = NULL;

/*-------------------------------End------------------------------------------*/

extern int ITK_user_main( int argc, char **  argv )
{
    FILE * fileptr = NULL;

    int line_count = 0;
    int ifail = ITK_ok;
    int len = 0;

    logical is_null = FALSE;

    char line_in[555 + 1] = "";
    char * ptr = 0;
    char logfilename[255 + 1] = "";
    char *older_item_id = NULL;
    char *newer_item_id = NULL;
    const char * verbose = NULL;
    const char * filename = NULL;
    char line_temp[555 + 1] ="";
    char *  login_group = NULL;
    char *  login_user = NULL;
    char * login_password = NULL;
    char * time_stamp = NULL;
    struct stat file_stat;
	tag_t  current_role_tag = NULLTAG;
	char role_name[SA_name_size_c+1];
	char *tmp_dir_path = NULL;

	get_time_stamp(DATE_FORMAT_STR, &time_stamp);
	tmp_dir_path = getenv( VSEM_UTIL_LOG_DIR_VAR );
	
    if( tmp_dir_path == NULL )
    {
		printf ("Environment variable %s is not set\n", VSEM_UTIL_LOG_DIR_VAR);
		exit(0);
	}
	
#if defined(WNT)
    sprintf(logfilename,"%s\\FVE_change_item_id_%s.log",tmp_dir_path, time_stamp);
#else
    sprintf(logfilename,"%s/FVE_change_item_id_%s.log",tmp_dir_path, time_stamp);
#endif

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);

    if(logfileptr)
    {
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
		printf("Start time: %s\n", time_stamp );
		FVE_FREE(time_stamp)
    }
    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

	login_user = ITK_ask_cli_argument("-u=");
	login_password = ITK_ask_cli_argument("-p=");
	login_group = ITK_ask_cli_argument("-g=");
	verbose = ITK_ask_cli_argument( "-v" );
	if ( verbose != 0 )
    {
        verbose_flag = true;
    }
    ITK_initialize_text_services (0);

	if ( login_user != NULL && strlen(login_user)!=0 &&  login_password != NULL && strlen(login_password)!=0 &&  login_group != NULL && strlen(login_group)!=0)
	{
   		ITK(ITK_init_module (login_user, login_password, login_group))
		if(ifail != ITK_ok)
		{
			printf("Login with user id: %s, group:%s is unsuccessful\n", login_user, login_group);
			fprintf(logfileptr,"Login with user id: %s, group:%s is unsuccessful\n", login_user, login_group);
			fclose( logfileptr );
			exit(0);
		}

	}
	else
	{
		ITK (ITK_auto_login ())
		if(ifail != ITK_ok)
		{
			fprintf(logfileptr,"Auto Login unsuccessful\n");
			exit(0);
		}
		else
			fprintf(logfileptr,"Auto Login successful\n");
	}

	ITK (SA_ask_current_role (&current_role_tag))
	ITK (SA_ask_role_name (current_role_tag, role_name))	
	fflush(logfileptr);	
	
	if (!((strcmp(role_name, "DBA") == 0) || (strcmp(role_name, "VSEM Admin") == 0) || (strcmp(role_name, "VSEM Super Admin") ==0)))
	{
		fprintf(logfileptr,"Login with role_name:%s\n",role_name);
		printf("You should be one of the role DBA, VSEM Admin, VSEM Super Admin to run the tool\n");
		fprintf(logfileptr,"You should be one of the role DBA, VSEM Admin, VSEM Super Admin to run the tool\n");
		fclose( logfileptr );
        exit(0);
	}

    older_item_id = ITK_ask_cli_argument("-old_id=");
    newer_item_id = ITK_ask_cli_argument("-new_id=");
	if( (older_item_id == NULL || newer_item_id == NULL) ||
		(tc_strlen(older_item_id) == 0 || tc_strlen(newer_item_id) == 0))
	{
		filename = ITK_ask_cli_argument("-file=");
		if(filename)
			printf("filename is %s\n", filename);

		if ( verbose != 0 )
		{
			verbose_flag = true;
		}

		if ( filename != NULL)
		{
			fileptr = fopen(filename, "r");
			if (fileptr == NULL)
			{
				fprintf(logfileptr, "ERROR: Can not open input file:%s\n", filename);
				get_time_stamp(DATE_FORMAT_STR, &time_stamp);
				fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
				printf("\nEnd time: %s\n", time_stamp);
				FVE_FREE(time_stamp)
				fflush(logfileptr);
				fclose(logfileptr);
				print_usage();
				exit(1);
			}
			
			stat( filename, &file_stat);

			//If input file size is Zero, Exit
			if( file_stat.st_size == 0 )
			{
				fprintf(logfileptr,"ERROR: Input File [%s] is empty!!.\n", filename);
				get_time_stamp(DATE_FORMAT_STR, &time_stamp);
				fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
				printf("\nEnd time: %s\n", time_stamp);
				FVE_FREE(time_stamp)
				fflush(logfileptr);
				fclose( logfileptr );
				print_usage();
				exit(1);
			}
		}
		else
		{
			printf("\nERROR: Either one of the argument should be specified\
					\n1. file \n2. old_id and new_id\n");
			fprintf(logfileptr,"\nERROR: Either one of the argument should be specified\
					\n1. file \n2. old_id and new_id\n", filename);
			print_usage();
			fflush(logfileptr);
			exit(1);
		}

		if ( fileptr != NULL )
		{
			line_count = 0;

			if(verbose_flag)
			{
				fprintf(logfileptr,"INFO: Before Parsing Input File [%s]!!.\n", filename);
				fflush(logfileptr);
			}

			//before change ownership is called ,check in the checked out objects
			//as there are few issues persisting
			//inbulid query//
		
			while (fgets(line_in, 512, fileptr) != 0)
			{
				line_count++;

				if(verbose_flag)
				{
					fprintf(logfileptr,"INFO: Processing Line # [%d]!!.\n", line_count);
					fflush(logfileptr);
				}

				len = (int) strlen(line_in);
				if (len > 0 && line_in[len-1] == '\n')
					line_in[len-1] = '\0';
				if ( strlen(  line_in ) == 0 )
					continue;

				tc_strcpy( line_temp, line_in);

				ptr = tc_strtok(line_temp, "|");
				FVE_get_value(ptr, &older_item_id, &is_null);

				ptr = tc_strtok(NULL, "|");
				FVE_get_value(ptr, &newer_item_id, &is_null);

				if(is_null == TRUE)
				{
					fprintf(logfileptr,"++++ERROR: Attribute values in the line should not be null. Pls. validate the input file before running the utility\n");
					fclose(logfileptr);
					exit(1);
				}

				if(ifail != ITK_ok)
					ifail = ITK_ok;

				if(verbose_flag)
				{
					fprintf(logfileptr,"INFO: Line %d: %s|%s\n",line_count,older_item_id, newer_item_id);
					fflush(logfileptr);
				}

				ITK(FVE_change_id(older_item_id, newer_item_id))

				FVE_FREE(older_item_id)
				FVE_FREE(newer_item_id)

				if(verbose_flag)
				{
					fprintf(logfileptr,"INFO: Complete Process Line # [%d]!!.\n", line_count);
					fflush(logfileptr);
				}

			}

			// Reset the input file to begin reading from the begining
			fseek( fileptr, 0, 0 );
		}
	}
	else
	{
		ITK(FVE_change_id(older_item_id, newer_item_id))
	}

    ITK_exit_module( true );

	fprintf(logfileptr,"\nUtility completed.\n\n");
	printf("\nUtility completed. See the log file %s for more details\n", logfilename);
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp);
	printf("\nEnd time: %s\n", time_stamp);
	FVE_FREE(time_stamp)

    if (logfileptr ) fclose( logfileptr);
    if (fileptr ) fclose( fileptr);

    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}


/*--------------------------------------------------------------------------*/

static void print_usage(void)
{
        printf("\n**********************************************************************************\n");
        printf("Usage: fve_change_item_id <args>\n\n");
        printf(" Where args include the following:\n\n");
		printf(" -u=<login user id>\n");
		printf(" -p=<login password>\n");
		printf(" -g=<login group>\n");
        printf(" -old_id=<item id>  Item Id of the item to be changed\n");
		printf(" -new_id=<item id>  New item id to be set\n");
		printf(" -file=<filename>  input file to change multiple Item IDs\n");
        printf(" Either one of the argument should be specified\n1. file\n2. old_id and new_id:\n\n");
		printf("Each line in the file contains the older itemID and new itemID seperated with pipe (|):\n\n");
        printf("Using older itemID item is searched and the ID is set to newer itemID\n\n");
        printf(" -v is a flag that will turn on verbose mode\n");
        printf("\n");
        printf(" NOTE:- \n");
        printf("**********************************************************************************\n\n");
}

/* This function checks the tokenised value is null or not */
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}

int FVE_change_id(char * old_item_id, char * new_item_id)
{
	int 			ifail 						= ITK_ok;
	tag_t 			newItem 					= NULLTAG;
	tag_t 			oldItem 					= NULLTAG;
	char 			item_type[WSO_name_size_c+1]= "";
	tag_t			attrIdTag					= NULLTAG;

	ITK( ITEM_find_item( new_item_id, &newItem ) )
	if( newItem == NULLTAG )
	{
		ITK( ITEM_find_item( old_item_id, &oldItem ) )
		if(oldItem != NULLTAG)
		{
			AM__set_application_bypass(true);
			ITK(WSOM_ask_object_type(oldItem, item_type))
			ITK(AOM_refresh(oldItem, true))
			if(ifail != ITK_ok)
			{
				ifail = ITK_ok;
				fprintf(logfileptr,"\nINFO: Failed to load the object %s \n", old_item_id);
			}
			else
			{
				ITK (POM_attr_id_of_attr("item_id", item_type, &attrIdTag))

				ITK (POM_set_attr_string  (1, &oldItem, attrIdTag, new_item_id))
				
				if(ifail != ITK_ok)
				{
					ifail = ITK_ok;
					fprintf(logfileptr,"INFO: %s does not complies to the naming rule for item type %s with ifail.\n", new_item_id, item_type, ifail);
				}
				else
				{
					ITK(AOM_save(oldItem))
					ifail = ITK_ok;					
					fprintf(logfileptr,"INFO: %s of type %s updated successfully.\n", new_item_id, item_type);
				}
			}
			ITK(AOM_refresh(oldItem, false))
			
			AM__set_application_bypass(false);
		}
		else
		{
			fprintf(logfileptr,"INFO: %s not found in database\n", old_item_id);
		}
	}
	else
	{
		fprintf(logfileptr,"INFO: %s id already exists in database\n", new_item_id);
	}
	fflush(logfileptr);

	return ifail;
}


void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
			EMH_ask_error_text (stat, &errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], texts[n_ifails-1] );
			fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, ifails[n_ifails-1], lineNumber, errstring );
			fflush(logfileptr);
			MEM_free( errstring );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
			TC_write_syslog( "%s: Error: %d %s\n", prog_name, ifails[n_ifails-1], errstring );
			fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, ifails[n_ifails-1], lineNumber, errstring );
			fflush(logfileptr);

            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
		TC_write_syslog( "%s: Error: %d %s\n", prog_name, stat, errstring );
		fprintf(logfileptr, "%s: Error: %d Line %d in %s\n", prog_name, stat, lineNumber, errstring );
			fflush(logfileptr);
        MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
	/*fprintf(logfileptr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );*/
	fflush(logfileptr);
}

void get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = (byte) newTime->tm_mon;
	currentTime.year = (short) newTime->tm_year + 1900;
	currentTime.day = (byte) newTime->tm_mday;
	currentTime.hour = (byte) newTime->tm_hour;
	currentTime.minute = (byte) newTime->tm_min;
	currentTime.second = (byte) newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}

// Get the last mo
int fve_get_last_mod_date_and_usr( tag_t object_tag, date_t *obj_last_moddate, tag_t *obj_last_modusr_tag )
{
    int			ifail			= ITK_ok;

	ITK( AOM_ask_value_date( object_tag, "last_mod_date", obj_last_moddate ) );
    ITK( AOM_ask_value_tag( object_tag, "last_mod_user", obj_last_modusr_tag ) );

	return ifail;
}
//set back usr and mod date back to the original
int fve_set_usr_and_mod_date_back( tag_t object_tag,  date_t obj_last_moddate,tag_t obj_last_modusr_tag)
{
    int    ifail   =   ITK_ok;
    tag_t  class_id = NULLTAG;

    /*****************************************/
    /* Finding the class id of remote Object */
    /*****************************************/
    ITK( POM_class_of_instance( object_tag, &class_id ));
    ITK(POM_refresh_instances( 1, &object_tag, class_id, POM_modify_lock));
    if( ifail != ITK_ok )
    {
        goto CLEANUP;
    }
    else
    {
		ITK( POM_set_env_info(POM_bypass_attr_update, true, 0, 0, NULLTAG, NULL) );
		ITK( POM_set_modification_date( object_tag, obj_last_moddate) );
		ITK( POM_set_modification_user( object_tag, obj_last_modusr_tag ) );
		ITK( POM_refresh_instances( 1, &object_tag, class_id, POM_no_lock));
		ITK( POM_set_env_info(POM_bypass_attr_update, false, 0, 0, NULLTAG, NULL) );
	}
CLEANUP:
  return ifail;
}

