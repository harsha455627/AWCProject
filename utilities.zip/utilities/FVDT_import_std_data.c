/*==================================================================================================

                    Copyright (c) 2016 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: FVDT_import_std_data.c
    Module  : main

        Used to create GDT Standard objects - Signal & Device names based upon data in input file
        If any of record not found in file but present in database, such recorda are made obsolete

        Requires a login account specified by -u=<user> -p=<pass> -g=<group>.
        
===============================================================================
 * History
 *------------------------------------------------------------------------------
 * Date                 Name              Description of Change
 * June,9 2016     Bhagwan Moondra           Initial Code
 * Sept 2 2016     Bhagwan Moondra         Additional check for class name vs file content to avoid
                                           data corruption
 * Apr 25 2017     Bhagwan Moondra         VSEM4.1 14580030 - Schematic Number- Character limit increase to 128
 * Apr 27 2017     Bhagwan Moondra         Defect 14609288 - Logging enhancement & failure case handling
 * -----------------------------------------------------------------------------
 *
===============================================================================*/
#include "FVDT_import_std_data.h"


/*--------------------------Function Prototypes-------------------------------*/


static void print_usage(void);
FILE *logfileptr = NULL;

int readAndDecryptPasswd( char *passwdFile, /* <I> */
                            char **passwd )    /* <O> */
{
    FILE        *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;
    
    
    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        printf( "ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Could not find password file '%s'\n",
                                                    passwdFile );
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        if( logfileptr )
        fprintf( logfileptr, "ERROR: Invalid format for password file '%s'\n",
                                                        passwdFile );
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);
    
    if ( key  ==  NULL )
    {
        printf( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        if( logfileptr )
            fprintf( logfileptr,"ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n");
        return !ITK_ok ;
    }
    
    DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;
    
    return ifail;
        
}


char *trim(char *str)
{
    size_t len = 0;
    char *frontp = str;
    char *endp = NULL;

    if( str == NULL ) { return NULL; }
    if( str[0] == '\0' ) { return str; }

    len = strlen(str);
    endp = str + len;

    /* Move the front and back pointers to address the first non-whitespace
     * characters from each end.
     */
    while( isspace(*frontp) ) { ++frontp; }
    if( endp != frontp )
    {
        while( isspace(*(--endp)) && endp != frontp ) {}
    }

    if( str + len - 1 != endp )
            *(endp + 1) = '\0';
    else if( frontp != str &&  endp == frontp )
            *str = '\0';

    /* Shift the string so that it starts at str so that if it's dynamically
     * allocated, we can still free it on the returned pointer.  Note the reuse
     * of endp to mean the front of the string buffer now.
     */
    endp = str;
    if( frontp != str )
    {
            while( *frontp ) { *endp++ = *frontp++; }
            *endp = '\0';
    }


    return str;
}

int parse_delimited_string(const char* delimitedString, char* delimiterChars, logical trim_blanks,
	                              int* stringCnt, char*** stringArray)
{
    int     ifail = ITK_ok;
    char*   parseBuffer = NULL;
    char*   token = NULL;

    *stringArray = NULL;
    *stringCnt = 0;

    if (!delimitedString || (tc_strlen(delimitedString) < 1))
       goto CLEANUP;

    FV_strdup(delimitedString, &parseBuffer);
    if (trim_blanks)
       trim(parseBuffer);

    token = tc_strtok(parseBuffer, delimiterChars);
    while (token)
    {
       ITK(FV_copy_string_to_array(stringCnt, stringArray, token))

       // Optionally trim blanks in *copied* string.
       if (trim_blanks)
       {
          trim((*stringArray)[*stringCnt-1]);
       }

       token = tc_strtok(NULL, delimiterChars);
    }

    if (FV_ask_debug_full())
    {
       FV_dump_string_array(*stringCnt, *stringArray, "Parsed strings");
    }

CLEANUP:

    FVDT_FREE(parseBuffer)

    return (ifail);
}

extern int ITK_user_main( int argc, char **  argv )
{   
    FILE*       fileptr                         = NULL;
    int         ifail                           = ITK_ok;
    int         len                             = 0;

    //Total lines read from import file.
    int         line_count                      = 0;

    //Total records of New device/signal creation
    int         num_created                     = 0;

    //Total records of device/signal which were active and getting updated 
    int         num_updates_actv                = 0;

    //Total records of device/signal which were obsolete and getting updated 
    int         num_updates_oblt                = 0;

    //Total records of device/signal getting obsolete
    int         num_obsoleted                   = 0;

    //Total records where create/update failed 
    int         num_failed                      = 0;

    //Sum of all records processed
    int         total_count                     = 0;

    int         count                           = 0;
    int         cnt_psf_tags                    = 0;
    char*       upwf                            = NULL;
    char**      Attributes                      = NULL;
    char        line_in[555 + 1]                = "";
    char        logfilename[255 + 1]            = "";
    char*       classname                       = NULL;
    const char* filename                        = NULL;
    char        line_temp[555 + 1]              = "";
    char*       login_group                     = NULL;
    char*       login_user                      = NULL;
    char*       login_password                  = NULL;
    char*       time_stamp                      = NULL;
    char*       tmp_dir_path                    = NULL;
    tag_t       found_tag                       = NULLTAG;
    tag_t       objCreated                      = NULLTAG;
    tag_t*      psf_tags                        = NULL;
    struct stat file_stat;
    logical exists = FALSE;
    logical isValid                             = FALSE;


	/*----------------------------------------------------------*/
    /*  Log files are placed in the directory specified by the  */
    /*  environment variable TC_TMP_DIR. If this is not set   */
    /*  the files are created in the current directory where    */
    /*  the executable is being run.                            */
    /*----------------------------------------------------------*/
    tmp_dir_path = getenv( DT_TMP_DIR_VAR );

    /*Append the log file name with the date and time stamp 
    along with Process ID */
    get_time_stamp(IMPORT_DATE_FORMAT_STR, &time_stamp);
    if (tmp_dir_path == NULL)
    {
        sprintf(logfilename,"IMPORT_STD_DATA_%s.log",time_stamp); 
    }
    else
    {
#ifdef UNX
        sprintf(logfilename,"%s/IMPORT_STD_DATA_%s.log",tmp_dir_path, time_stamp); 
#else
        sprintf(logfilename,"%s\\IMPORT_STD_DATA_%s.log",tmp_dir_path, time_stamp); 
#endif
    }
    
    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(logfileptr, "\nERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }
    printf("\nLog information will be written into %s\n\n",logfilename);
        
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
          FVDT_FREE(time_stamp)
    }

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }    
    
    classname       = ITK_ask_cli_argument("-class=");
    filename        = ITK_ask_cli_argument("-file=");
    login_user      = ITK_ask_cli_argument("-u=");
    login_password  = ITK_ask_cli_argument("-p=");
    login_group     = ITK_ask_cli_argument("-g=");
    upwf            = ITK_ask_cli_argument("-pf=");

    if (filename== NULL || strlen(filename)==0)
    {
        printf("\nERROR: File Name is missing\n");fflush(stdout);
        fprintf(logfileptr,"ERROR: File Name is missing\n\n");
        print_usage();
        exit(0);
    }

    if (classname== NULL || strlen(classname)==0)
    {
        printf("\nERROR: classname is missing\n");fflush(stdout);
        fprintf(logfileptr,"ERROR: classname is missing\n\n");
        print_usage();
        exit(0);
    }

    printf("\nfilename is %s\n", filename);fflush(stdout);

    /*-------------------------------------------*/
    /*          Decrypt the password             */
    /*-------------------------------------------*/
    if( upwf != 0 )
    {
        readAndDecryptPasswd( upwf, &login_password);
    }

    if ( login_user != NULL && strlen(login_user)!=0 
        &&  login_password != NULL && strlen(login_password)!=0 
        &&  login_group != NULL && strlen(login_group)!=0)
    {
        ITK(ITK_init_module (login_user, login_password, login_group))
        if(ifail != ITK_ok)
            fprintf(logfileptr,"Login with uid: %s, group:%s is unsuccessful\n", login_user, login_group);
        else
            fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n", login_user, login_group);
    }
    else
    {
        ITK_initialize_text_services (0);
        ITK (ITK_auto_login ())
        if(ifail != ITK_ok)
            fprintf(logfileptr,"Auto Login unsuccessful\n");
        else
            fprintf(logfileptr,"Auto Login successful\n");
    }

    if ( filename != NULL)
    {
        fileptr = fopen(filename, "r");
        if (fileptr == NULL)
        {
            fprintf(logfileptr, "ERROR: Can not open input file:%s\n", filename);
            get_time_stamp(IMPORT_DATE_FORMAT_STR, &time_stamp); 
            fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
            FVDT_FREE(time_stamp)
            fclose(logfileptr);
            ITK_exit_module( true );
            exit(1);
        }
    }
    stat( filename, &file_stat);

    /*If input file size is Zero, Exit*/
    if( file_stat.st_size == 0 )
    {
        printf("ERROR: Input File [%s] is empty!!.\n", filename);
        fprintf(logfileptr,"ERROR: Input File [%s] is empty!!.\n", filename);
        get_time_stamp(IMPORT_DATE_FORMAT_STR, &time_stamp); 
        fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
        FVDT_FREE(time_stamp)
        fclose( logfileptr );
        ITK_exit_module( true );
        exit(1);
    }

    ITK(POM_does_class_exist (classname, &exists))
    if (!exists 
        || ((strcmp(classname, SIG_CLASSNAME_CONST) != 0) && (strcmp(classname, COMP_CLASSNAME_CONST) != 0)))
    {
        fprintf(logfileptr,"\nERROR: %s is not a valid class name\n", classname);
        exit(0);
    }

    //Cross check file syntex against the class name provided
    fprintf(logfileptr,"\nValidating file syntex for given class name\n");
    if ( fileptr != NULL && fgets(line_in, 1110, fileptr) != 0 )
    {
        len = (int) strlen(line_in);
        if (len > 0 && line_in[len-1] == '\n')
            line_in[len-1] = '\0'; 
        if ( strlen(  line_in ) != 0 )
        {
            strcpy( line_temp, line_in);

            parse_delimited_string(line_temp,"|",TRUE,&count,&Attributes);
            ITK(FVDT_validate_data_in_file(Attributes, count, classname, line_count, &isValid));
            if(FALSE == isValid)
            {
                fprintf(logfileptr,"\nERROR: File %s is not a valid file for class %s\n", filename, classname);
                printf("\nERROR: File %s is not a valid file for class %s\n", filename, classname);
                exit(0);
            }
        }

        FVDT_FREE_ARRAY( Attributes, count);

        /* Reset the input file to begin reading from the begining*/
        fseek( fileptr, 0, 0 );
    }

    fprintf(logfileptr,"\nClass name & file syntex validation successful\n");

    //Update all existing devices for filling device codes & names
    if(strcmp(classname, COMP_CLASSNAME_CONST) == 0)
    {
        fprintf(logfileptr,"\nUpdating all Std devices for device codes\n");
        update_all_devices_codes_names();
    }

    if ( fileptr != NULL )
    {
        line_count = 0;
        while (fgets(line_in, 1110, fileptr) != 0)
        {
            line_count++;
            len = (int) strlen(line_in);
            if (len > 0 && line_in[len-1] == '\n')
                line_in[len-1] = '\0'; 
            if ( strlen(  line_in ) == 0 )
                continue;
            strcpy( line_temp, line_in);

            fprintf(logfileptr,"\n\nProcessing line no %d, of input file \n", line_count);

            parse_delimited_string(line_temp,"|",TRUE,&count,&Attributes);

            //Check if class object exist based on unique attribute
            //For Signal - Attribute is circuit number
            //For Device - Attribute is device code
            found_tag = NULLTAG;
            FVDT_WSO_uniq_check( Attributes[0], classname, &found_tag);

            //We have validated the first line of file only to exit in the begining.
            //But we should also validate each line before processing
            ITK(FVDT_validate_data_in_file(Attributes, count, classname, line_count, &isValid));
            if(FALSE == isValid)
            {
                num_failed++;

                //If an object is found for given class but has invalid data in file
                //Then add it in the found list, otherwise it will be made obsolete in the end
                if(found_tag != NULLTAG)
                    ITK(FV_add_unique_tag_to_array(&cnt_psf_tags, &psf_tags, found_tag))

                continue;
            }

            if(found_tag == NULLTAG)
            {
                //Its a new record for given class, create with active status
                objCreated = NULLTAG;
                FVE_create_name(Attributes, &num_created, classname, &num_failed, &objCreated);
                if(objCreated != NULLTAG)
                    ITK(FV_add_unique_tag_to_array(&cnt_psf_tags, &psf_tags, objCreated))
            }
            else
            {
                //Existing record found, update all properties with data from input file
                //Also store the tag in array for comparision later
                ITK(FV_add_unique_tag_to_array(&cnt_psf_tags, &psf_tags, found_tag))
                ITK(FVDT_update_wso_obj(found_tag, classname, Attributes, &num_updates_actv, &num_updates_oblt, &num_failed))
            }
            FVDT_FREE_ARRAY( Attributes, count);
        } //end of while loop
             
        /* Reset the input file to begin reading from the begining*/
        fseek( fileptr, 0, 0 );
    }

    //Finally, make all remaining std signals/devices obsolete which are not found in PSF file
    ITK(set_wso_obsolete(classname, cnt_psf_tags, psf_tags, &num_obsoleted))

    printf("\nImport successful.\n\n");

    fprintf(logfileptr,"\n\n\n********************************************************************************************\n");
    fprintf(logfileptr,"*********************************  SUMMARY  ************************************************\n");
    fprintf(logfileptr,"********************************************************************************************\n");
    fprintf(logfileptr,"\nImport  successful\n");

    ITK_exit_module( true );
    fprintf(logfileptr,"\nTotal lines read from import file: %d\n\n", line_count);
    fprintf(logfileptr,"\nNumber of NEW Standards Names CREATED are %d\n\n", num_created);
    fprintf(logfileptr,"\nNumber of ACTIVE Standard Names ALREADY EXISTS and UPDATED are %d\n\n", num_updates_actv);
    fprintf(logfileptr,"\nNumber of OBSOLETE Standard Names ALREADY EXISTS and UPDATED with active status are %d\n\n", num_updates_oblt);
    fprintf(logfileptr,"\nNumber of Standard Names which got OBSOLETE are %d\n\n", num_obsoleted);
    fprintf(logfileptr,"\nNumber of Standard Names FAILED to create/update are %d\n\n", num_failed);

    total_count = num_created + num_updates_actv + num_updates_oblt + num_obsoleted + num_failed;
    fprintf(logfileptr,"\nTotal Count of created(%d) + active updated(%d) + obsolete updated(%d) + obsoleted(%d) + failed(%d) = %d\n", num_created,num_updates_actv,num_updates_oblt,num_obsoleted,num_failed,total_count);

    if(num_obsoleted>0 && total_count>line_count)
        fprintf(logfileptr,"(Total count exceeds the number of lines in file as there are %d standard names in database which are not found in import file and hence got obsolete)\n", num_obsoleted);
    
    fprintf(logfileptr,"\n********************************************************************************************\n");
    fprintf(logfileptr,"********************************************************************************************\n\n");

    printf("\nUtility completed successfully.\n\n");
    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(IMPORT_DATE_FORMAT_STR, &time_stamp); 
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
    FVDT_FREE(time_stamp)   

    if (logfileptr ) fclose( logfileptr);
    if (fileptr ) fclose( fileptr);
    return ifail == ITK_ok ? EXIT_SUCCESS : EXIT_FAILURE;
}

int FVDT_WSO_uniq_check(char* attribute, char *classname, tag_t* objTag)
{
    int         ifail                   = ITK_ok;
    int         iRows                   = 0;
    int         iColumns                = 0;
    const char* enqid                   = "Find Class Object";
    const char* select_attrs[]          = {"puid"};
    char*       device_code             = NULL;
    char*       device_name             = NULL;
    void***     vReport                 = NULL;

    ITK(POM_enquiry_create(enqid))
    ITK(POM_enquiry_add_select_attrs(enqid, classname, 1, select_attrs))

    if(tc_strcmp(classname,COMP_CLASSNAME_CONST) == 0)
    {
        get_device_detail(attribute, &device_code, &device_name);
        ITK(POM_enquiry_set_string_expr(enqid,"attr_expr",classname,DEVICE_CODE_ATTR,POM_enquiry_equal,device_code))
    }
    else
        ITK(POM_enquiry_set_string_expr(enqid,"attr_expr",classname,SIG_CIRCUIT_NUM_ATTR,POM_enquiry_equal,attribute))

    ITK(POM_enquiry_set_where_expr(enqid,"attr_expr"))
    ITK(POM_enquiry_execute(enqid,&iRows,&iColumns,&vReport))
    ITK(POM_enquiry_delete(enqid))
    if(vReport != NULL)
        *objTag =  *((tag_t*)vReport[0][0]);

    //In case of Std device, device code is not present at the time of first import as this is a new field
    //Get the device object by object name
    if(*objTag == NULLTAG && tc_strcmp(classname,COMP_CLASSNAME_CONST) == 0)
    {
        int num = 0;
        tag_t * StdDeviceName_objs = NULL;
        WSO_search_criteria_t criteria;

        ITK(WSOM_clear_search_criteria(&criteria));
        tc_strcpy(criteria.class_name, classname);
        tc_strcpy(criteria.name, attribute);
        ITK(WSOM_search(criteria, &num, &StdDeviceName_objs));
        if(num>0 && StdDeviceName_objs != NULL)
            *objTag = StdDeviceName_objs[0];
    }

    FVDT_FREE(vReport)
    FVDT_FREE(device_code)
    FVDT_FREE(device_name)

    return ifail;
}


/*--------------------------------------------------------------------------*/

static void print_usage(void)
{
   printf("\n**********************************************************************************\n");
   printf("Usage: FVDT_import_std_data <args>\n\n");
   printf(" Where args include the following:\n\n");
   printf(" [-u=<login user id> {-p=password | -pf=passwordFile}] -g=<login group> -class=<ClassName> -file=<filename>\n\n");
   printf("\n");
   printf(" NOTE:- \n");
   printf("For Class FVDTStdCompName   use Import File : dev_gdt2db_load.txt  \n");
   printf("For Class FVDTStdSignalName use Import File : psf_gdt2db_load.txt  \n");
   printf("**********************************************************************************\n\n");        
}

int FVE_create_name(char ** Attributes, int * created_cnt, char *classname, int * failed_cnt, tag_t* objCreated)
{
    int ifail = ITK_ok;
    char*   active_val[1] = {ACTIVE};
    tag_t ObjType = NULLTAG;
    tag_t ObjInputTag = NULLTAG;
    *objCreated = NULLTAG;

    fprintf(logfileptr,"Trying to create %s\n", Attributes[0]);

    ITK(TCTYPE_find_type(classname, NULL,&ObjType))
    ITK(TCTYPE_construct_create_input(ObjType, &ObjInputTag)) 

    if(tc_strcmp(classname,COMP_CLASSNAME_CONST)==0)
    {
        int     length      = 0;
        char*   device_code = NULL;
        char*   device_name = NULL;
        get_device_detail(Attributes[0], &device_code, &device_name);

        ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, COMP_NAME_ATTR, 1, (const char**)&Attributes[0]))

        ITK(TCTYPE_set_create_display_value(ObjInputTag, DEVICE_CODE_ATTR, 1, (const char**)&device_code))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, DEVICE_NAME_ATTR, 1, (const char**)&device_name))

        length = tc_strlen(Attributes[1]);
        if ((Attributes[1]!=NULL) && (length>0)) 
            AOM_set_value_string(ObjInputTag,COMP_SYSTEM_REVIEWER,Attributes[1]);

        length = 0;
        length = tc_strlen(Attributes[2]);
        if ((Attributes[2]!=NULL) && (length>0)) 
            AOM_set_value_string(ObjInputTag,COMP_DESIGNATION,Attributes[2]);

        ITK(TCTYPE_set_create_display_value(ObjInputTag, COMP_CLASS_ATTR, 1, (const char**)&Attributes[3]))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, SCHEMATIC_ATTR, 1, (const char**)&Attributes[4]))
        FVDT_FREE(device_code)
        FVDT_FREE(device_name)
    }
    else if(tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
    {
        ITK(TCTYPE_set_create_display_value(ObjInputTag, OBJ_NAME_ATTR, 1, (const char**)&Attributes[0]))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_SYS_NAME_ATTR, 1, (const char**)&Attributes[6]))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_SUB_SYS_NAME_ATTR, 1, (const char**)&Attributes[7]))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_NAME_ATTR, 1, (const char**)&Attributes[8]))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_CIRCUIT_NUM_ATTR, 1, (const char**)&Attributes[0]))
        ITK(TCTYPE_set_create_display_value(ObjInputTag, SIG_ABB_SIG_NAME_ATTR, 1, (const char**)&Attributes[9]))
    }
    ITK(TCTYPE_set_create_display_value(ObjInputTag, STATUS_ATTR, 1, (const char**)active_val))
    ITK(TCTYPE_create_object(ObjInputTag, objCreated))
    ITK(AOM_save(*objCreated))

    if(ifail == ITK_ok)
    {
        (*created_cnt)++;
        if (tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
        {
            fprintf(logfileptr,"SUCCESS:: %s : %s has been created successfully in %s\n", Attributes[0],Attributes[8], classname);
            fflush (logfileptr);
            fflush (stdout);
            fflush (stderr);
        }
        else
        {
            fprintf(logfileptr,"SUCCESS:: %s has been created successfully in %s\n", Attributes[0], classname);
            fflush (logfileptr);
            fflush (stdout);
            fflush (stderr);
        }
    }
    else
    {
        if (tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
        {
            fprintf(logfileptr,"FAILED:: Creation of %s : $s in %s failed\n",Attributes[0],Attributes[8], classname);
            fflush (logfileptr);
            fflush (stdout);
            fflush (stderr);
        }
        else
        {
            fprintf(logfileptr,"FAILED:: Creation of %s in %s failed\n",Attributes[0], classname);
            fflush (logfileptr);
            fflush (stdout);
            fflush (stderr);
        }
        (*failed_cnt)++;
    }
    return ifail;
}

int FVDT_update_wso_obj(tag_t ObjInputTag, char* classname, char** Attributes, int* num_updates_actv, int* num_updates_oblt, int* num_failed)
{
    int     ifail = ITK_ok;
    char*   status = NULL;

    fprintf(logfileptr,"Existing record found: %s , trying to update the object with file values\n", Attributes[0]);

    ITK(AOM_ask_value_string(ObjInputTag, STATUS_ATTR, &status))

    ITK(AOM_refresh(ObjInputTag, TRUE))
    ITK(AOM_set_value_string(ObjInputTag, STATUS_ATTR, ACTIVE))

    if (tc_strcmp(classname,SIG_CLASSNAME_CONST)==0)
    {
        ITK(AOM_set_value_string(ObjInputTag, OBJ_NAME_ATTR, Attributes[0]))
        ITK(AOM_set_value_string(ObjInputTag, SIG_SYS_NAME_ATTR, Attributes[6]))
        ITK(AOM_set_value_string(ObjInputTag, SIG_SUB_SYS_NAME_ATTR, Attributes[7]))
        ITK(AOM_set_value_string(ObjInputTag, SIG_NAME_ATTR, Attributes[8]))
        ITK(AOM_set_value_string(ObjInputTag, SIG_ABB_SIG_NAME_ATTR, Attributes[9]))
    }
    else
    {
        int     length      = 0;
        char*   device_code = NULL;
        char*   device_name = NULL;
        get_device_detail(Attributes[0], &device_code, &device_name);
        ITK(AOM_set_value_string(ObjInputTag, OBJ_NAME_ATTR, Attributes[0]))
        ITK(AOM_set_value_string(ObjInputTag, COMP_NAME_ATTR, Attributes[0]))

        ITK(AOM_set_value_string(ObjInputTag, DEVICE_CODE_ATTR, device_code))
        ITK(AOM_set_value_string(ObjInputTag, DEVICE_NAME_ATTR, device_name))

        length = tc_strlen(Attributes[1]);
        if ((Attributes[1]!=NULL) && (length>0)) 
            AOM_set_value_string(ObjInputTag,COMP_SYSTEM_REVIEWER,Attributes[1]);

        length = 0;
        length = tc_strlen(Attributes[2]);
        if ((Attributes[2]!=NULL) && (length>0)) 
            AOM_set_value_string(ObjInputTag,COMP_DESIGNATION,Attributes[2]);

        ITK(AOM_set_value_string(ObjInputTag, COMP_CLASS_ATTR,Attributes[3]))
        ITK(AOM_set_value_string(ObjInputTag, SCHEMATIC_ATTR, Attributes[4]))
        FVDT_FREE(device_code)
        FVDT_FREE(device_name)
    }

    ITK(AOM_save(ObjInputTag))
    ITK(AOM_refresh(ObjInputTag, FALSE))
    if(ifail == ITK_ok)
    {
        fprintf(logfileptr,"Object update successful\n");

        if(status != NULL && tc_strlen(status)>0)
        {
            if(tc_strcmp(status, OBSOLETE) == 0)
                (*num_updates_oblt)++;
            else
                (*num_updates_actv)++;
        }
        else
            (*num_updates_oblt)++;  //This else condition should never arise but just in case (if there is object without any status)
    }
    else
    {
        (*num_failed)++;
        fprintf(logfileptr,"Object update failed\n");
    }

    return ifail;
}

void get_time_stamp(char* format, char** timestamp)
{
    date_t currentTime;
    struct tm* newTime = NULL;
    time_t localTime;
    time(&localTime);
    newTime = localtime(&localTime);
    currentTime.month = newTime->tm_mon;
    currentTime.year = newTime->tm_year + 1900;
    currentTime.day = newTime->tm_mday;
    currentTime.hour = newTime->tm_hour;
    currentTime.minute = newTime->tm_min;
    currentTime.second = newTime->tm_sec;

    DATE_date_to_string(currentTime, format, timestamp);
}

int FVDT_validate_data_in_file (char ** Attributes, int count, char *classname, int line_count, logical *isValid)
{
    int ifail = ITK_ok;
    *isValid = TRUE;

    if (strcmp(classname, SIG_CLASSNAME_CONST) == 0)
    {
        if (count != 10 )  
        {
            *isValid = FALSE;
            fprintf(logfileptr,"Error: line no %d, number of columns expected is 10 \n", line_count);
        }
        else
        {
            if (Attributes[0] == NULL || strlen(Attributes[0]) == 0)
            {
                *isValid = FALSE;
                fprintf(logfileptr,"Error: line no %d, first column of the line is blank\n", line_count);
            }
            else if (strstr (Attributes[8], "DO NOT USE"))
            {
                *isValid = FALSE;
                fprintf(logfileptr,"Skipping line no %d, DO NOT USE \n", line_count);
            }
        }
    }
    else if (strcmp(classname, COMP_CLASSNAME_CONST)== 0)
    {
        if (count < 1 ||  Attributes[0] == NULL || strlen(Attributes[0]) == 0)
        {
            *isValid = FALSE;
            fprintf(logfileptr,"Error: line no %d, first column of the line is blank\n", line_count);
        }
        else if (count != 5)
        {
            *isValid = FALSE;
            fprintf(logfileptr,"Error: line no %d, All the columns of this line are not defined\n", line_count);
        }
        else if (strlen(Attributes[3]) > 10)
        {
            *isValid = FALSE;
            fprintf(logfileptr,"Error: line no %d, Component Class value can not exceed 10 characters\n", line_count);
        }
        else if (strlen(Attributes[4]) > 128)
        {
            *isValid = FALSE;
            fprintf(logfileptr,"Error: line no %d, Schematic Number value can not exceed 128 characters\n", line_count);
        }
    }
    return ifail;
}

//Method to set Std Signals/Device obolete which are not found in PSF file
int set_wso_obsolete(char* class_name, int cnt_psf, tag_t* psf_tags, int* num_obsoleted)
{
    int         ifail                   = ITK_ok;
    int         Idx1                    = 0;
    int         iRows                   = 0;
    int         iColumns                = 0;
    int         iRowIdx                 = 0;
    int         cnt_db_tags             = 0;
    int         cnt_obs_tags            = 0;
    const char* enqid                   = "Find Class Objects";
    const char* select_attrs[]          = {"puid"};
    void***     vReport                 = NULL;
    tag_t*      db_tags                 = NULL;
    tag_t*      obs_tags                = NULL;

    ITK(POM_enquiry_create(enqid))
    ITK(POM_enquiry_add_select_attrs(enqid, class_name, 1, select_attrs))
    ITK(POM_enquiry_execute(enqid,&iRows,&iColumns,&vReport))
    ITK(POM_enquiry_delete(enqid))
    for(iRowIdx=0; iRowIdx<iRows; iRowIdx++)
    {
        tag_t objectTag =  *((tag_t*)vReport[iRowIdx][0]);
        if(objectTag != NULLTAG)
        {
            ITK(FV_add_unique_tag_to_array(&cnt_db_tags, &db_tags, objectTag))
        }
    }

    if(cnt_db_tags>cnt_psf)
    {
        for (Idx1=0; Idx1<cnt_db_tags; Idx1++)
        {
            if (FV_find_tag_in_array(cnt_psf, psf_tags, db_tags[Idx1]) <0)
            {
                ITK(FV_add_unique_tag_to_array(&cnt_obs_tags, &obs_tags, db_tags[Idx1]))
            }
        }

        for (Idx1=0; Idx1<cnt_obs_tags; Idx1++)
        {
            ITK(set_wso_status(obs_tags[Idx1], OBSOLETE))
            (*num_obsoleted)++;
        }
    }
    FVDT_FREE(vReport)

    return ifail;
}

int set_wso_status(tag_t Obj, char* status)
{
    int ifail   = ITK_ok;
    ITK(AOM_refresh(Obj, TRUE))
    ITK(AOM_set_value_string(Obj, STATUS_ATTR, status))
    ITK(AOM_save(Obj))
    ITK(AOM_refresh(Obj, FALSE))
    return ifail;
}

void get_device_detail(char* attribute, char** device_code, char** device_name)
{
    int     cnt_str     = 0;
    char**  arr_str     = NULL;

    *device_code = NULL;
    *device_name = NULL;

    parse_delimited_string(attribute,":",TRUE,&cnt_str,&arr_str);
    if(cnt_str>0  && arr_str != NULL )
    {
        if(arr_str[0] != NULL && strlen(arr_str[0]) > 0)
        {
            *device_code = MEM_alloc(sizeof(char)* (strlen(arr_str[0]) + 1));
            strcpy(*device_code, arr_str[0]);
        }
        if(arr_str[1] != NULL && strlen(arr_str[1]) > 0)
        {
            *device_name = MEM_alloc(sizeof(char)* (strlen(arr_str[1]) + 1));
            strcpy(*device_name, arr_str[1]);
        }
    }
    //FVDT_FREE_ARRAY( arr_str, cnt_str);
}

void update_all_devices_codes_names()
{
    int         ifail                   = ITK_ok;
    int         iRows                   = 0;
    int         iColumns                = 0;
    int         iRowIdx                 = 0;
    const char* enqid                   = "Find std Component Class Objects";
    const char* select_attrs[]          = {"puid"};
    void***     vReport                 = NULL;

    ITK(POM_enquiry_create(enqid))
    ITK(POM_enquiry_add_select_attrs(enqid, COMP_CLASSNAME_CONST, 1, select_attrs))
    ITK(POM_enquiry_execute(enqid,&iRows,&iColumns,&vReport))
    ITK(POM_enquiry_delete(enqid))
    for(iRowIdx=0; iRowIdx<iRows; iRowIdx++)
    {
        tag_t objectTag =  *((tag_t*)vReport[iRowIdx][0]);
        if(objectTag != NULLTAG)
        {
            char*   comp_name   = NULL;
            char*   device_code = NULL;
            char*   device_name = NULL;
            ITK(AOM_ask_value_string(objectTag, COMP_NAME_ATTR, &comp_name))

            if(comp_name == NULL || strlen(comp_name) == 0) continue;

            fprintf(logfileptr,"Trying to update device code & device name for %s\n", comp_name);

            get_device_detail(comp_name, &device_code, &device_name);
            AM__set_application_bypass(true);
            ITK(AOM_refresh(objectTag, TRUE))
            if(device_code != NULL && strlen(device_code)>0)
                ITK(AOM_set_value_string(objectTag, DEVICE_CODE_ATTR, device_code))

            if(ifail != ITK_ok)
                fprintf(logfileptr,"Update of %s for device code FAILED\n", comp_name);

            if(device_name != NULL && strlen(device_name)>0)
                ITK(AOM_set_value_string(objectTag, DEVICE_NAME_ATTR, device_name))

            if(ifail != ITK_ok)
                fprintf(logfileptr,"Update of %s for device name FAILED\n", comp_name);

            ITK(AOM_save(objectTag))
            ITK(AOM_refresh(objectTag, FALSE))
            AM__set_application_bypass(true);
            FVDT_FREE(device_code)
            FVDT_FREE(device_name)
            FVDT_FREE(comp_name)
        }
    }
}

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int *severities=NULL;
    const int *ifails=NULL;
    const char **texts=NULL;
    char *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );           
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
}
