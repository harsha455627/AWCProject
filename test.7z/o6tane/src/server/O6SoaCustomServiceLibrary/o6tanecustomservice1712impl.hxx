/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_12_O6TANECUSTOMSERVICE_IMPL_HXX 
#define TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_12_O6TANECUSTOMSERVICE_IMPL_HXX

#include <vector>
#include <unordered_map>
#include <map>
#include <iostream>
#include <cstring>

#include <textsrv/textserver.h>
#include <o6tanecustomservice1712.hxx>

#include <CustomServiceLibrary_exports.h>
#include <tc/emh.h>
#include <common/emh_const.h>

#define SEEDS_CUSTOM_ERROR_BASE (EMH_USER_error_base + 600)

#define ITK( argument )						                                \
{									                                        \
	if (retcode == ITK_ok)													\
	{																		\
		retcode = argument;                                                 \
		if ( retcode != ITK_ok )											\
		{																	\
			char* s;                                                        \
			TC_write_syslog( " "#argument "\n" );                           \
			TC_write_syslog( "  returns [%d]\n", retcode );                 \
			EMH_ask_error_text (retcode, &s);                               \
			EMH_store_error(EMH_severity_error,retcode);                    \
			TC_write_syslog( "  Teamcenter Error: [%s]\n", s);              \
			TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
			if (s != 0) MEM_free (s);                                       \
		}                                                                   \
	}																		\
}

namespace O6
{
    namespace Soa
    {
        namespace CustomServiceLibrary
        {
            namespace _2017_12
            {
                class O6TaneCustomServiceImpl;
            }
        }
    }
}


class SOACUSTOMSERVICELIBRARY_API O6::Soa::CustomServiceLibrary::_2017_12::O6TaneCustomServiceImpl : public O6::Soa::CustomServiceLibrary::_2017_12::O6TaneCustomService

{
public:

    virtual Teamcenter::Soa::Server::ServiceData calculateQSP ( const BusinessObjectRef<Teamcenter::BOMLine>& obj );


};

#include <CustomServiceLibrary_undef.h>
#endif
