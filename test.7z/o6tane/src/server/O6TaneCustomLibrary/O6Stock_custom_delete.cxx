//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6Stock_custom_delete
 *
 */
#include <O6TaneCustomLibrary/O6Stock_custom_delete.hxx>
#include <O6TaneCustomLibrary/method.hxx>

int O6Stock_custom_delete( METHOD_message_t * /*msg*/, va_list args )
{
	tag_t tg_object=va_arg( args, tag_t );
	/*=*/
	int verdict=ITK_ok, error_level=ITK_serious_error, irc=ITK_ok;

	{
	int count_rels2p=0;
	GRM_relation_t 	*rels2p;
	tag_t rel=NULLTAG,secondary=NULLTAG;
	//
	irc = ITK_CALL(GRM_ask_secondary( tg_object, &secondary ));
	irc = ITK_CALL(GRM_find_relation_type (GOODSPURGEDINWAREHOUSE, &rel));
	irc = ITK_CALL(GRM_list_primary_objects (secondary, rel, &count_rels2p, &rels2p));
	if (count_rels2p == 0){
	verdict=error_level;
	irc = ITK_CALL(EMH_store_error ( EMH_severity_error, 919110 ));
	}
	if (count_rels2p >0 )MEM_free(rels2p);

	}
	return (verdict);
}
