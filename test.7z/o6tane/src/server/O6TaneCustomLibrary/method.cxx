#include <O6TaneCustomLibrary/method.hxx>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <tc/emh_errors.h>
#include <tc/preferences.h>
#include <textsrv/textserver.h>
#include <pom/pom/pom.h>
#include <pom/enq/enq.h>
#include <tccore/custom.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/item_msg.h>
#include <tccore/item_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/workspaceobject.h>
#include <tccore/method.h>
#include <tccore/grm_msg.h>
#include <tccore/tc_msg.h>
#include <user_exits/user_exit_msg.h>
#include <ps/ps.h>
#include <qry/qry.h>
#include <bom/bom_msg.h>
#include <epm/epm.h>
#include <me/me_msg.h>
#include <ae/dataset.h>
#include <ict/ict_userservice.h>
#include <dispatcher/dispatcher_itk.h>
#include <O6TaneCustomLibrary/commun.hxx>

int summarize_stock_level ( tag_t sk);

int summarize_stock_level ( tag_t sk) {
int irc=ITK_ok;
tag_t rel_1=NULLTAG,rel_2=NULLTAG, rel_3=NULLTAG, rel_4=NULLTAG, rel_5=NULLTAG;
irc = ITK_CALL(GRM_find_relation_type (GOODSSUMWAREHOUSE, &rel_1));
irc = ITK_CALL(GRM_find_relation_type (GOODSINWAREHOUSE, &rel_2));
irc = ITK_CALL(GRM_find_relation_type (SUPRMGENRM, &rel_3)); 
irc = ITK_CALL(GRM_find_relation_type (BRMGENRM, &rel_4)); 
irc = ITK_CALL(GRM_find_relation_type (BFLEDEFFLE, &rel_5)); 
{
int count_relp2s=0,iter_relp2s=0;
GRM_relation_t 	*relp2s;
irc = ITK_CALL(GRM_list_secondary_objects (sk, rel_1, &count_relp2s, &relp2s));  
for (iter_relp2s=0;iter_relp2s<count_relp2s;iter_relp2s++){
irc = ITK_CALL(GRM_delete_relation (relp2s[iter_relp2s].the_relation));
}
if (count_relp2s>0)MEM_free(relp2s);
}
{
int count_p2s=0,iter_p2s=0;
tag_t 	*p2s;
irc = ITK_CALL(GRM_list_secondary_objects_only (sk, rel_2, &count_p2s, &p2s));  
for (iter_p2s=0;iter_p2s<count_p2s;iter_p2s++){
tag_t tg_class=NULLTAG,tg_attribut=NULLTAG,enqid=NULLTAG;
int objects_count=0;
tag_t *p_tg_objects;
char	*sAttrValue = (char*)NULL;
double dbl_actual=0.0;
irc = ITK_CALL(AOM_ask_value_string(p2s[iter_p2s], TRG_MASTER_ATT, &sAttrValue));
irc = ITK_CALL(AOM_ask_value_double(p2s[iter_p2s], QTY_ATT, &dbl_actual));
irc = ITK_CALL(POM_class_id_of_class ( Q_CLS, &tg_class ) );
irc = ITK_CALL(POM_attr_id_of_attr ( Q_CLS_ATT, Q_CLS, &tg_attribut ) );
irc = ITK_CALL(POM_create_enquiry_on_string ( tg_class, tg_attribut, POM_is_equal_to, &sAttrValue, &enqid ) );
irc = ITK_CALL(POM_execute_enquiry ( enqid, &objects_count, &p_tg_objects ) );
irc = ITK_CALL(POM_delete_enquiries ( 1, &enqid ) );
MEM_free(sAttrValue);
if (objects_count==1){
int prc_tp=0, fnd_entry=0, count_gen=0;
double sum_qty=0;
tag_t obj_sum=NULLTAG, dummy_object=NULLTAG, *gen;
irc = ITK_CALL(AOM_ask_value_string(p_tg_objects[0], OBJTYPE, &sAttrValue));
if (strcmp(sAttrValue,TP_1_1)==0){
irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&obj_sum));
if (obj_sum != NULLTAG){
  prc_tp=1;
}
}
else if (strcmp(sAttrValue,TP_1_2)==0){
irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&dummy_object));
if (dummy_object != NULLTAG){
  irc = ITK_CALL(GRM_list_secondary_objects_only (p_tg_objects[0], rel_4, &count_gen, &gen));
  if (count_gen==1){
    prc_tp=2;
    obj_sum=gen[0];
  }
  else if (count_gen==0){
    prc_tp=2;
    obj_sum=p_tg_objects[0];
    irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&dummy_object));
    if (dummy_object!=NULLTAG){
      obj_sum=dummy_object;
    }
  }
  else{
  }
  if (count_gen>0)MEM_free(gen);
}
else{
}
}
else if (strcmp(sAttrValue,TP_1_3)==0){
irc = ITK_CALL(GRM_list_primary_objects_only (p_tg_objects[0], rel_3, &count_gen, &gen));
if (count_gen==1){
  prc_tp=3;
  obj_sum=gen[0];
}
else if (count_gen==0){
  prc_tp=3;
  obj_sum=p_tg_objects[0];
  irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&dummy_object));
  if (dummy_object!=NULLTAG){
    obj_sum=dummy_object;
  }
}
else{
}
if (count_gen>0)MEM_free(gen);
}
else if (strcmp(sAttrValue,TP_2_1)==0){
irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&dummy_object));
if (dummy_object != NULLTAG){
  irc = ITK_CALL(GRM_list_secondary_objects_only (p_tg_objects[0], rel_5, &count_gen, &gen));
  if (count_gen==1){
    prc_tp=4;
    obj_sum=gen[0];
  }
  else if (count_gen==0){
    prc_tp=4;
    obj_sum=p_tg_objects[0];
    irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&dummy_object));
    if (dummy_object!=NULLTAG){
      obj_sum=dummy_object;
  }
  }
  else{
   }
  if (count_gen>0)MEM_free(gen);
}
else{
}          
}
else if (strcmp(sAttrValue,TP_2_2)==0){
irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&obj_sum));
if (obj_sum != NULLTAG){
  prc_tp=5;
}
}
else if (strcmp(sAttrValue,TP_3_1)==0){
irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&obj_sum));
if (obj_sum != NULLTAG){
  prc_tp=1;
}
}
else if (strcmp(sAttrValue,TP_4_1)==0){
irc = ITK_CALL(ITEM_ask_latest_rev(p_tg_objects[0],&obj_sum));
if (obj_sum != NULLTAG){
  prc_tp=1;
}
}
else{

}
MEM_free(sAttrValue);
if ((prc_tp!=0)&&(obj_sum!=NULLTAG)){
{
  int count_relp2s=0,iter_relp2s=0;
  GRM_relation_t 	*relp2s;
  irc = ITK_CALL(GRM_list_secondary_objects (sk, rel_1, &count_relp2s, &relp2s));  
  for (iter_relp2s=0;iter_relp2s<count_relp2s;iter_relp2s++){     
    if (relp2s[iter_relp2s].secondary==obj_sum){
      fnd_entry=1;
      irc = ITK_CALL(AOM_ask_value_double(relp2s[iter_relp2s].the_relation, QTY_ATT_O_R, &sum_qty)); 
      sum_qty=sum_qty+dbl_actual;
      ITK_CALL(AOM_refresh(relp2s[iter_relp2s].the_relation, TRUE));
      irc = ITK_CALL(AOM_save(relp2s[iter_relp2s].the_relation));
      irc = ITK_CALL(AOM_set_value_double(relp2s[iter_relp2s].the_relation, QTY_ATT_O_R,sum_qty));
      irc = ITK_CALL(AOM_save(relp2s[iter_relp2s].the_relation));
      irc = ITK_CALL(AOM_refresh(relp2s[iter_relp2s].the_relation, FALSE));
      iter_relp2s=count_relp2s;
    }
  }
  if (count_relp2s>0)MEM_free(relp2s);
}
{
  if (fnd_entry!=1){
    tag_t dummy_rel_tag=NULLTAG;
    fnd_entry=0;
    irc = ITK_CALL(GRM_create_relation(sk,obj_sum,rel_1,NULLTAG,&dummy_rel_tag));
    if (irc==ITK_ok){
      irc = ITK_CALL(AOM_refresh(dummy_rel_tag, TRUE));
      irc = ITK_CALL(GRM_save_relation (dummy_rel_tag));
      irc = ITK_CALL(AOM_set_value_double(dummy_rel_tag, QTY_ATT_O_R,dbl_actual));
      irc = ITK_CALL(AOM_save(dummy_rel_tag));
      irc = ITK_CALL(AOM_refresh(dummy_rel_tag, FALSE));
    }
  }
}
}
else{
}
MEM_free(p_tg_objects);
obj_sum=NULLTAG;
dummy_object=NULLTAG;
}
else{
if (objects_count>0)MEM_free(p_tg_objects);
}
}
}
return (irc);
}
/*=*/
