/******************************************************************************
 * Filename        :   FVE_VSCS_milestone_notification.h
 * Description     :   Defines the macro used in FVE_VSCS_milestone_notification.c
 * Module          :   FVE_VSCS_milestone_notification.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name				Description of Change
 * Aug,30 2017		Vinay Deshmukh      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_VSCS_MILESTONE_NOTIFICATION_H
#define FVE_VSCS_MILESTONE_NOTIFICATION_H

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <epm/epm.h>
#include <tccore/aom_prop.h>
#include <tc/envelope.h>
#include <fclasses/tc_date.h>
#include <tcinit/tcinit.h>
#include "PasswdFunction.h"
#include <FV_includes.h>

/*************************************************
* Macros Definition
**************************************************/
#define     FVE_DRSignOff_WORKFLOW_QRY    "InDRSignOffWorkflow_query"
#define     FVE_VSCSPostProduction_WORKFLOW_QRY    "InVSCSPostProdWorkflow_query"
#define     FVE_JOB_NAME                  "job_name"
#define     FVE_OBJECT_NAME               "object_name"
#define		PASSWORDKEY					  "PASSWORDKEY"
#define		FVE_NOTIFY_DUEDATE_LIMIT	  14

/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

// Date format is DD-MMM-YYYY
#define DATE_FORMAT      "%d-%b-%Y"

#endif /* FVE_VSCS_MILESTONE_NOTIFICATION_H */