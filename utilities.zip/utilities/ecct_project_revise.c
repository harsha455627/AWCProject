
#include <tccore/aom.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <form/form.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
# include <tc/tc.h>
#include <me/me.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <ps/absocc.h>

typedef struct stackNode {
        char   item_id[ITEM_id_size_c+1];
		char   rev_id[ITEM_id_size_c+1];
		char   item_type[ITEM_type_size_c+1];
		int    parameter_owner_exist;
		int    parameter_value_exist;
		char   *parameter_owner_value;
		char   parameter_value_id[ITEM_id_size_c+1];
		char   parameter_value_rev_id[ITEM_id_size_c+1];
        struct stackNode *next;
} STACKNODE;

/*===========================================================================*/

/*===========================================================================*/
static void initialize( void );
static int ecct_traverse_and_get_child_line(tag_t, int *, char *, char *, tag_t *);
static int ecct_set_parameter_owner (tag_t , char *, char *);
static char *my_name="ecct_add_parameter_value";
static int ecct_validate_project_for_rev (tag_t , logical *);
static int ecct_dettach_breakdown_from_proj (tag_t, char * );
static int ecct_create_breakdown_for_proj (tag_t, char *, tag_t *, tag_t *);
static int ecct_instantiate_dictionary (tag_t , tag_t);
static int ecct_get_breakdown_from_proj (tag_t , char *, char *, tag_t *);
void delete_stack_all(STACKNODE **);
int ecct_get_usages_of_arch_apn(tag_t apprpnode, int *n_usages,  tag_t **usage_apns);
static int ecct_push_node_in_stack (tag_t line, STACKNODE **head);
static int ecct_get_bomline_attr_for_revise (tag_t line, STACKNODE **newNode);
static int ecct_populate_param_value_in_stack (tag_t line, STACKNODE **newNode);
static int ecct_populate_param_owner_in_stack (tag_t line, STACKNODE **newNode);
int ecct_util_stack_node_init (STACKNODE  **stackNode);
static int ecct_store_project_structure_for_revise (tag_t line, STACKNODE **head);
static int ecct_store_data_for_revise (tag_t archParmBrkDwnRev, STACKNODE **head);
static int ecct_assign_owner_value_from_pred (char *proj_id, char *proj_rev, tag_t archParmBrkDwnRev, STACKNODE **head);
static int ecct_set_parameter_owner_for_revise (char *proj_id, char *proj_rev, tag_t line, STACKNODE *matchNode);
static int ecct_set_parameter_value_for_revise (char *proj_id, char *proj_rev, tag_t line, STACKNODE *matchNode);
static int ecct_traverse_and_assign_the_value (char *proj_id, char *proj_rev, tag_t line, STACKNODE **head);
static int ecct_lookup_node_in_stack (char *item_id, char *rev_id, STACKNODE **head, logical *matchFound, STACKNODE **matchNode);

/*===========================================================================*/
#define IDEBUG ((getenv("VSEM_DEBUG")==NULL)?0:atoi(getenv("VSEM_DEBUG")))
#define TC_PARAMETER_GRP_DEF_TYPE "ParmGrpDef"
#define TC_PARAMETER_GRP_REV_DEF_TYPE "ParmGrpDefRevision"
#define TC_PARAMETER_GRP_VAL_TYPE "ParmGrpVal"
#define TC_LOUHOLDER_ITEM_TYPE "Architecture"
#define TC_PARAMETER_OWNER_BOMLINE_REL "Fnd0StruObjAttrOverride"
#define TC_PROJ_BREAKDOWN_REL "TC_Generic_Architecture"
#define TC_PARAMETER_OWNER_FORM_TYPE "FVE_ParamOwnerForm"
#define TC_PARAMETER_REP_PKT_PARAM "Packeted Parameter"
#define TC_PARAMETER_REP_PARAM_GRP "Parameter Group"
#define TC_PARAMETER_REPRESENT_ATTR "represents"
#define TC_PARAMETER_REPRESENT_BRKDN "Parameter Breakdown"
#define OCCURRENCEGROUP_TYPE_NAME   "AppearanceGroup"
#define TC_PARAMETER_OWNER_ATTR_NAME "FVE_ParameterOwner"
#define IDEBUG ((getenv("VSEM_DEBUG")==NULL)?0:atoi(getenv("VSEM_DEBUG")))
#define FDEBUG ((getenv("FUNC_DEBUG")==NULL)?0:atoi(getenv("FUNC_DEBUG")))

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            dump_itk_errors ( stat, my_name, __LINE__, __FILE__ );         \
        }                                                                  \
    }                                                                      \
}

/*******************************************************************************
 * NAME: dump_itk_errors
 *
 * DESCRIPTION
 *  Function to dump the ITK errors. This function has been inheritted from
 *  Teamcenter sample code.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/
static void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int   *severities=NULL;
    const int   *ifails=NULL;
    const char **texts=NULL;
    char        *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           fprintf( stderr, "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            fprintf( stderr, "%s: Error %d: %s\n", prog_name, stat, errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        fprintf( stderr, "%s: Error %d: %s\n", prog_name, stat, errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    fprintf( stderr, "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
}
/*******************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *  Top function for this command line program.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 *
 ******************************************************************************/
extern int ITK_user_main( int argc, char **argv )
{
    int stat = ITK_ok;
    char *dict_id=NULL;
	char *dict_rev=NULL;
	char *proj_id=NULL;
	char *proj_rev=NULL;
    tag_t projectRev = NULLTAG;
    tag_t newProjectRev = NULLTAG;
    tag_t dictionaryRev = NULLTAG;
    tag_t archParmBrkDwn = NULLTAG;
    tag_t archParmBrkDwnRev = NULLTAG;
    tag_t prevBrkDwnRev = NULLTAG;
    char dictName[ITEM_name_size_c+1];
	logical isValid = false;
	STACKNODE *head = NULL;
	STACKNODE *temp = NULL;

	/* Intialize the Teamcenter environment */
    initialize( );

    /* Get command line argument */
	proj_id = ITK_ask_cli_argument("-proj_id=");
    proj_rev = ITK_ask_cli_argument("-proj_rev=");
    dict_id = ITK_ask_cli_argument("-dict_id=");
    dict_rev = ITK_ask_cli_argument("-dict_rev=");

	/* Get the ECCT project revision */
	if (IDEBUG) TC_write_syslog("Getting ecct project rev...\n");
	ITK ( ITEM_find_rev (proj_id, proj_rev, &projectRev))
	if (projectRev == NULLTAG)
	{
		TC_write_syslog ("+++VSEM ERROR+++ Could not locate the project with ID %s and REV %s\n", proj_id, proj_rev);
		return (!ITK_ok);
	}

	/* Get the Dictionary revision */
	if (IDEBUG) TC_write_syslog("Getting ecct dictionary rev...\n");
	ITK ( ITEM_find_rev (dict_id, dict_rev, &dictionaryRev))
	if (dictionaryRev == NULLTAG)
	{
		TC_write_syslog ("+++VSEM ERROR+++ Could not locate the Dictionary with ID %s and REV %s\n", dict_id, dict_rev);
		return (!ITK_ok);
	}

	/* Create a new revision of the ECCT project */
	ITK ( ecct_validate_project_for_rev (projectRev, &isValid))

	if (isValid == true)
	{
		/*Get the name of dict rev to create a breakdown revision*/
		ITK ( ITEM_ask_rev_name(dictionaryRev, dictName))
		if (IDEBUG) TC_write_syslog("Dictionary Name for lookup is %s\n", dictName);

		if (IDEBUG) TC_write_syslog ("\n\n\n Looking for Parameter breakdown with name %s \n\n\n", dictName);

		/* Get the breakdown from selected project for a selected dictionary id */
		ITK ( ecct_get_breakdown_from_proj (projectRev , dictName, TC_PROJ_BREAKDOWN_REL, &prevBrkDwnRev))
		if (IDEBUG) TC_write_syslog("Returning tag of breakdown revision %d\n", prevBrkDwnRev);

		if (prevBrkDwnRev != NULLTAG)
		{
			if (IDEBUG) TC_write_syslog ("\n\n\n Creating a new revision of ECCT project\n\n\n");
			/* Create a new revision of the ECCT project based on the selected revision */
			ITK ( ITEM_copy_rev (projectRev, NULL, &newProjectRev))

			if (IDEBUG) TC_write_syslog ("\n\n\n Dettaching the breakdown from the newly created revision\n\n\n");
			/* Dettach the parameter breakdown from new revision  (if any) */
			ITK ( ecct_dettach_breakdown_from_proj (newProjectRev, TC_PROJ_BREAKDOWN_REL))
			ITK ( AOM_refresh (newProjectRev, FALSE))

			if (IDEBUG) TC_write_syslog ("\n\n\n Creating a new breakdown revision for a new rev of ECCT project\n\n\n");
			/*Creating a new breakdown for a new project revision*/
			ITK ( ecct_create_breakdown_for_proj (newProjectRev, dictName, &archParmBrkDwn, &archParmBrkDwnRev))


			if (archParmBrkDwnRev)
			{
				if (IDEBUG) TC_write_syslog ("\n\n\n Instantiating a new breakdown revision for a new rev of ECCT project for a given dictionary\n\n\n");
				/*Instantiate the supplied dictionary in a new project revision breakdown */
				ITK ( ecct_instantiate_dictionary (archParmBrkDwnRev, dictionaryRev))

				if (IDEBUG) TC_write_syslog ("\n\n\n\n\n Store the data from previous breakdown revision\n\n\n\n\n");
				/*Store the parameter owner and value items that could be set on the new revision of the project */
				ITK ( ecct_store_data_for_revise (prevBrkDwnRev, &head))

				if (IDEBUG) TC_write_syslog ("\n\n\n Assigning parameter owner and value from previous revison\n\n\n");
				/*Store the parameter owner and value items that could be set on the new revision of the project */
				ITK ( ecct_assign_owner_value_from_pred (proj_id, proj_rev, archParmBrkDwnRev, &head))

				if (IDEBUG) TC_write_syslog ("\n\n\n Freeing up the memory from the stack\n\n\n");
				/*Delete the stacknode */
				delete_stack_all (&head);
			}
		}
		else
			TC_write_syslog ("+++VSEM ERROR+++ Selected dictionary doesn't exist on the previous revision for a name dictName.");
	}
    ITK ( ITK_exit_module( true ))
	
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * NAME: initialize
 *
 * DESCRIPTION
 *  This function initialize the teamcenter environment.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 *
 ******************************************************************************/
static void initialize(void)
{
    int  stat = ITK_ok;

    ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
    ITK (ITK_auto_login ())
}

/*******************************************************************************
 * NAME: ecct_traverse_and_get_child_line
 *
 * DESCRIPTION
 *  This is a recurrsive function that traverse the structure and return
 *  matching BOMLine for a give id and rev.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 *******************************************************************************/
static int ecct_traverse_and_get_child_line(tag_t line, int *stopProcessing, char *prod_id, char *prod_rev, tag_t *prodBomLine)
{
    int		stat = ITK_ok;
	char	*mod_name = "ecct_traverse_and_get_child_line";
	int		inx = 0;
    tag_t   child_item=NULLTAG;
	tag_t   child_item_rev=NULLTAG;
    logical is_it_null=FALSE;
    int     n_children=0;
    tag_t	*children=NULL;
	char	child_id[ITEM_id_size_c+1];
	char	child_rev_id[ITEM_id_size_c+1]; 
    int		line_item_rev_attr=-1;

	if (FDEBUG) TC_write_syslog("Entering:: %s\n",mod_name );
	if (*stopProcessing)
	{
		if (IDEBUG)TC_write_syslog("Stop Processing flag is set. Cannot continue...\n");
		return EXIT_SUCCESS;
	}

    ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemRevTag, &line_item_rev_attr ) )

	ITK ( BOM_line_ask_child_lines( line, &n_children, &children ) )
    for ( inx=0; inx<n_children; inx++ )
	{
		ITK ( BOM_line_ask_attribute_tag( children[inx], line_item_rev_attr, &child_item_rev ) )
    
		ITK ( ITEM_ask_item_of_rev( child_item_rev, &child_item ) )
		ITK ( ITEM_ask_id( child_item, child_id ) )
		ITK ( ITEM_ask_rev_id( child_item_rev, child_rev_id ) )
		
		if (IDEBUG) TC_write_syslog("Processing child_id=%s child_rev=%s...\n", child_id, child_rev_id);
		if ((!strcmp (child_id, prod_id)) && (!strcmp (child_rev_id, prod_rev)))
		{
				if (IDEBUG) TC_write_syslog ("Found the bomline for supplied prod_id=%s and prod_id=%s. No need to traverse further....\n", child_id,child_rev_id );
				*prodBomLine = (tag_t)MEM_alloc(sizeof(tag_t));
				*prodBomLine = children[inx];
				*stopProcessing = 1;
				break;
		}
		else
			ITK ( ecct_traverse_and_get_child_line( children[inx], stopProcessing, prod_id, prod_rev, prodBomLine ) )
	}
	if (children)
		MEM_free( children );

	if (FDEBUG) TC_write_syslog("Leaving:: %s\n",mod_name );

    return EXIT_SUCCESS;
}

/*******************************************************************************
 * NAME: ecct_set_parameter_owner
 *
 * DESCRIPTION
 *  This function:
 *    - Checks if parameter owner form already exist based on FormType attached.
 *    - If Form type of TC_PARAMETER_OWNER_FORM_TYPE doesn't exist, then create
 *      a form with supplied "form_name" argument and sets owner_name to a custom
 *      attribute specified by TC_PARAMETER_OWNER_ATTR_NAME.
 *    - The create form is then attached to a given BOM line IN CONTEXT of top line.
 *      This attachment action creates a necessary absoc and APNs.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 *******************************************************************************/
static int ecct_set_parameter_owner (tag_t line, char *form_name, char *owner_name)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_set_parameter_owner";
	tag_t			window = NULLTAG;
	tag_t			revRule = NULLTAG;
	tag_t			attWinTag = NULLTAG;
	tag_t			attachTopLine = NULLTAG;
	int				numAttachLine = 0;
	tag_t			*attachLines = NULL;
	tag_t			valuetag = NULLTAG;
	char            *param_owner_form_uid = NULL;
	char			obj_type[WSO_name_size_c+1];
	int				inx = 0;
	char            *ownerValue = NULL;
	int				formExist = 0;
	tag_t			owner_form_tag = NULLTAG;
	tag_t			attached_form = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);
	if (form_name == NULL)
	{
		TC_write_syslog ("+++VSEM ERROR+++Supplied form name is NULL. Cannot create parameter owner form\n");
		return ITK_ok;
	}
	if (form_name == NULL)
	{
		TC_write_syslog ("+++VSEM ERROR+++Parameter owner form exists but Parameter owner is not defined. Cannot create parameter owner form\n");
		return ITK_ok;
	}

	if (IDEBUG) TC_write_syslog ("Create a parameter owner form with name %s and value %s\n", form_name, owner_name);

	ITK (BOM_line_ask_window (line, &window))
    ITK (BOM_ask_window_config_rule(window, &revRule))

	ITK ( ME_init_module( ))
    ITK (ME_create_attachment_window(revRule, window, &attWinTag))
    ITK (ME_window_create_root_line(attWinTag, line, &attachTopLine))
    ITK (ME_line_ask_child_lines(attachTopLine, &numAttachLine, &attachLines))

	if (IDEBUG) TC_write_syslog ("Total attachment lines: %d\n", numAttachLine);
	
	for ( inx=0; inx<numAttachLine; inx++ )
	{
        ITK (AOM_ask_value_tag(attachLines[inx],"me_cl_wso",&valuetag))
		
		if (valuetag != NULLTAG)
		{
			ITK (WSOM_ask_object_type (valuetag, obj_type ) )
			/*TC_write_syslog ("Source object type is %s\n", obj_type);*/

			if (!strcmp (obj_type, TC_PARAMETER_OWNER_FORM_TYPE))
			{
				TC_write_syslog ("+++VSEM WARNING+++ Parameter Owner Form already exists....\n");
				formExist = 1;
				break;
			}
		}
	}
	if (attachLines)
		MEM_free (attachLines);

	if (formExist == 0)
	{
		if (IDEBUG) TC_write_syslog ("Creating Parameter Owner form with value %s...\n", form_name);
		ITK (FORM_create (form_name, "Parameter Owner Form", TC_PARAMETER_OWNER_FORM_TYPE, &owner_form_tag))

		if (owner_form_tag)
			if (IDEBUG) TC_write_syslog ("Owner form tag is %d\n", owner_form_tag);

		if (IDEBUG) TC_write_syslog ("Setting the Parameter Owner value %s...\n", owner_name);
		ITK (AOM_set_value_string (owner_form_tag, TC_PARAMETER_OWNER_ATTR_NAME, owner_name))
		ITK (AOM_save (owner_form_tag))

		ITK (AOM_lock (owner_form_tag))
		ITK (ME_line_add (attachTopLine, owner_form_tag, TC_PARAMETER_OWNER_BOMLINE_REL, &attached_form))
		ITK (AOM_unlock (owner_form_tag))
	}

	ITK (ME_window_close(attWinTag))

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return(stat);
}

/*******************************************************************************
 * NAME: ecct_validate_project_for_rev
 *
 * DESCRIPTION
 *   This is a placeholder function to perform any validation for revise.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 *******************************************************************************/
static int ecct_validate_project_for_rev (tag_t projectRev, logical *isValid)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_validate_project_for_rev";

	*isValid = true;

	return (stat);
}


/*******************************************************************************
 * NAME: ecct_dettach_breakdown_from_proj
 *
 * DESCRIPTION
 *  This function dettach the specified relation for a given object and used
 *  to dettach breakdown relation from a newly created revision where it has
 *  inheritted the breakdown from the previous revision.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *  This function wouldn't be needed once the BMIDE Deep copy rule doesn't inherrit
 *  the breakdown as a result of revise.
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 *******************************************************************************/
static int ecct_dettach_breakdown_from_proj (tag_t projectRev, char *relationType)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_dettach_breakdown_from_proj";
	int				inx = 0;
	int				n_secs = 0;
	tag_t			*sec_objs = NULL;
	tag_t			relation = NULLTAG;
	tag_t			relation_tag = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	ITK (GRM_find_relation_type(relationType, &relation_tag))

	/* Get the breakdown from */
	ITK (GRM_list_secondary_objects_only(projectRev,relation_tag,&n_secs,&sec_objs))

	if (IDEBUG) TC_write_syslog ("Total relations of type %s found to delete: %d\n", relationType, n_secs);
	for (inx = 0; inx < n_secs; inx++)
	{
		ITK (GRM_find_relation (projectRev, sec_objs[inx], relation_tag,&relation))
		if (relation != NULLTAG)
		{
			if (IDEBUG) TC_write_syslog ("Deleting a GRM relation for counter %d\n", inx);
			ITK (GRM_delete_relation (relation))
		}
	}

	if (sec_objs)
		MEM_free (sec_objs);
	
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}

/*******************************************************************************
 * NAME: ecct_get_breakdown_from_proj
 *
 * DESCRIPTION
 *  This is a utility function to get the breakdown from the project with a given
 *  relation (TC_Generic_Architecture). The expectation is that there would be
 *  only one breakdown exists on ECCT project.
 *  This function currently finds the matching breakdown by the supplied name.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *  GRM rules for the cardinality of TC_Generic_Architecture can ensure a single
 *  relation.
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_get_breakdown_from_proj (tag_t projectRev, char *dict_name, char *relationType, tag_t *brkdwnRev)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_get_breakdown_from_proj";
	int				inx = 0;
	int				n_secs = 0;
	tag_t			*sec_objs = NULL;
	tag_t			relation = NULLTAG;
	tag_t			item = NULLTAG;
	char			item_name[ITEM_name_size_c+1];
	tag_t			relation_tag = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	ITK (GRM_find_relation_type(relationType, &relation_tag))

	/* Get the breakdown from */
	ITK (GRM_list_secondary_objects_only(projectRev,relation_tag,&n_secs,&sec_objs))

	if (IDEBUG) TC_write_syslog ("Total relations of type %s found to delete: %d\n", relationType, n_secs);

	for (inx = 0; inx < n_secs; inx++)
	{
		ITK (AOM_refresh (sec_objs[inx], FALSE))
		ITK ( ITEM_ask_item_of_rev( sec_objs[inx], &item ))
		ITK ( ITEM_ask_name( item, item_name ))

		if (IDEBUG) TC_write_syslog ("Attached breakdown item has name %s\n", item_name);
		if (!strcmp (item_name, dict_name))
		{
			if (IDEBUG) TC_write_syslog ("Matching breakdown found\n");
			*brkdwnRev = (tag_t)MEM_alloc (sizeof(tag_t));
            *brkdwnRev = sec_objs[inx] ;
			
			break;
		}
	}

	if (sec_objs)
		MEM_free (sec_objs);
		
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}
/*******************************************************************************
 * NAME: ecct_create_breakdown_for_proj_WIP
 *
 * DESCRIPTION
 *  This function creates a breakdown with a given name and auto generated ids
 *  and relates the breakdown to the ecct project.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_create_breakdown_for_proj_WIP (tag_t projectRev, char *brkDnName, tag_t *parmBrkDwn, tag_t *parmBrkDwnRev)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_create_breakdown_for_proj";
	tag_t			archParmBrkDwn = NULLTAG;
	tag_t			archParmBrkDwnRev = NULLTAG;
	tag_t			relation = NULLTAG;
	tag_t			relation_tag = NULLTAG;
	tag_t ParmGrpDefType = NULLTAG;
    tag_t ParmGrpDefRevType = NULLTAG;
    tag_t ParmGrpDefInputTag = NULLTAG;
    tag_t ParmGrpDefRevInputTag = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);
    

    ITK ( TCTYPE_ask_type ( TC_PARAMETER_GRP_DEF_TYPE, &ParmGrpDefType ))
    /* stat = TCTYPE_ask_type ( TC_PARAMETER_GRP_REV_DEF_TYPE, &ParmGrpDefRevType ); */

	ITK ( TCTYPE_construct_create_input (ParmGrpDefType, &ParmGrpDefInputTag) )
	/*ITK ( TCTYPE_construct_create_input (ParmGrpDefRevType, &ParmGrpDefRevInputTag) )*/

	ITK ( TCTYPE_set_create_display_value( ParmGrpDefInputTag, "object_name", 1, &brkDnName ))
	ITK ( TCTYPE_set_create_display_value( ParmGrpDefInputTag, "represents", 1, &TC_PARAMETER_REPRESENT_BRKDN ))

	ITK ( TCTYPE_create_object ( ParmGrpDefInputTag, archParmBrkDwn))
	ITK ( AOM_save( archParmBrkDwn ))
	ITK ( ITEM_ask_latest_rev( archParmBrkDwn, &archParmBrkDwnRev))

	if ((archParmBrkDwn != NULLTAG) && (archParmBrkDwnRev!= NULLTAG))
	{
			*parmBrkDwn = archParmBrkDwn;
			*parmBrkDwnRev = archParmBrkDwnRev;

			ITK (GRM_find_relation_type(TC_PROJ_BREAKDOWN_REL, &relation_tag))

			/*Create TC_generic_architecture relation */
			ITK ( GRM_create_relation (projectRev, archParmBrkDwnRev, relation_tag, NULLTAG, &relation))
			if (relation != NULLTAG)
				ITK (GRM_save_relation(relation))
			else
			{
				TC_write_syslog ("+++VSEM ERROR+++ Failed while creating a relation between new project revision and breakdown. Aborting...\n");
				return (!ITK_ok);
			}
    }
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}
/*******************************************************************************
 * NAME: ecct_create_breakdown_for_proj
 *
 * DESCRIPTION
 *  This function creates a breakdown with a given name and auto generated ids
 *  and relates the breakdown to the ecct project.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_create_breakdown_for_proj (tag_t projectRev, char *brkDnName, tag_t *parmBrkDwn, tag_t *parmBrkDwnRev)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_create_breakdown_for_proj";
	tag_t			archParmBrkDwn = NULLTAG;
	tag_t			archParmBrkDwnRev = NULLTAG;
	tag_t			relation = NULLTAG;
	tag_t			relation_tag = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);
		
	ITK ( ARCH_create_arch_with_struct_info(NULL, NULL, TC_PARAMETER_GRP_DEF_TYPE, brkDnName, NULL, NULL, false, false, false, true, &archParmBrkDwn, &archParmBrkDwnRev))


	if ((archParmBrkDwn != NULLTAG) && (archParmBrkDwnRev!= NULLTAG))
	{
			/*Setting the value for represents on newly created breakdown */
			/*ITK (AOM_set_value_string(archParmBrkDwn, TC_PARAMETER_REPRESENT_ATTR, TC_PARAMETER_REPRESENT_BRKDN))*/

			/*Save the breakdown */
			ITK ( AOM_save(archParmBrkDwn))
			ITK ( AOM_save (archParmBrkDwnRev))

			*parmBrkDwn = archParmBrkDwn;
			*parmBrkDwnRev = archParmBrkDwnRev;

			ITK (GRM_find_relation_type(TC_PROJ_BREAKDOWN_REL, &relation_tag))

			/*Create TC_generic_architecture relation */
			ITK ( GRM_create_relation (projectRev, archParmBrkDwnRev, relation_tag, NULLTAG, &relation))
			if (relation != NULLTAG)
				ITK (GRM_save_relation(relation))
			else
			{
				TC_write_syslog ("+++VSEM ERROR+++ Failed while creating a relation between new project revision and breakdown. Aborting...\n");
				return (!ITK_ok);
			}
    }
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}
/*******************************************************************************
 * NAME: ecct_instantiate_dictionary
 *
 * DESCRIPTION
 *  This is a generic function that instantiates the immediate attachment of
 *  supplied dictionary to a supplied parameter breakdown revision.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_instantiate_dictionary (tag_t archParmBrkDwnRev, tag_t dictionaryRev)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_instantiate_dictionary";
    tag_t			dictWindow = NULLTAG;
    tag_t			top_dictLine = NULLTAG;
    tag_t			brkdnWindow = NULLTAG;
    tag_t			top_brkdnLine = NULLTAG;
	int				n_children=0;
    tag_t			*children=NULL;
	int				inx = 0;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	ITK (BOM_create_window( &dictWindow ))

    ITK (BOM_set_window_top_line( dictWindow, NULLTAG, dictionaryRev, NULLTAG, &top_dictLine ))

	ITK (BOM_create_window( &brkdnWindow ))

    ITK (BOM_set_window_top_line( brkdnWindow, NULLTAG, archParmBrkDwnRev, NULLTAG, &top_brkdnLine ))

	ITK (BOM_line_ask_child_lines( top_dictLine, &n_children, &children ))

	/*TC_write_syslog ("Total Children: %d\n\n", n_children);*/
	for ( inx=0; inx<n_children; inx++ )
	{
		if (IDEBUG) TC_write_syslog ("Before calling RDV_add_with_touchpoint..\n");
		ITK (RDV_add_with_touchpoint (top_brkdnLine, children[inx], true, true))
  		if (IDEBUG) TC_write_syslog ("After calling RDV_add_with_touchpoint..\n");
	}
	if (children)
		MEM_free( children );

	/* Close the BOM windows */
	ITK (BOM_close_window( dictWindow ))
	ITK (BOM_close_window( brkdnWindow ))

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}
/*******************************************************************************
 * NAME: ecct_store_data_for_revise
 *
 * DESCRIPTION
 *  This high level function traverse and stores the parameter owner and value 
 *  information for each parameter group/packetted parameter in a link list.
 *  This function is used to run on the previous revision of ECCT project where
 *  these store values are used to compare on a new revision.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_store_data_for_revise (tag_t archParmBrkDwnRev, STACKNODE **head)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_store_data_for_revise";
    tag_t			brkdnWindow = NULLTAG;
    tag_t			top_brkdnLine = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	ITK (BOM_create_window( &brkdnWindow ))

    ITK (BOM_set_window_top_line( brkdnWindow, NULLTAG, archParmBrkDwnRev, NULLTAG, &top_brkdnLine ))

	/* Traverse the top line and store the values */
	ITK ( ecct_store_project_structure_for_revise (top_brkdnLine, head))

	/* Close the BOM windows */
	ITK (BOM_close_window( brkdnWindow ))

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}
/*******************************************************************************
 * NAME: ecct_store_project_structure_for_revise
 *
 * DESCRIPTION
 *  This is a recursive function to store the parameter owner and value 
 *  information for each parameter group/packetted parameter in a link list
 * 
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_store_project_structure_for_revise (tag_t line, STACKNODE **head)
{
    int  stat = ITK_ok;
	char            *mod_name="ecct_store_project_structure_for_revise";
	int inx = 0;
    tag_t			line_item=NULLTAG;
	tag_t			line_item_rev=NULLTAG;
	int     n_children=0;
    tag_t  *children=NULL;
    static int   line_item_type_attr=-1;
	static int   line_item_attr=-1;
    static int   line_item_rev_attr=-1;
	char *line_item_type = NULL;
	char *child_item_type = NULL;
	char *paramGrpRepresent = NULL;
	int continueProcessing = 1;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

    ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemTag, &line_item_attr ) )
    ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemRevTag, &line_item_rev_attr ) )
	ITK ( BOM_line_look_up_attribute( (char *)bomAttr_itemType, &line_item_type_attr ) )
	
	ITK ( BOM_line_ask_attribute_tag( line, line_item_attr, &line_item ) )
	ITK ( BOM_line_ask_attribute_tag( line, line_item_rev_attr, &line_item_rev ) )
	ITK ( BOM_line_ask_attribute_string( line, line_item_type_attr, &line_item_type ) )

	if (IDEBUG) TC_write_syslog ("Current line item_type = %s\n", line_item_type);

	if (!strcmp (TC_PARAMETER_GRP_DEF_TYPE, line_item_type))
	{
		ITK (AOM_ask_value_string (line_item, TC_PARAMETER_REPRESENT_ATTR, &paramGrpRepresent))
		
		if (paramGrpRepresent)
		{
			if (IDEBUG) TC_write_syslog ("Parameter Group Represents: %s\n", paramGrpRepresent);

			if ((strcmp(paramGrpRepresent, TC_PARAMETER_REP_PARAM_GRP) == 0) ||
				(strcmp(paramGrpRepresent, TC_PARAMETER_REP_PKT_PARAM) == 0))
			{
				if (IDEBUG) TC_write_syslog ("Found the valid bomline representing Parameter Group or Packeted Parameter\n");
				ITK ( ecct_push_node_in_stack (line, head))
				
				/*parameter group or packeted parameter found. Setting a flag for not to traverse further */
				continueProcessing = 0;
			}
			MEM_free (paramGrpRepresent);
		}
	}

	if (!strcmp (TC_LOUHOLDER_ITEM_TYPE, line_item_type))
		continueProcessing = 0;

	MEM_free (line_item_type);

	if (continueProcessing)
	{
		if (IDEBUG) TC_write_syslog ("Continuing...Parameter Group or Packeted Parameter is not yet found\n");
		ITK ( BOM_line_ask_child_lines( line, &n_children, &children ) )

		/*TC_write_syslog ("Total Children: %d\n\n", n_children);*/
		for ( inx=0; inx<n_children; inx++ )
		{
			ITK ( ecct_store_project_structure_for_revise (children[inx], head))
		}
		if (children)
		MEM_free( children );
	}


	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * NAME: ecct_util_stack_node_init
 *
 * DESCRIPTION
 *  Initialize a stack node.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
int ecct_util_stack_node_init (
    STACKNODE  **stackNode
    )
{
    int     stat     = 0;
	char            *mod_name="ecct_util_stack_node_init";

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	*stackNode = (void*)MEM_alloc (sizeof (STACKNODE));
	strcpy ((*stackNode)->item_id, "");
	strcpy ((*stackNode)->rev_id, "");
	strcpy ((*stackNode)->item_type, "");
	(*stackNode)->parameter_owner_exist = 0;
	(*stackNode)->parameter_value_exist = 0;
	(*stackNode)->parameter_owner_value = NULL;
	strcpy ((*stackNode)->parameter_value_id, "");
	strcpy ((*stackNode)->parameter_value_rev_id, "");
	(*stackNode)->next = NULL;

EXIT:
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
    return stat;
}

/*******************************************************************************
 * NAME: ecct_populate_param_owner_in_stack
 *
 * DESCRIPTION
 *  This function finds the parameter owner value from the attached parameter
 *  owner form for a given bomline and populate the values on the STACKNODE.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_populate_param_owner_in_stack (tag_t line, STACKNODE **newNode)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_populate_param_owner_in_stack";
	tag_t			window = NULLTAG;
	tag_t			revRule = NULLTAG;
	tag_t			attWinTag = NULLTAG;
	tag_t			attachTopLine = NULLTAG;
	int				numAttachLine = 0;
	tag_t			*attachLines = NULL;
	tag_t			valuetag = NULLTAG;
	char            *param_owner_form_uid = NULL;
	char			obj_type[WSO_name_size_c+1];
	int				inx = 0;
	char            *ownerValue = NULL;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);
	if (IDEBUG) TC_write_syslog ("Processing id=%s and rev=%s for parameter owner form\n",(*newNode)->item_id,(*newNode)->rev_id );

	ITK (BOM_line_ask_window (line, &window))
    ITK (BOM_ask_window_config_rule(window, &revRule))

	ITK ( ME_init_module( ))
    ITK (ME_create_attachment_window(revRule, window, &attWinTag))
    ITK (ME_window_create_root_line(attWinTag, line, &attachTopLine))
    ITK (ME_line_ask_child_lines(attachTopLine, &numAttachLine, &attachLines))

	if (IDEBUG) TC_write_syslog ("Total attachment lines: %d\n", numAttachLine);
	
	for ( inx=0; inx<numAttachLine; inx++ )
	{
        ITK (AOM_ask_value_tag(attachLines[inx],"me_cl_wso",&valuetag))

		if (valuetag != NULLTAG)
		{
			ITK (WSOM_ask_object_type (valuetag, obj_type ) )
			/*TC_write_syslog ("Source object type is %s\n", obj_type);*/

			if (!strcmp (obj_type, TC_PARAMETER_OWNER_FORM_TYPE))
			{
				ITK (AOM_ask_value_string (valuetag,TC_PARAMETER_OWNER_ATTR_NAME,&ownerValue))
				/*TC_write_syslog ("\n\n\nFound the parameter owner object...\n\n\n"); */
				if (ownerValue)
				{
					if (IDEBUG) TC_write_syslog("Parameter owner name - %s\n", ownerValue);

					(*newNode)->parameter_owner_value = (char *)MEM_alloc ((strlen(ownerValue)+1)*sizeof(char));
					strcpy((*newNode)->parameter_owner_value,ownerValue);
					if (IDEBUG) TC_write_syslog("Parameter owner name - %s\n", (*newNode)->parameter_owner_value);
				}

				if (ownerValue)
					MEM_free (ownerValue);

				(*newNode)->parameter_owner_exist = 1;
				break;
			}
		}
	}
	if (attachLines)
		MEM_free (attachLines);

	ITK (ME_window_close(attWinTag))

	if ((*newNode)->parameter_owner_exist)
		if (IDEBUG) TC_write_syslog ("Parameter owner form found...\n");
	else
		TC_write_syslog ("+++VSEM ERROR+++ Parameter owner form does not exists...\n");

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return(stat);
}

/*******************************************************************************
 * NAME: ecct_populate_param_value_in_stack
 *
 * DESCRIPTION
 *  This function finds the parameter value object (id, rev) for a given bomline
 *  and populate (id, rev) on the STACKNODE.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_populate_param_value_in_stack (tag_t line, STACKNODE **newNode)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_populate_param_value_in_stack";
    tag_t			child_item=NULLTAG;
	tag_t			child_item_rev=NULLTAG;
	char			child_item_type[ITEM_type_size_c+1];
	int				inx = 0;
    tag_t			inputLineApn=NULLTAG;
	int				n_usages=0;
    tag_t			*usage_apns=NULL;
	tag_t			window = NULLTAG;
	tag_t			revRule = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);
	TC_write_syslog ("Processing id=%s and rev=%s for parameter value\n",(*newNode)->item_id,(*newNode)->rev_id );

	ITK ( ME_get_meapprpathnode_from_bomline (line, &inputLineApn))
	ITK ( ecct_get_usages_of_arch_apn (inputLineApn, &n_usages, &usage_apns))

	if (IDEBUG) TC_write_syslog ("DEBUG::Total Usages: %d\n", n_usages);

	if (n_usages > 1)
		TC_write_syslog ("+++ VSEM WARNING+++: More than 1 parameter value object found under parameter group.\n");

	if (n_usages)
	{
		ITK (BOM_line_ask_window (line, &window))
		ITK (BOM_ask_window_config_rule(window, &revRule))
	}

    for ( inx=0; inx<n_usages; inx++ )
	{
		ITK (ME_meapprpathnode_ask_item_revision (usage_apns[inx], revRule, &child_item_rev))
		ITK ( ITEM_ask_item_of_rev( child_item_rev, &child_item ) )
		ITK ( ITEM_ask_type (child_item, child_item_type))

		if (!strcmp (child_item_type, "ParmGrpVal"))
		{
			ITK ( ITEM_ask_id( child_item, (*newNode)->parameter_value_id ) )
			ITK ( ITEM_ask_rev_id( child_item_rev, (*newNode)->parameter_value_rev_id ) )
				
			(*newNode)->parameter_value_exist = 1;
		}
	}

	if (usage_apns)
		MEM_free (usage_apns);

	if ((*newNode)->parameter_value_exist)
		if (IDEBUG) TC_write_syslog ("Parameter Value found...\n");
	else
		TC_write_syslog ("+++VSEM ERROR+++Parameter Value does not exists...\n");

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}
/*******************************************************************************
 * NAME: ecct_get_bomline_attr_for_revise
 *
 * DESCRIPTION
 *  This is a high level function that returns both parameter owner and values
 *  for a given bomline.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_get_bomline_attr_for_revise (tag_t line, STACKNODE **newNode)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_get_bomline_attr_for_revise";
    static int		line_item_rev_attr=-1;
    static int		line_item_type_attr=-1;
    tag_t			line_item=NULLTAG;
	tag_t			line_item_rev=NULLTAG;
    tag_t			child_item=NULLTAG;
	tag_t			child_item_rev=NULLTAG;
	char			*line_item_type = NULL;
	char			*child_item_type = NULL;
	int				n_children=0;
    tag_t			*children=NULL;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);
	
    ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemRevTag, &line_item_rev_attr ) )
    ITK ( BOM_line_look_up_attribute( (char *)bomAttr_itemType, &line_item_type_attr ) )

	ITK ( BOM_line_ask_attribute_tag( line, line_item_rev_attr, &line_item_rev ) )
	ITK ( BOM_line_ask_attribute_string( line, line_item_type_attr, &line_item_type ) )

	strcpy ((*newNode)->item_type, line_item_type);
	MEM_free (line_item_type);

	/* Get and store the values from the supplied line */
	ITK ( ITEM_ask_item_of_rev( line_item_rev, &line_item ) )
	ITK ( ITEM_ask_id( line_item, (*newNode)->item_id ) )
	ITK ( ITEM_ask_rev_id( line_item_rev, (*newNode)->rev_id ) )

	/* Populate the parameter value for the supplied line */
	ITK ( ecct_populate_param_value_in_stack (line, newNode))

	/* Populate the parameter owner form for the supplied line */
	ITK ( ecct_populate_param_owner_in_stack (line, newNode))

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
	return (stat);
}
/*******************************************************************************
 * NAME: ecct_push_node_in_stack
 *
 * DESCRIPTION
 *  This a high level function that obtains parameter owner and parameter value
 *  and store it in the stack (linklist) for future reference.
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_push_node_in_stack (tag_t line, STACKNODE **head)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_push_node_in_stack";
	STACKNODE		*newNode = NULL;
	
	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);
	
	ITK (ecct_util_stack_node_init (&newNode))
	ITK (ecct_get_bomline_attr_for_revise (line, &newNode ))


	if (newNode->parameter_owner_exist)
		if (IDEBUG) TC_write_syslog ("SINGLE BOMLINE DETAILS: item_id%s    item_rev=%s    item_type=%s  parameter_owner=%s  value_id=%s  value_rev=%s\n",newNode->item_id,newNode->rev_id,newNode->item_type, newNode->parameter_owner_value,newNode->parameter_value_id,newNode->parameter_value_rev_id);
	else
		if (IDEBUG) TC_write_syslog ("SINGLE BOMLINE DETAILS: item_id%s    item_rev=%s    item_type=%s  value_id=%s  value_rev=%s\n",newNode->item_id,newNode->rev_id,newNode->item_type,newNode->parameter_value_id,newNode->parameter_value_rev_id);


	if (*head == NULL)
		*head = newNode;
    else
     {
        STACKNODE *prev=*head;
        while (prev->next != NULL)
           prev=prev->next;
        
		prev->next = newNode;
     }

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
	return (stat);

}
/*******************************************************************************
 * NAME: ecct_lookup_node_in_stack
 *
 * DESCRIPTION
 *  This function looks up item_id and rev_id in the stack and returns the
 *  status and matching stack node. The match stack node is used to retrieve
 *  the value of parameter owner and parameter value object identifier (id, rev)
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_lookup_node_in_stack (char *item_id, char *rev_id, STACKNODE **head, logical *matchFound, STACKNODE **matchNode)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_lookup_node_in_stack";
	STACKNODE		*tempNode = NULL;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	if (IDEBUG) TC_write_syslog ("+++ Input data to lookup in the stack is %s_%s\n", item_id, rev_id);
	
	*matchFound  = FALSE;
	
	tempNode = *head;

	if (IDEBUG) TC_write_syslog ("\ntempNode in the begining is %s_%s\n", tempNode->item_id, tempNode->rev_id);
	
    while ((tempNode != NULL) && (*matchNode == NULL))
	{
		if (IDEBUG) TC_write_syslog ("+++ Looping through %s_%s in the stack\n", tempNode->item_id, tempNode->rev_id);
		if ((!strcmp (item_id, tempNode->item_id)) && (!strcmp (rev_id, tempNode->rev_id)))
		{
			*matchFound = true;
			*matchNode = tempNode;
		}
		else
           tempNode=tempNode->next;
	}

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
	return (stat);
}


/*******************************************************************************
 * NAME: ecct_get_usages_of_arch_apn
 *
 * DESCRIPTION
 * This function is temporary in nature and will be obselete once
 * ARCH_usages_of_arch_apn() is functional. This function obtains the
 * the parameter value associated to parameter group.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
int ecct_get_usages_of_arch_apn (tag_t apprpnode,int *n_usages, tag_t **usage_apns)
{
    int					stat = ITK_ok;
	char				*mod_name="ecct_get_usages_of_arch_apn";
    int					n_objs = 0;
    GRM_relation_t		*prim_objs_list = NULL;
    tag_t				occgrp_tag = NULLTAG;
	int					inx = 0;
	int					jnx = 0;
    tag_t				obj_type_tag = NULLTAG;
    char				obj_type_name[WSO_name_size_c+1] = "\0";
    int					n_secs = 0;
    tag_t				*sec_objs = NULL;

    *n_usages = 0;
    *usage_apns = NULL;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	ITK (GRM_list_primary_objects(apprpnode,NULLTAG,&n_objs,&prim_objs_list))

    for(inx = 0;inx < n_objs;inx++)
    {
		ITK (TCTYPE_ask_object_type(prim_objs_list[inx].primary,&obj_type_tag))
		ITK (TCTYPE_ask_name(obj_type_tag,obj_type_name))

        if (tc_strcmp(obj_type_name,OCCURRENCEGROUP_TYPE_NAME) == 0)
        {
            occgrp_tag = prim_objs_list[inx].primary;
            break;
        }
     }

    if (prim_objs_list)
		MEM_free(prim_objs_list);
    
    if (occgrp_tag != NULLTAG)
    {
		ITK (GRM_list_secondary_objects_only(occgrp_tag,NULLTAG,&n_secs,&sec_objs))
       
		*usage_apns = (tag_t *)MEM_alloc((n_secs-1) *sizeof(tag_t));

		/*-------------------------------------------------------------------------
		 * The secondary object for occgrp also list the supplied APN from where we
		 * have started. We have to take away that apns from the results expected
		 * from this function.
		 */
		*n_usages = n_secs -1;

		for(inx = 0,jnx = 0;inx < n_secs;inx++)
		{
			if (sec_objs[inx] != apprpnode)
			{
				(*usage_apns)[jnx] = sec_objs[inx];
				jnx++;
			}
		}
    }
    if (sec_objs)
		MEM_free(sec_objs);
 	
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

    return stat;
}
/*******************************************************************************
 * NAME: ecct_assign_owner_value_from_pred
 *
 * DESCRIPTION
 *  This is a high level function to traverse the previous revision and apply the
 *  the values on the newly created revision.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_assign_owner_value_from_pred (char *proj_id, char *proj_rev, tag_t archParmBrkDwnRev, STACKNODE **head)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_assign_owner_value_from_pred";
    tag_t			brkdnWindow = NULLTAG;
    tag_t			top_brkdnLine = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	ITK (BOM_create_window( &brkdnWindow ))

    ITK (BOM_set_window_top_line( brkdnWindow, NULLTAG, archParmBrkDwnRev, NULLTAG, &top_brkdnLine ))

	/* Traverse the top line and store the values */
	ITK ( ecct_traverse_and_assign_the_value (proj_id, proj_rev, top_brkdnLine, head))

	/* Close the BOM windows */
	ITK (BOM_close_window( brkdnWindow ))

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);

	return (stat);
}
/*******************************************************************************
 * NAME: ecct_traverse_and_assign_the_value
 *
 * DESCRIPTION
 * Recurrsive function to traverse the new project revision breakdown and
 * assign the values and parameter owner.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_traverse_and_assign_the_value (char *proj_id, char *proj_rev, tag_t line, STACKNODE **head)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_traverse_and_assign_the_value";
	int				inx = 0;
    tag_t			line_item=NULLTAG;
	tag_t			line_item_rev=NULLTAG;
	int				n_children=0;
    tag_t			*children=NULL;
    int				line_item_type_attr=-1;
	int				line_item_attr=-1;
    int				line_item_rev_attr=-1;
	char			*line_item_type = NULL;
	char			*child_item_type = NULL;
	char			*paramGrpRepresent = NULL;
	int				continueProcessing = 1;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

    ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemTag, &line_item_attr ) )
    ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemRevTag, &line_item_rev_attr ) )
	ITK ( BOM_line_look_up_attribute( (char *)bomAttr_itemType, &line_item_type_attr ) )
	
	ITK ( BOM_line_ask_attribute_tag( line, line_item_attr, &line_item ) )
	ITK ( BOM_line_ask_attribute_tag( line, line_item_rev_attr, &line_item_rev ) )
	ITK ( BOM_line_ask_attribute_string( line, line_item_type_attr, &line_item_type ) )

	if (IDEBUG) TC_write_syslog ("Current line item_type = %s\n", line_item_type);

	if (!strcmp (TC_PARAMETER_GRP_DEF_TYPE, line_item_type))
	{
		ITK (AOM_ask_value_string (line_item, TC_PARAMETER_REPRESENT_ATTR, &paramGrpRepresent))
		
		if (paramGrpRepresent)
		{
			if (IDEBUG) TC_write_syslog ("Parameter Group Represents: %s\n", paramGrpRepresent);

			if ((strcmp(paramGrpRepresent, TC_PARAMETER_REP_PARAM_GRP) == 0) ||
				(strcmp(paramGrpRepresent, TC_PARAMETER_REP_PKT_PARAM) == 0))
			{
				char item_id[ITEM_id_size_c+1];
				char rev_id[ITEM_id_size_c+1];
				logical matchFound = false;
				STACKNODE *matchNode = NULL;
				
				if (IDEBUG)TC_write_syslog ("Found the valid bomline representing Parameter Group or Packeted Parameter\n");
				
				ITK ( ITEM_ask_id( line_item, item_id ) )
				ITK ( ITEM_ask_rev_id( line_item_rev, rev_id ) )

				/* Lookup the matching node in the stack of previous breakdown */
				ITK ( ecct_lookup_node_in_stack (item_id, rev_id, head, &matchFound, &matchNode))

				if (matchFound == true)
				{
					/* Set the parameter owner */
					ITK ( ecct_set_parameter_owner_for_revise (proj_id, proj_rev, line, matchNode))
					
					/* Set the parameter owner */
					ITK ( ecct_set_parameter_value_for_revise (proj_id, proj_rev, line, matchNode))
				}
				else
				{
					TC_write_syslog ("+++VSEM NOTIFY+++ id=%s and rev=%s is not found in the previous revision of ECCT project. Submit to the workflow...\n", item_id, rev_id);

				}
				/*parameter group or packeted parameter already found found. Setting a flag for not to traverse further */
				continueProcessing = 0;
			}
			MEM_free (paramGrpRepresent);
		}
	}
	if (!strcmp (TC_LOUHOLDER_ITEM_TYPE, line_item_type))
		continueProcessing = 0;

	MEM_free (line_item_type);

	if (continueProcessing)
	{
		if (IDEBUG)TC_write_syslog ("Continuing...Parameter Group or Packeted Parameter is not yet found\n");
		ITK ( BOM_line_ask_child_lines( line, &n_children, &children ) )

		/*TC_write_syslog ("Total Children: %d\n\n", n_children);*/
		for ( inx=0; inx<n_children; inx++ )
		{
			ITK ( ecct_traverse_and_assign_the_value (proj_id, proj_rev, children[inx], head))
		}
		if (children)
		MEM_free( children );
	}

	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * NAME: ecct_set_parameter_owner_for_revise
 *
 * DESCRIPTION
 *  Obtains the value of parameter owner from the stacknode and set it on the bomline.
 *  This function generates the parameter owner form with name PROJID_PROJREV-ARCHID_ARCHREV
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_set_parameter_owner_for_revise (char *proj_id, char *proj_rev, tag_t line, STACKNODE *matchNode)
{
    int				stat = ITK_ok;
	char            *mod_name="ecct_set_parameter_owner_for_revise";
	char			*owner_form_name = NULL;
	char			item_id[ITEM_id_size_c+1];
	char			rev_id[ITEM_id_size_c+1];
    tag_t			absocc_edit_mode_attr=NULLTAG;
    tag_t			absocc_ctxt_line_attr=NULLTAG;
	int				line_item_attr=-1;
    int				line_item_rev_attr=-1;
    tag_t			line_item=NULLTAG;
	tag_t			line_item_rev=NULLTAG;
    tag_t			proj_breakdownLine = NULLTAG;
    tag_t			archWindow = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	if (matchNode->parameter_owner_exist == 1)
	{
		/* Getting the id and rev from the supplied line */	
		ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemTag, &line_item_attr ) )
		ITK ( BOM_line_look_up_attribute( (char *)bomAttr_lineItemRevTag, &line_item_rev_attr ) )
	
		ITK ( BOM_line_ask_attribute_tag( line, line_item_attr, &line_item ) )
		ITK ( BOM_line_ask_attribute_tag( line, line_item_rev_attr, &line_item_rev ) )

		ITK ( ITEM_ask_id( line_item, item_id ) )
		ITK ( ITEM_ask_rev_id( line_item_rev, rev_id ) )

		/* Set the BOM window to make an attachment with IN-CONTEXT mode */
		ITK ( BOM_line_ask_window( line, &archWindow ))
		ITK ( BOM_ask_window_top_line( archWindow, &proj_breakdownLine ))

		//ITK ( PROP_ask_property_by_name( archWindow, (char *)"absocc_specific_edit_mode", &absocc_edit_mode_attr ))
		//ITK ( PROP_ask_property_by_name( archWindow, (char *)"absocc_ctxtline", &absocc_ctxt_line_attr ))
		//ITK ( PROP_set_value_logical( absocc_edit_mode_attr, TRUE ))
		//ITK ( PROP_set_value_tag( absocc_ctxt_line_attr, proj_breakdownLine ))
		  ITK (AOM_set_value_logical(archWindow,(char *)"absocc_specific_edit_mode",TRUE))
		  ITK (AOM_set_value_tag(archWindow,(char *)"absocc_ctxtline",proj_breakdownLine))
		  

		/* Generate the form name */
		owner_form_name = (char *)MEM_alloc ((strlen(proj_id) + strlen("_") + strlen(proj_rev) + strlen("-") + strlen(item_id)+ strlen("_") + strlen(rev_id) +1)*sizeof(char));
		strcpy (owner_form_name, proj_id);
		strcat (owner_form_name,"_");
		strcat (owner_form_name, proj_rev);
		strcat (owner_form_name,"-");
		strcat (owner_form_name, item_id);
		strcat (owner_form_name,"_");
		strcat (owner_form_name, rev_id);

		if (strlen (owner_form_name) > WSO_name_size_c)
			owner_form_name[WSO_name_size_c] = '/0';
		
		/* Set the Parameter owner */
		ITK ( ecct_set_parameter_owner (line, owner_form_name, matchNode->parameter_owner_value))

		MEM_free (owner_form_name);

		/* Save the BOM window */
		ITK ( BOM_save_window ( archWindow ))

		/* Turn OFF the edit with IN-CONTEXT mode */
		//ITK ( PROP_set_value_logical( absocc_edit_mode_attr, FALSE ))
		ITK (AOM_set_value_logical(archWindow,(char *)"absocc_specific_edit_mode",FALSE))
	}
	else
	{
		if (IDEBUG) TC_write_syslog ("+++ VSEM WARNING+++: Parameter owner doesn't exist for a bomline with tag %d. Skipping to set the parameter owner\n", line);
	}

	
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * NAME: ecct_set_parameter_value_for_revise
 *
 * DESCRIPTION
 *
 * This function obtains the parameter value object credentionals (item_id, item_rev)
 * from the matchNode and find the object. It then makes a copy of parameter value
 * object and assign parameter value to breakdown with an action similar to
 * Add Part to Product.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
static int ecct_set_parameter_value_for_revise (char *proj_id, char *proj_rev, tag_t line, STACKNODE *matchNode)
{
    int  stat = ITK_ok;
	char            *mod_name="ecct_set_parameter_value_for_revise";
	tag_t prodLineApn = NULLTAG;
    tag_t proj_rev_tag = NULLTAG;    
	tag_t part_rev_tag = NULLTAG;    
	tag_t new_part_rev_tag = NULLTAG;    
	tag_t new_part_tag = NULLTAG;    
	tag_t occ = NULLTAG;

	if (FDEBUG) TC_write_syslog ("Entering:: %s\n", mod_name);

	/* Get the tag for ECCT project revision */
	ITK (ITEM_find_rev (proj_id, proj_rev, &proj_rev_tag))

	if (proj_rev_tag == NULLTAG)
	{
		TC_write_syslog ("The ECCT project with id=%s and rev=%s cannot be located. Cannot set the parameter value for revise.\n", proj_id, proj_rev);
		return stat;
	}

	if (matchNode->parameter_value_exist == 1)
	{
		/* Get the tag for parameter value revision */
		ITK (ITEM_find_rev (matchNode->parameter_value_id, matchNode->parameter_value_rev_id, &part_rev_tag))
		if (part_rev_tag == NULLTAG)
		{
			TC_write_syslog ("+++VSEM ERROR+++ The Parameter value object with id=%s and rev=%s cannot be located. Cannot set the parameter value for revise.\n", matchNode->item_id, matchNode->rev_id);
			return stat;
		}

		/* Create a new item by making a copy */
		ITK (ITEM_copy_item (part_rev_tag, NULL, NULL, &new_part_tag, &new_part_rev_tag))

		if (new_part_rev_tag == NULLTAG)
		{
			TC_write_syslog ("+++VSEM ERROR+++ Error is creating a new item from rev. Cannot continue\n");
			return stat;
		}

		/* Get the APN for the given line */
		ITK ( ME_get_meapprpathnode_from_bomline (line, &prodLineApn))

		if (prodLineApn)
			ITK ( RDV_add_part_to_product (new_part_rev_tag, line, 1, &proj_rev_tag, prodLineApn, 0, NULL, 1, &occ))
		else
			TC_write_syslog ("+++VSEM ERROR+++ APN for the bomline tag %d is not found\n", line);
	}
	else
	{
		TC_write_syslog ("+++ VSEM WARNING+++: Matching parameter group is found but parameter value doesn't exist.\n");
	}
	if (FDEBUG) TC_write_syslog ("Leaving:: %s\n", mod_name);
    
	return stat;
}
/*******************************************************************************
 * NAME: delete_stack_all
 *
 * DESCRIPTION
 * Free up the memory recursively to cleanup the stack.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *   stackNode              In          Address of the stack node ptr.
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description                  
 * ----------     -------------------    -----------------------------
 * 09/01/08       Alok Laharia          Initial Creation             
 ******************************************************************************/
void delete_stack_all(STACKNODE **head)
{    
	STACKNODE *temp;
	int counter = 1;

	while(*head!=NULL)    
	{  
		if (IDEBUG) TC_write_syslog ("Delete Counter =%d\n", counter);
		counter++;
		temp = *head;        
		*head = (*head)->next;        
		if (temp ->parameter_owner_value !=NULL)
			MEM_free (temp ->parameter_owner_value);
		MEM_free(temp);    
	}
}