/******************************************************************************
 * Filename        :   fve_paramvalue_import_offline 
 * Description     :   Utility is called from dispatcher to import the  parameters values.
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date					Name				Description of Change
 * March 2014       Swapnal Shewale          Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_PARAMVALUE_IMPORT_OFFLINE_H
#define FVE_PARAMVALUE_IMPORT_OFFLINE_H
/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <FV_includes.h>



/*************************************************
* Macros Definition
**************************************************/

#define PASSWORDKEY     "PASSWORDKEY"

				 
void print_usage(void);



#endif
