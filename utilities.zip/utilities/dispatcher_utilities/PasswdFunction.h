/*********************************************************************
 **************   COPYRIGHT, 2000, FORD MOTOR COMPANY   **************
 *********************************************************************
 *
 * CONFIDENTIAL - FORD MOTOR COMPANY
 *
 * This is an unpublished work, which is a trade secret, created in 2000.
 * Ford Motor Company owns all rights to this work and intends to maintain
 * it in confidence to preserve its trade secret status. Ford Motor Company
 * reserves the right to protect this work as an unpublished copyrighted
 * work in the event of an inadvertent or deliberate unauthorized
 * publication. Ford Motor Company also reserves its rights under the
 * copyright laws to protect this work as a published work. Those having
 * access to this work may not copy it, use it, or disclose the information
 * contained in it without the written authorization of Ford Motor Company.
 *
 **************************************************************************
 *  FILE:
 *    PasswdFunction.h
 *
 * PURPOSE :
 *  Definitions for encrypting and decrypting password.
 *
 * INCLUDE FILES
 *
 *
 * Change history:
 * Author               Date            Change
 * Romit(TATA)          04/02/2000      Created.
 *
 *********************************************************************/
#ifndef PASSWD_FUNCTION_H 
#define PASSWD_FUNCTION_H 1

#define UPPER_ASCII_LIMIT 126
#define LOWER_ASCII_LIMIT 33 

extern int EncryptPasswd(char *inputPasswd,
                         char *keyValue,
                         char **encryptedPasswd);

extern int DecryptPasswd(char *encrptedPasswd,
                         char *keyValue,
                         char **actualPasswd);


#endif

