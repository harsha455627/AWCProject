/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <o6tanecustomservice1711impl.hxx>
#include <tccore\item.h>

using namespace O6::Soa::CustomServiceLibrary::_2017_11;
using namespace Teamcenter::Soa::Server;
using namespace std;

Teamcenter::Soa::Server::ServiceData O6TaneCustomServiceImpl::copyObjectAndCreateRelation ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj, const std::string targetItemtype, const std::string targetItemPattern, const std::string targetItemVersion )
{
    // TODO implement operation
	int retcode = ITK_ok;
	struct targetInfo *head_ptr = NULL;
	struct targetInfo *tail_ptr = NULL;

	ServiceData service_data;
	if ( obj.tag() != NULLTAG )
	{
		tag_t item_tag = NULLTAG;

		ITK ( ITEM_ask_item_of_rev ( obj.tag(), &item_tag ) );
		ITK ( getTargetTypeInfo ( item_tag, &head_ptr, ( char* ) targetItemtype.c_str() ) );
		if ( retcode == ITK_ok && head_ptr != NULL )
		{
			bool uflg = false;

			tag_t targetobj = NULLTAG;

			tail_ptr = head_ptr;

			ITK ( isUpdateRequired ( obj.tag(), tail_ptr, &uflg, &targetobj ) );
			if ( retcode == ITK_ok )
			{
				if ( uflg == true && targetobj != NULLTAG )
				{
					/**
					  * commenting below code because no need to copy attributes only
					  * need to update the bom if the formula is already attached/
					  */
					//ITK(update_target(obj.tag(),item_tag, tail_ptr,targetobj));

					// Add code here to copy BOM.
				}
				else
				{
					ITK ( create_target_and_copy_attrs_from_source ( obj.tag(), item_tag, tail_ptr, targetItemPattern, targetItemVersion, &service_data ) );
				}
			}

			/* Memory cleanup */
			do
			{
				struct targetInfo *tmp_ptr = head_ptr->next;

				if ( head_ptr->targettype != NULL )
				{
					MEM_free ( head_ptr->targettype );
					head_ptr->targettype = NULL;
				}
				if ( head_ptr->relation != NULL )
				{
					MEM_free ( head_ptr->relation );
					head_ptr->relation = NULL;
				}
				if ( head_ptr->actiontype != NULL )
				{
					MEM_free ( head_ptr->actiontype );
					head_ptr->actiontype = NULL;
				}
				if ( head_ptr->bomaction != NULL )
				{
					MEM_free ( head_ptr->bomaction );
					head_ptr->bomaction = NULL;
				}

				head_ptr->next = NULL;
				MEM_free ( head_ptr );

				head_ptr = tmp_ptr;

			} while ( head_ptr != NULL );
		}
	}

	if ( retcode != ITK_ok )
	{
		service_data.addErrorStack();
	}

	return service_data;
}



