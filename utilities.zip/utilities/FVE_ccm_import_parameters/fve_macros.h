/******************************************************************************
 * Filename        :   fve_macros.h
 * Description     :   Defines the macro used in fve_import_parameters.c
 * Module          :   fve_import_parameters.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * 03-Apr-2012    Swapnal Shewale	      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVE_MACROS_H
#define FVE_MACROS_H

/*************************************************
* System Header Files
**************************************************/
#include <fve_includes.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}	

/* CALL THE FUNCTION ONLY FOR LOGGING THE ERROR.*/
#define LOG_STATUS \
{\
   if (ifail != ITK_ok)\
   {\
      FVE_Log_Error( ifail, EMH_severity_warning , __FILE__ , __LINE__ , NULL);\
      ifail = ITK_ok;\
   }\
}\

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\

	

/* MACRO TO FREE THE MEMORY TO ALLOCATED ARRAY OF POINTERS.... */
#define FVE_FREE_ARRAY(p, count) \
{\
   int i = 0;\
   if ( p != NULL )\
   {\
      for(i = 0; i < count; i++)\
      {\
         if(p[i] != NULL)\
         {\
            MEM_free(p[i]);\
            p[i] = NULL;\
         }\
      }\
      MEM_free(p);\
      p = NULL;\
   }\
}\

#define FV_FREE_STRINGS(p) \
{\
   if ( p != NULL )\
   {\
      TC_free_strings(p);\
      p = NULL;\
   }\
}\

#define ITK(x) \
{\
   if ( ifail == ITK_ok )\
   {\
      if((ifail = (x)) != ITK_ok)\
      {\
         dump_itk_errors ( ifail, #x, __LINE__, __FILE__ );\
      }\
   }\
}\




#ifdef __cplusplus
}
#endif

#endif 
