//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#ifndef TEAMCENTER_HELLO_HELLO_HXX
#define TEAMCENTER_HELLO_HELLO_HXX

#ifdef __cplusplus
extern "C" {
#endif

#include <tc/tc_util.h>
// WINDOWS-specific macros
#if defined(WNT)
#define FV_MACHINE_TYPE             (SS_WNT_MACHINE)
#define FV_FILEPATH_DELIMITER       ("\\")
#define FV_FILEPATH_DELIMITER_CHAR  ('\\')
#define FV_SHELL_FILE_EXTENSION     ("bat")
#define FV_CALL_COMMAND             ("call")
#define FV_CRYPT_EXE_NAME         ("Crypt.exe")
#define FV_Move_Command           ("rename")
// UNIX-specific macroso
#else
#define FV_MACHINE_TYPE             (SS_UNIX_MACHINE)
#define FV_FILEPATH_DELIMITER       ("/")
#define FV_FILEPATH_DELIMITER_CHAR  ('/')
#define FV_SHELL_FILE_EXTENSION     ("sh")
#define FV_CALL_COMMAND             (" ")
#define FV_CRYPT_EXE_NAME         ("decrypt")
#define FV_Move_Command           ("mv")

#endif

#ifdef __cplusplus
}
#endif

#define FV_SPACE        (" ")

#include <string>
#include <vector>
#include <map>




namespace Teamcenter
{
    namespace Hello
    {
        class Hello;




/**
 * This sample client application demonstrates some of the basic features of the
 * Teamcenter Services framework and a few of the services.
 *
 * An instance of the Connection object is created with implementations of the
 * ExceptionHandler, PartialErrorListener, ChangeListener, and DeleteListeners
 * intefaces. This client application performs the following functions:
 * 1. Establishes a session with the Teamcenter server
 * 2. Display the contents of the Home Folder
 * 3. Performs a simple query of the database
 * 4. Create, revise, and delete an Item
 *
 */
class Hello
{
public:

};


}} //end namespace
#endif

