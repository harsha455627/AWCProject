//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object O6_FleRootRevisionImpl
//

#include <O6TaneCustomLibrary/O6_FleRootRevisionImpl.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>

#include <string>
#include <iostream>
#include <cstdlib>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>

#define STRING_ATTR_VALUE_SET_WARNING ( SEEDS_CUSTOM_ERROR_BASE + 51 )


/**
 * Bom line custom attributes.
 */
#define bomAttr_bl_occ_o6_percent_theoric "bl_occ_o6_percent_theoric"
#define bomAttr_bl_occ_o6_vol_percent_theoric "bl_occ_o6_vol_percent_theoric"
#define bomAttr_lineO6_SAP_Cost "o6_sap_cost"

#define OBJECT_TYPE "object_type"
#define MP_GEN_REV "O6_GenRMRevision"
#define SAP_PRICE_ATTR "o6_prix_sap"
#define SAP_PRICE_INI_ATTR "o6_prix_ini"
#define O6_SAP_COST "o6_sap_cost"
#define MEAN_DENSITY "o6_densite"
#define SAP_PRICE_SUP_ATTR "o6_prix_fournis"
#define GEN_TO_SUP "O6_GenToSupplRM"
#define SUPL_REV "O6_SupRMRevision"
#define FLE_BATCH_REV "O6_FleBatchRevision"
#define FLE_REV "O6_FleRevision"

/**
 * Bomline attributes declaration.
 */
static int item_revtag_attribute;
static int quantiy_attribute;
static int name_attribute;
static int bl_occ_o6_percent_theoric_attribute;
static int bl_occ_o6_vol_percent_theoric_attribute;
static int item_uom_attribute;
static int uom_attribute;
static int bl_o6_sap_cost_attribute;

using namespace o6tane;

//----------------------------------------------------------------------------------
// O6_FleRootRevisionImpl::O6_FleRootRevisionImpl(O6_FleRootRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
O6_FleRootRevisionImpl::O6_FleRootRevisionImpl( O6_FleRootRevision& busObj )
   : O6_FleRootRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// O6_FleRootRevisionImpl::~O6_FleRootRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
O6_FleRootRevisionImpl::~O6_FleRootRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// O6_FleRootRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int O6_FleRootRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = O6_FleRootRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

/**
 * Function    :  initialise_attribute
 * Description :  Initialize BOM attributes.
 * Input       :
 */

static int initialise_attribute (char *name,  int *attribute)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (name, attribute));

    return retcode;
  }

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 * Input       :
 */
static int initialise (void)
  {
    int retcode = ITK_ok;


    ITK(BOM_line_look_up_attribute (bomAttr_lineItemRevTag, &item_revtag_attribute));

    ITK(initialise_attribute (bomAttr_lineName, &name_attribute));
    ITK(initialise_attribute (bomAttr_occQty, &quantiy_attribute));
    ITK(initialise_attribute(bomAttr_itemUom, &item_uom_attribute));
    ITK(initialise_attribute (bomAttr_occUoM, &uom_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_percent_theoric, &bl_occ_o6_percent_theoric_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_vol_percent_theoric,&bl_occ_o6_vol_percent_theoric_attribute ));
    ITK(initialise_attribute (bomAttr_lineO6_SAP_Cost, &bl_o6_sap_cost_attribute ));

    return retcode;
  }

/**
 * Function		: getConvertedCost
 * Description	: Get cost value based on unit of measure selected
 * Input		:
 * 		bomline 		 - tag of Bomline used for evaluation
 * 		unitTopLinestr   - char pointer denoting Topline UOM value
 * 		sap_price_var    - double sap price value
 * 		finalcost        - double final cost based on UOM
 * Output		:
 * 		none
 */
int getConvertedCost(tag_t bomline, char* unitTopLinestr, double sap_price_var, double* finalcost){
	int retcode = ITK_ok;
	char* bl_uom_str = NULL;

	ITK(BOM_line_ask_attribute_string(bomline, item_uom_attribute, &bl_uom_str));
	if (retcode == ITK_ok && bl_uom_str != NULL) {

		if (tc_strlen(bl_uom_str) > 0) {
			if (tc_strcmp(unitTopLinestr, bl_uom_str) == 0) {
				/*Unit price calculation based on topline UOM and BOMLine component UOM*/
				if((tc_strcmp(unitTopLinestr, KG) == 0 && tc_strcmp(bl_uom_str, KG) == 0))
				{
					*finalcost = sap_price_var;
				}
				else if ( (tc_strcmp(unitTopLinestr, LITER) == 0 && tc_strcmp(bl_uom_str, LITER) == 0) )
				{
					*finalcost = sap_price_var;
				}
				else
				{
					*finalcost = sap_price_var * 1000;
				}
			} else if (tc_strcmp(unitTopLinestr, KG) == 0
					&& tc_strcmp(bl_uom_str, GM) == 0) {
				*finalcost = sap_price_var * 1000;
			}else if (tc_strcmp(unitTopLinestr, KG) == 0
					&& tc_strcmp(bl_uom_str, LITER) == 0) {
				*finalcost = sap_price_var;
			}else if (tc_strcmp(unitTopLinestr, GM) == 0
					&& tc_strcmp(bl_uom_str, LITER) == 0) {
				*finalcost = sap_price_var;
			}else if (tc_strcmp(unitTopLinestr, GM) == 0
					&& tc_strcmp(bl_uom_str, KG) == 0) {
				*finalcost = sap_price_var;
			}else if (tc_strcmp(unitTopLinestr, LITER) == 0
					&& tc_strcmp(bl_uom_str, KG) == 0) {
				*finalcost = sap_price_var;
			}else if (tc_strcmp(unitTopLinestr, LITER) == 0
					&& tc_strcmp(bl_uom_str, GM) == 0) {
				*finalcost = sap_price_var * 1000;
			}
		}

		MEM_free(bl_uom_str);
		bl_uom_str = NULL;
	}

	return retcode;
}

/**
 * Function		: traverse_BOM
 * Description	: Traverse single level bom and set attributes on bom line.
 * Input		:
 * 		top_line 		 - Top BOMLine
 * 		root_itemrev_tag - Item revision of top bomline.
 * Output		:
 * 		none
 */
int traverse_BOM(tag_t top_line, std::string objtype, double *totalcost) {

	int retcode = ITK_ok;
	int chld_cnt = 0;

	double totcost = 0;

	tag_t* children = NULL;

	char* tempValStr = NULL;

	ITK(BOM_line_ask_child_lines (top_line, &chld_cnt, &children));
	if (retcode == ITK_ok && chld_cnt > 0) {

		/* Get UOM of top line */
		char* unitTopLinestr = NULL;
		ITK(BOM_line_ask_attribute_string(top_line, item_uom_attribute, &unitTopLinestr));
		if(retcode == ITK_ok && unitTopLinestr != NULL){

			if (tc_strlen(unitTopLinestr) > 0 && tc_strcmp(unitTopLinestr, EACH) != 0) {
				for (int indx = 0; indx < chld_cnt && retcode == ITK_ok; indx++) {

					tag_t itemrev = NULLTAG;
					ITK(BOM_line_ask_attribute_tag (children[indx], item_revtag_attribute, &itemrev));
					if (retcode == ITK_ok && itemrev != NULLTAG ) {

						char* objtypestr = NULL;
						ITK(AOM_ask_value_string(itemrev,OBJECT_TYPE, &objtypestr));
						if (retcode == ITK_ok && objtypestr != NULL) {

							double sap_price_var = 0;
							if (tc_strcmp(objtypestr, MP_GEN_REV) == 0)
							{
								ITK ( BOM_line_ask_attribute_double ( children[indx], bl_o6_sap_cost_attribute, &sap_price_var) );

								if ( retcode == ITK_ok && sap_price_var == 0 )
								{
									ITK ( AOM_ask_value_double ( itemrev, SAP_PRICE_INI_ATTR, &sap_price_var ) );
								}

							} else if (tc_strcmp(objtypestr, SUPL_REV) == 0 && objtype != FLE_REV) {

								ITK(AOM_ask_value_double(itemrev, SAP_PRICE_SUP_ATTR, &sap_price_var));
								/**
								 * Change from MR03 Review
								 * a.	If the BOMLine contains a Generic RM, we use the value of its attribute
								 * 		"o6_prix_sap". If that one is empty, we use the one for "o6_prix_ini"
								 * b.	If the BOMLine contains a Supplier RM, we use the value of attribute
								 * 		"o6_prix_fournis"
								 *
								 */
								/**
								 * Formula does not have a supplier as a child component but just to re verify added above condition.
								 */
							}

							if (retcode == ITK_ok && sap_price_var > 0) {

								if (objtype == FLE_REV || objtype == FLE_BATCH_REV) {

									ITK(BOM_line_ask_attribute_string(children[indx], bl_occ_o6_percent_theoric_attribute, &tempValStr));
									if (retcode == ITK_ok && tempValStr != NULL) {

										if (tc_strlen(tempValStr) > 0) {

											double blqty = atof(tempValStr);
											if (blqty > 0) {
												double finalcost = 0;
												ITK(getConvertedCost(children[indx], unitTopLinestr, sap_price_var, &finalcost));
												if (retcode == ITK_ok && finalcost > 0)
												{
													char* pcUOMValue = NULL;
													double valueVar  = 0.0;

													ITK ( BOM_line_ask_attribute_string ( children[indx], item_uom_attribute, &pcUOMValue ) );
													/*Valeur calculation based on topline UOM and component UOM*/
													if ( ( tc_strcmp ( unitTopLinestr, KG ) == 0 || tc_strcmp ( unitTopLinestr, GM ) == 0 ) && tc_strcmp ( pcUOMValue, LITER ) == 0 )
													{
														double dDensite   = 0.0;

														tag_t tItemRevTag = NULLTAG;

														ITK ( BOM_line_ask_attribute_tag ( children[indx], item_revtag_attribute, &tItemRevTag ) );
														ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensite ) );

														valueVar = ( blqty * finalcost ) / ( 100 * dDensite ) ;
													}
													else if ( ( tc_strcmp ( unitTopLinestr, KG ) == 0 || tc_strcmp ( unitTopLinestr, GM ) == 0 ) && ( tc_strcmp ( pcUOMValue, KG ) == 0 || tc_strcmp ( pcUOMValue, GM ) == 0 ) )
													{
														valueVar = ( blqty / 100 ) * finalcost;
													}
													else if ( tc_strcmp ( unitTopLinestr, LITER ) == 0 && ( tc_strcmp ( pcUOMValue, KG ) == 0 || tc_strcmp ( pcUOMValue, GM ) == 0 ) )
													{
														char* pcVolPercent = NULL;
														ITK(BOM_line_ask_attribute_string(children[indx], bl_occ_o6_vol_percent_theoric_attribute, &pcVolPercent));

														double dDensite   = 0.0;

														tag_t tItemRevTag = NULLTAG;

														ITK ( BOM_line_ask_attribute_tag ( children[indx], item_revtag_attribute, &tItemRevTag ) );
														ITK ( AOM_ask_value_double ( tItemRevTag, MEAN_DENSITY, &dDensite ) );

														valueVar = dDensite * atof ( pcVolPercent ) * finalcost / 100;
														if ( pcVolPercent != NULL )
														{
															MEM_free ( pcVolPercent );
															pcVolPercent = NULL;
														}
													}
													else if ( tc_strcmp ( unitTopLinestr, LITER ) == 0 && tc_strcmp ( pcUOMValue, LITER ) == 0  )
													{
														char* pcVolPercent = NULL;

														ITK(BOM_line_ask_attribute_string(children[indx], bl_occ_o6_vol_percent_theoric_attribute, &pcVolPercent));

														valueVar = atof ( pcVolPercent ) * finalcost / 100;

														if ( pcVolPercent != NULL )
														{
															MEM_free ( pcVolPercent );
															pcVolPercent = NULL;
														}
													}
													if (valueVar > 0) {
														totcost = totcost + valueVar;
													}
													if ( pcUOMValue != NULL )
													{
														MEM_free ( pcUOMValue );
														pcUOMValue = NULL;
													}
												}
											}
										}
										MEM_free(tempValStr);
										tempValStr = NULL;
									}
								}
							}

							MEM_free(objtypestr);
							objtypestr = NULL;
						}
					}
				}

				if (totcost > 0) {

					*totalcost = totcost;
				}
			}


			MEM_free(unitTopLinestr);
			unitTopLinestr = NULL;

		}

		MEM_free(children);
		children = NULL;

	}

	return retcode;
}


///
/// Getter for a Double Property
/// @param value - Parameter Value
/// @param isNull - Returns true if the Parameter value is null
/// @return - Status. 0 if successful
///
int  O6_FleRootRevisionImpl::getO6_total_costBase( double &value, bool & /*isNull*/ ) const
{
    int retcode = ITK_ok;

    tag_t objrev = NULLTAG;
    std::string objtype = "";

    value =0;

    objtype = this->getO6_FleRootRevision()->getTypeName();
    objrev = this->getO6_FleRootRevision()->getTag();

    if(objrev != NULLTAG && objtype.length() > 0){

    	int n_bvrs =0;
    	tag_t* bvrs = NULL;
    	ITK(ITEM_rev_list_bom_view_revs(objrev,&n_bvrs, &bvrs));
		if (retcode == ITK_ok && bvrs != NULL) {
			if (n_bvrs == 1) {

				ITK(initialise());

				tag_t newwindow = NULLTAG;
				tag_t newbom_line = NULLTAG;
				ITK(BOM_create_window(&newwindow));
				if (retcode == ITK_ok && newwindow != NULLTAG ) {
					ITK(BOM_set_window_pack_all (newwindow, false));
					ITK(BOM_set_window_top_line(newwindow, NULLTAG, objrev, NULLTAG, &newbom_line));
					if (retcode == ITK_ok && newbom_line != NULLTAG ) {

						double totalcost = 0;
						ITK(traverse_BOM(newbom_line, objtype, &totalcost));
						if (totalcost > 0) {
							value = totalcost;
						}
					}
				}
				ITK(BOM_close_window(newwindow));

			} else if(n_bvrs > 1){
				TC_write_syslog("\nSEEDS Error : more than one BVRs found hence skipping runtime operation");
			}

			MEM_free(bvrs);
			bvrs = NULL;
		}
    }

    return retcode;
}

