/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tcinit/tcinit.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
#include <tc/folder.h>

#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <res/res_itk.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>


/*************************************************
* System Header Files
**************************************************/
#include <stdlib.h>


/*************************************************
/* MACROS
**************************************************/
#define DATE_FORMAT_STR			"%m%d%Y_%H%M%S"
#define IP_PUBLIC				"Public"
#define DATASET_TYPE			"HTML"


#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}	

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\


/*--------------------------Function Prototypes-------------------------------*/
static void print_usage(void);
int fve_create_vsem_favorite_folder(char * folder_name,char * folder_desc);
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null);
