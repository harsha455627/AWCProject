fve_import_parameter_values utility
-----------------------------
fve_import_parameter_values: This utility is intended for 
                         a) Bulk create / update of parameter value objects, 
			             b) Associating the value objects to the corresponding parameter usage objects,
			             c) Setting variant expressions between the usage and value objects
						   
USAGE:
    fve_import_parameter_values -u=<user id> -p=<password | password file> - g=<group>
                               -topNodeId=<Repository item Id> -revid=<Revision Id>
	                           -parmvalfile=<parameter value file>
			                   -varExpMapfile=<variant expression input file>
					
NOTE:   
        - This utility can be executed by any user with a Software Engineer or Module Supervisor Roles only
		- The utility requires a valid Repository item and rev id. It is expected that the ECCT Project Repository structure already has the
          desired parameter usages (either created through fve_import_parameters utility or instantiated from a dictionary).
		- This utility will create the parameter value objects under the desired parameter usages and sets the variant expressions between them.		  
		- The script will accept only .csv file formats for parameter value and variant expression files, with a "||" delimiter.
        - FVE_ccm_config.txt file is the config file needed for the execution of the utility. It is expected to specify the log file name and the path
		  in this file. The fve_import_parameter_values script will read the config file runtime, gets the log file name and the path where the log file needs
		  to be written to.	
		- The above config file needs to be in the same location from where the script will be executed.		  
						   

