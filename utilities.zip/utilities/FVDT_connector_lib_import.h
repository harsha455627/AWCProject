
/***************************************************************************/
/*                                                                         */
/* File Name   : FVDT_connector_lib_import.h                               */
/*                                                                         */                                       
/* Module      : FVDT_connector_lib_import                                 */
/*                                                                         */
/* Description : This file contains the Include Files, Function Prototypes */
/*               and Macro definitions of FVDT_connector_lib_import utility*/
/*                                                                         */
/***************************************************************************/
#include <tcinit/tcinit.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <tc/emh.h>
#include <sa/tcfile.h>
#include <pie/sample_inh.h>
#include <pie/sample_err.h>
#include <tccore/grm.h>
#include <tc/preferences.h>
#include <tccore/workspaceobject.h>
#include <ae/ae_types.h>
#include <ae/ae_errors.h>
#include <ae/dataset.h>
#include <tccore/grmtype.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <time.h>
#include <tc/envelope.h>
#include <tccore/item.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <FV_includes.h>



#define DESCRIPTION      "Object created by Import File"
#define  my_name  "FVDT_connector_lib_import"

/* Defines for log file names */
#define FVDT_GENERAL_LOG_FILE_NAME "FVDT_connector_import_summary"
#define FVDT_SUCCESS_LOG_FILE_NAME "FVDT_connector_import_success"
#define FVDT_FAILURE_LOG_FILE_NAME "FVDT_connector_import_failure"
#define FVDT_UNCHANGED_LOG_FILE_NAME "FVDT_connector_import_unchanged"
#define FVDT_REPLACEMENT_LOG_FILE_NAME "FVDT_connector_import_replacement"

#define DT_TMP_DIR_VAR "FVDT_UTIL_IMP_LOG_DIR"
#define FVDT_TIME_STR_LEN     30
#define FVDT_BUF_SIZE 1024
#define MAXINPUTLINELEN 5000
#define PASSWORDKEY     "PASSWORDKEY"

// OTB properties
#define item_idPROP             ("item_id")
#define item_revision_idPROP    ("item_revision_id")
#define object_namePROP         ("object_name")
#define object_descPROP         ("object_desc")
#define object_typePROP         ("object_type")
#define assigneePROP	("assignee")

// Custom properties
#define FVDTCHSSymNamePROP    ("FVDTCHSSymName")
#define FVDTCHSCavityNumPROP      ("FVDTCHSCavityNum")
#define FVDTCHSSubmergiblePROP      ("FVDTCHSSubmergible")
#define FVDTCHSRestrictedPROP      ("FVDTCHSRestricted")
#define FVDTCHSEvalRatingPROP      ("FVDTCHSEvalRating")
#define FVDTCHSMatForcePROP      ("FVDTCHSMatForce")
#define FVDTCHSReplacesPROP      ("FVDTCHSReplaces")
#define FVDTCHSServKitPartNumPROP      ("FVDTCHSServKitPartNum")
#define FVDTCHSSpecPROP      ("FVDTCHSSpec")
#define FVDTCHSReplacedByPROP      ("FVDTCHSReplacedBy")
#define FVDTCHSStatusPROP      ("FVDTCHSStatus")

// Custom Type
#define GDTConnectorEngineerTYPE       ("GDTConnectorEngineer")
#define GDTSystemReviewerTYPE		   ("GDTSystemReviewer")
#define FVE_VehProgramRevisionTYPE	   ("FVE_VehProgramRevision")

#define OBSOLETE_CONNECTOR "OBSOLETE"
#define IP_PUBLIC "Public"


char *FVDTMatConnAttrs[]  = {"","FVDTCHSSymName","FVDTCHSCavityNum","", "", "" , "FVDTCHSEvalRating","FVDTCHSMatForce",
                                  "FVDTCHSReplacedBy","FVDTCHSSpec"};



//#define ITK(x)                                                             \
//{                                                                          \
//    if ( ifail == ITK_ok )                                                  \
//    {                                                                      \
//        if ( (ifail = (x)) != ITK_ok )                                      \
//        {                                                                  \
//            dump_itk_errors ( ifail, my_name, __LINE__, __FILE__ );         \
//        }                                                                  \
//    }                                                                      \
//}

#define FVDT_FREE(p) {\
    if ( p != NULL ) {\
        MEM_free(p);\
        p = NULL;\
    }\
}

#define FVDT_FREE_ARRAY(p, count) {\
	int i = 0;\
   if ( p != NULL ) {\
        for(i = 0; i < count; i++) {\
            if(p[i] != NULL) {\
                MEM_free(p[i]);\
                p[i] = NULL;\
            }\
        }\
        MEM_free(p);\
        p = NULL;\
    }\
}

#define IMPORT_DATE_FORMAT_STR			"%m%d%Y_%H%M%S"

void  FVDT_String_to_StringArray  (char* line, char ***Attributes,  char * delim ,int *count );
int FVDT_find_item(char* item_id,	 tag_t** rev, int *count);
int FVDT_import_file ( char *str, char      *filename, tag_t     *file_tag);
int FVDT_file_exists(char * filename);
void get_time_stamp(char* format, char** timestamp);
int FVDT_create_log_files();
int FVDT_find_parent_veh_progs (tag_t subsysRev, tag_t** vehPrograms, int* vehProgramCount);
int FVDT_replace_connector_on_DT(tag_t dtRevision, tag_t oldConnector, char* newConnectorStr, tag_t* newDTRevision);
int FVDT_find_parent_subsystem_in_VP (tag_t vehPrg, tag_t dtRevision, tag_t* parentSubsystem);
int FVDT_Reminder_Mail2(tag_t connectorRev, char* connId, char* replaceBy,char *itemId, tag_t object);



/****************************************************************************/
/*                      G L O B A L    V A R I A B L E S                    */
/****************************************************************************/

int g_total_processed = 0;     /* Keeps count of the total number of items processed */
int g_no_of_successes = 0;     /* Keeps count of the number of items that are successfully imported  */
int g_no_of_failures  = 0;     /* Keeps count of the number of items for which import could not be done */
int g_no_of_unchanged  = 0;    /* Keeps count of the number of items that are not changed */
int g_no_of_repl_conn  = 0;    /* Keeps count of the number of replacement connectors */
int g_debug = 1;               /* Flag to indicate to extented debugging needs to be turned ON */

FILE *g_general_log   = NULL;  /* Pointer to the general log file */
FILE *g_success_log   = NULL;  /* Pointer to the log file containing item ids that were successfully processed */
FILE *g_failure_log   = NULL;  /* Pointer to the log file containing item ids that were unsuccessfully processed */
FILE *g_unchanged_log   = NULL;  /* Pointer to the log file containing item ids that remained unchanged */
FILE *g_replacement_log   = NULL;  /* Pointer to the log file containing item ids for which replacement connector is suggested */

