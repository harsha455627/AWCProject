/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

using System.Xml.Serialization;



namespace O6.Schemas.Customservicelibrary._2017_06.O6tanecustomservice 
{


[System.CodeDom.Compiler.GeneratedCodeAttribute("xsd2csharp", "1.0")]
[System.SerializableAttribute()]
[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlRootAttribute(Namespace="http://o6.com/Schemas/CustomServiceLibrary/2017-06/O6TaneCustomService", IsNullable=false)]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true)]
  public partial class TargetObjecs 
  {

         private string[] DisplaynamesField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("displaynames")]
     public string[] Displaynames
     { 
        get { return this.DisplaynamesField;}
        set { this.DisplaynamesField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getDisplaynames()
     { 
         if(this.DisplaynamesField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.DisplaynamesField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setDisplaynames(System.Collections.ArrayList val)
     { 
       this.DisplaynamesField = new string[val.Count];
       val.CopyTo(this.DisplaynamesField);
     }


     private string[] RealnamesField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("realnames")]
     public string[] Realnames
     { 
        get { return this.RealnamesField;}
        set { this.RealnamesField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getRealnames()
     { 
         if(this.RealnamesField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.RealnamesField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setRealnames(System.Collections.ArrayList val)
     { 
       this.RealnamesField = new string[val.Count];
       val.CopyTo(this.RealnamesField);
     }


     private string[] NrPatternField;
     ///<summary>XML Serialization Attributes</summary>
     [System.Xml.Serialization.XmlElementAttribute("nrPattern")]
     public string[] NrPattern
     { 
        get { return this.NrPatternField;}
        set { this.NrPatternField = value;}
     }

     ///<summary>To support access via generated code.</summary>
     public System.Collections.ArrayList getNrPattern()
     { 
         if(this.NrPatternField==null)
         { 
             return new System.Collections.ArrayList();
         }
             return new System.Collections.ArrayList(this.NrPatternField);
     } 
     ///<summary>Set the vaule of variable </summary> 
     public void setNrPattern(System.Collections.ArrayList val)
     { 
       this.NrPatternField = new string[val.Count];
       val.CopyTo(this.NrPatternField);
     }



    
    


  } // type
} // ns
            





