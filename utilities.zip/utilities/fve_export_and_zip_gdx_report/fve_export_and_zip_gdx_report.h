/******************************************************************************
 * Filename        :   fve_export_gdx_report.h
 * Description     :   Defines the macro used in fve_export_gdx_report
 * Module          :   fve_export_gdx_report.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date           Name                Description of Change
 * Aug-2015       Siddalingu R        Initial version
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FV_EXPORT_GDX_REPORT
#define FV_EXPORT_GDX_REPORT
#define XSD_DATASET_NAME	"GDX-004_XSD"

/*************************************************
* System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <fclasses/tc_string.h>
#include <time.h>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>
#include <FVDT_common.h>
#include <FV_prototypes.h>
#include "FVE_create_xml_headers.h"
#include "FV_includes.h"
#include "FV_gmrdb_reports.h"
/*************************************************
* Macros Definition
**************************************************/

/* Property Constant
****************************************************/
int FV_generate_gdx_xml_reportAndZip(char* gdx_rep_name, char* gdx_rep_type, char* rep_name_cmd, logical *flagValue,tag_t* rep_dataset);
int FV_create_zip_directory(char *dirFullPath);
int FV_generate_zip_dir_and_path(char* prefValue, char** sanitizedObjDirName,char** fileName, char** directoryPath);
int FV_execute_batch_file(const char *processFullPath, int argCnt, char *args[],logical setExecPriv, int *processReturnCode);
int FV_export_named_ref( tag_t tdataset, char *sNamedRefName,char *sExportDir, logical *expFile);
int FV_gdx_zip_directory(char* dirName, char* parentDirPath, tag_t* zipDatasetTag);
int FV_get_export_folder_tag(tag_t* expFolderTag);
static void print_usage(void);

#endif
