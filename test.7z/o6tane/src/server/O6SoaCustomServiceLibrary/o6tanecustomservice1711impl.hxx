/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_11_O6TANECUSTOMSERVICE_IMPL_HXX 
#define TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_11_O6TANECUSTOMSERVICE_IMPL_HXX


#include <o6tanecustomservice1711.hxx>
#include <o6tanecustomservice1706impl.hxx>

#include <CustomServiceLibrary_exports.h>

namespace O6
{
    namespace Soa
    {
        namespace CustomServiceLibrary
        {
            namespace _2017_11
            {
                class O6TaneCustomServiceImpl;
            }
        }
    }
}


class SOACUSTOMSERVICELIBRARY_API O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomServiceImpl : public O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomService

{
public:

    virtual Teamcenter::Soa::Server::ServiceData copyObjectAndCreateRelation ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj, const std::string targetItemtype, const std::string targetItemPattern, const std::string targetItemVersion );


};

#include <CustomServiceLibrary_undef.h>
#endif
