//
//  @file
//  This file contains the common implementation.
//

/**
 * Add common methods in this file.
 */
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <textsrv/textserver.h>

#include <string>

using namespace std;

/**
 * Function    :  GetLocaleTextValue
 * Description :  Function to get locale key value.
 *
 * Input       :
 * 		 pcKey		<I>  - char pointer
 * 		 sValue     <OF> - String output pointer
 *
 */
int GetLocaleTextValue ( char* pcKey, string &sValue )
{
	char* pcKeyValue = NULL;

	int retcode = ITK_ok;

	ITK ( TXTSRV_get_unsubstituted_text_resource ( pcKey, &pcKeyValue ) );

	sValue = string ( pcKeyValue );

	if ( pcKeyValue != NULL )
	{
		MEM_free ( pcKeyValue );
		pcKeyValue = NULL;
	}

	return retcode;
}
