/*************************************************
* Teamcenter Header Files
**************************************************/
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tcinit/tcinit.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
#include <tc/folder.h>
#include <stdio.h>
#include <tccore/aom.h>
#include <pom/pom/pom.h>
#include <textsrv/textserver.h>
#include <tccore/tctype.h>
#include <epm/epm.h>
#include <property/prop.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/project.h>
#include <ps/ps.h>
#include <sa/user.h>
#include <tc/tc.h>
#include <fclasses/tc_date.h>


/*************************************************
* System Header Files
**************************************************/
#include <stdlib.h>

/*************************************************
* Custom Header Files
**************************************************/
#include <FV_prototypes.h>
#include <FV_includes.h>
#include <FVE_user_common.h>
/*************************************************
/* MACROS
**************************************************/
//#define DATE_FORMAT_STR			"%m%d%Y_%H%M%S"
#define MAXSIZE 256
#define FV_DEBUG_TXT(X) if (FV_ask_debug() == TRUE) TC_write_syslog X;



#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}	

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.*/
/*#define FVE_FREE(p) \
{\
   if(p != NULL )\
   {\
      MEM_free(p);\
      p = NULL;\
   }\
}\*/

/*--------------------------Function Prototypes-------------------------------*/
static void print_usage(void);
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null);
void get_time_stamp(char* format, char** timestamp);
void push(tag_t, int);
void  pop(void);
int checkIfAlreadyExists(char* folderName,logical* isFolderPresentAndUnique);
extern int fve_create_vsem_gmrdb_folder_under_parent(tag_t parent_folder,char * folder_name,char * folder_type,tag_t *folder_tag);
//extern int FV_get_items_to_move(tag_t parent_folder, tag_t child_folder, tag_t *items_count, tag_t **item_tags, logical *has_items);
extern int FV_add_object_to_folder(tag_t object, tag_t folder, logical *is_added);
extern int FV_remove_object_from_folder(tag_t object, tag_t folder);
extern int FV_find_folder_under_parent(tag_t  parent_folder,char * folder_name,char * folder_type,tag_t *folder_tag);


