//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object O6_GenRMRevisionImpl
//

#include <O6TaneCustomLibrary/O6_GenRMRevisionImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>

using namespace o6tane;

//----------------------------------------------------------------------------------
// O6_GenRMRevisionImpl::O6_GenRMRevisionImpl(O6_GenRMRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
O6_GenRMRevisionImpl::O6_GenRMRevisionImpl( O6_GenRMRevision& busObj )
   : O6_GenRMRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// O6_GenRMRevisionImpl::~O6_GenRMRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
O6_GenRMRevisionImpl::~O6_GenRMRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// O6_GenRMRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int O6_GenRMRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = O6_GenRMRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


