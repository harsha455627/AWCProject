//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6_calculate_INCIs
 *
 */
#include <O6TaneCustomLibrary/O6_calculate_INCIs.hxx>
/* TC header files */
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <fclasses/tc_string.h>
#include <tc/preferences.h>
#include <base_utils/Mem.h>
#include <tccore/tctype.h>
#include <property/nr.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <tccore/grm.h>
#include <pom/pom/pom.h>
#include <cfm/cfm.h>
#include <sa/tcfile.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#include <ae/tool.h>
#include <fstream>
#include <ctime>
#include <itk/bmf.h>

/* Bom Attributes */
//#define bomAttr_bl_occ_o6_num_lot "bl_occ_o6_num_lot"
//#define bomAttr_bl_occ_o6_percent_reel "bl_occ_o6_percent_reel"
#define bomAttr_bl_occ_o6_percent_theoric "bl_occ_o6_percent_theoric"
#define bomAttr_bl_occ_o6_phase "bl_occ_o6_phase"
#define bomAttr_bl_occ_o6_impurete "bl_occ_o6_impurete"
#define bomAttr_bl_occ_o6_source_rm_list "bl_occ_o6_source_rms"

//#define bomAttr_bl_occ_o6_qte_pesee "bl_occ_o6_qte_pesee"
//#define bomAttr_bl_occ_o6_valeur "bl_occ_o6_valeur"
//#define bom_attr_bl_occ_o6_valeur_percent "bl_occ_o6_valeur_percent"

/*custom item*/
#define O6_FLE "O6_Fle"

/* Define properties */
#define ITEM_ID "item_id"
#define ITEM_REVISION_ID "item_revision_id"
#define OBJECT_NAME "object_name"
#define OBJECT_DESC "object_desc"
#define UOM_TAG "uom_tag"
#define OBJECT_TYPE "object_type"
#define O6_CLONE "o6_clone"
#define REVISION "revision"
#define PART "Part"
#define ATTRIBUTE "Attribute"
#define REFERENCE "Reference"
#define STRING "String"
#define BOOLEAN "Logical"
#define DATE "Date"
#define DOUBLE "Double"
#define TYPED_REFERENCE "Typed_Reference"
#define PREFIX "o6"
#define REL_STATUS "o6_cpd_status"
#define STRUCT_REVISIONS "structure_revisions"
#define REL_STATUS_LIST "release_status_list"
#define O6_DRG_TYPE "o6_drg_typ"
#define O6_IMPURETE "o6_impurete"
#define O6_ALLERGENE "o6_allergene"
#define O6_SIMULATION "o6_simulation"
#define O6_APPLICATION_TYPE "o6_application_typ"
#define O6_APLLICATION_ZONE "o6_application_zone"
#define O6_POPULATION_CIBLE "o6_cible_population"
#define O6_PISTE "o6_piste"
#define O6_VERSION "o6_version"
#define FRENCH_RINCE_VALUE "Rinc�"
#define ENGLISH_RINSE_VALUE "Rinsed"
#define TRUE_VALUE "True"
#define FALSE_VALUE "False"

#define REL_STATUS_OKRD "O6_OKRD"
#define REL_STATUS_DISUSED "O6_Disused"
#define REL_STATUS_DISABLED "O6_Disabled"

#define SUP_RM_REV "O6_SupRMRevision"
#define GEN_RM_REV "O6_GenRMRevision"
#define RM_BATCH_REV "O6_RMBatchRevision"
#define FLE_BATCH_REV "O6_FleBatchRevision"
#define FLE "O6_Fle"

/* Relation names */
#define GEN_TO_SUP "O6_GenToSupplRM"
#define RM_BATCH_TO_GEN "O6_BatchDefRel"
#define DRGPF_TO_FLE "O6_RegulatedRel"
#define TC_ATTACHES "TC_Attaches"
#define QUALI_QUANTI_REL "O6_QQRel"
#define REGULATED_REL "O6_RegulatedRel"
#define BRIEF_TO_FLE_REL "O6_BriefToFleRel"

#define COPY_AS_REF "CopyAsRef"
#define PRIMARY "Prim"
#define SECONDARY "Sec"

/*BO Types*/
#define INGLIST "O6_IngList"
#define INGList_REVISION "O6_IngListRevision"

/* Constants */

/* SourceToTarget � Create Relation from source to Target */
#define S2T "SourceToTarget"

/* SourceRevToTargetRev � Create relation from Source Revision to Target Revision */
#define SR2TR "SourceRevToTargetRev"

/* SourceRevToTarget � Create relation from Source Revision to Target */
#define SR2T "SourceRevToTarget"

/* SourceToTargetRev � Create relation from Source To Target Revision */
#define S2TR "SourceToTargetRev"

/* TargetToSource � create relation from target to source */
#define T2S "TargetToSource"

/* TargetRevToSourceRev � Create relation from target revision to source revision */
#define TR2SR "TargetRevToSourceRev"

/*	TargetRevToSource � Create relation from Target Revision to Source */
#define TR2S "TargetRevToSource"

/*	TargetToSourceRev � create relation from target to source revision */
#define T2SR "TargetToSourceRev"

/*NoCopyBOM - Do not copy BOM */
#define NO_COPY_BOM "NoCopyBOM"

/*CopyBOMUsingGen - Copy BOM using Generic RM Item */
#define COPY_BOM_USING_GEN "CopyBOMUsingGen"

/*CopyBOMUsingSup - Copy BOM using Supplier RM Item */
#define COPY_BOM_USING_SUP "CopyBomUsingSup"

/*SPECIFIQUE LOV VALUE*/
#define CHINE_VALUE "SPECIFIQUE"

/*International LOV Value*/
#define INTERNATIONAL "International"

/*Text Dataset Type*/
#define TEXT_DATASET_TYPE "Text"

/*Prefix for List of Ingredient Item Type object_name*/
#define LISTE_NAME_PREFIX "INCI-List-"

/*Custom textserver messages*/
#define INCI_BOM_REPORT_HEADER "o6_seeds_919705"
#define TEMPORARY_SIM_HEADER "o6_seeds_919706"
#define PURE_INCI_HEADER "o6_seeds_919707"
#define IMPURE_INCI_HEADER "o6_seeds_919704"
#define WARNING_HEADER "o6_seeds_919708"
#define NO_ING_CHILD_MESSAGE "o6_seeds_919709"
#define INVALID_MP_GEN_MESSAGE "o6_seeds_919710"
#define NO_REG_DOSSY_MESSAGE "o6_seeds_919711"
#define NO_FORMULA_CHILD_MESSAGE "o6_seeds_919712"
#define COPIED_INCI_HEADER "o6_seeds_919701"
#define SKIPPED_INCI_HEADER "o6_seeds_919703"
#define QQ_INCI_BOM_REPORT_HEADER "o6_seeds_919702"
#define COLON ":"
#define PERCENTAGE_SYMBOL "%"
#define NEW_LINE "\n"
#define OBJ_STRING "object_string"
/*NR Pattern*/
#define FLE_PATTERN "\"LOC\"nnnnnn"

/*NR Name*/
#define FLE_NR "O6_NR_Fle"

/*Hiphen*/
#define HIPHEN "-"

/*V Symbol*/
#define V_SYMBOL "F"

/*UnderScore Symbol*/
#define UNDERSCORE "_"

/*Comma Delimiter*/
#define COMMA_SYMBOL ","

/*CSV File Extension*/
#define CSV_FILE_EXTENSION ".csv"

/*Notepad Tool*/
#define NOTEPAD "Notepad"

/*Text Dataset format*/
#define TEXT_REFERENCE "TEXT_REF"

/*Intial Dataset Revision*/
#define INITIAL_DATASET_REV "A"

/* Custom Error */
#define STRING_ATTR_VALUE_SET_ERROR ( SEEDS_CUSTOM_ERROR_BASE + 1 )

/* BOM attributes initialize */
static int seqno_attribute;

/**
 * Change - Do not copy quantity & valuer attribute while cloning.
 */
//static int quantiy_attribute;
static int item_id_attribute;
static int item_rev_name_attribute;
static int item_revtag_attribute;
static int uom_tag_attribute;
static int iBOMLineSeqNo;
//static int bl_occ_o6_num_lot_attribute;
//static int bl_occ_o6_percent_reel_attribute;
static int bl_occ_o6_percent_theoric_attribute;
static int bl_occ_o6_phase_attribute;
static int iBOMLineGenRMListID;
//static int bl_occ_o6_qte_pesee_attribute;

static int iBOMLineItemAttrID;
static int iBOMLineImpureteAttrID;
static int iBOMLineQuantityAttrID;
static int bl_occ_attribute;

struct INCIInfo
{
	bool bIsINCImpure        = false;
	char* pcRMName           = NULL;
	char* pcOriginalRM       = NULL;
	char* pcDRGType          = NULL;
	char* pcDRGStatus        = NULL;
	char* pcINCName          = NULL;

	double dTotalPercentage  = 0.0;
	double dRMPercentage     = 0.0;
	double dINCIPercentage   = 0.0;

	struct INCIInfo *next    = NULL;
};


/**
 * Function    :  getLatestRevisionTag_on_post
 * Description :  Find latest revision.
 * Input       :
 * 		 itemTag	<I>	 - Item Tag
 * 		 itemRevTag <O>	 - Latest revision tag
 *
 */
int getLatestRevisionTag_on_post(tag_t itemTag, tag_t *itemRevTag) {
	int retcode = ITK_ok;

	ITK(ITEM_ask_latest_rev(itemTag,itemRevTag));

	return retcode;
}
/**
 * Function    :  initialise_attribute
 * Description :  Initialize BOM attributes.
 * Input       :
 */
static int initialise_attribute (char *name,  int *attribute)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (name, attribute));

    return retcode;
  }

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 * Input       :
 */
static int initialise (void)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute(bomAttr_occUoM, &uom_tag_attribute));
    ITK(BOM_line_look_up_attribute (bomAttr_lineItemRevTag, &item_revtag_attribute));
    ITK ( BOM_line_look_up_attribute ( bomAttr_occSeqNo, &iBOMLineSeqNo ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemId, &item_id_attribute ) );
	ITK ( BOM_line_look_up_attribute ( bomAttr_itemRevName, &item_rev_name_attribute ) );

    /* these tokens come from bom_attr.h */
    ITK ( initialise_attribute ( bomAttr_occSeqNo, &seqno_attribute ) );
    ITK ( initialise_attribute ( bomAttr_lineItemTag, &iBOMLineItemAttrID ) );
    ITK ( initialise_attribute ( bomAttr_realOccurrence, &bl_occ_attribute ) );
	/**
	 * Change - Do not copy quantity & valuer attribute while cloning.
	 */
    //ITK(initialise_attribute (bomAttr_occQty, &quantiy_attribute));

    /* Custom Attributes */
    //ITK(initialise_attribute (bomAttr_bl_occ_o6_num_lot, &bl_occ_o6_num_lot_attribute));
    //ITK(initialise_attribute (bomAttr_bl_occ_o6_percent_reel, &bl_occ_o6_percent_reel_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_percent_theoric, &bl_occ_o6_percent_theoric_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_phase, &bl_occ_o6_phase_attribute));
    ITK(initialise_attribute (bomAttr_bl_occ_o6_impurete, &iBOMLineImpureteAttrID));
	ITK ( initialise_attribute ( bomAttr_bl_occ_o6_source_rm_list, &iBOMLineGenRMListID ) );
    //ITK(initialise_attribute (bomAttr_bl_occ_o6_qte_pesee, &bl_occ_o6_qte_pesee_attribute));

	/**
	 * Change - Do not copy quantity & valuer attribute while cloning.
	 */
    //ITK(initialise_attribute (bomAttr_bl_occ_o6_valeur, &bl_occ_o6_valeur_attribute));
    //ITK(initialise_attribute (bom_attr_bl_occ_o6_valeur_percent, &bl_occ_o6_valeur_percent_attribute));



    return retcode;
  }
/**
 * Function    :  GetLocaleTextValue
 * Description :  Function to get locale key value.
 *
 * Input       :
 * 		 pcKey		<I>  - char pointer
 * 		 sValue     <OF> - String output pointer
 *
 */
int GetLocaleKeyValue ( char* pcKey, string &sValue )
{
	char* pcKeyValue = NULL;

	int retcode = ITK_ok;

	ITK ( TXTSRV_get_unsubstituted_text_resource ( pcKey, &pcKeyValue ) );

	sValue = string ( pcKeyValue );

	if ( pcKeyValue != NULL )
	{
		MEM_free ( pcKeyValue );
		pcKeyValue = NULL;
	}

	return retcode;
}
/**
 * Function    :  create_bvr
 * Description :  Create new BOM View and BOM View Revision
 * Input       :
 * 	targetitem <I>	- Item revision
 * 	bvrtag	   <O>	- Bom View Revision
 */
int create_bvr(tag_t targetitem, tag_t itemrev) {
	int retcode = ITK_ok;
	tag_t bomview = NULLTAG;

	ITK(PS_create_bom_view(NULLTAG, "", "", targetitem, &bomview ));
	if (retcode == ITK_ok && bomview != NULLTAG ) {

		ITK(AOM_save_without_extensions( bomview ));
		ITK(AOM_save_without_extensions( targetitem ));
		ITK(AOM_unlock( targetitem ));

		tag_t localbvr = NULLTAG;
		ITK(PS_create_bvr( bomview, "", "", false, itemrev, &localbvr));
		if (retcode == ITK_ok && localbvr != NULLTAG ) {
			ITK(AOM_save_without_extensions( localbvr ));
			ITK(AOM_save_without_extensions( itemrev ));
			ITK(AOM_unlock( itemrev ));
		}
	}

	return retcode;
}

/**
 * Function    :  GetDrgItemRev
 * Description :  Function to create a dataset, attach it to Item Rev and Import Named reference file to it.
 * Input       :
 * 		 tDRGItemRevs		     <I>     - Item Rev Tag Array.
 * 		 iDRGMPCount             <I>     - Item REv Count.
 * 		 tReqdDRGItemRev         <OF>    - Pointer to the Item Rev Found.
 * 		 bIsPFChine              <I>     - Boolean Value indicating IsPFChine value.
 */
int GetDrgItemRev ( tag_t* tDRGItemRevs, int iDRGMPCount, tag_t &tReqdDRGItemRev, string sTypeDeDrg, logical &isDRGItemUnreleased )
{
	int retcode         = ITK_ok;

	int iDRGItemCount   = 0;

	char* pcMPTypeDeDrg = NULL;

	for ( int iInx = 0; iInx < iDRGMPCount; iInx++ )
	{
		ITK ( AOM_ask_value_string ( tDRGItemRevs[iInx], O6_DRG_TYPE, &pcMPTypeDeDrg ) );

		if ( tc_strcmp ( pcMPTypeDeDrg, sTypeDeDrg.c_str() ) == 0 )
		{
			iDRGItemCount++;
		}
	}
	/*if corresponding DRG Absent check for International DRG*/
	if ( iDRGItemCount == 0 )
	{
		for ( int iInx = 0; iInx < iDRGMPCount; iInx++ )
		{
			ITK ( AOM_ask_value_string ( tDRGItemRevs[iInx], O6_DRG_TYPE, &pcMPTypeDeDrg ) );

			if ( tc_strcmp ( pcMPTypeDeDrg, INTERNATIONAL ) == 0 )
			{
				iDRGItemCount++;
			}
		}
	}
	if ( pcMPTypeDeDrg != NULL )
	{
		MEM_free ( pcMPTypeDeDrg );
		pcMPTypeDeDrg = NULL;
	}
	if ( iDRGItemCount == 1 )
	{
		char* pcTypeDeDrg = NULL;

		for ( int iInx = 0; iInx < iDRGMPCount; iInx++ )
		{
			ITK ( AOM_ask_value_string ( tDRGItemRevs[iInx], O6_DRG_TYPE, &pcTypeDeDrg ) );

			if ( tc_strcmp ( pcTypeDeDrg, sTypeDeDrg.c_str() ) == 0 )
			{
				tReqdDRGItemRev = tDRGItemRevs[iInx];
				break;
			}
		}

		if ( tReqdDRGItemRev == NULLTAG )
		{
			for ( int iInx = 0; iInx < iDRGMPCount; iInx++ )
			{
				ITK ( AOM_ask_value_string ( tDRGItemRevs[iInx], O6_DRG_TYPE, &pcTypeDeDrg ) );

				if ( tc_strcmp ( pcTypeDeDrg, INTERNATIONAL ) == 0 )
				{
					tReqdDRGItemRev = tDRGItemRevs[iInx];
					break;
				}
			}
		}

		if ( pcTypeDeDrg != NULL )
		{
			MEM_free ( pcTypeDeDrg );
			pcTypeDeDrg = NULL;
		}

		if ( tReqdDRGItemRev != NULLTAG )
		{
			int iRelStatusCount = 0;

			tag_t* tRelStatuses = NULL;

			ITK ( AOM_ask_value_tags ( tReqdDRGItemRev, REL_STATUS_LIST, &iRelStatusCount, &tRelStatuses ) );

			if ( iRelStatusCount != 0 && tRelStatuses != NULL )
			{
				isDRGItemUnreleased = FALSE;
			}
			else
			{
				isDRGItemUnreleased = TRUE;
			}
			if ( tRelStatuses != NULL )
			{
				MEM_free ( tRelStatuses );
				tRelStatuses = NULL;
			}
		}
	}
	if ( iDRGItemCount > 1  )
	{
		TC_write_syslog ( "SEED ERRORS: Multiple Regulatory Dossiers of same type found" );
	}
	/*else if ( iDRGItemCount > 1 )
	{
		char* pcMPGenID   = NULL;

		ITK ( AOM_ask_value_string ( tItemRevTag, "item_id",&pcMPGenID ) );
		write logic for more than one dossier of same type present use case
		sDRGErrorMessage = "ERROR doing Simulation. More than one Dossier MP Item type under MP Generique item " + string ( pcMPGenID );
		if ( pcMPGenID != NULL )
		{
			MEM_free ( pcMPGenID );
			pcMPGenID = NULL;
		}
	}
	else
	{
		char* pcMPGenID   = NULL;

		ITK ( AOM_ask_value_string ( tItemRevTag, "item_id", &pcMPGenID ) );

		write logic for no dossier item present in log file
		sDRGErrorMessage = "Error doing simulation. No matching Dossier MP Item type present under MP Generique item " + string ( pcMPGenID );

		if ( pcMPGenID != NULL )
		{
			MEM_free ( pcMPGenID );
			pcMPGenID = NULL;
		}
	}*/

	if ( pcMPTypeDeDrg != NULL )
	{
		MEM_free ( pcMPTypeDeDrg );
		pcMPTypeDeDrg = NULL;
	}
	return retcode;
}

/**
 * Function    :  PopulateDataToStructure_on_post
 * Description :  Function to populate INC data to Structure for INCI calculation.
 * Input       :
 * 		 tINCItemTag		     <I>     - Item Tag.
 * 		 fINCPercentage          <I>     - Percentage Value.
 * 		 tItemRevTag             <I>     - Item Rev Tag.
 * 		 fPercentage             <I>     - Percentage value.
 * 		 tReqdDRGItemRev         <I>     - Item Rev Tag.
 * 		 pcPercentageQty         <I>     - char array containing Percentage value.
 * 		 pcINCImpurete           <I>     - char array containing Impurity value.
 * 		 head_ptr                <OF>    - Pointer pointing to the first node of the linked list.
 */
int PopulateDataToStructure_on_post ( struct INCIInfo **head_ptr, tag_t tIncItemRevTag, tag_t tItemRevTag, double fPercentage, tag_t tReqdDRGItemRev, char* pcPercentageQty, bool bIsINCImpure )
{
	char* pcRMName              = NULL;
	char* pcRMItemID            = NULL;
	char* pcTypeDeDrg           = NULL;
	char* pcReleaseStatus       = NULL;
	char* pcINCRevName          = NULL;

	int retcode                 = ITK_ok;

	struct INCIInfo *temp_node  = NULL;
	struct INCIInfo *last       = *head_ptr;

	ITK ( AOM_ask_value_string ( tItemRevTag, ITEM_ID, &pcRMItemID ) );

	ITK ( AOM_ask_value_string ( tItemRevTag, OBJECT_NAME, &pcRMName ) );

	ITK ( AOM_ask_value_string ( tReqdDRGItemRev, O6_DRG_TYPE, &pcTypeDeDrg ) );

	ITK ( AOM_ask_value_string ( tReqdDRGItemRev, REL_STATUS, &pcReleaseStatus ) );

	ITK ( AOM_ask_value_string ( tIncItemRevTag, OBJECT_NAME, &pcINCRevName ) );

	if ( retcode == ITK_ok )
	{
		temp_node = ( struct INCIInfo* ) MEM_alloc ( sizeof ( struct INCIInfo ) );

		temp_node->pcRMName  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcRMName ) + 1 ) );
		tc_strcpy ( temp_node->pcRMName, pcRMName );

		if ( pcRMName != NULL )
		{
			MEM_free ( pcRMName );
			pcRMName = NULL;
		}

		temp_node->pcOriginalRM  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcRMItemID ) + 1 ) );
		tc_strcpy ( temp_node->pcOriginalRM, pcRMItemID );

		if ( pcRMItemID != NULL )
		{
			MEM_free ( pcRMItemID );
			pcRMItemID = NULL;
		}

		temp_node->pcDRGType  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcTypeDeDrg ) + 1 ) );
		tc_strcpy ( temp_node->pcDRGType, pcTypeDeDrg );

		if ( pcTypeDeDrg != NULL )
		{
			MEM_free ( pcTypeDeDrg );
			pcTypeDeDrg = NULL;
		}

		temp_node->pcDRGStatus  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcReleaseStatus ) + 1 ) );
		tc_strcpy ( temp_node->pcDRGStatus, pcReleaseStatus );

		if ( pcReleaseStatus != NULL )
		{
			MEM_free ( pcReleaseStatus );
			pcReleaseStatus = NULL;
		}

		temp_node->pcINCName  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcINCRevName ) + 1 ) );
		tc_strcpy ( temp_node->pcINCName, pcINCRevName );

		if ( pcINCRevName != NULL )
		{
			MEM_free ( pcINCRevName );
			pcINCRevName = NULL;
		}

		temp_node->bIsINCImpure = bIsINCImpure;
		temp_node->dTotalPercentage = atof ( pcPercentageQty ) * fPercentage/100;
		temp_node->dRMPercentage    = fPercentage;
		temp_node->dINCIPercentage  = atof ( pcPercentageQty );

		temp_node->next = NULL;

		if ( *head_ptr == NULL )
		{
			*head_ptr = temp_node;
		}
		else
		{
			bool bIsINCPresentInList = false;

			struct INCIInfo *current = *head_ptr;

			while ( current != NULL )
			{
				if ( ( tc_strcmp ( current->pcOriginalRM, temp_node->pcOriginalRM ) == 0 ) && ( current->bIsINCImpure == temp_node->bIsINCImpure ) ) // Keeping Pure or Impure INCIs together in the linked list for easy evaluation and writing in log file
				{
					bIsINCPresentInList = true;

					temp_node->pcOriginalRM = NULL;
					temp_node->pcRMName = NULL;
					temp_node->dRMPercentage = 0.0;
					temp_node->pcDRGType = NULL;
					temp_node->pcDRGStatus = NULL;

					temp_node->next = current->next;
					current->next = temp_node;
					break;
				}
				current = current->next;
			}

			if ( bIsINCPresentInList == false ) // If INCI not present in linked list already, adding new node at the last
			{
				while ( last->next != NULL )
				{
					last = last->next;
				}
				last->next = temp_node;
			}
		}
	}
	return retcode;
}

/**
 * Function    :  PopulateDataToStructure_on_post
 * Description :  Function to Populate Skipped INCI's data in Quali Quanti.
 *
 * Input       :
 *
 *      tIngListChildLine      <I>     - BOMLine Tag
 *      sIsAllergenValue       <I>     - String Value
 *      pcApplType             <I>     - Char Pointer
 *      sINCImpurete           <I>     - String
 *		head_ptr               <OF>    - Pointer pointing to the first node of the linked list.
 *
 */
int PopulateDataToStructure_on_post ( struct SkippedINCIInfo **head_ptr, tag_t tIngListChildLine, string sIsAllergenValue, char* pcApplType, string sINCImpurete )
{
	int retcode = ITK_ok;

	struct SkippedINCIInfo *temp_node = NULL;
	struct SkippedINCIInfo *last      = *head_ptr;

	if ( retcode == ITK_ok )
	{
		char* pcINCPercent = NULL;

		ITK ( BOM_line_ask_attribute_string ( tIngListChildLine, bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

		if ( retcode == ITK_ok )
		{
			char* pcINCItemID = NULL;
			char* pcINCName   = NULL;

			ITK ( BOM_line_ask_attribute_string ( tIngListChildLine, item_id_attribute, &pcINCItemID ) );
			ITK ( BOM_line_ask_attribute_string ( tIngListChildLine, item_rev_name_attribute, &pcINCName ) );

			if ( retcode == ITK_ok )
			{
				temp_node = ( struct SkippedINCIInfo* ) MEM_alloc ( sizeof ( struct SkippedINCIInfo ) );

				temp_node->pcINCIId  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcINCItemID ) + 1 ) );
				tc_strcpy ( temp_node->pcINCIId, pcINCItemID );

				if ( pcINCItemID != NULL )
				{
					MEM_free ( pcINCItemID );
					pcINCItemID = NULL;
				}

				temp_node->pcINCName  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcINCName ) + 1 ) );
				tc_strcpy ( temp_node->pcINCName, pcINCName );

				if ( pcINCName != NULL )
				{
					MEM_free ( pcINCName );
					pcINCName = NULL;
				}

				temp_node->pcImpurete  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( sINCImpurete.c_str() ) + 1 ) );
				tc_strcpy ( temp_node->pcImpurete, sINCImpurete.c_str() );

				temp_node->pcApplType  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( pcApplType ) + 1 ) );
				tc_strcpy ( temp_node->pcApplType, pcApplType );

				temp_node->pcAllergenValue  = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( sIsAllergenValue.c_str() ) + 1 ) );
				tc_strcpy ( temp_node->pcAllergenValue, sIsAllergenValue.c_str() );

				temp_node->dTotalPercentage = atof( pcINCPercent );

				temp_node->next = NULL;

				if ( *head_ptr == NULL )
				{
					*head_ptr = temp_node;
				}
				else
				{
					while ( last->next != NULL )
					{
						last = last->next;
					}
					last->next = temp_node;
				}
			}
		}
		if ( pcINCPercent != NULL )
		{
			MEM_free ( pcINCPercent );
			pcINCPercent = NULL;
		}
	}
	return retcode;
}

/**
 * Function    :  FetchAndAttachIngredients
 * Description :  Function to Fetch INCI's, Attach them to DRG PF's Liste d Ingredient and calculate and update Percentage and Impurete value.
 * Input       :
 * 		 tItemRevTag		     <I>     - Item Tag
 * 		 fPercentage             <I>     - Percentage value
 * 		 tRegRuleTypeTag         <I>     - Relation Type Tag
 * 		 tIngBOMWindowTag        <I>     - BOMWindow Tag
 * 		 tIngBOMTopLine          <I>     - BOMWindow Top Line
 */
int FetchAndAttachIngredients ( tag_t tItemRevTag, double fPercentage, tag_t tRegRuleTypeTag, tag_t tIngBOMWindowTag, tag_t tIngBOMTopLine, string sTypeDeDrg, struct INCIInfo **head_ptr, vector<string> &vInvalidMPGenItems, vector<string> &vChildlessMPGenItems, logical &isDRGItemUnreleased, string &sDRGBomError )
{
	int retcode               = ITK_ok;
	int iDRGMPCount           = 0;

	tag_t tReqdDRGItemRev     = NULLTAG;

	tag_t* tDRGItemRevs       = NULL;
	char* objectstringOfGenRM = NULL;
	ITK ( GRM_list_primary_objects_only ( tItemRevTag, tRegRuleTypeTag, &iDRGMPCount, &tDRGItemRevs ) );
	ITK(AOM_ask_value_string(tItemRevTag,OBJ_STRING,&objectstringOfGenRM));

	if ( iDRGMPCount > 0 )
	{
		ITK ( GetDrgItemRev ( tDRGItemRevs, iDRGMPCount, tReqdDRGItemRev, sTypeDeDrg, isDRGItemUnreleased ) ); // Getting the corresponding DRG MP Item based on Geographique value of DRG PF Item

		if ( retcode == ITK_ok && tReqdDRGItemRev != NULLTAG )
		{
			int retcode               = ITK_ok;
			int iTargetChildCount     = 0;
			int iIngrdntsCount        = 0;
			int iIncCount             = 0;
			int iDRGBomCount          = 0;

			tag_t tBOMWindowTag       = NULLTAG;
			tag_t tTopLine            = NULLTAG;

			tag_t* TargetChildren     = NULL;
			tag_t* tIngrdntsLines     = NULL;
			tag_t* tIncLines          = NULL;
			tag_t* tDRGBomTags        = NULL;

			ITK ( AOM_ask_value_tags ( tReqdDRGItemRev, STRUCT_REVISIONS, &iDRGBomCount, &tDRGBomTags ) );

			if ( iDRGBomCount != 0 )
			{
				ITK ( BOM_create_window ( &tBOMWindowTag ) );
				ITK ( BOM_set_window_pack_all ( tBOMWindowTag, false ) );
				ITK ( BOM_set_window_top_line ( tBOMWindowTag, NULLTAG, tReqdDRGItemRev, NULLTAG, &tTopLine ) );//set DRG MP as topline

				ITK ( BOM_line_ask_all_child_lines ( tTopLine, &iIngrdntsCount, &tIngrdntsLines ) );

				if ( iIngrdntsCount != 0 )
				{
					ITK ( BOM_line_ask_all_child_lines ( tIngrdntsLines[0], &iIncCount, &tIncLines ) );

					if ( tIngrdntsLines != NULL )
					{
						MEM_free ( tIngrdntsLines );
						tIngrdntsLines = NULL;
					}

					if ( iIncCount != 0 )
					{
						/*To check children under PF Items Liste d ingredients*/
						ITK ( BOM_line_ask_all_child_lines ( tIngBOMTopLine, &iTargetChildCount, &TargetChildren ) );

						if ( tIncLines > 0 )
						{
							if ( iTargetChildCount == 0 )
							{
								for ( int iInx = 0; iInx < iIncCount; iInx++ )
								{
									bool bIsINCImpure = false;

									double fINCPercentage = 0.0;

									tag_t tINCItemTag     = NULLTAG;
									tag_t tIncItemRevTag  = NULLTAG;
									tag_t tNewLineTag     = NULLTAG;
									tag_t tOccurenceTag   = NULLTAG;
									char* GenRMListToSet  = NULL;
									char* pcPercentageQty = NULL;
									char* pcINCImpurete   = NULL;

									ITK ( BOM_line_ask_attribute_tag ( tIncLines[iInx], iBOMLineItemAttrID, &tINCItemTag ) );
									ITK ( BOM_line_ask_attribute_tag ( tIncLines[iInx], item_revtag_attribute, &tIncItemRevTag ) );

									ITK ( BOM_line_add ( tIngBOMTopLine, tINCItemTag, tIncItemRevTag, NULLTAG, &tNewLineTag ) );//New inci getting added to deg PF ing list

									if ( retcode == ITK_ok && tNewLineTag != NULLTAG )
									{

										ITK ( BOM_save_window ( tIngBOMWindowTag ) );

										ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineQuantityAttrID, &pcPercentageQty ) );
										fINCPercentage = ( atof ( pcPercentageQty ) ) * fPercentage / 100;

										ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineQuantityAttrID, std::to_string ( fINCPercentage ).c_str() ) );
										GenRMListToSet = (char*)MEM_alloc((int)(( tc_strlen(objectstringOfGenRM)+tc_strlen(std::to_string ( fINCPercentage ).c_str())+ 5) * sizeof(char)));
										tc_strcpy(GenRMListToSet,objectstringOfGenRM);
										tc_strcat(GenRMListToSet,COLON);
										tc_strcat(GenRMListToSet,std::to_string ( fINCPercentage ).c_str());
										tc_strcat(GenRMListToSet,PERCENTAGE_SYMBOL);

										ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineGenRMListID,GenRMListToSet));
										ITK ( BOM_save_window ( tIngBOMWindowTag ) );
										MEM_free(GenRMListToSet);
										ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineImpureteAttrID, &pcINCImpurete ) );
										ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineImpureteAttrID, pcINCImpurete ) );

										ITK ( BOM_save_window ( tIngBOMWindowTag ) );
									}

									ITK ( BOM_line_ask_attribute_tag ( tNewLineTag, bl_occ_attribute, &tOccurenceTag ) );

									ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsINCImpure ) );

									ITK ( PopulateDataToStructure_on_post ( head_ptr, tIncItemRevTag, tItemRevTag, fPercentage, tReqdDRGItemRev, pcPercentageQty, bIsINCImpure ) );

									if ( pcPercentageQty != NULL )
									{
										MEM_free ( pcPercentageQty );
									}
									if ( pcINCImpurete != NULL )
									{
										MEM_free ( pcINCImpurete );
									}
								}
							}
							else
							{
								for ( int iInx = 0; iInx < iIncCount; iInx++ )
								{
									bool bIsINCItemPresent = false;

									tag_t tINCItemTag = NULLTAG;

									ITK ( BOM_line_ask_attribute_tag ( tIncLines[iInx], iBOMLineItemAttrID, &tINCItemTag ) );

									for ( int jJnx = 0; jJnx < iTargetChildCount; jJnx++ )
									{
										tag_t  tTargetINCItemTag = NULLTAG;

										ITK ( BOM_line_ask_attribute_tag ( TargetChildren[jJnx], iBOMLineItemAttrID, &tTargetINCItemTag ) );

										if ( tINCItemTag == tTargetINCItemTag )
										{
											char* pcINCImpurete    = NULL;
											char* pcTargetImpurete = NULL;

											tag_t tIncItemRevTag = NULLTAG;

											bIsINCItemPresent = true;

											ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineImpureteAttrID, &pcINCImpurete ) );
											ITK ( BOM_line_ask_attribute_tag ( tIncLines[iInx], item_revtag_attribute, &tIncItemRevTag ) );
											ITK ( BOM_line_ask_attribute_string ( TargetChildren[jJnx], iBOMLineImpureteAttrID, &pcTargetImpurete ) );

											if ( tc_strcmp ( pcINCImpurete, pcTargetImpurete ) == 0 )
											{
												bool bIsINCImpure           = false;
												tag_t tOccurenceTag         = NULLTAG;

												char* pcINCPercentageQty    = NULL;
												char* pcTargetPercentageQty = NULL;
												char* GenRMListToSet		=NULL;
												char* GenRMListbeforeSet		=NULL;
												double fINCPercentage = 0.0;
												double fINCPercentageBefAdd = 0.0;
												//int count =0;
												ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineQuantityAttrID, &pcINCPercentageQty ) );

												ITK ( BOM_line_ask_attribute_string ( TargetChildren[jJnx], iBOMLineQuantityAttrID, &pcTargetPercentageQty ) );
												fINCPercentageBefAdd =( ( atof ( pcINCPercentageQty ) ) * fPercentage / 100 );

												fINCPercentage = fINCPercentageBefAdd + ( atof ( pcTargetPercentageQty ) );

												ITK ( BOM_line_set_attribute_string ( TargetChildren[jJnx], iBOMLineQuantityAttrID, std::to_string ( fINCPercentage ).c_str() ) );

												ITK(BOM_line_ask_attribute_string(TargetChildren[jJnx], iBOMLineGenRMListID, &GenRMListbeforeSet));
												GenRMListToSet = (char*)MEM_alloc((int)((tc_strlen(objectstringOfGenRM) + tc_strlen(GenRMListbeforeSet) + tc_strlen(std::to_string(fINCPercentageBefAdd).c_str()) + 10) * sizeof(char)));

												tc_strcpy(GenRMListToSet, GenRMListbeforeSet);
												tc_strcat(GenRMListToSet,NEW_LINE);
												tc_strcat(GenRMListToSet,objectstringOfGenRM);
												tc_strcat(GenRMListToSet,COLON);
												tc_strcat(GenRMListToSet,std::to_string ( fINCPercentageBefAdd ).c_str());
												tc_strcat(GenRMListToSet,PERCENTAGE_SYMBOL);
												ITK(BOM_line_set_attribute_string(TargetChildren[jJnx], iBOMLineGenRMListID, GenRMListToSet));
												ITK ( BOM_save_window ( tIngBOMWindowTag ) );
												MEM_free(GenRMListToSet);
												ITK ( BOM_line_ask_attribute_tag ( TargetChildren[jJnx], bl_occ_attribute, &tOccurenceTag ) );

												ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsINCImpure ) );

												ITK ( PopulateDataToStructure_on_post ( head_ptr, tIncItemRevTag, tItemRevTag, fPercentage, tReqdDRGItemRev, pcINCPercentageQty, bIsINCImpure ) );

												if ( pcINCPercentageQty != NULL )
												{
													MEM_free ( pcINCPercentageQty );
													pcINCPercentageQty = NULL;
												}

												if ( pcTargetPercentageQty != NULL )
												{
													MEM_free ( pcTargetPercentageQty );
													pcTargetPercentageQty = NULL;
												}
											}
											else
											{
												bool bIsINCImpure     = false;

												char* pcPercentageQty = NULL;

												double fINCPercentage = 0.0;
												char* GenRMListToSet =NULL;
												tag_t tNewLineTag     = NULLTAG;
												tag_t tOccurenceTag  = NULLTAG;

												ITK ( BOM_line_add ( tIngBOMTopLine, tINCItemTag, tIncItemRevTag, NULLTAG, &tNewLineTag ) );

												if ( retcode == ITK_ok && tNewLineTag != NULLTAG )
												{
													ITK ( BOM_save_window ( tIngBOMWindowTag ) );
													ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineQuantityAttrID, &pcPercentageQty ) );
													fINCPercentage = ( atof ( pcPercentageQty ) ) * fPercentage / 100;

													ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineQuantityAttrID, std::to_string ( fINCPercentage ).c_str() ) );
													GenRMListToSet = (char*)MEM_alloc((int)(( tc_strlen(objectstringOfGenRM)+tc_strlen(std::to_string ( fINCPercentage ).c_str())+ 5) * sizeof(char)));
													tc_strcpy(GenRMListToSet,objectstringOfGenRM);
													tc_strcat(GenRMListToSet,COLON);
													tc_strcat(GenRMListToSet,std::to_string ( fINCPercentage ).c_str());
													tc_strcat(GenRMListToSet,PERCENTAGE_SYMBOL);
												ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineGenRMListID,GenRMListToSet));


													ITK ( BOM_save_window ( tIngBOMWindowTag ) );
													MEM_free(GenRMListToSet);


													ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineImpureteAttrID, &pcINCImpurete ) );
													ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineImpureteAttrID, pcINCImpurete ) );
													ITK ( BOM_save_window ( tIngBOMWindowTag ) );
												}

												ITK ( BOM_line_ask_attribute_tag ( tNewLineTag, bl_occ_attribute, &tOccurenceTag ) );

												ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsINCImpure ) );

												ITK ( PopulateDataToStructure_on_post ( head_ptr, tIncItemRevTag, tItemRevTag, fPercentage, tReqdDRGItemRev, pcPercentageQty, bIsINCImpure ) );

												if ( pcPercentageQty != NULL )
												{
													MEM_free ( pcPercentageQty );
													pcPercentageQty = NULL;
												}
											}
											if ( pcTargetImpurete != NULL )
											{
												MEM_free ( pcTargetImpurete );
												pcTargetImpurete = NULL;
											}

											if ( pcINCImpurete != NULL )
											{
												MEM_free ( pcINCImpurete );
												pcINCImpurete = NULL;
											}
											break;
										}
										else
										{
											continue;
										}
									}
									if ( bIsINCItemPresent == false )
									{
										bool bIsINCImpure     = false;

										char* pcPercentageQty = NULL;
										char* pcINCImpurete   = NULL;
										char* GenRMListToSet =NULL;
										double fINCPercentage = 0.0;

										tag_t tIncItemRevTag = NULLTAG;
										tag_t tNewLineTag    = NULLTAG;
										tag_t tOccurenceTag  = NULLTAG;

										ITK ( BOM_line_ask_attribute_tag ( tIncLines[iInx], item_revtag_attribute, &tIncItemRevTag ) );
										ITK ( BOM_line_add ( tIngBOMTopLine, tINCItemTag, tIncItemRevTag, NULLTAG, &tNewLineTag ) );

										if ( retcode == ITK_ok && tNewLineTag != NULLTAG )
										{
											ITK ( BOM_save_window ( tIngBOMWindowTag ) );

											ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineQuantityAttrID, &pcPercentageQty ) );
											fINCPercentage = ( atof ( pcPercentageQty ) ) * fPercentage / 100;

											ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineQuantityAttrID, std::to_string ( fINCPercentage ).c_str() ) );
											GenRMListToSet = (char*)MEM_alloc((int)(( tc_strlen(objectstringOfGenRM)+tc_strlen(std::to_string ( fINCPercentage ).c_str())+ 5) * sizeof(char)));
											tc_strcpy(GenRMListToSet,objectstringOfGenRM);
											tc_strcat(GenRMListToSet,COLON);
											tc_strcat(GenRMListToSet,std::to_string ( fINCPercentage ).c_str());
											tc_strcat(GenRMListToSet,PERCENTAGE_SYMBOL);
										ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineGenRMListID,GenRMListToSet));


											ITK ( BOM_save_window ( tIngBOMWindowTag ) );
											MEM_free(GenRMListToSet);

											ITK ( BOM_line_ask_attribute_string ( tIncLines[iInx], iBOMLineImpureteAttrID, &pcINCImpurete ) );
											ITK ( BOM_line_set_attribute_string ( tNewLineTag, iBOMLineImpureteAttrID, pcINCImpurete ) );

											ITK ( BOM_save_window ( tIngBOMWindowTag ) );
										}

										ITK ( BOM_line_ask_attribute_tag ( tNewLineTag, bl_occ_attribute, &tOccurenceTag ) );

										ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsINCImpure ) );

										ITK ( PopulateDataToStructure_on_post ( head_ptr, tIncItemRevTag, tItemRevTag, fPercentage, tReqdDRGItemRev, pcPercentageQty, bIsINCImpure ) );
										if ( pcPercentageQty != NULL )
										{
											MEM_free ( pcPercentageQty );
											pcPercentageQty = NULL;
										}
										if ( pcINCImpurete != NULL )
										{
											MEM_free ( pcINCImpurete );
											pcINCImpurete = NULL;
										}
									}
								}
							}
						}

						ITK ( BOM_close_window ( tBOMWindowTag ) );
					}
					else
					{
						char* pcRegDossID = NULL;
						char* pcRMID      = NULL;

						ITK ( AOM_ask_value_string ( tReqdDRGItemRev, ITEM_ID, &pcRegDossID ) );
						ITK ( AOM_ask_value_string ( tItemRevTag, ITEM_ID, &pcRMID ) );

						ITK ( GetLocaleKeyValue ( NO_ING_CHILD_MESSAGE, sDRGBomError ) );

						sDRGBomError = sDRGBomError + " " + string ( pcRegDossID ) + " [ Raw Material :  " + string ( pcRMID ) + " ]";
						if ( pcRegDossID != NULL )
						{
							MEM_free ( pcRegDossID );
							pcRegDossID = NULL;
						}
						if ( pcRMID != NULL )
						{
							MEM_free ( pcRegDossID );
							pcRegDossID = NULL;
						}
					}
				}
				else
				{
					char* pcRegDossID = NULL;
					char* pcRMID      = NULL;

					ITK ( AOM_ask_value_string ( tReqdDRGItemRev, ITEM_ID, &pcRegDossID ) );
					ITK ( AOM_ask_value_string ( tItemRevTag, ITEM_ID, &pcRMID ) );

					ITK ( GetLocaleKeyValue ( NO_ING_CHILD_MESSAGE, sDRGBomError ) );

					sDRGBomError = sDRGBomError + " " + string ( pcRegDossID ) + " [ Raw Material :  " + string ( pcRMID ) + " ]";

					if ( pcRegDossID != NULL )
					{
						MEM_free ( pcRegDossID );
						pcRegDossID = NULL;
					}
					if ( pcRMID != NULL )
					{
						MEM_free ( pcRegDossID );
						pcRegDossID = NULL;
					}
				}
			}
			else
			{
				char* pcRegDossID = NULL;
				char* pcRMID      = NULL;

				ITK ( AOM_ask_value_string ( tReqdDRGItemRev, ITEM_ID, &pcRegDossID ) );
				ITK ( AOM_ask_value_string ( tItemRevTag, ITEM_ID, &pcRMID ) );

				ITK ( GetLocaleKeyValue ( NO_ING_CHILD_MESSAGE, sDRGBomError ) );

				sDRGBomError = sDRGBomError + " " + string ( pcRegDossID ) + " [ Raw Material :  " + string ( pcRMID ) + " ]";

				if ( pcRegDossID != NULL )
				{
					MEM_free ( pcRegDossID );
					pcRegDossID = NULL;
				}
				if ( pcRMID != NULL )
				{
					MEM_free ( pcRegDossID );
					pcRegDossID = NULL;
				}
			}
			if ( tDRGBomTags != NULL )
			{
				MEM_free ( tDRGBomTags );
				tDRGBomTags = NULL;
			}
			if ( tIncLines != NULL )
			{
				MEM_free ( tIncLines );
				tIncLines = NULL;
			}
			if ( TargetChildren != NULL )
			{
				MEM_free ( TargetChildren );
				TargetChildren = NULL;
			}
		}

		if ( isDRGItemUnreleased == TRUE )
		{
			char* pcMPGenItemID = NULL;

			ITK ( AOM_ask_value_string ( tItemRevTag,ITEM_ID, &pcMPGenItemID ) );
			if ( retcode == ITK_ok && pcMPGenItemID != NULL )
			{
				vInvalidMPGenItems.push_back ( string ( pcMPGenItemID ) );
			}

			if ( pcMPGenItemID != NULL )
			{
				MEM_free ( pcMPGenItemID );
				pcMPGenItemID = NULL;
			}
		}
	}
	else
	{
		char* pcMPGenItemID = NULL;

		isDRGItemUnreleased = TRUE; //to print Temporary simulation header in the beginning even if no DRG Item present under MP Generique

		ITK ( AOM_ask_value_string ( tItemRevTag,ITEM_ID, &pcMPGenItemID ) );
		if ( retcode == ITK_ok && pcMPGenItemID != NULL )
		{
			vChildlessMPGenItems.push_back ( string ( pcMPGenItemID ) );
		}

		if ( pcMPGenItemID != NULL )
		{
			MEM_free ( pcMPGenItemID );
			pcMPGenItemID = NULL;
		}
	}

	if ( tDRGItemRevs != NULL )
	{
		MEM_free ( tDRGItemRevs );
		tDRGItemRevs = NULL;
	}
	return retcode;
}

/**
 * Function    :  CreateIngItem
 * Description :  Function to create Liste d Ingredient Item
 * Input       :
 * 		 tItemTag		     <O>     - Item tag of Item Created
 */
int CreateIngItem ( tag_t *tItemTag, char* pcFLEObjectName, char* pcPFRevID )
{
	int retcode               = ITK_ok;

	tag_t tRevTypeTag         = NULLTAG;
	tag_t tRevCreateInputTag  = NULLTAG;

	/* Construct a CreateInput object for Item Revision */
	ITK ( TCTYPE_find_type ( INGList_REVISION, NULL, &tRevTypeTag ) );
	ITK ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) );

	if ( retcode == ITK_ok && tRevCreateInputTag != NULLTAG )
	{
		tag_t tItemTypeTag        = NULLTAG;
		tag_t tItemCreateInputTag = NULLTAG;

		/* Construct a CreateInput object for Item */
		ITK ( TCTYPE_find_type ( INGLIST, NULL, &tItemTypeTag ) );
		ITK ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) );

		if ( retcode == ITK_ok && tItemCreateInputTag != NULLTAG )
		{
			string sObjectName = LISTE_NAME_PREFIX + string ( pcFLEObjectName ) + HIPHEN + string ( pcPFRevID );

			ITK ( AOM_set_value_string ( tItemCreateInputTag, OBJECT_NAME, sObjectName.c_str() ) );
			ITK ( AOM_set_value_tag ( tItemCreateInputTag, REVISION, tRevCreateInputTag ) );

			/*Create Item Object*/
			ITK ( TCTYPE_create_object ( tItemCreateInputTag, tItemTag ) );
			ITK ( AOM_save_with_extensions ( *tItemTag ) );

		}
	}
	return retcode;
}

/**
 * Function    :  CreateBVandBVR_on_post
 * Description :  Function to create BOM View and Bom View Rev for an Item
 * Input       :
 * 		 tInputItemTag		     <I>     - Item tag of Item for which BOMView to be Created
 * 		 tInputItemRevTag        <I>     - Item Rev tag of Item for which BVR to be Created
 */
int CreateBVandBVR_on_post ( tag_t tInputItemTag, tag_t tInputItemRevTag )
{
	int retcode    = ITK_ok;

	tag_t tBomview = NULLTAG;

	ITK ( PS_create_bom_view ( NULLTAG, "", "", tInputItemTag, &tBomview ) );

	if ( retcode == ITK_ok && tBomview != NULLTAG )
	{
		tag_t tBVR = NULLTAG;

		ITK ( AOM_save_without_extensions ( tBomview ) );
		ITK ( AOM_save_without_extensions ( tInputItemTag ) );
		ITK ( AOM_unlock ( tInputItemTag ) );

		ITK ( PS_create_bvr ( tBomview, "", "", false, tInputItemRevTag, &tBVR ) );

		if ( retcode == ITK_ok && tBVR != NULLTAG )
		{
			ITK ( AOM_save_without_extensions ( tBVR ) );
			ITK ( AOM_save_without_extensions ( tInputItemRevTag ) );
			ITK ( AOM_unlock ( tInputItemRevTag ) );
		}
	}
	return retcode;
}
/**
 * Function    :  CreateAndAttachDataset_on_post
 * Description :  Function to create a dataset, attach it to Item Rev and Import Named reference file to it.
 * Input       :
 * 		 tPFItemRevTag		     <I>     - Item Rev Tag
 * 		 sINCIReportPath         <I>     - String containing path of the report
 * 		 sDatasetName            <I>     - String containing name for created dataset
 * 		 sFileName               <I>     - String containing name for file name under dataset
 */
int CreateAndAttachDataset_on_post ( tag_t tPFItemRevTag, string sINCIReportPath, string sDatasetName, string sFileName )
{
	int retcode = ITK_ok;

	IMF_file_t descriptor;

	tag_t tTextDatasetTypeTag  = NULLTAG;
	tag_t tTextDatasetTag      = NULLTAG;
	tag_t tRelTypeTag          = NULLTAG;
	tag_t tRelationTag         = NULLTAG;
	tag_t tNamedRefFile        = NULLTAG;
	tag_t tToolTag             = NULLTAG;

	ITK ( AE_find_datasettype2 ( TEXT_DATASET_TYPE, &tTextDatasetTypeTag ) );

	if ( retcode == ITK_ok && tTextDatasetTypeTag != NULLTAG )
	{
		ITK ( AE_create_dataset_with_id	( tTextDatasetTypeTag, sDatasetName.c_str(), "", sDatasetName.c_str(), INITIAL_DATASET_REV, &tTextDatasetTag ) );

		if ( retcode == ITK_ok && tTextDatasetTag != NULLTAG )
		{
			ITK ( AE_find_tool2 ( NOTEPAD, &tToolTag ) );
			ITK ( AE_set_dataset_tool ( tTextDatasetTag, tToolTag ) );
			ITK ( AE_set_dataset_format2 ( tTextDatasetTag, TEXT_REFERENCE ) );
			ITK ( AOM_save ( tTextDatasetTag ) );

			ITK ( GRM_find_relation_type ( TC_ATTACHES, &tRelTypeTag ) );
			ITK ( GRM_create_relation ( tPFItemRevTag, tTextDatasetTag, tRelTypeTag, NULL, &tRelationTag ) );

			if ( retcode == ITK_ok && tRelationTag != NULLTAG )
			{
				ITK ( GRM_save_relation ( tRelationTag ) );
				ITK ( AOM_unload ( tPFItemRevTag ) );

				ITK ( IMF_fmsfile_import ( sINCIReportPath.c_str() , sFileName.c_str(), SS_TEXT, &tNamedRefFile, &descriptor ) );

				if ( retcode == ITK_ok && tNamedRefFile != NULLTAG )
				{
					ITK ( AOM_refresh ( tTextDatasetTag, TRUE ) );
					ITK ( AE_add_dataset_named_ref ( tTextDatasetTag, TEXT_DATASET_TYPE, AE_PART_OF, tNamedRefFile ) );

					if ( retcode == ITK_ok )
					{
						ITK ( AOM_save ( tTextDatasetTag ) );
						ITK ( AOM_unload ( tNamedRefFile ) );
						ITK ( AOM_unload ( tTextDatasetTag ) );
					}
				}
			}
		}
	}

	return retcode;
}

/**
 * Function    :  CreateAndAttachDataset_on_post
 * Description :  Function to create and attach dataset.
 *
 * Input       :
 * 		 tSecIngListRevTag		<I>  - Item Rev Tag
 * 		 sINCIReportPath        <I>  - String
 * 		 sFileName              <I>  - String
 *
 */
int CreateAndAttachDataset_on_post ( tag_t tSecIngListRevTag, string sINCIReportPath, string sFileName )
{
	int retcode = ITK_ok;

	tag_t tTextDatasetTypeTag  = NULLTAG;

	ITK ( AE_find_datasettype2 ( TEXT_DATASET_TYPE, &tTextDatasetTypeTag ) );

	string sDatasetName = sFileName;
    string sCSVExt = CSV_FILE_EXTENSION;
	int i = sDatasetName.find ( CSV_FILE_EXTENSION );

	sDatasetName.erase ( i, sCSVExt.length() );

	if ( retcode == ITK_ok && tTextDatasetTypeTag != NULLTAG )
	{
		tag_t tTextDatasetTag = NULLTAG;

		ITK ( AE_create_dataset_with_id	( tTextDatasetTypeTag, sDatasetName.c_str(), "", sDatasetName.c_str(), INITIAL_DATASET_REV, &tTextDatasetTag ) );

		if ( retcode == ITK_ok && tTextDatasetTag != NULLTAG )
		{
			tag_t tRelTypeTag  = NULLTAG;
			tag_t tRelationTag = NULLTAG;
			tag_t tToolTag     = NULLTAG;

			ITK ( AE_find_tool2 ( NOTEPAD, &tToolTag ) );
			ITK ( AE_set_dataset_tool ( tTextDatasetTag, tToolTag ) );
			ITK ( AE_set_dataset_format2 ( tTextDatasetTag, TEXT_REFERENCE ) );
			ITK ( AOM_save ( tTextDatasetTag ) );

			ITK ( GRM_find_relation_type ( TC_ATTACHES, &tRelTypeTag ) );
			ITK ( GRM_create_relation ( tSecIngListRevTag, tTextDatasetTag, tRelTypeTag, NULL, &tRelationTag ) );

			if ( retcode == ITK_ok && tRelationTag != NULLTAG )
			{
				IMF_file_t descriptor;

				tag_t tNamedRefFile = NULLTAG;

				ITK ( GRM_save_relation ( tRelationTag ) );
				ITK ( AOM_unload ( tSecIngListRevTag ) );

				ITK ( IMF_fmsfile_import ( sINCIReportPath.c_str() , sFileName.c_str(), SS_TEXT, &tNamedRefFile, &descriptor ) );

				if ( retcode == ITK_ok && tNamedRefFile != NULLTAG )
				{
					ITK ( AOM_refresh ( tTextDatasetTag, TRUE ) );
					ITK ( AE_add_dataset_named_ref ( tTextDatasetTag, TEXT_DATASET_TYPE, AE_PART_OF, tNamedRefFile ) );

					if ( retcode == ITK_ok )
					{
						ITK ( AOM_save ( tTextDatasetTag ) );
						ITK ( AOM_unload ( tNamedRefFile ) );
						ITK ( AOM_unload ( tTextDatasetTag ) );
					}
				}
			}
		}
	}

	return retcode;
}
/**
 * Function    :  AttachItemRevToBVR_on_post
 * Description :  Function to add Item Rev to BOM
 * Input       :
 * 		 tFPBOMWindowTag		     <I>     - Target BVR BOM Window
 * 		 targetbomline               <I>     - Target BOMLine
 * 		 itemtag                     <I>     - Item Tag of Item to be added to Bomline
 * 		 itemrevtag                  <I>     - Item Rev Tag of the Item
 */
int AttachItemRevToBVR_on_post ( tag_t tFPBOMWindowTag, tag_t targetbomline, tag_t itemtag, tag_t itemrevtag )
{
	int retcode    = ITK_ok;

	tag_t new_line = NULLTAG;

	ITK ( BOM_line_add ( targetbomline, itemtag, itemrevtag, NULLTAG, &new_line ) );

	if ( retcode == ITK_ok && new_line != NULLTAG )
	{
	    ITK ( BOM_save_window ( tFPBOMWindowTag ) );
	}
	return retcode;
}

/**
 * Function    :  CreateLogFile
 * Description :  Function to create log file for INCI BOM
 * Input       :
 * 		 tPFItemRevTag		     <I>     - Item Rev Tag
 * 		 tInputItemTag           <I>     - Item Tag
 *
 */
int CreateLogFile ( tag_t tPFItemRevTag, tag_t tInputItemTag )
{
	char* pcTransientVolDir = NULL;
	char* pcPFItemName      = NULL;
	char* pcCurrentTime     = NULL;
	char* pcFLEId           = NULL;
	char* pcPFId            = NULL;

	int retcode             = ITK_ok;
	int iFleItemCount       = 0;

	tag_t tRegRuleTypeTag   = NULLTAG;

	tag_t* tFLEItemRevs     = NULL;

	ITK ( IMF_get_transient_volume_root_dir ( 4, &pcTransientVolDir ) );

	if ( retcode == ITK_ok && pcTransientVolDir != NULL )
	{
		string sNoFormulaChild = "";

		ITK ( AOM_ask_value_string ( tInputItemTag, OBJECT_NAME, &pcPFItemName ) );

		time_t now = time ( 0 );

		tm *ltm = localtime ( &now );

		char local_buff[80];

		sprintf_s ( local_buff, "%d-%d-%d-%d-%d-%d", ( 1900 + ltm->tm_year ),
				 ( 1 + ltm->tm_mon ), ( ltm->tm_mday ), ( 1 + ltm->tm_hour ),
				 ( 1 + ltm->tm_min ), ( 1 + ltm->tm_sec ) );

		pcCurrentTime = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( local_buff ) + 1 ) );

		tc_strcpy ( pcCurrentTime, local_buff );

		string sFileName = string ( pcPFItemName ) + UNDERSCORE + string ( pcCurrentTime ) + CSV_FILE_EXTENSION;

		string sDatasetName = string ( pcPFItemName ) + UNDERSCORE + string ( pcCurrentTime );

		if ( pcCurrentTime != NULL )
		{
			MEM_free ( pcCurrentTime );
			pcCurrentTime = NULL;
		}
		if ( pcPFItemName != NULL )
		{
			MEM_free ( pcPFItemName );
			pcPFItemName = NULL;
		}

		string sINCIReportPath = string ( pcTransientVolDir ) + "\\" + sFileName;

		if ( pcTransientVolDir != NULL )
		{
			MEM_free ( pcTransientVolDir );
			pcTransientVolDir = NULL;
		}

		ofstream fINCIReport( sINCIReportPath  );

		ITK ( TCTYPE_find_type ( DRGPF_TO_FLE, DRGPF_TO_FLE, &tRegRuleTypeTag ) );

		ITK ( GRM_list_secondary_objects_only ( tPFItemRevTag, tRegRuleTypeTag, &iFleItemCount, &tFLEItemRevs ) );

		ITK ( AOM_ask_value_string ( tFLEItemRevs[0], ITEM_ID, &pcFLEId ) );

		ITK ( AOM_ask_value_string ( tPFItemRevTag, ITEM_ID, &pcPFId ) );
		fINCIReport<<"\n";

		ITK ( GetLocaleKeyValue ( NO_FORMULA_CHILD_MESSAGE, sNoFormulaChild ) );

		sNoFormulaChild = sNoFormulaChild + " " + string ( pcFLEId ) + " [ PF Reg Dossier : " + string ( pcPFId ) + " ]";

		fINCIReport<<sNoFormulaChild;

		fINCIReport.close();

		ITK ( CreateAndAttachDataset_on_post ( tPFItemRevTag, sINCIReportPath, sDatasetName, sFileName ) );

		if ( retcode == ITK_ok )
		{
			remove ( sINCIReportPath.c_str() );
		}

		if ( pcFLEId != NULL )
		{
			MEM_free ( pcFLEId );
			pcFLEId = NULL;
		}
		if ( pcPFId != NULL )
		{
			MEM_free ( pcPFId );
			pcPFId = NULL;
		}
	}
	if ( tFLEItemRevs != NULL )
	{
		MEM_free ( tFLEItemRevs );
		tFLEItemRevs = NULL;
	}
	return retcode;
}

/**
 * Function    :  SortStructure
 * Description :  Function to sort INCI's based on their percentage value
 * Input       :
 * 		 tIngBOMWindowTag		  <I>     - BOMWindow Tag
 * 		 tIngBOMTopLine           <I>     - BOMLine Tag
 *
 */
int SortStructure ( tag_t tIngBOMWindowTag, tag_t tIngBOMTopLine )
{
	int retcode         = ITK_ok;
	int iINGChildCount  = 0;

	tag_t* tINGChildren = 0;

	ITK ( BOM_line_ask_all_child_lines ( tIngBOMTopLine, &iINGChildCount, &tINGChildren ) );

	if ( iINGChildCount > 0 )
	{
		vector<pair<double,tag_t>> vPercentageChild;

		for ( int iInx = 0; iInx < iINGChildCount; iInx++ )
		{
			char* pcPercentage  = NULL;

			ITK ( BOM_line_ask_attribute_string ( tINGChildren[iInx], iBOMLineQuantityAttrID, &pcPercentage ) );

			vPercentageChild.push_back ( make_pair ( atof ( pcPercentage ), tINGChildren[iInx] ) );

			if ( pcPercentage != NULL )
			{
				MEM_free ( pcPercentage );
				pcPercentage = NULL;
			}
		}

		sort ( vPercentageChild.begin(), vPercentageChild.end() );

		int iSeqNumber = 10;

		//for ( int iInx = 0; iInx < vPercentageChild.size(); iInx++ )
		for ( int iInx = vPercentageChild.size()-1; iInx >= 0; iInx-- )
		{
			tag_t tBOMLine = vPercentageChild[iInx].second;

			string sSeqNumber = to_string ( iSeqNumber );

			ITK ( BOM_line_set_attribute_string ( tBOMLine, iBOMLineSeqNo, sSeqNumber.c_str () ) );

			iSeqNumber = iSeqNumber + 10;
		}
		BOM_save_window ( tIngBOMWindowTag );

		vPercentageChild.clear();
	}

	if ( tINGChildren != NULL )
	{
		MEM_free ( tINGChildren );
		tINGChildren = NULL;
	}

	return retcode;
}


/**
 * Function    :  CreateLogFile
 * Description :  Function to create log file for INCI BOM
 * Input       :
 * 		 tPFItemRevTag		     <I>     - Item Rev Tag
 * 		 tInputItemTag           <I>     - Item Tag
 * 		 head_ptr                <I>     - Head_Ptr of the head node to the linked list
 * 		 vInvalidMPGenItems      <I>     - Vector of strings
 * 		 vChildlessMPGenItems    <I>     - Vector of strings
 * 		 isDRGItemUnreleased     <I>     - Boolean attribute
 * 		 sDRGBomError            <I>     - String
 *
 */
int CreateLogFile ( tag_t tPFItemRevTag, tag_t tInputItemTag, struct INCIInfo *head_ptr, vector<string> vInvalidMPGenItems, vector<string> vChildlessMPGenItems, bool isDRGItemUnreleased, string sDRGBomError )
{
	char* pcTransientVolDir = NULL;
	char* pcPFItemName      = NULL;
	char* pcCurrentTime     = NULL;

    int retcode = ITK_ok;

    ITK ( IMF_get_transient_volume_root_dir ( 4, &pcTransientVolDir ) );

    if ( retcode == ITK_ok && pcTransientVolDir != NULL )
    {
    	string sPureHeader   = "";
    	string sBOMHeader    = "";
    	string sImpureHeader = "";

		ITK ( AOM_ask_value_string ( tInputItemTag, OBJECT_NAME, &pcPFItemName ) );

		time_t now = time ( 0 );

		tm *ltm = localtime ( &now );

		char local_buff[80];

		sprintf_s ( local_buff, "%d-%d-%d-%d-%d-%d", ( 1900 + ltm->tm_year ),
				 ( 1 + ltm->tm_mon ), ( ltm->tm_mday ), ( 1 + ltm->tm_hour ),
				 ( 1 + ltm->tm_min ), ( 1 + ltm->tm_sec ) );

		pcCurrentTime = ( char* ) MEM_alloc ( sizeof ( char ) * ( tc_strlen ( local_buff ) + 1 ) );

		tc_strcpy ( pcCurrentTime, local_buff );

		string sFileName = string ( pcPFItemName ) + UNDERSCORE + string ( pcCurrentTime ) + CSV_FILE_EXTENSION;

		string sDatasetName = string ( pcPFItemName ) + UNDERSCORE + string ( pcCurrentTime );

		if ( pcCurrentTime != NULL )
		{
			MEM_free ( pcCurrentTime );
			pcCurrentTime = NULL;
		}
		if ( pcPFItemName != NULL )
		{
			MEM_free ( pcPFItemName );
			pcPFItemName = NULL;
		}

		string sINCIReportPath = string ( pcTransientVolDir ) + "\\" + sFileName;

		if ( pcTransientVolDir != NULL )
		{
			MEM_free ( pcTransientVolDir );
			pcTransientVolDir = NULL;
		}

		ofstream fINCIReport( sINCIReportPath  );

		if ( isDRGItemUnreleased == true )
		{
			string sTempHeader = "";

			ITK ( GetLocaleKeyValue ( TEMPORARY_SIM_HEADER, sTempHeader ) );
			fINCIReport<<sTempHeader;
			fINCIReport << "\n\n";
		}

		ITK ( GetLocaleKeyValue ( PURE_INCI_HEADER, sPureHeader ) );
		fINCIReport<<sPureHeader;
		INCIInfo *temp = new INCIInfo;

		temp = head_ptr;

		fINCIReport << "\n";

		ITK ( GetLocaleKeyValue ( INCI_BOM_REPORT_HEADER, sBOMHeader ) );
		fINCIReport<<sBOMHeader;

		while ( temp != NULL)
		{
			if ( temp->bIsINCImpure == false )
			{
				string sRMPercent  = ( temp->dRMPercentage == 0 ) ? "" : to_string ( temp->dRMPercentage );
				string sOriginalRM = ( temp->pcOriginalRM == NULL ) ? "" : string ( temp->pcOriginalRM );
				string sRMName     = ( temp->pcRMName == NULL ) ? "" : string ( temp->pcRMName );
				string sDRGType    = ( temp->pcDRGType == NULL ) ? "" : string ( temp->pcDRGType );
				string sDRGStatus  = ( temp->pcDRGStatus == NULL ) ? "" : string ( temp->pcDRGStatus );

				fINCIReport <<  "\n" + sRMPercent + COMMA_SYMBOL + sOriginalRM + COMMA_SYMBOL + sRMName + COMMA_SYMBOL + sDRGType + COMMA_SYMBOL + sDRGStatus
						+ COMMA_SYMBOL + string ( temp->pcINCName ) + COMMA_SYMBOL + to_string ( temp->dINCIPercentage ) + COMMA_SYMBOL + to_string ( temp->dTotalPercentage ) ;
			}

			temp=temp->next;
		}

		fINCIReport << "\n\n\n\n";

		temp = head_ptr;

		ITK ( GetLocaleKeyValue ( IMPURE_INCI_HEADER, sImpureHeader ) );
		fINCIReport<<sImpureHeader;

		fINCIReport << "\n";

		fINCIReport << sBOMHeader;

		while ( temp != NULL)
		{
			if ( temp->bIsINCImpure == true )
			{
				string sRMPercent  = ( temp->dRMPercentage == 0 ) ? "" : to_string ( temp->dRMPercentage );
				string sOriginalRM = ( temp->pcOriginalRM == NULL ) ? "" : string ( temp->pcOriginalRM );
				string sRMName     = ( temp->pcRMName == NULL ) ? "" : string ( temp->pcRMName );
				string sDRGType    = ( temp->pcDRGType == NULL ) ? "" : string ( temp->pcDRGType );
				string sDRGStatus  = ( temp->pcDRGStatus == NULL ) ? "" : string ( temp->pcDRGStatus );

				fINCIReport <<  "\n" + sRMPercent + COMMA_SYMBOL + sOriginalRM + COMMA_SYMBOL + sRMName + COMMA_SYMBOL + sDRGType + COMMA_SYMBOL + sDRGStatus
						+ COMMA_SYMBOL + string ( temp->pcINCName ) + COMMA_SYMBOL + to_string ( temp->dINCIPercentage ) + COMMA_SYMBOL + to_string ( temp->dTotalPercentage ) ;
			}

			temp = temp->next;
		}

		if ( sDRGBomError.compare ( "" ) != 0 )
		{
			fINCIReport <<"\n\n\n";
			fINCIReport << sDRGBomError;
		}

		if ( vInvalidMPGenItems.size() != 0 || vChildlessMPGenItems.size() != 0 )
		{
			string sWarningMessage = "";
			fINCIReport<<"\n\n";
			ITK ( GetLocaleKeyValue ( WARNING_HEADER, sWarningMessage ) );
			fINCIReport<<sWarningMessage;
		}
		if ( ! vInvalidMPGenItems.empty() )
		{
			string sInvalidMP = "";

			fINCIReport <<"\n\n";

			ITK ( GetLocaleKeyValue ( INVALID_MP_GEN_MESSAGE, sInvalidMP ) );
			fINCIReport<<sInvalidMP;

			fINCIReport <<"\n";
			for ( int iInx = 0; iInx < vInvalidMPGenItems.size(); iInx++ )
			{
				fINCIReport << vInvalidMPGenItems[iInx];
				fINCIReport << "\n";
			}
		}
		if ( ! vChildlessMPGenItems.empty() )
		{
			string sNoRegDossy = "";
			fINCIReport <<"\n";

			ITK ( GetLocaleKeyValue ( NO_REG_DOSSY_MESSAGE, sNoRegDossy ) );
			fINCIReport<<sNoRegDossy;

			fINCIReport <<"\n";
			for ( int iInx = 0; iInx < vChildlessMPGenItems.size(); iInx++ )
			{
				fINCIReport << vChildlessMPGenItems[iInx];
				fINCIReport << "\n";
			}
		}


		fINCIReport.close();

		ITK ( CreateAndAttachDataset_on_post ( tPFItemRevTag, sINCIReportPath, sDatasetName, sFileName ) );

		if ( retcode == ITK_ok )
		{
			remove ( sINCIReportPath.c_str() );
		}
    }
    return retcode;
}

/**
 * Function    :  ReviseAndAttachQQ
 * Description :  Function to revise and attach QQ object
 * Input       :
 * 		 tIngListLatestRev		<I>     - Item Rev Tag
 * 		 PFItemRevTag           <I>     - Item Rev Tag
 */
int ReviseAndAttachQQ ( tag_t tIngListLatestRev, tag_t &tRevisedIngListRev )
{
	int retcode = ITK_ok;

	ITK ( ITEM_copy_rev ( tIngListLatestRev, NULL, &tRevisedIngListRev ) );

	if ( retcode == ITK_ok && tRevisedIngListRev != NULLTAG )
	{
		ITK ( ITEM_save_rev ( tRevisedIngListRev ) );
		ITK ( AOM_refresh ( tRevisedIngListRev, FALSE ) );
	}

	return retcode;
}

/**
 * Function    :  GetAllergenValue_on_post
 * Description :  Function to get Allergen Value for ING Revs.
 *
 * Input       :
 * 		 tINCItemRevTag		<I>  - Item Rev Tag
 * 		 isAllergen         <OF> - boolean pointer
 *
 */
int GetAllergenValue_on_post ( tag_t tINCItemRevTag, bool &isAllergen )
{
	int retcode                = ITK_ok;
    int iPrimIngRegCount       = 0;

	tag_t tRegulatedRelTag     = NULLTAG;

	tag_t* tPrimIngListRevTags = NULL;

	ITK ( TCTYPE_find_type ( REGULATED_REL, REGULATED_REL, &tRegulatedRelTag ) );

	ITK ( GRM_list_primary_objects_only ( tINCItemRevTag, tRegulatedRelTag, &iPrimIngRegCount, &tPrimIngListRevTags ) );

	if ( retcode == ITK_ok && iPrimIngRegCount != 0 )
	{
		ITK ( AOM_ask_value_logical ( tPrimIngListRevTags[0], O6_ALLERGENE, &isAllergen ) );

		if ( tPrimIngListRevTags != NULL )
		{
			MEM_free ( tPrimIngListRevTags );
			tPrimIngListRevTags = NULL;
		}
	}
	return retcode;
}

/**
 * Function    :  get_time_on_post
 * Description :  Gets the system current time and return string in
 * 				  YY-MM-DD-hh-mm-ss format.
 *
 * Input       :
 *
 * Output
 * 		curren_time - Preference value.
 */
int get_time_on_post(char** curren_time) {
	int retcode = ITK_ok;

	time_t now = time(0);

	tm *ltm = localtime(&now);

	char local_buff[80];
	sprintf_s(local_buff, "%d-%d-%d-%d-%d-%d", (1900 + ltm->tm_year),
			(1 + ltm->tm_mon), (ltm->tm_mday), (1 + ltm->tm_hour),
			(1 + ltm->tm_min), (1 + ltm->tm_sec));

	*curren_time = (char*) MEM_alloc(sizeof(char) * (tc_strlen(local_buff) + 1));
	tc_strcpy(*curren_time, local_buff);

	return retcode;
}

/**
 * Function    :  GetFileName_on_post
 * Description :  Function to get FileName to be attached to Dataset's Named Reference.
 *
 * Input       :
 * 		 tSecIngListRevTag		<I>  - Item Rev Tag
 * 		 sFileName              <OF> - String pointer
 *
 */
int GetFileName_on_post ( tag_t tSecIngListRevTag, string &sFileName )
{
	char* pcSecIngListRevName = NULL;
	char* pcCurrentTime       = NULL;

	int retcode = ITK_ok;

	ITK ( AOM_ask_value_string ( tSecIngListRevTag, OBJECT_NAME, &pcSecIngListRevName ) );

	ITK ( get_time_on_post ( &pcCurrentTime ) );

	if ( retcode == ITK_ok && pcCurrentTime != NULL )
	{
		sFileName = string ( pcSecIngListRevName ) + UNDERSCORE + string ( pcCurrentTime ) + CSV_FILE_EXTENSION;
	}

	if ( pcSecIngListRevName != NULL )
	{
		MEM_free ( pcSecIngListRevName );
		pcSecIngListRevName = NULL;
	}
	if ( pcCurrentTime != NULL )
	{
		MEM_free ( pcCurrentTime );
		pcCurrentTime = NULL;
	}
	return retcode;
}

/**
 * Function    :  GetLocaleTextValue_on_post
 * Description :  Function to get locale key value.
 *
 * Input       :
 * 		 pcKey		<I>  - char pointer
 * 		 sValue     <OF> - String output pointer
 *
 */
int GetLocaleTextValue_on_post ( char* pcKey, string &sValue )
{
	char* pcKeyValue = NULL;

	int retcode = ITK_ok;

	ITK ( TXTSRV_get_unsubstituted_text_resource ( pcKey, &pcKeyValue ) );

	sValue = string ( pcKeyValue );

	if ( pcKeyValue != NULL )
	{
		MEM_free ( pcKeyValue );
		pcKeyValue = NULL;
	}

	return retcode;
}

/**
 * Function    :  FormulateReport_on_post
 * Description :  Function to Formulate Report or Copy BOMLines based on bIsSimReqd.
 *
 * Input       :
 * 		 tIngListChildren		<I>  - Tags of BOMLine
 * 		 iIngListChildCount     <I>  - Number of Children
 * 		 tSecIngListRevTag      <I>  - Item Rev Tag
 *
 */
int FormulateReport_on_post ( tag_t* tIngListChildren, int iIngListChildCount, tag_t tSecIngListRevTag )
{
    int retcode = ITK_ok;

    char* pcTransientVolDir = NULL;

	ofstream fINCIReport;

	string sFileName         = "";
	string sINCIReportPath   = "";

	struct SkippedINCIInfo *head_ptr = NULL;

	ITK ( IMF_get_transient_volume_root_dir ( 4, &pcTransientVolDir ) );

	if ( retcode == ITK_ok && pcTransientVolDir != NULL )
	{
		ITK ( GetFileName_on_post ( tSecIngListRevTag, sFileName ) );

		if ( retcode == ITK_ok && sFileName.compare ( "" ) != 0 )
		{
			string sValue = "";
			sINCIReportPath = string ( pcTransientVolDir ) + "\\" + sFileName;

			if ( pcTransientVolDir != NULL )
			{
				MEM_free ( pcTransientVolDir );
				pcTransientVolDir = NULL;
			}
			fINCIReport.open( sINCIReportPath );

			ITK ( GetLocaleTextValue_on_post ( COPIED_INCI_HEADER, sValue ) );

            if ( retcode == ITK_ok && sValue.compare ( "" ) != 0 )
            {
            	fINCIReport<< sValue;
            	sValue = "";
            	fINCIReport << "\n";
            	ITK ( GetLocaleTextValue_on_post ( QQ_INCI_BOM_REPORT_HEADER, sValue ) );

            	if ( retcode == ITK_ok && sValue.compare ( "" ) != 0 )
            	{
            		fINCIReport << sValue;
            	}
            }
		}
	}

	for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
	{
		bool bIsImpurete = false;

		tag_t tOccurenceTag = NULLTAG;

		ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

		ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

		if ( retcode == ITK_ok )
		{
			bool isAllergen = false;

			char* pcApplType = NULL;

			tag_t tINCItemRevTag = NULLTAG;

			ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

			if ( retcode == ITK_ok )
			{
				ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

				if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
				{
					/*Getting Allergen value of Ingredient*/
					ITK ( GetAllergenValue_on_post ( tINCItemRevTag, isAllergen ) );

					if ( retcode == ITK_ok )
					{
						/*Writing to Report only if Ingredient is Pure*/
						if ( bIsImpurete == false )
						{
							char* pcINCPercent = NULL;

							ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

							/*Check if Ingredient's Allergen value is True*/
							if ( isAllergen == true )
							{
								/*Check if Application Type is Rince*/
								if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
								{
									/*Writing to Report only if Application Type is Rince and content >= 0.01*/
									if ( atof ( pcINCPercent ) >= 0.01 )
									{
										char* pcINCID      = NULL;
										char* pcINCRevName = NULL;

										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_id_attribute, &pcINCID ) );
										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_rev_name_attribute, &pcINCRevName ) );

										fINCIReport<<"\n" + string ( pcINCID ) + COMMA_SYMBOL + string ( pcINCRevName ) + COMMA_SYMBOL + TRUE_VALUE + COMMA_SYMBOL + string ( pcApplType ) + COMMA_SYMBOL + string ( pcINCPercent );

										if ( pcINCID != NULL )
										{
											MEM_free ( pcINCID );
											pcINCID = NULL;
										}
										if ( pcINCRevName != NULL )
										{
											MEM_free ( pcINCRevName );
											pcINCRevName = NULL;
										}
									}
									/*Populating Skipped INCI entries if Application Type is Rince and content < 0.01*/
									else
									{
										ITK ( PopulateDataToStructure_on_post ( &head_ptr, tIngListChildren[iInx], TRUE_VALUE, pcApplType, FALSE_VALUE ) );
									}
								}
								else
								{
									/*Writing to Report only if Application Type is Non Rince value and content >= 0.001*/
									if ( atof ( pcINCPercent ) >= 0.001 )
									{
										char* pcINCID      = NULL;
										char* pcINCRevName = NULL;

										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_id_attribute, &pcINCID ) );
										ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_rev_name_attribute, &pcINCRevName ) );

										fINCIReport<<"\n" + string ( pcINCID ) + COMMA_SYMBOL + string ( pcINCRevName ) + COMMA_SYMBOL + TRUE_VALUE + COMMA_SYMBOL + string ( pcApplType ) + COMMA_SYMBOL + string ( pcINCPercent );

										if ( pcINCID != NULL )
										{
											MEM_free ( pcINCID );
											pcINCID = NULL;
										}
										if ( pcINCRevName != NULL )
										{
											MEM_free ( pcINCRevName );
											pcINCRevName = NULL;
										}
									}
									/*Populating Skipped INCI entries if Application Type is Non Rince value and content < 0.001*/
									else
									{
										ITK ( PopulateDataToStructure_on_post ( &head_ptr, tIngListChildren[iInx], TRUE_VALUE, pcApplType, FALSE_VALUE ) );
									}
								}
								if ( pcINCPercent != NULL )
								{
									MEM_free ( pcINCPercent );
									pcINCPercent = NULL;
								}
							}
							/*Check if Ingredient's Allergen value is False*/
							else
							{
								char* pcINCID      = NULL;
								char* pcINCRevName = NULL;

								ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_id_attribute, &pcINCID ) );
								ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], item_rev_name_attribute, &pcINCRevName ) );

								fINCIReport<<"\n" + string ( pcINCID ) + COMMA_SYMBOL + string ( pcINCRevName ) + COMMA_SYMBOL + FALSE_VALUE + COMMA_SYMBOL + string ( pcApplType ) + COMMA_SYMBOL + string ( pcINCPercent );

								if ( pcINCID != NULL )
								{
									MEM_free ( pcINCID );
									pcINCID = NULL;
								}
								if ( pcINCRevName != NULL )
								{
									MEM_free ( pcINCRevName );
									pcINCRevName = NULL;
								}
							}
							if ( pcINCPercent != NULL )
							{
								MEM_free ( pcINCPercent );
								pcINCPercent = NULL;
							}
						}
						/*Populating Impure INCI's ID entries*/
						else
						{
							if ( isAllergen == true )
							{
								ITK ( PopulateDataToStructure_on_post ( &head_ptr, tIngListChildren[iInx], TRUE_VALUE, pcApplType, TRUE_VALUE ) );
							}
							else
							{
								ITK ( PopulateDataToStructure_on_post ( &head_ptr, tIngListChildren[iInx], FALSE_VALUE, pcApplType, TRUE_VALUE ) );
							}
						}
					}
				}
			}
			if ( pcApplType != NULL )
			{
				MEM_free ( pcApplType );
				pcApplType = NULL;
			}
		}
	}

	/*Writing Skipped INCI's to Report*/
	if ( head_ptr != NULL )
	{
		string sSkippedHeader = "";
		string sBOMHeader     = "";
		string sImpureHeader  = "";


		fINCIReport<<"\n\n\n\n";

		ITK ( GetLocaleTextValue_on_post ( SKIPPED_INCI_HEADER, sSkippedHeader ) );
		fINCIReport<<sSkippedHeader;

		fINCIReport<<"\n";

		ITK ( GetLocaleTextValue_on_post ( QQ_INCI_BOM_REPORT_HEADER, sBOMHeader ) );
		fINCIReport<<sBOMHeader;


		SkippedINCIInfo *temp = new SkippedINCIInfo;
		temp = head_ptr;

		while ( temp != NULL)
		{
			if ( ( tc_strcmp ( temp->pcImpurete, FALSE_VALUE ) == 0 ) )
			{
				string sINCName = ( temp->pcINCName == NULL ) ? "" : string ( temp->pcINCName );

				fINCIReport <<  "\n" + string ( temp->pcINCIId ) + COMMA_SYMBOL + sINCName + COMMA_SYMBOL + string ( temp->pcAllergenValue ) + COMMA_SYMBOL + string ( temp->pcApplType ) + COMMA_SYMBOL + to_string ( temp->dTotalPercentage );
			}
			temp=temp->next;
		}

		fINCIReport << "\n\n\n\n";

		temp = head_ptr;
		ITK ( GetLocaleTextValue_on_post ( IMPURE_INCI_HEADER, sImpureHeader ) );
		fINCIReport<<sImpureHeader;

		fINCIReport << "\n";

		fINCIReport << sBOMHeader;

		while ( temp != NULL)
		{
			if ( ( tc_strcmp ( temp->pcImpurete, TRUE_VALUE ) == 0 ) )
			{
				string sINCName = ( temp->pcINCName == NULL ) ? "" : string ( temp->pcINCName );

				fINCIReport <<  "\n" + string ( temp->pcINCIId ) + COMMA_SYMBOL + sINCName + COMMA_SYMBOL + string ( temp->pcAllergenValue ) + COMMA_SYMBOL + string ( temp->pcApplType ) + COMMA_SYMBOL + to_string ( temp->dTotalPercentage );
			}
			temp=temp->next;
		}

	}

	fINCIReport.close();

	ITK ( CreateAndAttachDataset_on_post ( tSecIngListRevTag, sINCIReportPath, sFileName ) );

	if ( retcode == ITK_ok )
	{
		remove ( sINCIReportPath.c_str() );
	}

	/*Memory Cleanup*/
	if ( head_ptr != NULL )
	{
		struct SkippedINCIInfo *tmp_ptr = NULL;
		do
		{
			tmp_ptr = head_ptr->next;

			if ( head_ptr->pcINCIId != NULL )
			{
				MEM_free ( head_ptr->pcINCIId );
				head_ptr->pcINCIId = NULL;
			}
			if ( head_ptr->pcINCName != NULL )
			{
				MEM_free ( head_ptr->pcINCName );
				head_ptr->pcINCName = NULL;
			}
			if ( head_ptr->pcAllergenValue != NULL )
			{
				MEM_free ( head_ptr->pcAllergenValue );
				head_ptr->pcAllergenValue = NULL;
			}
			if ( head_ptr->pcApplType != NULL )
			{
				MEM_free ( head_ptr->pcApplType );
				head_ptr->pcApplType = NULL;
			}
            if ( head_ptr->pcImpurete != NULL )
            {
            	MEM_free ( head_ptr->pcImpurete );
            	head_ptr->pcImpurete = NULL;
            }

			head_ptr->next = NULL;

			MEM_free ( head_ptr );

			head_ptr = tmp_ptr;

		} while ( head_ptr != NULL );
	}
	return retcode;
}
/**
 * Function    :  CreateSecIngBOM_on_post
 * Description :  Function to Formulate Report or Copy BOMLines based on bIsSimReqd.
 *
 * Input       :
 * 		 tIngListChildren		<I>  - Tags of BOMLine
 * 		 iIngListChildCount     <I>  - Number of Children
 * 		 tSecIngListRevTag      <I>  - Item Rev Tag
 * 		 bIsSimReqd             <I>  - Boolean Value
 *
 */
int CreateSecIngBOM_on_post ( tag_t* tIngListChildren, int iIngListChildCount, tag_t tSecIngListRevTag, bool bIsSimReqd )
{
	int retcode = ITK_ok;
	int iSecIngBVRCount = 0;

	tag_t* tSecBVRTags  = NULL;

	ITK ( AOM_ask_value_tags ( tSecIngListRevTag, STRUCT_REVISIONS, &iSecIngBVRCount ,&tSecBVRTags ) );

	if ( tSecBVRTags != NULL )
	{
		MEM_free ( tSecBVRTags );
		tSecBVRTags = NULL;
	}

	ITK ( initialise () );

	if ( bIsSimReqd == true )
	{
		if ( iSecIngBVRCount == 0 )
		{
			/*Formulating Report if Simulation value is True*/
			ITK ( FormulateReport_on_post ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
		}
		else
		{
			int iIngChildCount        = 0;

			tag_t tSecIngBOMWindowTag = NULLTAG;
			tag_t tSecIngBOMTopline   = NULLTAG;

			tag_t* tIngChildLines     = NULL;

			ITK ( BOM_create_window ( &tSecIngBOMWindowTag ) );
			ITK ( BOM_set_window_top_line ( tSecIngBOMWindowTag, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngBOMTopline ) );
			ITK ( BOM_line_ask_all_child_lines ( tSecIngBOMTopline, &iIngChildCount, &tIngChildLines ) );

			if ( retcode == ITK_ok && iIngChildCount == 0 )
			{
				/*Formulating Report if Simulation value is True*/
				ITK ( FormulateReport_on_post ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}
			else
			{
				for ( int iInx = 0; iInx < iIngChildCount; iInx++ )
				{
					ITK ( BOM_line_cut ( tIngChildLines[iInx] ) );
					BOM_save_window ( tSecIngBOMWindowTag );
				}
				/*Formulating Report if Simulation value is True*/
				ITK ( FormulateReport_on_post ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}
			if ( tIngChildLines != NULL )
			{
				MEM_free ( tIngChildLines );
				tIngChildLines = NULL;
			}
		}
	}
	else
	{
		/*Create BOM, if no BOM present earlier under Quali Quanti Object*/
		if ( iSecIngBVRCount == 0 )
		{
			tag_t tSecIngListItemTag = NULLTAG;

			ITK ( ITEM_ask_item_of_rev ( tSecIngListRevTag, &tSecIngListItemTag ) );

			if ( retcode == ITK_ok && tSecIngListItemTag != NULLTAG )
			{
				ITK ( CreateBVandBVR_on_post ( tSecIngListItemTag, tSecIngListRevTag ) );

				if ( retcode == ITK_ok )
				{
					tag_t tSecIngBOMWindow   = NULLTAG;
					tag_t tSecIngListTopLine = NULLTAG;

					ITK ( BOM_create_window ( &tSecIngBOMWindow ) );

					ITK ( BOM_set_window_top_line ( tSecIngBOMWindow, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngListTopLine ) );

					for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
					{
						bool bIsImpurete = false;

						tag_t tOccurenceTag = NULLTAG;

						ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

						ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

						if ( retcode == ITK_ok )
						{
							/*If Ingredient is Pure*/
							if ( bIsImpurete == false )
							{
								tag_t tINCItemRevTag = NULLTAG;
								tag_t tNewLineTag    = NULLTAG;

								ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

								if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
								{
									bool isAllergen = false;

									/*Getting Allergen Value of Ingredient*/
									ITK ( GetAllergenValue_on_post ( tINCItemRevTag, isAllergen ) );

									if ( retcode == ITK_ok )
									{
										char* pcApplType = NULL;

										ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

										if ( retcode == ITK_ok )
										{
											/*If Allergen value of Ingredient is True*/
											if ( isAllergen == true )
											{
												char* pcINCPercent = NULL;

												ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

												/*If Application Type Is RINCE*/
												if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
												{
													/* If Application Type is RINCE and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.01 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												/*If Application Type is any value other than Rince*/
												else
												{
													/* If Application Type is Non Rince and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.001 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												if ( pcINCPercent != NULL )
												{
													MEM_free ( pcINCPercent );
													pcINCPercent = NULL;
												}
											}
											/*If Ingredient's Allergen Value is False, Copy the BOMLine */
											else
											{
												ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
											}
										}
										if ( pcApplType != NULL )
										{
											MEM_free ( pcApplType );
											pcApplType = NULL;
										}
									}
								}
							}
						}
					}
					ITK ( BOM_save_window ( tSecIngBOMWindow ) );
					ITK ( BOM_close_window ( tSecIngBOMWindow ) );
				}
			}
			/*Once BOM attached, Formulate report*/
			ITK ( FormulateReport_on_post ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
		}
		else
		{
			int iIngChildCount        = 0;

			tag_t tSecIngBOMWindowTag = NULLTAG;
			tag_t tSecIngBOMTopline   = NULLTAG;

			tag_t* tIngChildLines     = NULL;

			ITK ( BOM_create_window ( &tSecIngBOMWindowTag ) );
			ITK ( BOM_set_window_top_line ( tSecIngBOMWindowTag, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngBOMTopline ) );
			ITK ( BOM_line_ask_all_child_lines ( tSecIngBOMTopline, &iIngChildCount, &tIngChildLines ) );

			if ( retcode == ITK_ok && iIngChildCount == 0 )
			{
				tag_t tSecIngListItemTag = NULLTAG;

				ITK ( ITEM_ask_item_of_rev ( tSecIngListRevTag, &tSecIngListItemTag ) );

				if ( retcode == ITK_ok && tSecIngListItemTag != NULLTAG )
				{
					tag_t tSecIngBOMWindow   = NULLTAG;
					tag_t tSecIngListTopLine = NULLTAG;

					ITK ( BOM_create_window ( &tSecIngBOMWindow ) );

					ITK ( BOM_set_window_top_line ( tSecIngBOMWindow, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngListTopLine ) );

					for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
					{
						bool bIsImpurete = false;

						tag_t tOccurenceTag = NULLTAG;

						ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

						ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

						if ( retcode == ITK_ok )
						{
							/*If Ingredient is Pure*/
							if ( bIsImpurete == false )
							{
								tag_t tINCItemRevTag = NULLTAG;
								tag_t tNewLineTag    = NULLTAG;

								ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

								if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
								{
									bool isAllergen = false;

									/*Getting Allergen Value of Ingredient*/
									ITK ( GetAllergenValue_on_post ( tINCItemRevTag, isAllergen ) );

									if ( retcode == ITK_ok )
									{
										char* pcApplType = NULL;

										ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

										if ( retcode == ITK_ok )
										{
											/*If Allergen value of Ingredient is True*/
											if ( isAllergen == true )
											{
												char* pcINCPercent = NULL;

												ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

												/*If Application Type Is RINCE*/
												if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
												{
													/* If Application Type is RINCE and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.01 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												/*If Application Type is any value other than Rince*/
												else
												{
													/* If Application Type is Non Rince and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.001 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												if ( pcINCPercent != NULL )
												{
													MEM_free ( pcINCPercent );
													pcINCPercent = NULL;
												}
											}
											/*If Ingredient's Allergen Value is False, Copy the BOMLine */
											else
											{
												ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
											}
										}
										if ( pcApplType != NULL )
										{
											MEM_free ( pcApplType );
											pcApplType = NULL;
										}
									}
								}
							}
						}
					}
					ITK ( BOM_save_window ( tSecIngBOMWindow ) );
					ITK ( BOM_close_window ( tSecIngBOMWindow ) );
				}
				/*Once BOM attached, Formulate report*/
				ITK ( FormulateReport_on_post ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}
			else
			{
				tag_t tSecIngListItemTag = NULLTAG;

				for ( int iInx = 0; iInx < iIngChildCount; iInx++ )
				{
					ITK ( BOM_line_cut ( tIngChildLines[iInx] ) );
					BOM_save_window ( tSecIngBOMWindowTag );
				}

				ITK ( ITEM_ask_item_of_rev ( tSecIngListRevTag, &tSecIngListItemTag ) );

				if ( retcode == ITK_ok && tSecIngListItemTag != NULLTAG )
				{
					tag_t tSecIngBOMWindow   = NULLTAG;
					tag_t tSecIngListTopLine = NULLTAG;

					ITK ( BOM_create_window ( &tSecIngBOMWindow ) );

					ITK ( BOM_set_window_top_line ( tSecIngBOMWindow, NULLTAG, tSecIngListRevTag, NULLTAG, &tSecIngListTopLine ) );

					for ( int iInx = 0; iInx < iIngListChildCount; iInx++ )
					{
						bool bIsImpurete = false;

						tag_t tOccurenceTag = NULLTAG;

						ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], bl_occ_attribute, &tOccurenceTag ) );

						ITK ( AOM_ask_value_logical ( tOccurenceTag, O6_IMPURETE, &bIsImpurete ) );

						if ( retcode == ITK_ok )
						{
							/*If Ingredient is Pure*/
							if ( bIsImpurete == false )
							{
								tag_t tINCItemRevTag = NULLTAG;
								tag_t tNewLineTag    = NULLTAG;

								ITK ( BOM_line_ask_attribute_tag ( tIngListChildren[iInx], item_revtag_attribute, &tINCItemRevTag ) );

								if ( retcode == ITK_ok && tINCItemRevTag != NULLTAG )
								{
									bool isAllergen = false;

									/*Getting Allergen Value of Ingredient*/
									ITK ( GetAllergenValue_on_post ( tINCItemRevTag, isAllergen ) );

									if ( retcode == ITK_ok )
									{
										char* pcApplType = NULL;

										ITK ( AOM_ask_value_string ( tSecIngListRevTag, O6_APPLICATION_TYPE, &pcApplType ) );

										if ( retcode == ITK_ok )
										{
											/*If Allergen value of Ingredient is True*/
											if ( isAllergen == true )
											{
												char* pcINCPercent = NULL;

												ITK ( BOM_line_ask_attribute_string ( tIngListChildren[iInx], bl_occ_o6_percent_theoric_attribute, &pcINCPercent ) );

												/*If Application Type Is RINCE*/
												if ( ( tc_strcmp ( pcApplType, FRENCH_RINCE_VALUE ) == 0 ) || ( tc_strcmp ( pcApplType, ENGLISH_RINSE_VALUE ) == 0 ) )
												{
													/* If Application Type is RINCE and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.01 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												/*If Application Type is any value other than Rince*/
												else
												{
													/* If Application Type is Non Rince and content is >= 0.01, copy the BOMLine*/
													if ( atof ( pcINCPercent ) >= 0.001 )
													{
														ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
													}
													else
													{
														continue;
													}
												}
												if ( pcINCPercent != NULL )
												{
													MEM_free ( pcINCPercent );
													pcINCPercent = NULL;
												}
											}
											/*If Ingredient's Allergen Value is False, Copy the BOMLine */
											else
											{
												ITK ( BOM_line_copy ( tSecIngListTopLine, tIngListChildren[iInx], NULLTAG, &tNewLineTag ) );
											}
										}
										if ( pcApplType != NULL )
										{
											MEM_free ( pcApplType );
											pcApplType = NULL;
										}
									}
								}
							}
						}
					}
					ITK ( BOM_save_window ( tSecIngBOMWindow ) );
					ITK ( BOM_close_window ( tSecIngBOMWindow ) );
				}
				/*Once BOM attached, Formulate report*/
				ITK ( FormulateReport_on_post ( tIngListChildren, iIngListChildCount, tSecIngListRevTag ) );
			}
			if ( tIngChildLines != NULL )
			{
				MEM_free ( tIngChildLines );
				tIngChildLines = NULL;
			}
		}
	}
	return retcode;
}

/**
 * Function    :  CalculateQualiQuanti
 * Description :  Function to do the quali Quanti calculation
 *
 * Input       :
 * 		 	tIngListRevTag		<I>  - Item Revision Tag
 *
 */
int CalculateQualiQuanti ( tag_t tIngListRevTag )
{
	int retcode = ITK_ok;

	tag_t tQualiQuantiRelTag = NULLTAG;

	ITK ( TCTYPE_find_type ( QUALI_QUANTI_REL, QUALI_QUANTI_REL, &tQualiQuantiRelTag ) );

	if ( retcode == ITK_ok && tQualiQuantiRelTag != NULLTAG )
	{
		int iPFRegDossRevCount   = 0;

		tag_t* tPFRegDossRevTags = NULL;

		ITK ( GRM_list_secondary_objects_only ( tIngListRevTag, tQualiQuantiRelTag, &iPFRegDossRevCount, &tPFRegDossRevTags ) );

		if ( retcode == ITK_ok && iPFRegDossRevCount != 0 )
		{
			int iPFBVRCount           = 0;

			tag_t tTargetPFItemRevTag = NULLTAG;

			tag_t* tPFBVRTags         = NULL;

			tTargetPFItemRevTag = tPFRegDossRevTags[0];

			if ( tPFRegDossRevTags != NULL )
			{
				MEM_free ( tPFRegDossRevTags );
				tPFRegDossRevTags = NULL;
			}

			ITK ( AOM_ask_value_tags ( tTargetPFItemRevTag, STRUCT_REVISIONS, &iPFBVRCount, &tPFBVRTags ) );

			if ( tPFBVRTags != NULL )
			{
				MEM_free ( tPFBVRTags );
				tPFBVRTags = NULL;
			}

			if ( retcode == ITK_ok && iPFBVRCount != 0 )
			{
				int iFPChildCount     = 0;

				tag_t tPFBOMWindowTag = NULLTAG;
				tag_t tFPBOMTopLine   = NULLTAG;

				tag_t* tFPChildren    = NULL;

				ITK ( BOM_create_window ( &tPFBOMWindowTag ) );
				ITK ( BOM_set_window_top_line ( tPFBOMWindowTag, NULLTAG, tTargetPFItemRevTag, NULLTAG, &tFPBOMTopLine ) );
				ITK ( BOM_line_ask_all_child_lines ( tFPBOMTopLine, &iFPChildCount, &tFPChildren ) );

				if ( retcode == ITK_ok && iFPChildCount != 0 )
				{
					int iIngListChildCount = 0;

					tag_t* tIngListChildren = NULL;

					ITK ( BOM_set_window_pack_all ( tPFBOMWindowTag, false ) );
					ITK ( BOM_line_ask_all_child_lines ( tFPChildren[0], &iIngListChildCount, &tIngListChildren ) );

					if ( retcode == ITK_ok && iIngListChildCount != 0 )
					{
						bool bIsSimReqd = false;

						ITK ( AOM_ask_value_logical ( tIngListRevTag, O6_SIMULATION, &bIsSimReqd ) );

						if ( retcode == ITK_ok )
						{
							ITK ( CreateSecIngBOM_on_post ( tIngListChildren, iIngListChildCount, tIngListRevTag, bIsSimReqd ) );
						}
					}
					if ( tIngListChildren != NULL )
					{
						MEM_free ( tIngListChildren );
						tIngListChildren = NULL;
					}
				}

				ITK ( BOM_close_window ( tPFBOMWindowTag ) );

				if ( tFPChildren != NULL )
				{
					MEM_free ( tFPChildren );
					tFPChildren = NULL;
				}
			}
		}
	}

	return retcode;
}

/**
 * Function    :  PopulatePropsToIngListRev
 * Description :  Function to copy properties from FleRevision to IngListRevision.
 *
 * Input       :
 * 		 tRevisedIngListRev		<I>  - Item Revision Tag
 * 		 tPFItemRevTag          <I>  - Item Revision Tag
 *
 */
int PopulatePropsToIngListRev ( tag_t tIngListRevTag, tag_t tPFItemRevTag )
{
	int retcode           = ITK_ok;

	tag_t tRegRuleTypeTag = NULLTAG;

	vector<pair<string,string>> vSourcePropsAndVals;

	ITK ( TCTYPE_find_type ( DRGPF_TO_FLE, DRGPF_TO_FLE, &tRegRuleTypeTag ) );

	if ( retcode == ITK_ok && tRegRuleTypeTag != NULLTAG )
	{
		int iFleItemCount   = 0;

		tag_t* tFLEItemRevs = NULL;

		ITK ( GRM_list_secondary_objects_only ( tPFItemRevTag, tRegRuleTypeTag, &iFleItemCount, &tFLEItemRevs ) );
		if ( retcode == ITK_ok && iFleItemCount != 0 )
		{
			int iFleBriefRevCount = 0;

			tag_t tFLEToBriefRel  = NULLTAG;
			tag_t* tFLEBriefRevs  = NULL;

			ITK ( TCTYPE_find_type ( BRIEF_TO_FLE_REL, BRIEF_TO_FLE_REL, &tFLEToBriefRel ) );

			if ( retcode == ITK_ok && tFLEToBriefRel != NULLTAG )
			{
				ITK ( GRM_list_primary_objects_only ( tFLEItemRevs[0], tFLEToBriefRel, &iFleBriefRevCount, &tFLEBriefRevs ) );
				if ( retcode == ITK_ok && iFleBriefRevCount != 0 )
				{
					char* pcApplType = NULL;
					char* pcApplZone = NULL;
					char* pcPopCible = NULL;

					ITK ( AOM_ask_value_string ( tFLEBriefRevs[0], O6_APPLICATION_TYPE, &pcApplType ) );
					ITK ( AOM_ask_value_string ( tFLEBriefRevs[0], O6_APLLICATION_ZONE, &pcApplZone ) );
					ITK ( AOM_ask_value_string ( tFLEBriefRevs[0], O6_POPULATION_CIBLE, &pcPopCible ) );

					if ( retcode == ITK_ok )
					{
						vSourcePropsAndVals.push_back ( make_pair ( O6_APPLICATION_TYPE, string ( pcApplType ) ) );
						vSourcePropsAndVals.push_back ( make_pair ( O6_APLLICATION_ZONE, string ( pcApplZone ) ) );
						vSourcePropsAndVals.push_back ( make_pair ( O6_POPULATION_CIBLE, string ( pcPopCible ) ) );
					}

					for ( int iInx = 0; iInx < vSourcePropsAndVals.size(); iInx++ )
					{
						ITK ( AOM_refresh ( tIngListRevTag, true ) );
						ITK ( AOM_set_value_string ( tIngListRevTag, ( vSourcePropsAndVals[iInx].first ).c_str(), ( vSourcePropsAndVals[iInx].second ).c_str() ) );
						if ( retcode == ITK_ok )
						{
							ITK ( AOM_save ( tIngListRevTag ) );
							ITK ( AOM_refresh ( tIngListRevTag, false ) );
						}
					}

					if ( pcApplType != NULL )
					{
						MEM_free ( pcApplType );
						pcApplType = NULL;
					}
					if ( pcApplZone != NULL )
					{
						MEM_free ( pcApplZone );
						pcApplZone = NULL;
					}
					if ( pcPopCible != NULL )
					{
						MEM_free ( pcPopCible );
						pcPopCible = NULL;
					}
				}
			}

			if ( tFLEBriefRevs != NULL )
			{
				MEM_free ( tFLEBriefRevs );
				tFLEBriefRevs = NULL;
			}
		}

		if ( tFLEItemRevs != NULL )
		{
			MEM_free ( tFLEItemRevs );
			tFLEItemRevs = NULL;
		}
	}

	vSourcePropsAndVals.clear();

	return retcode;
}

int O6_calculate_INCIs( METHOD_message_t * msg, va_list args )
{

	int retcode = ITK_ok;
	std::string generateQQ ("");
	int skipSaveOnCreate =0;
	struct INCIInfo *head_ptr = NULL;
	tag_t objectTag  = NULLTAG;
	BMF_extension_arguments_t* extensionArgs = NULL;
	int iParamCount=0;
	va_list largs;
	va_copy( largs, args);
	objectTag = va_arg(largs, tag_t);
	skipSaveOnCreate = va_arg(largs,int);
	va_end( largs );

	ITK(BMF_get_user_params(msg, &iParamCount, &extensionArgs))


	for (int iparamIndex = 0; iparamIndex < iParamCount; iparamIndex++)
				{
					if (tc_strcmp(extensionArgs[iparamIndex].paramName, "generateQQ") == 0)
					{

						generateQQ.assign(extensionArgs[iparamIndex].arg_val.str_value);
						break;
					}

				}

	if(skipSaveOnCreate == 0)
	{
	if ( objectTag != NULLTAG)
	{
		char* pcTypeDeDrg          = NULL;

		int iBVRCount              = 0;
		int iFleItemCount          = 0;

		tag_t tInputItemTag        = NULLTAG;
		tag_t tRegRuleTypeTag      = NULLTAG;
		tag_t tIngBOMWindowTag     = NULLTAG;
		tag_t tIngBOMTopLine       = NULLTAG;
		tag_t tFPIngredientItem    = NULLTAG;

		tag_t* tBVRTag             = NULL;

		vector <string> vInvalidMPGenItems;
		vector<string> vChildlessMPGenItems;

		ITK ( ITEM_ask_item_of_rev ( objectTag, &tInputItemTag ) );

		ITK ( AOM_ask_value_tags ( objectTag, STRUCT_REVISIONS, &iBVRCount, &tBVRTag ) );

		if ( tBVRTag != NULL )
		{
			MEM_free ( tBVRTag );
			tBVRTag = NULL;
		}

		ITK ( AOM_ask_value_string ( objectTag, O6_DRG_TYPE, &pcTypeDeDrg ) );

		ITK ( initialise () );

		ITK ( TCTYPE_find_type ( DRGPF_TO_FLE, DRGPF_TO_FLE, &tRegRuleTypeTag ) );

		if ( retcode == ITK_ok && tRegRuleTypeTag != NULLTAG )
		{
			tag_t* tFLEItemRevs = NULL;

			ITK ( GRM_list_secondary_objects_only ( objectTag, tRegRuleTypeTag, &iFleItemCount, &tFLEItemRevs ) );

			if ( retcode == ITK_ok && iFleItemCount != 0 )
			{
				char* pcFLEObjectName = NULL;
				char* pcPFRevID       = NULL;

				int iFLEBVRCount      = 0;

				tag_t tBOMWindowTag   = NULLTAG;
				tag_t tTopLine        = NULLTAG;

				tag_t* tFleChildren   = NULL;
				tag_t* tFLEBVRTags    = NULL;

				ITK ( AOM_ask_value_string ( tFLEItemRevs[0], OBJECT_NAME, &pcFLEObjectName) );
				ITK ( AOM_ask_value_string ( objectTag, ITEM_REVISION_ID, &pcPFRevID ) );

				if ( iBVRCount == 0 ) // If no BVR present under DRG PF Item Rev
				{
					tag_t tFPBOMWindowTag      = NULLTAG;
					tag_t tFPBOMTopLine        = NULLTAG;

					ITK ( CreateBVandBVR_on_post ( tInputItemTag, objectTag ) );

					if ( retcode == ITK_ok )
					{
						ITK ( BOM_create_window ( &tFPBOMWindowTag ) );

						ITK ( BOM_set_window_top_line ( tFPBOMWindowTag, NULLTAG, objectTag, NULLTAG, &tFPBOMTopLine ) );

						ITK ( CreateIngItem ( &tFPIngredientItem, pcFLEObjectName, pcPFRevID ) ); // Creating Ingredient List

						if ( retcode == ITK_ok && tFPIngredientItem != NULLTAG )
						{
							tag_t tFPIngredientItemRev = NULLTAG;

							ITK ( ITEM_ask_latest_rev ( tFPIngredientItem, &tFPIngredientItemRev ) );
							ITK ( AttachItemRevToBVR_on_post ( tFPBOMWindowTag, tFPBOMTopLine, tFPIngredientItem, tFPIngredientItemRev ) ); // Attaching Ing List Rev as a Child to DRG PF BOM
							if ( retcode == ITK_ok )
							{
								ITK ( BOM_close_window ( tFPBOMWindowTag ) );

								ITK ( CreateBVandBVR_on_post ( tFPIngredientItem, tFPIngredientItemRev ) );

								if ( retcode == ITK_ok )
								{
									ITK ( BOM_create_window ( &tIngBOMWindowTag ) );
									ITK ( BOM_set_window_top_line ( tIngBOMWindowTag, NULLTAG, tFPIngredientItemRev, NULLTAG, &tIngBOMTopLine ) );
								}
							}
						}
					}
				}
				else
				{
					int iFPChildCount          = 0;
					int iListeIngrCount        = 0;

					tag_t tFPBOMWindowTag      = NULLTAG;
					tag_t tFPBOMTopLine        = NULLTAG;
					tag_t tFPIngredientItemRev = NULLTAG;

					tag_t* tFPChildren         = NULL;
					tag_t* tListeIngrChild     = NULL;

					ITK ( BOM_create_window ( &tFPBOMWindowTag ) );
					ITK ( BOM_set_window_top_line ( tFPBOMWindowTag, NULLTAG, objectTag, NULLTAG, &tFPBOMTopLine ) );
					ITK ( BOM_line_ask_all_child_lines ( tFPBOMTopLine, &iFPChildCount, &tFPChildren ) );

					if ( retcode == ITK_ok && iFPChildCount == 0 ) // If BVR present under DRG PF but no child present
					{
						ITK ( CreateIngItem ( &tFPIngredientItem, pcFLEObjectName, pcPFRevID ) );

						if ( retcode == ITK_ok && tFPIngredientItem != NULLTAG )
						{
							tag_t tFPIngredientItemRev = NULLTAG;

							ITK ( ITEM_ask_latest_rev ( tFPIngredientItem, &tFPIngredientItemRev ) );
							ITK ( AttachItemRevToBVR_on_post ( tFPBOMWindowTag, tFPBOMTopLine, tFPIngredientItem, tFPIngredientItemRev ) );

							if ( retcode == ITK_ok )
							{
								ITK ( BOM_close_window ( tFPBOMWindowTag ) );

								ITK ( CreateBVandBVR_on_post ( tFPIngredientItem, tFPIngredientItemRev ) );

								if ( retcode == ITK_ok )
								{
									ITK ( BOM_create_window ( &tIngBOMWindowTag ) );
									ITK ( BOM_set_window_top_line ( tIngBOMWindowTag, NULLTAG, tFPIngredientItemRev, NULLTAG, &tIngBOMTopLine ) );
								}
							}
						}
					}
					else // If BVR present under DRG PF with ING List already present
					{
						ITK ( BOM_line_ask_all_child_lines ( tFPChildren[0], &iListeIngrCount, &tListeIngrChild ) );

						for ( int iInx = 0; iInx < iListeIngrCount; iInx++ )
						{
							ITK ( BOM_line_cut ( tListeIngrChild[iInx] ) ); // Cutting already present children of ING List for fresh INCI calculation
							BOM_save_window ( tFPBOMWindowTag );
						}

						ITK ( BOM_line_ask_attribute_tag ( tFPChildren[0], item_revtag_attribute, &tFPIngredientItemRev ) );

						ITK ( BOM_close_window ( tFPBOMWindowTag ) );

						ITK ( BOM_create_window ( &tIngBOMWindowTag ) );
						ITK ( BOM_set_window_top_line ( tIngBOMWindowTag, NULLTAG, tFPIngredientItemRev, NULLTAG, &tIngBOMTopLine ) );
					}
					if ( tFPChildren != NULL )
					{
						MEM_free ( tFPChildren );
						tFPChildren = NULL;
					}
					if ( tListeIngrChild != NULL )
					{
						MEM_free ( tListeIngrChild );
						tListeIngrChild = NULL;
					}
				}

				ITK ( AOM_ask_value_tags ( tFLEItemRevs[0], STRUCT_REVISIONS, &iFLEBVRCount, &tFLEBVRTags ) );

				if ( tFLEBVRTags != 0 )
				{
					MEM_free ( tFLEBVRTags );
					tFLEBVRTags = NULL;
				}

				if ( iFLEBVRCount != 0 ) // If Formula BVR count is not 0
				{
					ITK ( BOM_create_window ( &tBOMWindowTag ) );
					ITK ( BOM_set_window_pack_all ( tBOMWindowTag, false ) );
					ITK ( BOM_set_window_top_line ( tBOMWindowTag, NULLTAG, tFLEItemRevs[0], NULLTAG, &tTopLine ) );

					if ( tTopLine != NULLTAG )
					{
						char *pcPercentage         = NULL;
						char *pcPercentAttrName    = NULL;

						double fPercentage         = 0.0;

						int iFleChildCount         = 0;

						string sDRGBomError = "";

						tag_t tItemRevTag          = NULLTAG;

						ITK ( BOM_line_ask_all_child_lines ( tTopLine, &iFleChildCount, &tFleChildren ) );

						ITK ( PREF_ask_char_value ( SEEDS_PERCENT_VALUE_ATTRIBUTE, 0, &pcPercentAttrName ) ); // Getting the property value for percentage from preference

						if ( pcPercentAttrName != NULL )
						{
							bool isDRGUnreleasedHeader = false; // Boolean variable to be passed to other function to print Unreleased DRG MP Header in log file.

							if ( iFleChildCount > 0 )
							{
								ITK ( initialise_attribute ( pcPercentAttrName, &iBOMLineQuantityAttrID ) );

								for ( int iInx = 0; iInx < iFleChildCount; iInx++ )
								{
									logical isDRGItemUnreleased = NULL;

									ITK ( BOM_line_ask_attribute_string ( tFleChildren[iInx], iBOMLineQuantityAttrID, &pcPercentage ) );//Got the % of genRM tFleChildren is GemRM

									fPercentage = atof ( pcPercentage );

									if ( pcPercentage != NULL )
									{
										MEM_free ( pcPercentage );
										pcPercentage = NULL;
									}

									ITK ( BOM_line_ask_attribute_tag ( tFleChildren[iInx], item_revtag_attribute, &tItemRevTag ) );//get the item rev tag of gen RM

									ITK ( FetchAndAttachIngredients ( tItemRevTag, fPercentage, tRegRuleTypeTag, tIngBOMWindowTag, tIngBOMTopLine, string ( pcTypeDeDrg ), &head_ptr, vInvalidMPGenItems, vChildlessMPGenItems, isDRGItemUnreleased, sDRGBomError ) );

									if ( isDRGItemUnreleased == TRUE )
									{
										isDRGUnreleasedHeader = true;
									}
									if ( sDRGBomError.compare ( "" ) != 0 ) // Break from the loop and INCI calculation if any Problem with children of Raw material
									{
										break;
									}
								}
								ITK ( SortStructure ( tIngBOMWindowTag, tIngBOMTopLine ) );

								ITK ( CreateLogFile ( objectTag, tInputItemTag, head_ptr, vInvalidMPGenItems, vChildlessMPGenItems, isDRGUnreleasedHeader, sDRGBomError) );

								vInvalidMPGenItems.clear();
								vChildlessMPGenItems.clear();

								if ( head_ptr != NULL )
								{
									/*Memory Cleanup*/
									struct INCIInfo *tmp_ptr = NULL;
									do
									{
										tmp_ptr = head_ptr->next;

										if ( head_ptr->pcRMName != NULL )
										{
											MEM_free ( head_ptr->pcRMName );
											head_ptr->pcRMName = NULL;
										}
										if ( head_ptr->pcOriginalRM != NULL )
										{
											MEM_free ( head_ptr->pcOriginalRM );
											head_ptr->pcOriginalRM = NULL;
										}
										if ( head_ptr->pcDRGType != NULL )
										{
											MEM_free ( head_ptr->pcDRGType );
											head_ptr->pcDRGType = NULL;
										}
										if ( head_ptr->pcDRGStatus != NULL )
										{
											MEM_free ( head_ptr->pcDRGStatus );
											head_ptr->pcDRGStatus = NULL;
										}
										if ( head_ptr->pcINCName != NULL )
										{
											MEM_free ( head_ptr->pcINCName );
											head_ptr->pcINCName = NULL;
										}

										head_ptr->next = NULL;

										MEM_free ( head_ptr );

										head_ptr = tmp_ptr;

									} while ( head_ptr != NULL );
								}
							}
							else
							{
								ITK ( CreateLogFile ( objectTag, tInputItemTag ) );
							}
						}
						if ( pcPercentAttrName != NULL )
						{
							MEM_free ( pcPercentAttrName );
							pcPercentAttrName = NULL;
						}
					}

					if ( tFleChildren != NULL )
					{
						MEM_free ( tFleChildren );
						tFleChildren = NULL;
					}
					if ( pcFLEObjectName != NULL )
					{
						MEM_free ( pcFLEObjectName );
						pcFLEObjectName = NULL;
					}
					if ( pcPFRevID != NULL )
					{
						MEM_free ( pcPFRevID );
						pcPFRevID = NULL;
					}

					ITK ( BOM_close_window ( tIngBOMWindowTag ) );
					ITK ( BOM_close_window ( tBOMWindowTag ) );
				}
				else
				{
					ITK ( CreateLogFile ( objectTag, tInputItemTag ) );
				}
			}
			if ( tFLEItemRevs != NULL )
			{
				MEM_free ( tFLEItemRevs );
				tFLEItemRevs = NULL;
			}
	    }
		if ( pcTypeDeDrg != NULL )
		{
			MEM_free ( pcTypeDeDrg );
			pcTypeDeDrg = NULL;
		}
    }

	if ( (retcode == ITK_ok) && (tc_strcmp(generateQQ.c_str(),"1")== 0) ) // Once INCI calculation is completed, doing quali quanti calculation
	{
		int iIngListRevCount     = 0;

		tag_t tQualiQuantiRelTag = NULLTAG;

		tag_t* tIngListRevTag    = NULL;

		ITK ( TCTYPE_find_type ( QUALI_QUANTI_REL, QUALI_QUANTI_REL, &tQualiQuantiRelTag ) );

		if ( retcode == ITK_ok && tQualiQuantiRelTag != NULLTAG )
		{
			ITK ( GRM_list_primary_objects_only ( objectTag, tQualiQuantiRelTag, &iIngListRevCount, &tIngListRevTag ) );

			if ( retcode == ITK_ok && tIngListRevTag != NULLTAG )
			{
				tag_t tIngItemTag = NULLTAG;

				ITK ( ITEM_ask_item_of_rev	( tIngListRevTag[0], &tIngItemTag ) );

				if ( retcode == ITK_ok && tIngItemTag != NULLTAG )
				{
					tag_t tIngListLatestRev = NULLTAG;

					ITK ( ITEM_ask_latest_rev ( tIngItemTag, &tIngListLatestRev ) );

					if ( retcode == ITK_ok && tIngListLatestRev != NULLTAG )
					{
						int iBVRCount   = 0;

						tag_t* tBVRTags = NULL;

						ITK ( AOM_ask_value_tags ( tIngListLatestRev, STRUCT_REVISIONS, &iBVRCount, &tBVRTags ) );

						if ( retcode == ITK_ok && iBVRCount != 0 )
						{
							int iIngListChildCount = 0;

							tag_t tIngListBOMWindow = NULLTAG;
							tag_t tIngListTopLine   = NULLTAG;

							tag_t* tIngListChildren = NULL;

							ITK ( BOM_create_window ( &tIngListBOMWindow ) );

							ITK ( BOM_set_window_pack_all ( tIngListBOMWindow, false ) );

							ITK ( BOM_set_window_top_line ( tIngListBOMWindow, NULLTAG, tIngListLatestRev, NULLTAG, &tIngListTopLine ) );

							ITK ( BOM_line_ask_all_child_lines ( tIngListTopLine, &iIngListChildCount, &tIngListChildren ) );

							if ( iIngListChildCount == 0 )
							{
								ITK ( PopulatePropsToIngListRev ( tIngListLatestRev, objectTag ) );

								if ( retcode == ITK_ok )
								{
									/*write logic to put bom under tIngListLatestRev*/
									ITK ( CalculateQualiQuanti ( tIngListLatestRev ) );
								}
							}
							if ( iIngListChildCount > 0 )
							{
								tag_t tRevisedIngListRev = NULLTAG;

								/*write logic to revise inglist rev, attach using qq relation*/
								ITK ( ReviseAndAttachQQ ( tIngListLatestRev, tRevisedIngListRev ) );

								if ( retcode == ITK_ok && tRevisedIngListRev != NULLTAG )
								{
									ITK ( PopulatePropsToIngListRev ( tRevisedIngListRev, objectTag ) );

									if ( retcode == ITK_ok )
									{
										ITK ( CalculateQualiQuanti ( tRevisedIngListRev ) );
									}
								}
							}

							if ( tIngListChildren != NULL )
							{
								MEM_free ( tIngListChildren );
								tIngListChildren = NULL;
							}
						}
						if ( retcode == ITK_ok && iBVRCount == 0 )
						{
							ITK ( PopulatePropsToIngListRev ( tIngListLatestRev, objectTag ) );

							if ( retcode == ITK_ok )
							{
								ITK ( CalculateQualiQuanti ( tIngListLatestRev ) );
							}
						}

						if ( tBVRTags != NULL )
						{
							MEM_free ( tBVRTags );
							tBVRTags = NULL;
						}
					}
				}
			}
		}

		if ( tIngListRevTag != NULL )
		{
			MEM_free ( tIngListRevTag );
			tIngListRevTag = NULL;
		}
	}

	}
	MEM_free(extensionArgs);
	return retcode;

}
