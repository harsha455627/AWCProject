/*==================================================================================================

                    Copyright (c) 2009 SIEMENS PLM SOFTWARE INC.
                             Unpublished - All rights reserved
====================================================================================================
File description:

    Filename: FVE_create_update_mail_template.c
    Module  : main

        Used to create and update mail template
        Requires a login account specified by -u=<user> -p=<pass> -g=<group>
===============================================================================
Date               Name                    Description of Change
17-Sep-2014        Shreya Suman              Initial version
15-Sep-2016        Kevin Wedgworth           Changed to use autologin()
===============================================================================*/
#include <time.h>
#include "FV_update_gdx_xsd_utility.h"
#include "FV_prototypes.h"

/* Global Attributes */
char *          login_group                     = NULL;
char *          login_user                      = NULL;
char *          login_password                  = NULL;
FILE *logfileptr = NULL;

/*******************************************************************************
 * NAME: ITK_user_main
 *
 * DESCRIPTION
 *   This utility will read the input file ,create xsd definition dataset if not present . 
 *	 If present will update the named reference attached to the dataset
 *
 * Usage:
 *   FV_update_gdx_xsd_utility -u=user -p=password|-pf=password_file -g=group
 *           -i=input file name -f=xsd definition file location
 *
 * ARGUMENTS
 *   u              In     User name
 *   p              In     Password
 *   pf             In     Password file (COTS autologin)
 *   g              In     Group
 *   i              In     Input definition name
 *   f              In     path of the directory holding the definition files
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 *
 *  Date          Author                 Change Description
 * ----------     -------------------    -----------------------------
 *  July 2015      Shreya Suman            Created
 *
 ******************************************************************************/

extern int ITK_user_main( int argc, char **  argv )
{
    int             ifail                           = ITK_ok;
	int             line_count                      = 0;
    char *          def_file                        = NULL;
    char *          template_home                   = NULL;
    char *          template_name                   = NULL;
    char *          template_file                   = NULL;
    char **         template_rule                   = NULL;
    char            fileline[257]                   = "";
	char            fileline_tmp[257]               = "";
    FILE *          inputfileptr                    = NULL;
	char            logfilename[255 + 1]            = "";
	char *          time_stamp                      = NULL;
    char *          ptr						    = NULL;
	logical         is_template_name_null			=	FALSE;

    /*Append the log file name with the date and time stamp 
    along with Process ID */
    get_time_stamp(DATE_FORMAT_STR, &time_stamp);
    sprintf(logfilename,"FV_update_gdx_xsd_utility_%s.log",time_stamp);

    logfileptr = fopen( logfilename, "w+");
    if (logfileptr == NULL)
    {
        fprintf(stderr, "ERROR: Can not create log file:%s\n", logfilename);
        exit(1);
    }

    printf("\nLog information will be written into %s\n\n",logfilename);
        
    if(logfileptr)
    {        
        fprintf(logfileptr,"Start time: %s\n", time_stamp);
        fprintf(logfileptr,"argc: %d\n", argc);
        FVE_FREE(time_stamp)
    }
    

    if (ITK_ask_cli_argument("-h"))
    {
        print_usage();
        exit(0);
    }

    login_user     = ITK_ask_cli_argument("-u=");
//    login_password = ITK_ask_cli_argument("-p=");
    login_group    = ITK_ask_cli_argument("-g=");
    def_file       = ITK_ask_cli_argument("-i=");
    template_home  = ITK_ask_cli_argument("-f=");

    ITK_initialize_text_services (0);
//    CLEANUP(ITK_init_module (login_user, login_password, login_group))
    ifail = fve_autologin();
    if(ifail != ITK_ok)
    {
        printf("Login with userid: %s, group:%s is unsuccessful\n", login_user, login_group);
        fprintf(logfileptr,"ERROR: Login with uid: %s, group:%s is unsuccessful\n", login_user, login_group);    
        fclose( logfileptr );		
        print_usage();
        exit(0);
    }
    else{
        printf("Login with userid: %s, group:%s is successful\n", login_user, login_group);
	    fprintf(logfileptr,"Login with uid: %s, group:%s is successful\n", login_user, login_group);
	}

  fprintf(logfileptr,"-------------------------------------------------------------------\n\n");

  printf("\n%s",def_file);
    /*Read input file */
		#ifdef UNX
			inputfileptr = fopen( def_file, "r");
		#else
			  fopen_s(&inputfileptr,def_file, "r");
		#endif

    if (!inputfileptr)
    {
       printf("Unable to read definition file , utility terminating.\n\n");
	   fprintf(logfileptr,"Unable to read definition file , utility terminating.\n\n");
       goto CLEANUP;
    }

    /* Process input file */
    while (fgets(fileline, 256, inputfileptr) != NULL) 
    {
      template_name   = NULL;
      template_file   = NULL;

	  fprintf(logfileptr,"Processing for Line Number =%d\n", line_count);
	  fflush(logfileptr);

	  if(fileline && tc_strlen(fileline)> 0){
		tc_strcpy( fileline_tmp, fileline);
		ptr = tc_strtok(fileline_tmp, ",");
		FVE_get_value(ptr, &template_name, &is_template_name_null);

		if(is_template_name_null == FALSE){
		fprintf(logfileptr,"Template Name = %s\n",template_name);
		fflush(logfileptr);

		}
		else{
		fprintf(logfileptr,"Template Name is NULL\n");
		fflush(logfileptr);
		}
	  }

      if (template_name)
      {
		template_file = (char *) tc_strtok(NULL,",");

         if (template_file)
         {           
           fprintf(logfileptr,"Template File = %s\n",template_name);
			fflush(logfileptr);
         }
      }

      /* Create / update Mail Template */      
      ifail = fve_update_xsd_definition(template_name,template_file,template_home);
      if (template_rule) MEM_free(template_rule);

	  fprintf(logfileptr,"After calling fve_update_xsd_definition for Line Number =%d\n", line_count);
	  fprintf(logfileptr,"=======================================================================\n\n");
	  fflush(logfileptr);

    }//End of while loop
    fclose(inputfileptr);
    ITK_exit_module( true );
    printf("Utility completed successfully.\n\n");
    fprintf(logfileptr,"\nUtility completed successfully.\n\n");
    get_time_stamp(DATE_FORMAT_STR, &time_stamp); 
    fprintf(logfileptr,"\nEnd time: %s\n", time_stamp); 
    FVE_FREE(time_stamp); 

	if (logfileptr ) fclose( logfileptr);

    CLEANUP:

    return ifail;
}

/*******************************************************************************
 * NAME: print_usage
 *
 * DESCRIPTION
 *  prints command usage
 *
 * ARGUMENTS
 *   
 *
 * RETURNS
 *   
 *
 * NOTES
 ******************************************************************************/
static void print_usage(void)
{
        printf("\n********************************************************\n");
        printf("Usage: fve_create_update_mail_template <args>\n\n");
        printf(" Where args include the following:\n\n");
        printf(" -u=<login user id>\n");
        printf(" -p=<login password>\n");
        printf(" -pf=<login enc. password file>\n");
        printf(" -g=<login group>\n");
        printf(" -i=definition filename\n");
        printf(" -f=directory holding templates\n");
        printf("\n");
        printf("***********************************************************\n\n");        
}

/* This function checks the tokenised value is null or not */
void FVE_get_value(char * init_value, char ** attr, logical * is_value_null)
{
	if(init_value != NULL)
	{
		*attr = (char *) MEM_alloc ((int)((strlen(init_value) + 1)) * sizeof(char));
		tc_strcpy((*attr), init_value);
	}
	else
		(* is_value_null) = TRUE;
}

/*******************************************************************************
 * NAME: fve_update_xsd_definition
 *
 * DESCRIPTION
 *  Function to create/update mail templates
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *   template_name          In         Name of the template
 *   template_home          In         Full path of the template files
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/

int fve_update_xsd_definition(char * template_name,char * template_file,char * template_home)
{
    int			ifail						= ITK_ok;
    int			num_found					= 0;
    int			inx							= 0;
    tag_t*		objTags						= NULL;
    tag_t		attachmentTypeTag			= NULLTAG;
    tag_t		htmlTypeTag					= NULLTAG;
	tag_t       file_tag					= NULLTAG;
	tag_t       tagDataSet					= NULLTAG;
	char**		att_name					= NULL;
    char**		attr_values					= NULL;
    char*		fullpathname				= NULL;
	int			last_element				= 0;

	fprintf(logfileptr,"Inside fve_update_xsd_definition\n");
	fflush(logfileptr);

    attr_values    = (char **) MEM_alloc(sizeof(char*)*2);
    attr_values[0] = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(attr_values[0],template_name);

    att_name       = (char **) MEM_alloc(sizeof(char*)*2);
    att_name[0]    = (char *) MEM_alloc((sizeof(char)*strlen(template_name))+1);
    tc_strcpy(att_name[0],"object_name");

    fullpathname = (char*) MEM_alloc(sizeof(char)*512);

    sprintf(fullpathname,"%s//%s",template_home,template_file);


	 last_element = tc_strlen(fullpathname);
	 fullpathname[--last_element]='\0';

	 printf(" Template Name is: %s\n",fullpathname);

    fprintf(logfileptr,"Full Path Name =%s\n",fullpathname);
    fflush(logfileptr);	

	 attr_values[0] = template_name;

    /* search for template_name */
    FV_search_objects_by_attrs("Text",1,att_name,attr_values,&num_found,&objTags);
	printf("\nTotal template found %d\n\n",num_found);
	if(num_found >0)
	{		
		fprintf(logfileptr,"Template found,Deleting XSD Template\n");
		fflush(logfileptr);	

		CLEANUP(TCTYPE_find_type  ("Text","",&htmlTypeTag))
       
		   for(inx =0 ;inx<num_found;inx++)
		   {
			   if(inx == 0)
			   {  
				   CLEANUP(TCTYPE_ask_object_type(objTags[inx], &attachmentTypeTag ))
				   if ((attachmentTypeTag == htmlTypeTag))
				   {  
					   printf("Deleting template....\n");
					   CLEANUP(fve_delete_template(objTags[inx]))
					   printf("Template Deleted Successfully....\n");
				   }
			   }
		   }
	    fprintf(logfileptr,"Existing Template Deleted\n");
		fflush(logfileptr);
	}
	    /* search for template_name */
    FV_search_objects_by_attrs("Text",1,att_name,attr_values,&num_found,&objTags);
	TC_write_syslog("Total template found after Delete %d\n\n",num_found);

	if(num_found == 0)
	{
	  printf("Creating template....\n");
	  fprintf(logfileptr,"Creating XSD Template\n");
	  fflush(logfileptr);
	  CLEANUP( fve_create_dataset (template_name,"","Text",&tagDataSet))
	  CLEANUP( AOM_refresh(tagDataSet, false ))
	  CLEANUP( fve_import_file(fullpathname,&file_tag))
      CLEANUP( fve_attach_file (tagDataSet,file_tag,"Text"))
	  CLEANUP( fve_attach_template_to_folder (tagDataSet))
	  fprintf(logfileptr,"XSD Template Created\n");
	  fflush(logfileptr);
	  printf("Template Created Successfully....\n");
    }

	

CLEANUP:
    if (objTags)      MEM_free(objTags);
    if (attr_values)  MEM_free(attr_values);
    if (att_name)     MEM_free(att_name);
    if (fullpathname) MEM_free(fullpathname);
    
    return ifail;

}


/*====================================================================================================================================================
Function     :  fve_create_dataset

Description  :  Function to create dataset

input        :  
pchDatasetName - Name of Dataset
pchDatasetDesc - Description of the dataset
pchDatasetType - Dataset type

Output       :   tagDataSet     - Tag of dataset


Return value :  ITK_ok if successfully completed
non zero value on error 

=====================================================================================================================================================*/
int fve_create_dataset (char  *pchDatasetName,char  *pchDatasetDesc,char  *pchDatasetType,tag_t *tagDataSet)
{
    int   ifail          = ITK_ok;
    tag_t tagDatasetType = NULLTAG;
    tag_t tagToolTag     = NULLTAG;

    if ((ifail = AE_find_datasettype (pchDatasetType, &tagDatasetType)) != ITK_ok)
    {
        TC_write_syslog( " Failed to find dataset type \n");
        return ifail;
    }

    if (tagDatasetType == NULLTAG)
    {
        TC_write_syslog( "  dataset type tag is NULL\n");
        return !ITK_ok;
    }

    ifail = AE_ask_datasettype_def_tool (tagDatasetType,&tagToolTag);

    if (tagToolTag == NULLTAG)
    {
        TC_write_syslog( " dataset Tool is NULL \n");
        return !ITK_ok;
    }


    if ((ifail = AE_create_dataset_with_id (tagDatasetType, pchDatasetName, \
        pchDatasetDesc, 0, 0, tagDataSet)) != ITK_ok)
    {
		 TC_write_syslog( "After AE_create_dataset_with_id, dataset is NULL \n");
        return ifail;
    }

    if ((ifail = AE_set_dataset_tool (*tagDataSet, tagToolTag)) != ITK_ok)
    {
		TC_write_syslog( "Failed to set Dataset Tool \n");
        return ifail;
    }

    if ((ifail = AOM_save (*tagDataSet)) != ITK_ok)
    {
        return ifail;
    }

	TC_write_syslog( " Dataset Created and Saved \n");

    return ifail;
}

/*====================================================================================================================================================
Function     :  fve_delete_template

Description  :  Function to delete dataset

input        :  
dataset - Tag of Dataset
Return value :  ITK_ok if successfully completed
non zero value on error 

=====================================================================================================================================================*/

int fve_delete_template (tag_t	dataset)
{
	int		ifail						= ITK_ok ;
    int		num_contents_home			= 0;
	int		num_contents_temp_folder	= 0;
	int		i							= 0;
	tag_t	userTag						= NULLTAG;
	tag_t	homeFolderTag				= NULLTAG;
	tag_t	template_folder_tag			= NULLTAG;
	tag_t   latestTag					= NULLTAG;
	tag_t*	home_content_tags			= NULL;
	tag_t*	template_content_tags		= NULL;
	char*	userName					= NULL;
	char*	folder						= NULL;
	char*	datasetName					= NULL;
	char*	tempName					= NULL;

	TC_write_syslog("Entering fve_delete_template \n");

		CLEANUP( AE_ask_dataset_latest_rev(dataset,&latestTag))
		if(latestTag != NULLTAG)
		{
			CLEANUP( POM_get_user(&userName,&userTag))
			CLEANUP( SA_ask_user_home_folder(userTag, &homeFolderTag))
			CLEANUP( AOM_ask_value_tags(homeFolderTag, "contents", &num_contents_home, &home_content_tags))
			TC_write_syslog ("num_contents_home = %d\n", num_contents_home);
			for( i = 0; i < num_contents_home; i++)
			{
				CLEANUP(AOM_ask_name(home_content_tags[i], &folder))
				if(tc_strcmp(folder, GDX_XSD_TEMPLATE_FOLDER) == 0)
				{
					template_folder_tag = home_content_tags[i];
					break;
				}
				FVE_FREE(folder)
			}
			FVE_FREE(home_content_tags)

			if(template_folder_tag != NULLTAG)
			{
				CLEANUP( AOM_ask_value_tags(template_folder_tag, "contents", &num_contents_temp_folder, &template_content_tags))
				TC_write_syslog ("num_contents_temp_folder = %d\n", num_contents_temp_folder);
				CLEANUP(AOM_ask_name(latestTag, &datasetName))
				TC_write_syslog ("latestTag = %s\n", datasetName);
				for( i = 0; i < num_contents_temp_folder; i++)
				{
					CLEANUP(AOM_ask_name(template_content_tags[i], &tempName))			
					if(tc_strcmp(datasetName, tempName) == 0)
					{
						CLEANUP(FL_remove(template_folder_tag,template_content_tags[i]))
						CLEANUP(AOM_save(template_folder_tag))
						CLEANUP(AOM_refresh(template_folder_tag,false))
						TC_write_syslog ("Template = %s Removed\n", tempName);
						break;
					}
					FVE_FREE(tempName)
				}
			}
			FVE_FREE(template_content_tags)
			FVE_FREE(datasetName)
	   }
	   CLEANUP(AOM_lock_for_delete(dataset))
	   CLEANUP(AE_delete_all_dataset_revs(dataset))
	
CLEANUP:
	if (userName)      MEM_free(userName);
	TC_write_syslog("Exiting fve_delete_template \n");
	return ifail;
}


/******************************************************************************
Function     :  fve_import_file

Description  :  Function to import file to TC

input        :  file  - filename that needs to be imported

Output       :  file_tag - file tag


Return value :  if successfull ITK_ok else non-zero number


*******************************************************************************/
int fve_import_file(char  *file,tag_t *file_tag)
{
    int ifail = ITK_ok;
    IMF_file_t file_desc;
    *file_tag = NULLTAG;

	TC_write_syslog("\n Importing File : %s\n" , file);
    if ((ifail = IMF_import_file (file, NULL, SS_TEXT, file_tag,&file_desc)) != ITK_ok)
    {
        TC_write_syslog(" IMF_import_file failed %d\n",ifail);
        return ifail;
    }
    if (*file_tag == NULLTAG)
    {
        TC_write_syslog("file_tag is NULL \n");
        return !ITK_ok;
    }
    if ((ifail = IMF_close_file (file_desc)) != ITK_ok)
    {
		TC_write_syslog(" IMF_close_file failed %d\n",ifail);
        return ifail;
    }

    if ((ifail = AOM_save (*file_tag)) != ITK_ok)
    {
        return ifail;
    }
    TC_write_syslog("\n File : %s. IMPORTED\n" , file);
    return ifail;
}

/******************************************************************************
Function     :  fve_attach_file

Description  :  Function to TC file to dataset

input        :  
dataset       - Tag of dataset
file_tag,				 - TC file tag
dst_type			   - dataset type

Output       :  


Return value :  If successful ITK_ok else non-zero number 

*******************************************************************************/
int fve_attach_file (tag_t	dataset,tag_t	file_tag,char	*dst_type )
{
    int ifail                                 = ITK_ok;
    int ref_count                             = 0;
    int lock_type                             = 0;
    logical verdict                           = FALSE;
    char	strNamedRef[AE_reference_size_c + 1] = "\0";

	
    AE_reference_type_t ref_type  = AE_PART_OF;

    tc_strcpy(strNamedRef, dst_type);

    if ((ifail = POM_is_loaded (dataset, &verdict)) != ITK_ok)
    {
		TC_write_syslog("\n POM_is_loaded failed \n");
        return ifail;
    }

    if (verdict == FALSE)
    {
        if ((ifail = AOM_load (dataset)) != ITK_ok)
        {
			TC_write_syslog("\n AOM_load Failed \n");
            return ifail;
        }
    }

    if ((ifail = POM_ask_instance_lock (dataset, &lock_type)) != ITK_ok)
    {
		TC_write_syslog("\n Error getting Lock on Dataset Object\n");
        return ifail;
    }

    if (lock_type != POM_modify_lock)
    {
        if ((ifail = AOM_lock (dataset)) != ITK_ok)
        {
            return ifail;
        }
    }

    if ((ifail = AE_ask_dataset_ref_count (dataset, &ref_count)) != ITK_ok)
    {
        return ifail;
    }

    if (ref_count > 0)
    {
        if ((ifail = AE_remove_dataset_named_ref (dataset,strNamedRef)) != ITK_ok)
        {
			TC_write_syslog("\n Dataset named Ref not removed \n");
            return ifail;
        }
    }

    if ((ifail = AE_add_dataset_named_ref (dataset, strNamedRef, \
        ref_type, file_tag)) != ITK_ok)
    {
		TC_write_syslog("\n error in attaching named reference \n");
        return ifail;
    }

    if ((ifail = AOM_save (dataset)) != ITK_ok)
    {
        return ifail;
    }

    if ((ifail = AOM_unlock (dataset)) != ITK_ok)
    {
        return ifail;
    }

    return ifail;
}


/******************************************************************************
Function     :  fve_attach_template_to_folder

Description  :  Function to attach dataset to "Mail Templates" Folder 
				Under Infodba's Home Folder

input        :  
dataset       - Tag of dataset

Output       :  
Return value :  If successful ITK_ok else non-zero number 

*******************************************************************************/
int fve_attach_template_to_folder (tag_t	dataset)
{
	int		ifail						= ITK_ok;
	int		num_contents_home			= 0;
	int		num_contents_temp_folder	= 0;
	int		i							= 0;
	int		match_cnt					= 0;
	tag_t	userTag						= NULLTAG;
	tag_t	homeFolderTag				= NULLTAG;
	tag_t	template_folder_tag			= NULLTAG;
	tag_t*	home_content_tags			= NULL;
	tag_t*	template_content_tags		= NULL;
	char*	userName					= NULL;
	char*	folder						= NULL;
	char*	datasetName					= NULL;
	char*	tempName					= NULL;
	char*	mailTemplateFolderName		= "GDX XSD Templates";

		TC_write_syslog("\n Entering fve_attach_template_to_folder \n");

		CLEANUP( POM_get_user(&userName,&userTag))
		CLEANUP( SA_ask_user_home_folder(userTag, &homeFolderTag))

		CLEANUP( AOM_ask_value_tags(homeFolderTag, "contents", &num_contents_home, &home_content_tags))
		TC_write_syslog ("num_contents_home = %d\n", num_contents_home);

		for( i = 0; i < num_contents_home; i++)
		{
			CLEANUP(AOM_ask_name(home_content_tags[i], &folder))
			if(tc_strcmp(folder, mailTemplateFolderName) == 0)
			{
				match_cnt++;
			}
			FVE_FREE(folder)

			if(match_cnt > 0)
			{
				template_folder_tag = home_content_tags[i];
				break;
			}
		}

		if(match_cnt == 0)
		{
			AM__set_application_bypass(TRUE);
			CLEANUP(FV_FL_create("GDX XSD Templates", "XSD Templates Folder", &template_folder_tag))
			CLEANUP(AOM_save(template_folder_tag))
			CLEANUP(FL_insert(homeFolderTag, template_folder_tag, num_contents_home))
			CLEANUP(AOM_save(homeFolderTag))
			AM__set_application_bypass(FALSE);
		}

		FVE_FREE(home_content_tags)

		CLEANUP( AOM_ask_value_tags(template_folder_tag, "contents", &num_contents_temp_folder, &template_content_tags))
		TC_write_syslog ("num_contents_temp_folder = %d\n", num_contents_temp_folder);

		match_cnt =0;
		CLEANUP(AOM_ask_name(dataset, &datasetName))
		for( i = 0; i < num_contents_temp_folder; i++)
		{
			CLEANUP(AOM_ask_name(template_content_tags[i], &tempName))			
			if(tc_strcmp(datasetName, tempName) == 0)
			{
				match_cnt++;
			}
			FVE_FREE(tempName)

			if(match_cnt > 0)
			{
				TC_write_syslog ("template %s already exists in Folder\n", datasetName);
				template_folder_tag = template_content_tags[i];
				break;
			}
		}

		if(match_cnt == 0)
		{
			AM__set_application_bypass(TRUE);
			CLEANUP( AOM_refresh(template_folder_tag,true))
			CLEANUP( AOM_refresh(dataset,false))
			CLEANUP( FL_insert(template_folder_tag, dataset, num_contents_temp_folder))
			CLEANUP( AOM_save(template_folder_tag))
			CLEANUP( AOM_refresh(template_folder_tag,false))
			AM__set_application_bypass(FALSE);
		}
		FVE_FREE(template_content_tags)


CLEANUP:
	
	FVE_FREE(userName)
	FVE_FREE(datasetName)
	TC_write_syslog("\n Exiting fve_attach_template_to_folder \n");
	return ifail;
}
