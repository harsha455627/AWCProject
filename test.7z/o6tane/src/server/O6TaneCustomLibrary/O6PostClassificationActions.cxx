//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6PostClassificationActions
 *
 */
#include <O6TaneCustomLibrary/O6PostClassificationActions.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <metaframework/CreateInput.hxx>
#include <tccore/method.h>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tccore/tctype.h>
#include <ics/ics.h>
#include <ics/ics2.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <pom/enq/enq.h>


#define ENQ_ID "O6_pomenq006"
#define TEST_POOL_ATTR "o6_test_pool"
#define TEST_REVISION "O6_TestRevision"
#define PRIMARY_OBJ_ATTR "primary_object"
#define SECONDARY_OBJ_ATTR "secondary_object"
#define CID_ATTR "cid"
#define SMLB0_CLASS "smlb0"
#define EXT_1_ATTR "ext_1"
#define EXPR "O6_exp1"


/**
 * Function    :  O6PostClassificationActions
 * Description :  Copies value of ext_1 attribute on smlb0 class to o6_test_pool
 * 				  attribute on Test Revision.
 * Input
 * 		args - Arguments
 */
int O6PostClassificationActions( METHOD_message_t * /*msg*/, va_list args )
{
    int retcode = ITK_ok;
	bool isNull = true;

	tag_t primaryObj = NULLTAG;

	va_list largs;
	va_copy( largs, args);
	Teamcenter::CreateInput *creInput = va_arg(largs, Teamcenter::CreateInput*);
	va_end( largs );

	ITK(creInput->getTag(PRIMARY_OBJ_ATTR, primaryObj, isNull));
	if ((isNull == FALSE) && (retcode == ITK_ok) && primaryObj != NULLTAG) {
		tag_t primaryObjType = NULLTAG;

		ITK(TCTYPE_ask_object_type(primaryObj, &primaryObjType));
		if (retcode == ITK_ok && primaryObjType != NULLTAG ) {

			char* primobjtypename = NULL;
			ITK(TCTYPE_ask_name2(primaryObjType, &primobjtypename));
			if (retcode == ITK_ok && primobjtypename != NULL) {
				if (tc_strcmp(primobjtypename, TEST_REVISION) == 0) {
					//logical isClassified = FALSE;
					tag_t classificationObject = NULLTAG;
					isNull = true;
					ITK(creInput->getTag(SECONDARY_OBJ_ATTR, classificationObject, isNull));
					if ((isNull == FALSE) && (retcode == ITK_ok)
							&& classificationObject != NULLTAG ) {
						tag_t classTag = NULLTAG;
						ITK(ICS_ask_class_of_classification_obj(classificationObject, &classTag));
						if (retcode == ITK_ok && classTag != NULLTAG ) {
							char* classID = NULL;
							ITK(AOM_ask_value_string(classTag, CID_ATTR, &classID));
							if (retcode == ITK_ok && classID != NULL) {

								char* cls_id = (char*) MEM_alloc(sizeof(char) * (tc_strlen(classID) + 1));
								tc_strcpy(cls_id, classID);
								MEM_free(classID);
								classID = NULL;

								/**
								 * Since there is no direct relation exists from classification
								 * icm0 and cmlb0 class used POM query.
								 */
								ITK(POM_enquiry_create(ENQ_ID));
							    const char * enq_select_attrs[] = {EXT_1_ATTR};
							    ITK(POM_enquiry_add_select_attrs(ENQ_ID, SMLB0_CLASS, 1, enq_select_attrs));
							    ITK(POM_enquiry_set_string_expr(ENQ_ID, EXPR, SMLB0_CLASS, CID_ATTR, POM_enquiry_equal, cls_id));
							    ITK(POM_enquiry_set_where_expr (ENQ_ID, EXPR));

							    void ***result = NULL;
							    int rows = 0;
							    int columns = 0;
							    ITK(POM_enquiry_execute(ENQ_ID, &rows, &columns, &result));
							    if (retcode == ITK_ok && rows > 0 && result != NULL)
							    {
							        if(rows == 1)
							        {
							          if(result[0][0] != NULL && tc_strlen((char*)result[0][0]) > 0){

							        	  ITK(AOM_refresh(primaryObj, true));
							        	  ITK(AOM_set_value_string(primaryObj, TEST_POOL_ATTR, ((char*)result[0][0])));
							        	  ITK(AOM_save_without_extensions(primaryObj));
							        	  ITK(AOM_unlock(primaryObj));
							          }
							        }
							        else
							        {
							        	TC_write_syslog("\nSEEDS Error : More than one class ids found in Classification Admin for class :%s",cls_id);
							        }

							        MEM_free(result);
							        result = NULL;
							    }
							    ITK(POM_enquiry_delete(ENQ_ID));

							    MEM_free(cls_id);
							    cls_id = NULL;
							}
						}
					}
				}
				MEM_free(primobjtypename);
				primobjtypename = NULL;
			}
		}
	}


 return retcode;

}
