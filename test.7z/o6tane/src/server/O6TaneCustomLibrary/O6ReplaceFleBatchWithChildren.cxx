//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension O6ReplaceFleBatchWithChildren
 *
 */
#include <O6TaneCustomLibrary/O6ReplaceFleBatchWithChildren.hxx>
#include <O6TaneCustomLibrary/O6SeedsCommon.hxx>
#include <stdarg.h>
#include <ug_va_copy.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <bom/bom.h>
#include <tccore/tctype.h>

#define OBJECT_TYPE "object_type"
#define FLE_REV "O6_FleRevision"
#define FLE_BATCH_REV_TYPE "O6_FleBatchRevision"

/**
 * Bomline attributes declaration.
 */
static int item_revtag_attribute;

/**
 * Function    :  initialise
 * Description :  Search BOM attributes and initialize.
 * Input       :
 */
static int initialise (void)
  {
    int retcode = ITK_ok;

    ITK(BOM_line_look_up_attribute (bomAttr_lineItemRevTag, &item_revtag_attribute));
    return retcode;
  }

/**
 * Function    :  O6ReplaceFleBatchWithChildren
 * Description :  Used to replace FLEBatch item revision with its children for FLE Revision as parent.
 * Input       :
 *      msg 		 - Input msg for extension
 *      args         - Input args for extension
 * Output	   :
 * 		none
 */
int O6ReplaceFleBatchWithChildren( METHOD_message_t * /*msg*/, va_list args )
{
		int retcode = ITK_ok;
		tag_t parent_tag = NULLTAG;
		tag_t item_tag = NULLTAG;
		tag_t itemRev_tag = NULLTAG;
		tag_t bv_tag = NULLTAG;
		char* occType = NULL;
		tag_t *newBomline_tag = NULL;

		va_list largs;
		va_copy( largs, args);

			parent_tag = va_arg(largs, tag_t);
			item_tag = va_arg(largs, tag_t);
			itemRev_tag = va_arg(largs, tag_t);
			bv_tag = va_arg(largs, tag_t);
			occType = va_arg(largs, char*);
			newBomline_tag = va_arg(largs, tag_t*);
		va_end( largs );
		
		if(*newBomline_tag != NULLTAG && parent_tag != NULLTAG){

			/**
			 * Initialize bom attributes
			 */
			ITK(initialise());

			tag_t fleItemRevTag = NULLTAG;
			ITK(BOM_line_ask_attribute_tag (parent_tag, item_revtag_attribute, &fleItemRevTag));
			if (retcode == ITK_ok && fleItemRevTag != NULLTAG ) {
				tag_t flerevTypeTag = NULLTAG;
				ITK(TCTYPE_ask_object_type(fleItemRevTag, &flerevTypeTag));
				if (retcode== ITK_ok && flerevTypeTag != NULLTAG ) {
					logical answerFlg = FALSE;
					ITK(TCTYPE_is_type_of_as_str(flerevTypeTag,FLE_REV,&answerFlg));
					if(retcode == ITK_ok && answerFlg == TRUE){

						tag_t fleBatchRevtag = NULLTAG;
						ITK(BOM_line_ask_attribute_tag (*newBomline_tag, item_revtag_attribute, &fleBatchRevtag));
						if (retcode == ITK_ok && fleBatchRevtag != NULLTAG ) {
							tag_t fleBatchRevTypeTag = NULLTAG;
							ITK(TCTYPE_ask_object_type(fleBatchRevtag, &fleBatchRevTypeTag));
							if (retcode== ITK_ok && fleBatchRevTypeTag != NULLTAG ) {
								logical answerFlg = FALSE;
								ITK(TCTYPE_is_type_of_as_str(fleBatchRevTypeTag,FLE_BATCH_REV_TYPE,&answerFlg));
								if(retcode == ITK_ok && answerFlg == TRUE){
                                    int nChilds =0;
                                    tag_t *tchildren = NULL;
									ITK(BOM_line_ask_all_child_lines(*newBomline_tag,&nChilds,&tchildren));
									if(retcode == ITK_ok && nChilds > 0){
										tag_t newline = NULLTAG;
										for(int indx=0; indx < nChilds && retcode == ITK_ok; indx++){
											newline = NULLTAG;
											ITK(BOM_line_copy(parent_tag,tchildren[indx],NULLTAG, &newline));
										}
										if(retcode == ITK_ok){
											tag_t winTag = NULLTAG;
											ITK(BOM_line_ask_window(parent_tag, &winTag));
											ITK(BOM_save_window(winTag));
										}

										MEM_free(tchildren);
										tchildren = NULL;
									}
								}
							}
						}
					}
				}
			}
		}

		return retcode;
}
