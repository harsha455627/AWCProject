/******************************************************************************
 * Filename        :   FVDT_import_std_data.h
 * Description     :   Defines the macro used in FVDT_import_std_data.c
 * Module          :   FVDT_import_std_data.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date                 Name              Description of Change
 * June,9 2016     Bhagwan Moondra           Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/
#pragma once
#ifndef FVDT_IMPORT_STD_DATA_H
#define FVDT_IMPORT_STD_DATA_H

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <FV_includes.h>
#include "PasswdFunction.h"

/*************************************************
* Macros Definition
**************************************************/

#define OBJ_NAME_ATTR			"object_name"
#define COMP_NAME_ATTR			"FVDTCompName"
#define SIG_NAME_ATTR			"FVDTSignalName"
#define SIG_SUB_SYS_NAME_ATTR			"FVDTSigSubSysName"
#define SIG_SYS_NAME_ATTR			"FVDTSigSysName"
#define SIG_CIRCUIT_NUM_ATTR			"FVDTCircuitNum"
#define SIG_ABB_SIG_NAME_ATTR			"fv9AbbSignalName"
#define STATUS_ATTR                 "fv9Status"

#define COMP_CLASSNAME_CONST			"FVDTStdCompName"
#define SIG_CLASSNAME_CONST			"FVDTStdSignalName"
#define COMP_SYSTEM_REVIEWER        "fv9SystemReviewer"
#define COMP_DESIGNATION            "fv9ComponentDesignation"

#define DEVICE_CODE_ATTR            "fv9DeviceCode"
#define DEVICE_NAME_ATTR            "fv9DeviceName"
#define SCHEMATIC_ATTR              "fv9SchematicNum"
#define COMP_CLASS_ATTR             "fv9CompClass"

#define PASSWORDKEY     "PASSWORDKEY"
#define DT_TMP_DIR_VAR  "FVDT_UTIL_IMP_LOG_DIR"

#define OBSOLETE        "Obsolete"
#define ACTIVE          "Active"
#define IMPORT_DATE_FORMAT_STR			"%m%d%Y_%H%M%S"

//#define ITK(x) \
//{\
//   if ( ifail == ITK_ok )\
//   {\
//      if((ifail = (x)) != ITK_ok)\
//      {\
//         dump_itk_errors ( ifail, #x, __LINE__, __FILE__ );\
//      }\
//   }\
//}\


#define FVDT_FREE(p) {\
    if ( p != NULL ) {\
        MEM_free(p);\
        p = NULL;\
    }\
}

#define FVDT_FREE_ARRAY(p, count) {\
	int i = 0;\
   if ( p != NULL ) {\
        for(i = 0; i < count; i++) {\
            if(p[i] != NULL) {\
                MEM_free(p[i]);\
                p[i] = NULL;\
            }\
        }\
        MEM_free(p);\
        p = NULL;\
    }\
}\

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, 
                    const char * fileName );
void get_time_stamp(char* format, char** timestamp);
int FVDT_WSO_uniq_check(char* Attributes, char*className, tag_t* obj);
int FVE_create_name(char ** Attributes, int * created_cnt, char *className,
                    int * failed_cnt, tag_t* objCreated);
int FVDT_update_wso_obj(tag_t ObjInputTag, char* classname, char** Attributes, int* num_updates_actv, int* num_updates_oblt, int* num_failed);
int FVDT_validate_data_in_file (char ** Attributes, int count, char *classname, int line_count,logical *isValid);
int set_wso_obsolete(char* class_name, int cnt_psf, tag_t* psf_tags, int* num_obsoleted);
int set_wso_status(tag_t obj, char* status);
void get_device_detail(char* attribute, char** device_code, char** device_name);
void update_all_devices_codes_names();
char *trim(char *str);
int parse_delimited_string(const char* delimitedString, char* delimiterChars, logical trim_blanks,
	                              int* stringCnt, char*** stringArray);
#endif /* FVDT_IMPORT_STD_DATA_H */
