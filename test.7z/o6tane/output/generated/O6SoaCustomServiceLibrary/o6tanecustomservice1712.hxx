/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_12_O6TANECUSTOMSERVICE_HXX 
#define TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_12_O6TANECUSTOMSERVICE_HXX


#include <bom/BOMLine.hxx>
#include <teamcenter/soa/server/ServiceData.hxx>



#include <teamcenter/soa/server/ServiceException.hxx>
#include <metaframework/BusinessObjectRef.hxx>

#include <CustomServiceLibrary_exports.h>

namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmStream; }}}}
namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmParser; }}}}


namespace O6
{
    namespace Soa
    {
        namespace CustomServiceLibrary
        {
            namespace _2017_12
            {
                class O6TaneCustomService;
            }
        }
    }
}


class SOACUSTOMSERVICELIBRARY_API O6::Soa::CustomServiceLibrary::_2017_12::O6TaneCustomService

{
public:

    static const std::string XSD_NAMESPACE;




    O6TaneCustomService();
    virtual ~O6TaneCustomService();
    

    /**
     * .
     *
     * @param obj
     *        This is the Teamcenter::BOMLine
     *
     * @return
     *
     */
    virtual Teamcenter::Soa::Server::ServiceData calculateQSP ( const BusinessObjectRef<Teamcenter::BOMLine>& obj ) = 0;


};

#include <CustomServiceLibrary_undef.h>
#endif

