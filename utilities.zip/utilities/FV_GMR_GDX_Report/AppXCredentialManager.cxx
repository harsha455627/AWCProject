//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================



#include <teamcenter/clientx/AppXCredentialManager.hxx>

#include <iostream>


#include <teamcenter/soa/client/CanceledOperationException.hxx>

using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Soa::Client;
using namespace Teamcenter::Schemas::Soa::_2006_03::Exceptions;


AppXCredentialManager::AppXCredentialManager()
    :credentials( "","","", "","SoaAppX")
{

}


/**
    * Return the type of credentials this implementation provides,
    * standard (user/password) or Single-Sign-On. In this case
    * Standard credentials are returned.
    *
    */
CredentialManager::CredentialsType AppXCredentialManager::getCredentialType()
{
    return CredentialManager::USERPASSWORD;
}

/**
    * Prompt's the user for credentials.
    * This method will only be called by the framework when a login attempt has
    * failed.
    *
    */
CredentialManager::Credentials AppXCredentialManager::getCredentials(InvalidCredentialsException e)
{
    cout <<  e.getMessage() << endl;
    return promptForCredentials();
}

/**
    * Return the cached credentials.
    * This method will be called when a service request is sent without a valid
    * session ( session has expired on the server).
    *
    */
CredentialManager::Credentials AppXCredentialManager::getCredentials(InvalidUserException e)
{
    // Have not logged in yet, shoult not happen but just in case
    if (credentials.username.length() == 0)
        return promptForCredentials();



    // Return cached credentials
    return credentials;
}

/**
    * Cache the group and role
    * This is called after the SessionService.setSessionGroupMember service
    * operation is called.
    *
    */
void AppXCredentialManager::setGroupRole(const std::string& group, const std::string& role)
{
    credentials.group = group;
    credentials.role  = role;
}

/**
    * Cache the User and Password
    * This is called after the SessionService.login service operation is called.
    *
    */
void AppXCredentialManager::setUserPassword(const std::string& user, const std::string& password, const std::string& discriminator)
{
    credentials.username      = user;
    credentials.securetoken   = password;
    credentials.descriminator = discriminator;
}


CredentialManager::Credentials AppXCredentialManager::promptForCredentials()
{
    cout << "Please enter user credentials ('exit' to quit):" << endl;
    cout << "User Name: ";
    cin >> credentials.username;

    if (credentials.username == "exit")
        throw CanceledOperationException("");

    cout << "Password:  ";
    cin >> credentials.securetoken;

    return credentials;
}


