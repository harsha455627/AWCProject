//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#include <teamcenter/clientx/AppXRequestListener.hxx>

#include <iostream>


using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Soa::Client;

void AppXRequestListener::serviceRequest ( const ServiceInfo& /*info*/  )
{
     // will log the service name when done
}

void AppXRequestListener::serviceResponse( const ServiceInfo& info  )
{
    cout <<  info.id  << ": " << info.service << "." << info.operation << endl;
}


