/*
 * @file
 *
 *   This file contains the implementation of the xml parsing using apache xerces parser.
 *
 */

#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/parsers/AbstractDOMParser.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMImplementationRegistry.hpp>
#include <xercesc/dom/DOMLSParser.hpp>
#include <xercesc/dom/DOMException.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMError.hpp>
#include <xercesc/dom/DOMLocator.hpp>
#include <xercesc/dom/DOMNamedNodeMap.hpp>
#include <xercesc/dom/DOMAttr.hpp>
#include <O6TaneCustomLibrary/O6ParseObjMapXML.hpp>
#include <string.h>
#include <stdlib.h>
#include <cstdio>

#if defined(XERCES_NEW_IOSTREAMS)
#include <fstream>
#else
#include <fstream.h>
#endif

#define OBJ_NODE "DocType"
#define ATTR_NODE "attribute"
#define ATTR_NAME "name"

using namespace std;

/**
 * Function    :  readChildElements
 * Description :  Traverse the xml in recursively and create a link list of objects.
 *
 * Input       :
 *		node	- XML node
 *
 * Output
 * 		start	- Start pointer of a object link list.
 * 		rear	- Rear pointer of a object link list.
 */
int readChildElements(DOMNode *node, doc_types_t **start, doc_types_t **rear) {
	int retcode = ITK_ok;

	DOMNode *child;
	if (node != NULL) {
		if (node->getNodeType() == DOMNode::ELEMENT_NODE) {

			char *nodename = XMLString::transcode(node->getNodeName());
			if (nodename != NULL) {
				if (tc_strcmp(nodename, OBJ_NODE) == 0 || tc_strcmp(nodename, ATTR_NODE) == 0) {
					//TC_write_syslog("\node%s", nodename);

					if (node->hasAttributes()) {
						// get all the attributes of the node
						DOMNamedNodeMap *pAttributes = node->getAttributes();
						const XMLSize_t nSize = pAttributes->getLength();

						for (XMLSize_t i = 0; i < nSize; ++i) {
							DOMAttr *pAttributeNode = (DOMAttr*) pAttributes->item(i);
							// get attribute name
							char *attrname = XMLString::transcode(pAttributeNode->getName());
							if (attrname != NULL && tc_strcmp(attrname, ATTR_NAME) == 0) {
								//TC_write_syslog("\node%s", attrname);
								XMLString::release(&attrname);

								// get attribute type
								char* attrval = XMLString::transcode(pAttributeNode->getValue());
								if (attrval != NULL && tc_strlen(attrval) > 0) {

									std::string localVal(attrval);
									XMLString::release(&attrval);

									if (tc_strcmp(nodename, OBJ_NODE) == 0) {

										/**
										 * Create a objects link list
										 */
										doc_types_t* tmpnode = NULL;
										tmpnode = (doc_types_t*)MEM_alloc(sizeof(doc_types_t) * 1);
										tmpnode->next = NULL;

										tmpnode->type_name = (char*) MEM_alloc(sizeof(char) * (tc_strlen(localVal.c_str()) + 1));
										tc_strcpy(tmpnode->type_name,localVal.c_str());

										if (*start == NULL && *rear == NULL) {
											*start = tmpnode;
											*rear = tmpnode;
										} else if(*rear != NULL){
											(*rear)->next = tmpnode;
											*rear = (*rear)->next;
										}
									}
								}
							}
						}
					}
				}
				XMLString::release(&nodename);
			}
		}
		for (child = node->getFirstChild(); child != NULL; child = child->getNextSibling()) {
			readChildElements(child, start, rear);
		}
	}
	return retcode;
}

/**
 * Function    :  parseXml
 * Description :  Helper function to read XML and parse.
 *
 * Input       :
 *		xmlFilePath	- XML input file path
 *
 * Output
 * 		start	- Start pointer of a object link list.
 * 		rear	- Rear pointer of a object link list.
 */
int parseXml(char* xmlFilePath, doc_types_t **start, doc_types_t **rear) {
	int retcode = ITK_ok;

	if (xmlFilePath != NULL) {

		// Initialize the XML4C system
		try {
			XMLPlatformUtils::Initialize();
		} catch (const XMLException& /*toCatch*/) {
			TC_write_syslog("\nSEEDS Error : Error while initializing xml parser.");
			retcode = SEEDS_XML_ERROR;
		}

		// Instantiate the DOM parser.
		static const XMLCh gLS[] = { chLatin_L, chLatin_S, chNull };
		DOMImplementation *impl = DOMImplementationRegistry::getDOMImplementation(gLS);
		if (impl != NULL) {

			DOMLSParser *parser = ((DOMImplementationLS*) impl)->createLSParser(DOMImplementationLS::MODE_SYNCHRONOUS, 0);
			if (parser != NULL) {
				DOMConfiguration *config = parser->getDomConfig();
				if (config != NULL) {

					// And create our error handler and install it
					DOMXMLErrorHandler errorHandler;
					config->setParameter(XMLUni::fgDOMErrorHandler, &errorHandler);
					config->setParameter(XMLUni::fgDOMValidateIfSchema, true);

					//reset error count first
					errorHandler.resetErrors();

					XERCES_CPP_NAMESPACE_QUALIFIER DOMDocument *doc = 0;

					try {
						// reset document pool
						parser->resetDocumentPool();
						doc = parser->parseURI(xmlFilePath);
					} catch (const XMLException& /*toCatch*/) {
						TC_write_syslog(
								"\nSEEDS Error : Error while reading XML.");
						retcode = SEEDS_XML_ERROR;
					} catch (const DOMException& /*toCatch*/) {
						TC_write_syslog(
								"\nSEEDS Error : Error while reading XML.");
						retcode = SEEDS_XML_ERROR;
					} catch (...) {
						TC_write_syslog(
								"\nSEEDS Error : Error while reading XML.");
						retcode = SEEDS_XML_ERROR;
					}

					//
					//  Extract the DOM tree, get the list of all the elements and report the
					//  length as the count of elements.
					//
					if (errorHandler.getSawErrors()) {
						TC_write_syslog("\nSEEDS Error : Error while initializing xml parser.");
						retcode = SEEDS_XML_ERROR;
					} else if (doc != NULL) {
						retcode = readChildElements((DOMNode*) doc->getDocumentElement(), start, rear);
						if (retcode != ITK_ok) {
							TC_write_syslog("\nSEEDS Error : Error while initializing xml parser.");
							retcode = SEEDS_XML_ERROR;
						}
					}
				}

				//
				//  Delete the parser itself.  Must be done prior to calling Terminate, below.
				//
				parser->release();
			}
		}

		// And call the termination method
		XMLPlatformUtils::Terminate();
	}

	return retcode;
}


DOMXMLErrorHandler::DOMXMLErrorHandler() :

    fSawErrors(false)
{
}

DOMXMLErrorHandler::~DOMXMLErrorHandler()
{
}


// ---------------------------------------------------------------------------
//  DOMCountHandlers: Overrides of the DOM ErrorHandler interface
// ---------------------------------------------------------------------------
bool DOMXMLErrorHandler::handleError(const DOMError& /*domError*/)
{
    fSawErrors = true;

    return true;
}

void DOMXMLErrorHandler::resetErrors()
{
    fSawErrors = false;
}
