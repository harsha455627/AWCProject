/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#ifndef TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_O6TANECUSTOMSERVICE_HXX 
#define TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_O6TANECUSTOMSERVICE_HXX


#include <o6tanecustomservice1706.hxx>
#include <o6tanecustomservice1711.hxx>
#include <o6tanecustomservice1712.hxx>


namespace O6
{
    namespace Soa
    {
        namespace CustomServiceLibrary
        {
            class O6TaneCustomService;
        }
    }
}


/**
 * Custom Service
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libo6soacustomservicelibrary.dll
 * </li>
 * </ul>
 */

class O6::Soa::CustomServiceLibrary::O6TaneCustomService
    : public O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomService,
             public O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomService,
             public O6::Soa::CustomServiceLibrary::_2017_12::O6TaneCustomService
{};

#endif

