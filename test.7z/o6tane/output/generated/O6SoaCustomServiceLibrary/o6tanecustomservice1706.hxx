/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_06_O6TANECUSTOMSERVICE_HXX 
#define TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_06_O6TANECUSTOMSERVICE_HXX


#include <tccore/WorkspaceObject.hxx>
#include <teamcenter/soa/server/ServiceData.hxx>



#include <teamcenter/soa/server/ServiceException.hxx>
#include <metaframework/BusinessObjectRef.hxx>

#include <CustomServiceLibrary_exports.h>

namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmStream; }}}}
namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmParser; }}}}
namespace O6 { namespace Services { namespace CustomServiceLibrary { namespace _2017_06 { class O6TaneCustomServiceIiopSkeleton; }}}}


namespace O6
{
    namespace Soa
    {
        namespace CustomServiceLibrary
        {
            namespace _2017_06
            {
                class O6TaneCustomService;
            }
        }
    }
}


class SOACUSTOMSERVICELIBRARY_API O6::Soa::CustomServiceLibrary::_2017_06::O6TaneCustomService

{
public:

    static const std::string XSD_NAMESPACE;

    struct TargetObjecs;

    struct  TargetObjecs
    {
        /**
         * contain list of strings of Target Objects
         */
        std::vector< std::string > displaynames;
        /**
         * real names
         */
        std::vector< std::string > realnames;
        /**
         * Naming Rule Pattern
         */
        std::vector< std::string > nrPattern;

    private:
        friend class Teamcenter::Soa::Internal::Server::SdmStream;
        friend class O6::Services::CustomServiceLibrary::_2017_06::O6TaneCustomServiceIiopSkeleton;

        void serialize( Teamcenter::Soa::Internal::Server::SdmStream* _sdmStream, const std::string& elementName="TargetObjecs" );
    };



    O6TaneCustomService();
    virtual ~O6TaneCustomService();
    

    /**
     * Calculate ingredient percentage in the BOM.
     *
     * @param obj
     *        Selected object
     *
     * @return
     *
     */
    virtual Teamcenter::Soa::Server::ServiceData calculateINCIs ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj ) = 0;

    /**
     * .
     *
     * @param obj
     *        Teamcenter Worksspace object
     *
     * @param targetItemtype
     *        Target Item Type
     *
     * @return
     *
     */
    virtual Teamcenter::Soa::Server::ServiceData copyObjectAndCreateRelation ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj,
        const std::string targetItemtype ) = 0;

    /**
     * .
     *
     * @param obj
     *        Workspace Object
     *
     * @return
     *
     */
    virtual TargetObjecs getTargets ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj ) = 0;


};

#include <CustomServiceLibrary_undef.h>
#endif

