//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  O6TaneCustomLibrary

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libO6TaneCustomLibrary

#if !defined(LIBO6TANECUSTOMLIBRARY) && !defined(IPLIB)
#   error IPLIB or LIBO6TANECUSTOMLIBRARY is not defined
#endif

/* Handwritten code should use O6TANECUSTOMLIBRARY_API, not O6TANECUSTOMLIBRARYEXPORT */

#define O6TANECUSTOMLIBRARY_API O6TANECUSTOMLIBRARYEXPORT

#if IPLIB==libO6TaneCustomLibrary || defined(LIBO6TANECUSTOMLIBRARY)
#   if defined(__lint)
#       define O6TANECUSTOMLIBRARYEXPORT       __export(O6TaneCustomLibrary)
#       define O6TANECUSTOMLIBRARYGLOBAL       extern __global(O6TaneCustomLibrary)
#       define O6TANECUSTOMLIBRARYPRIVATE      extern __private(O6TaneCustomLibrary)
#   elif defined(_WIN32)
#       define O6TANECUSTOMLIBRARYEXPORT       __declspec(dllexport)
#       define O6TANECUSTOMLIBRARYGLOBAL       extern __declspec(dllexport)
#       define O6TANECUSTOMLIBRARYPRIVATE      extern
#   else
#       define O6TANECUSTOMLIBRARYEXPORT
#       define O6TANECUSTOMLIBRARYGLOBAL       extern
#       define O6TANECUSTOMLIBRARYPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define O6TANECUSTOMLIBRARYEXPORT       __export(O6TaneCustomLibrary)
#       define O6TANECUSTOMLIBRARYGLOBAL       extern __global(O6TaneCustomLibrary)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define O6TANECUSTOMLIBRARYEXPORT      __declspec(dllimport)
#       define O6TANECUSTOMLIBRARYGLOBAL       extern __declspec(dllimport)
#   else
#       define O6TANECUSTOMLIBRARYEXPORT
#       define O6TANECUSTOMLIBRARYGLOBAL       extern
#   endif
#endif
