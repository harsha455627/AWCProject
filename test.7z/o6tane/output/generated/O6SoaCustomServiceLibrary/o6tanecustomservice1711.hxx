/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_11_O6TANECUSTOMSERVICE_HXX 
#define TEAMCENTER_SERVICES_CUSTOMSERVICELIBRARY_2017_11_O6TANECUSTOMSERVICE_HXX


#include <tccore/WorkspaceObject.hxx>
#include <teamcenter/soa/server/ServiceData.hxx>



#include <teamcenter/soa/server/ServiceException.hxx>
#include <metaframework/BusinessObjectRef.hxx>

#include <CustomServiceLibrary_exports.h>

namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmStream; }}}}
namespace Teamcenter { namespace Soa {  namespace Internal { namespace Server { class SdmParser; }}}}


namespace O6
{
    namespace Soa
    {
        namespace CustomServiceLibrary
        {
            namespace _2017_11
            {
                class O6TaneCustomService;
            }
        }
    }
}


class SOACUSTOMSERVICELIBRARY_API O6::Soa::CustomServiceLibrary::_2017_11::O6TaneCustomService

{
public:

    static const std::string XSD_NAMESPACE;




    O6TaneCustomService();
    virtual ~O6TaneCustomService();
    

    /**
     * .
     *
     * @param obj
     *        None
     *
     * @param targetItemtype
     *        None
     *
     * @param targetItemPattern
     *        None
     *
     * @param targetItemVersion
     *        None
     *
     * @return
     *
     */
    virtual Teamcenter::Soa::Server::ServiceData copyObjectAndCreateRelation ( const BusinessObjectRef<Teamcenter::WorkspaceObject>& obj,
        const std::string targetItemtype,
        const std::string targetItemPattern,
        const std::string targetItemVersion ) = 0;


};

#include <CustomServiceLibrary_undef.h>
#endif

