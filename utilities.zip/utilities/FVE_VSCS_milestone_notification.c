#include "FVE_VSCS_milestone_notification.h"
#include "textsrv/iman_textserver.h"

/******************************************************************************
 * Filename        :   FVE_VSCS_milestone_notification.c
 * Description     :   This Utility is used for VSCS Workflows
 *						1. Vehicle Program D&R SignOff Workflow
 *						2. VSCS Post Production workflow
 *						Once the above workflows are initiated, this utility checks the milestone dates
 *						attached with the respective vehicle programs and sends reminder notifications to
 *						the responsible users to complete the task. The reminder notifications are sent 
 *						before specific days till the milestone due date and those specific days are controlled
 *						through macro FVE_NOTIFY_DUEDATE_LIMIT defined in the .h file. 
 *
 * Module          :   FVE_VSCS_milestone_notification.exe
 * ENVIRONMENT     :   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name				Description of Change
 * Aug,30 2017		Vinay Deshmukh      Initial Code
 * -----------------------------------------------------------------------------
 *
 *****************************************************************************/

static void print_help(void)
{
   printf("\nUsage of FVE_VSCS_milestone_notification utility\n");
   printf("\nFVE_VSCS_milestone_notification -u=<uid> -p=<pwd> -g=<grp>\n\n");
   printf("   uid = user id to login to teamcenter to use this utility\n");
   printf("   pwd = password of user teamcenter user\n");
   printf("   grp = group of teamcenter user\n");
   printf("   -h  = print help of utility\n\n");
   printf("   example: FVE_VSCS_milestone_notification -u=xxx -p=\"\" -g=dba\n");
   printf("            FVE_VSCS_milestone_notification -u=infodba -p=infodba -g=dba\n");
}

int FVE_send_mail(tag_t reminderTask, char* dueDate, logical isDueDatePast)
{
   int      ifail                   = ITK_ok;
   int		signoff_count			= 0;
   int		num_of_signoff_count	= 0;
   int		subtask_index			= 0;
   int		subtask_count			= 0;

   tag_t    envelope                = NULLTAG;
   tag_t	memberTag				= NULLTAG;
 
   tag_t	responsible_party		= NULLTAG;

   tag_t*	signoff_tag				= NULL;
   tag_t*	sub_tasks				= NULL;

   char*    process_id              = NULL;
   char*    task_name               = NULL;
   char*    tasktype                = NULL;

   char     customSubject[1024]     = {'\0'};
   char     customComment[1024]     = {'\0'};
   char*	subtask_type			= NULL;

   char*	function_name			= "FVE_send_mail";

   SIGNOFF_TYPE_t	memberType;
   EPM_state_t		taskState       = 0;

   FV_DEBUG_TXT(("Entering %s \n", function_name))
   
   CLEANUP(AOM_ask_value_string(reminderTask, "job_name", &process_id))
   CLEANUP(AOM_ask_value_string(reminderTask, "object_name", &task_name))

   if(isDueDatePast)
   {
	   sprintf(customSubject, "Late Notification - Reminder for Process ID - {%s} ", process_id);
	   sprintf(customComment , "Workflow Task \"%s\" was due on \"%s\" ", task_name, dueDate);
   }
   else
   {
	   sprintf(customSubject, "Reminder for Process ID - {%s} ", process_id);
	   sprintf(customComment , "Workflow Task \"%s\" is due on \"%s\" ", task_name, dueDate);
   }

   CLEANUP(FV_Mail_Envelope_create(customSubject, customComment, &envelope))

   CLEANUP(AOM_ask_value_string(reminderTask, "task_type", &tasktype))
   if(tc_strcmp (tasktype , "EPMReviewTask")==0)
   {
	   FV_DEBUG_TXT(("Entering EPMReviewTask \n"))
	   
	   CLEANUP(EPM_ask_sub_tasks( reminderTask, &subtask_count, &sub_tasks))
		
	   for(subtask_index =0; subtask_index < subtask_count; subtask_index++)
	   {
		   CLEANUP(AOM_ask_value_string(sub_tasks[subtask_index], "task_type", &subtask_type))
		   CLEANUP(EPM_ask_state(sub_tasks[subtask_index], &taskState))

		   if((tc_strcmp (subtask_type , "EPMPerformSignoffTask")==0) && (taskState == EPM_started))
		   {
			   CLEANUP(EPM_ask_attachments(sub_tasks[subtask_index], EPM_signoff_attachment, &num_of_signoff_count, &signoff_tag))
			   for(signoff_count=0; signoff_count < num_of_signoff_count; signoff_count++)
			   {
					CLEANUP(EPM_ask_signoff_member( signoff_tag[signoff_count], &memberTag, &memberType))
					CLEANUP(SA_ask_groupmember_user( memberTag, &responsible_party ))
			   }  
		   }
		   else if((tc_strcmp (subtask_type , "EPMSelectSignoffTask")==0) && (taskState == EPM_started))
		   {
				CLEANUP(AOM_ask_last_modifier(sub_tasks[subtask_index], &responsible_party))
		   }
	   }
   }
   else if( (tc_strcmp (tasktype, "EPMDoTask")==0) || (tc_strcmp (tasktype, "EPMConditionTask")==0) || (tc_strcmp (tasktype, "EPMConditionTask")==0))
   {
	    //Get the responsible party for the task where this handler is attached
		CLEANUP(EPM_ask_responsible_party ( reminderTask, &responsible_party ))
   }

   if(responsible_party != NULLTAG)
   {
	   /*char*	userid	= NULL;
	   CLEANUP(SA_ask_user_identifier(responsible_party,  userid))*/
	   FV_DEBUG_TXT(("Sending email to user \n"))
	   CLEANUP(MAIL_add_envelope_receiver(envelope, responsible_party))
	   CLEANUP(MAIL_send_envelope(envelope))
   }
   else
   {
	   FV_DEBUG_TXT(("+++ERROR : Could not send email to user since NO user is assigned \n"))
   }

CLEANUP:

   FV_DEBUG_TXT(("Exiting %s\n", function_name))

   FVE_FREE(sub_tasks)
   FVE_FREE(signoff_tag)

   return ifail;
}

int FV_get_MileStone_DueDate(char* strRelAt, char* vehPrg, date_t* dueDate)
{
	int ifail				= ITK_ok;
	int entry_count			= 0;
	int num_found			= 0;
	int	iCnt				= 0;

	tag_t query_tag			= NULLTAG;
	tag_t* results			= NULL;
	
	char** entries			= NULL;
	char** values			= NULL;
	char* veh_prg_id		= TC_text(FVE_VEH_PRG_ID_ATTR);
	char* veh_milestone_id	= TC_text(FVE_MILESTONE_ID_ATTR);
	char* formattedMSDuedate= NULL;

	char*	function_name	= "FV_get_MileStone_DueDate"; 

	FV_DEBUG_TXT(("Entering %s \n", function_name))

	*dueDate = NULLDATE;

	ITK(QRY_find("__FVEGetVehMSDueDate", &query_tag))
	if(query_tag != NULLTAG)
	{
		CLEANUP(QRY_find_user_entries(query_tag, &entry_count, &entries, &values))
			
		for(iCnt = 0; iCnt < entry_count; iCnt++)
		{
				if((entries[iCnt] != NULL) && (tc_strcmp(entries[iCnt], veh_prg_id) == 0))
					values[iCnt] = vehPrg;				
				else if((entries[iCnt] != NULL) && (tc_strcmp(entries[iCnt], veh_milestone_id) == 0))
					values[iCnt] = strRelAt;
		}

		FV_DEBUG_TXT(("The Milestone Due Date Query is being made on %s and %s \n", values[0], values[1]))
		
		// Query for Milestone with * and the Milestone ID. 
		CLEANUP(QRY_execute(query_tag, entry_count, entries, values, &num_found, &results))
		if(num_found > 0)
		{
			CLEANUP(AOM_ask_value_date(results[0], FVE_MS_DUE_DATE_ATTR, dueDate))
			
			CLEANUP(DATE_date_to_string(*dueDate, DATE_FORMAT, &formattedMSDuedate))
			FV_DEBUG_TXT(("Found Milestone %s with due date %s \n", values[1], formattedMSDuedate))

			FVE_FREE(results)
		}			
	}	

CLEANUP:

	FV_DEBUG_TXT(("Exiting %s \n", function_name))

	return ifail;
}

int FV_vscs_get_valid_secondary_obj_of_type_with_relation
(
    tag_t   tPrimaryObj,
    char*   pszRelationTypeName,
    char*   pszSecondaryObjType,
    tag_t** pptSecondaryObjects,
    tag_t** pptRelationObjects,
    int*    piObjectCount
)
{

    int     ifail                           = ITK_ok;
    int     iCount                          = 0;
    int     iIterator                       = 0;
    int     iSecondaryCount                 = 0;

    tag_t   tRelationType                   = NULLTAG;

    char    szObjectType[TCTYPE_name_size_c+1] = "";
	char*	function_name					   = "FV_vscs_get_valid_secondary_obj_of_type_with_relation";	

    GRM_relation_t *ptSecondaryObjects      = NULL;

    logical hasAccess						= false;

	FV_DEBUG_TXT(("Entering %s \n", function_name))

    /* Initializing the Out Parameter to this function. */
    (*piObjectCount) = 0;
    (*pptSecondaryObjects) = NULL;
    (*pptRelationObjects) = NULL;

    /* verify input */
    if(tPrimaryObj == NULLTAG || FV_IS_STRING_EMPTY(pszSecondaryObjType))
    {
        return ifail;
    }

    /* get the "IMAN_specification" relation type tag */
    CLEANUP( GRM_find_relation_type(pszRelationTypeName,
                                                   &tRelationType)); 
    
    CLEANUP( GRM_list_secondary_objects(tPrimaryObj, tRelationType, 
                                                       &iSecondaryCount,
                                                       &ptSecondaryObjects));
                                       
    for(iIterator = 0; iIterator < iSecondaryCount && ifail == ITK_ok; iIterator++)
    {
        tag_t   tObjectType = NULLTAG;

		// There is a risk that user does not have READ access to typed reference object.
       // So check that item revision is readable before getting property values.
       CLEANUP(AM_check_privilege(ptSecondaryObjects[iIterator].secondary, FV_READ_ACCESS, &hasAccess))
       if (hasAccess)
       {
			CLEANUP(TCTYPE_ask_object_type(ptSecondaryObjects[iIterator].secondary, &tObjectType));
			CLEANUP(TCTYPE_ask_name(tObjectType, szObjectType));
     
			if (tc_strcmp(szObjectType, pszSecondaryObjType) == 0)
			{
				iCount++;
				(*pptSecondaryObjects) = (tag_t*)MEM_realloc ( (*pptSecondaryObjects) , (sizeof(tag_t) * iCount) );
				(*pptSecondaryObjects)[iCount -1] = ptSecondaryObjects[iIterator].secondary;

				(*pptRelationObjects) = (tag_t*)MEM_realloc ( (*pptRelationObjects) , (sizeof(tag_t) * iCount) );
				(*pptRelationObjects)[iCount -1] = ptSecondaryObjects[iIterator].the_relation;
			}
		}
    }

    if(iCount == 0)
    {
        TC_write_syslog("No Secondary Object associated with the %s relation to the object.\n", pszRelationTypeName);
    }
    else
    {
        (*piObjectCount ) = iCount;
    }

CLEANUP:

	FV_DEBUG_TXT(("Exiting %s \n", function_name))

    FVE_FREE(ptSecondaryObjects);
    return ifail;
}

//Tells the differnce of dates in terms of number of seconds
double FV_get_date_difference(date_t target, date_t input)
{
    double diff = 0;
    struct  tm compare_tm;
    struct  tm target_tm;

    compare_tm.tm_mday = input.day;
    compare_tm.tm_mon  = input.month;
    compare_tm.tm_year = input.year - 1900;
    compare_tm.tm_hour = 0;
    compare_tm.tm_sec  = 0;
    compare_tm.tm_min  = 0;

    target_tm.tm_mday = target.day;
    target_tm.tm_mon  = target.month;
    target_tm.tm_year = target.year - 1900;
    target_tm.tm_hour = 0;
    target_tm.tm_sec  = 0;
    target_tm.tm_min  = 0;

    diff = difftime(mktime(&target_tm), mktime(&compare_tm));
    return diff;
}

int process_task_for_notification(tag_t epmtask, tag_t childTask)
{
	int		ifail			= ITK_ok;
	int     cnt				= 0;
	int		cntVehEcuRevs	= 0;
	int		time_diff		= 0;
	int		attach_count	= 0;
	int		idx				= 0;
	int		revsCnt			= 0;

	date_t	taskStartDate		= NULLDATE;
	date_t	rel_DueDate			= NULLDATE;
	date_t  today_date			= NULLDATE; 

	tag_t*	attachments_tag		= NULL;
	tag_t*	resultTags			= NULL;
	tag_t*	vehEcuRevs			= NULL;
	tag_t*	relVehEcuRevs		= NULL;
	tag_t*	docrevs				= NULL;
	tag_t*	RelObjss			= NULL;

	tag_t	vehPrgTag			= NULLTAG;
    tag_t	vehPrgRevTag		= NULLTAG;
	tag_t	summItem			= NULLTAG;
	tag_t	RevTag				= NULLTAG;

	char*	value				= NULL;
	char*	modelYear			= NULL;
	char*	programCode			= NULL;
	char*   formattedCurrDate	= NULL;
	char*   milestone_id        = NULL;
	char*   formattedTaskDueDate= NULL;	  
	char*   vehicle_prog_id     = NULL;
    char*   vehicle_prog_rev    = NULL;
	char*	FVE_VehPrgID		= NULL;
	char*	function_name		= "process_task_for_notification";

	logical	isVehSumRev		= FALSE;
	
	FV_DEBUG_TXT(("Entering %s \n", function_name))

	GET_CURRENT_DATE_TIME(today_date)
	//notif_flag = FALSE;

	CLEANUP(DATE_date_to_string(today_date, DATE_FORMAT, &formattedCurrDate))
	FV_DEBUG_TXT(("\nToday's Date: %s\n",formattedCurrDate))

	// Get the start Date of the Task
	CLEANUP(AOM_ask_value_date(childTask, "fnd0StartDate", &taskStartDate))
	time_diff = (FV_get_date_difference(today_date, taskStartDate))/(60*60*24);

	// get the vehicle Group from the target attachment
	CLEANUP(EPM_ask_attachments(epmtask, EPM_target_attachment, &attach_count, &attachments_tag))

	// get the vehicle architecture and then the vehicle program
	for(idx = 0; idx < attach_count; idx++)
	{
		CLEANUP(FV_object_is_typeof(attachments_tag[idx], FV9VSCSSumDataRevisionTYPE, &isVehSumRev))

		if(!isVehSumRev)
		  continue;

		CLEANUP((ITEM_ask_item_of_rev(attachments_tag[idx], &summItem)))

		CLEANUP(FV_grm_get_primary_obj_of_parent_type(summItem, FV9_ArchECU_NetCom_RelTYPE, FV9VehECUGroupRevisionTYPE,
										&vehEcuRevs, &relVehEcuRevs, &cntVehEcuRevs));

		CLEANUP((AOM_ask_value_tag(vehEcuRevs[0], "fv9VehProgramRef", &vehPrgRevTag)))

		CLEANUP((AOM_ask_value_string(vehPrgRevTag, "object_string", &vehicle_prog_rev)))
		FV_DEBUG_TXT(("Vehicle Program Revision is : %s\n", vehicle_prog_rev))

		CLEANUP((ITEM_ask_item_of_rev(vehPrgRevTag, &vehPrgTag)))
		CLEANUP((AOM_ask_value_string(vehPrgTag, "object_string", &vehicle_prog_id)))
		FV_DEBUG_TXT(("Vehicle Program is : %s\n", vehicle_prog_id))

		// Get Model year and program code from vehicle group revision
		CLEANUP(AOM_ask_value_string(vehEcuRevs[0], fv9ModelYear_cmpdPROP, &modelYear)) 
		CLEANUP(AOM_ask_value_string(vehEcuRevs[0], fv9ProgramID_cmpdPROP, &programCode))
		FV_DEBUG_TXT(("ModelYear : %s and Program Code : %s\n", modelYear, programCode))

		// get Vehicle Architecture Revision from the vehicle group
		FV_find_vehicle_ecu_archs_for_vehicle_ref(vehEcuRevs[0], FV_FIND_LATEST_REV_ONLY, FV_FIND_ACTIVE_ONLY, &cnt, &resultTags);

		if(cnt > 0)
		{
			CLEANUP((AOM_ask_value_string(resultTags[0], "object_string", &value)))
			FV_DEBUG_TXT(("Vehicle Architecture is : %s\n", value))

			//Read Doc Control Revision from Vehicle Arch
			CLEANUP(FV_vscs_get_valid_secondary_obj_of_type_with_relation(resultTags[0], FV9_ArchECU_NetCom_RelTYPE, FV9VSCSDocCtrlTYPE, &docrevs, &RelObjss, &revsCnt))
				
			if(revsCnt == 0 )
			{
				FV_DEBUG_TXT(("+++ERROR : No Document Control Revision attached with Vehicle Architecture %s\n", value))
				break;
			}
			
			CLEANUP(FV_ask_latest_revision(docrevs[0], &RevTag))

		 	CLEANUP((AOM_ask_value_string(RevTag, "object_string", &value)))
			FV_DEBUG_TXT(("Document Control is: %s\n", value))

			// read releasedAt value to be checked with all milestone which would be fetched from DB
			CLEANUP(AOM_ask_value_string(RevTag, fv9VSCSReleasedAtPROP, &milestone_id))	

			FV_strdup(modelYear, &FVE_VehPrgID);
			FV_strcat(&FVE_VehPrgID, ", ");     // COMMA could not be used, since the query expects a space between model year and program code
			FV_strcat(&FVE_VehPrgID, programCode);

			// get the Milestone due dates for the ReleasedAt value from the document control revision
			CLEANUP(FV_get_MileStone_DueDate(milestone_id, FVE_VehPrgID, &rel_DueDate))
				
			if(DATE_IS_NULL(rel_DueDate))
			{
				FV_DEBUG_TXT(("+++ERROR : Milestone %s  associated with Vehicle Program %s does not have Due Date set \n", milestone_id, vehicle_prog_rev))
				goto CLEANUP;
			}

            {
				int  time_left_for_mlstn = 0;
                time_left_for_mlstn = (FV_get_date_difference(rel_DueDate, today_date))/(60*60*24);
                  
				// send  a notification only if the milestone date is within 14(FVE_NOTIFY_DUEDATE_LIMIT) days 
                if  (time_left_for_mlstn <= FVE_NOTIFY_DUEDATE_LIMIT && time_diff >= 0 && time_left_for_mlstn >= 0)
                {
					CLEANUP(DATE_date_to_string(rel_DueDate, DATE_FORMAT, &formattedTaskDueDate))

					//FVE_send_mail() will send email to the recipients of epmtask.
					FVE_send_mail (childTask, formattedTaskDueDate, FALSE); 
                }

				// Late notification - Notify if the due date has past by one day
				if( time_left_for_mlstn == -1 )
				{
					CLEANUP(DATE_date_to_string(rel_DueDate, DATE_FORMAT, &formattedTaskDueDate))
					FVE_send_mail (childTask, formattedTaskDueDate, TRUE); 
				}
            }
		}
	}

CLEANUP:

	FV_DEBUG_TXT(("Exiting %s \n", function_name))

	FVE_FREE(attachments_tag)
    FVE_FREE(resultTags)
    FVE_FREE(vehEcuRevs)
    FVE_FREE(relVehEcuRevs)
	FVE_FREE(docrevs)
	FVE_FREE(RelObjss)
	
	return ifail;
}

int FVE_Process_Task(int numWipProc, tag_t* wip_proc)
{
	int		ifail			= ITK_ok;
	int		iCntWipProc		= 0;
	int		iCnt			= 0;
	int     subtask_count	= 0;

	tag_t   epmtask			= NULLTAG;
	tag_t*  childtasks      = NULL;

	char*   process_id		= NULL;
	char*   task_name       = NULL;
	char*	function_name   = "FVE_Process_Task";

	EPM_state_t	task_state  = 0;

	FV_DEBUG_TXT(("Entering %s \n", function_name))

	// Loop for all the started task of workflow "Vehicle Program D&R Signoff" 
    for(iCntWipProc = 0; iCntWipProc < numWipProc; iCntWipProc++)
    {
		epmtask = wip_proc[iCntWipProc];
		CLEANUP(AOM_ask_value_string(epmtask, FVE_JOB_NAME, &process_id))

		CLEANUP(EPM_ask_sub_tasks(epmtask, &subtask_count, &childtasks))
		for(iCnt=0; iCnt < subtask_count; iCnt++)
		{
			CLEANUP(AOM_ask_value_string(childtasks[iCnt], FVE_OBJECT_NAME, &task_name))
			CLEANUP(EPM_ask_state(childtasks[iCnt], &task_state))
			if(task_state == EPM_started)
			{
				// Don't go to the proxy path
				if(tc_strcmp(task_name, "Proxy  Approval")== 0)
				{
					continue;
				}
				else
				{
					FV_DEBUG_TXT(("\n <%d> Process ID: %s\n", iCntWipProc+1, process_id))
					FV_DEBUG_TXT(("\n Task Name: %s\n", task_name))
					CLEANUP(process_task_for_notification(epmtask, childtasks[iCnt]))
					break;
				}
			}
		}
	}

CLEANUP:

	FV_DEBUG_TXT(("Exiting %s \n", function_name))

	FVE_FREE(childtasks)
	return ifail;
}


int FVE_process_started_task( )
{
   int         ifail                            = ITK_ok;

   int         numWipProc                       = 0;
   int         entry_count                      = 0;
   
   tag_t       qry_tag                          = NULLTAG;

   tag_t*      wip_proc                         = NULL;
   tag_t*      wf_task_assign_objs              = NULL;
   tag_t*      veh_assign_objs                  = NULL;
   tag_t*      veh_notif_objs                   = NULL;
   tag_t*      childtasks                       = NULL;   

   char*       qry_name                         = NULL;
   char**	   entries                          = NULL;
   char**	   values                           = NULL;
   

   // Entries of query "InDRSignOffWorkflow_query" are 
   // state_value = 4 and template_name = "Vehicle Program D&R Signoff"
   qry_name = IMAN_text(FVE_DRSignOff_WORKFLOW_QRY);

   FV_DEBUG_TXT(("Processing %s Query \n", FVE_DRSignOff_WORKFLOW_QRY))
   CLEANUP(QRY_find(qry_name, &qry_tag))
   if(qry_tag == NULLTAG)
   {
      FV_DEBUG_TXT(("\"InDRSignOffWorkflow_query\" query is not available in tc server\n"))
   }

   CLEANUP(QRY_find_user_entries(qry_tag, &entry_count, &entries, &values))
   CLEANUP(QRY_execute(qry_tag, entry_count, entries, values, &numWipProc, &wip_proc))

   CLEANUP(FVE_Process_Task(numWipProc, wip_proc))

   // Entries of query "InVSCSPostProdWorkflow_query" are 
   // state_value = 4 and template_name = "VSCS Post Production workflow"
   qry_name = IMAN_text(FVE_VSCSPostProduction_WORKFLOW_QRY);
   FV_DEBUG_TXT(("Processing %s Query \n", FVE_VSCSPostProduction_WORKFLOW_QRY))
   CLEANUP(QRY_find(qry_name, &qry_tag))
   if(qry_tag == NULLTAG)
   {
      FV_DEBUG_TXT(("\"InVSCSPostProdWorkflow_query\" query is not available in tc server\n"))
   }

   CLEANUP(QRY_find_user_entries(qry_tag, &entry_count, &entries, &values))
   CLEANUP(QRY_execute(qry_tag, entry_count, entries, values, &numWipProc, &wip_proc))

   CLEANUP(FVE_Process_Task(numWipProc, wip_proc))


CLEANUP:

   FVE_FREE(wf_task_assign_objs)
   FVE_FREE(veh_assign_objs)
   FVE_FREE(veh_notif_objs)
   FVE_FREE(wip_proc)
   FVE_FREE(childtasks)

   return ifail;
}

int readAndDecryptPasswd( char *passwdFile,  char **passwd )
{
    FILE         *passwdFilePtr =  NULL;
    char        buffString[BUFSIZ+1] = "\0";
    char        *chrPtr = NULL;
    char        *key = NULL;
    char        *out_passwd = NULL;
    int         ifail = ITK_ok;

    passwdFilePtr = (FILE *)fopen( passwdFile, "r" );
    if( passwdFilePtr == NULL )
    {
        FV_DEBUG_TXT(("ERROR: Could not find password file '%s'\n", passwdFile ))
        return !ITK_ok ;
    }
    if ( fgets( buffString, BUFSIZ, passwdFilePtr ) != NULL )
    {
        /* Remove the trailing new-line added by fgets */
        chrPtr = (char *)strtok( buffString, "\n" );
    }
    else
    {
        FV_DEBUG_TXT(("ERROR: Invalid format for password file '%s'\n", passwdFile ))
        return !ITK_ok ;
    }
    key = ( char *)getenv(PASSWORDKEY);
    
    if ( key  ==  NULL )
    {
        FV_DEBUG_TXT(( "ERROR: Environment PASSWORDKEY not set with the Key value for decrypting password\n\n"))
        return !ITK_ok ;
    }
    
    //DecryptPasswd( chrPtr, key, &out_passwd );
    *passwd = out_passwd;    
    return ifail;
}

extern int ITK_user_main(int argc, char **argv)
{
   int      ifail               = ITK_ok;
   char*	uid                 = NULL;
   char*	pwd                 = NULL;
   char*	grp                 = NULL;
   char*	password_file       = NULL;
  
   // Uncomment to debug
   //getch();
   argv = NULL;

   if(argc < 4)
   {
      print_help();
      exit(0);
   }
   if (ITK_ask_cli_argument("-h"))
   {
      print_help();
      exit(0);
   }

   uid				= ITK_ask_cli_argument("-u=");
   pwd				= ITK_ask_cli_argument("-p=");
   password_file	= ITK_ask_cli_argument("-pf=");
   grp				= ITK_ask_cli_argument("-g=");

   if( password_file != NULL )
   {
        readAndDecryptPasswd( password_file, &pwd) ;  
   }

   if ( uid != NULL && strlen(uid)!=0 &&  pwd != NULL && strlen(pwd)!=0 &&  grp != NULL && strlen(grp)!=0)
   {
	   ITK(ITK_init_module (uid, pwd, grp))

	   if(ifail != ITK_ok)
         printf("\n Login with user ID: %s, group:%s is unsuccessful\n", uid, grp);
       else
         printf("\n Login with uid: %s, group:%s is successful\n", uid, grp);
   }
   else
   {
	   ITK(ITK_initialize_text_services(ITK_BATCH_TEXT_MODE))

	   ITK (ITK_auto_login ())
	   if(ifail != ITK_ok)
         printf("\n Auto Login unsuccessful\n");
       else
         printf("\n Auto Login successful\n");
   }
   
   if(ifail == ITK_ok)
   {
		ITK(FVE_process_started_task())
   }

   ITK (ITK_exit_module (FALSE) );

   return ifail;
}
