//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  o6tanedispatch

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libo6tanedispatch

#if !defined(LIBO6TANEDISPATCH) && !defined(IPLIB)
#   error IPLIB or LIBO6TANEDISPATCH is not defined
#endif

/* Handwritten code should use O6TANEDISPATCH_API, not O6TANEDISPATCHEXPORT */

#define O6TANEDISPATCH_API O6TANEDISPATCHEXPORT

#if IPLIB==libo6tanedispatch || defined(LIBO6TANEDISPATCH)
#   if defined(__lint)
#       define O6TANEDISPATCHEXPORT       __export(o6tanedispatch)
#       define O6TANEDISPATCHGLOBAL       extern __global(o6tanedispatch)
#       define O6TANEDISPATCHPRIVATE      extern __private(o6tanedispatch)
#   elif defined(_WIN32)
#       define O6TANEDISPATCHEXPORT       __declspec(dllexport)
#       define O6TANEDISPATCHGLOBAL       extern __declspec(dllexport)
#       define O6TANEDISPATCHPRIVATE      extern
#   else
#       define O6TANEDISPATCHEXPORT
#       define O6TANEDISPATCHGLOBAL       extern
#       define O6TANEDISPATCHPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define O6TANEDISPATCHEXPORT       __export(o6tanedispatch)
#       define O6TANEDISPATCHGLOBAL       extern __global(o6tanedispatch)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define O6TANEDISPATCHEXPORT      __declspec(dllimport)
#       define O6TANEDISPATCHGLOBAL       extern __declspec(dllimport)
#   else
#       define O6TANEDISPATCHEXPORT
#       define O6TANEDISPATCHGLOBAL       extern
#   endif
#endif
