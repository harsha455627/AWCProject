/******************************************************************************
File        : FV_gsdb_update_release_status.cpp
Description : Utility to update status for DCR objects which have status as perform-signoffs

Date          Author                    Reason
05/03/2017    VenuBabu Avala            Initial Version
****************************************************************************/  

/*
Compile
%TC_ROOT%\sample\compile -DIPLIB=none FV_gsdb_update_release_status.cpp

Link and Create Executable File
%TC_ROOT%\sample\linkitk -o FV_gsdb_update_release_status FV_gsdb_update_release_status.obj
*/

#include <tc/tc.h>
#include <tccore/tctype.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <pom/pom/pom.h>
#include <pom/enq/enq.h>
#include <tccore/grmtype.h>
#include <tccore/grm.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_basic.h>
#include <fclasses/tc_date.h>
#include <fclasses/tc_string.h>
#include <time.h>

#define ITK( argument )                                             \
{                                                                   \
	int retCode = argument;                                         \
	if ( retCode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retCode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retCode );                        \
	EMH_ask_error_text (retCode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	}                                                               \
}

#define ERROR_CHECK( argument )                                     \
{                                                                   \
	int retCode = argument;                                         \
	if ( retCode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retCode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retCode );                        \
	EMH_ask_error_text (retCode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	return retCode;                                                 \
	}                                                               \
}

/********************************* start function declarations ***********************************/

int FV_update_release_status_for_failed_objects(const char *failed_dcr_list_file,         /* <I> */ 
												const char *success_file,                 /* <I> */ 
												const char *error_file                    /* <I> */
											   );
											   
int FV_get_failed_dcr_revisons(FILE *fpList,                 /* <I> */ 
							   int *failed_count,            /* <O> */ 
							   tag_t **failed_objects        /* <OF> */
							  );
							  
int FV_update_dcr_status_with_signal_status(int failed_count,                   /* <I> */ 
                                            tag_t *failed_objects,              /* <I> */ 
											FILE *fpSuccess,                    /* <I> */ 
											FILE *fpError                       /* <I> */
										   );
										   
int FV_get_release_status_of_sec_object(tag_t object,                   /* <I> */ 
                                        char **status,                  /* <OF> */ 
										tag_t *release_status_tag       /* <O> */
									   );
									   
int FV_set_new_status(tag_t object,        /* <I> */
                      char* newStatus,     /* <I> */
				      date_t releaseDate   /* <I> */
                     );			 

void displayHelp();

/****************************** end function declarations *******************************************/

int ITK_user_main(int argc,char* argv[])
{
	int retcode = ITK_ok;

	ITK_initialize_text_services(0);

	if ( ITK_ask_cli_argument( "-h" ) != 0 )
	{
		displayHelp();
		return retcode;
	}

	char *user = ITK_ask_cli_argument("-u=");
	char *passwd = ITK_ask_cli_argument("-p=");
	char *group = ITK_ask_cli_argument("-g=");

	char *failed_dcr_list_file = ITK_ask_cli_argument("-failed_dcr_list_file=");
	char *success_file = ITK_ask_cli_argument("-success_file=");
	char *error_file = ITK_ask_cli_argument("-error_file=");

	if( user == NULL || passwd == NULL || group == NULL || failed_dcr_list_file == NULL || success_file == NULL || error_file == NULL )
	{
		displayHelp();
		return retcode;
	}
	
	ERROR_CHECK(ITK_init_module(user, passwd, group));

	logical bypass = false;

    ERROR_CHECK(ITK_ask_bypass( &bypass ));

    if( !bypass )
    {
        ITK(ITK_set_bypass( true ));
        bypass = true;
    }

	time_t start,end;
    double dif;
	
	time (&start);
	
	ITK(FV_update_release_status_for_failed_objects(failed_dcr_list_file, success_file, error_file));

    time (&end);

	dif = difftime (end,start);
	printf ("It took %.2lf seconds OR %.2lf minutes to generate the report.\n", dif,dif/60 );
	TC_write_syslog ("It took %.2lf seconds OR %.2lf minutes to generate the report.\n", dif,dif/60 );

	ERROR_CHECK(ITK_exit_module(true));

	return retcode;
}

void displayHelp()
{
	printf("************************************************************************************\n");
	printf("This utility updates the release status of DCR objects which have perform-signoffs status with the status of signals attached to them.\n\n");
	printf("This utility accepts the following arguments.\nplease run with dba previleges and turn on bypass before running this utility.\n\n");
	printf("-u=<userid>..\n");
	printf("-p=<password>..\n");
	printf("-g=<dba>..\n");
	printf("-failed_dcr_list_file=<Failed Objects will be written to this file>..\n");
    printf("-sucecss_file=<Revisions with successful status update will be written to this file>..\n");
	printf("-error_file=<Revisions which are failed during status update will be written to this file>..\n");
	printf("************************************************************************************");
}

int FV_update_release_status_for_failed_objects(const char *failed_dcr_list_file,         /* <I> */ 
												const char *success_file,                 /* <I> */ 
												const char *error_file                    /* <I> */
											   )
{
	int retcode = ITK_ok;
	int failed_count = 0;
	
	tag_t *failed_objects = NULL;
	logical dryrun = false;
	
	FILE *fpList, *fpSuccess, *fpError = NULL;
	//to be replaced by fopen_s in future VC++ versions
	fpList = fopen(failed_dcr_list_file, "w+");
	if( fpList == NULL )
	{
		printf("Unable to open the file <%s> for writing\n", failed_dcr_list_file);
		return ITK_ok;
	}
	
	fpSuccess = fopen(success_file, "w+");
	if( fpSuccess == NULL )
	{
		printf("Unable to open the file <%s> for writing\n", success_file);
		return ITK_ok;
	}
	
	fpError = fopen(error_file, "w+");
	if( fpError == NULL )
	{
		printf("Unable to open the file <%s> for writing\n", error_file);
		return ITK_ok;
	}
	fprintf(fpList,"Item ID\tRev ID\tObject Name\tStatus Name\n");
	
	ITK(FV_get_failed_dcr_revisons(fpList, &failed_count, &failed_objects));
	
	char *dry_run = ITK_ask_cli_argument("-dry_run=");
	
	if( dry_run != NULL && tc_strcmp(dry_run, "yes") == 0 )
	{
		dryrun = true;
		printf("You are runinng in dry run mode and the status will not be updated\n");
	}	
	if( !dryrun )
	{
		ITK(FV_update_dcr_status_with_signal_status(failed_count, failed_objects, fpSuccess, fpError));
	}
	
	MEM_free(failed_objects);
	
	fclose(fpList);
	fclose(fpSuccess);
	fclose(fpError);
	
	return retcode;
}

int FV_get_failed_dcr_revisons(FILE *fpList,                 /* <I> */ 
							   int *failed_count,            /* <O> */ 
							   tag_t **failed_objects        /* <OF> */
							  )
{
	int retcode = ITK_ok;	
	int rows = 0;
    int columns = 0;

    void ***report = NULL;
    
	const char *select_attr_list_item[] = {"item_id","object_name"};
	const char *select_attr_list_rev[] = {"puid","item_revision_id"};
    const char *rev_type_value[] = {"FVE_DCRRevision"};
	const char *status_name_value[] = {"perform-signoffs"};
	const char *QUERY_NAME = "DCR_failed_revs_query";

    *failed_count = 0;
    *failed_objects = NULL;

    ITK(POM_enquiry_create(QUERY_NAME));
	
	ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"Item",2,select_attr_list_item));
    ITK(POM_enquiry_add_select_attrs(QUERY_NAME,"FVE_DCRRevision",2,select_attr_list_rev));	

    ITK(POM_enquiry_set_string_value(QUERY_NAME,"rev_type_value",1,rev_type_value,POM_enquiry_const_value));
	ITK(POM_enquiry_set_string_value(QUERY_NAME,"status_name_value",1,status_name_value,POM_enquiry_const_value));
    
    ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp1","FVE_DCRRevision","object_type",POM_enquiry_equal,"rev_type_value"));
	ITK(POM_enquiry_set_attr_expr(QUERY_NAME,"exp2","ReleaseStatus","name",POM_enquiry_equal,"status_name_value"));
	
    ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp3","FVE_DCRRevision","items_tag",POM_enquiry_equal,"Item","puid"));
    ITK(POM_enquiry_set_join_expr(QUERY_NAME,"exp4","FVE_DCRRevision","release_status_list",POM_enquiry_equal,"ReleaseStatus","puid"));
       
    ITK(POM_enquiry_set_expr(QUERY_NAME,"exp5","exp3",POM_enquiry_and,"exp4"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp6","exp5",POM_enquiry_and,"exp1"));
	ITK(POM_enquiry_set_expr(QUERY_NAME,"exp7","exp6",POM_enquiry_and,"exp2"));

    ITK(POM_enquiry_set_where_expr(QUERY_NAME,"exp7"));

    /* execute the query */
    ITK(POM_enquiry_execute(QUERY_NAME,&rows,&columns,&report));
    printf("No Of <FVE_DCRRevision> objects found with status <perform-signoffs> = <%d>\n", rows);

    ITK(POM_enquiry_delete(QUERY_NAME));

    if( rows > 0 )
    {
        int inx = 0;

        *failed_objects = (tag_t *) MEM_alloc(rows*sizeof(tag_t));
        *failed_count = rows;
		
        for(inx = 0; inx < rows; inx++)
        {
			(*failed_objects)[inx] = (tag_t)(*((tag_t*) report[inx][2]));
			fprintf(fpList,"%s\t%s\t%s\tperform-signoffs\n",report[inx][0], report[inx][3], report[inx][1]);
        }
    }
	
	return retcode;
}

int FV_update_dcr_status_with_signal_status(int failed_count,                   /* <I> */ 
                                            tag_t *failed_objects,              /* <I> */ 
											FILE *fpSuccess,                    /* <I> */ 
											FILE *fpError                       /* <I> */
										   )
{
	int retcode = ITK_ok;
	
	tag_t relation_type_tag = NULLTAG;
	
	ITK(GRM_find_relation_type("CMHasImpactedItem", &relation_type_tag));
	
	if(relation_type_tag == NULLTAG)
	{
		printf("Unable to find CMHasImpactedItem relation in Teamcenter. Exiting...\n");
		return retcode;
	}
	
	for (int inx = 0; inx < failed_count; inx++)
	{
		int sec_count = 0;
		
		tag_t *sec_objects = NULL;
		
		char *dcr_object_string = NULL;
		
		ITK(AOM_ask_value_string(failed_objects[inx], "object_string", &dcr_object_string));
		
		ITK(GRM_list_secondary_objects_only(failed_objects[inx], relation_type_tag, &sec_count, &sec_objects));
		
		if( sec_count > 0 )
		{
			tag_t release_status_tag = NULLTAG;
			
			char *sec_status = NULL;
			
			ITK(FV_get_release_status_of_sec_object(sec_objects[0], &sec_status, &release_status_tag));
			
			if( release_status_tag != NULL && tc_strcmp(sec_status, "perform-signoffs") != 0 )
			{
				char *sec_object_string = NULL;
				date_t release_date = NULLDATE;
				
				ITK(AOM_ask_value_string(sec_objects[0], "object_string", &sec_object_string));
				printf("%s has status %s\n", sec_object_string, sec_status);
				
				ITK(AOM_ask_value_date(release_status_tag, "date_released", &release_date));
				
				retcode = FV_set_new_status(failed_objects[inx], sec_status, release_date);
				
				if( retcode != ITK_ok )
				{
					char* error_text = NULL;

					ITK(EMH_ask_error_text(retcode, &error_text));

					fprintf(fpError, "Unable to update status for object %s. Error Code : %d\tError Message : %s\n", dcr_object_string, retcode, error_text);
					
					MEM_free(error_text);
				}
				else
				{
					fprintf(fpSuccess, "%s was updated successfully with new status %s\n", dcr_object_string, sec_status);
				}
				
				MEM_free(sec_object_string);
			}
			else
			{
				fprintf(fpError, "%s has either no status for secondary object or secondary object also has perform-signoffs status\n", dcr_object_string);
			}
			MEM_free(sec_status);
		}
		else
		{
			fprintf(fpError, "%s has no secondary objects attached to it. so not updating.\n", dcr_object_string);
		}
		MEM_free(dcr_object_string);
		MEM_free(sec_objects);
	}
	
	return retcode;
}

int FV_get_release_status_of_sec_object(tag_t object,                   /* <I> */ 
                                        char **status,                  /* <OF> */ 
										tag_t *release_status_tag       /* <O> */
									   )
{
	int retcode = ITK_ok;
	int status_count = 0;
	
	tag_t *status_objects = NULL;
	
	*release_status_tag = NULL;
	*status = NULL;
	
	ITK(AOM_ask_value_tags(object, "release_status_list", &status_count, &status_objects));
	
	if( status_count > 0 )
	{
		char *status_name = NULL;
		
		ITK(AOM_ask_value_string(status_objects[0], "name", &status_name));
		
		*status = (char *) MEM_alloc(sizeof(char)*(tc_strlen(status_name)+1));
		tc_strcpy(*status, status_name);
		
		*release_status_tag = status_objects[0];
		
		MEM_free(status_name);
	}
	
	MEM_free(status_objects);
	
	return retcode;
}

int FV_set_new_status(tag_t object,        /* <I> */
                      char* newStatus,     /* <I> */
				      date_t releaseDate   /* <I> */
                     )
{
    int retcode = ITK_ok;
 
    tag_t tStatusClass = NULLTAG;
    tag_t tInstance = NULLTAG;
    tag_t instClassId = NULLTAG;
    tag_t tStatusDate = NULLTAG;
    tag_t tAttrDateId = NULLTAG;
    tag_t tRelStatusAttrId = NULLTAG;

    char *classname = NULL;
	
    ERROR_CHECK(POM_class_id_of_class("ReleaseStatus",&tStatusClass));

    ERROR_CHECK(POM_create_instance(tStatusClass,&tInstance));

    ERROR_CHECK(RELSTAT_initialize_release_status(tInstance, newStatus));

    ERROR_CHECK(POM_class_of_instance(object,&instClassId));

    ERROR_CHECK(POM_name_of_class(instClassId,&classname));

    ERROR_CHECK(POM_attr_id_of_attr("release_status_list",classname,&tRelStatusAttrId));

    //ITK(AOM_refresh(object,POM_modify_lock));
    ERROR_CHECK(AOM_lock( object ));

    ERROR_CHECK(POM_set_attr_tags(1,&object,tRelStatusAttrId,0,1,&tInstance));

    ERROR_CHECK(POM_attr_id_of_attr("date_released","ReleaseStatus",&tStatusDate));

    ERROR_CHECK(POM_set_attr_date(1,&tInstance,tStatusDate,releaseDate));

    ERROR_CHECK(POM_attr_id_of_attr("date_released",classname,&tAttrDateId ));

    ERROR_CHECK(POM_set_attr_date(1,&object,tAttrDateId,releaseDate));

    ERROR_CHECK(POM_save_instances(1,&tInstance,FALSE));

    ERROR_CHECK(AOM_save(object));

    //ITK(AOM_refresh(object,POM_no_lock));
    ERROR_CHECK(AOM_unlock( object ));

    MEM_free( classname );
	
    return retcode;
}