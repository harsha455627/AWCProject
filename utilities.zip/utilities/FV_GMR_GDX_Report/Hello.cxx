//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================

#include <teamcenter/hello/Hello.hxx>

#include <teamcenter/clientx/AppXSession.hxx>
#include <teamcenter/hello/GDXReport.hxx>

#include <teamcenter/soa/client/model/User.hxx>
#include <teamcenter/soa/client/RuntimeException.hxx>

#include <iostream>
#include <fstream>
#include <sstream>

#ifdef WIN32
#include <tchar.h>
#endif

using namespace std;
using namespace Teamcenter::ClientX;
using namespace Teamcenter::Hello;
using namespace Teamcenter::Soa::Client;
using namespace Teamcenter::Soa::Client::Model;


/**
    * @param args    -help or -h will print out a Usage statement
    */

#ifdef WIN32
int _tmain(int argc, _TCHAR* argv[])
#else
int main(int argc, char* argv[])
#endif
{
	int ifail = ITK_ok;

    if (argc > 1)
    {
        if (strcmp( argv[1],"-help")==0 || strcmp(argv[1],"-h")==0)
        {
            cout << "usage: Hello [-host http://server:port/tc " << endl;
			cout<< "-u <user_name>" << endl;
			cout<< "-k <Full Path to encryption key File> " << endl;
			cout <<"-pf <Full Path to Encrypted Password File>" << endl;
			cout <<"-template <Excel Template file Name for report, Multiple templates can be given separated by \",\">" << endl;
			cout <<"-repName <Name for Generated report,For Multiple templates, give names separated by \",\">" << endl;
			cout <<" NOTE: _<timestamp> will be appended to report names"<<endl;
			cout <<"-outDir <Full Path to Local Output Directory> " << endl;
			cout <<"-cert <OPTIONAL: <Mandatoy only when connecting to host using HTTPS protocol>, \n\t Full Path to server CA Certificate File> ] " << endl;
            return 0;
        }
    }

    // Get optional host information
    std::string serverHost = "http://localhost:7001/tc";
	std::string username = "infodba";
	std::string keyfilePath = "";
	std::string userPwd = "";
	std::string directory = "";
	std::string templateName = "";
	std::string repName = "";
	std::string certPath = "";
	vector<string> templates;
	vector<string> repNames;

	char*	executable_command				= NULL;

	if(argc > 14)
	{
		if(strcmp( argv[1], "-host")==0 )
		{
			serverHost = argv[2];
		}
		if(strcmp( argv[3], "-u")==0 )
		{
			username = argv[4];
		}
		if(strcmp( argv[5], "-k")==0 )
		{
			keyfilePath = argv[6];
		}
		if(strcmp( argv[7], "-pf")==0 )
		{
			FILE*	pipe							= NULL;
			std::string pfPath = argv[8];
			FILE* pfFilePrt = fopen(pfPath.c_str(),"r+");
			if(pfFilePrt != NULL)
			{				
				#if defined(WNT)  
						char	fileline[1024 + 1]              = "";
						char	fileline_tmp[1024 + 1]          = "";
						while(fgets(fileline, 1024, pfFilePrt) != NULL) 
						{
							int len = strlen(fileline);
							 /* Remove the trailing new-line added by fgets */
							if (len > 0 && fileline[len-1] == '\n')
									fileline[len-1] = '\0';

							strcpy( fileline_tmp, fileline);

							executable_command = (char *)MEM_alloc((int)(1024)*sizeof(char) );
							strcpy(executable_command,(char*)TC_getenv("TC_ROOT"));
							strcat(executable_command,FV_FILEPATH_DELIMITER);
							strcat(executable_command,"install");
							strcat(executable_command,FV_FILEPATH_DELIMITER);
							strcat(executable_command,"install");
							strcat(executable_command,FV_FILEPATH_DELIMITER);
							strcat(executable_command,FV_CRYPT_EXE_NAME);
							strcat(executable_command," ");
							strcat(executable_command,"/d");
							strcat(executable_command," ");
							strcat(executable_command,fileline_tmp);

							//printf("\nCommand : %s\n",executable_command);

							  pipe = _popen(executable_command,"r");
							  if (pipe)
							  {
								char buffer[128];
								std::string result = "";
								while(!feof(pipe)) {
    								if(fgets(buffer, 128, pipe) != NULL)
    									result += buffer;
								}
								_pclose(pipe);

								userPwd = result;
								userPwd = userPwd.substr(0, userPwd.size()-1);
							  
							  }
						}
					#else
					  /* This behavior is only for Solaris server. */

							executable_command = (char *)MEM_alloc((int)(1024 + 16)*sizeof(char) );
							strcpy(executable_command,FV_CRYPT_EXE_NAME);
							strcat(executable_command,FV_SPACE);
							strcat(executable_command,"-a");
							strcat(executable_command,FV_SPACE);
							strcat(executable_command,"aes");
							strcat(executable_command,FV_SPACE);
							strcat(executable_command,"-k");
							strcat(executable_command,FV_SPACE);
							strcat(executable_command,keyfilePath.c_str());
							strcat(executable_command,FV_SPACE);
							strcat(executable_command,"-i");
							strcat(executable_command,FV_SPACE);
							strcat(executable_command,pfPath.c_str());


					  pipe = popen(executable_command,"r");
					  if (pipe)
					  {
						char buffer[128];
						std::string result = "";
						while(!feof(pipe)) {
    						if(fgets(buffer, 128, pipe) != NULL)								
    							result += buffer;
						}
						pclose(pipe);
						userPwd = result;
						userPwd = userPwd.substr(0, userPwd.size()-1);
					  }
					#endif
			}
			else
			{
				cout << "ERROR Reading password file, make sure the path entered is valid. " << endl;
				return 0;
			}
		}
		if(strcmp( argv[9], "-template")==0 )
		{
			templateName = argv[10];
			if(templateName.empty() == false)
			{
				istringstream f(templateName);
				string s;    
				while (getline(f, s, ',')) {
					cout << s << endl;
					templates.push_back(s);
				}				
			}
			else
			{
				cout << "ERROR: Template Name argument Value is empty. Exiting..." << endl;
				return 0;
			}
		}

		if(strcmp( argv[11], "-repName")==0 )
		{
			repName = argv[12];
			if(repName.empty() == false)
			{				
				istringstream f(repName);
				string s;    
				while (getline(f, s, ',')) {
					cout << s << endl;
					repNames.push_back(s);
				}				
			}
			else
			{
				cout << "ERROR: Template Name argument Value is empty. Exiting..." << endl;
				return 0;
			}
		}
		if(strcmp( argv[13], "-outDir")==0 )
		{
			directory = argv[14];
		}

		if((serverHost.find("HTTPS",0) == 0) ||(serverHost.find("https",0) == 0))
		{
			if(argc > 16)
			{
				if(strcmp( argv[15], "-cert")==0 )
				{
					certPath = argv[16];
				}
			}
			else
			{
				cout << "ERROR :Missing CA Certificate File Path for Host Server. " << endl;
				return 0;
			}
		}
	}
	else
	{
            cout << "usage: Hello [-host http://server:port/tc " << endl;
			cout<< "-u <user_name>" << endl;
			cout<< "-k <Full Path to encryption key File> " << endl;
			cout <<"-pf <Full Path to Encrypted Password File>" << endl;
			cout <<"-template <Excel Template file Name for report, Multiple templates can be given separated by \",\">" << endl;
			cout <<"-repName <Name for Generated report,For Multiple templates, give names separated by \",\">" << endl;
			cout <<" NOTE: _<timestamp> will be appended to report names"<<endl;
			cout <<"-outDir <Full Path to Local Output Directory> " << endl;
			cout <<"-cert <OPTIONAL: <Mandatoy only when connecting to host using HTTPS protocol>, \n\t Full Path to server CA Certificate File> ] " << endl;
            return 0;
	}

    AppXSession     session(serverHost,certPath);
    GDXReport       report;
	FILE *			gdxLogFile;
	
    try
	{
			string currDate = report.currentDateTime();
			string abs_path = "GDX_" + currDate + ".log" ;

			#ifdef UNX
				gdxLogFile =fopen(abs_path.c_str(), "w");
			#else
				  fopen_s(&gdxLogFile,abs_path.c_str(), "w");
			#endif


			cout << "\nLOG INFORMATION WILL BE WRITTEN TO : " << abs_path << endl;

		    fprintf(gdxLogFile,"Logging In....\n");
			fflush(gdxLogFile);
			// Establish a session with the Teamcenter Server
	
			Teamcenter::Soa::Common::AutoPtr<User> user = session.login(username,userPwd);
			if( user.isNull())
			{
				fprintf(gdxLogFile,"Login Failed....\n");
				fflush(gdxLogFile);
				fclose(gdxLogFile);
				return 0;
			}
			else
			{						
				fprintf(gdxLogFile,"Login Successfull....\n\n");
				fprintf(gdxLogFile,"Processing Begins to generate GDX Excel Report...\n");
				fflush(gdxLogFile);

				
				ITK_init_from_cpp(argc,argv);
				//ITK_initialize_text_services(0);

				fprintf(gdxLogFile,"Initialization complete\n");
				fflush(gdxLogFile);

				report.generateReport(gdxLogFile,directory,templates,repNames);

				fprintf(gdxLogFile,"Processing Ends for generate GDX Excel Report, Logging Out..\n\n");
				fflush(gdxLogFile);

				//ITK_exit_module(true);
				session.logout();

				fprintf(gdxLogFile,"logged Out Successfully\n");
				fflush(gdxLogFile);
				fclose(gdxLogFile);
			}
    }
    catch( Teamcenter::Soa::Client::RuntimeException& e)
    {
        cout << e.getMessage() << endl;
        cout << "The application will terminate." << endl;
    }
    return ifail;
}



